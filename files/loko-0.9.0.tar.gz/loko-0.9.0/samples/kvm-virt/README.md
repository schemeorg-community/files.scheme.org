# Virtual machine using KVM

This is a (very) hacked together PC emulator based on Linux KVM. It
requires Linux, a processor that supports virtualization, and X11 for
graphics.
