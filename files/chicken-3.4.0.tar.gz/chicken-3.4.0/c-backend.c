/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:59
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[814];
static double C_possibly_force_alignment;


/* from getsize in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1050(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1050(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1046(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1046(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8815)
static void C_ccall f_8815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1152)
static void C_ccall f_1152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8507)
static void C_ccall f_8507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8781)
static void C_ccall f_8781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8769)
static void C_ccall f_8769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8700)
static void C_ccall f_8700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8687)
static void C_ccall f_8687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8569)
static void C_ccall f_8569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8516)
static C_word C_fcall f_8516(C_word *a,C_word t0);
C_noret_decl(f_8513)
static C_word C_fcall f_8513(C_word t0);
C_noret_decl(f_8510)
static C_word C_fcall f_8510(C_word t0);
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7820)
static void C_fcall f_7820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8336)
static void C_fcall f_8336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8278)
static void C_fcall f_8278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8242)
static void C_fcall f_8242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_fcall f_8207(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8159)
static void C_fcall f_8159(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_fcall f_8111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8063)
static void C_fcall f_8063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8028)
static void C_fcall f_8028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7992)
static void C_fcall f_7992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7956)
static void C_fcall f_7956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7934)
static void C_fcall f_7934(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_fcall f_7929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7924)
static void C_fcall f_7924(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6930)
static void C_fcall f_6930(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6957)
static void C_fcall f_6957(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7152)
static void C_fcall f_7152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7161)
static void C_fcall f_7161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7170)
static void C_ccall f_7170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_fcall f_7558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_fcall f_7525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7535)
static void C_ccall f_7535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_fcall f_7493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_fcall f_7458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7388)
static void C_fcall f_7388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_fcall f_7343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_fcall f_7311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7279)
static void C_fcall f_7279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7247)
static void C_fcall f_7247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7193)
static void C_fcall f_7193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6902)
static void C_fcall f_6902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5760)
static void C_fcall f_5760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_fcall f_5862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_fcall f_5895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5991)
static void C_fcall f_5991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6623)
static void C_fcall f_6623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_fcall f_6643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_fcall f_6577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_fcall f_6527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_fcall f_6477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_fcall f_6438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_fcall f_6399(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_fcall f_6360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_fcall f_6321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_fcall f_6261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_fcall f_6222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_fcall f_6186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6150)
static void C_fcall f_6150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_fcall f_6114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_fcall f_6078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6043)
static void C_fcall f_6043(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_fcall f_6038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5690)
static void C_fcall f_5690(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5685)
static void C_fcall f_5685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5224)
static void C_fcall f_5224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5233)
static void C_fcall f_5233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_fcall f_5245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_fcall f_5257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_fcall f_5297(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4901)
static void C_fcall f_4901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4773)
static void C_fcall f_4773(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4802)
static void C_fcall f_4802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_fcall f_4805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_fcall f_4789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_fcall f_3911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_fcall f_3939(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_fcall f_4557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_fcall f_4005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_fcall f_4519(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_fcall f_4462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_fcall f_4483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_fcall f_4426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_fcall f_4393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_fcall f_4402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_fcall f_4347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_fcall f_4037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_fcall f_3649(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_fcall f_3478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_fcall f_3484(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_fcall f_3680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_fcall f_3687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_fcall f_3776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_fcall f_3515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_fcall f_3822(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_fcall f_3837(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_fcall f_3853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_fcall f_3899(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_fcall f_3192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_fcall f_3378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_fcall f_3381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_fcall f_3427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_fcall f_3231(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_fcall f_3195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_fcall f_2941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_fcall f_2979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_fcall f_3000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_fcall f_3065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_fcall f_2792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_fcall f_2882(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_fcall f_2626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_fcall f_2652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_fcall f_2629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1199)
static void C_fcall f_1199(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2594)
static void C_fcall f_2594(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_fcall f_1202(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_fcall f_2495(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_fcall f_1846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_fcall f_1852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_fcall f_2003(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1384)
static void C_fcall f_1384(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_fcall f_1157(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_7820)
static void C_fcall trf_7820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7820(t0,t1);}

C_noret_decl(trf_8336)
static void C_fcall trf_8336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8336(t0,t1);}

C_noret_decl(trf_8278)
static void C_fcall trf_8278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8278(t0,t1);}

C_noret_decl(trf_8242)
static void C_fcall trf_8242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8242(t0,t1);}

C_noret_decl(trf_8207)
static void C_fcall trf_8207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8207(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8207(t0,t1);}

C_noret_decl(trf_8159)
static void C_fcall trf_8159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8159(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8159(t0,t1);}

C_noret_decl(trf_8111)
static void C_fcall trf_8111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8111(t0,t1);}

C_noret_decl(trf_8063)
static void C_fcall trf_8063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8063(t0,t1);}

C_noret_decl(trf_8028)
static void C_fcall trf_8028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8028(t0,t1);}

C_noret_decl(trf_7992)
static void C_fcall trf_7992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7992(t0,t1);}

C_noret_decl(trf_7956)
static void C_fcall trf_7956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7956(t0,t1);}

C_noret_decl(trf_7934)
static void C_fcall trf_7934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7934(t0,t1);}

C_noret_decl(trf_7929)
static void C_fcall trf_7929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7929(t0,t1);}

C_noret_decl(trf_7924)
static void C_fcall trf_7924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7924(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7924(t0,t1);}

C_noret_decl(trf_7735)
static void C_fcall trf_7735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7735(t0,t1);}

C_noret_decl(trf_6930)
static void C_fcall trf_6930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6930(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6930(t0,t1);}

C_noret_decl(trf_6957)
static void C_fcall trf_6957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6957(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6957(t0,t1);}

C_noret_decl(trf_7152)
static void C_fcall trf_7152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7152(t0,t1);}

C_noret_decl(trf_7161)
static void C_fcall trf_7161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7161(t0,t1);}

C_noret_decl(trf_7558)
static void C_fcall trf_7558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7558(t0,t1);}

C_noret_decl(trf_7525)
static void C_fcall trf_7525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7525(t0,t1);}

C_noret_decl(trf_7493)
static void C_fcall trf_7493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7493(t0,t1);}

C_noret_decl(trf_7458)
static void C_fcall trf_7458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7458(t0,t1);}

C_noret_decl(trf_7388)
static void C_fcall trf_7388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7388(t0,t1);}

C_noret_decl(trf_7343)
static void C_fcall trf_7343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7343(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7343(t0,t1);}

C_noret_decl(trf_7311)
static void C_fcall trf_7311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7311(t0,t1);}

C_noret_decl(trf_7279)
static void C_fcall trf_7279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7279(t0,t1);}

C_noret_decl(trf_7247)
static void C_fcall trf_7247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7247(t0,t1);}

C_noret_decl(trf_7215)
static void C_fcall trf_7215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7215(t0,t1);}

C_noret_decl(trf_7193)
static void C_fcall trf_7193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7193(t0,t1);}

C_noret_decl(trf_6902)
static void C_fcall trf_6902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6902(t0,t1);}

C_noret_decl(trf_5760)
static void C_fcall trf_5760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5760(t0,t1);}

C_noret_decl(trf_5862)
static void C_fcall trf_5862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5862(t0,t1);}

C_noret_decl(trf_5895)
static void C_fcall trf_5895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5895(t0,t1);}

C_noret_decl(trf_5991)
static void C_fcall trf_5991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5991(t0,t1);}

C_noret_decl(trf_6623)
static void C_fcall trf_6623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6623(t0,t1);}

C_noret_decl(trf_6643)
static void C_fcall trf_6643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6643(t0,t1);}

C_noret_decl(trf_6577)
static void C_fcall trf_6577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6577(t0,t1);}

C_noret_decl(trf_6527)
static void C_fcall trf_6527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6527(t0,t1);}

C_noret_decl(trf_6477)
static void C_fcall trf_6477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6477(t0,t1);}

C_noret_decl(trf_6438)
static void C_fcall trf_6438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6438(t0,t1);}

C_noret_decl(trf_6399)
static void C_fcall trf_6399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6399(t0,t1);}

C_noret_decl(trf_6360)
static void C_fcall trf_6360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6360(t0,t1);}

C_noret_decl(trf_6321)
static void C_fcall trf_6321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6321(t0,t1);}

C_noret_decl(trf_6261)
static void C_fcall trf_6261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6261(t0,t1);}

C_noret_decl(trf_6222)
static void C_fcall trf_6222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6222(t0,t1);}

C_noret_decl(trf_6186)
static void C_fcall trf_6186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6186(t0,t1);}

C_noret_decl(trf_6150)
static void C_fcall trf_6150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6150(t0,t1);}

C_noret_decl(trf_6114)
static void C_fcall trf_6114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6114(t0,t1);}

C_noret_decl(trf_6078)
static void C_fcall trf_6078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6078(t0,t1);}

C_noret_decl(trf_6052)
static void C_fcall trf_6052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6052(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6052(t0,t1,t2);}

C_noret_decl(trf_6043)
static void C_fcall trf_6043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6043(t0,t1,t2);}

C_noret_decl(trf_6038)
static void C_fcall trf_6038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6038(t0,t1);}

C_noret_decl(trf_5690)
static void C_fcall trf_5690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5690(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5690(t0,t1,t2);}

C_noret_decl(trf_5685)
static void C_fcall trf_5685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5685(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5685(t0,t1);}

C_noret_decl(trf_5224)
static void C_fcall trf_5224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5224(t0,t1);}

C_noret_decl(trf_5233)
static void C_fcall trf_5233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5233(t0,t1);}

C_noret_decl(trf_5245)
static void C_fcall trf_5245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5245(t0,t1);}

C_noret_decl(trf_5257)
static void C_fcall trf_5257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5257(t0,t1);}

C_noret_decl(trf_5297)
static void C_fcall trf_5297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5297(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5297(t0,t1);}

C_noret_decl(trf_4901)
static void C_fcall trf_4901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4901(t0,t1);}

C_noret_decl(trf_4773)
static void C_fcall trf_4773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4773(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4773(t0,t1,t2);}

C_noret_decl(trf_4802)
static void C_fcall trf_4802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4802(t0,t1);}

C_noret_decl(trf_4805)
static void C_fcall trf_4805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4805(t0,t1);}

C_noret_decl(trf_4789)
static void C_fcall trf_4789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4789(t0,t1);}

C_noret_decl(trf_4709)
static void C_fcall trf_4709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4709(t0,t1,t2);}

C_noret_decl(trf_3911)
static void C_fcall trf_3911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3911(t0,t1);}

C_noret_decl(trf_3939)
static void C_fcall trf_3939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3939(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3939(t0,t1);}

C_noret_decl(trf_4557)
static void C_fcall trf_4557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4557(t0,t1);}

C_noret_decl(trf_4005)
static void C_fcall trf_4005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4005(t0,t1);}

C_noret_decl(trf_4519)
static void C_fcall trf_4519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4519(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4519(t0,t1,t2,t3);}

C_noret_decl(trf_4462)
static void C_fcall trf_4462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4462(t0,t1);}

C_noret_decl(trf_4483)
static void C_fcall trf_4483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4483(t0,t1);}

C_noret_decl(trf_4426)
static void C_fcall trf_4426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4426(t0,t1);}

C_noret_decl(trf_4393)
static void C_fcall trf_4393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4393(t0,t1);}

C_noret_decl(trf_4402)
static void C_fcall trf_4402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4402(t0,t1);}

C_noret_decl(trf_4347)
static void C_fcall trf_4347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4347(t0,t1);}

C_noret_decl(trf_4037)
static void C_fcall trf_4037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4037(t0,t1);}

C_noret_decl(trf_4097)
static void C_fcall trf_4097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4097(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4097(t0,t1,t2,t3);}

C_noret_decl(trf_3649)
static void C_fcall trf_3649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3649(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3649(t0,t1,t2,t3);}

C_noret_decl(trf_3478)
static void C_fcall trf_3478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3478(t0,t1);}

C_noret_decl(trf_3484)
static void C_fcall trf_3484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3484(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3484(t0,t1,t2,t3);}

C_noret_decl(trf_3680)
static void C_fcall trf_3680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3680(t0,t1,t2,t3);}

C_noret_decl(trf_3687)
static void C_fcall trf_3687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3687(t0,t1);}

C_noret_decl(trf_3776)
static void C_fcall trf_3776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3776(t0,t1);}

C_noret_decl(trf_3515)
static void C_fcall trf_3515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3515(t0,t1);}

C_noret_decl(trf_3822)
static void C_fcall trf_3822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3822(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3822(t0,t1,t2);}

C_noret_decl(trf_3837)
static void C_fcall trf_3837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3837(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3837(t0,t1,t2,t3);}

C_noret_decl(trf_3853)
static void C_fcall trf_3853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3853(t0,t1);}

C_noret_decl(trf_3899)
static void C_fcall trf_3899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3899(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3899(t0,t1,t2,t3);}

C_noret_decl(trf_3192)
static void C_fcall trf_3192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3192(t0,t1);}

C_noret_decl(trf_3378)
static void C_fcall trf_3378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3378(t0,t1);}

C_noret_decl(trf_3381)
static void C_fcall trf_3381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3381(t0,t1);}

C_noret_decl(trf_3427)
static void C_fcall trf_3427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3427(t0,t1);}

C_noret_decl(trf_3231)
static void C_fcall trf_3231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3231(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3231(t0,t1,t2);}

C_noret_decl(trf_3195)
static void C_fcall trf_3195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3195(t0,t1);}

C_noret_decl(trf_3208)
static void C_fcall trf_3208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3208(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3208(t0,t1,t2,t3);}

C_noret_decl(trf_2941)
static void C_fcall trf_2941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2941(t0,t1);}

C_noret_decl(trf_2979)
static void C_fcall trf_2979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2979(t0,t1);}

C_noret_decl(trf_3000)
static void C_fcall trf_3000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3000(t0,t1);}

C_noret_decl(trf_3065)
static void C_fcall trf_3065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3065(t0,t1);}

C_noret_decl(trf_2792)
static void C_fcall trf_2792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2792(t0,t1);}

C_noret_decl(trf_2813)
static void C_fcall trf_2813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2813(t0,t1,t2,t3);}

C_noret_decl(trf_2882)
static void C_fcall trf_2882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2882(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2882(t0,t1,t2);}

C_noret_decl(trf_2855)
static void C_fcall trf_2855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2855(t0,t1,t2);}

C_noret_decl(trf_2626)
static void C_fcall trf_2626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2626(t0,t1);}

C_noret_decl(trf_2652)
static void C_fcall trf_2652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2652(t0,t1);}

C_noret_decl(trf_2629)
static void C_fcall trf_2629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2629(t0,t1);}

C_noret_decl(trf_1199)
static void C_fcall trf_1199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1199(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1199(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2594)
static void C_fcall trf_2594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2594(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2594(t0,t1,t2,t3);}

C_noret_decl(trf_1202)
static void C_fcall trf_1202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1202(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1202(t0,t1,t2,t3);}

C_noret_decl(trf_2495)
static void C_fcall trf_2495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2495(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2495(t0,t1,t2,t3);}

C_noret_decl(trf_1846)
static void C_fcall trf_1846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1846(t0,t1);}

C_noret_decl(trf_1852)
static void C_fcall trf_1852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1852(t0,t1);}

C_noret_decl(trf_2003)
static void C_fcall trf_2003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2003(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2003(t0,t1);}

C_noret_decl(trf_1384)
static void C_fcall trf_1384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1384(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1384(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1157)
static void C_fcall trf_1157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1157(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1157(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2336)){
C_save(t1);
C_rereclaim2(2336*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,814);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],15,"\010compileroutput");
lf[2]=C_h_intern(&lf[2],12,"\010compilergen");
lf[3]=C_h_intern(&lf[3],7,"newline");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],17,"\010compilergen-list");
lf[7]=C_h_intern(&lf[7],11,"intersperse");
lf[8]=C_h_intern(&lf[8],18,"\010compilerunique-id");
lf[9]=C_h_intern(&lf[9],22,"\010compilergenerate-code");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[12]=C_h_intern(&lf[12],17,"lambda-literal-id");
lf[13]=C_h_intern(&lf[13],4,"find");
lf[14]=C_h_intern(&lf[14],14,"\004coreimmediate");
lf[15]=C_h_intern(&lf[15],4,"bool");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[18]=C_h_intern(&lf[18],4,"char");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[20]=C_h_intern(&lf[20],3,"nil");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[22]=C_h_intern(&lf[22],3,"fix");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[24]=C_h_intern(&lf[24],3,"eof");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[27]=C_h_intern(&lf[27],12,"\004coreliteral");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[31]=C_h_intern(&lf[31],2,"if");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[35]=C_h_intern(&lf[35],9,"\004coreproc");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[37]=C_h_intern(&lf[37],9,"\004corebind");
lf[38]=C_h_intern(&lf[38],8,"\004coreref");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[41]=C_h_intern(&lf[41],10,"\004coreunbox");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[44]=C_h_intern(&lf[44],13,"\004coreupdate_i");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[46]=C_h_intern(&lf[46],11,"\004coreupdate");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[50]=C_h_intern(&lf[50],16,"\004coreupdatebox_i");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[53]=C_h_intern(&lf[53],14,"\004coreupdatebox");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[56]=C_h_intern(&lf[56],12,"\004coreclosure");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[61]=C_h_intern(&lf[61],8,"for-each");
lf[62]=C_h_intern(&lf[62],4,"iota");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[64]=C_h_intern(&lf[64],8,"\004corebox");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[67]=C_h_intern(&lf[67],10,"\004corelocal");
lf[68]=C_h_intern(&lf[68],13,"\004coresetlocal");
lf[69]=C_h_intern(&lf[69],11,"\004coreglobal");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[74]=C_h_intern(&lf[74],21,"\010compilerc-ify-string");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[80]=C_h_intern(&lf[80],14,"\004coresetglobal");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1,");
lf[85]=C_h_intern(&lf[85],16,"\004coresetglobal_i");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\004],0,");
lf[90]=C_h_intern(&lf[90],14,"\004coreundefined");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[92]=C_h_intern(&lf[92],9,"\004corecall");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[98]=C_h_intern(&lf[98],26,"lambda-literal-temporaries");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_h_intern(&lf[100],22,"lambda-literal-looping");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[104]=C_h_intern(&lf[104],6,"unsafe");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[109]=C_h_intern(&lf[109],19,"no-procedure-checks");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[112]=C_h_intern(&lf[112],24,"\010compileremit-trace-info");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[115]=C_h_intern(&lf[115],16,"string-translate");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[118]=C_h_intern(&lf[118],8,"->string");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[121]=C_h_intern(&lf[121],17,"string-translate*");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[123]=C_h_intern(&lf[123],27,"lambda-literal-closure-size");
lf[124]=C_h_intern(&lf[124],28,"\010compilersource-info->string");
lf[125]=C_h_intern(&lf[125],12,"\004corerecurse");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[129]=C_h_intern(&lf[129],16,"\004coredirect_call");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[131]=C_h_intern(&lf[131],13,"\004corecallunit");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[136]=C_h_intern(&lf[136],11,"\004corereturn");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[141]=C_h_intern(&lf[141],20,"\004coreinline_allocate");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[144]=C_h_intern(&lf[144],15,"\004coreinline_ref");
lf[145]=C_h_intern(&lf[145],34,"\010compilerforeign-result-conversion");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[147]=C_h_intern(&lf[147],18,"\004coreinline_update");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[150]=C_h_intern(&lf[150],36,"\010compilerforeign-argument-conversion");
lf[151]=C_h_intern(&lf[151],33,"\010compilerforeign-type-declaration");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],19,"\004coreinline_loc_ref");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[159]=C_h_intern(&lf[159],22,"\004coreinline_loc_update");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_h_intern(&lf[165],11,"\004coreswitch");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[170]=C_h_intern(&lf[170],9,"\004corecond");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[174]=C_h_intern(&lf[174],13,"pair-for-each");
lf[175]=C_h_intern(&lf[175],13,"string-append");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[177]=C_h_intern(&lf[177],30,"\010compilerexternal-protos-first");
lf[178]=C_h_intern(&lf[178],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[179]=C_h_intern(&lf[179],22,"foreign-callback-stubs");
lf[180]=C_h_intern(&lf[180],29,"\010compilerforeign-declarations");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[183]=C_h_intern(&lf[183],28,"\010compilertarget-include-file");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[185]=C_h_intern(&lf[185],18,"\010compilerunit-name");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[187]=C_h_intern(&lf[187],19,"\010compilerused-units");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[189]=C_h_intern(&lf[189],27,"\010compilercompiler-arguments");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[195]=C_h_intern(&lf[195],18,"string-intersperse");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[199]=C_h_intern(&lf[199],7,"\003sysmap");
lf[200]=C_h_intern(&lf[200],12,"string-split");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[202]=C_h_intern(&lf[202],15,"chicken-version");
lf[203]=C_h_intern(&lf[203],15,"\003sysmatch-error");
lf[204]=C_h_intern(&lf[204],18,"\003sysdecode-seconds");
lf[205]=C_h_intern(&lf[205],15,"current-seconds");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[210]=C_h_intern(&lf[210],23,"\003syslambda-info->string");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[220]=C_h_intern(&lf[220],9,"make-list");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[224]=C_h_intern(&lf[224],4,"none");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[235]=C_h_intern(&lf[235],8,"toplevel");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[238]=C_h_intern(&lf[238],27,"\010compileremit-unsafe-marker");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[251]=C_h_intern(&lf[251],21,"small-parameter-limit");
lf[252]=C_h_intern(&lf[252],11,"lset-adjoin");
lf[253]=C_h_intern(&lf[253],1,"=");
lf[254]=C_h_intern(&lf[254],32,"lambda-literal-callee-signatures");
lf[255]=C_h_intern(&lf[255],24,"lambda-literal-allocated");
lf[256]=C_h_intern(&lf[256],21,"lambda-literal-direct");
lf[257]=C_h_intern(&lf[257],33,"lambda-literal-rest-argument-mode");
lf[258]=C_h_intern(&lf[258],28,"lambda-literal-rest-argument");
lf[259]=C_h_intern(&lf[259],27,"\010compilermake-variable-list");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[261]=C_h_intern(&lf[261],27,"lambda-literal-customizable");
lf[262]=C_h_intern(&lf[262],29,"lambda-literal-argument-count");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[269]=C_h_intern(&lf[269],27,"\010compilermake-argument-list");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[309]=C_h_intern(&lf[309],6,"vector");
lf[310]=C_h_intern(&lf[310],23,"lambda-literal-external");
lf[311]=C_h_intern(&lf[311],14,"\003syscopy-bytes");
lf[312]=C_h_intern(&lf[312],11,"make-string");
lf[313]=C_h_intern(&lf[313],6,"modulo");
lf[314]=C_h_intern(&lf[314],3,"fx/");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_h_intern(&lf[328],23,"\010compilerencode-literal");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[330]=C_h_intern(&lf[330],32,"\010compilerblock-variable-literal\077");
lf[331]=C_h_intern(&lf[331],20,"\010compilerbig-fixnum\077");
lf[332]=C_h_intern(&lf[332],7,"sprintf");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[334]=C_h_intern(&lf[334],25,"\010compilerwords-per-flonum");
lf[335]=C_h_intern(&lf[335],6,"reduce");
lf[336]=C_h_intern(&lf[336],1,"+");
lf[337]=C_h_intern(&lf[337],12,"vector->list");
lf[338]=C_h_intern(&lf[338],14,"\010compilerwords");
lf[339]=C_h_intern(&lf[339],15,"\003sysbytevector\077");
lf[340]=C_h_intern(&lf[340],19,"\010compilerimmediate\077");
lf[341]=C_h_intern(&lf[341],19,"lambda-literal-body");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[354]=C_h_intern(&lf[354],4,"list");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[393]=C_h_intern(&lf[393],26,"\010compilertarget-stack-size");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[396]=C_h_intern(&lf[396],30,"\010compilertarget-heap-shrinkage");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[398]=C_h_intern(&lf[398],27,"\010compilertarget-heap-growth");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[400]=C_h_intern(&lf[400],33,"\010compilertarget-initial-heap-size");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[403]=C_h_intern(&lf[403],25,"\010compilertarget-heap-size");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[407]=C_h_intern(&lf[407],40,"\010compilerdisable-stack-overflow-checking");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[413]=C_h_intern(&lf[413],4,"fold");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_h_intern(&lf[416],28,"\010compilerinsert-timer-checks");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[421]=C_h_intern(&lf[421],14,"no-argc-checks");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[468]=C_h_intern(&lf[468],16,"\010compilercleanup");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"o");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[476]=C_h_intern(&lf[476],18,"\010compilerreal-name");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[478]=C_h_intern(&lf[478],25,"emit-procedure-table-info");
lf[479]=C_h_intern(&lf[479],31,"generate-foreign-callback-stubs");
lf[480]=C_h_intern(&lf[480],31,"\010compilergenerate-foreign-stubs");
lf[481]=C_h_intern(&lf[481],29,"\010compilerforeign-lambda-stubs");
lf[482]=C_h_intern(&lf[482],36,"\010compilergenerate-external-variables");
lf[483]=C_h_intern(&lf[483],27,"\010compilerexternal-variables");
lf[484]=C_h_intern(&lf[484],1,"p");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[505]=C_h_intern(&lf[505],11,"string-copy");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[507]=C_h_intern(&lf[507],13,"list-tabulate");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[510]=C_h_intern(&lf[510],41,"\010compilergenerate-foreign-callback-header");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[523]=C_h_intern(&lf[523],4,"void");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[548]=C_h_intern(&lf[548],21,"foreign-stub-callback");
lf[549]=C_h_intern(&lf[549],16,"foreign-stub-cps");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_h_intern(&lf[551],27,"foreign-stub-argument-names");
lf[552]=C_h_intern(&lf[552],17,"foreign-stub-body");
lf[553]=C_h_intern(&lf[553],17,"foreign-stub-name");
lf[554]=C_h_intern(&lf[554],24,"foreign-stub-return-type");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[557]=C_h_intern(&lf[557],27,"foreign-stub-argument-types");
lf[558]=C_h_intern(&lf[558],19,"\010compilerreal-name2");
lf[559]=C_h_intern(&lf[559],15,"foreign-stub-id");
lf[560]=C_h_intern(&lf[560],5,"float");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[562]=C_h_intern(&lf[562],8,"c-string");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[566]=C_h_intern(&lf[566],16,"nonnull-c-string");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[569]=C_h_intern(&lf[569],3,"ref");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[571]=C_h_intern(&lf[571],5,"const");
lf[572]=C_h_intern(&lf[572],7,"pointer");
lf[573]=C_h_intern(&lf[573],9,"c-pointer");
lf[574]=C_h_intern(&lf[574],15,"nonnull-pointer");
lf[575]=C_h_intern(&lf[575],17,"nonnull-c-pointer");
lf[576]=C_h_intern(&lf[576],8,"function");
lf[577]=C_h_intern(&lf[577],8,"instance");
lf[578]=C_h_intern(&lf[578],16,"nonnull-instance");
lf[579]=C_h_intern(&lf[579],12,"instance-ref");
lf[580]=C_h_intern(&lf[580],18,"\003syshash-table-ref");
lf[581]=C_h_intern(&lf[581],27,"\010compilerforeign-type-table");
lf[582]=C_h_intern(&lf[582],17,"nonnull-c-string*");
lf[583]=C_h_intern(&lf[583],25,"nonnull-unsigned-c-string");
lf[584]=C_h_intern(&lf[584],26,"nonnull-unsigned-c-string*");
lf[585]=C_h_intern(&lf[585],6,"symbol");
lf[586]=C_h_intern(&lf[586],9,"c-string*");
lf[587]=C_h_intern(&lf[587],17,"unsigned-c-string");
lf[588]=C_h_intern(&lf[588],18,"unsigned-c-string*");
lf[589]=C_h_intern(&lf[589],6,"double");
lf[590]=C_h_intern(&lf[590],16,"unsigned-integer");
lf[591]=C_h_intern(&lf[591],18,"unsigned-integer32");
lf[592]=C_h_intern(&lf[592],4,"long");
lf[593]=C_h_intern(&lf[593],7,"integer");
lf[594]=C_h_intern(&lf[594],9,"integer32");
lf[595]=C_h_intern(&lf[595],13,"unsigned-long");
lf[596]=C_h_intern(&lf[596],6,"number");
lf[597]=C_h_intern(&lf[597],9,"integer64");
lf[598]=C_h_intern(&lf[598],13,"c-string-list");
lf[599]=C_h_intern(&lf[599],14,"c-string-list*");
lf[600]=C_h_intern(&lf[600],3,"int");
lf[601]=C_h_intern(&lf[601],5,"int32");
lf[602]=C_h_intern(&lf[602],5,"short");
lf[603]=C_h_intern(&lf[603],14,"unsigned-short");
lf[604]=C_h_intern(&lf[604],13,"scheme-object");
lf[605]=C_h_intern(&lf[605],13,"unsigned-char");
lf[606]=C_h_intern(&lf[606],12,"unsigned-int");
lf[607]=C_h_intern(&lf[607],14,"unsigned-int32");
lf[608]=C_h_intern(&lf[608],4,"byte");
lf[609]=C_h_intern(&lf[609],13,"unsigned-byte");
lf[610]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[611]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[612]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[613]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[614]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[625]=C_h_intern(&lf[625],36,"foreign-callback-stub-argument-types");
lf[626]=C_h_intern(&lf[626],33,"foreign-callback-stub-return-type");
lf[627]=C_h_intern(&lf[627],24,"foreign-callback-stub-id");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[630]=C_h_intern(&lf[630],32,"foreign-callback-stub-qualifiers");
lf[631]=C_h_intern(&lf[631],26,"foreign-callback-stub-name");
lf[632]=C_h_intern(&lf[632],4,"quit");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[652]=C_h_intern(&lf[652],11,"byte-vector");
lf[653]=C_h_intern(&lf[653],19,"nonnull-byte-vector");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[655]=C_h_intern(&lf[655],4,"blob");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[657]=C_h_intern(&lf[657],9,"u16vector");
lf[658]=C_h_intern(&lf[658],17,"nonnull-u16vector");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[660]=C_h_intern(&lf[660],8,"s8vector");
lf[661]=C_h_intern(&lf[661],16,"nonnull-s8vector");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[663]=C_h_intern(&lf[663],9,"u32vector");
lf[664]=C_h_intern(&lf[664],17,"nonnull-u32vector");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[666]=C_h_intern(&lf[666],9,"s16vector");
lf[667]=C_h_intern(&lf[667],17,"nonnull-s16vector");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[669]=C_h_intern(&lf[669],9,"s32vector");
lf[670]=C_h_intern(&lf[670],17,"nonnull-s32vector");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[672]=C_h_intern(&lf[672],9,"f32vector");
lf[673]=C_h_intern(&lf[673],17,"nonnull-f32vector");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[675]=C_h_intern(&lf[675],9,"f64vector");
lf[676]=C_h_intern(&lf[676],17,"nonnull-f64vector");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[683]=C_h_intern(&lf[683],8,"template");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[690]=C_h_intern(&lf[690],6,"struct");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[693]=C_h_intern(&lf[693],5,"union");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[696]=C_h_intern(&lf[696],4,"enum");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[705]=C_h_intern(&lf[705],3,"...");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_h_intern(&lf[709],12,"nonnull-blob");
lf[710]=C_h_intern(&lf[710],8,"u8vector");
lf[711]=C_h_intern(&lf[711],16,"nonnull-u8vector");
lf[712]=C_h_intern(&lf[712],14,"scheme-pointer");
lf[713]=C_h_intern(&lf[713],22,"nonnull-scheme-pointer");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[808]=C_h_intern(&lf[808],17,"\003sysstring-append");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[810]=C_h_intern(&lf[810],5,"cons*");
lf[811]=C_h_intern(&lf[811],29,"\010compilerstring->c-identifier");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[813]=C_h_intern(&lf[813],6,"random");
C_register_lf2(lf,814,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1090 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1093 in k1090 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1098,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1096 in k1093 in k1090 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1107,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1107,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_set_block_item(lf[1],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1113,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1134,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8807,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8811,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 100  random */
t9=C_retrieve(lf[813]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_fix(16777216));}

/* k8809 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8815,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 100  current-seconds */
t3=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8813 in k8809 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 100  sprintf */
t2=C_retrieve(lf[332]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[812],((C_word*)t0)[2],t1);}

/* k8805 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 99   string->c-identifier */
t2=C_retrieve(lf[811]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1152,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1154,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4691,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[468]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4764,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4853,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4869,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[482]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4885,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4936,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4954,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[479]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5187,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5618,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5683,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6900,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7733,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8507,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[51],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8507,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8510,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8513,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8516,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8569,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8569(2,t8,lf[795]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8569(2,t9,lf[796]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8516(C_a_i(&a,4),t9);
/* c-backend.scm: 1355 string-append */
t11=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[797],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8569(2,t9,lf[798]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8569(2,t9,lf[799]);}
else{
t9=C_retrieve(lf[0]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8569(2,t11,lf[800]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8687,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1360 big-fixnum? */
t12=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8700,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1369 number->string */
C_number_to_string(3,0,t11,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_i_string_length(t11);
t13=f_8516(C_a_i(&a,4),t12);
/* c-backend.scm: 1372 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t6,lf[806],t13,t11);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1377 bomb */
t11=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[807],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8739,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=f_8510(t2);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_string(&a,1,t13);
t15=f_8513(t2);
t16=f_8516(C_a_i(&a,4),t15);
/* c-backend.scm: 1380 string-append */
t17=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,t11,t14,t16);}
else{
t11=f_8513(t2);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8769,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=f_8510(t2);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8516(C_a_i(&a,4),t11);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8781,a[2]=t16,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8783,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1390 list-tabulate */
t19=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t11,t18);}}}}}}}}}}}}

/* a8782 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8783,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1390 encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k8779 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1387 cons* */
t2=C_retrieve(lf[810]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8767 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1386 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[809]);}

/* k8737 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1379 ##sys#string-append */
t2=C_retrieve(lf[808]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8698 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1369 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[804],t1,lf[805]);}

/* k8685 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8687,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8683,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1367 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1361 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[3],lf[803],t13);}}

/* k8681 in k8685 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1367 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[801],t1,lf[802]);}

/* k8567 in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_8569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8569,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1351 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static C_word C_fcall f_8516(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static C_word C_fcall f_8513(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1050(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static C_word C_fcall f_8510(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1046(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7733,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[769]);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[601]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[770]);}
else{
t10=(C_word)C_eqp(t5,lf[606]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[607]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[771]);}
else{
t12=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[772]);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[773]);}
else{
t14=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[774]);}
else{
t15=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[775]);}
else{
t16=(C_word)C_eqp(t5,lf[560]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[589]));
if(C_truep(t17)){
/* c-backend.scm: 1289 sprintf */
t18=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[776],t3);}
else{
t18=(C_word)C_eqp(t5,lf[596]);
if(C_truep(t18)){
/* c-backend.scm: 1290 sprintf */
t19=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[777],t3);}
else{
t19=(C_word)C_eqp(t5,lf[566]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7820,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_7820(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[562]);
if(C_truep(t21)){
t22=t20;
f_7820(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[575]);
if(C_truep(t22)){
t23=t20;
f_7820(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[586]);
if(C_truep(t23)){
t24=t20;
f_7820(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[582]);
if(C_truep(t24)){
t25=t20;
f_7820(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t25)){
t26=t20;
f_7820(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t26)){
t27=t20;
f_7820(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[583]);
if(C_truep(t27)){
t28=t20;
f_7820(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t28)){
t29=t20;
f_7820(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[585]);
if(C_truep(t29)){
t30=t20;
f_7820(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[598]);
t31=t20;
f_7820(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[599])));}}}}}}}}}}}}}}}}}}}}

/* k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7820,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1294 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[778],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t2)){
/* c-backend.scm: 1295 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[779],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t4)){
/* c-backend.scm: 1296 sprintf */
t5=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[780],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t5)){
/* c-backend.scm: 1297 sprintf */
t6=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[781],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
/* c-backend.scm: 1298 sprintf */
t8=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[782],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t8)){
/* c-backend.scm: 1299 sprintf */
t9=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[783],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t9)){
/* c-backend.scm: 1300 sprintf */
t10=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[784],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[785]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[523]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[604]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[786]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1304 ##sys#hash-table-ref */
t14=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t14=t13;
f_7901(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1306 foreign-result-conversion */
t4=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7924,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7929,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7934,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7956,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7956(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7956(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[575]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7992,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7992(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7992(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[569]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8028,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_8028(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_8028(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8063,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_8063(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_8063(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_8063(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8111,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_8111(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_8111(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_8111(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[579]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8159,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t21=t17;
f_8159(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_8159(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_8159(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8207,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_8207(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_8207(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[572]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8242,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_8242(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_8242(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[573]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8278,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_8278(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_8278(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[3]);
t24=(C_word)C_eqp(t23,lf[576]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=(C_word)C_i_cadr(((C_word*)t0)[3]);
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* c-backend.scm: 1308 sprintf */
t28=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t28))(4,t28,((C_word*)t0)[5],lf[793],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 1308 g1021 */
t26=t2;
f_7924(t26,((C_word*)t0)[5]);}}
else{
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8336,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(((C_word*)t0)[3]);
t27=(C_word)C_eqp(t26,lf[696]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[3]);
t30=t25;
f_8336(t30,(C_word)C_i_nullp(t29));}
else{
t29=t25;
f_8336(t29,C_SCHEME_FALSE);}}
else{
t28=t25;
f_8336(t28,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1308 g1021 */
t5=t2;
f_7924(t5,((C_word*)t0)[5]);}}
else{
/* c-backend.scm: 1325 err */
t2=((C_word*)t0)[2];
f_7735(t2,((C_word*)t0)[5]);}}}

/* k8334 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[794],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[4]);}}

/* k8276 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7929(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[3]);}}

/* k8240 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7929(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[3]);}}

/* k8205 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8207(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[4]);}}

/* k8157 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[792],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[4]);}}

/* k8109 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[791],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[4]);}}

/* k8061 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[790],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[4]);}}

/* k8026 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_8028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1312 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[789],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[4]);}}

/* k7990 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7934(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[3]);}}

/* k7954 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7934(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7924(t2,((C_word*)t0)[3]);}}

/* g1012 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7934,NULL,2,t0,t1);}
/* c-backend.scm: 1310 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[788],((C_word*)t0)[2]);}

/* g1018 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7929,NULL,2,t0,t1);}
/* c-backend.scm: 1321 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[787],((C_word*)t0)[2]);}

/* g1021 in k7899 in k7818 in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7924(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7924,NULL,2,t0,t1);}
/* c-backend.scm: 1324 err */
t2=((C_word*)t0)[2];
f_7735(t2,t1);}

/* err in ##compiler#foreign-result-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7735,NULL,2,t0,t1);}
/* c-backend.scm: 1280 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[768],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6902,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[604]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[715]);}
else{
t6=(C_word)C_eqp(t4,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[716]);}
else{
t8=(C_word)C_eqp(t4,lf[608]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6930,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6930(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[600]);
if(C_truep(t10)){
t11=t9;
f_6930(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[606]);
if(C_truep(t11)){
t12=t9;
f_6930(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[607]);
t13=t9;
f_6930(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[609])));}}}}}}

/* k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6930(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6930,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[717]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[718]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[603]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[719]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[720]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6957(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
t8=t6;
f_6957(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[560])));}}}}}}

/* k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6957(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6957,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[721]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[722]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[723]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[724]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[725]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[572]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[726]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[574]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[727]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[712]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[728]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[713]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[729]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[730]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[575]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[731]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[655]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[732]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[709]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[733]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[652]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[734]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[653]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[735]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[710]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[736]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[737]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[657]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[738]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[739]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[740]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[664]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[741]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[742]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[661]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[743]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[744]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[745]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[746]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[670]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[747]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[748]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[673]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[749]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[750]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[676]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[751]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[562]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_7152(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[586]);
if(C_truep(t36)){
t37=t35;
f_7152(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t38=t35;
f_7152(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[588])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7152,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[752]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7161(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_7161(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_7161(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_7161(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7161,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[753]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[754]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1256 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7170(2,t4,C_SCHEME_FALSE);}}}}

/* k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_7170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7170,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1258 foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7193,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[572]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7215,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[3]);
t8=t5;
f_7215(t8,(C_word)C_i_nullp(t7));}
else{
t7=t5;
f_7215(t7,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7247,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7247(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7247(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[573]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7279,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7279(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7279(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[575]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7311,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7311(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7311(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7343,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7343(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7343(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7343(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7388,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_7388(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7388(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7388(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[576]);
if(C_truep(t16)){
t17=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cadr(((C_word*)t0)[3]);
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
t20=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[761]);}
else{
/* c-backend.scm: 1260 g948 */
t18=t2;
f_7193(t18,((C_word*)t0)[4]);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7458,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_7458(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_7458(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[696]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7493,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_7493(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_7493(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[569]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7525,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_7525(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_7525(t25,C_SCHEME_FALSE);}}
else{
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7558,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_car(((C_word*)t0)[3]);
t25=(C_word)C_eqp(t24,lf[579]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t29=t23;
f_7558(t29,(C_word)C_i_nullp(t28));}
else{
t28=t23;
f_7558(t28,C_SCHEME_FALSE);}}
else{
t27=t23;
f_7558(t27,C_SCHEME_FALSE);}}
else{
t26=t23;
f_7558(t26,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1260 g948 */
t3=t2;
f_7193(t3,((C_word*)t0)[4]);}}
else{
/* c-backend.scm: 1274 err */
t2=((C_word*)t0)[2];
f_6902(t2,((C_word*)t0)[4]);}}}

/* k7556 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],lf[766],t2,lf[767]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7523 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7525,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7535,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1260 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[765]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7533 in k7523 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_7535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1260 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[763],t1,lf[764]);}

/* k7491 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7456 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7386 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[760]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7341 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[759]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7309 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[758]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7277 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[757]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7245 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[756]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* k7213 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[755]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7193(t2,((C_word*)t0)[3]);}}

/* g948 in k7168 in k7159 in k7150 in k6955 in k6928 in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_7193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7193,NULL,2,t0,t1);}
/* c-backend.scm: 1273 err */
t2=((C_word*)t0)[2];
f_6902(t2,t1);}

/* err in ##compiler#foreign-argument-conversion in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6902,NULL,2,t0,t1);}
/* c-backend.scm: 1210 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[714],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5683,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5685,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5690,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[604]);
if(C_truep(t7)){
/* c-backend.scm: 1130 str */
t8=t5;
f_5690(t8,t1,lf[635]);}
else{
t8=(C_word)C_eqp(t6,lf[18]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[608]));
if(C_truep(t9)){
/* c-backend.scm: 1131 str */
t10=t5;
f_5690(t10,t1,lf[636]);}
else{
t10=(C_word)C_eqp(t6,lf[605]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[609]));
if(C_truep(t11)){
/* c-backend.scm: 1132 str */
t12=t5;
f_5690(t12,t1,lf[637]);}
else{
t12=(C_word)C_eqp(t6,lf[606]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[590]));
if(C_truep(t13)){
/* c-backend.scm: 1133 str */
t14=t5;
f_5690(t14,t1,lf[638]);}
else{
t14=(C_word)C_eqp(t6,lf[607]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[591]));
if(C_truep(t15)){
/* c-backend.scm: 1134 str */
t16=t5;
f_5690(t16,t1,lf[639]);}
else{
t16=(C_word)C_eqp(t6,lf[600]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5760,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5760(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[593]);
t19=t17;
f_5760(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[15])));}}}}}}}

/* k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5760,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1135 str */
t2=((C_word*)t0)[7];
f_5690(t2,((C_word*)t0)[6],lf[640]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[594]));
if(C_truep(t3)){
/* c-backend.scm: 1136 str */
t4=((C_word*)t0)[7];
f_5690(t4,((C_word*)t0)[6],lf[641]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t4)){
/* c-backend.scm: 1137 str */
t5=((C_word*)t0)[7];
f_5690(t5,((C_word*)t0)[6],lf[642]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t5)){
/* c-backend.scm: 1138 str */
t6=((C_word*)t0)[7];
f_5690(t6,((C_word*)t0)[6],lf[643]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t6)){
/* c-backend.scm: 1139 str */
t7=((C_word*)t0)[7];
f_5690(t7,((C_word*)t0)[6],lf[644]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
if(C_truep(t7)){
/* c-backend.scm: 1140 str */
t8=((C_word*)t0)[7];
f_5690(t8,((C_word*)t0)[6],lf[645]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t8)){
/* c-backend.scm: 1141 str */
t9=((C_word*)t0)[7];
f_5690(t9,((C_word*)t0)[6],lf[646]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t9)){
/* c-backend.scm: 1142 str */
t10=((C_word*)t0)[7];
f_5690(t10,((C_word*)t0)[6],lf[647]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t11)){
/* c-backend.scm: 1143 str */
t12=((C_word*)t0)[7];
f_5690(t12,((C_word*)t0)[6],lf[648]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[572]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[574]));
if(C_truep(t13)){
/* c-backend.scm: 1145 str */
t14=((C_word*)t0)[7];
f_5690(t14,((C_word*)t0)[6],lf[649]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_5862(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t16)){
t17=t15;
f_5862(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[712]);
t18=t15;
f_5862(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[713])));}}}}}}}}}}}}}

/* k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5862,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1146 str */
t2=((C_word*)t0)[7];
f_5690(t2,((C_word*)t0)[6],lf[650]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[651]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[652]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[653]));
if(C_truep(t5)){
/* c-backend.scm: 1149 str */
t6=((C_word*)t0)[7];
f_5690(t6,((C_word*)t0)[6],lf[654]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[655]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5895(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[709]);
if(C_truep(t8)){
t9=t7;
f_5895(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[710]);
t10=t7;
f_5895(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[711])));}}}}}}

/* k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5895,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1150 str */
t2=((C_word*)t0)[7];
f_5690(t2,((C_word*)t0)[6],lf[656]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[657]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[658]));
if(C_truep(t3)){
/* c-backend.scm: 1151 str */
t4=((C_word*)t0)[7];
f_5690(t4,((C_word*)t0)[6],lf[659]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[661]));
if(C_truep(t5)){
/* c-backend.scm: 1152 str */
t6=((C_word*)t0)[7];
f_5690(t6,((C_word*)t0)[6],lf[662]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[663]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[664]));
if(C_truep(t7)){
/* c-backend.scm: 1153 str */
t8=((C_word*)t0)[7];
f_5690(t8,((C_word*)t0)[6],lf[665]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[666]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[667]));
if(C_truep(t9)){
/* c-backend.scm: 1154 str */
t10=((C_word*)t0)[7];
f_5690(t10,((C_word*)t0)[6],lf[668]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[669]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[670]));
if(C_truep(t11)){
/* c-backend.scm: 1155 str */
t12=((C_word*)t0)[7];
f_5690(t12,((C_word*)t0)[6],lf[671]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[673]));
if(C_truep(t13)){
/* c-backend.scm: 1156 str */
t14=((C_word*)t0)[7];
f_5690(t14,((C_word*)t0)[6],lf[674]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[675]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[676]));
if(C_truep(t15)){
/* c-backend.scm: 1157 str */
t16=((C_word*)t0)[7];
f_5690(t16,((C_word*)t0)[6],lf[677]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[566]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5991(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
if(C_truep(t18)){
t19=t17;
f_5991(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t19)){
t20=t17;
f_5991(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t20)){
t21=t17;
f_5991(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[583]);
if(C_truep(t21)){
t22=t17;
f_5991(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t22)){
t23=t17;
f_5991(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t24=t17;
f_5991(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[585])));}}}}}}}}}}}}}}}

/* k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5991,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1160 str */
t2=((C_word*)t0)[7];
f_5690(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t2)){
/* c-backend.scm: 1161 str */
t3=((C_word*)t0)[7];
f_5690(t3,((C_word*)t0)[6],lf[679]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1163 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_6006(2,t4,C_SCHEME_FALSE);}}}}

/* k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1165 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1166 str */
t2=((C_word*)t0)[3];
f_5690(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6043,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6052,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[572]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6078,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[4]);
t10=t7;
f_6078(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_6078(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[574]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6114,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[4]);
t12=t9;
f_6114(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_6114(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[573]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6150,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[4]);
t14=t11;
f_6150(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_6150(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[575]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6186,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[4]);
t16=t13;
f_6186(t16,(C_word)C_i_nullp(t15));}
else{
t15=t13;
f_6186(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[569]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6222,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[4]);
t18=t15;
f_6222(t18,(C_word)C_i_nullp(t17));}
else{
t17=t15;
f_6222(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[683]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6261,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[4]);
t20=t17;
f_6261(t20,(C_word)C_i_listp(t19));}
else{
t19=t17;
f_6261(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6321,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[4]);
t22=t19;
f_6321(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_6321(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[690]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6360,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6360(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6360(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[693]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6399,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6399(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6399(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[696]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6438,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[4]);
t28=t25;
f_6438(t28,(C_word)C_i_nullp(t27));}
else{
t27=t25;
f_6438(t27,C_SCHEME_FALSE);}}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[577]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6477,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t29))){
t30=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t31=t27;
f_6477(t31,(C_word)C_i_nullp(t30));}
else{
t30=t27;
f_6477(t30,C_SCHEME_FALSE);}}
else{
t29=t27;
f_6477(t29,C_SCHEME_FALSE);}}
else{
t27=(C_word)C_i_car(((C_word*)t0)[4]);
t28=(C_word)C_eqp(t27,lf[578]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6527,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t30))){
t31=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t33=t29;
f_6527(t33,(C_word)C_i_nullp(t32));}
else{
t32=t29;
f_6527(t32,C_SCHEME_FALSE);}}
else{
t31=t29;
f_6527(t31,C_SCHEME_FALSE);}}
else{
t29=(C_word)C_i_car(((C_word*)t0)[4]);
t30=(C_word)C_eqp(t29,lf[579]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6577,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t32))){
t33=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t33))){
t34=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t35=t31;
f_6577(t35,(C_word)C_i_nullp(t34));}
else{
t34=t31;
f_6577(t34,C_SCHEME_FALSE);}}
else{
t33=t31;
f_6577(t33,C_SCHEME_FALSE);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6623,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[4]);
t33=(C_word)C_eqp(t32,lf[576]);
if(C_truep(t33)){
t34=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_i_cddr(((C_word*)t0)[4]);
t36=t31;
f_6623(t36,(C_word)C_i_pairp(t35));}
else{
t35=t31;
f_6623(t35,C_SCHEME_FALSE);}}
else{
t34=t31;
f_6623(t34,C_SCHEME_FALSE);}}}}}}}}}}}}}}}
else{
/* c-backend.scm: 1168 g871 */
t5=t2;
f_6038(t5,((C_word*)t0)[6]);}}
else{
/* c-backend.scm: 1204 err */
t2=((C_word*)t0)[2];
f_5685(t2,((C_word*)t0)[6]);}}}}

/* k6621 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6623,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6639,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[708]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[4]);}}

/* k6637 in k6621 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_stringp(t3);
t5=t2;
f_6643(t5,(C_truep(t4)?t3:C_SCHEME_FALSE));}
else{
t4=t2;
f_6643(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6643(t3,C_SCHEME_FALSE);}}

/* k6641 in k6637 in k6621 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6643,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[700]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6650,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6654,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6656,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6655 in k6641 in k6637 in k6621 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6656,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[705],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[706]);}
else{
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[707]);}}

/* k6652 in k6641 in k6637 in k6621 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[704]);}

/* k6648 in k6641 in k6637 in k6621 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[701],((C_word*)t0)[2],lf[702],t1,lf[703]);}

/* k6575 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6577,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t5=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[4]);}}

/* k6588 in k6575 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[699],((C_word*)t0)[2]);}

/* k6525 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6043(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[3]);}}

/* k6475 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6043(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[3]);}}

/* k6436 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6438,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[4]);}}

/* k6446 in k6436 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[697],t1,lf[698],((C_word*)t0)[2]);}

/* k6397 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6399,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[4]);}}

/* k6407 in k6397 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[694],t1,lf[695],((C_word*)t0)[2]);}

/* k6358 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[4]);}}

/* k6368 in k6358 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[691],t1,lf[692],((C_word*)t0)[2]);}

/* k6319 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6321,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6331,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[4]);}}

/* k6329 in k6319 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[689],t1);}

/* k6259 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6261,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6278,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[688]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[3]);}}

/* k6276 in k6259 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6286,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6288,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6287 in k6276 in k6259 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6288,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[687]);}

/* k6284 in k6276 in k6259 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[686]);}

/* k6280 in k6276 in k6259 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[684],t1,lf[685]);}

/* k6272 in k6259 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 str */
t2=((C_word*)t0)[3];
f_5690(t2,((C_word*)t0)[2],t1);}

/* k6220 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6222,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6232,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1172 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[682],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[4]);}}

/* k6230 in k6220 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1172 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6184 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6052(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[3]);}}

/* k6148 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6052(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[3]);}}

/* k6112 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6052(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[3]);}}

/* k6076 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6052(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6038(t2,((C_word*)t0)[3]);}}

/* g858 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6052,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6060,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1170 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[681],((C_word*)t0)[2]);}

/* k6058 in g858 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1170 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g868 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6043(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6043,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6051,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1184 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6049 in g868 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1184 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[680],((C_word*)t0)[2]);}

/* g871 in k6004 in k5989 in k5893 in k5860 in k5758 in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_6038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6038,NULL,2,t0,t1);}
/* c-backend.scm: 1203 err */
t2=((C_word*)t0)[2];
f_5685(t2,t1);}

/* str in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5690(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5690,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1128 string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[634],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5685,NULL,2,t0,t1);}
/* c-backend.scm: 1127 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[633],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5618,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5622,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1109 foreign-callback-stub-name */
t5=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1110 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1111 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5631,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1112 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1114 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[629]);}

/* k5635 in k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1115 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[628]);}

/* k5679 in k5635 in k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1115 gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k5638 in k5635 in k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5648,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1116 pair-for-each */
t4=C_retrieve(lf[174]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5647 in k5638 in k5635 in k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5648,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5652,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5669,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1118 foreign-type-declaration */
t8=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k5667 in a5647 in k5638 in k5635 in k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1118 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5650 in a5647 in k5638 in k5635 in k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1119 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5641 in k5638 in k5635 in k5629 in k5626 in k5623 in k5620 in ##compiler#generate-foreign-callback-header in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1121 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5187,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5193,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5193,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5197,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1056 foreign-callback-stub-id */
t4=C_retrieve(lf[627]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1057 real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5203,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1058 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1059 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5206,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1061 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[624]);}

/* k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5212,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5214,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1088 fold */
t6=C_retrieve(lf[413]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[623],((C_word*)t0)[4],t1);}

/* k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1089 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5616,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1091 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5559(2,t3,C_SCHEME_UNDEFINED);}}

/* k5614 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1091 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[621],t1,lf[622]);}

/* k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1092 generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[620],((C_word*)t0)[2]);}

/* k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1093 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[618],((C_word*)t0)[2],lf[619]);}

/* k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1094 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[617]);}

/* k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5601,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1095 for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5600 in k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5601,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5609,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1097 foreign-result-conversion */
t5=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[616]);}

/* k5607 in a5600 in k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1097 gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[613],t1,((C_word*)t0)[2],lf[614],C_SCHEME_TRUE,lf[615]);}

/* k5569 in k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_5574(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5599,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1102 foreign-argument-conversion */
t5=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k5597 in k5569 in k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1102 gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[612],t1);}

/* k5572 in k5569 in k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1103 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[611],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k5575 in k5572 in k5569 in k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5580,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_5580(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1104 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5578 in k5575 in k5572 in k5569 in k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1105 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[610]);}

/* compute-size in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5214,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5224,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5224(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
if(C_truep(t8)){
t9=t7;
f_5224(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t9)){
t10=t7;
f_5224(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t10)){
t11=t7;
f_5224(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t11)){
t12=t7;
f_5224(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[523]);
if(C_truep(t12)){
t13=t7;
f_5224(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t7;
f_5224(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t14)){
t15=t7;
f_5224(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t15)){
t16=t7;
f_5224(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t16)){
t17=t7;
f_5224(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t17)){
t18=t7;
f_5224(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[608]);
t19=t7;
f_5224(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[609])));}}}}}}}}}}}}

/* k5222 in compute-size in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5224,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5233(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t4)){
t5=t3;
f_5233(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
if(C_truep(t5)){
t6=t3;
f_5233(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t6)){
t7=t3;
f_5233(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t7)){
t8=t3;
f_5233(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t8)){
t9=t3;
f_5233(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t9)){
t10=t3;
f_5233(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t10)){
t11=t3;
f_5233(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t11)){
t12=t3;
f_5233(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t12)){
t13=t3;
f_5233(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t13)){
t14=t3;
f_5233(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t14)){
t15=t3;
f_5233(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t16=t3;
f_5233(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[599])));}}}}}}}}}}}}}}

/* k5231 in k5222 in compute-size in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5233,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1070 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[561]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5245(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t4)){
t5=t3;
f_5245(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t5)){
t6=t3;
f_5245(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
t7=t3;
f_5245(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[588])));}}}}}

/* k5243 in k5231 in k5222 in compute-size in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5245,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1072 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[563],((C_word*)t0)[5],lf[564],((C_word*)t0)[5],lf[565]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5257(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_5257(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_5257(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_5257(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k5255 in k5243 in k5231 in k5222 in compute-size in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5257,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1074 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[567],((C_word*)t0)[4],lf[568]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1076 ##sys#hash-table-ref */
t3=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[581]),((C_word*)t0)[2]);}
else{
t3=t2;
f_5263(2,t3,C_SCHEME_FALSE);}}}

/* k5261 in k5255 in k5243 in k5231 in k5222 in compute-size in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5263,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1078 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5214(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[569]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_5297(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t5)){
t6=t4;
f_5297(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[573]);
if(C_truep(t6)){
t7=t4;
f_5297(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t7)){
t8=t4;
f_5297(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t8)){
t9=t4;
f_5297(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t9)){
t10=t4;
f_5297(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t10)){
t11=t4;
f_5297(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[578]);
t12=t4;
f_5297(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[579])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k5295 in k5261 in k5255 in k5243 in k5231 in k5222 in compute-size in k5210 in k5204 in k5201 in k5198 in k5195 in a5192 in generate-foreign-callback-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_5297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1083 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[570]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1084 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5214(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4954,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4960,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4960,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 989  foreign-stub-id */
t4=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 990  real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 991  foreign-stub-argument-types */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5185,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 993  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[556]);}

/* k5183 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[555],t1);
/* c-backend.scm: 993  intersperse */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 994  foreign-stub-return-type */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 995  foreign-stub-name */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 996  foreign-stub-body */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 997  foreign-stub-argument-names */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4991(2,t3,t1);}
else{
/* c-backend.scm: 997  make-list */
t3=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 998  foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[550]);}

/* k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 999  foreign-stub-cps */
t3=C_retrieve(lf[549]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1000 foreign-stub-callback */
t3=C_retrieve(lf[548]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1001 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5174,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1003 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5006(2,t3,C_SCHEME_UNDEFINED);}}

/* k5172 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1003 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[546],t1,lf[547]);}

/* k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1005 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[544],((C_word*)t0)[6],lf[545]);}
else{
t3=t2;
f_5009(2,t3,C_SCHEME_UNDEFINED);}}

/* k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1008 gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[539],((C_word*)t0)[2],lf[540],C_SCHEME_TRUE,lf[541],((C_word*)t0)[2],lf[542]);}
else{
/* c-backend.scm: 1010 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[543],((C_word*)t0)[2],C_make_character(40));}}

/* k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[3]);}

/* k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1013 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[534],C_SCHEME_TRUE,lf[535],((C_word*)t0)[2],lf[536]);}
else{
/* c-backend.scm: 1014 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[537],C_SCHEME_TRUE,lf[538],((C_word*)t0)[2],C_make_character(40));}}

/* k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1016 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[533]);}

/* k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1017 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[532]);}

/* k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5122,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1026 iota */
t5=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k5150 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1018 for-each */
t2=*((C_word*)lf[61]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5121 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5122,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5130,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5142,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1023 symbol->string */
t7=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1023 sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[531],t3);}}

/* k5140 in a5121 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1021 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5128 in a5121 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1024 foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[530]);}

/* k5132 in k5128 in a5121 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1025 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5136 in k5132 in k5128 in a5121 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1020 gen */
t2=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[527],((C_word*)t0)[3],C_make_character(41),t1,lf[528],((C_word*)t0)[2],lf[529]);}

/* k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1027 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[526]);}
else{
t3=t2;
f_5033(2,t3,C_SCHEME_UNDEFINED);}}

/* k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5042,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1029 gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[517]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t4)){
/* c-backend.scm: 1040 gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1039 gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[525],((C_word*)t0)[2]);}}}

/* k5061 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1041 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k5064 in k5061 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5104,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1042 make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[524]);}

/* k5102 in k5064 in k5061 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1042 intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5098 in k5064 in k5061 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k5067 in k5064 in k5061 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[523]);
if(C_truep(t3)){
t4=t2;
f_5072(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1043 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5070 in k5067 in k5064 in k5061 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1044 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[522]);}

/* k5073 in k5070 in k5067 in k5064 in k5061 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1046 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[518],C_SCHEME_TRUE,lf[519]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1048 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[520]);}
else{
/* c-backend.scm: 1049 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[521]);}}}

/* k5040 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1031 gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE);}

/* k5043 in k5040 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1033 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1035 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[514]);}
else{
/* c-backend.scm: 1036 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[515]);}}}

/* k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4968 in k4965 in k4962 in a4959 in ##compiler#generate-foreign-stubs in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1050 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4936,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4942,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a4941 in ##compiler#generate-foreign-callback-stub-prototypes in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4942,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4946,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 981  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4944 in a4941 in ##compiler#generate-foreign-callback-stub-prototypes in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 982  generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k4947 in k4944 in a4941 in ##compiler#generate-foreign-callback-stub-prototypes in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 983  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4885,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 968  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4887 in ##compiler#generate-external-variables in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4894,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4893 in k4887 in ##compiler#generate-external-variables in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4894,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
t5=t3;
f_4901(t5,(C_word)C_eqp(t4,C_fix(3)));}
else{
t4=t3;
f_4901(t4,C_SCHEME_FALSE);}}

/* k4899 in a4893 in k4887 in ##compiler#generate-external-variables in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4901,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t5=(C_truep(t4)?lf[508]:lf[509]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 972  foreign-type-declaration */
t7=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,t2);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4919 in k4899 in a4893 in k4887 in ##compiler#generate-external-variables in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 972  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4869,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4875,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 960  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4874 in ##compiler#make-argument-list in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4875,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 962  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4881 in a4874 in ##compiler#make-argument-list in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 962  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4853,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 955  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4858 in ##compiler#make-variable-list in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4859,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 957  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4865 in a4858 in ##compiler#make-variable-list in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 957  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[506],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4764,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4773,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4773(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4773,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4789,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4802,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_4802(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_4802(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_4802(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_4802(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_4802(t10,C_SCHEME_FALSE);}}}}}

/* k4800 in loop in ##compiler#cleanup in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4802,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_4805(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4812,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 946  string-copy */
t4=C_retrieve(lf[505]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_4789(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k4810 in k4800 in loop in ##compiler#cleanup in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4805(t3,t2);}

/* k4803 in k4800 in loop in ##compiler#cleanup in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_4789(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k4787 in loop in ##compiler#cleanup in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 949  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4773(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4691,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4695,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 911  gen */
t7=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[502],C_SCHEME_TRUE,lf[503],t6,lf[504]);}

/* k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4698,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4709(t6,t2,((C_word*)t0)[2]);}

/* do572 in k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4709,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 915  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[495]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 916  lambda-literal-id */
t5=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4720 in do572 in k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4725,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 917  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[500],t1,((C_word*)t0)[2],lf[501]);}

/* k4723 in k4720 in do572 in k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 920  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[496],C_retrieve(lf[185]),lf[497]);}
else{
/* c-backend.scm: 921  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[498]);}}
else{
/* c-backend.scm: 922  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[499]);}}

/* k4726 in k4723 in k4720 in do572 in k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4709(t3,((C_word*)t0)[2],t2);}

/* k4696 in k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 923  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[494]);}

/* k4699 in k4696 in k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 924  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[493]);}

/* k4702 in k4699 in k4696 in k4693 in emit-procedure-table-info in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 925  gen */
t2=C_retrieve(lf[2]);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[486],C_SCHEME_TRUE,lf[487],C_SCHEME_TRUE,lf[488],C_SCHEME_TRUE,lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],C_SCHEME_TRUE,lf[492]);}

/* ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[60],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_1154,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1199,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2626,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2792,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3192,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3899,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3822,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3515,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3680,a[2]=t17,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3478,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3521,a[2]=t17,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3911,a[2]=t4,a[3]=t8,a[4]=t21,a[5]=t19,a[6]=t2,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4658,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t8,a[6]=t14,a[7]=t23,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 894  debugging */
t25=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t24,lf[484],lf[485]);}

/* k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 896  header */
t4=((C_word*)t0)[2];
f_2626(t4,t3);}

/* k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 897  declarations */
t3=((C_word*)t0)[2];
f_2792(t3,t2);}

/* k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 898  generate-external-variables */
t3=C_retrieve(lf[482]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[483]));}

/* k4666 in k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 899  generate-foreign-stubs */
t3=C_retrieve(lf[480]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[481]),((C_word*)t0)[3]);}

/* k4669 in k4666 in k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 900  prototypes */
t3=((C_word*)t0)[2];
f_2941(t3,t2);}

/* k4672 in k4669 in k4666 in k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 901  generate-foreign-callback-stubs */
t3=C_retrieve(lf[479]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[179]),((C_word*)t0)[2]);}

/* k4675 in k4672 in k4669 in k4666 in k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 902  trampolines */
t3=((C_word*)t0)[2];
f_3192(t3,t2);}

/* k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 903  procedures */
t3=((C_word*)t0)[2];
f_3911(t3,t2);}

/* k4681 in k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 904  emit-procedure-table-info */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4684 in k4681 in k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4660 in k4656 in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 475  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[477],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3911,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3917,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 718  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 719  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 720  real-name */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3930,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 721  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 722  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 723  lambda-literal-customizable */
t5=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4655,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 724  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_3939(t3,C_SCHEME_FALSE);}}

/* k4653 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3939(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3939(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3939,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 726  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[475]);}

/* k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3948,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 727  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[474]);}

/* k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3951,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 728  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 729  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 730  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 731  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 732  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 733  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 734  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 736  string-append */
t3=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[185]),lf[472]);}
else{
t3=t2;
f_3972(2,t3,lf[473]);}}

/* k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 738  debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[470],lf[471],((C_word*)t0)[14]);}
else{
t3=t2;
f_3975(2,t3,C_SCHEME_UNDEFINED);}}

/* k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 739  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4624,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 740  cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4622 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[466],t1,lf[467],C_SCHEME_TRUE);}

/* k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 749  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[460]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4585,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 742  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[465]);}}

/* k4583 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[463]:lf[464]);
/* c-backend.scm: 743  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4586 in k4583 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 745  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[461]);}
else{
/* c-backend.scm: 746  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[462]);}}

/* k4589 in k4586 in k4583 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 747  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4605 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4610(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 751  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[459]);}}

/* k4608 in k4605 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 752  gen */
t2=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[453],C_SCHEME_TRUE,lf[454],C_SCHEME_TRUE,lf[455],C_SCHEME_TRUE,lf[456],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[458],((C_word*)t0)[2]);}

/* k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 757  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_3990(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 758  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[452]);}}

/* k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4557,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_4557(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4557(t4,C_SCHEME_FALSE);}}

/* k4555 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4557,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 760  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[451]);}
else{
t2=((C_word*)t0)[2];
f_3993(2,t2,C_SCHEME_UNDEFINED);}}

/* k4558 in k4555 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 761  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3993(2,t2,C_SCHEME_UNDEFINED);}}

/* k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[15]);}

/* k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 763  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[450]);}
else{
t3=t2;
f_3999(2,t3,C_SCHEME_UNDEFINED);}}

/* k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 764  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[449]);}

/* k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[224]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_4005(t5,t4);}
else{
t4=t2;
f_4005(t4,C_SCHEME_UNDEFINED);}}

/* k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4005,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 766  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[448]);}

/* k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 768  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[446],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4519,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4519(t8,t2,((C_word*)t0)[20],t4);}}

/* do459 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4519(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4519,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4529,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 772  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[447],t2,C_make_character(59));}}

/* k4527 in do459 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4519(t4,((C_word*)t0)[2],t2,t3);}

/* k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4231,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 774  fold */
t6=C_retrieve(lf[413]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 808  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[427]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_4462(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_4462(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k4460 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4462,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 822  gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[437],C_SCHEME_TRUE,lf[438],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440]);}
else{
/* c-backend.scm: 825  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[441],((C_word*)t0)[3],lf[442]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4474(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 827  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[445]);}}}

/* k4472 in k4460 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 828  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[444]);}
else{
t3=t2;
f_4477(2,t3,C_SCHEME_UNDEFINED);}}

/* k4475 in k4472 in k4460 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[104]);
t4=t2;
f_4483(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[407]))));}
else{
t3=t2;
f_4483(t3,C_SCHEME_FALSE);}}

/* k4481 in k4475 in k4472 in k4460 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 830  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[443]);}
else{
t2=((C_word*)t0)[2];
f_4384(2,t2,C_SCHEME_UNDEFINED);}}

/* k4382 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4426,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4426(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
t6=t3;
f_4426(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_4426(t4,C_SCHEME_FALSE);}}

/* k4424 in k4382 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 834  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[431],((C_word*)t0)[3],lf[432],((C_word*)t0)[3],lf[433]);}
else{
t4=((C_word*)t0)[2];
f_4387(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 835  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434],((C_word*)t0)[3],lf[435],((C_word*)t0)[3],lf[436]);}}
else{
t2=((C_word*)t0)[2];
f_4387(2,t2,C_SCHEME_UNDEFINED);}}

/* k4385 in k4382 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_4393(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_4393(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_4393(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k4391 in k4385 in k4382 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4393,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 837  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[430]);}
else{
t3=t2;
f_4396(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_4014(2,t2,C_SCHEME_UNDEFINED);}}

/* k4394 in k4391 in k4385 in k4382 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_4402(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_4402(t3,C_SCHEME_FALSE);}}

/* k4400 in k4394 in k4391 in k4385 in k4382 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 839  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[428]);}
else{
/* c-backend.scm: 840  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[429]);}}

/* k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 809  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[426]);}

/* k4321 in k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 810  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[425]);}

/* k4324 in k4321 in k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 812  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 813  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[424]);}}

/* k4327 in k4324 in k4321 in k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 814  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[422],((C_word*)t0)[3],lf[423]);}

/* k4330 in k4327 in k4324 in k4321 in k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4335,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4347(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
if(C_truep(t5)){
t6=t3;
f_4347(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_4347(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k4345 in k4330 in k4327 in k4324 in k4321 in k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 816  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[418],((C_word*)t0)[2],lf[419],((C_word*)t0)[2],lf[420]);}
else{
t2=((C_word*)t0)[3];
f_4335(2,t2,C_SCHEME_UNDEFINED);}}

/* k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 817  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[417]);}
else{
t3=t2;
f_4338(2,t3,C_SCHEME_UNDEFINED);}}

/* k4336 in k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 818  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[414],((C_word*)t0)[2],lf[415]);}

/* a4305 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4306,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 774  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3521(3,t5,t4,t2);}

/* k4312 in a4305 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4231,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4237,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 776  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[409],C_SCHEME_TRUE,lf[410],C_SCHEME_TRUE,lf[411],((C_word*)t0)[2],lf[412]);}

/* k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[407]))){
/* c-backend.scm: 780  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[408]);}
else{
t3=t2;
f_4240(2,t3,C_SCHEME_UNDEFINED);}}

/* k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4243(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[400]))){
/* c-backend.scm: 783  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[401],C_retrieve(lf[400]),lf[402]);}
else{
if(C_truep(C_retrieve(lf[403]))){
/* c-backend.scm: 785  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),lf[405],C_SCHEME_TRUE,lf[406]);}
else{
t4=t3;
f_4274(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k4272 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[398]))){
/* c-backend.scm: 788  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),C_make_character(59));}
else{
t3=t2;
f_4277(2,t3,C_SCHEME_UNDEFINED);}}

/* k4275 in k4272 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[396]))){
/* c-backend.scm: 790  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[397],C_retrieve(lf[396]),C_make_character(59));}
else{
t3=t2;
f_4280(2,t3,C_SCHEME_UNDEFINED);}}

/* k4278 in k4275 in k4272 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[393]))){
/* c-backend.scm: 792  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[394],C_retrieve(lf[393]),lf[395]);}
else{
t2=((C_word*)t0)[2];
f_4243(2,t2,C_SCHEME_UNDEFINED);}}

/* k4241 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 793  gen */
t3=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[386],((C_word*)t0)[3],lf[387],C_SCHEME_TRUE,lf[388],((C_word*)t0)[3],lf[389],C_SCHEME_TRUE,lf[390],C_SCHEME_TRUE,lf[391],C_SCHEME_TRUE,lf[392]);}

/* k4244 in k4241 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 798  gen */
t3=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[380],((C_word*)t0)[2],lf[381],C_SCHEME_TRUE,lf[382],C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384],C_SCHEME_TRUE,lf[385]);}

/* k4247 in k4244 in k4241 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 802  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[2],lf[379]);}

/* k4250 in k4247 in k4244 in k4241 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4014(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 804  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[376],((C_word*)t0)[4],lf[377]);}}

/* k4259 in k4250 in k4247 in k4244 in k4241 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 805  literal-frame */
t3=((C_word*)t0)[2];
f_3478(t3,t2);}

/* k4262 in k4259 in k4250 in k4247 in k4244 in k4241 in k4238 in k4235 in k4229 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 806  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[374],((C_word*)t0)[2],lf[375]);}

/* k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[235],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_4037(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_4037(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_4037(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_4037(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_4037(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4037,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[365]:lf[366]);
/* c-backend.scm: 851  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[367],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[371]:lf[372]);
/* c-backend.scm: 877  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[373]);}}
else{
t2=((C_word*)t0)[10];
f_4017(2,t2,C_SCHEME_UNDEFINED);}}

/* k4170 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 879  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[369]);}
else{
/* c-backend.scm: 880  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[370],((C_word*)t0)[3]);}}

/* k4173 in k4170 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4187,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 882  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4178(2,t3,C_SCHEME_UNDEFINED);}}

/* k4185 in k4173 in k4170 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4176 in k4173 in k4170 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 884  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[368]);}

/* k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[309]);
if(C_truep(t3)){
/* c-backend.scm: 852  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_4046(2,t4,C_SCHEME_UNDEFINED);}}

/* k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 853  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[363],((C_word*)t0)[5],lf[364]);}

/* k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 855  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4052(2,t3,C_SCHEME_UNDEFINED);}}

/* k4151 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 857  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[359],C_SCHEME_TRUE,lf[360],C_SCHEME_TRUE,lf[361],((C_word*)t0)[6],lf[362]);}

/* k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[354]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 861  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[355],((C_word*)t0)[6],lf[356]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[309]);
if(C_truep(t5)){
/* c-backend.scm: 862  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[357],((C_word*)t0)[6],lf[358]);}
else{
t6=t2;
f_4058(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 863  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[353]);}

/* k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4126,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 864  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[352]);}

/* k4124 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 864  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4120 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 865  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[350],((C_word*)t0)[5],lf[351]);}

/* k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 867  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[348],((C_word*)t0)[2],lf[349]);}

/* k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 869  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[346],((C_word*)t0)[3],lf[347]);}

/* k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 870  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[345]);}

/* k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4097(t7,t2,t3,((C_word*)t0)[2]);}

/* do503 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4097,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4107,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 874  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[344],t2,C_make_character(59));}}

/* k4105 in do503 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4097(t4,((C_word*)t0)[2],t2,t3);}

/* k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4035 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 875  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[342],((C_word*)t0)[3],lf[343]);}
else{
t3=((C_word*)t0)[2];
f_4017(2,t3,C_SCHEME_UNDEFINED);}}

/* k4015 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 886  lambda-literal-body */
t4=C_retrieve(lf[341]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4025 in k4015 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 885  expression */
t3=((C_word*)t0)[4];
f_1199(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k4018 in k4015 in k4012 in k4009 in k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in a3916 in procedures in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 891  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3521,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 653  immediate? */
t4=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3528,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[334]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3521(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3588,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3596,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 658  vector->list */
t6=*((C_word*)lf[337]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 659  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k3600 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3602,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 660  bad-literal */
f_3515(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 662  ##sys#bytevector? */
t3=*((C_word*)lf[339]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k3618 in k3600 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3620,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 662  words */
t4=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3649(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 669  bad-literal */
f_3515(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k3618 in k3600 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3649(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3649,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3671,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 668  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3521(3,t8,t6,t7);}}

/* k3669 in loop in k3618 in k3600 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 668  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3649(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3625 in k3618 in k3600 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k3594 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3590 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 658  reduce */
t2=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[336]+1),C_fix(0),t1);}

/* k3586 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k3557 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3563,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3521(3,t4,t2,t3);}

/* k3561 in k3557 in k3526 in literal-size in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3478,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3484(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* do389 in literal-frame in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3484(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3484,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3494,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3513,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 647  sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[333],t2);}}

/* k3511 in do389 in literal-frame in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 647  gen-lit */
t2=((C_word*)t0)[4];
f_3680(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3492 in do389 in literal-frame in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3484(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3680,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 673  big-fixnum? */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_3687(t5,C_SCHEME_FALSE);}}

/* k3818 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3687(t2,(C_word)C_i_not(t1));}

/* k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3687,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 674  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[316],((C_word*)t0)[4],lf[317]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 675  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k3691 in k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[0]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 677  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[318]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[319]:lf[320]);
/* c-backend.scm: 679  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 681  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[321],t4,lf[322]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3743,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 684  c-ify-string */
t6=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 689  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[326]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_3776(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_3776(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k3774 in k3691 in k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3776,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 693  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[329]);}
else{
/* c-backend.scm: 696  bad-literal */
f_3515(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k3777 in k3774 in k3691 in k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3789,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 694  encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3787 in k3777 in k3774 in k3691 in k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 694  gen-string-constant */
t2=((C_word*)t0)[3];
f_3822(t2,((C_word*)t0)[2],t1);}

/* k3780 in k3777 in k3774 in k3691 in k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 695  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[327]);}

/* k3741 in k3691 in k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3749,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 686  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[325]);}

/* k3747 in k3741 in k3691 in k3685 in gen-lit in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 687  gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[323],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[324]);}

/* bad-literal in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3515(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3515,NULL,2,t1,t2);}
/* c-backend.scm: 650  bomb */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[315],t2);}

/* gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3822(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3822,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3829,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 700  fx/ */
t5=*((C_word*)lf[314]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3832,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 701  modulo */
t3=*((C_word*)lf[313]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3832,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3837,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3837(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do420 in k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3837(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3837,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3853(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_3853(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3874,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3889,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3893,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 707  string-like-substring */
f_3899(t7,((C_word*)t0)[4],t3,t8);}}

/* k3891 in do420 in k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3887 in do420 in k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3872 in do420 in k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3837(t4,((C_word*)t0)[2],t2,t3);}

/* k3851 in do420 in k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3853,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3864,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 706  string-like-substring */
f_3899(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3862 in k3851 in do420 in k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3858 in k3851 in do420 in k3830 in k3827 in gen-string-constant in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3899(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3899,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3906,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 711  make-string */
t7=*((C_word*)lf[312]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3904 in string-like-substring in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 712  ##sys#copy-bytes */
t3=C_retrieve(lf[311]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k3907 in k3904 in string-like-substring in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3192,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3195,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3231,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3311,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3359,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3359,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3363,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 606  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 607  lambda-literal-rest-argument */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 608  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 609  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 610  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 611  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3378(t3,C_SCHEME_FALSE);}}

/* k3474 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3378(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3378,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_3381(t5,t4);}
else{
t3=t2;
f_3381(t3,C_SCHEME_UNDEFINED);}}

/* k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3381,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 613  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 615  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[305],((C_word*)t0)[9],lf[306],C_SCHEME_TRUE,lf[307],((C_word*)t0)[9],lf[308]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3421(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 623  lambda-literal-allocated */
t4=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k3463 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3421(2,t3,t2);}
else{
/* c-backend.scm: 623  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3419 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[224]);
t4=t2;
f_3427(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3427(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3425 in k3419 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3427,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[309]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 626  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 627  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 628  lset-adjoin */
t3=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3443 in k3425 in k3419 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3439 in k3425 in k3419 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3435 in k3425 in k3419 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3391 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 617  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[303],((C_word*)t0)[3],lf[304]);}

/* k3394 in k3391 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 618  restore */
f_3195(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3397 in k3394 in k3391 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 619  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3400 in k3397 in k3394 in k3391 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 620  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[302]);}

/* k3403 in k3400 in k3397 in k3394 in k3391 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 621  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k3413 in k3403 in k3400 in k3397 in k3394 in k3391 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3385 in k3379 in k3376 in k3373 in k3370 in k3367 in k3364 in k3361 in a3358 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 622  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[301]);}

/* k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3330,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 632  gen */
t4=C_retrieve(lf[2]);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[296],t2,lf[297],C_SCHEME_TRUE,lf[298],t2,lf[299],t2,lf[300]);}

/* k3332 in a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 634  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[293],((C_word*)t0)[3],lf[294],((C_word*)t0)[3],lf[295]);}

/* k3335 in k3332 in a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  restore */
f_3195(t2,((C_word*)t0)[3]);}

/* k3338 in k3335 in k3332 in a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[292],((C_word*)t0)[2],C_make_character(44));}

/* k3341 in k3338 in k3335 in k3332 in a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3353,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 637  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[291]);}

/* k3355 in k3341 in k3338 in k3335 in k3332 in a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 637  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3351 in k3341 in k3338 in k3335 in k3332 in a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3344 in k3341 in k3338 in k3335 in k3332 in a3329 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 638  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[290]);}

/* k3312 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 640  emitter */
t4=((C_word*)t0)[3];
f_3231(t4,t3,C_SCHEME_FALSE);}

/* k3326 in k3312 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3315 in k3312 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 641  emitter */
t3=((C_word*)t0)[2];
f_3231(t3,t2,C_SCHEME_TRUE);}

/* k3322 in k3315 in k3312 in k3309 in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3231(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3231,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3233 in emitter in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3233,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[285]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[286]);
/* c-backend.scm: 584  gen */
t6=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[287],t2,C_make_character(114),t4,lf[288],C_SCHEME_TRUE,lf[289],t2,C_make_character(114),t5);}

/* k3235 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 586  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[283],((C_word*)t0)[4],lf[284]);}

/* k3238 in k3235 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 587  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[282],((C_word*)t0)[4],C_make_character(114));}

/* k3241 in k3238 in k3235 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 588  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3246(2,t3,C_SCHEME_UNDEFINED);}}

/* k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 589  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[278],((C_word*)t0)[4],lf[279],C_SCHEME_TRUE,lf[280],C_SCHEME_TRUE,lf[281],((C_word*)t0)[4],C_make_character(59));}

/* k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 592  restore */
f_3195(t2,((C_word*)t0)[4]);}

/* k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 593  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[277]);}

/* k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 595  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}
else{
/* c-backend.scm: 596  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[276]);}}

/* k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 597  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[274]);}

/* k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 598  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[273]);}
else{
t3=t2;
f_3264(2,t3,C_SCHEME_UNDEFINED);}}

/* k3262 in k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 599  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[272]);}

/* k3265 in k3262 in k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 600  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[271]);}

/* k3268 in k3265 in k3262 in k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3280,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 601  make-argument-list */
t6=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[270]);}

/* k3282 in k3268 in k3265 in k3262 in k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 601  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3278 in k3268 in k3265 in k3262 in k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3271 in k3268 in k3265 in k3262 in k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 602  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[268]);}

/* restore in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3195(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3195,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3199,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3208,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3208(t8,t3,t4,C_fix(0));}

/* do338 in restore in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3208,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3218,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 579  gen */
t5=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[265],t2,lf[266],t3,lf[267]);}}

/* k3216 in do338 in restore in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3208(t4,((C_word*)t0)[2],t2,t3);}

/* k3197 in restore in trampolines in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 580  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[263],((C_word*)t0)[2],lf[264]);}

/* prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2941,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 508  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2969,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2973,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 511  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 512  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 513  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2979(t3,C_SCHEME_FALSE);}}

/* k3188 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2979(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2979,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 514  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[260]);}

/* k3174 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 514  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 515  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 516  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 517  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 518  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 519  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 521  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_3000(t5,C_SCHEME_UNDEFINED);}}

/* k3166 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3000(t3,t2);}

/* k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3000,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 522  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 527  lambda-literal-callee-signatures */
t5=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3159 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3141 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3142,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3153,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 526  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k3151 in a3141 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 537  string-append */
t5=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[185]),lf[242]);}
else{
t5=t4;
f_3118(2,t5,lf[243]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 529  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[249],((C_word*)t0)[5],lf[250],C_SCHEME_TRUE);}}

/* k3091 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 530  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[248]);}

/* k3094 in k3091 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[246]:lf[247]);
/* c-backend.scm: 531  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3097 in k3094 in k3091 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 533  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[244]);}
else{
/* c-backend.scm: 534  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}}

/* k3100 in k3097 in k3094 in k3091 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 535  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3116 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3121,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 538  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[240],t1,lf[241],C_SCHEME_TRUE);}

/* k3119 in k3116 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[238]))){
/* c-backend.scm: 540  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[239],C_SCHEME_TRUE);}
else{
t3=t2;
f_3124(2,t3,C_SCHEME_UNDEFINED);}}

/* k3122 in k3119 in k3116 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 541  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k3125 in k3122 in k3119 in k3116 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 542  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[236],((C_word*)t0)[2]);}

/* k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 543  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3015(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 544  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}}

/* k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3065,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3065(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3065(t4,C_SCHEME_FALSE);}}

/* k3063 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_3065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3065,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 546  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}
else{
t2=((C_word*)t0)[2];
f_3018(2,t2,C_SCHEME_UNDEFINED);}}

/* k3066 in k3063 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 547  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3018(2,t2,C_SCHEME_UNDEFINED);}}

/* k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[4]);}

/* k3019 in k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 550  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[231]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 558  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k3051 in k3019 in k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3056(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 560  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[232]);}}

/* k3054 in k3051 in k3019 in k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 561  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3025 in k3019 in k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 553  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[227],((C_word*)t0)[2],lf[228],C_SCHEME_TRUE,lf[229],((C_word*)t0)[2],lf[230]);}}

/* k3034 in k3025 in k3019 in k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k3037 in k3034 in k3025 in k3019 in k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in a2968 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 556  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[225],t2,lf[226]);}

/* k2946 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2953,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a2952 in k2946 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2953,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2957,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 565  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[222],t2,lf[223]);}

/* k2955 in a2952 in k2946 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 566  make-list */
t4=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[221]);}

/* k2965 in k2955 in a2952 in k2946 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k2958 in k2955 in a2952 in k2946 in k2943 in prototypes in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 567  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[219]);}

/* declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2792,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2799,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 479  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[218]);}

/* k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2935,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[187]));}

/* a2934 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2935,3,t0,t1,t2);}
/* c-backend.scm: 482  gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[214],t2,lf[215],C_SCHEME_TRUE,lf[216],t2,lf[217]);}

/* k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_2805(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 486  gen */
t4=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[212],((C_word*)t0)[2],lf[213]);}}

/* k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 487  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[211]);}

/* k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2813,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2813(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2813,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2823,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 491  ##sys#lambda-info->string */
t6=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2829,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 493  gen */
t8=C_retrieve(lf[2]);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[208],((C_word*)t0)[5],lf[209],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2882(t6,t2,C_fix(0));}

/* do274 in k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2882(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2882,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2892,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 500  gen */
t7=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k2890 in do274 in k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2882(t3,((C_word*)t0)[2],t2);}

/* k2830 in k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2855(t9,t2,t5);}

/* do279 in k2830 in k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2855,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2865,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 503  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[207]);}}

/* k2863 in do279 in k2830 in k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2855(t3,((C_word*)t0)[2],t2);}

/* k2833 in k2830 in k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 504  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k2836 in k2833 in k2830 in k2827 in k2821 in do268 in k2806 in k2803 in k2800 in k2797 in declarations in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2813(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2626,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2629,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2646,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2784,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 449  current-seconds */
t5=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2782 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 449  ##sys#decode-seconds */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_2652(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_2652(t3,C_SCHEME_FALSE);}}

/* k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2652,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2729,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 453  pad0 */
f_2629(t9,t10);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2629(t2,((C_word*)t0)[2]);}

/* k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2629(t2,((C_word*)t0)[2]);}

/* k2735 in k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2741,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 453  pad0 */
f_2629(t2,((C_word*)t0)[2]);}

/* k2739 in k2735 in k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2745,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2751,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 456  chicken-version */
t7=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k2761 in k2739 in k2735 in k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 456  string-split */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k2757 in k2739 in k2735 in k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2750 in k2739 in k2735 in k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2751,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[197],t2,lf[198]);}

/* k2747 in k2739 in k2735 in k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 454  string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[196]);}

/* k2743 in k2739 in k2735 in k2731 in k2727 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 451  gen */
t2=C_retrieve(lf[2]);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[190],((C_word*)t0)[7],lf[191],C_SCHEME_TRUE,lf[192],C_SCHEME_TRUE,lf[193],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[194]);}

/* k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 459  gen-list */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[189]));}

/* k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 460  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 461  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[186],C_retrieve(lf[185]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 463  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[188]);}}

/* k2716 in k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 464  gen-list */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[187]));}

/* k2677 in k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 465  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[181],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[182],C_retrieve(lf[183]),lf[184]);}

/* k2680 in k2677 in k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[177]))){
/* c-backend.scm: 467  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[179]));}
else{
t3=t2;
f_2685(2,t3,C_SCHEME_UNDEFINED);}}

/* k2683 in k2680 in k2677 in k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[180])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 469  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_2688(2,t3,C_SCHEME_UNDEFINED);}}

/* k2698 in k2683 in k2680 in k2677 in k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2705,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[180]));}

/* a2704 in k2698 in k2683 in k2680 in k2677 in k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2705,3,t0,t1,t2);}
/* c-backend.scm: 470  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k2686 in k2683 in k2680 in k2677 in k2674 in k2671 in k2668 in k2650 in k2644 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[177]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 472  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[179]));}}

/* pad0 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2629(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2629,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 447  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2641 in pad0 in header in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 447  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[176],t1);}

/* expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_1199(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1199,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2594,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 442  expr */
t11=((C_word*)t6)[1];
f_1202(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2594(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2594,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2600,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 436  pair-for-each */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a2599 in expr-args in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2600,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_2604(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 438  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k2602 in a2599 in expr-args in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 439  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1202(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_1202(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[209],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1202,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[16]:lf[17]);
/* c-backend.scm: 127  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[18]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 128  gen */
t16=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t1,lf[19],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t14)){
/* c-backend.scm: 129  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,lf[21]);}
else{
t15=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 130  gen */
t17=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t1,lf[23],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t16)){
/* c-backend.scm: 131  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[25]);}
else{
/* c-backend.scm: 132  bomb */
t17=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[26]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[27]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 137  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[28],t13,lf[29]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 138  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[30],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[31]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1326,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
t14=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_SCHEME_TRUE,lf[34]);}
else{
t13=(C_word)C_eqp(t9,lf[35]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 150  gen */
t15=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,lf[36],t14);}
else{
t14=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1384,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_1384(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[38]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1435,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 162  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[40]);}
else{
t16=(C_word)C_eqp(t9,lf[41]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1462,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 167  gen */
t18=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,lf[43]);}
else{
t17=(C_word)C_eqp(t9,lf[44]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1481,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 172  gen */
t19=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[45]);}
else{
t18=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1514,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 179  gen */
t20=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[49]);}
else{
t19=(C_word)C_eqp(t9,lf[50]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1551,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
t21=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,lf[52]);}
else{
t20=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1580,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
t22=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[55]);}
else{
t21=(C_word)C_eqp(t9,lf[56]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1612,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 201  gen */
t24=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t24))(5,t24,t23,lf[63],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[64]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1647,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 211  gen */
t24=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,lf[66]);}
else{
t23=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 215  gen */
t25=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[68]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1679,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 218  gen */
t27=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t27))(5,t27,t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 227  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[70],t26,lf[71]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1721,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1725,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 228  symbol->string */
t31=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 229  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[76],t26,lf[77]);}
else{
/* c-backend.scm: 230  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[78],t26,lf[79]);}}}
else{
t26=(C_word)C_eqp(t9,lf[80]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1753,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t28)){
/* c-backend.scm: 236  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[81],t27,lf[82]);}
else{
/* c-backend.scm: 237  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[83],t27,lf[84]);}}
else{
t27=(C_word)C_eqp(t9,lf[85]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_cadr(t7))){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1787,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 245  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[86],t28,lf[87]);}
else{
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1800,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 249  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[88],t28,lf[89]);}}
else{
t28=(C_word)C_eqp(t9,lf[90]);
if(C_truep(t28)){
/* c-backend.scm: 253  gen */
t29=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t29))(3,t29,t1,lf[91]);}
else{
t29=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1843,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=t36,a[5]=t32,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t31,a[9]=t33,a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 262  source-info->string */
t38=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[125]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2154,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 319  lambda-literal-closure-size */
t36=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[129]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2239,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2243,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 347  find-lambda */
t41=((C_word*)t0)[2];
f_1157(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[131]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2262,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 364  gen */
t37=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t37))(8,t37,t35,C_SCHEME_TRUE,lf[133],t36,lf[134],t34,lf[135]);}
else{
t33=(C_word)C_eqp(t9,lf[136]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2281,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 369  gen */
t35=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,C_SCHEME_TRUE,lf[138]);}
else{
t34=(C_word)C_eqp(t9,lf[139]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2300,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 374  gen */
t37=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t37))(5,t37,t35,lf[140],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[141]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2319,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 379  gen */
t39=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t39))(6,t39,t36,lf[142],t37,lf[143],t38);}
else{
t36=(C_word)C_eqp(t9,lf[144]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2355,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 387  foreign-result-conversion */
t39=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t39))(4,t39,t37,t38,lf[146]);}
else{
t37=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2375,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2393,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-type-declaration */
t42=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t38,lf[152]);}
else{
t38=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2409,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-result-conversion */
t42=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t39,lf[158]);}
else{
t39=(C_word)C_eqp(t9,lf[159]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2439,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2467,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 403  foreign-type-declaration */
t43=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t42,t40,lf[164]);}
else{
t40=(C_word)C_eqp(t9,lf[165]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2476,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 410  gen */
t42=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,C_SCHEME_TRUE,lf[169]);}
else{
t41=(C_word)C_eqp(t9,lf[170]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2559,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 425  gen */
t43=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t43))(3,t43,t42,lf[172]);}
else{
/* c-backend.scm: 433  bomb */
t42=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t42))(3,t42,t1,lf[173]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2557 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 426  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2560 in k2557 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 427  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[171]);}

/* k2563 in k2560 in k2557 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2566 in k2563 in k2560 in k2557 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 429  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2569 in k2566 in k2563 in k2560 in k2557 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 430  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 431  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1202(t4,t2,t3,((C_word*)t0)[3]);}

/* k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 412  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2482,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2495,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2495(t7,((C_word*)t0)[2],t2,t3);}

/* do215 in k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2495(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2495,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 416  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[166]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 419  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[167]);}}

/* k2516 in do215 in k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 420  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2519 in k2516 in do215 in k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 421  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2522 in k2519 in k2516 in do215 in k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2525 in k2522 in k2519 in k2516 in do215 in k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2495(t4,((C_word*)t0)[2],t2,t3);}

/* k2503 in do215 in k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 417  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2506 in k2503 in do215 in k2480 in k2477 in k2474 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 418  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k2465 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 403  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[162],t1,lf[163]);}

/* k2437 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 404  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1202(t4,t2,t3,((C_word*)t0)[3]);}

/* k2440 in k2437 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 405  foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2457 in k2440 in k2437 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 405  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[161],t1);}

/* k2443 in k2440 in k2437 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 406  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2446 in k2443 in k2440 in k2437 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[160]);}

/* k2421 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2427,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[157]);}

/* k2425 in k2421 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 397  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[156]);}

/* k2407 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 398  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2410 in k2407 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 399  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[154]);}

/* k2391 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2397,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2395 in k2391 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 391  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_make_character(41),t1);}

/* k2373 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 392  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2376 in k2373 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 393  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[148]);}

/* k2353 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 387  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k2317 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 382  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_2322(2,t3,C_SCHEME_UNDEFINED);}}

/* k2329 in k2317 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 383  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2594(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2320 in k2317 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 384  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2298 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 375  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2594(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2301 in k2298 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 376  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2279 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 370  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k2282 in k2279 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 371  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k2260 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 365  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2594(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2263 in k2260 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 366  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[132]);}

/* k2241 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 347  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2237 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 349  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k2185 in k2237 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2220,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 351  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[130],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_2190(2,t3,C_SCHEME_UNDEFINED);}}

/* k2218 in k2185 in k2237 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 352  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_2190(2,t4,C_SCHEME_UNDEFINED);}}

/* k2188 in k2185 in k2237 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_2193(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2208,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 354  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k2206 in k2188 in k2185 in k2237 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 355  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2193(2,t2,C_SCHEME_UNDEFINED);}}

/* k2191 in k2188 in k2185 in k2237 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 356  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_2196(2,t3,C_SCHEME_UNDEFINED);}}

/* k2194 in k2191 in k2188 in k2185 in k2237 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 357  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 321  lambda-literal-temporaries */
t4=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2138,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 334  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k2136 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2141(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 335  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[128]);}}

/* k2139 in k2136 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 336  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2594(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2142 in k2139 in k2136 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 322  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 323  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2120 in k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2121,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 325  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2123 in a2120 in k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 326  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1202(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2126 in k2123 in a2120 in k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 327  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2101 in k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2111,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 331  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2117 in k2101 in k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 329  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2110 in k2101 in k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2111,4,t0,t1,t2,t3);}
/* c-backend.scm: 330  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[127],t2,C_make_character(59));}

/* k2104 in k2101 in k2098 in k2095 in k2152 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 332  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126]);}

/* k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[15]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_1846(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1846(t3,C_SCHEME_FALSE);}}

/* k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_1846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1846,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2047,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 265  find-lambda */
t6=((C_word*)t0)[2];
f_1157(t6,t5,t1);}
else{
t4=t3;
f_1852(t4,C_SCHEME_FALSE);}}

/* k2045 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 265  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2041 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1852(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_1852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1852,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[112]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2036,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1197,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 115  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}}
else{
t4=t3;
f_1858(2,t4,C_SCHEME_UNDEFINED);}}

/* k1195 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 115  string-translate* */
t2=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[122]);}

/* k2034 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[119],t1,lf[120]);}

/* k1185 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  string-translate */
t2=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[116],lf[117]);}

/* k2027 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 269  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[113],t1,lf[114]);}

/* k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[35],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 273  gen */
t7=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[94]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 277  lambda-literal-id */
t6=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 303  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k1980 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 304  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1202(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k1983 in k1980 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 305  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[110],((C_word*)t0)[4],lf[111]);}

/* k1986 in k1983 in k1980 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2003(t5,t3);}
else{
t5=C_retrieve(lf[109]);
t6=t4;
f_2003(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k2001 in k1986 in k1983 in k1980 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_2003(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 308  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[105],((C_word*)t0)[2],lf[106]);}
else{
/* c-backend.scm: 309  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[107],((C_word*)t0)[2],lf[108]);}}

/* k1989 in k1986 in k1983 in k1980 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 310  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[102],((C_word*)t0)[3],lf[103],((C_word*)t0)[2],C_make_character(44));}

/* k1992 in k1989 in k1986 in k1983 in k1980 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 311  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2594(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 312  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k1977 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 278  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_1889(2,t3,C_SCHEME_FALSE);}}

/* k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 279  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_1939(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 294  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k1961 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 295  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1202(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1964 in k1961 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 296  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1937 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 297  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k1940 in k1937 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1945(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 298  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k1943 in k1940 in k1937 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1948(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 299  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k1946 in k1943 in k1940 in k1937 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2594(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1949 in k1946 in k1943 in k1940 in k1937 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 280  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 281  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a1921 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1922,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 283  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k1924 in a1921 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 284  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1202(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1927 in k1924 in a1921 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 285  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1896 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1912,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 289  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k1918 in k1896 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 287  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1911 in k1896 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1912,4,t0,t1,t2,t3);}
/* c-backend.scm: 288  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[97],t2,C_make_character(59));}

/* k1899 in k1896 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1904(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 290  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[96],((C_word*)t0)[2],C_make_character(59));}}

/* k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 291  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[95]);}

/* k1868 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 274  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2594(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1871 in k1868 in k1856 in k1850 in k1844 in k1841 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[93]);}

/* k1798 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 250  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1801 in k1798 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1785 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 246  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1788 in k1785 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1751 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 238  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1754 in k1751 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1723 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1719 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[72],((C_word*)t0)[2],lf[73],t1,C_make_character(41));}

/* k1677 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 219  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1202(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1645 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1648 in k1645 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[65]);}

/* k1610 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1615,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 207  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k1636 in k1610 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 202  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1623 in k1610 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1624,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[59],t3,lf[60]);}

/* k1626 in a1623 in k1610 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 205  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1202(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1629 in k1626 in a1623 in k1610 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k1613 in k1610 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 208  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[57],t2,lf[58]);}

/* k1578 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1581 in k1578 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 195  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k1584 in k1581 in k1578 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 196  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1587 in k1584 in k1581 in k1578 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 197  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1549 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1552 in k1549 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 188  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[51]);}

/* k1555 in k1552 in k1549 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 189  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1558 in k1555 in k1552 in k1549 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 190  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1512 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1202(t4,t2,t3,((C_word*)t0)[3]);}

/* k1515 in k1512 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 181  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[47],t4,lf[48]);}

/* k1518 in k1515 in k1512 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 182  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1521 in k1518 in k1515 in k1512 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 183  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1479 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1202(t4,t2,t3,((C_word*)t0)[3]);}

/* k1482 in k1479 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 174  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k1485 in k1482 in k1479 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 175  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1488 in k1485 in k1482 in k1479 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 176  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1460 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 168  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1463 in k1460 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 169  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1433 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1438,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 163  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1436 in k1433 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 164  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[39],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_1384(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1384,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 155  gen */
t7=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 159  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1202(t7,t1,t6,t3);}}

/* k1392 in loop in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 156  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1202(t4,t2,t3,((C_word*)t0)[6]);}

/* k1395 in k1392 in loop in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 157  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k1398 in k1395 in k1392 in loop in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 158  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1384(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k1324 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1327 in k1324 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k1330 in k1327 in k1324 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1333 in k1330 in k1327 in k1324 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[32]);}

/* k1336 in k1333 in k1330 in k1327 in k1324 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1202(t4,t2,t3,((C_word*)t0)[2]);}

/* k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in expr in expression in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_fcall f_1157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1157,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1161,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 111  find */
t5=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1168 in find-lambda in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1169,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 111  lambda-literal-id */
t4=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1175 in a1168 in find-lambda in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k1159 in find-lambda in ##compiler#generate-code in k1150 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 112  bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1134,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1140,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1148,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 93   intersperse */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k1146 in ##compiler#gen-list in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1139 in ##compiler#gen-list in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1140,3,t0,t1,t2);}
/* c-backend.scm: 92   display */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[1]));}

/* ##compiler#gen in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_1113r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1113r(t0,t1,t2);}}

static void C_ccall f_1113r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1119,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a1118 in ##compiler#gen in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1119,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 86   newline */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_retrieve(lf[1]));}
else{
/* c-backend.scm: 87   display */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve(lf[1]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[675] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_1092c-backend.scm",(void*)f_1092},
{"f_1095c-backend.scm",(void*)f_1095},
{"f_1098c-backend.scm",(void*)f_1098},
{"f_1101c-backend.scm",(void*)f_1101},
{"f_1104c-backend.scm",(void*)f_1104},
{"f_1107c-backend.scm",(void*)f_1107},
{"f_8811c-backend.scm",(void*)f_8811},
{"f_8815c-backend.scm",(void*)f_8815},
{"f_8807c-backend.scm",(void*)f_8807},
{"f_1152c-backend.scm",(void*)f_1152},
{"f_8507c-backend.scm",(void*)f_8507},
{"f_8783c-backend.scm",(void*)f_8783},
{"f_8781c-backend.scm",(void*)f_8781},
{"f_8769c-backend.scm",(void*)f_8769},
{"f_8739c-backend.scm",(void*)f_8739},
{"f_8700c-backend.scm",(void*)f_8700},
{"f_8687c-backend.scm",(void*)f_8687},
{"f_8683c-backend.scm",(void*)f_8683},
{"f_8569c-backend.scm",(void*)f_8569},
{"f_8516c-backend.scm",(void*)f_8516},
{"f_8513c-backend.scm",(void*)f_8513},
{"f_8510c-backend.scm",(void*)f_8510},
{"f_7733c-backend.scm",(void*)f_7733},
{"f_7820c-backend.scm",(void*)f_7820},
{"f_7901c-backend.scm",(void*)f_7901},
{"f_8336c-backend.scm",(void*)f_8336},
{"f_8278c-backend.scm",(void*)f_8278},
{"f_8242c-backend.scm",(void*)f_8242},
{"f_8207c-backend.scm",(void*)f_8207},
{"f_8159c-backend.scm",(void*)f_8159},
{"f_8111c-backend.scm",(void*)f_8111},
{"f_8063c-backend.scm",(void*)f_8063},
{"f_8028c-backend.scm",(void*)f_8028},
{"f_7992c-backend.scm",(void*)f_7992},
{"f_7956c-backend.scm",(void*)f_7956},
{"f_7934c-backend.scm",(void*)f_7934},
{"f_7929c-backend.scm",(void*)f_7929},
{"f_7924c-backend.scm",(void*)f_7924},
{"f_7735c-backend.scm",(void*)f_7735},
{"f_6900c-backend.scm",(void*)f_6900},
{"f_6930c-backend.scm",(void*)f_6930},
{"f_6957c-backend.scm",(void*)f_6957},
{"f_7152c-backend.scm",(void*)f_7152},
{"f_7161c-backend.scm",(void*)f_7161},
{"f_7170c-backend.scm",(void*)f_7170},
{"f_7558c-backend.scm",(void*)f_7558},
{"f_7525c-backend.scm",(void*)f_7525},
{"f_7535c-backend.scm",(void*)f_7535},
{"f_7493c-backend.scm",(void*)f_7493},
{"f_7458c-backend.scm",(void*)f_7458},
{"f_7388c-backend.scm",(void*)f_7388},
{"f_7343c-backend.scm",(void*)f_7343},
{"f_7311c-backend.scm",(void*)f_7311},
{"f_7279c-backend.scm",(void*)f_7279},
{"f_7247c-backend.scm",(void*)f_7247},
{"f_7215c-backend.scm",(void*)f_7215},
{"f_7193c-backend.scm",(void*)f_7193},
{"f_6902c-backend.scm",(void*)f_6902},
{"f_5683c-backend.scm",(void*)f_5683},
{"f_5760c-backend.scm",(void*)f_5760},
{"f_5862c-backend.scm",(void*)f_5862},
{"f_5895c-backend.scm",(void*)f_5895},
{"f_5991c-backend.scm",(void*)f_5991},
{"f_6006c-backend.scm",(void*)f_6006},
{"f_6623c-backend.scm",(void*)f_6623},
{"f_6639c-backend.scm",(void*)f_6639},
{"f_6643c-backend.scm",(void*)f_6643},
{"f_6656c-backend.scm",(void*)f_6656},
{"f_6654c-backend.scm",(void*)f_6654},
{"f_6650c-backend.scm",(void*)f_6650},
{"f_6577c-backend.scm",(void*)f_6577},
{"f_6590c-backend.scm",(void*)f_6590},
{"f_6527c-backend.scm",(void*)f_6527},
{"f_6477c-backend.scm",(void*)f_6477},
{"f_6438c-backend.scm",(void*)f_6438},
{"f_6448c-backend.scm",(void*)f_6448},
{"f_6399c-backend.scm",(void*)f_6399},
{"f_6409c-backend.scm",(void*)f_6409},
{"f_6360c-backend.scm",(void*)f_6360},
{"f_6370c-backend.scm",(void*)f_6370},
{"f_6321c-backend.scm",(void*)f_6321},
{"f_6331c-backend.scm",(void*)f_6331},
{"f_6261c-backend.scm",(void*)f_6261},
{"f_6278c-backend.scm",(void*)f_6278},
{"f_6288c-backend.scm",(void*)f_6288},
{"f_6286c-backend.scm",(void*)f_6286},
{"f_6282c-backend.scm",(void*)f_6282},
{"f_6274c-backend.scm",(void*)f_6274},
{"f_6222c-backend.scm",(void*)f_6222},
{"f_6232c-backend.scm",(void*)f_6232},
{"f_6186c-backend.scm",(void*)f_6186},
{"f_6150c-backend.scm",(void*)f_6150},
{"f_6114c-backend.scm",(void*)f_6114},
{"f_6078c-backend.scm",(void*)f_6078},
{"f_6052c-backend.scm",(void*)f_6052},
{"f_6060c-backend.scm",(void*)f_6060},
{"f_6043c-backend.scm",(void*)f_6043},
{"f_6051c-backend.scm",(void*)f_6051},
{"f_6038c-backend.scm",(void*)f_6038},
{"f_5690c-backend.scm",(void*)f_5690},
{"f_5685c-backend.scm",(void*)f_5685},
{"f_5618c-backend.scm",(void*)f_5618},
{"f_5622c-backend.scm",(void*)f_5622},
{"f_5625c-backend.scm",(void*)f_5625},
{"f_5628c-backend.scm",(void*)f_5628},
{"f_5631c-backend.scm",(void*)f_5631},
{"f_5637c-backend.scm",(void*)f_5637},
{"f_5681c-backend.scm",(void*)f_5681},
{"f_5640c-backend.scm",(void*)f_5640},
{"f_5648c-backend.scm",(void*)f_5648},
{"f_5669c-backend.scm",(void*)f_5669},
{"f_5652c-backend.scm",(void*)f_5652},
{"f_5643c-backend.scm",(void*)f_5643},
{"f_5187c-backend.scm",(void*)f_5187},
{"f_5193c-backend.scm",(void*)f_5193},
{"f_5197c-backend.scm",(void*)f_5197},
{"f_5200c-backend.scm",(void*)f_5200},
{"f_5203c-backend.scm",(void*)f_5203},
{"f_5206c-backend.scm",(void*)f_5206},
{"f_5212c-backend.scm",(void*)f_5212},
{"f_5553c-backend.scm",(void*)f_5553},
{"f_5556c-backend.scm",(void*)f_5556},
{"f_5616c-backend.scm",(void*)f_5616},
{"f_5559c-backend.scm",(void*)f_5559},
{"f_5562c-backend.scm",(void*)f_5562},
{"f_5565c-backend.scm",(void*)f_5565},
{"f_5568c-backend.scm",(void*)f_5568},
{"f_5601c-backend.scm",(void*)f_5601},
{"f_5609c-backend.scm",(void*)f_5609},
{"f_5571c-backend.scm",(void*)f_5571},
{"f_5599c-backend.scm",(void*)f_5599},
{"f_5574c-backend.scm",(void*)f_5574},
{"f_5577c-backend.scm",(void*)f_5577},
{"f_5580c-backend.scm",(void*)f_5580},
{"f_5214c-backend.scm",(void*)f_5214},
{"f_5224c-backend.scm",(void*)f_5224},
{"f_5233c-backend.scm",(void*)f_5233},
{"f_5245c-backend.scm",(void*)f_5245},
{"f_5257c-backend.scm",(void*)f_5257},
{"f_5263c-backend.scm",(void*)f_5263},
{"f_5297c-backend.scm",(void*)f_5297},
{"f_4954c-backend.scm",(void*)f_4954},
{"f_4960c-backend.scm",(void*)f_4960},
{"f_4964c-backend.scm",(void*)f_4964},
{"f_4967c-backend.scm",(void*)f_4967},
{"f_4970c-backend.scm",(void*)f_4970},
{"f_5185c-backend.scm",(void*)f_5185},
{"f_4976c-backend.scm",(void*)f_4976},
{"f_4979c-backend.scm",(void*)f_4979},
{"f_4982c-backend.scm",(void*)f_4982},
{"f_4985c-backend.scm",(void*)f_4985},
{"f_4988c-backend.scm",(void*)f_4988},
{"f_4991c-backend.scm",(void*)f_4991},
{"f_4994c-backend.scm",(void*)f_4994},
{"f_4997c-backend.scm",(void*)f_4997},
{"f_5000c-backend.scm",(void*)f_5000},
{"f_5003c-backend.scm",(void*)f_5003},
{"f_5174c-backend.scm",(void*)f_5174},
{"f_5006c-backend.scm",(void*)f_5006},
{"f_5009c-backend.scm",(void*)f_5009},
{"f_5012c-backend.scm",(void*)f_5012},
{"f_5015c-backend.scm",(void*)f_5015},
{"f_5018c-backend.scm",(void*)f_5018},
{"f_5021c-backend.scm",(void*)f_5021},
{"f_5024c-backend.scm",(void*)f_5024},
{"f_5027c-backend.scm",(void*)f_5027},
{"f_5152c-backend.scm",(void*)f_5152},
{"f_5122c-backend.scm",(void*)f_5122},
{"f_5142c-backend.scm",(void*)f_5142},
{"f_5130c-backend.scm",(void*)f_5130},
{"f_5134c-backend.scm",(void*)f_5134},
{"f_5138c-backend.scm",(void*)f_5138},
{"f_5030c-backend.scm",(void*)f_5030},
{"f_5033c-backend.scm",(void*)f_5033},
{"f_5063c-backend.scm",(void*)f_5063},
{"f_5066c-backend.scm",(void*)f_5066},
{"f_5104c-backend.scm",(void*)f_5104},
{"f_5100c-backend.scm",(void*)f_5100},
{"f_5069c-backend.scm",(void*)f_5069},
{"f_5072c-backend.scm",(void*)f_5072},
{"f_5075c-backend.scm",(void*)f_5075},
{"f_5042c-backend.scm",(void*)f_5042},
{"f_5045c-backend.scm",(void*)f_5045},
{"f_5036c-backend.scm",(void*)f_5036},
{"f_4936c-backend.scm",(void*)f_4936},
{"f_4942c-backend.scm",(void*)f_4942},
{"f_4946c-backend.scm",(void*)f_4946},
{"f_4949c-backend.scm",(void*)f_4949},
{"f_4885c-backend.scm",(void*)f_4885},
{"f_4889c-backend.scm",(void*)f_4889},
{"f_4894c-backend.scm",(void*)f_4894},
{"f_4901c-backend.scm",(void*)f_4901},
{"f_4921c-backend.scm",(void*)f_4921},
{"f_4869c-backend.scm",(void*)f_4869},
{"f_4875c-backend.scm",(void*)f_4875},
{"f_4883c-backend.scm",(void*)f_4883},
{"f_4853c-backend.scm",(void*)f_4853},
{"f_4859c-backend.scm",(void*)f_4859},
{"f_4867c-backend.scm",(void*)f_4867},
{"f_4764c-backend.scm",(void*)f_4764},
{"f_4773c-backend.scm",(void*)f_4773},
{"f_4802c-backend.scm",(void*)f_4802},
{"f_4812c-backend.scm",(void*)f_4812},
{"f_4805c-backend.scm",(void*)f_4805},
{"f_4789c-backend.scm",(void*)f_4789},
{"f_4691c-backend.scm",(void*)f_4691},
{"f_4695c-backend.scm",(void*)f_4695},
{"f_4709c-backend.scm",(void*)f_4709},
{"f_4722c-backend.scm",(void*)f_4722},
{"f_4725c-backend.scm",(void*)f_4725},
{"f_4728c-backend.scm",(void*)f_4728},
{"f_4698c-backend.scm",(void*)f_4698},
{"f_4701c-backend.scm",(void*)f_4701},
{"f_4704c-backend.scm",(void*)f_4704},
{"f_1154c-backend.scm",(void*)f_1154},
{"f_4658c-backend.scm",(void*)f_4658},
{"f_4662c-backend.scm",(void*)f_4662},
{"f_4665c-backend.scm",(void*)f_4665},
{"f_4668c-backend.scm",(void*)f_4668},
{"f_4671c-backend.scm",(void*)f_4671},
{"f_4674c-backend.scm",(void*)f_4674},
{"f_4677c-backend.scm",(void*)f_4677},
{"f_4680c-backend.scm",(void*)f_4680},
{"f_4683c-backend.scm",(void*)f_4683},
{"f_4686c-backend.scm",(void*)f_4686},
{"f_3911c-backend.scm",(void*)f_3911},
{"f_3917c-backend.scm",(void*)f_3917},
{"f_3921c-backend.scm",(void*)f_3921},
{"f_3924c-backend.scm",(void*)f_3924},
{"f_3927c-backend.scm",(void*)f_3927},
{"f_3930c-backend.scm",(void*)f_3930},
{"f_3933c-backend.scm",(void*)f_3933},
{"f_3936c-backend.scm",(void*)f_3936},
{"f_4655c-backend.scm",(void*)f_4655},
{"f_3939c-backend.scm",(void*)f_3939},
{"f_3945c-backend.scm",(void*)f_3945},
{"f_3948c-backend.scm",(void*)f_3948},
{"f_3951c-backend.scm",(void*)f_3951},
{"f_3954c-backend.scm",(void*)f_3954},
{"f_3957c-backend.scm",(void*)f_3957},
{"f_3960c-backend.scm",(void*)f_3960},
{"f_3963c-backend.scm",(void*)f_3963},
{"f_3966c-backend.scm",(void*)f_3966},
{"f_3969c-backend.scm",(void*)f_3969},
{"f_3972c-backend.scm",(void*)f_3972},
{"f_3975c-backend.scm",(void*)f_3975},
{"f_3978c-backend.scm",(void*)f_3978},
{"f_4624c-backend.scm",(void*)f_4624},
{"f_3981c-backend.scm",(void*)f_3981},
{"f_4585c-backend.scm",(void*)f_4585},
{"f_4588c-backend.scm",(void*)f_4588},
{"f_4591c-backend.scm",(void*)f_4591},
{"f_4607c-backend.scm",(void*)f_4607},
{"f_4610c-backend.scm",(void*)f_4610},
{"f_3984c-backend.scm",(void*)f_3984},
{"f_3987c-backend.scm",(void*)f_3987},
{"f_3990c-backend.scm",(void*)f_3990},
{"f_4557c-backend.scm",(void*)f_4557},
{"f_4560c-backend.scm",(void*)f_4560},
{"f_3993c-backend.scm",(void*)f_3993},
{"f_3996c-backend.scm",(void*)f_3996},
{"f_3999c-backend.scm",(void*)f_3999},
{"f_4002c-backend.scm",(void*)f_4002},
{"f_4005c-backend.scm",(void*)f_4005},
{"f_4008c-backend.scm",(void*)f_4008},
{"f_4519c-backend.scm",(void*)f_4519},
{"f_4529c-backend.scm",(void*)f_4529},
{"f_4011c-backend.scm",(void*)f_4011},
{"f_4462c-backend.scm",(void*)f_4462},
{"f_4474c-backend.scm",(void*)f_4474},
{"f_4477c-backend.scm",(void*)f_4477},
{"f_4483c-backend.scm",(void*)f_4483},
{"f_4384c-backend.scm",(void*)f_4384},
{"f_4426c-backend.scm",(void*)f_4426},
{"f_4387c-backend.scm",(void*)f_4387},
{"f_4393c-backend.scm",(void*)f_4393},
{"f_4396c-backend.scm",(void*)f_4396},
{"f_4402c-backend.scm",(void*)f_4402},
{"f_4320c-backend.scm",(void*)f_4320},
{"f_4323c-backend.scm",(void*)f_4323},
{"f_4326c-backend.scm",(void*)f_4326},
{"f_4329c-backend.scm",(void*)f_4329},
{"f_4332c-backend.scm",(void*)f_4332},
{"f_4347c-backend.scm",(void*)f_4347},
{"f_4335c-backend.scm",(void*)f_4335},
{"f_4338c-backend.scm",(void*)f_4338},
{"f_4306c-backend.scm",(void*)f_4306},
{"f_4314c-backend.scm",(void*)f_4314},
{"f_4231c-backend.scm",(void*)f_4231},
{"f_4237c-backend.scm",(void*)f_4237},
{"f_4240c-backend.scm",(void*)f_4240},
{"f_4274c-backend.scm",(void*)f_4274},
{"f_4277c-backend.scm",(void*)f_4277},
{"f_4280c-backend.scm",(void*)f_4280},
{"f_4243c-backend.scm",(void*)f_4243},
{"f_4246c-backend.scm",(void*)f_4246},
{"f_4249c-backend.scm",(void*)f_4249},
{"f_4252c-backend.scm",(void*)f_4252},
{"f_4261c-backend.scm",(void*)f_4261},
{"f_4264c-backend.scm",(void*)f_4264},
{"f_4014c-backend.scm",(void*)f_4014},
{"f_4037c-backend.scm",(void*)f_4037},
{"f_4172c-backend.scm",(void*)f_4172},
{"f_4175c-backend.scm",(void*)f_4175},
{"f_4187c-backend.scm",(void*)f_4187},
{"f_4178c-backend.scm",(void*)f_4178},
{"f_4043c-backend.scm",(void*)f_4043},
{"f_4046c-backend.scm",(void*)f_4046},
{"f_4049c-backend.scm",(void*)f_4049},
{"f_4153c-backend.scm",(void*)f_4153},
{"f_4052c-backend.scm",(void*)f_4052},
{"f_4055c-backend.scm",(void*)f_4055},
{"f_4058c-backend.scm",(void*)f_4058},
{"f_4061c-backend.scm",(void*)f_4061},
{"f_4126c-backend.scm",(void*)f_4126},
{"f_4122c-backend.scm",(void*)f_4122},
{"f_4064c-backend.scm",(void*)f_4064},
{"f_4067c-backend.scm",(void*)f_4067},
{"f_4070c-backend.scm",(void*)f_4070},
{"f_4073c-backend.scm",(void*)f_4073},
{"f_4076c-backend.scm",(void*)f_4076},
{"f_4079c-backend.scm",(void*)f_4079},
{"f_4097c-backend.scm",(void*)f_4097},
{"f_4107c-backend.scm",(void*)f_4107},
{"f_4082c-backend.scm",(void*)f_4082},
{"f_4017c-backend.scm",(void*)f_4017},
{"f_4027c-backend.scm",(void*)f_4027},
{"f_4020c-backend.scm",(void*)f_4020},
{"f_3521c-backend.scm",(void*)f_3521},
{"f_3528c-backend.scm",(void*)f_3528},
{"f_3602c-backend.scm",(void*)f_3602},
{"f_3620c-backend.scm",(void*)f_3620},
{"f_3649c-backend.scm",(void*)f_3649},
{"f_3671c-backend.scm",(void*)f_3671},
{"f_3627c-backend.scm",(void*)f_3627},
{"f_3596c-backend.scm",(void*)f_3596},
{"f_3592c-backend.scm",(void*)f_3592},
{"f_3588c-backend.scm",(void*)f_3588},
{"f_3559c-backend.scm",(void*)f_3559},
{"f_3563c-backend.scm",(void*)f_3563},
{"f_3478c-backend.scm",(void*)f_3478},
{"f_3484c-backend.scm",(void*)f_3484},
{"f_3513c-backend.scm",(void*)f_3513},
{"f_3494c-backend.scm",(void*)f_3494},
{"f_3680c-backend.scm",(void*)f_3680},
{"f_3820c-backend.scm",(void*)f_3820},
{"f_3687c-backend.scm",(void*)f_3687},
{"f_3693c-backend.scm",(void*)f_3693},
{"f_3776c-backend.scm",(void*)f_3776},
{"f_3779c-backend.scm",(void*)f_3779},
{"f_3789c-backend.scm",(void*)f_3789},
{"f_3782c-backend.scm",(void*)f_3782},
{"f_3743c-backend.scm",(void*)f_3743},
{"f_3749c-backend.scm",(void*)f_3749},
{"f_3515c-backend.scm",(void*)f_3515},
{"f_3822c-backend.scm",(void*)f_3822},
{"f_3829c-backend.scm",(void*)f_3829},
{"f_3832c-backend.scm",(void*)f_3832},
{"f_3837c-backend.scm",(void*)f_3837},
{"f_3893c-backend.scm",(void*)f_3893},
{"f_3889c-backend.scm",(void*)f_3889},
{"f_3874c-backend.scm",(void*)f_3874},
{"f_3853c-backend.scm",(void*)f_3853},
{"f_3864c-backend.scm",(void*)f_3864},
{"f_3860c-backend.scm",(void*)f_3860},
{"f_3899c-backend.scm",(void*)f_3899},
{"f_3906c-backend.scm",(void*)f_3906},
{"f_3909c-backend.scm",(void*)f_3909},
{"f_3192c-backend.scm",(void*)f_3192},
{"f_3359c-backend.scm",(void*)f_3359},
{"f_3363c-backend.scm",(void*)f_3363},
{"f_3366c-backend.scm",(void*)f_3366},
{"f_3369c-backend.scm",(void*)f_3369},
{"f_3372c-backend.scm",(void*)f_3372},
{"f_3375c-backend.scm",(void*)f_3375},
{"f_3476c-backend.scm",(void*)f_3476},
{"f_3378c-backend.scm",(void*)f_3378},
{"f_3381c-backend.scm",(void*)f_3381},
{"f_3387c-backend.scm",(void*)f_3387},
{"f_3465c-backend.scm",(void*)f_3465},
{"f_3421c-backend.scm",(void*)f_3421},
{"f_3427c-backend.scm",(void*)f_3427},
{"f_3445c-backend.scm",(void*)f_3445},
{"f_3441c-backend.scm",(void*)f_3441},
{"f_3437c-backend.scm",(void*)f_3437},
{"f_3393c-backend.scm",(void*)f_3393},
{"f_3396c-backend.scm",(void*)f_3396},
{"f_3399c-backend.scm",(void*)f_3399},
{"f_3402c-backend.scm",(void*)f_3402},
{"f_3405c-backend.scm",(void*)f_3405},
{"f_3415c-backend.scm",(void*)f_3415},
{"f_3408c-backend.scm",(void*)f_3408},
{"f_3311c-backend.scm",(void*)f_3311},
{"f_3330c-backend.scm",(void*)f_3330},
{"f_3334c-backend.scm",(void*)f_3334},
{"f_3337c-backend.scm",(void*)f_3337},
{"f_3340c-backend.scm",(void*)f_3340},
{"f_3343c-backend.scm",(void*)f_3343},
{"f_3357c-backend.scm",(void*)f_3357},
{"f_3353c-backend.scm",(void*)f_3353},
{"f_3346c-backend.scm",(void*)f_3346},
{"f_3314c-backend.scm",(void*)f_3314},
{"f_3328c-backend.scm",(void*)f_3328},
{"f_3317c-backend.scm",(void*)f_3317},
{"f_3324c-backend.scm",(void*)f_3324},
{"f_3231c-backend.scm",(void*)f_3231},
{"f_3233c-backend.scm",(void*)f_3233},
{"f_3237c-backend.scm",(void*)f_3237},
{"f_3240c-backend.scm",(void*)f_3240},
{"f_3243c-backend.scm",(void*)f_3243},
{"f_3246c-backend.scm",(void*)f_3246},
{"f_3249c-backend.scm",(void*)f_3249},
{"f_3252c-backend.scm",(void*)f_3252},
{"f_3255c-backend.scm",(void*)f_3255},
{"f_3258c-backend.scm",(void*)f_3258},
{"f_3261c-backend.scm",(void*)f_3261},
{"f_3264c-backend.scm",(void*)f_3264},
{"f_3267c-backend.scm",(void*)f_3267},
{"f_3270c-backend.scm",(void*)f_3270},
{"f_3284c-backend.scm",(void*)f_3284},
{"f_3280c-backend.scm",(void*)f_3280},
{"f_3273c-backend.scm",(void*)f_3273},
{"f_3195c-backend.scm",(void*)f_3195},
{"f_3208c-backend.scm",(void*)f_3208},
{"f_3218c-backend.scm",(void*)f_3218},
{"f_3199c-backend.scm",(void*)f_3199},
{"f_2941c-backend.scm",(void*)f_2941},
{"f_2945c-backend.scm",(void*)f_2945},
{"f_2969c-backend.scm",(void*)f_2969},
{"f_2973c-backend.scm",(void*)f_2973},
{"f_2976c-backend.scm",(void*)f_2976},
{"f_3190c-backend.scm",(void*)f_3190},
{"f_2979c-backend.scm",(void*)f_2979},
{"f_3176c-backend.scm",(void*)f_3176},
{"f_2982c-backend.scm",(void*)f_2982},
{"f_2985c-backend.scm",(void*)f_2985},
{"f_2988c-backend.scm",(void*)f_2988},
{"f_2991c-backend.scm",(void*)f_2991},
{"f_2994c-backend.scm",(void*)f_2994},
{"f_2997c-backend.scm",(void*)f_2997},
{"f_3168c-backend.scm",(void*)f_3168},
{"f_3000c-backend.scm",(void*)f_3000},
{"f_3003c-backend.scm",(void*)f_3003},
{"f_3161c-backend.scm",(void*)f_3161},
{"f_3142c-backend.scm",(void*)f_3142},
{"f_3153c-backend.scm",(void*)f_3153},
{"f_3006c-backend.scm",(void*)f_3006},
{"f_3093c-backend.scm",(void*)f_3093},
{"f_3096c-backend.scm",(void*)f_3096},
{"f_3099c-backend.scm",(void*)f_3099},
{"f_3102c-backend.scm",(void*)f_3102},
{"f_3118c-backend.scm",(void*)f_3118},
{"f_3121c-backend.scm",(void*)f_3121},
{"f_3124c-backend.scm",(void*)f_3124},
{"f_3127c-backend.scm",(void*)f_3127},
{"f_3009c-backend.scm",(void*)f_3009},
{"f_3012c-backend.scm",(void*)f_3012},
{"f_3015c-backend.scm",(void*)f_3015},
{"f_3065c-backend.scm",(void*)f_3065},
{"f_3068c-backend.scm",(void*)f_3068},
{"f_3018c-backend.scm",(void*)f_3018},
{"f_3021c-backend.scm",(void*)f_3021},
{"f_3053c-backend.scm",(void*)f_3053},
{"f_3056c-backend.scm",(void*)f_3056},
{"f_3027c-backend.scm",(void*)f_3027},
{"f_3036c-backend.scm",(void*)f_3036},
{"f_3039c-backend.scm",(void*)f_3039},
{"f_2948c-backend.scm",(void*)f_2948},
{"f_2953c-backend.scm",(void*)f_2953},
{"f_2957c-backend.scm",(void*)f_2957},
{"f_2967c-backend.scm",(void*)f_2967},
{"f_2960c-backend.scm",(void*)f_2960},
{"f_2792c-backend.scm",(void*)f_2792},
{"f_2799c-backend.scm",(void*)f_2799},
{"f_2935c-backend.scm",(void*)f_2935},
{"f_2802c-backend.scm",(void*)f_2802},
{"f_2805c-backend.scm",(void*)f_2805},
{"f_2808c-backend.scm",(void*)f_2808},
{"f_2813c-backend.scm",(void*)f_2813},
{"f_2823c-backend.scm",(void*)f_2823},
{"f_2829c-backend.scm",(void*)f_2829},
{"f_2882c-backend.scm",(void*)f_2882},
{"f_2892c-backend.scm",(void*)f_2892},
{"f_2832c-backend.scm",(void*)f_2832},
{"f_2855c-backend.scm",(void*)f_2855},
{"f_2865c-backend.scm",(void*)f_2865},
{"f_2835c-backend.scm",(void*)f_2835},
{"f_2838c-backend.scm",(void*)f_2838},
{"f_2626c-backend.scm",(void*)f_2626},
{"f_2784c-backend.scm",(void*)f_2784},
{"f_2646c-backend.scm",(void*)f_2646},
{"f_2652c-backend.scm",(void*)f_2652},
{"f_2729c-backend.scm",(void*)f_2729},
{"f_2733c-backend.scm",(void*)f_2733},
{"f_2737c-backend.scm",(void*)f_2737},
{"f_2741c-backend.scm",(void*)f_2741},
{"f_2763c-backend.scm",(void*)f_2763},
{"f_2759c-backend.scm",(void*)f_2759},
{"f_2751c-backend.scm",(void*)f_2751},
{"f_2749c-backend.scm",(void*)f_2749},
{"f_2745c-backend.scm",(void*)f_2745},
{"f_2670c-backend.scm",(void*)f_2670},
{"f_2673c-backend.scm",(void*)f_2673},
{"f_2676c-backend.scm",(void*)f_2676},
{"f_2718c-backend.scm",(void*)f_2718},
{"f_2679c-backend.scm",(void*)f_2679},
{"f_2682c-backend.scm",(void*)f_2682},
{"f_2685c-backend.scm",(void*)f_2685},
{"f_2700c-backend.scm",(void*)f_2700},
{"f_2705c-backend.scm",(void*)f_2705},
{"f_2688c-backend.scm",(void*)f_2688},
{"f_2629c-backend.scm",(void*)f_2629},
{"f_2643c-backend.scm",(void*)f_2643},
{"f_1199c-backend.scm",(void*)f_1199},
{"f_2594c-backend.scm",(void*)f_2594},
{"f_2600c-backend.scm",(void*)f_2600},
{"f_2604c-backend.scm",(void*)f_2604},
{"f_1202c-backend.scm",(void*)f_1202},
{"f_2559c-backend.scm",(void*)f_2559},
{"f_2562c-backend.scm",(void*)f_2562},
{"f_2565c-backend.scm",(void*)f_2565},
{"f_2568c-backend.scm",(void*)f_2568},
{"f_2571c-backend.scm",(void*)f_2571},
{"f_2574c-backend.scm",(void*)f_2574},
{"f_2476c-backend.scm",(void*)f_2476},
{"f_2479c-backend.scm",(void*)f_2479},
{"f_2482c-backend.scm",(void*)f_2482},
{"f_2495c-backend.scm",(void*)f_2495},
{"f_2518c-backend.scm",(void*)f_2518},
{"f_2521c-backend.scm",(void*)f_2521},
{"f_2524c-backend.scm",(void*)f_2524},
{"f_2527c-backend.scm",(void*)f_2527},
{"f_2505c-backend.scm",(void*)f_2505},
{"f_2508c-backend.scm",(void*)f_2508},
{"f_2467c-backend.scm",(void*)f_2467},
{"f_2439c-backend.scm",(void*)f_2439},
{"f_2442c-backend.scm",(void*)f_2442},
{"f_2459c-backend.scm",(void*)f_2459},
{"f_2445c-backend.scm",(void*)f_2445},
{"f_2448c-backend.scm",(void*)f_2448},
{"f_2423c-backend.scm",(void*)f_2423},
{"f_2427c-backend.scm",(void*)f_2427},
{"f_2409c-backend.scm",(void*)f_2409},
{"f_2412c-backend.scm",(void*)f_2412},
{"f_2393c-backend.scm",(void*)f_2393},
{"f_2397c-backend.scm",(void*)f_2397},
{"f_2375c-backend.scm",(void*)f_2375},
{"f_2378c-backend.scm",(void*)f_2378},
{"f_2355c-backend.scm",(void*)f_2355},
{"f_2319c-backend.scm",(void*)f_2319},
{"f_2331c-backend.scm",(void*)f_2331},
{"f_2322c-backend.scm",(void*)f_2322},
{"f_2300c-backend.scm",(void*)f_2300},
{"f_2303c-backend.scm",(void*)f_2303},
{"f_2281c-backend.scm",(void*)f_2281},
{"f_2284c-backend.scm",(void*)f_2284},
{"f_2262c-backend.scm",(void*)f_2262},
{"f_2265c-backend.scm",(void*)f_2265},
{"f_2243c-backend.scm",(void*)f_2243},
{"f_2239c-backend.scm",(void*)f_2239},
{"f_2187c-backend.scm",(void*)f_2187},
{"f_2220c-backend.scm",(void*)f_2220},
{"f_2190c-backend.scm",(void*)f_2190},
{"f_2208c-backend.scm",(void*)f_2208},
{"f_2193c-backend.scm",(void*)f_2193},
{"f_2196c-backend.scm",(void*)f_2196},
{"f_2154c-backend.scm",(void*)f_2154},
{"f_2138c-backend.scm",(void*)f_2138},
{"f_2141c-backend.scm",(void*)f_2141},
{"f_2144c-backend.scm",(void*)f_2144},
{"f_2097c-backend.scm",(void*)f_2097},
{"f_2100c-backend.scm",(void*)f_2100},
{"f_2121c-backend.scm",(void*)f_2121},
{"f_2125c-backend.scm",(void*)f_2125},
{"f_2128c-backend.scm",(void*)f_2128},
{"f_2103c-backend.scm",(void*)f_2103},
{"f_2119c-backend.scm",(void*)f_2119},
{"f_2111c-backend.scm",(void*)f_2111},
{"f_2106c-backend.scm",(void*)f_2106},
{"f_1843c-backend.scm",(void*)f_1843},
{"f_1846c-backend.scm",(void*)f_1846},
{"f_2047c-backend.scm",(void*)f_2047},
{"f_2043c-backend.scm",(void*)f_2043},
{"f_1852c-backend.scm",(void*)f_1852},
{"f_1197c-backend.scm",(void*)f_1197},
{"f_2036c-backend.scm",(void*)f_2036},
{"f_1187c-backend.scm",(void*)f_1187},
{"f_2029c-backend.scm",(void*)f_2029},
{"f_1858c-backend.scm",(void*)f_1858},
{"f_1982c-backend.scm",(void*)f_1982},
{"f_1985c-backend.scm",(void*)f_1985},
{"f_1988c-backend.scm",(void*)f_1988},
{"f_2003c-backend.scm",(void*)f_2003},
{"f_1991c-backend.scm",(void*)f_1991},
{"f_1994c-backend.scm",(void*)f_1994},
{"f_1997c-backend.scm",(void*)f_1997},
{"f_1979c-backend.scm",(void*)f_1979},
{"f_1889c-backend.scm",(void*)f_1889},
{"f_1963c-backend.scm",(void*)f_1963},
{"f_1966c-backend.scm",(void*)f_1966},
{"f_1939c-backend.scm",(void*)f_1939},
{"f_1942c-backend.scm",(void*)f_1942},
{"f_1945c-backend.scm",(void*)f_1945},
{"f_1948c-backend.scm",(void*)f_1948},
{"f_1951c-backend.scm",(void*)f_1951},
{"f_1892c-backend.scm",(void*)f_1892},
{"f_1895c-backend.scm",(void*)f_1895},
{"f_1922c-backend.scm",(void*)f_1922},
{"f_1926c-backend.scm",(void*)f_1926},
{"f_1929c-backend.scm",(void*)f_1929},
{"f_1898c-backend.scm",(void*)f_1898},
{"f_1920c-backend.scm",(void*)f_1920},
{"f_1912c-backend.scm",(void*)f_1912},
{"f_1901c-backend.scm",(void*)f_1901},
{"f_1904c-backend.scm",(void*)f_1904},
{"f_1870c-backend.scm",(void*)f_1870},
{"f_1873c-backend.scm",(void*)f_1873},
{"f_1800c-backend.scm",(void*)f_1800},
{"f_1803c-backend.scm",(void*)f_1803},
{"f_1787c-backend.scm",(void*)f_1787},
{"f_1790c-backend.scm",(void*)f_1790},
{"f_1753c-backend.scm",(void*)f_1753},
{"f_1756c-backend.scm",(void*)f_1756},
{"f_1725c-backend.scm",(void*)f_1725},
{"f_1721c-backend.scm",(void*)f_1721},
{"f_1679c-backend.scm",(void*)f_1679},
{"f_1647c-backend.scm",(void*)f_1647},
{"f_1650c-backend.scm",(void*)f_1650},
{"f_1612c-backend.scm",(void*)f_1612},
{"f_1638c-backend.scm",(void*)f_1638},
{"f_1624c-backend.scm",(void*)f_1624},
{"f_1628c-backend.scm",(void*)f_1628},
{"f_1631c-backend.scm",(void*)f_1631},
{"f_1615c-backend.scm",(void*)f_1615},
{"f_1580c-backend.scm",(void*)f_1580},
{"f_1583c-backend.scm",(void*)f_1583},
{"f_1586c-backend.scm",(void*)f_1586},
{"f_1589c-backend.scm",(void*)f_1589},
{"f_1551c-backend.scm",(void*)f_1551},
{"f_1554c-backend.scm",(void*)f_1554},
{"f_1557c-backend.scm",(void*)f_1557},
{"f_1560c-backend.scm",(void*)f_1560},
{"f_1514c-backend.scm",(void*)f_1514},
{"f_1517c-backend.scm",(void*)f_1517},
{"f_1520c-backend.scm",(void*)f_1520},
{"f_1523c-backend.scm",(void*)f_1523},
{"f_1481c-backend.scm",(void*)f_1481},
{"f_1484c-backend.scm",(void*)f_1484},
{"f_1487c-backend.scm",(void*)f_1487},
{"f_1490c-backend.scm",(void*)f_1490},
{"f_1462c-backend.scm",(void*)f_1462},
{"f_1465c-backend.scm",(void*)f_1465},
{"f_1435c-backend.scm",(void*)f_1435},
{"f_1438c-backend.scm",(void*)f_1438},
{"f_1384c-backend.scm",(void*)f_1384},
{"f_1394c-backend.scm",(void*)f_1394},
{"f_1397c-backend.scm",(void*)f_1397},
{"f_1400c-backend.scm",(void*)f_1400},
{"f_1326c-backend.scm",(void*)f_1326},
{"f_1329c-backend.scm",(void*)f_1329},
{"f_1332c-backend.scm",(void*)f_1332},
{"f_1335c-backend.scm",(void*)f_1335},
{"f_1338c-backend.scm",(void*)f_1338},
{"f_1341c-backend.scm",(void*)f_1341},
{"f_1157c-backend.scm",(void*)f_1157},
{"f_1169c-backend.scm",(void*)f_1169},
{"f_1177c-backend.scm",(void*)f_1177},
{"f_1161c-backend.scm",(void*)f_1161},
{"f_1134c-backend.scm",(void*)f_1134},
{"f_1148c-backend.scm",(void*)f_1148},
{"f_1140c-backend.scm",(void*)f_1140},
{"f_1113c-backend.scm",(void*)f_1113},
{"f_1119c-backend.scm",(void*)f_1119},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
