/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:57
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: csi.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -output-file csi.c -extend private-namespace.scm
   used units: library eval data_structures ports extras srfi_69 match srfi_69 ports
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[559];
static double C_possibly_force_alignment;


/* from k1503 */
static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8747)
static void C_ccall f_8747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8962)
static void C_ccall f_8962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8938)
static void C_ccall f_8938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8918)
static void C_ccall f_8918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8781)
static void C_fcall f_8781(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8794)
static void C_ccall f_8794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8906)
static void C_ccall f_8906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8797)
static void C_ccall f_8797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8828)
static void C_fcall f_8828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8808)
static void C_ccall f_8808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8779)
static void C_ccall f_8779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8672)
static void C_ccall f_8672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8678)
static void C_fcall f_8678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8603)
static void C_ccall f_8603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8518)
static void C_ccall f_8518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8522)
static void C_ccall f_8522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8590)
static void C_ccall f_8590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8534)
static void C_ccall f_8534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8558)
static void C_fcall f_8558(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8462)
static void C_fcall f_8462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8399)
static void C_ccall f_8399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8399)
static void C_ccall f_8399r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8403)
static void C_ccall f_8403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_fcall f_8430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8229)
static void C_ccall f_8229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8232)
static void C_ccall f_8232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_ccall f_8393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8235)
static void C_ccall f_8235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8387)
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8238)
static void C_ccall f_8238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8385)
static void C_ccall f_8385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_fcall f_8363(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8357)
static void C_ccall f_8357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8353)
static void C_ccall f_8353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_ccall f_8245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8291)
static void C_ccall f_8291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8281)
static void C_ccall f_8281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8166)
static void C_fcall f_8166(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8137)
static void C_ccall f_8137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8027)
static void C_ccall f_8027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8030)
static void C_ccall f_8030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8033)
static void C_ccall f_8033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_ccall f_8124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8036)
static void C_ccall f_8036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8118)
static void C_ccall f_8118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8039)
static void C_ccall f_8039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7996)
static void C_ccall f_7996(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7996)
static void C_ccall f_7996r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7956)
static void C_fcall f_7956(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7969)
static void C_ccall f_7969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7753)
static void C_ccall f_7753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_fcall f_7900(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7933)
static void C_ccall f_7933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7940)
static void C_ccall f_7940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_fcall f_7916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7765)
static void C_ccall f_7765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7894)
static void C_ccall f_7894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7774)
static void C_fcall f_7774(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7888)
static void C_ccall f_7888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_fcall f_7808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7862)
static void C_ccall f_7862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7819)
static void C_ccall f_7819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7754)
static void C_ccall f_7754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7694)
static void C_fcall f_7694(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7663)
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_fcall f_7627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7652)
static void C_ccall f_7652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_ccall f_7538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7532)
static void C_ccall f_7532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_fcall f_1242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_fcall f_1258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_fcall f_7337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_fcall f_7351(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7415)
static void C_ccall f_7415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7397)
static void C_ccall f_7397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7225)
static void C_ccall f_7225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7248)
static void C_fcall f_7248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7264)
static void C_ccall f_7264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7159)
static void C_fcall f_7159(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7157)
static void C_ccall f_7157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7126)
static void C_ccall f_7126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7072)
static void C_ccall f_7072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7075)
static void C_ccall f_7075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6871)
static void C_fcall f_6871(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_fcall f_6944(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_fcall f_7054(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7066)
static void C_ccall f_7066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_fcall f_6657(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6707)
static void C_ccall f_6707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6367)
static void C_fcall f_6367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6385)
static void C_ccall f_6385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_fcall f_6452(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6487)
static void C_fcall f_6487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6543)
static void C_ccall f_6543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6472)
static void C_ccall f_6472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6466)
static void C_ccall f_6466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6456)
static void C_ccall f_6456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6138)
static void C_ccall f_6138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6136)
static void C_ccall f_6136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_fcall f_6106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_fcall f_6073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_fcall f_5883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5909)
static void C_fcall f_5909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_fcall f_5937(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5676)
static void C_ccall f_5676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5682)
static void C_fcall f_5682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5539)
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5651)
static void C_ccall f_5651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5309)
static void C_fcall f_5309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5383)
static void C_fcall f_5383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5319)
static void C_fcall f_5319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5202)
static void C_fcall f_5202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5111)
static void C_fcall f_5111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_fcall f_4453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_fcall f_4459(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_fcall f_4620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_fcall f_4632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_fcall f_4666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_fcall f_4824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4850)
static void C_fcall f_4850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_fcall f_4550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_fcall f_4566(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4476)
static void C_fcall f_4476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_fcall f_4294(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4322)
static void C_fcall f_4322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static C_word C_fcall f_4411(C_word t0);
C_noret_decl(f_4237)
static void C_fcall f_4237(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4243)
static void C_fcall f_4243(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4255)
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_fcall f_4187(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4001)
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_fcall f_4086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_fcall f_4123(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_fcall f_3972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3921)
static void C_fcall f_3921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_fcall f_3916(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3810)
static void C_fcall f_3810(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_fcall f_3878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_fcall f_3638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_fcall f_3477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_fcall f_3382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_fcall f_3318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_fcall f_3062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_fcall f_3094(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_fcall f_2870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_fcall f_2388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2344)
static void C_fcall f_2344(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1817)
static void C_fcall f_1817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_fcall f_2634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_fcall f_1674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_fcall f_1618(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static C_word C_fcall f_1537(C_word t0,C_word t1);
C_noret_decl(f_1510)
static void C_fcall f_1510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static C_word C_fcall f_1448(C_word t0);
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1180)
static void C_ccall f_1180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8781)
static void C_fcall trf_8781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8781(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8781(t0,t1,t2,t3);}

C_noret_decl(trf_8828)
static void C_fcall trf_8828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8828(t0,t1);}

C_noret_decl(trf_8678)
static void C_fcall trf_8678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8678(t0,t1);}

C_noret_decl(trf_8558)
static void C_fcall trf_8558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8558(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8558(t0,t1,t2,t3);}

C_noret_decl(trf_8462)
static void C_fcall trf_8462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8462(t0,t1);}

C_noret_decl(trf_8430)
static void C_fcall trf_8430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8430(t0,t1);}

C_noret_decl(trf_8363)
static void C_fcall trf_8363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8363(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8363(t0,t1,t2);}

C_noret_decl(trf_8166)
static void C_fcall trf_8166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8166(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8166(t0,t1,t2);}

C_noret_decl(trf_7956)
static void C_fcall trf_7956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7956(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7956(t0,t1,t2,t3);}

C_noret_decl(trf_7900)
static void C_fcall trf_7900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7900(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7900(t0,t1,t2,t3);}

C_noret_decl(trf_7916)
static void C_fcall trf_7916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7916(t0,t1);}

C_noret_decl(trf_7774)
static void C_fcall trf_7774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7774(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7774(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7808)
static void C_fcall trf_7808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7808(t0,t1);}

C_noret_decl(trf_7694)
static void C_fcall trf_7694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7694(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7694(t0,t1,t2,t3);}

C_noret_decl(trf_7663)
static void C_fcall trf_7663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7663(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7663(t0,t1,t2,t3);}

C_noret_decl(trf_7627)
static void C_fcall trf_7627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7627(t0,t1,t2);}

C_noret_decl(trf_1242)
static void C_fcall trf_1242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1242(t0,t1);}

C_noret_decl(trf_1258)
static void C_fcall trf_1258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1258(t0,t1);}

C_noret_decl(trf_7337)
static void C_fcall trf_7337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7337(t0,t1);}

C_noret_decl(trf_7351)
static void C_fcall trf_7351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7351(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7351(t0,t1,t2);}

C_noret_decl(trf_7248)
static void C_fcall trf_7248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7248(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7248(t0,t1,t2);}

C_noret_decl(trf_7159)
static void C_fcall trf_7159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7159(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7159(t0,t1,t2);}

C_noret_decl(trf_6871)
static void C_fcall trf_6871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6871(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6871(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6944)
static void C_fcall trf_6944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6944(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6944(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7054)
static void C_fcall trf_7054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7054(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7054(t0,t1,t2);}

C_noret_decl(trf_6657)
static void C_fcall trf_6657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6657(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6657(t0,t1,t2,t3);}

C_noret_decl(trf_6367)
static void C_fcall trf_6367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6367(t0,t1,t2);}

C_noret_decl(trf_6452)
static void C_fcall trf_6452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6452(t0,t1);}

C_noret_decl(trf_6487)
static void C_fcall trf_6487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6487(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6487(t0,t1,t2,t3);}

C_noret_decl(trf_6106)
static void C_fcall trf_6106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6106(t0,t1);}

C_noret_decl(trf_6073)
static void C_fcall trf_6073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6073(t0,t1);}

C_noret_decl(trf_5883)
static void C_fcall trf_5883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5883(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5883(t0,t1,t2,t3);}

C_noret_decl(trf_5909)
static void C_fcall trf_5909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5909(t0,t1);}

C_noret_decl(trf_5937)
static void C_fcall trf_5937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5937(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5937(t0,t1);}

C_noret_decl(trf_5682)
static void C_fcall trf_5682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5682(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5682(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5539)
static void C_fcall trf_5539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5539(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5539(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5309)
static void C_fcall trf_5309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5309(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5309(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5383)
static void C_fcall trf_5383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5383(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5383(t0,t1);}

C_noret_decl(trf_5319)
static void C_fcall trf_5319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5319(t0,t1);}

C_noret_decl(trf_5202)
static void C_fcall trf_5202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5202(t0,t1);}

C_noret_decl(trf_5111)
static void C_fcall trf_5111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5111(t0,t1);}

C_noret_decl(trf_4453)
static void C_fcall trf_4453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4453(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4453(t0,t1);}

C_noret_decl(trf_4459)
static void C_fcall trf_4459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4459(t0,t1);}

C_noret_decl(trf_4620)
static void C_fcall trf_4620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4620(t0,t1);}

C_noret_decl(trf_4632)
static void C_fcall trf_4632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4632(t0,t1);}

C_noret_decl(trf_4666)
static void C_fcall trf_4666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4666(t0,t1,t2);}

C_noret_decl(trf_4824)
static void C_fcall trf_4824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4824(t0,t1);}

C_noret_decl(trf_4850)
static void C_fcall trf_4850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4850(t0,t1);}

C_noret_decl(trf_4550)
static void C_fcall trf_4550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4550(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4550(t0,t1,t2);}

C_noret_decl(trf_4566)
static void C_fcall trf_4566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4566(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4566(t0,t1,t2);}

C_noret_decl(trf_4470)
static void C_fcall trf_4470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4470(t0,t1,t2);}

C_noret_decl(trf_4476)
static void C_fcall trf_4476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4476(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4476(t0,t1,t2);}

C_noret_decl(trf_4294)
static void C_fcall trf_4294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4294(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4294(t0,t1);}

C_noret_decl(trf_4300)
static void C_fcall trf_4300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4300(t0,t1,t2);}

C_noret_decl(trf_4322)
static void C_fcall trf_4322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4322(t0,t1);}

C_noret_decl(trf_4237)
static void C_fcall trf_4237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4237(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4237(t0,t1,t2);}

C_noret_decl(trf_4243)
static void C_fcall trf_4243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4243(t0,t1,t2);}

C_noret_decl(trf_4255)
static void C_fcall trf_4255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4255(t0,t1,t2);}

C_noret_decl(trf_4187)
static void C_fcall trf_4187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4187(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4187(t0,t1,t2);}

C_noret_decl(trf_4001)
static void C_fcall trf_4001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4001(t0,t1,t2);}

C_noret_decl(trf_4086)
static void C_fcall trf_4086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4086(t0,t1,t2,t3);}

C_noret_decl(trf_4123)
static void C_fcall trf_4123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4123(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4123(t0,t1,t2);}

C_noret_decl(trf_4035)
static void C_fcall trf_4035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4035(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4035(t0,t1,t2,t3);}

C_noret_decl(trf_3972)
static void C_fcall trf_3972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3972(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3972(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3921)
static void C_fcall trf_3921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3921(t0,t1);}

C_noret_decl(trf_3916)
static void C_fcall trf_3916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3916(t0,t1,t2);}

C_noret_decl(trf_3810)
static void C_fcall trf_3810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3810(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3810(t0,t1,t2,t3);}

C_noret_decl(trf_3878)
static void C_fcall trf_3878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3878(t0,t1);}

C_noret_decl(trf_3813)
static void C_fcall trf_3813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3813(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3813(t0,t1,t2);}

C_noret_decl(trf_3638)
static void C_fcall trf_3638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3638(t0,t1,t2);}

C_noret_decl(trf_3477)
static void C_fcall trf_3477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3477(t0,t1);}

C_noret_decl(trf_3382)
static void C_fcall trf_3382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3382(t0,t1);}

C_noret_decl(trf_3318)
static void C_fcall trf_3318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3318(t0,t1);}

C_noret_decl(trf_3062)
static void C_fcall trf_3062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3062(t0,t1,t2);}

C_noret_decl(trf_3094)
static void C_fcall trf_3094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3094(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3094(t0,t1,t2,t3);}

C_noret_decl(trf_2870)
static void C_fcall trf_2870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2870(t0,t1);}

C_noret_decl(trf_2813)
static void C_fcall trf_2813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2813(t0,t1,t2,t3);}

C_noret_decl(trf_2388)
static void C_fcall trf_2388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2388(t0,t1,t2);}

C_noret_decl(trf_2344)
static void C_fcall trf_2344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2344(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2344(t0,t1,t2);}

C_noret_decl(trf_1817)
static void C_fcall trf_1817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1817(t0,t1);}

C_noret_decl(trf_2634)
static void C_fcall trf_2634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2634(t0,t1);}

C_noret_decl(trf_1674)
static void C_fcall trf_1674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1674(t0,t1);}

C_noret_decl(trf_1618)
static void C_fcall trf_1618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1618(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1618(t0,t1,t2);}

C_noret_decl(trf_1510)
static void C_fcall trf_1510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1510(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4678)){
C_save(t1);
C_rereclaim2(4678*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,559);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],3,"map");
lf[3]=C_h_intern(&lf[3],6,"lambda");
lf[4]=C_h_intern(&lf[4],14,"\004coreundefined");
lf[5]=C_h_intern(&lf[5],20,"\003syscall-with-values");
lf[6]=C_h_intern(&lf[6],9,"\004coreset!");
lf[7]=C_h_intern(&lf[7],6,"gensym");
lf[8]=C_h_intern(&lf[8],16,"\003syscheck-syntax");
lf[9]=C_h_intern(&lf[9],25,"set!-values/define-values");
lf[10]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000C\012CHICKEN\012(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[13]=C_h_intern(&lf[13],19,"\003sysundefined-value");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[16]=C_h_intern(&lf[16],27,"\003sysrepl-print-length-limit");
lf[17]=C_h_intern(&lf[17],4,"\000csi");
lf[18]=C_h_intern(&lf[18],12,"\003sysfeatures");
lf[19]=C_h_intern(&lf[19],15,"\003csiprint-usage");
lf[20]=C_h_intern(&lf[20],7,"display");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\002\042\047\012    -b  -batch                  terminate after command-line processing\012 "
"   -w  -no-warnings            disable all warnings\012    -k  -keyword-style STYLE"
"    enable alternative keyword-syntax (none, prefix or suffix)\012    -s  -script P"
"ATHNAME        use interpreter for shell scripts\012        -ss PATHNAME           "
" shell script with `main\047 procedure\012    -R  -require-extension NAME require exte"
"nsion before executing code\012    -I  -include-path PATHNAME  add PATHNAME to incl"
"ude path\012    --                          ignore all following options\012\012");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\002\257Usage: csi {FILENAME | OPTION}\012\012  where OPTION may be one of the following:"
"\012\012    -h  -help  --help           display this text and exit\012    -v  -version   "
"             display version and exit\012        -release                print rele"
"ase number and exit\012    -i  -case-insensitive       enable case-insensitive read"
"ing\012    -e  -eval EXPRESSION        evaluate given expression\012    -p  -print EXP"
"RESSION       evaluate and print result(s)\012    -P  -pretty-print EXPRESSION  eva"
"luate and print result(s) prettily\012    -D  -feature SYMBOL         register feat"
"ure identifier\012    -q  -quiet                  do not print banner\012    -n  -no-i"
"nit                do not load initialization file `");
lf[23]=C_h_intern(&lf[23],16,"\003csiprint-banner");
lf[24]=C_h_intern(&lf[24],5,"print");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[26]=C_h_intern(&lf[26],15,"chicken-version");
lf[27]=C_h_intern(&lf[27],9,"read-char");
lf[28]=C_h_intern(&lf[28],4,"read");
lf[29]=C_h_intern(&lf[29],18,"\003sysuser-read-hook");
lf[30]=C_h_intern(&lf[30],5,"quote");
lf[31]=C_h_intern(&lf[31],17,"\003csihistory-count");
lf[32]=C_h_intern(&lf[32],15,"\003csihistory-ref");
lf[33]=C_h_intern(&lf[33],21,"\003syssharp-number-hook");
lf[35]=C_h_intern(&lf[35],9,"substring");
lf[36]=C_h_intern(&lf[36],18,"\003csichop-separator");
lf[37]=C_h_intern(&lf[37],4,"sub1");
lf[38]=C_h_intern(&lf[38],1,"@");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],13,"string-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[42]=C_h_intern(&lf[42],22,"\003csilookup-script-file");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[44]=C_h_intern(&lf[44],25,"\003syspeek-nonnull-c-string");
lf[45]=C_h_intern(&lf[45],12,"string-split");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[48]=C_h_intern(&lf[48],6,"getenv");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[50]=C_h_intern(&lf[50],16,"\003csihistory-list");
lf[51]=C_h_intern(&lf[51],13,"vector-resize");
lf[52]=C_h_intern(&lf[52],15,"\003csihistory-add");
lf[53]=C_h_intern(&lf[53],9,"\003syserror");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[55]=C_h_intern(&lf[55],14,"\003csitty-input\077");
lf[56]=C_h_intern(&lf[56],13,"\003systty-port\077");
lf[57]=C_h_intern(&lf[57],18,"\003sysstandard-input");
lf[58]=C_h_intern(&lf[58],18,"\003sysbreak-on-error");
lf[59]=C_h_intern(&lf[59],20,"\003sysread-prompt-hook");
lf[61]=C_h_intern(&lf[61],15,"hash-table-set!");
lf[62]=C_h_intern(&lf[62],16,"toplevel-command");
lf[63]=C_h_intern(&lf[63],4,"eval");
lf[64]=C_h_intern(&lf[64],12,"load-noisily");
lf[65]=C_h_intern(&lf[65],10,"singlestep");
lf[66]=C_h_intern(&lf[66],14,"hash-table-ref");
lf[67]=C_h_intern(&lf[67],15,"hash-table-walk");
lf[68]=C_h_intern(&lf[68],9,"read-line");
lf[69]=C_h_intern(&lf[69],6,"length");
lf[70]=C_h_intern(&lf[70],5,"write");
lf[71]=C_h_intern(&lf[71],6,"printf");
lf[72]=C_h_intern(&lf[72],12,"pretty-print");
lf[73]=C_h_intern(&lf[73],8,"integer\077");
lf[74]=C_h_intern(&lf[74],6,"values");
lf[75]=C_h_intern(&lf[75],18,"\003sysrepl-eval-hook");
lf[76]=C_h_intern(&lf[76],22,"\003csitrace-indent-level");
lf[77]=C_h_intern(&lf[77],4,"exit");
lf[78]=C_h_intern(&lf[78],1,"x");
lf[79]=C_h_intern(&lf[79],11,"macroexpand");
lf[80]=C_h_intern(&lf[80],1,"p");
lf[81]=C_h_intern(&lf[81],1,"d");
lf[82]=C_h_intern(&lf[82],12,"\003csidescribe");
lf[83]=C_h_intern(&lf[83],2,"du");
lf[84]=C_h_intern(&lf[84],8,"\003csidump");
lf[85]=C_h_intern(&lf[85],3,"dur");
lf[86]=C_h_intern(&lf[86],1,"r");
lf[87]=C_h_intern(&lf[87],10,"\003csireport");
lf[88]=C_h_intern(&lf[88],1,"q");
lf[89]=C_h_intern(&lf[89],1,"l");
lf[90]=C_h_intern(&lf[90],12,"\003sysfor-each");
lf[91]=C_h_intern(&lf[91],4,"load");
lf[92]=C_h_intern(&lf[92],2,"ln");
lf[93]=C_h_intern(&lf[93],6,"print*");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[95]=C_h_intern(&lf[95],8,"\000printer");
lf[96]=C_h_intern(&lf[96],1,"t");
lf[97]=C_h_intern(&lf[97],17,"\003sysdisplay-times");
lf[98]=C_h_intern(&lf[98],14,"\003sysstop-timer");
lf[99]=C_h_intern(&lf[99],15,"\003sysstart-timer");
lf[100]=C_h_intern(&lf[100],2,"tr");
lf[102]=C_h_intern(&lf[102],8,"\003syswarn");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[106]=C_h_intern(&lf[106],25,"\003csitraced-procedure-exit");
lf[107]=C_h_intern(&lf[107],26,"\003csitraced-procedure-entry");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\033can not trace non-procedure");
lf[109]=C_h_intern(&lf[109],7,"\003sysmap");
lf[110]=C_h_intern(&lf[110],14,"string->symbol");
lf[111]=C_h_intern(&lf[111],3,"utr");
lf[112]=C_h_intern(&lf[112],7,"\003csidel");
lf[113]=C_h_intern(&lf[113],3,"eq\077");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[115]=C_h_intern(&lf[115],2,"br");
lf[116]=C_h_intern(&lf[116],1,"a");
lf[117]=C_h_intern(&lf[117],15,"\003sysbreak-entry");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\047can not set breakpoint on non-procedure");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[120]=C_h_intern(&lf[120],3,"ubr");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[122]=C_h_intern(&lf[122],3,"uba");
lf[123]=C_h_intern(&lf[123],14,"do-unbreak-all");
lf[124]=C_h_intern(&lf[124],8,"breakall");
lf[125]=C_h_intern(&lf[125],19,"\003sysbreak-in-thread");
lf[126]=C_h_intern(&lf[126],9,"breakonly");
lf[127]=C_h_intern(&lf[127],4,"info");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[129]=C_h_intern(&lf[129],3,"car");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[131]=C_h_intern(&lf[131],1,"c");
lf[132]=C_h_intern(&lf[132],19,"\003syslast-breakpoint");
lf[133]=C_h_intern(&lf[133],16,"\003sysbreak-resume");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[135]=C_h_intern(&lf[135],3,"exn");
lf[136]=C_h_intern(&lf[136],18,"\003syslast-exception");
lf[137]=C_h_intern(&lf[137],4,"step");
lf[138]=C_h_intern(&lf[138],1,"s");
lf[139]=C_h_intern(&lf[139],6,"system");
lf[140]=C_h_intern(&lf[140],1,"\077");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\004TToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print macroexpanded expression EXP\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[144]=C_h_intern(&lf[144],22,"hash-table-ref/default");
lf[145]=C_h_intern(&lf[145],7,"unquote");
lf[146]=C_h_intern(&lf[146],16,"\003csitrace-indent");
lf[147]=C_h_intern(&lf[147],19,"\003syswrite-char/port");
lf[148]=C_h_intern(&lf[148],19,"\003sysstandard-output");
lf[149]=C_h_intern(&lf[149],12,"flush-output");
lf[150]=C_h_intern(&lf[150],16,"\003syswrite-char-0");
lf[151]=C_h_intern(&lf[151],4,"add1");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[153]=C_h_intern(&lf[153],23,"\003csiparse-option-string");
lf[154]=C_h_intern(&lf[154],17,"get-output-string");
lf[155]=C_h_intern(&lf[155],18,"open-output-string");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[157]=C_h_intern(&lf[157],7,"reverse");
lf[158]=C_h_intern(&lf[158],22,"with-exception-handler");
lf[159]=C_h_intern(&lf[159],30,"call-with-current-continuation");
lf[160]=C_h_intern(&lf[160],17,"open-input-string");
lf[161]=C_h_intern(&lf[161],4,"chop");
lf[162]=C_h_intern(&lf[162],4,"sort");
lf[163]=C_h_intern(&lf[163],19,"with-output-to-port");
lf[164]=C_h_intern(&lf[164],19,"current-output-port");
lf[165]=C_h_intern(&lf[165],8,"truncate");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\001\374~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbols:\011~S~%~\012                   Memory:\011heap size "
"is ~S bytes~A with ~S bytes currently in use~%~  \012                     nursery s"
"ize is ~S bytes, stack grows ~A~%");
lf[175]=C_h_intern(&lf[175],21,"\003sysinclude-pathnames");
lf[176]=C_h_intern(&lf[176],14,"build-platform");
lf[177]=C_h_intern(&lf[177],16,"software-version");
lf[178]=C_h_intern(&lf[178],13,"software-type");
lf[179]=C_h_intern(&lf[179],12,"machine-type");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[181]=C_h_intern(&lf[181],11,"make-string");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[183]=C_h_intern(&lf[183],8,"string<\077");
lf[184]=C_h_intern(&lf[184],15,"keyword->string");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[186]=C_h_intern(&lf[186],17,"memory-statistics");
lf[187]=C_h_intern(&lf[187],21,"\003syssymbol-table-info");
lf[188]=C_h_intern(&lf[188],2,"gc");
lf[189]=C_h_intern(&lf[189],19,"\003csibytevector-data");
lf[190]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[192]=C_h_intern(&lf[192],7,"sprintf");
lf[193]=C_h_intern(&lf[193],7,"fprintf");
lf[194]=C_h_intern(&lf[194],8,"list-ref");
lf[195]=C_h_intern(&lf[195],10,"string-ref");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[200]=C_h_intern(&lf[200],7,"newline");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[211]=C_h_intern(&lf[211],28,"\003sysarbitrary-unbound-symbol");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[215]=C_h_intern(&lf[215],8,"\003syssize");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[217]=C_h_intern(&lf[217],8,"\003sysslot");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol with name ~S~%");
lf[219]=C_h_intern(&lf[219],18,"\003syssymbol->string");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[222]=C_h_intern(&lf[222],32,"\003syssymbol-has-toplevel-binding\077");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[225]=C_h_intern(&lf[225],15,"describe-object");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[227]=C_h_intern(&lf[227],25,"\003syspeek-unsigned-integer");
lf[228]=C_h_intern(&lf[228],9,"\000tinyclos");
lf[229]=C_h_intern(&lf[229],19,"\010tinyclosentity-tag");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[245]=C_h_intern(&lf[245],11,"\003csihexdump");
lf[246]=C_h_intern(&lf[246],8,"\003sysbyte");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[249]=C_h_intern(&lf[249],23,"\003syslambda-info->string");
lf[250]=C_h_intern(&lf[250],10,"hash-table");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[256]=C_h_intern(&lf[256],9,"condition");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[258]=C_h_intern(&lf[258],4,"cdar");
lf[259]=C_h_intern(&lf[259],4,"caar");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[262]=C_h_intern(&lf[262],6,"unveil");
lf[263]=C_h_intern(&lf[263],6,"append");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[266]=C_h_intern(&lf[266],15,"meroon-instance");
lf[267]=C_h_intern(&lf[267],9,"provided\077");
lf[268]=C_h_intern(&lf[268],6,"meroon");
lf[269]=C_h_intern(&lf[269],15,"\003sysbytevector\077");
lf[270]=C_h_intern(&lf[270],13,"\003syslocative\077");
lf[271]=C_h_intern(&lf[271],9,"instance\077");
lf[272]=C_h_intern(&lf[272],5,"port\077");
lf[273]=C_h_intern(&lf[273],11,"\003sysnumber\077");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[275]=C_h_intern(&lf[275],17,"\003sysblock-address");
lf[276]=C_h_intern(&lf[276],14,"set-describer!");
lf[277]=C_h_intern(&lf[277],3,"min");
lf[278]=C_h_intern(&lf[278],4,"dump");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\035can not dump immediate object");
lf[280]=C_h_intern(&lf[280],13,"\003syspeek-byte");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\023can not dump object");
lf[282]=C_h_intern(&lf[282],10,"write-char");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[284]=C_h_intern(&lf[284],5,"fxmod");
lf[285]=C_h_intern(&lf[285],11,"\003csideldups");
lf[286]=C_h_intern(&lf[286],6,"equal\077");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000D\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000i\376\003\000"
"\000\002\376\377\012\000\000R\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000q\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000-\376\003\000\000\002\376\377\012\000\000I\376\003\000\000\002\376"
"\377\012\000\000p\376\003\000\000\002\376\377\012\000\000P\376\377\016");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376"
"B\000\000\006--help\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensiti"
"ve\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000"
"\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\377\016");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[298]=C_h_intern(&lf[298],16,"\003sysstring->list");
lf[299]=C_h_intern(&lf[299],7,"\003csirun");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[301]=C_h_intern(&lf[301],8,"\003syslist");
lf[302]=C_h_intern(&lf[302],6,"\000match");
lf[303]=C_h_intern(&lf[303],4,"repl");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\002-"
"s\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000\000\003-ss\376\377\016");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[313]=C_h_intern(&lf[313],22,"\004corerequire-extension");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[318]=C_h_intern(&lf[318],8,"for-each");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[321]=C_h_intern(&lf[321],4,"main");
lf[322]=C_h_intern(&lf[322],22,"command-line-arguments");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[327]=C_h_intern(&lf[327],17,"\003sysstring-append");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[329]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[331]=C_h_intern(&lf[331],13,"keyword-style");
lf[332]=C_h_intern(&lf[332],7,"\000prefix");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[334]=C_h_intern(&lf[334],5,"\000none");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[336]=C_h_intern(&lf[336],7,"\000suffix");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[338]=C_h_intern(&lf[338],7,"provide");
lf[339]=C_h_intern(&lf[339],5,"match");
lf[340]=C_h_intern(&lf[340],8,"string=\077");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[343]=C_h_intern(&lf[343],17,"register-feature!");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[346]=C_h_intern(&lf[346],14,"case-sensitive");
lf[347]=C_h_intern(&lf[347],16,"case-insensitive");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[350]=C_h_intern(&lf[350],12,"load-verbose");
lf[351]=C_h_intern(&lf[351],20,"\003syswarnings-enabled");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[357]=C_h_intern(&lf[357],20,"\003syseval-debug-level");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[364]=C_h_intern(&lf[364],20,"\003syswindows-platform");
lf[365]=C_h_intern(&lf[365],6,"script");
lf[366]=C_h_intern(&lf[366],12,"program-name");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[373]=C_h_intern(&lf[373],25,"\003sysimplicit-exit-handler");
lf[374]=C_h_intern(&lf[374],15,"make-hash-table");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[376]=C_h_intern(&lf[376],11,"repl-prompt");
lf[377]=C_h_intern(&lf[377],6,"srfi-8");
lf[378]=C_h_intern(&lf[378],7,"srfi-16");
lf[379]=C_h_intern(&lf[379],7,"srfi-26");
lf[380]=C_h_intern(&lf[380],7,"srfi-31");
lf[381]=C_h_intern(&lf[381],7,"srfi-15");
lf[382]=C_h_intern(&lf[382],7,"srfi-11");
lf[383]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[384]=C_h_intern(&lf[384],25,"\003sysenable-runtime-macros");
lf[385]=C_h_intern(&lf[385],6,"define");
lf[386]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[387]=C_h_intern(&lf[387],12,"syntax-error");
lf[388]=C_h_intern(&lf[388],17,"define-for-syntax");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[390]=C_h_intern(&lf[390],18,"\003sysregister-macro");
lf[391]=C_h_intern(&lf[391],6,"letrec");
lf[392]=C_h_intern(&lf[392],3,"rec");
lf[393]=C_h_intern(&lf[393],22,"chicken-compile-shared");
lf[394]=C_h_intern(&lf[394],3,"not");
lf[395]=C_h_intern(&lf[395],9,"compiling");
lf[396]=C_h_intern(&lf[396],4,"unit");
lf[397]=C_h_intern(&lf[397],7,"declare");
lf[398]=C_h_intern(&lf[398],4,"else");
lf[399]=C_h_intern(&lf[399],11,"cond-expand");
lf[400]=C_h_intern(&lf[400],6,"export");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[402]=C_h_intern(&lf[402],6,"static");
lf[403]=C_h_intern(&lf[403],5,"begin");
lf[404]=C_h_intern(&lf[404],7,"dynamic");
lf[405]=C_h_intern(&lf[405],16,"define-extension");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[408]=C_h_intern(&lf[408],22,"string-parse-start+end");
lf[409]=C_h_intern(&lf[409],7,"receive");
lf[410]=C_h_intern(&lf[410],28,"string-parse-final-start+end");
lf[411]=C_h_intern(&lf[411],20,"let-string-start+end");
lf[412]=C_h_intern(&lf[412],5,"apply");
lf[413]=C_h_intern(&lf[413],3,"let");
lf[414]=C_h_intern(&lf[414],10,"\003sysappend");
lf[415]=C_h_intern(&lf[415],2,"<>");
lf[416]=C_h_intern(&lf[416],5,"<...>");
lf[417]=C_h_intern(&lf[417],20,"\003sysregister-macro-2");
lf[418]=C_h_intern(&lf[418],4,"cute");
lf[419]=C_h_intern(&lf[419],3,"cut");
lf[420]=C_h_intern(&lf[420],3,"use");
lf[421]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[422]=C_h_intern(&lf[422],17,"require-extension");
lf[423]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[424]=C_h_intern(&lf[424],23,"\004corerequire-for-syntax");
lf[425]=C_h_intern(&lf[425],18,"require-for-syntax");
lf[426]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[427]=C_h_intern(&lf[427],18,"\003sysmake-structure");
lf[428]=C_h_intern(&lf[428],14,"\003sysstructure\077");
lf[429]=C_h_intern(&lf[429],15,"\000record-setters");
lf[430]=C_h_intern(&lf[430],19,"\003syscheck-structure");
lf[431]=C_h_intern(&lf[431],10,"\004corecheck");
lf[432]=C_h_intern(&lf[432],13,"\003sysblock-ref");
lf[433]=C_h_intern(&lf[433],18,"getter-with-setter");
lf[434]=C_h_intern(&lf[434],1,"y");
lf[435]=C_h_intern(&lf[435],14,"\003sysblock-set!");
lf[436]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[437]=C_h_intern(&lf[437],18,"define-record-type");
lf[438]=C_h_intern(&lf[438],3,"and");
lf[439]=C_h_intern(&lf[439],4,"memv");
lf[440]=C_h_intern(&lf[440],4,"cond");
lf[441]=C_h_intern(&lf[441],17,"handle-exceptions");
lf[442]=C_h_intern(&lf[442],10,"\003syssignal");
lf[443]=C_h_intern(&lf[443],14,"condition-case");
lf[444]=C_h_intern(&lf[444],9,"\003sysapply");
lf[445]=C_h_intern(&lf[445],10,"\003sysvalues");
lf[446]=C_h_intern(&lf[446],27,"\003sysregister-record-printer");
lf[447]=C_h_intern(&lf[447],21,"define-record-printer");
lf[448]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[449]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[450]=C_h_intern(&lf[450],2,"if");
lf[451]=C_h_intern(&lf[451],9,"split-at!");
lf[452]=C_h_intern(&lf[452],4,"take");
lf[453]=C_h_intern(&lf[453],4,"list");
lf[454]=C_h_intern(&lf[454],3,"cdr");
lf[455]=C_h_intern(&lf[455],4,"fx>=");
lf[456]=C_h_intern(&lf[456],3,"fx=");
lf[457]=C_h_intern(&lf[457],11,"case-lambda");
lf[458]=C_h_intern(&lf[458],11,"lambda-list");
lf[459]=C_h_intern(&lf[459],25,"\003sysdecompose-lambda-list");
lf[460]=C_h_intern(&lf[460],10,"fold-right");
lf[461]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[462]=C_h_intern(&lf[462],7,"require");
lf[463]=C_h_intern(&lf[463],6,"srfi-1");
lf[464]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[465]=C_h_intern(&lf[465],5,"null\077");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[467]=C_h_intern(&lf[467],14,"\004coreimmutable");
lf[468]=C_h_intern(&lf[468],14,"let-optionals*");
lf[469]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[470]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[471]=C_h_intern(&lf[471],8,"optional");
lf[472]=C_h_intern(&lf[472],9,":optional");
lf[473]=C_h_intern(&lf[473],14,"symbol->string");
lf[474]=C_h_intern(&lf[474],4,"let*");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[477]=C_h_intern(&lf[477],5,"%rest");
lf[478]=C_h_intern(&lf[478],4,"body");
lf[479]=C_h_intern(&lf[479],4,"cadr");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[481]=C_h_intern(&lf[481],13,"let-optionals");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[483]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[484]=C_h_intern(&lf[484],4,"eqv\077");
lf[485]=C_h_intern(&lf[485],6,"switch");
lf[486]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[487]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[488]=C_h_intern(&lf[488],2,"or");
lf[489]=C_h_intern(&lf[489],6,"select");
lf[490]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[491]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[492]=C_h_intern(&lf[492],21,"\003syssyntax-error-hook");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[494]=C_h_intern(&lf[494],8,"and-let*");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[496]=C_h_intern(&lf[496],20,"\004coredefine-constant");
lf[497]=C_h_intern(&lf[497],15,"define-constant");
lf[498]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[499]=C_h_intern(&lf[499],18,"\004coredefine-inline");
lf[500]=C_h_intern(&lf[500],13,"define-inline");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[502]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[503]=C_h_intern(&lf[503],9,"nth-value");
lf[504]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[505]=C_h_intern(&lf[505],13,"letrec-values");
lf[506]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[507]=C_h_intern(&lf[507],10,"let-values");
lf[508]=C_h_intern(&lf[508],11,"let*-values");
lf[509]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[510]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[511]=C_h_intern(&lf[511],13,"define-values");
lf[512]=C_h_intern(&lf[512],11,"set!-values");
lf[513]=C_h_intern(&lf[513],6,"unless");
lf[514]=C_h_intern(&lf[514],4,"when");
lf[515]=C_h_intern(&lf[515],16,"\003sysdynamic-wind");
lf[516]=C_h_intern(&lf[516],12,"parameterize");
lf[517]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[518]=C_h_intern(&lf[518],10,"\000compiling");
lf[519]=C_h_intern(&lf[519],19,"\004corecompiletimetoo");
lf[520]=C_h_intern(&lf[520],20,"\004corecompiletimeonly");
lf[521]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[522]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[523]=C_h_intern(&lf[523],8,"run-time");
lf[524]=C_h_intern(&lf[524],7,"compile");
lf[525]=C_h_intern(&lf[525],12,"compile-time");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[527]=C_h_intern(&lf[527],9,"eval-when");
lf[528]=C_h_intern(&lf[528],8,"\003sysvoid");
lf[529]=C_h_intern(&lf[529],9,"fluid-let");
lf[530]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[531]=C_h_intern(&lf[531],11,"\000type-error");
lf[532]=C_h_intern(&lf[532],15,"\003syssignal-hook");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[534]=C_h_intern(&lf[534],6,"ensure");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[536]=C_h_intern(&lf[536],6,"assert");
lf[537]=C_h_intern(&lf[537],20,"with-input-from-file");
lf[538]=C_h_intern(&lf[538],27,"\003syscurrent-source-filename");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[541]=C_h_intern(&lf[541],28,"\003sysresolve-include-filename");
lf[542]=C_h_intern(&lf[542],7,"include");
lf[543]=C_h_intern(&lf[543],12,"\004coredeclare");
lf[544]=C_h_intern(&lf[544],4,"time");
lf[545]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[546]=C_h_intern(&lf[546],3,"val");
lf[547]=C_h_intern(&lf[547],28,"\003sysstring->qualified-symbol");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[553]=C_h_intern(&lf[553],27,"\003sysqualified-symbol-prefix");
lf[554]=C_h_intern(&lf[554],13,"define-record");
lf[555]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[556]=C_h_intern(&lf[556],6,"symbol");
lf[557]=C_h_intern(&lf[557],11,"\003sysprovide");
lf[558]=C_h_intern(&lf[558],19,"chicken-more-macros");
C_register_lf2(lf,559,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1073 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1076 in k1073 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1079 in k1076 in k1073 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#provide */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[558]);}

/* k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[473]+1);
t4=*((C_word*)lf[110]+1);
t5=*((C_word*)lf[40]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8740,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[554],t6);}

/* a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8740(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8740r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8740r(t0,t1,t2,t3);}}

static void C_ccall f_8740r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[554],t2,lf[556]);}

/* k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[554],((C_word*)t0)[5],lf[555]);}

/* k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8750,2,t0,t1);}
t2=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8756,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8962,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[552],((C_word*)t0)[3]);}

/* k8960 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[427],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8918,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8938,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[551]);}

/* k8936 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8918,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[78]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8779,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_8781(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8781(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8781,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k8789 in mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8794,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8910,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[549],t1,lf[550]);}

/* k8908 in k8789 in mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8792 in k8789 in mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8797,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8906,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[548],((C_word*)t0)[2]);}

/* k8904 in k8792 in k8789 in mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8795 in k8792 in k8789 in mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8797,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[78],lf[546]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t3);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_list(&a,4,lf[435],lf[78],((C_word*)t0)[7],lf[546]);
t7=(C_word)C_a_i_list(&a,4,lf[3],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14);
t16=t9;
f_8828(t16,(C_word)C_a_i_list(&a,3,lf[433],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=t9;
f_8828(t15,(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14));}}

/* k8826 in k8795 in k8792 in k8789 in mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8828,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[403],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8808,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8781(t7,t4,t5,t6);}

/* k8806 in k8826 in k8795 in k8792 in k8789 in mapslots in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8808,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8777 in k8916 in k8940 in k8754 in k8748 in k8745 in k8742 in a8739 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8779,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8652,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[409],t3);}

/* a8651 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_8652r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8652r(t0,t1,t2,t3);}}

static void C_ccall f_8652r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t4,lf[301]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8669,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[409],t2,lf[458]);}}

/* k8667 in a8651 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[409],((C_word*)t0)[3],lf[545]);}

/* k8670 in k8667 in a8651 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_8678(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_8678(t3,C_SCHEME_FALSE);}}

/* k8676 in k8670 in k8667 in a8651 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8678,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[5],t3,t6));}}

/* k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8611,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[544],t4);}

/* a8610 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8611(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8611r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8611r(t0,t1,t2);}}

static void C_ccall f_8611r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8615,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[96]);}

/* k8613 in a8610 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8615,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[99]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,1,lf[98]);
t6=(C_word)C_a_i_list(&a,2,lf[97],t5);
t7=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t8=(C_word)C_a_i_list(&a,4,lf[3],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[5],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[403],t2,t9));}

/* k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8595,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[397],t3);}

/* a8594 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_8595r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8595r(t0,t1,t2);}}

static void C_ccall f_8595r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8603,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8605,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8604 in a8594 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8605,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k8601 in a8594 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8603,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[543],t1));}

/* k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[537]);
t4=*((C_word*)lf[28]+1);
t5=*((C_word*)lf[157]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8518,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[542],t6);}

/* a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8518,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#resolve-include-filename */
t4=C_retrieve(lf[541]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8590,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   load-verbose */
t4=C_retrieve(lf[350]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8588 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[539],((C_word*)t0)[2],lf[540]);}
else{
t2=((C_word*)t0)[3];
f_8525(2,t2,C_SCHEME_UNDEFINED);}}

/* k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8532,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a8533 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8534,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8540,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8581,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[515]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8580 in a8533 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8581,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* a8547 in a8533 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8556,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8554 in a8547 in a8533 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8556,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8558,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8558(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do38 in k8554 in a8547 in a8533 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8558(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8558,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 44   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8575,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8573 in do38 in k8554 in a8547 in a8533 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8575,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8558(t3,((C_word*)t0)[2],t1,t2);}

/* a8539 in a8533 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8540,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* k8530 in k8523 in k8520 in a8517 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8532,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[403],t1));}

/* k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8458,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[536],t3);}

/* a8457 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8458(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_8458r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8458r(t0,t1,t2,t3);}}

static void C_ccall f_8458r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8462,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[30],lf[535]);
t7=t4;
f_8462(t7,(C_word)C_a_i_list(&a,2,lf[467],t6));}
else{
t6=t4;
f_8462(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k8460 in a8457 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8462,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[431],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[53],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t2,t3,t10));}

/* k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8399,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[534],t3);}

/* a8398 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_8399r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8399r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8399r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8403,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k8401 in a8398 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8403,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8430,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_8430(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[30],lf[533]);
t8=(C_word)C_a_i_list(&a,2,lf[467],t7);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t10=t6;
f_8430(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k8428 in k8401 in a8398 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8430,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[531],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[532],t2);
t4=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8225,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[529],t4);}

/* a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_8225r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8225r(t0,t1,t2,t3);}}

static void C_ccall f_8225r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8229,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[529],t2,lf[530]);}

/* k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[3]);}

/* k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8392 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8393,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8238,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8386 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8387,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8245,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8385,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k8383 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8347 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8353,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8357,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8363,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_8363(t8,t3,t4);}

/* loop in k8347 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8363(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8363,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8377,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* csi.scm: 44   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8375 in loop in k8347 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8377,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8355 in k8347 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8351 in k8347 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8341,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a8340 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8341,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8315 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8321,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8335,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8334 in k8315 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8335,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8323 in k8315 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8325,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8319 in k8315 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8311 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8313,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[3],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8269,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8297,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t9=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8296 in k8311 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8297,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8271 in k8311 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8277,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8281,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8291,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8290 in k8271 in k8311 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8291,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8279 in k8271 in k8311 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8281,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8275 in k8271 in k8311 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8267 in k8311 in k8243 in k8236 in k8233 in k8230 in k8227 in a8224 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8269,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8130,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[527],t3);}

/* a8129 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_8130r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8130r(t0,t1,t2,t3);}}

static void C_ccall f_8130r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8137,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8166,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8166(t15,t11,t2);}

/* loop in a8129 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_8166(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8166,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8179,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[63]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_8179(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[91]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[523]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_8179(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[524]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[525]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_8179(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[526],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8177 in loop in a8129 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8166(t3,((C_word*)t0)[2],t2);}

/* k8135 in a8129 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8137,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[518],C_retrieve(lf[18])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[519],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[520],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[521]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[522]));}}

/* k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[129]+1);
t4=*((C_word*)lf[479]+1);
t5=*((C_word*)lf[2]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8020,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[516],t6);}

/* a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8020r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8020r(t0,t1,t2,t3);}}

static void C_ccall f_8020r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8024,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[516],t2,lf[517]);}

/* k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8033,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8036,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8124,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8123 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8124,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8118,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8117 in k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8118,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8037 in k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8046,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8112,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[301]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k8110 in k8037 in k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8116,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[301]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8114 in k8110 in k8037 in k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8044 in k8037 in k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8082,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8084,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8083 in k8044 in k8037 in k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8084,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[96],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[6],t3,lf[96]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[413],t6,t7,t8));}

/* k8080 in k8044 in k8037 in k8034 in k8031 in k8028 in k8025 in k8022 in a8019 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[413],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t9));}

/* k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8010,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[514],t3);}

/* a8009 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_8010r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8010r(t0,t1,t2,t3);}}

static void C_ccall f_8010r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[450],t2,t4));}

/* k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7996,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[513],t3);}

/* a7995 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7996(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_7996r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7996r(t0,t1,t2,t3);}}

static void C_ccall f_7996r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],t2,t4,t5));}

/* k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1139,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[512],t3);}

/* k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t3=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7663,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7694,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7734,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t10=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[507],t9);}

/* a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7734,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[507],t2,lf[510]);}

/* k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[129]+1),t2);}

/* k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7956(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7956(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7956,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7969,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* csi.scm: 44   append */
t6=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* csi.scm: 44   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7663(t6,t5,t4,t3);}
else{
t6=t5;
f_7969(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7967 in loop in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7956(t3,((C_word*)t0)[2],t2,t1);}

/* k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7946,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7945 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7946,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7954,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7952 in a7945 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7754,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7900,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7900(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7900(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7900,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7916,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7940,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7694(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7933,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t7=((C_word*)t0)[2];
f_7754(3,t7,t6,t4);}}}

/* k7931 in loop in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7933,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7916(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7938 in loop in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7940,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7916(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7914 in loop in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7900(t3,((C_word*)t0)[2],t2,t1);}

/* k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7772,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7894,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7893 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7894,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7772,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7774,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7774(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7774(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7774,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7792,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7794,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7808,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7888,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   cdar */
t8=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7808(t7,C_SCHEME_FALSE);}}}

/* k7886 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7808(t2,(C_word)C_i_nullp(t1));}

/* k7806 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7808,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7862,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7774(t9,t5,t6,t7,t8);}}

/* k7860 in k7806 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7862,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t2));}

/* k7837 in k7806 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7839,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7819,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7774(t9,t5,t6,t7,t8);}

/* k7817 in k7837 in k7806 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7819,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* a7793 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7802,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7754(3,t4,t3,t2);}

/* k7800 in a7793 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7790 in fold in k7770 in k7763 in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7792,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7751 in k7748 in k7745 in k7736 in a7661 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7754,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7694(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7694,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7717,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* csi.scm: 44   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* csi.scm: 44   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7715 in map* in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7721,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7694(t4,t2,((C_word*)t0)[2],t3);}

/* k7719 in k7715 in map* in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7721,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7663,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7684,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7682 in append* in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7684,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7612,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[508],t3);}

/* a7611 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7612,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7616,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[508],t2,lf[509]);}

/* k7614 in a7611 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7616,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7627,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7627(t7,((C_word*)t0)[2],t2);}

/* fold in k7614 in a7611 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7627,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[413],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7652,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7650 in fold in k7614 in a7611 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7652,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[507],((C_word*)t0)[2],t1));}

/* k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7492,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[505],t3);}

/* a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7492,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7496,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[505],t2,lf[506]);}

/* k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7496,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7505,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7604,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7606,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7605 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7606,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7602 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[414]+1),t1);}

/* k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7508,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7592,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7591 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7592,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7600,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7598 in a7591 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7509,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7586,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7585 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7586,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[504]));}

/* k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7532,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7536,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7538,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7537 in k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7538,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7558,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k7556 in a7537 in k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7562,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7563 in k7556 in a7537 in k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7564,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7572,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7509(3,t4,t3,t2);}

/* k7570 in a7563 in k7556 in a7537 in k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7572,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[6],((C_word*)t0)[2],t1));}

/* k7560 in k7556 in a7537 in k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7562,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

/* k7534 in k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7530 in k7526 in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7532,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7506 in k7503 in k7494 in a7491 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7509,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7471,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[503],t3);}

/* a7470 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7471,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7475,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7473 in a7470 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7475,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[194],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[3],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}

/* k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7461,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[500],t3);}

/* a7460 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7461,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[500],t2,lf[502]);}

/* k1231 in a7460 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_1242(t9,(C_word)C_a_i_cons(&a,2,lf[3],t8));}
else{
t6=t5;
f_1242(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k1240 in k1231 in a7460 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_1242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1258(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[3],t6);
t8=t5;
f_1258(t8,(C_word)C_i_not(t7));}}

/* k1256 in k1240 in k1231 in a7460 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_1258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[500],lf[501],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1245(2,t2,C_SCHEME_UNDEFINED);}}

/* k1243 in k1240 in k1231 in a7460 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[499],t3));}

/* k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7440,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[497],t3);}

/* a7439 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7444,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[497],t2,lf[498]);}

/* k7442 in a7439 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7444,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[496],t3,t4));}

/* k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7324,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[494],t3);}

/* a7323 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7324,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7328,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[494],t2,lf[495]);}

/* k7326 in a7323 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7328,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7337,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_7337(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_7337(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k7335 in k7326 in a7323 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7337,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 44   ##sys#syntax-error-hook */
t2=C_retrieve(lf[492]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[493],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7351,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7351(t7,((C_word*)t0)[3],t2);}}

/* fold in k7335 in k7326 in a7323 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7351(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7351,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[403],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7380,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7397,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7415,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k7413 in fold in k7335 in k7326 in a7323 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7415,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t2));}

/* k7395 in fold in k7335 in k7326 in a7323 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7397,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k7378 in fold in k7335 in k7326 in a7323 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7380,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7225,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[489],t4);}

/* a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7225,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7235,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7233 in a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7235,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7246,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7248,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7248(t8,t4,((C_word*)t0)[2]);}

/* expand in k7233 in a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7248,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7264,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[489],t3,lf[490]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[491]);}}

/* k7262 in expand in k7233 in a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7264,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7301 in k7262 in expand in k7233 in a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7302,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[2],t2));}

/* k7298 in k7262 in expand in k7233 in a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7300,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[488],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7292,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7248(t6,t5,((C_word*)t0)[2]);}

/* k7290 in k7298 in k7262 in expand in k7233 in a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7244 in k7233 in a7224 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7246,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7136,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[485],t4);}

/* a7135 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7136,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7146,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7144 in a7135 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7157,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7159,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7159(t8,t4,((C_word*)t0)[2]);}

/* expand in k7144 in a7135 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7159(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7159,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7175,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[485],t3,lf[486]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[487]);}}

/* k7173 in expand in k7144 in a7135 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7175,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[403],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7203,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_7159(t9,t8,((C_word*)t0)[2]);}}

/* k7201 in k7173 in expand in k7144 in a7135 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7203,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7155 in k7144 in a7135 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7157,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6850,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[481],t3);}

/* a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6850r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6850r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6850r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7047,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[481],t3,lf[483]);}

/* k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[481],((C_word*)t0)[4],lf[482]);}

/* k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[2]);}

/* k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7054,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7069,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a7125 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7126,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7134,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7054(t3,lf[480],t2);}

/* k7132 in a7125 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7072,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7075,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[478]);}

/* k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[477]);}

/* k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a7115 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7116,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7124,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7054(t3,lf[476],t2);}

/* k7122 in a7115 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7084,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[7]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6861,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6863 in k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6869,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6867 in k6863 in k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6869,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6871,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6871(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k6867 in k6863 in k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6871(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6871,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6916,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6914 in recur in k6867 in k6863 in k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6928,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6926 in k6914 in recur in k6867 in k6863 in k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6928,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6922 in k6914 in recur in k6867 in k6863 in k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6892,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* csi.scm: 44   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_6871(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k6890 in k6922 in k6914 in recur in k6867 in k6863 in k6859 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7082 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7087,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[7]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6944,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6944(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k7082 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6944(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6944,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[431],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6978,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7044,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k7042 in recur in k7082 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7044,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7008,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* csi.scm: 44   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_6944(t12,t8,t9,t10,t11);}

/* k7006 in k7042 in recur in k7082 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7008,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k6976 in recur in k7082 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[475]);
t4=(C_word)C_a_i_list(&a,2,lf[467],t3);
t5=(C_word)C_a_i_list(&a,3,lf[53],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t2,t5));}

/* k7085 in k7082 in k7079 in k7076 in k7073 in k7070 in k7067 in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7087,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[474],t7,t1));}

/* prefix-sym in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_7054(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7054,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7062,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7066,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   symbol->string */
t6=*((C_word*)lf[473]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k7064 in prefix-sym in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7060 in prefix-sym in k7051 in k7048 in k7045 in a6849 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string->symbol */
t2=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6793,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[471],t3);}

/* a6792 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6793,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6797,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6795 in a6792 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[465],t1);
t5=(C_word)C_a_i_list(&a,2,lf[454],t1);
t6=(C_word)C_a_i_list(&a,2,lf[465],t5);
t7=(C_word)C_a_i_list(&a,2,lf[431],t6);
t8=(C_word)C_a_i_list(&a,2,lf[129],t1);
t9=(C_word)C_a_i_list(&a,2,lf[30],lf[1]);
t10=(C_word)C_a_i_list(&a,2,lf[467],t9);
t11=(C_word)C_a_i_list(&a,3,lf[53],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[450],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[450],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[413],t3,t13));}

/* k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6787,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[472],t3);}

/* a6786 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6787,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[471],t2));}

/* k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6634,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[468],t3);}

/* a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6634r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6634r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6634r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6638,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[468],t3,lf[470]);}

/* k6636 in a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[468],((C_word*)t0)[3],lf[469]);}

/* k6639 in k6636 in a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6642 in k6639 in k6636 in a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6644,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6655,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6657,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6657(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k6642 in k6639 in k6636 in a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6657(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6657,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[465],t2);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[413],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],lf[466]);
t9=(C_word)C_a_i_list(&a,2,lf[467],t8);
t10=(C_word)C_a_i_list(&a,3,lf[53],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6707,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}}}

/* k6705 in loop in k6642 in k6639 in k6636 in a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6707,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[450],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[30],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[450],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6718,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_6657(t16,t14,t1,t15);}

/* k6716 in k6705 in loop in k6642 in k6639 in k6636 in a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6718,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6653 in k6642 in k6639 in k6636 in a6633 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6655,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6358,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[457],t3);}

/* a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6358,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[457],t2,lf[464]);}

/* k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   require */
t3=C_retrieve(lf[462]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[463]);}

/* k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6619,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6621,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6620 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6621,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6631,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a6630 in a6620 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6631,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k6617 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[277]+1),t1);}

/* k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6367,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6367(t7,t2,C_fix(0));}

/* loop in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6367,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k6379 in loop in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6385,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6367(t4,t2,t3);}

/* k6383 in k6379 in loop in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6385,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[69],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6426,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   fold-right */
t7=C_retrieve(lf[460]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[461],((C_word*)t0)[2]);}

/* a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6428,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6438,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* csi.scm: 44   ##sys#check-syntax */
t7=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[457],t6,lf[458]);}

/* k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6442,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_i_zerop(t2);
t5=t3;
f_6452(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_6452(t4,(C_word)C_a_i_list(&a,3,lf[456],((C_word*)t0)[2],t2));}}

/* k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6452,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6456,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6458,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a6467 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6468,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6472,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6487,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6487(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a6467 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6487,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[413],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6543,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6541 in build in a6467 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6543,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6554,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* csi.scm: 44   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_6487(t11,t8,t10,t1);}
else{
/* csi.scm: 44   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6487(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k6552 in k6541 in build in a6467 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6554,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6470 in a6467 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6472,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6485,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[453]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6483 in k6470 in a6467 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6485,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],t1,((C_word*)t0)[2]));}

/* a6457 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6466,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   take */
t3=C_retrieve(lf[452]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6464 in a6457 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   split-at! */
t2=C_retrieve(lf[451]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6454 in k6450 in k6440 in a6437 in a6427 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6456,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k6424 in k6412 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in a6357 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t2));}

/* k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6301,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[447],t3);}

/* a6300 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_6301r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6301r(t0,t1,t2,t3);}}

static void C_ccall f_6301r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6311,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6341,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[449]);}}

/* k6339 in a6300 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[446],t3));}

/* k6309 in a6300 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6311,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[446],t3,t6));}

/* k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6225,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[441],t3);}

/* a6224 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6225r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6225r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6229,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6227 in a6224 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6230 in k6227 in a6224 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6232,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[3],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[3],t7);
t9=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t10=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[3],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[5],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[158],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[3],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[159],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6041,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[443],t3);}

/* a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6041r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6041r(t0,t1,t2,t3);}}

static void C_ccall f_6041r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6045,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6050,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[256]);
t4=(C_word)C_a_i_list(&a,3,lf[428],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[217],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[438],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6191,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k6189 in k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[442],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[398],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k6185 in k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6187,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[440],t1);
t3=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[441],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6050,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6073,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_6073(t12,(C_word)C_a_i_cons(&a,2,lf[413],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_6073(t10,(C_word)C_a_i_cons(&a,2,lf[413],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6136,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a6137 in parse-clause in k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6138,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[439],t3,((C_word*)t0)[2]));}

/* k6134 in parse-clause in k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[438],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_6106(t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_6106(t6,(C_word)C_a_i_cons(&a,2,lf[413],t5));}}

/* k6104 in k6134 in parse-clause in k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6106,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6071 in parse-clause in k6046 in k6043 in a6040 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_6073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6073,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[398],t1));}

/* k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5851,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[437],t3);}

/* a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5851r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5851r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5851r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5858,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[129]+1),t5);}

/* k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6031 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6032,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[436]));}

/* k6028 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[427],t2);
t4=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[78]);
t6=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5883,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_5883(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k6028 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5883,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[78]);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t9);
t11=(C_word)C_a_i_list(&a,2,lf[431],t10);
t12=(C_word)C_a_i_list(&a,3,lf[432],lf[78],t3);
t13=(C_word)C_a_i_list(&a,4,lf[3],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5909,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[78],lf[434]);
t17=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t17);
t19=(C_word)C_a_i_list(&a,2,lf[431],t18);
t20=(C_word)C_a_i_list(&a,4,lf[435],lf[78],t3,lf[434]);
t21=(C_word)C_a_i_list(&a,4,lf[385],t16,t19,t20);
t22=t14;
f_5909(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_5909(t15,C_SCHEME_END_OF_LIST);}}}

/* k5907 in loop in k6028 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5909,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_5937(t6,(C_word)C_a_i_list(&a,3,lf[433],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_5937(t5,((C_word*)t0)[2]);}}

/* k5935 in k5907 in loop in k6028 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5937,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5929,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   add1 */
t6=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5927 in k5935 in k5907 in loop in k6028 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5883(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5919 in k5935 in k5907 in loop in k6028 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5921,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5879 in k6028 in k5856 in a5850 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5842,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[425],t3);}

/* a5841 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5842,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5846,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[425],t2,lf[426]);}

/* k5844 in a5841 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5846,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[424],((C_word*)t0)[2]));}

/* k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5823,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[422],t3);}

/* a5822 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5823,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5827,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[422],t2,lf[423]);}

/* k5825 in a5822 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5836,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5835 in k5825 in a5822 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5836,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5832 in k5825 in a5822 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5834,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5804,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[420],t3);}

/* a5803 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5804,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5808,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[420],t2,lf[421]);}

/* k5806 in a5803 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5817,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5816 in k5806 in a5803 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5817,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5813 in k5806 in a5803 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5815,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5676,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[419],t3);}

/* a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5676,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5682,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5682(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5682,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5692,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t7=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[415]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5763,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t9=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[416]);
if(C_truep(t8)){
/* csi.scm: 44   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* csi.scm: 44   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k5761 in loop in a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5763,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5682(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k5690 in loop in a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5695,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5693 in k5690 in loop in a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5695,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[403],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t5));}}

/* k5699 in k5693 in k5690 in loop in a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5708,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5706 in k5699 in k5693 in k5690 in loop in a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5708,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5724,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5722 in k5706 in k5699 in k5693 in k5690 in loop in a5675 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t3));}

/* k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5533,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[418],t3);}

/* a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5533,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5539,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5539(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5539,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5549,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[415]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5624,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t10=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[416]);
if(C_truep(t9)){
/* csi.scm: 44   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5651,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t11=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k5649 in loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5651,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5539(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k5622 in loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5539(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k5547 in loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5552,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5550 in k5547 in loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5552,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[3],t5));}}

/* k5556 in k5550 in k5547 in loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5569,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5567 in k5556 in k5550 in k5547 in loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5569,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5583 in k5567 in k5556 in k5550 in k5547 in loop in a5532 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5585,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5474,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[411],t3);}

/* a5473 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_5474r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5474r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[408],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[409],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[410],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[409],t10));}}

/* k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5303,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[405],t3);}

/* a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5303r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5303r(t0,t1,t2,t3);}}

static void C_ccall f_5303r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5309,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5309(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5309,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5319,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[400],t5);
t8=t6;
f_5319(t8,(C_word)C_a_i_list(&a,2,lf[397],t7));}
else{
t7=t6;
f_5319(t7,lf[401]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5383,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_5383(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_5383(t7,C_SCHEME_FALSE);}}}

/* k5381 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5383,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[405],lf[407],((C_word*)t0)[7]);}}

/* k5384 in k5381 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5386,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[402],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t5=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[404],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5431,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t6=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[400],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5444,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5452,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   cdar */
t10=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   caar */
t7=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k5457 in k5384 in k5381 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[405],lf[406],t1);}

/* k5450 in k5384 in k5381 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5442 in k5384 in k5381 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5309(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5429 in k5384 in k5381 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5431,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5309(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5408 in k5384 in k5381 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5410,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5309(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5317 in loop in a5302 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5319,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[393],t2);
t4=(C_word)C_a_i_list(&a,2,lf[394],lf[395]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[396],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[397],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[338],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[398],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[399],t3,t5,t13));}

/* k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5252,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[392],t3);}

/* a5251 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_5252r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5252r(t0,t1,t2,t3);}}

static void C_ccall f_5252r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[391],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[391],t5,t2));}}

/* k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5192,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[388],t3);}

/* a5191 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_5192r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5192r(t0,t1,t2,t3);}}

static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[383]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5202,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_5202(t11,(C_word)C_a_i_cons(&a,2,lf[3],t10));}
else{
t9=t8;
f_5202(t9,(C_word)C_i_car(t5));}}

/* k5200 in a5191 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5202,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5205,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* csi.scm: 44   syntax-error */
t3=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[388],lf[389],((C_word*)t0)[2]);}}

/* k5219 in k5200 in a5191 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5205(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k5203 in k5200 in a5191 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[384]))?(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[3],((C_word*)t0)[2]):lf[386]));}

/* k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   register-feature! */
t3=C_retrieve(lf[343]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[377],lf[378],lf[379],lf[380],lf[381],lf[382]);}

/* k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=C_mutate(&lf[11],lf[12]);
t3=C_retrieve(lf[13]);
t4=C_mutate(&lf[14],lf[15]);
t5=C_set_block_item(lf[16],0,C_fix(2048));
t6=(C_word)C_a_i_cons(&a,2,lf[17],C_retrieve(lf[18]));
t7=C_mutate((C_word*)lf[18]+1,t6);
t8=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1387,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1399,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[27]+1);
t11=*((C_word*)lf[28]+1);
t12=C_retrieve(lf[29]);
t13=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1438,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[34],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1448,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[35]+1);
t17=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t18=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 144  make-string */
t20=*((C_word*)lf[181]+1);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,C_fix(256));}

/* k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1510,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1558,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[50]+1,t5);
t7=C_set_block_item(lf[31],0,C_fix(1));
t8=C_retrieve(lf[51]);
t9=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1703,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[192]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5186,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 196  repl-prompt */
t14=C_retrieve(lf[376]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t11,t13);}

/* a5185 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5186,2,t0,t1);}
/* csi.scm: 199  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[375],C_retrieve(lf[31]));}

/* k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1728,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1730,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t4=C_retrieve(lf[59]);
t5=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1743,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1757,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 211  make-hash-table */
t7=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[113]+1));}

/* k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1757,2,t0,t1);}
t2=C_mutate(&lf[60],t1);
t3=C_retrieve(lf[61]);
t4=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_retrieve(lf[63]);
t6=C_retrieve(lf[64]);
t7=*((C_word*)lf[28]+1);
t8=C_retrieve(lf[65]);
t9=*((C_word*)lf[66]+1);
t10=C_retrieve(lf[67]);
t11=C_retrieve(lf[68]);
t12=*((C_word*)lf[69]+1);
t13=*((C_word*)lf[20]+1);
t14=*((C_word*)lf[70]+1);
t15=C_retrieve(lf[45]);
t16=C_retrieve(lf[71]);
t17=C_retrieve(lf[72]);
t18=*((C_word*)lf[73]+1);
t19=*((C_word*)lf[74]+1);
t20=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1800,a[2]=t10,a[3]=t8,a[4]=t13,a[5]=t16,a[6]=t19,a[7]=t6,a[8]=t11,a[9]=t15,a[10]=t5,a[11]=t7,a[12]=t17,tmp=(C_word)a,a+=13,tmp));
t21=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2338,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(lf[76],0,C_fix(0));
t23=lf[101]=C_SCHEME_END_OF_LIST;;
t24=lf[104]=C_SCHEME_END_OF_LIST;;
t25=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2379,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2407,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2430,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2721,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2745,tmp=(C_word)a,a+=2,tmp));
t30=C_retrieve(lf[71]);
t31=C_retrieve(lf[161]);
t32=C_retrieve(lf[162]);
t33=C_retrieve(lf[163]);
t34=*((C_word*)lf[164]+1);
t35=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2848,a[2]=t34,a[3]=t33,a[4]=t32,a[5]=t31,a[6]=t30,tmp=(C_word)a,a+=7,tmp));
t36=C_mutate((C_word*)lf[189]+1,lf[190]);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 574  make-hash-table */
t38=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,*((C_word*)lf[113]+1));}

/* k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3042,2,t0,t1);}
t2=C_mutate(&lf[191],t1);
t3=C_retrieve(lf[192]);
t4=C_retrieve(lf[71]);
t5=C_retrieve(lf[193]);
t6=*((C_word*)lf[69]+1);
t7=*((C_word*)lf[194]+1);
t8=*((C_word*)lf[195]+1);
t9=C_retrieve(lf[144]);
t10=C_retrieve(lf[67]);
t11=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3044,a[2]=t9,a[3]=t10,a[4]=t3,a[5]=t7,a[6]=t6,a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t12=C_retrieve(lf[61]);
t13=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3808,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[20]+1);
t16=*((C_word*)lf[40]+1);
t17=*((C_word*)lf[181]+1);
t18=*((C_word*)lf[282]+1);
t19=C_mutate((C_word*)lf[245]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=t15,a[3]=t18,a[4]=t17,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t20=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4178,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[287],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4237,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[288],lf[289]);
t23=C_mutate(&lf[290],lf[291]);
t24=C_mutate(&lf[292],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4294,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4437,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 955  run */
t27=C_retrieve(lf[299]);
((C_proc2)C_retrieve_proc(t27))(2,t27,t26);}

/* k5176 in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5184,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[373]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5182 in k5176 in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5179 in k5176 in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5172,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 827  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[372]);}

/* k5170 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[371]);
/* csi.scm: 827  parse-option-string */
t3=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4444,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 828  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5166 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 828  canonicalize-args */
f_4294(((C_word*)t0)[2],t1);}

/* k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 829  member* */
f_4237(t4,lf[370],((C_word*)t3)[1]);}

/* k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 830  member* */
f_4237(t2,lf[369],((C_word*)((C_word*)t0)[4])[1]);}

/* k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5061,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5111,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5111(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5111(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5111(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5151,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 844  canonicalize-args */
f_4294(t4,((C_word*)t0)[2]);}}

/* k5162 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 844  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5149 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[368],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4453(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5109 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_5111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 835  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[367]);}
else{
t2=((C_word*)t0)[2];
f_5061(2,t2,C_SCHEME_UNDEFINED);}}

/* k5059 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 836  program-name */
t4=C_retrieve(lf[366]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5062 in k5059 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 837  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5065 in k5062 in k5059 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 838  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[365]);}

/* k5068 in k5065 in k5062 in k5059 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[364]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 841  lookup-script-file */
t6=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4453(t4,C_SCHEME_UNDEFINED);}}

/* k5077 in k5068 in k5065 in k5062 in k5059 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4453(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4453(t2,C_SCHEME_FALSE);}}

/* k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4453,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 847  member* */
f_4237(t2,lf[363],((C_word*)((C_word*)t0)[4])[1]);}

/* k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4459(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5055,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 848  member* */
f_4237(t3,lf[362],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5053 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4459(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4459,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 849  member* */
f_4237(t2,lf[361],((C_word*)((C_word*)t0)[4])[1]);}

/* k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4468,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5042,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5046,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 851  getenv */
t6=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[360]);}

/* k5044 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[358]);
/* csi.scm: 851  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[359]);}

/* k5040 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4550,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[357],0,C_fix(0));
t6=t4;
f_4620(t6,t5);}
else{
t5=t4;
f_4620(t5,C_SCHEME_UNDEFINED);}}

/* k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4620,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 874  member* */
f_4237(t3,lf[356],((C_word*)((C_word*)t0)[6])[1]);}

/* k5029 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 875  print-usage */
t3=C_retrieve(lf[19]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4623(2,t2,C_SCHEME_UNDEFINED);}}

/* k5032 in k5029 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 876  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 877  member* */
f_4237(t3,lf[355],((C_word*)((C_word*)t0)[6])[1]);}

/* k5020 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 878  print-banner */
t3=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4626(2,t2,C_SCHEME_UNDEFINED);}}

/* k5023 in k5020 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 879  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[354],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5012,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5019,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 881  chicken-version */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=t2;
f_4629(2,t3,C_SCHEME_UNDEFINED);}}

/* k5017 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 881  print */
t2=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5010 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 882  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 883  member* */
f_4237(t3,lf[353],((C_word*)((C_word*)t0)[6])[1]);}

/* k4997 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5002(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 884  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[352]);}}
else{
t2=((C_word*)t0)[3];
f_4632(t2,C_SCHEME_UNDEFINED);}}

/* k5000 in k4997 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[351],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4632(t3,t2);}

/* k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4632(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4632,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4635(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4993,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 887  load-verbose */
t4=C_retrieve(lf[350]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}

/* k4991 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 888  print-banner */
t2=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 889  member* */
f_4237(t3,lf[349],((C_word*)((C_word*)t0)[6])[1]);}

/* k4976 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4978,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4981(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 890  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[348]);}}
else{
t2=((C_word*)t0)[3];
f_4638(2,t2,C_SCHEME_UNDEFINED);}}

/* k4979 in k4976 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 891  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[347]);}

/* k4982 in k4979 in k4976 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 892  case-sensitive */
t2=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4975,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 893  collect-options */
t4=((C_word*)t0)[2];
f_4470(t4,t3,lf[345]);}

/* k4973 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4971,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 894  collect-options */
t4=((C_word*)t0)[2];
f_4470(t4,t3,lf[344]);}

/* k4969 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4951,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4967,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 897  collect-options */
t6=((C_word*)t0)[2];
f_4470(t6,t5,lf[342]);}

/* k4965 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4953 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 898  collect-options */
t4=((C_word*)t0)[2];
f_4470(t4,t3,lf[341]);}

/* k4961 in k4953 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4957 in k4953 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 897  append */
t2=*((C_word*)lf[263]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[175]),((C_word*)t0)[2]);}

/* k4949 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 896  deldups */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[340]+1));}

/* k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=C_mutate((C_word*)lf[175]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[302],C_retrieve(lf[18]));
t4=C_mutate((C_word*)lf[18]+1,t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 903  provide */
t6=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[339]);}

/* k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[330],t4))){
/* csi.scm: 908  keyword-style */
t5=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,lf[332]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[333],t5))){
/* csi.scm: 910  keyword-style */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,lf[334]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[335],t6))){
/* csi.scm: 912  keyword-style */
t7=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,lf[336]);}
else{
t7=t2;
f_4658(2,t7,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 906  ##sys#error */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[337]);}}
else{
t3=t2;
f_4658(2,t3,C_SCHEME_UNDEFINED);}}

/* k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4885,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 913  member* */
f_4237(t3,lf[329],((C_word*)((C_word*)t0)[2])[1]);}

/* k4883 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4661(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 861  ##sys#string-append */
t4=C_retrieve(lf[327]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[328],lf[14]);}}

/* k4515 in k4883 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4523,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 862  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4521 in k4515 in k4883 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 863  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4545,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 864  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[326]);}}

/* k4543 in k4521 in k4515 in k4883 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[325]);
/* csi.scm: 864  chop-separator */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4527 in k4521 in k4515 in k4883 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 865  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[324],lf[14]);}

/* k4530 in k4527 in k4521 in k4515 in k4883 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 866  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4536 in k4530 in k4527 in k4521 in k4515 in k4883 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 867  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4661(2,t2,C_SCHEME_UNDEFINED);}}

/* k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4661,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4666(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4666,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4679,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 917  repl */
t5=C_retrieve(lf[303]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_member(t4,lf[304]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4694,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_4694(2,t8,t6);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[305]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[306]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[307]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[309]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[310]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t8=(C_word)C_i_cdr(((C_word*)t3)[1]);
t9=C_set_block_item(t3,0,t8);
t10=t7;
f_4694(2,t10,t9);}
else{
t8=(C_word)C_i_string_equal_p(lf[311],t4);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(lf[312],t4));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4723,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4739,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 930  string->symbol */
t13=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,t12);}
else{
t10=(C_word)C_i_string_equal_p(lf[314],t4);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(lf[315],t4));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 933  evalstring */
f_4550(t12,t13,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_i_string_equal_p(lf[316],t4);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(lf[317],t4));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cadr(((C_word*)t3)[1]);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4785,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 936  evalstring */
f_4550(t14,t15,(C_word)C_a_i_list(&a,1,t16));}
else{
t14=(C_word)C_i_string_equal_p(lf[319],t4);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(lf[320],t4));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4801,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_cadr(((C_word*)t3)[1]);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4811,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 941  evalstring */
f_4550(t16,t17,(C_word)C_a_i_list(&a,1,t18));}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 946  load */
t17=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,t4);}}}}}}}}

/* k4816 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=t2;
f_4824(t4,(C_word)C_i_string_equal_p(lf[323],t3));}
else{
t3=t2;
f_4824(t3,C_SCHEME_FALSE);}}

/* k4822 in k4816 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4829,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4839,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 948  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4694(2,t2,C_SCHEME_UNDEFINED);}}

/* a4838 in k4822 in k4816 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4839r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4839r(t0,t1,t2);}}

static void C_ccall f_4839r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4850,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_4850(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_4850(t4,C_SCHEME_FALSE);}}

/* k4848 in a4838 in k4822 in k4816 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 950  exit */
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a4828 in k4822 in k4816 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4837,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 948  command-line-arguments */
t3=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4835 in a4828 in k4822 in k4816 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
t2=C_retrieve(lf[321]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a4810 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4811r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4811r(t0,t1,t2);}}

static void C_ccall f_4811r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),C_retrieve(lf[72]),t2);}

/* k4799 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4694(2,t4,t3);}

/* a4784 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4785r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4785r(t0,t1,t2);}}

static void C_ccall f_4785r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),*((C_word*)lf[24]+1),t2);}

/* k4773 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4694(2,t4,t3);}

/* k4753 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4694(2,t4,t3);}

/* k4737 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],t1);
t3=(C_word)C_a_i_list(&a,2,lf[313],t2);
/* csi.scm: 930  eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k4721 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4694(2,t4,t3);}

/* k4692 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4666(t3,((C_word*)t0)[2],t2);}

/* k4677 in do959 in k4659 in k4656 in k4653 in k4646 in k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 918  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4550(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4550,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4554,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4554(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4597,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4554(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4597 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 869  open-input-string */
t3=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4555 in k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4562 in k4555 in k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4564,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4566(t5,((C_word*)t0)[2],t1);}

/* do945 in k4562 in k4555 in k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4566(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4566,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 872  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[301]+1));}}

/* a4588 in do945 in k4562 in k4555 in k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
/* csi.scm: 872  eval */
t2=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4585 in do945 in k4562 in k4555 in k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 872  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4574 in do945 in k4562 in k4555 in k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4581 in k4574 in do945 in k4562 in k4555 in k4552 in evalstring in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4566(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4470,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4476,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4476(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4476,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 857  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[300],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4503,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 858  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4501 in loop in collect-options in k4466 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in ##csi#run in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4294(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4294,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4300,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4300(t6,t1,t2);}

/* loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4300,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[293]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[294]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[295]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[296]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4322,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[291]);
t8=t4;
f_4322(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4322(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4322(t6,C_SCHEME_FALSE);}}}}

/* k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4322,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 813  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4300(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4372,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 814  substring */
t5=*((C_word*)lf[35]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 818  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4300(t4,t2,t3);}}

/* k4377 in k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4370 in k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[298]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4336 in k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4411,tmp=(C_word)a,a+=2,tmp);
t4=f_4411(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4361,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 817  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[297],((C_word*)t0)[2]);}}

/* a4360 in k4336 in k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4361,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4349 in k4336 in k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4355,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 816  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4300(t4,t2,t3);}

/* k4353 in k4349 in k4336 in k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 816  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4336 in k4320 in loop in canonicalize-args in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static C_word C_fcall f_4411(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4237(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4237,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4243,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4243(t7,t1,t3);}

/* loop in member* in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4243,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4255,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4255(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4255,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 788  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4243(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 790  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4178r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4178r(t0,t1,t2,t3);}}

static void C_ccall f_4178r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4182,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4182(2,t5,*((C_word*)lf[286]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4182(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 776  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4180 in ##csi#deldups in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4187,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4187(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4180 in ##csi#deldups in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4187(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4187,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4203,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4216,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 781  del */
t7=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4214 in recur in k4180 in ##csi#deldups in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 781  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4187(t2,((C_word*)t0)[2],t1);}

/* k4201 in recur in k4180 in ##csi#deldups in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3969,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4001,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4001(t10,t1,C_fix(0));}

/* do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4001,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 749  justify */
t5=((C_word*)t0)[2];
f_3972(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4174 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 749  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 750  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4086(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4086,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 755  fxmod */
t7=*((C_word*)lf[284]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 760  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4145 in do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4169,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 761  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4167 in k4145 in do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  justify */
t2=((C_word*)t0)[3];
f_3972(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4163 in k4145 in do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4148 in k4145 in do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4086(t4,((C_word*)t0)[2],t2,t3);}

/* k4103 in do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4123(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* do828 in k4103 in do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4123(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4123,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4133,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 759  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[283],((C_word*)t0)[2]);}}

/* k4131 in do828 in k4103 in do821 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4123(t3,((C_word*)t0)[2],t2);}

/* k4015 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 762  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k4018 in k4015 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4035(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* do836 in k4018 in k4015 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4035,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 766  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4046 in do836 in k4018 in k4015 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 768  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 769  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4049 in k4046 in do836 in k4018 in k4015 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4035(t4,((C_word*)t0)[2],t2,t3);}

/* k4021 in k4018 in k4015 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 770  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4024 in k4021 in k4018 in k4015 in k4012 in k4009 in do811 in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4001(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3972,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3976,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 741  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3974 in justify in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3976,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3992,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 744  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3990 in k3974 in justify in ##csi#hexdump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 744  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3808r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3808r(t0,t1,t2,t3);}}

static void C_ccall f_3808r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3810,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3916,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3921,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len786798 */
t7=t6;
f_3921(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out787796 */
t9=t5;
f_3916(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body784789 */
t11=t4;
f_3810(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len786 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3921,NULL,2,t0,t1);}
/* def-out787796 */
t2=((C_word*)t0)[2];
f_3916(t2,t1,C_SCHEME_FALSE);}

/* def-out787 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3916,NULL,3,t0,t1,t2);}
/* body784789 */
t3=((C_word*)t0)[2];
f_3810(t3,t1,t2,*((C_word*)lf[148]+1));}

/* body784 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3810(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3810,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3813,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 723  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[278],lf[279],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3835,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 724  ##sys#bytevector? */
t6=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3833 in body784 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3835,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 724  bestlen */
t4=((C_word*)t0)[2];
f_3813(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 725  bestlen */
t4=((C_word*)t0)[2];
f_3813(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_pointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 727  hexdump */
t4=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[280]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3878(t6,(C_word)C_i_assq(t5,C_retrieve(lf[189])));}
else{
t5=t4;
f_3878(t5,C_SCHEME_FALSE);}}}}}

/* k3876 in k3833 in body784 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3878,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 730  bestlen */
t5=((C_word*)t0)[2];
f_3813(t5,t3,t4);}
else{
/* csi.scm: 731  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[278],lf[281],((C_word*)t0)[5]);}}

/* k3886 in k3876 in k3833 in body784 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 730  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3857 in k3833 in body784 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 725  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3840 in k3833 in body784 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 724  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* bestlen in body784 in ##csi#dump in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3813,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 722  min */
t3=*((C_word*)lf[277]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3802,4,t0,t1,t2,t3);}
/* csi.scm: 712  hash-table-set! */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve2(lf[191],"describer-table"),t2,t3);}

/* ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3044r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3044r(t0,t1,t2,t3);}}

static void C_ccall f_3044r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3048(2,t5,*((C_word*)lf[148]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3048(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 586  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3781,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 610  ##sys#block-address */
t5=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[9]);}
else{
t4=t3;
f_3176(2,t4,C_SCHEME_UNDEFINED);}}

/* k3779 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 610  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[274],t1);}

/* k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[11]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[11]));
/* csi.scm: 613  fprintf */
t4=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[9],lf[203],((C_word*)t0)[11],t3,t3,t3);}
else{
switch(((C_word*)t0)[11]){
case C_SCHEME_TRUE:
/* csi.scm: 614  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[204]);
case C_SCHEME_FALSE:
/* csi.scm: 615  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[205]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[11]))){
/* csi.scm: 616  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[206]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[11]))){
/* csi.scm: 617  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[207]);}
else{
t3=C_retrieve(lf[13]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[11]);
if(C_truep(t4)){
/* csi.scm: 618  fprintf */
t5=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[9],lf[208]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[11]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 620  fprintf */
t6=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[9],lf[210],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11]);}
else{
t5=(C_word)C_slot(lf[211],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[11],t5);
if(C_truep(t6)){
/* csi.scm: 625  fprintf */
t7=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[9],lf[212]);}
else{
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
/* csi.scm: 626  ##sys#number? */
t8=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[11]);}}}}}}}}

/* k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 626  fprintf */
t2=((C_word*)t0)[12];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[11],((C_word*)t0)[10],lf[213],((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[9]))){
/* csi.scm: 627  descseq */
t2=((C_word*)t0)[8];
f_3050(6,t2,((C_word*)t0)[11],lf[214],*((C_word*)lf[215]+1),((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
/* csi.scm: 628  descseq */
t2=((C_word*)t0)[8];
f_3050(6,t2,((C_word*)t0)[11],lf[216],*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[9]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3305,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 630  ##sys#symbol-has-toplevel-binding? */
t4=C_retrieve(lf[222]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
/* csi.scm: 634  descseq */
t2=((C_word*)t0)[8];
f_3050(6,t2,((C_word*)t0)[11],lf[223],((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* csi.scm: 635  fprintf */
t4=((C_word*)t0)[12];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[11],((C_word*)t0)[10],lf[224],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[9]))){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[9],t4);
t6=t3;
f_3382(t6,(C_word)C_eqp(C_retrieve(lf[229]),t5));}
else{
t4=t3;
f_3382(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3382(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 645  port? */
t3=C_retrieve(lf[272]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}}}}}}}}

/* k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3422,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_truep(t2)?lf[230]:lf[231]);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3441,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 651  ##sys#peek-unsigned-integer */
t7=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
/* csi.scm: 652  instance? */
t3=C_retrieve(lf[271]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t3=t2;
f_3450(2,t3,C_SCHEME_FALSE);}}}

/* k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 653  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 654  ##sys#locative? */
t3=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 656  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
if(C_truep((C_word)C_pointerp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3547,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 669  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 670  ##sys#bytevector? */
t3=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}}}

/* k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 672  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],lf[247],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 675  ##sys#lambda-info->string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[250]))){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[253]:lf[254]);
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
/* csi.scm: 678  fprintf */
t7=((C_word*)t0)[5];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[6],lf[255],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[256]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* csi.scm: 685  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],lf[261],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[266]))){
/* csi.scm: 695  provided? */
t3=C_retrieve(lf[267]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[268]);}
else{
t3=t2;
f_3687(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3685 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3687,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 696  unveil */
t2=C_retrieve(lf[262]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[6]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 699  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[191],"describer-table"),t2,C_SCHEME_FALSE);}
else{
/* csi.scm: 706  fprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[5],lf[265]);}}}

/* k3700 in k3685 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3702,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve(lf[189]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3730,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[63]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 704  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[264],t4);}}}

/* k3739 in k3700 in k3685 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 705  descseq */
t2=((C_word*)t0)[3];
f_3050(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3728 in k3700 in k3685 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 702  append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k3724 in k3700 in k3685 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_3709 in k3700 in k3685 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3709,3,t0,t1,t2);}
/* g769770 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3618 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a3624 in k3618 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3625,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3629,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 688  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[260],t2);}

/* k3627 in a3624 in k3618 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3629,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3638(t6,((C_word*)t0)[2],t2);}

/* loop in k3627 in a3624 in k3618 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3638,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3648,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 691  caar */
t5=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k3671 in loop in k3627 in a3624 in k3618 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 692  cdar */
t4=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_3648(2,t3,C_SCHEME_UNDEFINED);}}

/* k3663 in k3671 in loop in k3627 in a3624 in k3618 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 692  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[257],t1,t2);}

/* k3646 in loop in k3627 in a3624 in k3618 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 693  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3638(t3,((C_word*)t0)[2],t2);}

/* k3582 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 680  fprintf */
t4=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],lf[252],t3);}

/* k3585 in k3582 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 681  hash-table-walk */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3591 in k3585 in k3582 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3592,4,t0,t1,t2,t3);}
/* csi.scm: 683  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[251],t2,t3);}

/* k3570 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 675  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[248],t1);}

/* k3557 in k3551 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 673  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3545 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 669  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[244],t1);}

/* k3464 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3477,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3477(t5,lf[234]);
case C_fix(1):
t5=t4;
f_3477(t5,lf[235]);
case C_fix(2):
t5=t4;
f_3477(t5,lf[236]);
case C_fix(3):
t5=t4;
f_3477(t5,lf[237]);
case C_fix(4):
t5=t4;
f_3477(t5,lf[238]);
case C_fix(5):
t5=t4;
f_3477(t5,lf[239]);
case C_fix(6):
t5=t4;
f_3477(t5,lf[240]);
case C_fix(7):
t5=t4;
f_3477(t5,lf[241]);
case C_fix(8):
t5=t4;
f_3477(t5,lf[242]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3477(t6,(C_truep(t5)?lf[243]:C_SCHEME_UNDEFINED));}}

/* k3475 in k3464 in k3457 in k3448 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 655  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[233],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3439 in k3420 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 646  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[232],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3380 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3382,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 641  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3392,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3396,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 643  ##sys#peek-unsigned-integer */
t4=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],C_fix(0));}}

/* k3394 in k3380 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 643  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[226],t1);}

/* k3390 in k3380 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 642  descseq */
t2=((C_word*)t0)[3];
f_3050(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3336 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3305(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 630  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[221],((C_word*)t0)[2]);}}

/* k3303 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3318(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3318(t4,C_SCHEME_FALSE);}}

/* k3316 in k3303 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 632  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[220],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3308(2,t2,C_SCHEME_UNDEFINED);}}

/* k3306 in k3303 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 633  ##sys#symbol->string */
t3=C_retrieve(lf[219]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3313 in k3306 in k3303 in k3273 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 633  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[218],t1);}

/* k3243 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(65536)))){
/* csi.scm: 622  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[209],t2);}
else{
t4=t3;
f_3251(2,t4,C_SCHEME_UNDEFINED);}}

/* k3249 in k3243 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 623  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* k3177 in k3174 in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3050,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3173,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 589  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3173,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 590  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[202],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3057(2,t4,C_SCHEME_UNDEFINED);}}

/* k3055 in k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3062(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3055 in k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3062,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 594  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[196],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3085,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 596  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3083 in loop1 in k3055 in k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3085,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3094(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3083 in loop1 in k3055 in k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_3094(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3094,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 599  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[201],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 606  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3156 in loop2 in k3083 in loop1 in k3055 in k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 606  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3094(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 607  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3094(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3102 in loop2 in k3083 in loop1 in k3055 in k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[197]:lf[198]);
/* csi.scm: 601  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[199],t3,t5);}
else{
/* csi.scm: 604  newline */
t3=*((C_word*)lf[200]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3105 in k3102 in loop2 in k3083 in loop1 in k3055 in k3171 in descseq in k3046 in ##csi#describe in k3040 in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 605  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3062(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2848r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2848r(t0,t1,t2);}}

static void C_ccall f_2848r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2856,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_2856(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 514  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 514  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 516  gc */
t3=C_retrieve(lf[188]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 517  ##sys#symbol-table-info */
t3=C_retrieve(lf[187]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 518  memory-statistics */
t3=C_retrieve(lf[186]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2870,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 520  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[185]);}

/* k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3024,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[184]),C_retrieve(lf[18]));}

/* k3026 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[183]+1));}

/* k3022 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k3018 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2986 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2987,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2991,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 523  display */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[182]);}

/* k2989 in a2986 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2995 in k2989 in a2986 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2996,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3004,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 526  make-string */
t7=*((C_word*)lf[181]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k3002 in a2995 in k2989 in a2986 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 526  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[180],((C_word*)t0)[2],t1);}

/* k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 540  machine-type */
t4=C_retrieve(lf[179]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2914 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[168]:lf[169]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 542  software-type */
t5=C_retrieve(lf[178]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2922 in k2914 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 543  software-version */
t3=C_retrieve(lf[177]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2926 in k2922 in k2914 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 544  build-platform */
t3=C_retrieve(lf[176]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2930 in k2926 in k2922 in k2914 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 546  shorten */
f_2870(t2,t3);}

/* k2934 in k2930 in k2926 in k2922 in k2914 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2940,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 547  shorten */
f_2870(t2,t3);}

/* k2938 in k2934 in k2930 in k2926 in k2922 in k2914 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[170]:lf[171]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[172]:lf[173]);
/* csi.scm: 529  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[174],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[175]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2889 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 554  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2892 in k2889 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 555  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[167]);}
else{
t3=t2;
f_2897(2,t3,C_SCHEME_UNDEFINED);}}

/* k2895 in k2892 in k2889 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 556  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[166]);}
else{
t3=t2;
f_2900(2,t3,C_SCHEME_UNDEFINED);}}

/* k2898 in k2895 in k2892 in k2889 in k2886 in k2883 in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_2870(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2870,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2878,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 519  truncate */
t5=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2876 in shorten in k2866 in k2863 in k2860 in a2857 in k2854 in ##csi#report in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2745,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2749,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 492  open-input-string */
t4=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2754,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2777,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2779,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  call-with-current-continuation */
t6=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2779,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2785,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2797,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  with-exception-handler */
t5=C_retrieve(lf[158]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2796 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2835 in a2796 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2836r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2836r(t0,t1,t2);}}

static void C_ccall f_2836r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2841 in a2835 in a2796 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2802 in a2796 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2811,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 500  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2809 in a2802 in a2796 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2813(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do683 in k2809 in a2802 in a2796 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2813,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 502  reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2830,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 500  read */
t5=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2828 in do683 in k2809 in a2802 in a2796 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2813(t3,((C_word*)t0)[2],t1,t2);}

/* a2784 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2785,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2790 in a2784 in a2778 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
/* csi.scm: 499  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[156],((C_word*)t0)[2]);}

/* k2775 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2772 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2753 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2754,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2764,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 496  open-output-string */
t4=C_retrieve(lf[155]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2762 in a2753 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 497  write */
t3=*((C_word*)lf[70]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2765 in k2762 in a2753 in k2747 in ##csi#parse-option-string in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 498  get-output-string */
t2=C_retrieve(lf[154]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do-unbreak-all in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2725,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2731,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}

/* a2730 in do-unbreak-all in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2731,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k2723 in do-unbreak-all in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[104]=C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[13]));}

/* ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2430,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2435,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 396  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_retrieve(lf[76]));}

/* k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 397  trace-indent */
t4=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2436 in k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 398  write */
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2439 in k2436 in k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 399  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[152]);}

/* k2442 in k2439 in k2436 in k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2455,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2454 in k2442 in k2439 in k2436 in k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2455,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 402  write */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2457 in a2454 in k2442 in k2439 in k2436 in k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[148]+1));}

/* k2445 in k2442 in k2439 in k2436 in k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 405  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ##csi#traced-procedure-exit in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 406  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2407,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2411,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 388  trace-indent */
t5=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2409 in ##csi#traced-procedure-entry in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 389  add1 */
t3=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[76]));}

/* k2413 in k2409 in ##csi#traced-procedure-entry in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 390  write */
t5=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2416 in k2413 in k2409 in ##csi#traced-procedure-entry in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 391  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2419 in k2416 in k2413 in k2409 in ##csi#traced-procedure-entry in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 392  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#trace-indent in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2383,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[148]+1));}

/* k2381 in ##csi#trace-indent in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2388(t5,((C_word*)t0)[2],C_retrieve(lf[76]));}

/* do617 in k2381 in ##csi#trace-indent in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_2388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2388,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2398,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[148]+1));}}

/* k2396 in do617 in k2381 in ##csi#trace-indent in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 382  sub1 */
t3=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2403 in k2396 in do617 in k2381 in ##csi#trace-indent in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2388(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2338,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2344,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2344(t8,t1,t3);}

/* loop in ##csi#del in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_2344(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2344,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 371  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2358 in loop in ##csi#del in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 373  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2344(t4,t2,t3);}}

/* k2368 in k2358 in loop in ##csi#del in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2370,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
t3=C_set_block_item(lf[76],0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 239  exit */
t4=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_1817(t6,(C_word)C_eqp(lf[145],t5));}
else{
t5=t4;
f_1817(t5,C_SCHEME_FALSE);}}}

/* k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_1817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 243  hash-table-ref/default */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[60],"command-table"),t2,C_SCHEME_FALSE);}
else{
t4=t3;
f_1823(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 359  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2318 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2319r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2319r(t0,t1,t2);}}

static void C_ccall f_2319r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2323,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 360  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2321 in a2318 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2312 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
/* csi.scm: 359  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[123],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 250  read */
t4=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[80]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 254  read */
t5=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[81]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 259  read */
t6=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[83]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 263  read */
t7=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 267  read */
t8=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[86]);
if(C_truep(t7)){
/* csi.scm: 272  report */
t8=C_retrieve(lf[87]);
((C_proc2)C_retrieve_proc(t8))(2,t8,((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[88]);
if(C_truep(t8)){
/* csi.scm: 273  exit */
t9=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t9))(2,t9,((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1960,a[2]=t10,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 275  read-line */
t12=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1994,a[2]=t11,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 279  read-line */
t13=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[96]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 283  read */
t13=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[100]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2060,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2064,a[2]=t14,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 287  read-line */
t16=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[111]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=t15,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 288  read-line */
t17=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[115]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2106,a[2]=t16,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 289  read-line */
t18=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[120]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2123,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=t17,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 290  read-line */
t19=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[122]);
if(C_truep(t16)){
/* csi.scm: 291  do-unbreak-all */
t17=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t17))(2,t17,((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t17)){
t18=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[126]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2157,a[2]=t19,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 295  read */
t21=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[127]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[101],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2189,a[2]=t20,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[129]+1),C_retrieve2(lf[101],"traced-procedures"));}
else{
t21=t20;
f_2166(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[131]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[132]))){
t21=C_retrieve(lf[132]);
t22=C_set_block_item(lf[132],0,C_SCHEME_FALSE);
/* csi.scm: 305  ##sys#break-resume */
t23=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t23))(3,t23,((C_word*)t0)[15],t21);}
else{
/* csi.scm: 306  display */
t21=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[134]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[135]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[136]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[136]));
/* csi.scm: 309  history-add */
t24=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[137]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 312  read */
t24=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[138]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 316  read-line */
t25=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[140]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 321  display */
t26=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[142]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 356  printf */
t26=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[143],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2297 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2273 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2278,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2283,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 347  hash-table-walk */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[60],"command-table"),t3);}

/* a2282 in k2273 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2283,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 352  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,C_make_character(32),t4);}
else{
/* csi.scm: 353  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[141],t2);}}

/* k2276 in k2273 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2254 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 317  system */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2257 in k2254 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2262,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 318  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2260 in k2257 in k2254 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2231 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 313  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2234 in k2231 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
/* csi.scm: 314  eval */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2241 in k2234 in k2231 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 314  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2215 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 310  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[136]));}

/* k2187 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 298  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* k2164 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[104],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),C_retrieve2(lf[104],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2177 in k2164 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 300  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[128],t1);}

/* k2155 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 295  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2151 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[125]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2125 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 290  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2121 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2117 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2692,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2691 in k2117 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2692,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 473  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2694 in a2691 in k2117 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 478  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[104],"broken-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 475  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[121],t1);}}

/* k2713 in k2694 in a2691 in k2117 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[104],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2104 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 289  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2100 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2611,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2624,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2623 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2624,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2628,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 452  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2626 in a2623 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2673,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 455  ##sys#warn */
t5=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[119],t1);}
else{
t4=t3;
f_2634(t4,C_SCHEME_UNDEFINED);}}

/* k2671 in k2626 in a2623 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 457  del */
t5=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}

/* k2678 in k2671 in k2626 in a2623 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
f_2634(t3,t2);}

/* k2632 in k2626 in a2623 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_2634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2634,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[104],"broken-procedures"));
t5=C_mutate(&lf[104],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 459  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[118],((C_word*)t0)[3]);}}

/* a2654 in k2632 in k2626 in a2623 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2655r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2655r(t0,t1,t2);}}

static void C_ccall f_2655r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2659,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 465  ##sys#break-entry */
t4=C_retrieve(lf[117]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2657 in a2654 in k2632 in k2626 in a2623 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2610 in k2096 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2611,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[116]));
/* csi.scm: 449  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k2083 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 288  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2079 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2075 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2077,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2570,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2569 in k2075 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2570,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2574,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 438  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2572 in a2569 in k2075 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 443  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 440  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[114],t1);}}

/* k2591 in k2572 in a2569 in k2075 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2062 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 287  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2058 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2476,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[101],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2489,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2488 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2489,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2493,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 414  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2491 in a2488 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures")))){
/* csi.scm: 416  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[103],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures")))){
/* csi.scm: 418  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[105]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[101],"traced-procedures"));
t5=C_mutate(&lf[101],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2532,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 421  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[108],t1);}}}}

/* a2531 in k2491 in a2488 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2532r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2532r(t0,t1,t2);}}

static void C_ccall f_2532r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2536,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 427  traced-procedure-entry */
t4=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2534 in a2531 in k2491 in a2488 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 428  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2546 in k2534 in a2531 in k2491 in a2488 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2547r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2547r(t0,t1,t2);}}

static void C_ccall f_2547r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2551,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 430  traced-procedure-exit */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2549 in a2546 in k2534 in a2531 in k2491 in a2488 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2540 in k2534 in a2531 in k2491 in a2488 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2475 in k2054 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2476,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 411  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2008,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2035 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2036r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2036r(t0,t1,t2);}}

static void C_ccall f_2036r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2040,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 285  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2038 in a2035 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2007 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2012,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[99]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2010 in a2007 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2023,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2022 in k2010 in a2007 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2023r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2023r(t0,t1,t2);}}

static void C_ccall f_2023r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2034,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2032 in a2022 in k2010 in a2007 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=C_retrieve(lf[97]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2025 in a2022 in k2010 in a2007 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2016 in k2010 in a2007 in k2001 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
/* csi.scm: 284  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1992 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1967 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a1976 in k1967 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1977,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily542 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[95],t3);}

/* a1982 in a1976 in k1967 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1983,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1987,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 280  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1985 in a1982 in a1976 in k1967 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 280  print* */
t2=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[94]);}

/* k1970 in k1967 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1958 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 275  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1948 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[91]),t1);}

/* k1951 in k1948 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1909 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 268  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1912 in k1909 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1917,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 269  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1915 in k1912 in k1909 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 270  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1918 in k1915 in k1912 in k1909 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 271  dump */
t2=C_retrieve(lf[84]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1894 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 264  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1897 in k1894 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 265  dump */
t2=C_retrieve(lf[84]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1879 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 260  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1882 in k1879 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 261  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1861 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 255  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1864 in k1861 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 256  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1867 in k1864 in k1861 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1842 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1854,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 251  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1852 in k1842 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 251  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1845 in k1842 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1827 in k1821 in k1815 in ##sys#repl-eval-hook in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* toplevel-command in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1759r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1759r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1763,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1763(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1763(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1761 in toplevel-command in k1755 in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1763,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[5],lf[62]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[62]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* csi.scm: 218  hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],C_retrieve2(lf[60],"command-table"),((C_word*)t0)[5],t4);}

/* ##sys#read-prompt-hook in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1750,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 209  tty-input? */
t3=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1748 in ##sys#read-prompt-hook in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 209  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k1726 in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1730,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 202  ##sys#tty-port? */
t3=C_retrieve(lf[56]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[57]+1));}}

/* ##csi#history-ref in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1703,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[31])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[50]),t3));}
else{
/* csi.scm: 194  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[54],t2);}}

/* ##csi#history-add in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1664,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[13]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[50]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1674,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[31]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 185  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[50]),t8);}
else{
t7=t6;
f_1674(t7,C_SCHEME_UNDEFINED);}}

/* k1686 in ##csi#history-add in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=((C_word*)t0)[2];
f_1674(t3,t2);}

/* k1672 in ##csi#history-add in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_1674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[50]),C_retrieve(lf[31]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[31]),C_fix(1));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1558,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 158  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[49]);}

/* k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=f_1448(t3);
if(C_truep(t4)){
/* csi.scm: 160  addext */
f_1510(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t5=((C_word*)t0)[5];
t6=(C_word)C_block_size(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1537,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=f_1537(t7,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t12=(C_truep(t10)?(C_word)C_i_foreign_block_argumentp(t10):C_SCHEME_FALSE);
t13=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t14=(C_word)stub486(t11,t12,t13);
/* ##sys#peek-nonnull-c-string */
t15=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t9,t14,C_fix(0));}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 164  addext */
f_1510(t9,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1601 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 166  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[47],((C_word*)t0)[2]);}}

/* k1607 in k1601 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 167  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[46]);}

/* k1614 in k1607 in k1601 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1618(t5,((C_word*)t0)[2],t1);}

/* loop in k1614 in k1607 in k1601 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_1618(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1618,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 169  chop-separator */
t6=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1643 in loop in k1614 in k1607 in k1601 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 169  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1626 in loop in k1614 in k1607 in k1601 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 170  addext */
f_1510(t2,t1);}

/* k1629 in k1626 in loop in k1614 in k1607 in k1601 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 171  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1618(t3,((C_word*)t0)[4],t2);}}

/* k1584 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 163  chop-separator */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1598 in k1584 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[43],((C_word*)t0)[2]);}

/* k1594 in k1584 in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  addext */
f_1510(((C_word*)t0)[2],t1);}

/* loop in k1560 in ##csi#lookup-script-file in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static C_word C_fcall f_1537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=f_1448((C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* addext in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_fcall f_1510(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1510,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 147  file-exists? */
t4=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1515 in addext in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 149  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k1518 in k1515 in addext in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1526,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 150  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1524 in k1518 in k1515 in addext in k1489 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1460,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1464,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 132  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1462 in ##csi#chop-separator in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))?f_1448(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
/* csi.scm: 135  substring */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t1);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}}

/* dirseparator? in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static C_word C_fcall f_1448(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(t1,C_make_character(92));
return((C_truep(t2)?t2:(C_word)C_eqp(t1,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1438,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 121  history-ref */
t5=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1444 in ##sys#sharp-number-hook in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1446,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##sys#user-read-hook in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1409,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[31]),C_fix(1));
/* csi.scm: 116  history-ref */
t8=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
/* csi.scm: 117  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1424 in ##sys#user-read-hook in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##csi#print-banner in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1407,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 105  chicken-version */
t3=C_retrieve(lf[26]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k1405 in ##csi#print-banner in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 105  print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[12],t1,lf[25]);}

/* ##csi#print-usage in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1391,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 75   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[22]);}

/* k1389 in ##csi#print-usage in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 90   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[14]);}

/* k1392 in k1389 in ##csi#print-usage in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1225 in k1222 in k1219 in k1216 in k1213 in k1210 in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 91   display */
t2=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[21]);}

/* assign in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1139,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1143,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[9],t2,lf[10]);}

/* k1141 in assign in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1180,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[7]),((C_word*)t0)[5]);}}}

/* k1178 in k1141 in assign in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1180,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1199,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1201,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a1200 in k1178 in k1141 in assign in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1201,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k1197 in k1178 in k1141 in assign in k1136 in k1133 in k1130 in k1127 in k1124 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1199,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[769] = {
{"toplevelcsi.scm",(void*)C_toplevel},
{"f_1075csi.scm",(void*)f_1075},
{"f_1078csi.scm",(void*)f_1078},
{"f_1081csi.scm",(void*)f_1081},
{"f_1084csi.scm",(void*)f_1084},
{"f_1087csi.scm",(void*)f_1087},
{"f_1090csi.scm",(void*)f_1090},
{"f_1093csi.scm",(void*)f_1093},
{"f_1096csi.scm",(void*)f_1096},
{"f_1099csi.scm",(void*)f_1099},
{"f_1102csi.scm",(void*)f_1102},
{"f_8740csi.scm",(void*)f_8740},
{"f_8744csi.scm",(void*)f_8744},
{"f_8747csi.scm",(void*)f_8747},
{"f_8750csi.scm",(void*)f_8750},
{"f_8756csi.scm",(void*)f_8756},
{"f_8962csi.scm",(void*)f_8962},
{"f_8942csi.scm",(void*)f_8942},
{"f_8938csi.scm",(void*)f_8938},
{"f_8918csi.scm",(void*)f_8918},
{"f_8781csi.scm",(void*)f_8781},
{"f_8791csi.scm",(void*)f_8791},
{"f_8910csi.scm",(void*)f_8910},
{"f_8794csi.scm",(void*)f_8794},
{"f_8906csi.scm",(void*)f_8906},
{"f_8797csi.scm",(void*)f_8797},
{"f_8828csi.scm",(void*)f_8828},
{"f_8808csi.scm",(void*)f_8808},
{"f_8779csi.scm",(void*)f_8779},
{"f_1105csi.scm",(void*)f_1105},
{"f_8652csi.scm",(void*)f_8652},
{"f_8669csi.scm",(void*)f_8669},
{"f_8672csi.scm",(void*)f_8672},
{"f_8678csi.scm",(void*)f_8678},
{"f_1108csi.scm",(void*)f_1108},
{"f_8611csi.scm",(void*)f_8611},
{"f_8615csi.scm",(void*)f_8615},
{"f_1111csi.scm",(void*)f_1111},
{"f_8595csi.scm",(void*)f_8595},
{"f_8605csi.scm",(void*)f_8605},
{"f_8603csi.scm",(void*)f_8603},
{"f_1114csi.scm",(void*)f_1114},
{"f_8518csi.scm",(void*)f_8518},
{"f_8522csi.scm",(void*)f_8522},
{"f_8590csi.scm",(void*)f_8590},
{"f_8525csi.scm",(void*)f_8525},
{"f_8534csi.scm",(void*)f_8534},
{"f_8581csi.scm",(void*)f_8581},
{"f_8548csi.scm",(void*)f_8548},
{"f_8556csi.scm",(void*)f_8556},
{"f_8558csi.scm",(void*)f_8558},
{"f_8575csi.scm",(void*)f_8575},
{"f_8540csi.scm",(void*)f_8540},
{"f_8532csi.scm",(void*)f_8532},
{"f_1117csi.scm",(void*)f_1117},
{"f_8458csi.scm",(void*)f_8458},
{"f_8462csi.scm",(void*)f_8462},
{"f_1120csi.scm",(void*)f_1120},
{"f_8399csi.scm",(void*)f_8399},
{"f_8403csi.scm",(void*)f_8403},
{"f_8430csi.scm",(void*)f_8430},
{"f_1123csi.scm",(void*)f_1123},
{"f_8225csi.scm",(void*)f_8225},
{"f_8229csi.scm",(void*)f_8229},
{"f_8232csi.scm",(void*)f_8232},
{"f_8393csi.scm",(void*)f_8393},
{"f_8235csi.scm",(void*)f_8235},
{"f_8387csi.scm",(void*)f_8387},
{"f_8238csi.scm",(void*)f_8238},
{"f_8385csi.scm",(void*)f_8385},
{"f_8349csi.scm",(void*)f_8349},
{"f_8363csi.scm",(void*)f_8363},
{"f_8377csi.scm",(void*)f_8377},
{"f_8357csi.scm",(void*)f_8357},
{"f_8353csi.scm",(void*)f_8353},
{"f_8245csi.scm",(void*)f_8245},
{"f_8341csi.scm",(void*)f_8341},
{"f_8317csi.scm",(void*)f_8317},
{"f_8335csi.scm",(void*)f_8335},
{"f_8325csi.scm",(void*)f_8325},
{"f_8321csi.scm",(void*)f_8321},
{"f_8313csi.scm",(void*)f_8313},
{"f_8297csi.scm",(void*)f_8297},
{"f_8273csi.scm",(void*)f_8273},
{"f_8291csi.scm",(void*)f_8291},
{"f_8281csi.scm",(void*)f_8281},
{"f_8277csi.scm",(void*)f_8277},
{"f_8269csi.scm",(void*)f_8269},
{"f_1126csi.scm",(void*)f_1126},
{"f_8130csi.scm",(void*)f_8130},
{"f_8166csi.scm",(void*)f_8166},
{"f_8179csi.scm",(void*)f_8179},
{"f_8137csi.scm",(void*)f_8137},
{"f_1129csi.scm",(void*)f_1129},
{"f_8020csi.scm",(void*)f_8020},
{"f_8024csi.scm",(void*)f_8024},
{"f_8027csi.scm",(void*)f_8027},
{"f_8030csi.scm",(void*)f_8030},
{"f_8033csi.scm",(void*)f_8033},
{"f_8124csi.scm",(void*)f_8124},
{"f_8036csi.scm",(void*)f_8036},
{"f_8118csi.scm",(void*)f_8118},
{"f_8039csi.scm",(void*)f_8039},
{"f_8112csi.scm",(void*)f_8112},
{"f_8116csi.scm",(void*)f_8116},
{"f_8046csi.scm",(void*)f_8046},
{"f_8084csi.scm",(void*)f_8084},
{"f_8082csi.scm",(void*)f_8082},
{"f_1132csi.scm",(void*)f_1132},
{"f_8010csi.scm",(void*)f_8010},
{"f_1135csi.scm",(void*)f_1135},
{"f_7996csi.scm",(void*)f_7996},
{"f_1138csi.scm",(void*)f_1138},
{"f_1212csi.scm",(void*)f_1212},
{"f_1215csi.scm",(void*)f_1215},
{"f_7734csi.scm",(void*)f_7734},
{"f_7738csi.scm",(void*)f_7738},
{"f_7747csi.scm",(void*)f_7747},
{"f_7956csi.scm",(void*)f_7956},
{"f_7969csi.scm",(void*)f_7969},
{"f_7750csi.scm",(void*)f_7750},
{"f_7946csi.scm",(void*)f_7946},
{"f_7954csi.scm",(void*)f_7954},
{"f_7753csi.scm",(void*)f_7753},
{"f_7900csi.scm",(void*)f_7900},
{"f_7933csi.scm",(void*)f_7933},
{"f_7940csi.scm",(void*)f_7940},
{"f_7916csi.scm",(void*)f_7916},
{"f_7765csi.scm",(void*)f_7765},
{"f_7894csi.scm",(void*)f_7894},
{"f_7772csi.scm",(void*)f_7772},
{"f_7774csi.scm",(void*)f_7774},
{"f_7888csi.scm",(void*)f_7888},
{"f_7808csi.scm",(void*)f_7808},
{"f_7862csi.scm",(void*)f_7862},
{"f_7839csi.scm",(void*)f_7839},
{"f_7819csi.scm",(void*)f_7819},
{"f_7794csi.scm",(void*)f_7794},
{"f_7802csi.scm",(void*)f_7802},
{"f_7792csi.scm",(void*)f_7792},
{"f_7754csi.scm",(void*)f_7754},
{"f_7694csi.scm",(void*)f_7694},
{"f_7717csi.scm",(void*)f_7717},
{"f_7721csi.scm",(void*)f_7721},
{"f_7663csi.scm",(void*)f_7663},
{"f_7684csi.scm",(void*)f_7684},
{"f_1218csi.scm",(void*)f_1218},
{"f_7612csi.scm",(void*)f_7612},
{"f_7616csi.scm",(void*)f_7616},
{"f_7627csi.scm",(void*)f_7627},
{"f_7652csi.scm",(void*)f_7652},
{"f_1221csi.scm",(void*)f_1221},
{"f_7492csi.scm",(void*)f_7492},
{"f_7496csi.scm",(void*)f_7496},
{"f_7606csi.scm",(void*)f_7606},
{"f_7604csi.scm",(void*)f_7604},
{"f_7505csi.scm",(void*)f_7505},
{"f_7592csi.scm",(void*)f_7592},
{"f_7600csi.scm",(void*)f_7600},
{"f_7508csi.scm",(void*)f_7508},
{"f_7586csi.scm",(void*)f_7586},
{"f_7528csi.scm",(void*)f_7528},
{"f_7538csi.scm",(void*)f_7538},
{"f_7558csi.scm",(void*)f_7558},
{"f_7564csi.scm",(void*)f_7564},
{"f_7572csi.scm",(void*)f_7572},
{"f_7562csi.scm",(void*)f_7562},
{"f_7536csi.scm",(void*)f_7536},
{"f_7532csi.scm",(void*)f_7532},
{"f_7509csi.scm",(void*)f_7509},
{"f_1224csi.scm",(void*)f_1224},
{"f_7471csi.scm",(void*)f_7471},
{"f_7475csi.scm",(void*)f_7475},
{"f_1227csi.scm",(void*)f_1227},
{"f_7461csi.scm",(void*)f_7461},
{"f_1233csi.scm",(void*)f_1233},
{"f_1242csi.scm",(void*)f_1242},
{"f_1258csi.scm",(void*)f_1258},
{"f_1245csi.scm",(void*)f_1245},
{"f_1306csi.scm",(void*)f_1306},
{"f_7440csi.scm",(void*)f_7440},
{"f_7444csi.scm",(void*)f_7444},
{"f_1309csi.scm",(void*)f_1309},
{"f_7324csi.scm",(void*)f_7324},
{"f_7328csi.scm",(void*)f_7328},
{"f_7337csi.scm",(void*)f_7337},
{"f_7351csi.scm",(void*)f_7351},
{"f_7415csi.scm",(void*)f_7415},
{"f_7397csi.scm",(void*)f_7397},
{"f_7380csi.scm",(void*)f_7380},
{"f_1312csi.scm",(void*)f_1312},
{"f_7225csi.scm",(void*)f_7225},
{"f_7235csi.scm",(void*)f_7235},
{"f_7248csi.scm",(void*)f_7248},
{"f_7264csi.scm",(void*)f_7264},
{"f_7302csi.scm",(void*)f_7302},
{"f_7300csi.scm",(void*)f_7300},
{"f_7292csi.scm",(void*)f_7292},
{"f_7246csi.scm",(void*)f_7246},
{"f_1315csi.scm",(void*)f_1315},
{"f_7136csi.scm",(void*)f_7136},
{"f_7146csi.scm",(void*)f_7146},
{"f_7159csi.scm",(void*)f_7159},
{"f_7175csi.scm",(void*)f_7175},
{"f_7203csi.scm",(void*)f_7203},
{"f_7157csi.scm",(void*)f_7157},
{"f_1318csi.scm",(void*)f_1318},
{"f_6850csi.scm",(void*)f_6850},
{"f_7047csi.scm",(void*)f_7047},
{"f_7050csi.scm",(void*)f_7050},
{"f_7053csi.scm",(void*)f_7053},
{"f_7126csi.scm",(void*)f_7126},
{"f_7134csi.scm",(void*)f_7134},
{"f_7069csi.scm",(void*)f_7069},
{"f_7072csi.scm",(void*)f_7072},
{"f_7075csi.scm",(void*)f_7075},
{"f_7078csi.scm",(void*)f_7078},
{"f_7116csi.scm",(void*)f_7116},
{"f_7124csi.scm",(void*)f_7124},
{"f_7081csi.scm",(void*)f_7081},
{"f_6861csi.scm",(void*)f_6861},
{"f_6865csi.scm",(void*)f_6865},
{"f_6869csi.scm",(void*)f_6869},
{"f_6871csi.scm",(void*)f_6871},
{"f_6916csi.scm",(void*)f_6916},
{"f_6928csi.scm",(void*)f_6928},
{"f_6924csi.scm",(void*)f_6924},
{"f_6892csi.scm",(void*)f_6892},
{"f_7084csi.scm",(void*)f_7084},
{"f_6944csi.scm",(void*)f_6944},
{"f_7044csi.scm",(void*)f_7044},
{"f_7008csi.scm",(void*)f_7008},
{"f_6978csi.scm",(void*)f_6978},
{"f_7087csi.scm",(void*)f_7087},
{"f_7054csi.scm",(void*)f_7054},
{"f_7066csi.scm",(void*)f_7066},
{"f_7062csi.scm",(void*)f_7062},
{"f_1321csi.scm",(void*)f_1321},
{"f_6793csi.scm",(void*)f_6793},
{"f_6797csi.scm",(void*)f_6797},
{"f_1324csi.scm",(void*)f_1324},
{"f_6787csi.scm",(void*)f_6787},
{"f_1327csi.scm",(void*)f_1327},
{"f_6634csi.scm",(void*)f_6634},
{"f_6638csi.scm",(void*)f_6638},
{"f_6641csi.scm",(void*)f_6641},
{"f_6644csi.scm",(void*)f_6644},
{"f_6657csi.scm",(void*)f_6657},
{"f_6707csi.scm",(void*)f_6707},
{"f_6718csi.scm",(void*)f_6718},
{"f_6655csi.scm",(void*)f_6655},
{"f_1330csi.scm",(void*)f_1330},
{"f_6358csi.scm",(void*)f_6358},
{"f_6392csi.scm",(void*)f_6392},
{"f_6395csi.scm",(void*)f_6395},
{"f_6621csi.scm",(void*)f_6621},
{"f_6631csi.scm",(void*)f_6631},
{"f_6619csi.scm",(void*)f_6619},
{"f_6398csi.scm",(void*)f_6398},
{"f_6367csi.scm",(void*)f_6367},
{"f_6381csi.scm",(void*)f_6381},
{"f_6385csi.scm",(void*)f_6385},
{"f_6401csi.scm",(void*)f_6401},
{"f_6404csi.scm",(void*)f_6404},
{"f_6407csi.scm",(void*)f_6407},
{"f_6414csi.scm",(void*)f_6414},
{"f_6428csi.scm",(void*)f_6428},
{"f_6438csi.scm",(void*)f_6438},
{"f_6442csi.scm",(void*)f_6442},
{"f_6452csi.scm",(void*)f_6452},
{"f_6468csi.scm",(void*)f_6468},
{"f_6487csi.scm",(void*)f_6487},
{"f_6543csi.scm",(void*)f_6543},
{"f_6554csi.scm",(void*)f_6554},
{"f_6472csi.scm",(void*)f_6472},
{"f_6485csi.scm",(void*)f_6485},
{"f_6458csi.scm",(void*)f_6458},
{"f_6466csi.scm",(void*)f_6466},
{"f_6456csi.scm",(void*)f_6456},
{"f_6426csi.scm",(void*)f_6426},
{"f_1333csi.scm",(void*)f_1333},
{"f_6301csi.scm",(void*)f_6301},
{"f_6341csi.scm",(void*)f_6341},
{"f_6311csi.scm",(void*)f_6311},
{"f_1336csi.scm",(void*)f_1336},
{"f_6225csi.scm",(void*)f_6225},
{"f_6229csi.scm",(void*)f_6229},
{"f_6232csi.scm",(void*)f_6232},
{"f_1339csi.scm",(void*)f_1339},
{"f_6041csi.scm",(void*)f_6041},
{"f_6045csi.scm",(void*)f_6045},
{"f_6048csi.scm",(void*)f_6048},
{"f_6191csi.scm",(void*)f_6191},
{"f_6187csi.scm",(void*)f_6187},
{"f_6050csi.scm",(void*)f_6050},
{"f_6138csi.scm",(void*)f_6138},
{"f_6136csi.scm",(void*)f_6136},
{"f_6106csi.scm",(void*)f_6106},
{"f_6073csi.scm",(void*)f_6073},
{"f_1342csi.scm",(void*)f_1342},
{"f_5851csi.scm",(void*)f_5851},
{"f_5858csi.scm",(void*)f_5858},
{"f_6032csi.scm",(void*)f_6032},
{"f_6030csi.scm",(void*)f_6030},
{"f_5883csi.scm",(void*)f_5883},
{"f_5909csi.scm",(void*)f_5909},
{"f_5937csi.scm",(void*)f_5937},
{"f_5929csi.scm",(void*)f_5929},
{"f_5921csi.scm",(void*)f_5921},
{"f_5881csi.scm",(void*)f_5881},
{"f_1345csi.scm",(void*)f_1345},
{"f_5842csi.scm",(void*)f_5842},
{"f_5846csi.scm",(void*)f_5846},
{"f_1348csi.scm",(void*)f_1348},
{"f_5823csi.scm",(void*)f_5823},
{"f_5827csi.scm",(void*)f_5827},
{"f_5836csi.scm",(void*)f_5836},
{"f_5834csi.scm",(void*)f_5834},
{"f_1351csi.scm",(void*)f_1351},
{"f_5804csi.scm",(void*)f_5804},
{"f_5808csi.scm",(void*)f_5808},
{"f_5817csi.scm",(void*)f_5817},
{"f_5815csi.scm",(void*)f_5815},
{"f_1354csi.scm",(void*)f_1354},
{"f_5676csi.scm",(void*)f_5676},
{"f_5682csi.scm",(void*)f_5682},
{"f_5763csi.scm",(void*)f_5763},
{"f_5692csi.scm",(void*)f_5692},
{"f_5695csi.scm",(void*)f_5695},
{"f_5701csi.scm",(void*)f_5701},
{"f_5708csi.scm",(void*)f_5708},
{"f_5724csi.scm",(void*)f_5724},
{"f_1357csi.scm",(void*)f_1357},
{"f_5533csi.scm",(void*)f_5533},
{"f_5539csi.scm",(void*)f_5539},
{"f_5651csi.scm",(void*)f_5651},
{"f_5624csi.scm",(void*)f_5624},
{"f_5549csi.scm",(void*)f_5549},
{"f_5552csi.scm",(void*)f_5552},
{"f_5558csi.scm",(void*)f_5558},
{"f_5569csi.scm",(void*)f_5569},
{"f_5585csi.scm",(void*)f_5585},
{"f_1360csi.scm",(void*)f_1360},
{"f_5474csi.scm",(void*)f_5474},
{"f_1363csi.scm",(void*)f_1363},
{"f_5303csi.scm",(void*)f_5303},
{"f_5309csi.scm",(void*)f_5309},
{"f_5383csi.scm",(void*)f_5383},
{"f_5386csi.scm",(void*)f_5386},
{"f_5459csi.scm",(void*)f_5459},
{"f_5452csi.scm",(void*)f_5452},
{"f_5444csi.scm",(void*)f_5444},
{"f_5431csi.scm",(void*)f_5431},
{"f_5410csi.scm",(void*)f_5410},
{"f_5319csi.scm",(void*)f_5319},
{"f_1366csi.scm",(void*)f_1366},
{"f_5252csi.scm",(void*)f_5252},
{"f_1369csi.scm",(void*)f_1369},
{"f_5192csi.scm",(void*)f_5192},
{"f_5202csi.scm",(void*)f_5202},
{"f_5221csi.scm",(void*)f_5221},
{"f_5205csi.scm",(void*)f_5205},
{"f_1372csi.scm",(void*)f_1372},
{"f_1375csi.scm",(void*)f_1375},
{"f_1491csi.scm",(void*)f_1491},
{"f_5186csi.scm",(void*)f_5186},
{"f_1728csi.scm",(void*)f_1728},
{"f_1757csi.scm",(void*)f_1757},
{"f_3042csi.scm",(void*)f_3042},
{"f_5178csi.scm",(void*)f_5178},
{"f_5184csi.scm",(void*)f_5184},
{"f_5181csi.scm",(void*)f_5181},
{"f_4437csi.scm",(void*)f_4437},
{"f_5172csi.scm",(void*)f_5172},
{"f_4441csi.scm",(void*)f_4441},
{"f_5168csi.scm",(void*)f_5168},
{"f_4444csi.scm",(void*)f_4444},
{"f_4447csi.scm",(void*)f_4447},
{"f_4450csi.scm",(void*)f_4450},
{"f_5164csi.scm",(void*)f_5164},
{"f_5151csi.scm",(void*)f_5151},
{"f_5111csi.scm",(void*)f_5111},
{"f_5061csi.scm",(void*)f_5061},
{"f_5064csi.scm",(void*)f_5064},
{"f_5067csi.scm",(void*)f_5067},
{"f_5070csi.scm",(void*)f_5070},
{"f_5079csi.scm",(void*)f_5079},
{"f_4453csi.scm",(void*)f_4453},
{"f_4456csi.scm",(void*)f_4456},
{"f_5055csi.scm",(void*)f_5055},
{"f_4459csi.scm",(void*)f_4459},
{"f_4462csi.scm",(void*)f_4462},
{"f_5046csi.scm",(void*)f_5046},
{"f_5042csi.scm",(void*)f_5042},
{"f_4468csi.scm",(void*)f_4468},
{"f_4620csi.scm",(void*)f_4620},
{"f_5031csi.scm",(void*)f_5031},
{"f_5034csi.scm",(void*)f_5034},
{"f_4623csi.scm",(void*)f_4623},
{"f_5022csi.scm",(void*)f_5022},
{"f_5025csi.scm",(void*)f_5025},
{"f_4626csi.scm",(void*)f_4626},
{"f_5019csi.scm",(void*)f_5019},
{"f_5012csi.scm",(void*)f_5012},
{"f_4629csi.scm",(void*)f_4629},
{"f_4999csi.scm",(void*)f_4999},
{"f_5002csi.scm",(void*)f_5002},
{"f_4632csi.scm",(void*)f_4632},
{"f_4993csi.scm",(void*)f_4993},
{"f_4635csi.scm",(void*)f_4635},
{"f_4978csi.scm",(void*)f_4978},
{"f_4981csi.scm",(void*)f_4981},
{"f_4984csi.scm",(void*)f_4984},
{"f_4638csi.scm",(void*)f_4638},
{"f_4975csi.scm",(void*)f_4975},
{"f_4641csi.scm",(void*)f_4641},
{"f_4971csi.scm",(void*)f_4971},
{"f_4644csi.scm",(void*)f_4644},
{"f_4967csi.scm",(void*)f_4967},
{"f_4955csi.scm",(void*)f_4955},
{"f_4963csi.scm",(void*)f_4963},
{"f_4959csi.scm",(void*)f_4959},
{"f_4951csi.scm",(void*)f_4951},
{"f_4648csi.scm",(void*)f_4648},
{"f_4655csi.scm",(void*)f_4655},
{"f_4658csi.scm",(void*)f_4658},
{"f_4885csi.scm",(void*)f_4885},
{"f_4517csi.scm",(void*)f_4517},
{"f_4523csi.scm",(void*)f_4523},
{"f_4545csi.scm",(void*)f_4545},
{"f_4529csi.scm",(void*)f_4529},
{"f_4532csi.scm",(void*)f_4532},
{"f_4538csi.scm",(void*)f_4538},
{"f_4661csi.scm",(void*)f_4661},
{"f_4666csi.scm",(void*)f_4666},
{"f_4818csi.scm",(void*)f_4818},
{"f_4824csi.scm",(void*)f_4824},
{"f_4839csi.scm",(void*)f_4839},
{"f_4850csi.scm",(void*)f_4850},
{"f_4829csi.scm",(void*)f_4829},
{"f_4837csi.scm",(void*)f_4837},
{"f_4811csi.scm",(void*)f_4811},
{"f_4801csi.scm",(void*)f_4801},
{"f_4785csi.scm",(void*)f_4785},
{"f_4775csi.scm",(void*)f_4775},
{"f_4755csi.scm",(void*)f_4755},
{"f_4739csi.scm",(void*)f_4739},
{"f_4723csi.scm",(void*)f_4723},
{"f_4694csi.scm",(void*)f_4694},
{"f_4679csi.scm",(void*)f_4679},
{"f_4550csi.scm",(void*)f_4550},
{"f_4597csi.scm",(void*)f_4597},
{"f_4554csi.scm",(void*)f_4554},
{"f_4557csi.scm",(void*)f_4557},
{"f_4564csi.scm",(void*)f_4564},
{"f_4566csi.scm",(void*)f_4566},
{"f_4589csi.scm",(void*)f_4589},
{"f_4587csi.scm",(void*)f_4587},
{"f_4576csi.scm",(void*)f_4576},
{"f_4583csi.scm",(void*)f_4583},
{"f_4470csi.scm",(void*)f_4470},
{"f_4476csi.scm",(void*)f_4476},
{"f_4503csi.scm",(void*)f_4503},
{"f_4294csi.scm",(void*)f_4294},
{"f_4300csi.scm",(void*)f_4300},
{"f_4322csi.scm",(void*)f_4322},
{"f_4379csi.scm",(void*)f_4379},
{"f_4372csi.scm",(void*)f_4372},
{"f_4338csi.scm",(void*)f_4338},
{"f_4361csi.scm",(void*)f_4361},
{"f_4351csi.scm",(void*)f_4351},
{"f_4355csi.scm",(void*)f_4355},
{"f_4411csi.scm",(void*)f_4411},
{"f_4237csi.scm",(void*)f_4237},
{"f_4243csi.scm",(void*)f_4243},
{"f_4255csi.scm",(void*)f_4255},
{"f_4178csi.scm",(void*)f_4178},
{"f_4182csi.scm",(void*)f_4182},
{"f_4187csi.scm",(void*)f_4187},
{"f_4216csi.scm",(void*)f_4216},
{"f_4203csi.scm",(void*)f_4203},
{"f_3969csi.scm",(void*)f_3969},
{"f_4001csi.scm",(void*)f_4001},
{"f_4176csi.scm",(void*)f_4176},
{"f_4011csi.scm",(void*)f_4011},
{"f_4014csi.scm",(void*)f_4014},
{"f_4086csi.scm",(void*)f_4086},
{"f_4147csi.scm",(void*)f_4147},
{"f_4169csi.scm",(void*)f_4169},
{"f_4165csi.scm",(void*)f_4165},
{"f_4150csi.scm",(void*)f_4150},
{"f_4105csi.scm",(void*)f_4105},
{"f_4123csi.scm",(void*)f_4123},
{"f_4133csi.scm",(void*)f_4133},
{"f_4017csi.scm",(void*)f_4017},
{"f_4020csi.scm",(void*)f_4020},
{"f_4035csi.scm",(void*)f_4035},
{"f_4048csi.scm",(void*)f_4048},
{"f_4051csi.scm",(void*)f_4051},
{"f_4023csi.scm",(void*)f_4023},
{"f_4026csi.scm",(void*)f_4026},
{"f_3972csi.scm",(void*)f_3972},
{"f_3976csi.scm",(void*)f_3976},
{"f_3992csi.scm",(void*)f_3992},
{"f_3808csi.scm",(void*)f_3808},
{"f_3921csi.scm",(void*)f_3921},
{"f_3916csi.scm",(void*)f_3916},
{"f_3810csi.scm",(void*)f_3810},
{"f_3835csi.scm",(void*)f_3835},
{"f_3878csi.scm",(void*)f_3878},
{"f_3888csi.scm",(void*)f_3888},
{"f_3859csi.scm",(void*)f_3859},
{"f_3842csi.scm",(void*)f_3842},
{"f_3813csi.scm",(void*)f_3813},
{"f_3802csi.scm",(void*)f_3802},
{"f_3044csi.scm",(void*)f_3044},
{"f_3048csi.scm",(void*)f_3048},
{"f_3781csi.scm",(void*)f_3781},
{"f_3176csi.scm",(void*)f_3176},
{"f_3275csi.scm",(void*)f_3275},
{"f_3422csi.scm",(void*)f_3422},
{"f_3450csi.scm",(void*)f_3450},
{"f_3459csi.scm",(void*)f_3459},
{"f_3553csi.scm",(void*)f_3553},
{"f_3687csi.scm",(void*)f_3687},
{"f_3702csi.scm",(void*)f_3702},
{"f_3741csi.scm",(void*)f_3741},
{"f_3730csi.scm",(void*)f_3730},
{"f_3726csi.scm",(void*)f_3726},
{"f_3709csi.scm",(void*)f_3709},
{"f_3620csi.scm",(void*)f_3620},
{"f_3625csi.scm",(void*)f_3625},
{"f_3629csi.scm",(void*)f_3629},
{"f_3638csi.scm",(void*)f_3638},
{"f_3673csi.scm",(void*)f_3673},
{"f_3665csi.scm",(void*)f_3665},
{"f_3648csi.scm",(void*)f_3648},
{"f_3584csi.scm",(void*)f_3584},
{"f_3587csi.scm",(void*)f_3587},
{"f_3592csi.scm",(void*)f_3592},
{"f_3572csi.scm",(void*)f_3572},
{"f_3559csi.scm",(void*)f_3559},
{"f_3547csi.scm",(void*)f_3547},
{"f_3466csi.scm",(void*)f_3466},
{"f_3477csi.scm",(void*)f_3477},
{"f_3441csi.scm",(void*)f_3441},
{"f_3382csi.scm",(void*)f_3382},
{"f_3396csi.scm",(void*)f_3396},
{"f_3392csi.scm",(void*)f_3392},
{"f_3338csi.scm",(void*)f_3338},
{"f_3305csi.scm",(void*)f_3305},
{"f_3318csi.scm",(void*)f_3318},
{"f_3308csi.scm",(void*)f_3308},
{"f_3315csi.scm",(void*)f_3315},
{"f_3245csi.scm",(void*)f_3245},
{"f_3251csi.scm",(void*)f_3251},
{"f_3179csi.scm",(void*)f_3179},
{"f_3050csi.scm",(void*)f_3050},
{"f_3173csi.scm",(void*)f_3173},
{"f_3057csi.scm",(void*)f_3057},
{"f_3062csi.scm",(void*)f_3062},
{"f_3085csi.scm",(void*)f_3085},
{"f_3094csi.scm",(void*)f_3094},
{"f_3158csi.scm",(void*)f_3158},
{"f_3104csi.scm",(void*)f_3104},
{"f_3107csi.scm",(void*)f_3107},
{"f_2848csi.scm",(void*)f_2848},
{"f_2856csi.scm",(void*)f_2856},
{"f_2858csi.scm",(void*)f_2858},
{"f_2862csi.scm",(void*)f_2862},
{"f_2865csi.scm",(void*)f_2865},
{"f_2868csi.scm",(void*)f_2868},
{"f_2885csi.scm",(void*)f_2885},
{"f_3028csi.scm",(void*)f_3028},
{"f_3024csi.scm",(void*)f_3024},
{"f_3020csi.scm",(void*)f_3020},
{"f_2987csi.scm",(void*)f_2987},
{"f_2991csi.scm",(void*)f_2991},
{"f_2996csi.scm",(void*)f_2996},
{"f_3004csi.scm",(void*)f_3004},
{"f_2888csi.scm",(void*)f_2888},
{"f_2916csi.scm",(void*)f_2916},
{"f_2924csi.scm",(void*)f_2924},
{"f_2928csi.scm",(void*)f_2928},
{"f_2932csi.scm",(void*)f_2932},
{"f_2936csi.scm",(void*)f_2936},
{"f_2940csi.scm",(void*)f_2940},
{"f_2891csi.scm",(void*)f_2891},
{"f_2894csi.scm",(void*)f_2894},
{"f_2897csi.scm",(void*)f_2897},
{"f_2900csi.scm",(void*)f_2900},
{"f_2870csi.scm",(void*)f_2870},
{"f_2878csi.scm",(void*)f_2878},
{"f_2745csi.scm",(void*)f_2745},
{"f_2749csi.scm",(void*)f_2749},
{"f_2779csi.scm",(void*)f_2779},
{"f_2797csi.scm",(void*)f_2797},
{"f_2836csi.scm",(void*)f_2836},
{"f_2842csi.scm",(void*)f_2842},
{"f_2803csi.scm",(void*)f_2803},
{"f_2811csi.scm",(void*)f_2811},
{"f_2813csi.scm",(void*)f_2813},
{"f_2830csi.scm",(void*)f_2830},
{"f_2785csi.scm",(void*)f_2785},
{"f_2791csi.scm",(void*)f_2791},
{"f_2777csi.scm",(void*)f_2777},
{"f_2774csi.scm",(void*)f_2774},
{"f_2754csi.scm",(void*)f_2754},
{"f_2764csi.scm",(void*)f_2764},
{"f_2767csi.scm",(void*)f_2767},
{"f_2721csi.scm",(void*)f_2721},
{"f_2731csi.scm",(void*)f_2731},
{"f_2725csi.scm",(void*)f_2725},
{"f_2430csi.scm",(void*)f_2430},
{"f_2435csi.scm",(void*)f_2435},
{"f_2438csi.scm",(void*)f_2438},
{"f_2441csi.scm",(void*)f_2441},
{"f_2444csi.scm",(void*)f_2444},
{"f_2455csi.scm",(void*)f_2455},
{"f_2459csi.scm",(void*)f_2459},
{"f_2447csi.scm",(void*)f_2447},
{"f_2450csi.scm",(void*)f_2450},
{"f_2407csi.scm",(void*)f_2407},
{"f_2411csi.scm",(void*)f_2411},
{"f_2415csi.scm",(void*)f_2415},
{"f_2418csi.scm",(void*)f_2418},
{"f_2421csi.scm",(void*)f_2421},
{"f_2379csi.scm",(void*)f_2379},
{"f_2383csi.scm",(void*)f_2383},
{"f_2388csi.scm",(void*)f_2388},
{"f_2398csi.scm",(void*)f_2398},
{"f_2405csi.scm",(void*)f_2405},
{"f_2338csi.scm",(void*)f_2338},
{"f_2344csi.scm",(void*)f_2344},
{"f_2360csi.scm",(void*)f_2360},
{"f_2370csi.scm",(void*)f_2370},
{"f_1800csi.scm",(void*)f_1800},
{"f_1817csi.scm",(void*)f_1817},
{"f_2319csi.scm",(void*)f_2319},
{"f_2323csi.scm",(void*)f_2323},
{"f_2313csi.scm",(void*)f_2313},
{"f_1823csi.scm",(void*)f_1823},
{"f_2299csi.scm",(void*)f_2299},
{"f_2275csi.scm",(void*)f_2275},
{"f_2283csi.scm",(void*)f_2283},
{"f_2278csi.scm",(void*)f_2278},
{"f_2256csi.scm",(void*)f_2256},
{"f_2259csi.scm",(void*)f_2259},
{"f_2262csi.scm",(void*)f_2262},
{"f_2233csi.scm",(void*)f_2233},
{"f_2236csi.scm",(void*)f_2236},
{"f_2243csi.scm",(void*)f_2243},
{"f_2217csi.scm",(void*)f_2217},
{"f_2189csi.scm",(void*)f_2189},
{"f_2166csi.scm",(void*)f_2166},
{"f_2179csi.scm",(void*)f_2179},
{"f_2157csi.scm",(void*)f_2157},
{"f_2153csi.scm",(void*)f_2153},
{"f_2127csi.scm",(void*)f_2127},
{"f_2123csi.scm",(void*)f_2123},
{"f_2119csi.scm",(void*)f_2119},
{"f_2692csi.scm",(void*)f_2692},
{"f_2696csi.scm",(void*)f_2696},
{"f_2715csi.scm",(void*)f_2715},
{"f_2106csi.scm",(void*)f_2106},
{"f_2102csi.scm",(void*)f_2102},
{"f_2098csi.scm",(void*)f_2098},
{"f_2624csi.scm",(void*)f_2624},
{"f_2628csi.scm",(void*)f_2628},
{"f_2673csi.scm",(void*)f_2673},
{"f_2680csi.scm",(void*)f_2680},
{"f_2634csi.scm",(void*)f_2634},
{"f_2655csi.scm",(void*)f_2655},
{"f_2659csi.scm",(void*)f_2659},
{"f_2611csi.scm",(void*)f_2611},
{"f_2085csi.scm",(void*)f_2085},
{"f_2081csi.scm",(void*)f_2081},
{"f_2077csi.scm",(void*)f_2077},
{"f_2570csi.scm",(void*)f_2570},
{"f_2574csi.scm",(void*)f_2574},
{"f_2593csi.scm",(void*)f_2593},
{"f_2064csi.scm",(void*)f_2064},
{"f_2060csi.scm",(void*)f_2060},
{"f_2056csi.scm",(void*)f_2056},
{"f_2489csi.scm",(void*)f_2489},
{"f_2493csi.scm",(void*)f_2493},
{"f_2532csi.scm",(void*)f_2532},
{"f_2536csi.scm",(void*)f_2536},
{"f_2547csi.scm",(void*)f_2547},
{"f_2551csi.scm",(void*)f_2551},
{"f_2541csi.scm",(void*)f_2541},
{"f_2476csi.scm",(void*)f_2476},
{"f_2003csi.scm",(void*)f_2003},
{"f_2036csi.scm",(void*)f_2036},
{"f_2040csi.scm",(void*)f_2040},
{"f_2008csi.scm",(void*)f_2008},
{"f_2012csi.scm",(void*)f_2012},
{"f_2023csi.scm",(void*)f_2023},
{"f_2034csi.scm",(void*)f_2034},
{"f_2027csi.scm",(void*)f_2027},
{"f_2017csi.scm",(void*)f_2017},
{"f_1994csi.scm",(void*)f_1994},
{"f_1969csi.scm",(void*)f_1969},
{"f_1977csi.scm",(void*)f_1977},
{"f_1983csi.scm",(void*)f_1983},
{"f_1987csi.scm",(void*)f_1987},
{"f_1972csi.scm",(void*)f_1972},
{"f_1960csi.scm",(void*)f_1960},
{"f_1950csi.scm",(void*)f_1950},
{"f_1953csi.scm",(void*)f_1953},
{"f_1911csi.scm",(void*)f_1911},
{"f_1914csi.scm",(void*)f_1914},
{"f_1917csi.scm",(void*)f_1917},
{"f_1920csi.scm",(void*)f_1920},
{"f_1896csi.scm",(void*)f_1896},
{"f_1899csi.scm",(void*)f_1899},
{"f_1881csi.scm",(void*)f_1881},
{"f_1884csi.scm",(void*)f_1884},
{"f_1863csi.scm",(void*)f_1863},
{"f_1866csi.scm",(void*)f_1866},
{"f_1869csi.scm",(void*)f_1869},
{"f_1844csi.scm",(void*)f_1844},
{"f_1854csi.scm",(void*)f_1854},
{"f_1847csi.scm",(void*)f_1847},
{"f_1829csi.scm",(void*)f_1829},
{"f_1759csi.scm",(void*)f_1759},
{"f_1763csi.scm",(void*)f_1763},
{"f_1743csi.scm",(void*)f_1743},
{"f_1750csi.scm",(void*)f_1750},
{"f_1730csi.scm",(void*)f_1730},
{"f_1703csi.scm",(void*)f_1703},
{"f_1664csi.scm",(void*)f_1664},
{"f_1688csi.scm",(void*)f_1688},
{"f_1674csi.scm",(void*)f_1674},
{"f_1558csi.scm",(void*)f_1558},
{"f_1562csi.scm",(void*)f_1562},
{"f_1603csi.scm",(void*)f_1603},
{"f_1609csi.scm",(void*)f_1609},
{"f_1616csi.scm",(void*)f_1616},
{"f_1618csi.scm",(void*)f_1618},
{"f_1645csi.scm",(void*)f_1645},
{"f_1628csi.scm",(void*)f_1628},
{"f_1631csi.scm",(void*)f_1631},
{"f_1586csi.scm",(void*)f_1586},
{"f_1600csi.scm",(void*)f_1600},
{"f_1596csi.scm",(void*)f_1596},
{"f_1537csi.scm",(void*)f_1537},
{"f_1510csi.scm",(void*)f_1510},
{"f_1517csi.scm",(void*)f_1517},
{"f_1520csi.scm",(void*)f_1520},
{"f_1526csi.scm",(void*)f_1526},
{"f_1460csi.scm",(void*)f_1460},
{"f_1464csi.scm",(void*)f_1464},
{"f_1448csi.scm",(void*)f_1448},
{"f_1438csi.scm",(void*)f_1438},
{"f_1446csi.scm",(void*)f_1446},
{"f_1409csi.scm",(void*)f_1409},
{"f_1426csi.scm",(void*)f_1426},
{"f_1399csi.scm",(void*)f_1399},
{"f_1407csi.scm",(void*)f_1407},
{"f_1387csi.scm",(void*)f_1387},
{"f_1391csi.scm",(void*)f_1391},
{"f_1394csi.scm",(void*)f_1394},
{"f_1139csi.scm",(void*)f_1139},
{"f_1143csi.scm",(void*)f_1143},
{"f_1180csi.scm",(void*)f_1180},
{"f_1201csi.scm",(void*)f_1201},
{"f_1199csi.scm",(void*)f_1199},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
