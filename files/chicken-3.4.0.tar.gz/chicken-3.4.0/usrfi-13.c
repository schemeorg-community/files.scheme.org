/* Generated from srfi-13.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:56
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: srfi-13.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file usrfi-13.c
   unit: srfi_13
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_14_toplevel)
C_externimport void C_ccall C_srfi_14_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[159];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_13_toplevel)
C_externexport void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_fcall f_7364(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7370)
static void C_fcall f_7370(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_fcall f_7274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7305)
static C_word C_fcall f_7305(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6938)
static void C_fcall f_6938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_fcall f_6820(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6832)
static C_word C_fcall f_6832(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6718)
static void C_fcall f_6718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6768)
static void C_fcall f_6768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6609)
static void C_ccall f_6609(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6609)
static void C_ccall f_6609r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6636)
static C_word C_fcall f_6636(C_word t0,C_word t1);
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6543)
static void C_ccall f_6543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6548)
static C_word C_fcall f_6548(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6577)
static C_word C_fcall f_6577(C_word t0,C_word t1);
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6440)
static void C_fcall f_6440(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static C_word C_fcall f_6499(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6404)
static void C_fcall f_6404(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6349)
static C_word C_fcall f_6349(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static C_word C_fcall f_6300(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6269)
static void C_ccall f_6269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6181)
static void C_fcall f_6181(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6213)
static void C_fcall f_6213(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6211)
static void C_ccall f_6211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6116)
static void C_fcall f_6116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_fcall f_6017(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6032)
static void C_fcall f_6032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_fcall f_5893(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5851)
static void C_fcall f_5851(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5833)
static void C_ccall f_5833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5789)
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static C_word C_fcall f_5750(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4);
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5699)
static C_word C_fcall f_5699(C_word t0,C_word t1);
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_fcall f_5644(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static C_word C_fcall f_5566(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_fcall f_5513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_fcall f_5474(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static C_word C_fcall f_5435(C_word t0,C_word t1);
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_fcall f_5378(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5343)
static void C_fcall f_5343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static C_word C_fcall f_5308(C_word t0,C_word t1);
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_fcall f_5255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5216)
static void C_fcall f_5216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static C_word C_fcall f_5177(C_word t0,C_word t1);
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5085)
static void C_fcall f_5085(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static C_word C_fcall f_5050(C_word t0,C_word t1);
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4957)
static void C_ccall f_4957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_fcall f_4353(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4359)
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4235)
static void C_fcall f_4235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4189)
static void C_fcall f_4189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_fcall f_4107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4125)
static void C_fcall f_4125(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static C_word C_fcall f_4160(C_word t0,C_word t1);
C_noret_decl(f_4109)
static void C_fcall f_4109(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4090)
static void C_fcall f_4090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4042)
static void C_fcall f_4042(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3991)
static void C_fcall f_3991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3940)
static void C_fcall f_3940(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3889)
static void C_fcall f_3889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3814)
static void C_fcall f_3814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3763)
static void C_fcall f_3763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3715)
static void C_fcall f_3715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3664)
static void C_fcall f_3664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3613)
static void C_fcall f_3613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3562)
static void C_fcall f_3562(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3487)
static void C_fcall f_3487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_fcall f_3366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_fcall f_3269(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_fcall f_3304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_fcall f_2852(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_fcall f_2865(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_fcall f_2888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_fcall f_2779(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_fcall f_2792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_fcall f_2797(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_fcall f_2807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_fcall f_2694(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_fcall f_2707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_fcall f_2720(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2730)
static void C_fcall f_2730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_fcall f_2621(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_fcall f_2634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2649)
static void C_fcall f_2649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_fcall f_2598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_fcall f_2552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_fcall f_2511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static C_word C_fcall f_2476(C_word t0,C_word t1);
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_fcall f_2422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_fcall f_2381(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static C_word C_fcall f_2346(C_word t0,C_word t1);
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2303)
static void C_fcall f_2303(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2262)
static void C_fcall f_2262(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_2089)
static void C_fcall f_2089(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static C_word C_fcall f_2176(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_fcall f_1904(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_1910)
static void C_fcall f_1910(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static C_word C_fcall f_1994(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1855)
static void C_fcall f_1855(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1809)
static void C_fcall f_1809(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_fcall f_1758(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1764)
static void C_fcall f_1764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_fcall f_1697(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_fcall f_1709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_fcall f_1639(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1646)
static void C_fcall f_1646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7364)
static void C_fcall trf_7364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7364(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7364(t0,t1,t2,t3);}

C_noret_decl(trf_7370)
static void C_fcall trf_7370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7370(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7370(t0,t1,t2);}

C_noret_decl(trf_7274)
static void C_fcall trf_7274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7274(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7274(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6938)
static void C_fcall trf_6938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6938(t0,t1,t2,t3);}

C_noret_decl(trf_6820)
static void C_fcall trf_6820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6820(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6820(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6718)
static void C_fcall trf_6718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6718(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6718(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6768)
static void C_fcall trf_6768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6768(t0,t1);}

C_noret_decl(trf_6440)
static void C_fcall trf_6440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6440(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6440(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6404)
static void C_fcall trf_6404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6404(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6404(t0,t1,t2,t3);}

C_noret_decl(trf_6181)
static void C_fcall trf_6181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6181(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6181(t0,t1,t2,t3);}

C_noret_decl(trf_6213)
static void C_fcall trf_6213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6213(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6213(t0,t1,t2);}

C_noret_decl(trf_6116)
static void C_fcall trf_6116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6116(t0,t1,t2);}

C_noret_decl(trf_6017)
static void C_fcall trf_6017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6017(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6017(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6032)
static void C_fcall trf_6032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6032(t0,t1,t2);}

C_noret_decl(trf_5893)
static void C_fcall trf_5893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5893(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5893(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5851)
static void C_fcall trf_5851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5851(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5851(t0,t1,t2);}

C_noret_decl(trf_5789)
static void C_fcall trf_5789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5789(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5789(t0,t1,t2);}

C_noret_decl(trf_5644)
static void C_fcall trf_5644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5644(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5644(t0,t1,t2,t3);}

C_noret_decl(trf_5605)
static void C_fcall trf_5605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5605(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5605(t0,t1,t2,t3);}

C_noret_decl(trf_5513)
static void C_fcall trf_5513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5513(t0,t1,t2);}

C_noret_decl(trf_5474)
static void C_fcall trf_5474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5474(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5474(t0,t1,t2);}

C_noret_decl(trf_5378)
static void C_fcall trf_5378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5378(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5378(t0,t1,t2);}

C_noret_decl(trf_5343)
static void C_fcall trf_5343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5343(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5343(t0,t1,t2);}

C_noret_decl(trf_5255)
static void C_fcall trf_5255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5255(t0,t1,t2);}

C_noret_decl(trf_5216)
static void C_fcall trf_5216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5216(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5216(t0,t1,t2);}

C_noret_decl(trf_5120)
static void C_fcall trf_5120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5120(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5120(t0,t1,t2);}

C_noret_decl(trf_5085)
static void C_fcall trf_5085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5085(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5085(t0,t1,t2);}

C_noret_decl(trf_4353)
static void C_fcall trf_4353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4353(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4353(t0,t1,t2,t3);}

C_noret_decl(trf_4359)
static void C_fcall trf_4359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4359(t0,t1,t2);}

C_noret_decl(trf_4235)
static void C_fcall trf_4235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4235(t0,t1);}

C_noret_decl(trf_4189)
static void C_fcall trf_4189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4189(t0,t1);}

C_noret_decl(trf_4107)
static void C_fcall trf_4107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4107(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4107(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4125)
static void C_fcall trf_4125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4125(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4125(t0,t1,t2,t3);}

C_noret_decl(trf_4109)
static void C_fcall trf_4109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4109(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4109(t0,t1,t2,t3);}

C_noret_decl(trf_4090)
static void C_fcall trf_4090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4090(t0,t1);}

C_noret_decl(trf_4042)
static void C_fcall trf_4042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4042(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4042(t0,t1);}

C_noret_decl(trf_3991)
static void C_fcall trf_3991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3991(t0,t1);}

C_noret_decl(trf_3940)
static void C_fcall trf_3940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3940(t0,t1);}

C_noret_decl(trf_3889)
static void C_fcall trf_3889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3889(t0,t1);}

C_noret_decl(trf_3814)
static void C_fcall trf_3814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3814(t0,t1);}

C_noret_decl(trf_3763)
static void C_fcall trf_3763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3763(t0,t1);}

C_noret_decl(trf_3715)
static void C_fcall trf_3715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3715(t0,t1);}

C_noret_decl(trf_3664)
static void C_fcall trf_3664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3664(t0,t1);}

C_noret_decl(trf_3613)
static void C_fcall trf_3613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3613(t0,t1);}

C_noret_decl(trf_3562)
static void C_fcall trf_3562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3562(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3562(t0,t1);}

C_noret_decl(trf_3487)
static void C_fcall trf_3487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3487(t0,t1);}

C_noret_decl(trf_3331)
static void C_fcall trf_3331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3331(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_3331(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_3366)
static void C_fcall trf_3366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3366(t0,t1);}

C_noret_decl(trf_3269)
static void C_fcall trf_3269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3269(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_3269(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_3304)
static void C_fcall trf_3304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3304(t0,t1);}

C_noret_decl(trf_2852)
static void C_fcall trf_2852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2852(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2852(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2865)
static void C_fcall trf_2865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2865(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2865(t0,t1);}

C_noret_decl(trf_2878)
static void C_fcall trf_2878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2878(t0,t1,t2,t3);}

C_noret_decl(trf_2888)
static void C_fcall trf_2888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2888(t0,t1);}

C_noret_decl(trf_2779)
static void C_fcall trf_2779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2779(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2779(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2792)
static void C_fcall trf_2792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2792(t0,t1);}

C_noret_decl(trf_2797)
static void C_fcall trf_2797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2797(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2797(t0,t1,t2,t3);}

C_noret_decl(trf_2807)
static void C_fcall trf_2807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2807(t0,t1);}

C_noret_decl(trf_2694)
static void C_fcall trf_2694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2694(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2694(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2707)
static void C_fcall trf_2707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2707(t0,t1);}

C_noret_decl(trf_2720)
static void C_fcall trf_2720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2720(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2720(t0,t1,t2,t3);}

C_noret_decl(trf_2730)
static void C_fcall trf_2730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2730(t0,t1);}

C_noret_decl(trf_2621)
static void C_fcall trf_2621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2621(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2621(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2634)
static void C_fcall trf_2634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2634(t0,t1);}

C_noret_decl(trf_2639)
static void C_fcall trf_2639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2639(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2639(t0,t1,t2,t3);}

C_noret_decl(trf_2649)
static void C_fcall trf_2649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2649(t0,t1);}

C_noret_decl(trf_2598)
static void C_fcall trf_2598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2598(t0,t1,t2);}

C_noret_decl(trf_2552)
static void C_fcall trf_2552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2552(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2552(t0,t1,t2);}

C_noret_decl(trf_2511)
static void C_fcall trf_2511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2511(t0,t1,t2);}

C_noret_decl(trf_2422)
static void C_fcall trf_2422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2422(t0,t1,t2);}

C_noret_decl(trf_2381)
static void C_fcall trf_2381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2381(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2381(t0,t1,t2);}

C_noret_decl(trf_2303)
static void C_fcall trf_2303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2303(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2303(t0,t1,t2);}

C_noret_decl(trf_2262)
static void C_fcall trf_2262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2262(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2262(t0,t1,t2);}

C_noret_decl(trf_2083)
static void C_fcall trf_2083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2083(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_2083(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_2089)
static void C_fcall trf_2089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2089(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2089(t0,t1,t2,t3);}

C_noret_decl(trf_1904)
static void C_fcall trf_1904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1904(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_1904(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_1910)
static void C_fcall trf_1910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1910(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1910(t0,t1,t2,t3);}

C_noret_decl(trf_1855)
static void C_fcall trf_1855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1855(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1855(t0,t1,t2,t3);}

C_noret_decl(trf_1809)
static void C_fcall trf_1809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1809(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1809(t0,t1,t2,t3);}

C_noret_decl(trf_1758)
static void C_fcall trf_1758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1758(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1758(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1764)
static void C_fcall trf_1764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1764(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1764(t0,t1,t2);}

C_noret_decl(trf_1697)
static void C_fcall trf_1697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1697(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1697(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1709)
static void C_fcall trf_1709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1709(t0,t1,t2,t3);}

C_noret_decl(trf_1639)
static void C_fcall trf_1639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1639(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1639(t0,t1,t2,t3);}

C_noret_decl(trf_1646)
static void C_fcall trf_1646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1646(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr7r)
static void C_fcall tr7r(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7r(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n*3);
t7=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_13_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1090)){
C_save(t1);
C_rereclaim2(1090*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,159);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],22,"string-parse-start+end");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\032Illegal substring END spec");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000 Illegal substring START/END spec");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\034Illegal substring START spec");
lf[7]=C_h_intern(&lf[7],28,"string-parse-final-start+end");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\034Extra arguments to procedure");
lf[9]=C_h_intern(&lf[9],18,"substring-spec-ok\077");
lf[10]=C_h_intern(&lf[10],20,"check-substring-spec");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\027Illegal substring spec.");
lf[12]=C_h_intern(&lf[12],16,"substring/shared");
lf[14]=C_h_intern(&lf[14],13,"\003syssubstring");
lf[15]=C_h_intern(&lf[15],11,"string-copy");
lf[16]=C_h_intern(&lf[16],10,"string-map");
lf[18]=C_h_intern(&lf[18],11,"make-string");
lf[19]=C_h_intern(&lf[19],11,"string-map!");
lf[21]=C_h_intern(&lf[21],11,"string-fold");
lf[22]=C_h_intern(&lf[22],17,"string-fold-right");
lf[23]=C_h_intern(&lf[23],13,"string-unfold");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[27]=C_h_intern(&lf[27],3,"min");
lf[28]=C_h_intern(&lf[28],19,"string-unfold-right");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[31]=C_h_intern(&lf[31],15,"string-for-each");
lf[32]=C_h_intern(&lf[32],21,"string-for-each-index");
lf[33]=C_h_intern(&lf[33],12,"string-every");
lf[34]=C_h_intern(&lf[34],18,"char-set-contains\077");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[36]=C_h_intern(&lf[36],9,"char-set\077");
lf[37]=C_h_intern(&lf[37],10,"string-any");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[39]=C_h_intern(&lf[39],15,"string-tabulate");
lf[43]=C_h_intern(&lf[43],9,"char-ci=\077");
lf[45]=C_h_intern(&lf[45],20,"string-prefix-length");
lf[46]=C_h_intern(&lf[46],20,"string-suffix-length");
lf[47]=C_h_intern(&lf[47],23,"string-prefix-length-ci");
lf[48]=C_h_intern(&lf[48],23,"string-suffix-length-ci");
lf[49]=C_h_intern(&lf[49],14,"string-prefix\077");
lf[50]=C_h_intern(&lf[50],14,"string-suffix\077");
lf[51]=C_h_intern(&lf[51],17,"string-prefix-ci\077");
lf[52]=C_h_intern(&lf[52],17,"string-suffix-ci\077");
lf[55]=C_h_intern(&lf[55],9,"char-ci<\077");
lf[56]=C_h_intern(&lf[56],14,"string-compare");
lf[57]=C_h_intern(&lf[57],17,"string-compare-ci");
lf[58]=C_h_intern(&lf[58],7,"string=");
lf[59]=C_h_intern(&lf[59],6,"values");
lf[60]=C_h_intern(&lf[60],8,"string<>");
lf[61]=C_h_intern(&lf[61],7,"string<");
lf[62]=C_h_intern(&lf[62],7,"string>");
lf[63]=C_h_intern(&lf[63],8,"string<=");
lf[64]=C_h_intern(&lf[64],8,"string>=");
lf[65]=C_h_intern(&lf[65],10,"string-ci=");
lf[66]=C_h_intern(&lf[66],11,"string-ci<>");
lf[67]=C_h_intern(&lf[67],10,"string-ci<");
lf[68]=C_h_intern(&lf[68],10,"string-ci>");
lf[69]=C_h_intern(&lf[69],11,"string-ci<=");
lf[70]=C_h_intern(&lf[70],11,"string-ci>=");
lf[72]=C_h_intern(&lf[72],6,"modulo");
lf[73]=C_h_intern(&lf[73],11,"string-hash");
lf[74]=C_h_intern(&lf[74],13,"char->integer");
lf[75]=C_h_intern(&lf[75],14,"string-hash-ci");
lf[76]=C_h_intern(&lf[76],13,"string-upcase");
lf[77]=C_h_intern(&lf[77],11,"char-upcase");
lf[78]=C_h_intern(&lf[78],14,"string-upcase!");
lf[79]=C_h_intern(&lf[79],15,"string-downcase");
lf[80]=C_h_intern(&lf[80],13,"char-downcase");
lf[81]=C_h_intern(&lf[81],16,"string-downcase!");
lf[83]=C_h_intern(&lf[83],11,"string-skip");
lf[84]=C_h_intern(&lf[84],12,"string-index");
lf[85]=C_h_intern(&lf[85],17,"string-titlecase!");
lf[86]=C_h_intern(&lf[86],16,"string-titlecase");
lf[87]=C_h_intern(&lf[87],11,"string-take");
lf[88]=C_h_intern(&lf[88],15,"\003syscheck-range");
lf[89]=C_h_intern(&lf[89],17,"string-take-right");
lf[90]=C_h_intern(&lf[90],11,"string-drop");
lf[91]=C_h_intern(&lf[91],17,"string-drop-right");
lf[92]=C_h_intern(&lf[92],11,"string-trim");
lf[93]=C_h_intern(&lf[93],19,"char-set:whitespace");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[95]=C_h_intern(&lf[95],17,"string-trim-right");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[97]=C_h_intern(&lf[97],17,"string-skip-right");
lf[98]=C_h_intern(&lf[98],16,"string-trim-both");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[100]=C_h_intern(&lf[100],16,"string-pad-right");
lf[101]=C_h_intern(&lf[101],10,"string-pad");
lf[102]=C_h_intern(&lf[102],13,"string-delete");
lf[103]=C_h_intern(&lf[103],8,"char-set");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\0006string-delete criteria not predicate, char or char-set");
lf[105]=C_h_intern(&lf[105],13,"string-filter");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\0006string-delete criteria not predicate, char or char-set");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[108]=C_h_intern(&lf[108],18,"string-index-right");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000+CRITERIA param is neither char-set or char.");
lf[112]=C_h_intern(&lf[112],12,"string-count");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000+CRITERIA param is neither char-set or char.");
lf[114]=C_h_intern(&lf[114],12,"string-fill!");
lf[115]=C_h_intern(&lf[115],12,"string-copy!");
lf[116]=C_h_intern(&lf[116],15,"string-contains");
lf[117]=C_h_intern(&lf[117],18,"string-contains-ci");
lf[119]=C_h_intern(&lf[119],23,"make-kmp-restart-vector");
lf[120]=C_h_intern(&lf[120],6,"char=\077");
lf[121]=C_h_intern(&lf[121],11,"make-vector");
lf[122]=C_h_intern(&lf[122],8,"kmp-step");
lf[123]=C_h_intern(&lf[123],25,"string-kmp-partial-search");
lf[124]=C_h_intern(&lf[124],12,"string-null\077");
lf[125]=C_h_intern(&lf[125],14,"string-reverse");
lf[126]=C_h_intern(&lf[126],15,"string-reverse!");
lf[127]=C_h_intern(&lf[127],12,"string->list");
lf[128]=C_h_intern(&lf[128],20,"string-append/shared");
lf[129]=C_h_intern(&lf[129],25,"string-concatenate/shared");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[131]=C_h_intern(&lf[131],18,"string-concatenate");
lf[132]=C_h_intern(&lf[132],26,"string-concatenate-reverse");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[135]=C_h_intern(&lf[135],33,"string-concatenate-reverse/shared");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[137]=C_h_intern(&lf[137],14,"string-replace");
lf[138]=C_h_intern(&lf[138],15,"string-tokenize");
lf[139]=C_h_intern(&lf[139],16,"char-set:graphic");
lf[140]=C_h_intern(&lf[140],10,"xsubstring");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\042Cannot replicate empty (sub)string");
lf[145]=C_h_intern(&lf[145],13,"string-xcopy!");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\042Cannot replicate empty (sub)string");
lf[147]=C_h_intern(&lf[147],11,"string-join");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[149]=C_h_intern(&lf[149],5,"infix");
lf[150]=C_h_intern(&lf[150],12,"strict-infix");
lf[151]=C_h_intern(&lf[151],6,"prefix");
lf[152]=C_h_intern(&lf[152],6,"suffix");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\024Illegal join grammar");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\0006Empty list cannot be joined with STRICT-INFIX grammar.");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\033STRINGS parameter not list.");
lf[157]=C_h_intern(&lf[157],17,"register-feature!");
lf[158]=C_h_intern(&lf[158],7,"srfi-13");
C_register_lf2(lf,159,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1428,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1426 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 64   register-feature! */
t3=*((C_word*)lf[157]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[158]);}

/* k1429 in k1426 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word ab[198],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1433,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1526,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1553,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1593,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1609,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1639,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1661,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1679,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1697,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1740,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[20],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1758,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1791,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1833,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1879,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2058,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2244,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2285,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2322,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2452,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2582,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[40],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2621,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[41],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2694,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2779,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[44],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2852,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2937,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2967,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2997,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3027,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3057,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3087,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3117,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3147,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[53],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3269,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate(&lf[54],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3331,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3393,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3423,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3453,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3515,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3582,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3633,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3684,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3732,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3780,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3842,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3909,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3960,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4011,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4059,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate(&lf[71],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4107,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4179,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4225,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4281,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4299,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4317,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4335,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate(&lf[82],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4353,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4412,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4430,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4455,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4475,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4502,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4525,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4552,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4594,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4640,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4690,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4748,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4810,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4918,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5026,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5149,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5284,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5407,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5542,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5677,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5718,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate(&lf[26],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5750,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5753,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5815,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate(&lf[118],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5877,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5975,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6110,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6148,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6269,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6272,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6327,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6382,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6428,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6434,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6536,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6609,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6694,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate(&lf[134],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6820,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6863,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6914,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6996,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate(&lf[144],*((C_word*)lf[114]+1));
t99=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7134,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate(&lf[143],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7274,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[147]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7347,tmp=(C_word)a,a+=2,tmp));
t102=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t102+1)))(2,t102,C_SCHEME_UNDEFINED);}

/* string-join in k1429 in k1426 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_7347r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7347r(t0,t1,t2,t3);}}

static void C_ccall f_7347r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a=C_alloc(17);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[148]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?lf[149]:(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7364,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t9,lf[149]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[150]));
if(C_truep(t15)){
t16=(C_word)C_u_i_car(t2);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7426,a[2]=t16,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_slot(t2,C_fix(1));
/* srfi-13.scm: 1930 buildit */
t19=t12;
f_7364(t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t9,lf[151]);
if(C_truep(t16)){
/* srfi-13.scm: 1932 buildit */
t17=t12;
f_7364(t17,t13,t2,C_SCHEME_END_OF_LIST);}
else{
t17=(C_word)C_eqp(t9,lf[152]);
if(C_truep(t17)){
t18=(C_word)C_u_i_car(t2);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7456,a[2]=t18,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_slot(t2,C_fix(1));
t21=(C_word)C_a_i_list(&a,1,t5);
/* srfi-13.scm: 1935 buildit */
t22=t12;
f_7364(t22,t19,t20,t21);}
else{
/* srfi-13.scm: 1937 ##sys#error */
t18=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t13,lf[147],lf[153],t9,*((C_word*)lf[147]+1));}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t13=(C_word)C_eqp(t9,lf[150]);
if(C_truep(t13)){
/* srfi-13.scm: 1946 ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t1,lf[147],lf[154],*((C_word*)lf[147]+1));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[155]);}}
else{
/* srfi-13.scm: 1941 ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t1,lf[147],lf[156],t2,*((C_word*)lf[147]+1));}}}

/* k7454 in string-join in k1429 in k1426 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7456,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7409(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7424 in string-join in k1429 in k1426 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7426,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7409(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7407 in string-join in k1429 in k1426 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1926 string-concatenate */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* buildit in string-join in k1429 in k1426 */
static void C_fcall f_7364(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7364,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7370,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7370(t7,t1,t2);}

/* recur in buildit in string-join in k1429 in k1426 */
static void C_fcall f_7370(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7370,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7392,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-13.scm: 1922 recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k7390 in recur in buildit in string-join in k1429 in k1426 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7392,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* %multispan-repcopy! in k1429 in k1426 */
static void C_fcall f_7274(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7274,NULL,8,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_u_fixnum_difference(t8,t7);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7345,a[2]=t1,a[3]=t9,a[4]=t8,a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=t6,a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1881 modulo */
t11=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t5,t9);}

/* k7343 in %multispan-repcopy! in k1429 in k1426 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7345,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],t1);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t4=f_5750(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],t2);
t6=(C_word)C_u_fixnum_difference(t3,t5);
t7=(C_word)C_fixnum_divide(t6,((C_word*)t0)[3]);
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t5);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,f_7305(t9,t8,t7));}

/* do1288 in k7343 in %multispan-repcopy! in k1429 in k1426 */
static C_word C_fcall f_7305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=(C_word)C_u_fixnum_difference(t1,((C_word*)t0)[8]);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],t4);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t5);
return(f_5750(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[6],t6));}
else{
t4=f_5750(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3]);
t5=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[2]);
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t11=t5;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}

/* string-xcopy! in k1429 in k1426 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_7134r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_7134r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_7134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t7=(C_word)C_i_check_exact_2(t5,lf[145]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7143,a[2]=t5,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7187,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1845 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a7186 in string-xcopy! in k1429 in k1426 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7187,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[5]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t5);
t7=(C_word)C_u_fixnum_difference(t4,t3);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7200,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[3],a[10]=t7,a[11]=t1,a[12]=t5,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 1859 check-substring-spec */
t9=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,*((C_word*)lf[145]+1),((C_word*)t0)[3],((C_word*)t0)[4],t6);}

/* k7198 in a7186 in string-xcopy! in k1429 in k1426 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7200,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[12],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
/* srfi-13.scm: 1861 ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc12)(void*)(*((C_word*)t4+1)))(12,t4,((C_word*)t0)[11],lf[145],lf[146],*((C_word*)lf[145]+1),((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(C_fix(1),((C_word*)t0)[10]);
if(C_truep(t4)){
t5=(C_word)C_subchar(((C_word*)t0)[7],((C_word*)t0)[4]);
/* srfi-13.scm: 1866 ##srfi13#string-fill! */
t6=lf[144];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,((C_word*)t0)[11],((C_word*)t0)[9],t5,((C_word*)t0)[8],((C_word*)t0)[2]);}
else{
t5=(C_word)C_fixnum_divide(((C_word*)t0)[6],((C_word*)t0)[10]);
t6=(C_word)C_fixnum_divide(((C_word*)t0)[5],((C_word*)t0)[10]);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7253,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 1871 modulo */
t9=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],((C_word*)t0)[10]);}
else{
/* srfi-13.scm: 1875 %multispan-repcopy! */
f_7274(((C_word*)t0)[11],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}}

/* k7251 in k7198 in a7186 in string-xcopy! in k1429 in k1426 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7253,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7249,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1872 modulo */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7247 in k7251 in k7198 in a7186 in string-xcopy! in k1429 in k1426 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
/* srfi-13.scm: 1870 %string-copy! */
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_5750(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* a7142 in string-xcopy! in k1429 in k1426 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7143,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7165,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1847 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1854 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a7164 in a7142 in string-xcopy! in k1429 in k1426 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7165,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[145]);
/* srfi-13.scm: 1852 values */
C_values(5,0,t1,t4,t2,t3);}

/* a7154 in a7142 in string-xcopy! in k1429 in k1426 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7155,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1847 string-parse-final-start+end */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[145]+1),((C_word*)t0)[2],t2);}

/* xsubstring in k1429 in k1426 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_6996r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6996r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6996r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[140]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7005,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7049,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1799 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a7048 in xsubstring in k1429 in k1426 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7049,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t4,t3);
t6=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
t7=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[141]);}
else{
t8=(C_word)C_eqp(t5,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1815 ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc10)(void*)(*((C_word*)t9+1)))(10,t9,t1,lf[140],lf[142],*((C_word*)lf[140]+1),((C_word*)t0)[2],((C_word*)t0)[3],t2,t3,t4);}
else{
t9=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t9)){
t10=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 1819 make-string */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,t6,t10);}
else{
t10=(C_word)C_fixnum_divide(((C_word*)t0)[3],t5);
t11=(C_word)C_fixnum_divide(t2,t5);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7109,a[2]=t5,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1823 modulo */
t14=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,((C_word*)t0)[3],t5);}
else{
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7112,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1827 make-string */
t14=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t6);}}}}}

/* k7110 in a7048 in xsubstring in k1429 in k1426 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7115,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1828 %multispan-repcopy! */
f_7274(t2,t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7113 in k7110 in a7048 in xsubstring in k1429 in k1426 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7107 in a7048 in xsubstring in k1429 in k1426 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7109,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7105,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1824 modulo */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7103 in k7107 in a7048 in xsubstring in k1429 in k1426 */
static void C_ccall f_7105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
/* srfi-13.scm: 1823 ##sys#substring */
t3=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a7004 in xsubstring in k1429 in k1426 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7005,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7027,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1801 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1811 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a7026 in a7004 in xsubstring in k1429 in k1426 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7027,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[140]);
/* srfi-13.scm: 1808 values */
C_values(5,0,t1,t4,t2,t3);}

/* a7016 in a7004 in xsubstring in k1429 in k1426 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1801 string-parse-final-start+end */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[140]+1),((C_word*)t0)[2],t2);}

/* string-tokenize in k1429 in k1426 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6914r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6914r(t0,t1,t2,t3);}}

static void C_ccall f_6914r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[139]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6926,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6932,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a6931 in string-tokenize in k1429 in k1426 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6932,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6938,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6938(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in a6931 in string-tokenize in k1429 in k1426 */
static void C_fcall f_6938(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6938,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[3];
t6=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,t6))){
/* srfi-13.scm: 1756 string-index-right */
t7=*((C_word*)lf[108]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
t7=t4;
f_6942(2,t7,C_SCHEME_FALSE);}}

/* k6940 in lp in a6931 in string-tokenize in k1429 in k1426 */
static void C_ccall f_6942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6942,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6951,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1759 string-skip-right */
t4=*((C_word*)lf[97]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}}

/* k6949 in k6940 in lp in a6931 in string-tokenize in k1429 in k1426 */
static void C_ccall f_6951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6951,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6965,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1762 ##sys#substring */
t4=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[4],t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6976,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1764 ##sys#substring */
t3=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6974 in k6949 in k6940 in lp in a6931 in string-tokenize in k1429 in k1426 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6976,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6963 in k6949 in k6940 in lp in a6931 in string-tokenize in k1429 in k1426 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6965,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* srfi-13.scm: 1761 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6938(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6925 in string-tokenize in k1429 in k1426 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6926,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[138]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-replace in k1429 in k1426 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr6r,(void*)f_6863r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_6863r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_6863r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6867,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t2,a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1733 check-substring-spec */
t8=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,*((C_word*)lf[137]+1),t2,t4,t5);}

/* k6865 in string-replace in k1429 in k1426 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6872,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6878,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1734 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6877 in k6865 in string-replace in k1429 in k1426 */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6878,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],((C_word*)t0)[3]);
t7=(C_word)C_u_fixnum_difference(t4,t6);
t8=(C_word)C_u_fixnum_plus(t7,t5);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6891,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1738 make-string */
t10=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}

/* k6889 in a6877 in k6865 in string-replace in k1429 in k1426 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=f_5750(t1,C_fix(0),((C_word*)t0)[10],C_fix(0),((C_word*)t0)[9]);
t3=f_5750(t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[5]);
t5=f_5750(t1,t4,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a6871 in k6865 in string-replace in k1429 in k1426 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6872,2,t0,t1);}
/* srfi-13.scm: 1734 string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[137]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %finish-string-concatenate-reverse in k1429 in k1426 */
static void C_fcall f_6820(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6820,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6824,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_fixnum_plus(t5,t2);
/* srfi-13.scm: 1713 make-string */
t8=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k6822 in %finish-string-concatenate-reverse in k1429 in k1426 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6824,2,t0,t1);}
t2=f_5750(t1,((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0),((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6832,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=f_6832(t3,((C_word*)t0)[6],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* lp in k6822 in %finish-string-concatenate-reverse in k1429 in k1426 */
static C_word C_fcall f_6832(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=(C_word)C_u_fixnum_difference(t1,t5);
t7=f_5750(((C_word*)t0)[2],t6,t3,C_fix(0),t5);
t9=t6;
t10=t4;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* string-concatenate-reverse/shared in k1429 in k1426 */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6694r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6694r(t0,t1,t2,t3);}}

static void C_ccall f_6694r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[136]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_fix((C_word)C_header_size(t5)):(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(C_word)C_i_check_exact_2(t9,lf[135]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6718,a[2]=t9,a[3]=t5,a[4]=t14,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_6718(t16,t1,C_fix(0),C_SCHEME_FALSE,t2);}

/* lp in string-concatenate-reverse/shared in k1429 in k1426 */
static void C_fcall f_6718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6718,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_fix((C_word)C_header_size(t5));
t7=(C_word)C_u_fixnum_plus(t2,t6);
t8=t3;
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,C_fix(0)));
t10=(C_truep(t9)?t3:t4);
t11=(C_word)C_slot(t4,C_fix(1));
/* srfi-13.scm: 1699 lp */
t19=t1;
t20=t7;
t21=t10;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
/* srfi-13.scm: 1703 substring/shared */
t6=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t7)){
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_fix((C_word)C_header_size(t8));
t10=t2;
t11=t6;
f_6768(t11,(C_word)C_eqp(t10,t9));}
else{
t8=t6;
f_6768(t8,C_SCHEME_FALSE);}}}}

/* k6766 in lp in string-concatenate-reverse/shared in k1429 in k1426 */
static void C_fcall f_6768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_car(((C_word*)t0)[5]));}
else{
/* srfi-13.scm: 1710 %finish-string-concatenate-reverse */
f_6820(((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* string-concatenate-reverse in k1429 in k1426 */
static void C_ccall f_6609(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_6609r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6609r(t0,t1,t2,t3);}}

static void C_ccall f_6609r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(2);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[133]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_fix((C_word)C_header_size(t5)):(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(C_word)C_i_check_exact_2(t9,lf[132]);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6636,tmp=(C_word)a,a+=2,tmp);
t14=f_6636(C_fix(0),t2);
/* srfi-13.scm: 1684 %finish-string-concatenate-reverse */
f_6820(t1,t14,t2,t5,t9);}

/* lp in string-concatenate-reverse in k1429 in k1426 */
static C_word C_fcall f_6636(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_u_fixnum_plus(t1,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t1);}}

/* string-concatenate in k1429 in k1426 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6536,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6577,tmp=(C_word)a,a+=2,tmp);
t4=f_6577(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6543,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1651 make-string */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k6541 in string-concatenate in k1429 in k1426 */
static void C_ccall f_6543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6548,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=f_6548(t2,C_fix(0),((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* lp in k6541 in string-concatenate in k1429 in k1426 */
static C_word C_fcall f_6548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=f_5750(((C_word*)t0)[2],t1,t3,C_fix(0),t4);
t6=(C_word)C_u_fixnum_plus(t1,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* do1138 in string-concatenate in k1429 in k1426 */
static C_word C_fcall f_6577(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_i_car(t1);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_u_fixnum_plus(t2,t5);
t8=t3;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t2);}}

/* string-concatenate/shared in k1429 in k1426 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6434,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6440,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6440(t6,t1,t2,C_fix(0),C_SCHEME_FALSE);}

/* lp in string-concatenate/shared in k1429 in k1426 */
static void C_fcall f_6440(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6440,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_fix((C_word)C_header_size(t5));
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1624 lp */
t19=t1;
t20=t6;
t21=t3;
t22=t4;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t9=(C_word)C_u_fixnum_plus(t3,t7);
t10=t4;
t11=(C_truep(t10)?t10:t2);
/* srfi-13.scm: 1625 lp */
t19=t1;
t20=t6;
t21=t9;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}}
else{
t5=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[130]);}
else{
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_fix((C_word)C_header_size(t6));
t8=t3;
t9=(C_word)C_eqp(t8,t7);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_u_i_car(t4));}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6494,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1632 make-string */
t11=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t3);}}}}

/* k6492 in lp in string-concatenate/shared in k1429 in k1426 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6499,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=f_6499(t2,((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* lp in k6492 in lp in string-concatenate/shared in k1429 in k1426 */
static C_word C_fcall f_6499(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=f_5750(((C_word*)t0)[2],t2,t3,C_fix(0),t4);
t6=(C_word)C_slot(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,t4);
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* string-append/shared in k1429 in k1426 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_6428r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6428r(t0,t1,t2);}}

static void C_ccall f_6428r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-13.scm: 1615 string-concatenate/shared */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* string->list in k1429 in k1426 */
static void C_ccall f_6382(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6382r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6382r(t0,t1,t2,t3);}}

static void C_ccall f_6382r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6388,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6394,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6393 in string->list in k1429 in k1426 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6394,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6404,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6404(t8,t1,t4,C_SCHEME_END_OF_LIST);}

/* do1110 in a6393 in string->list in k1429 in k1426 */
static void C_fcall f_6404(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6404,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t10=t1;
t11=t6;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* a6387 in string->list in k1429 in k1426 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6388,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[127]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse! in k1429 in k1426 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6327r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6327r(t0,t1,t2,t3);}}

static void C_ccall f_6327r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6333,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6339,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6338 in string-reverse! in k1429 in k1426 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6339,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6349(t5,t4,t2));}

/* do1098 in a6338 in string-reverse! in k1429 in k1426 */
static C_word C_fcall f_6349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
t3=t1;
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[2],t1);
t6=(C_word)C_subchar(((C_word*)t0)[2],t2);
t7=(C_word)C_setsubchar(((C_word*)t0)[2],t1,t6);
t8=(C_word)C_setsubchar(((C_word*)t0)[2],t2,t5);
t9=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t12=t9;
t13=t10;
t1=t12;
t2=t13;
goto loop;}}

/* a6332 in string-reverse! in k1429 in k1426 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse in k1429 in k1426 */
static void C_ccall f_6272(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6272r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6272r(t0,t1,t2,t3);}}

static void C_ccall f_6272r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6278,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6284,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6283 in string-reverse in k1429 in k1426 */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6284,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6291,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1557 make-string */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k6289 in a6283 in string-reverse in k1429 in k1426 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6300,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=f_6300(t3,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* do1087 in k6289 in a6283 in string-reverse in k1429 in k1426 */
static C_word C_fcall f_6300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_setsubchar(((C_word*)t0)[2],t2,t4);
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* a6277 in string-reverse in k1429 in k1426 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6278,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-null? in k1429 in k1426 */
static void C_ccall f_6269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6269,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_null_p(t2));}

/* string-kmp-partial-search in k1429 in k1426 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr6r,(void*)f_6148r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_6148r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_6148r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(12);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?*((C_word*)lf[120]+1):(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?C_fix(0):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6166,a[2]=t14,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6172,a[2]=t5,a[3]=t8,a[4]=t2,a[5]=t12,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t15,t16);}

/* a6171 in string-kmp-partial-search in k1429 in k1426 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6172,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6181(t9,t1,t3,((C_word*)t0)[2]);}

/* lp in a6171 in string-kmp-partial-search in k1429 in k1426 */
static void C_fcall f_6181(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6181,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_eqp(t4,((C_word*)t0)[9]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_fixnum_negate(t2));}
else{
t6=t2;
t7=((C_word*)t0)[8];
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}
else{
t9=(C_word)C_subchar(((C_word*)t0)[7],t2);
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6211,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6213,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t13,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_6213(t15,t11,t3);}}}

/* lp2 in lp in a6171 in string-kmp-partial-search in k1429 in k1426 */
static void C_fcall f_6213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6213,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6220,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_subchar(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1537 c= */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k6218 in lp2 in lp in a6171 in string-kmp-partial-search in k1429 in k1426 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1541 lp2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6213(t4,((C_word*)t0)[5],t2);}}}

/* k6209 in lp in a6171 in string-kmp-partial-search in k1429 in k1426 */
static void C_ccall f_6211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1535 lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6181(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6165 in string-kmp-partial-search in k1429 in k1426 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6166,2,t0,t1);}
/* srfi-13.scm: 1526 string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* kmp-step in k1429 in k1426 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_6110,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6116,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_6116(t11,t1,t5);}

/* lp in kmp-step in k1429 in k1426 */
static void C_fcall f_6116(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6116,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6123,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_subchar(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1504 c= */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k6121 in lp in kmp-step in k1429 in k1426 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1508 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6116(t4,((C_word*)t0)[5],t2);}}}

/* make-kmp-restart-vector in k1429 in k1426 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5975r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5975r(t0,t1,t2,t3);}}

static void C_ccall f_5975r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[120]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5987,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5993,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a5992 in make-kmp-restart-vector in k1429 in k1426 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5993,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6000,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1458 make-vector */
t7=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,C_fix(-1));}

/* k5998 in a5992 in make-kmp-restart-vector in k1429 in k1426 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6003,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[5],C_fix(0)))){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6017(t8,t2,C_fix(0),C_fix(-1),((C_word*)t0)[3]);}
else{
t3=t2;
f_6003(2,t3,C_SCHEME_UNDEFINED);}}

/* lp1 in k5998 in a5992 in make-kmp-restart-vector in k1429 in k1426 */
static void C_fcall f_6017(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6017,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[8]))){
t6=(C_word)C_subchar(((C_word*)t0)[7],t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=((C_word*)t0)[6],a[11]=t2,tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_6032(t10,t1,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* lp2 in lp1 in k5998 in a5992 in make-kmp-restart-vector in k1429 in k1426 */
static void C_fcall f_6032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6032,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[11],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6059,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t5,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1476 c= */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t2,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[3]);
t7=(C_word)C_subchar(((C_word*)t0)[2],t6);
/* srfi-13.scm: 1480 c= */
t8=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[6],t7);}}

/* k6063 in lp2 in lp1 in k5998 in a5992 in make-kmp-restart-vector in k1429 in k1426 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t3=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],t2,t3);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-13.scm: 1484 lp1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6017(t6,((C_word*)t0)[3],t2,t3,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[7]);
/* srfi-13.scm: 1486 lp2 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6032(t3,((C_word*)t0)[3],t2);}}

/* k6057 in lp2 in lp1 in k5998 in a5992 in make-kmp-restart-vector in k1429 in k1426 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_truep(t1)?C_fix(-1):C_fix(0));
t3=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1477 lp1 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6017(t5,((C_word*)t0)[2],((C_word*)t0)[5],C_fix(0),t4);}

/* k6001 in k5998 in a5992 in make-kmp-restart-vector in k1429 in k1426 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a5986 in make-kmp-restart-vector in k1429 in k1426 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
/* srfi-13.scm: 1456 string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[119]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %kmp-search in k1429 in k1426 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5877,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_u_fixnum_difference(t6,t5);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5884,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t5,a[6]=t3,a[7]=t9,a[8]=t7,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 1405 make-kmp-restart-vector */
t11=*((C_word*)lf[119]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,t2,t4,t5,t6);}

/* k5882 in %kmp-search in k1429 in k1426 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5884,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_5893(t6,((C_word*)t0)[2],((C_word*)t0)[8],C_fix(0),t2,((C_word*)t0)[7]);}

/* lp in k5882 in %kmp-search in k1429 in k1426 */
static void C_fcall f_5893(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5893,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_eqp(t6,((C_word*)t0)[8]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[8]));}
else{
t8=t5;
t9=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t11=(C_word)C_subchar(((C_word*)t0)[5],t2);
t12=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t3);
t13=(C_word)C_subchar(((C_word*)t0)[3],t12);
/* srfi-13.scm: 1416 c= */
t14=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t11,t13);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}

/* k5913 in lp in k5882 in %kmp-search in k1429 in k1426 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[9]);
t3=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* srfi-13.scm: 1418 lp */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5893(t6,((C_word*)t0)[4],t2,t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],C_fix(1));
/* srfi-13.scm: 1422 lp */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5893(t6,((C_word*)t0)[4],t4,C_fix(0),t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1423 lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5893(t5,((C_word*)t0)[4],((C_word*)t0)[9],t2,((C_word*)t0)[7],t4);}}}

/* string-contains-ci in k1429 in k1426 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5815r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5815r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5815r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[116]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5821,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5827,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5826 in string-contains-ci in k1429 in k1426 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5827,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5833,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5839,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5838 in a5826 in string-contains-ci in k1429 in k1426 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5839,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5851,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_5851(t9,t1,((C_word*)t0)[2]);}

/* lp in a5838 in a5826 in string-contains-ci in k1429 in k1426 */
static void C_fcall f_5851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5851,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1375 string-ci= */
t5=*((C_word*)lf[65]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5862 in lp in a5838 in a5826 in string-contains-ci in k1429 in k1426 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1377 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5851(t3,((C_word*)t0)[4],t2);}}

/* a5832 in a5826 in string-contains-ci in k1429 in k1426 */
static void C_ccall f_5833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5833,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5820 in string-contains-ci in k1429 in k1426 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5821,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-contains in k1429 in k1426 */
static void C_ccall f_5753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5753r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5753r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5753r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[116]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5759,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5765,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5764 in string-contains in k1429 in k1426 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5765,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5771,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5777,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5776 in a5764 in string-contains in k1429 in k1426 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5777,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5789,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_5789(t9,t1,((C_word*)t0)[2]);}

/* lp in a5776 in a5764 in string-contains in k1429 in k1426 */
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5789,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1364 string= */
t5=*((C_word*)lf[58]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5800 in lp in a5776 in a5764 in string-contains in k1429 in k1426 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1366 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5789(t3,((C_word*)t0)[4],t2);}}

/* a5770 in a5764 in string-contains in k1429 in k1426 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5758 in string-contains in k1429 in k1426 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-copy! in k1429 in k1426 */
static C_word C_fcall f_5750(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
return((C_word)C_substring_copy(t3,t1,t4,t5,t2));}

/* string-copy! in k1429 in k1426 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_5718r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5718r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5724,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5730,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5729 in string-copy! in k1429 in k1426 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5730,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[115]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5737,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_fixnum_difference(t3,t2);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t6);
/* srfi-13.scm: 1344 check-substring-spec */
t8=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[4],t7);}

/* k5735 in a5729 in string-copy! in k1429 in k1426 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1345 %string-copy! */
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_5750(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* a5723 in string-copy! in k1429 in k1426 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fill! in k1429 in k1426 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_5677r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5677r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5677r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5683,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5689,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5688 in string-fill! in k1429 in k1426 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5689,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5699(t5,t4));}

/* do947 in a5688 in string-fill! in k1429 in k1426 */
static C_word C_fcall f_5699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}

/* a5682 in string-fill! in k1429 in k1426 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5683,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-count in k1429 in k1426 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_5542r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5542r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5542r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5548,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5554,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5553 in string-count in k1429 in k1426 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5554,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5566(t4,t2,C_fix(0)));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5600,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1310 char-set? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5598 in a5553 in string-count in k1429 in k1426 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5600,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5605(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5644,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5644(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
/* srfi-13.scm: 1322 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[112],lf[113],*((C_word*)lf[112]+1),((C_word*)t0)[4]);}}}

/* do937 in k5598 in a5553 in string-count in k1429 in k1426 */
static void C_fcall f_5644(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5644,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5665,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1319 criteria */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* k5663 in do937 in k5598 in a5553 in string-count in k1429 in k1426 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_5644(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* do932 in k5598 in a5553 in string-count in k1429 in k1426 */
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5605,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5626,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1312 char-set-contains? */
t9=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k5624 in do932 in k5598 in a5553 in string-count in k1429 in k1426 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_5605(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* do927 in a5553 in string-count in k1429 in k1426 */
static C_word C_fcall f_5566(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
return(t2);}
else{
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_subchar(((C_word*)t0)[3],t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
t8=(C_truep(t7)?(C_word)C_u_fixnum_plus(t2,C_fix(1)):t2);
t10=t5;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* a5547 in string-count in k1429 in k1426 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip-right in k1429 in k1426 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_5407r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5407r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5413,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5419,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5418 in string-skip-right in k1429 in k1426 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5419,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5435(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5465,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1284 char-set? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5463 in a5418 in string-skip-right in k1429 in k1426 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5465,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5474(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5513(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1295 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[97],lf[111],*((C_word*)lf[97]+1),((C_word*)t0)[3]);}}}

/* lp in k5463 in a5418 in string-skip-right in k1429 in k1426 */
static void C_fcall f_5513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5513,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5526,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1293 criteria */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5524 in lp in k5463 in a5418 in string-skip-right in k1429 in k1426 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1293 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5513(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k5463 in a5418 in string-skip-right in k1429 in k1426 */
static void C_fcall f_5474(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5474,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5487,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1287 char-set-contains? */
t6=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5485 in lp in k5463 in a5418 in string-skip-right in k1429 in k1426 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1288 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5474(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a5418 in string-skip-right in k1429 in k1426 */
static C_word C_fcall f_5435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a5412 in string-skip-right in k1429 in k1426 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5413,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[97]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip in k1429 in k1426 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_5284r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5284r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5284r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5290,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5296,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5295 in string-skip in k1429 in k1426 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5296,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5308(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5338,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1262 char-set? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5336 in a5295 in string-skip in k1429 in k1426 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5343,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5343(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5378(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1273 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[83],lf[110],*((C_word*)lf[83]+1),((C_word*)t0)[4]);}}}

/* lp in k5336 in a5295 in string-skip in k1429 in k1426 */
static void C_fcall f_5378(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5378,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5391,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1271 criteria */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5389 in lp in k5336 in a5295 in string-skip in k1429 in k1426 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1271 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5378(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k5336 in a5295 in string-skip in k1429 in k1426 */
static void C_fcall f_5343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5343,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5356,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1265 char-set-contains? */
t7=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5354 in lp in k5336 in a5295 in string-skip in k1429 in k1426 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1266 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5343(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a5295 in string-skip in k1429 in k1426 */
static C_word C_fcall f_5308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a5289 in string-skip in k1429 in k1426 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5290,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[83]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index-right in k1429 in k1426 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_5149r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5149r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5149r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5155,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5161,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5160 in string-index-right in k1429 in k1426 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5161,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5177(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5207,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1241 char-set? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5205 in a5160 in string-index-right in k1429 in k1426 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5207,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5216(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5255(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1251 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[108],lf[109],*((C_word*)lf[108]+1),((C_word*)t0)[3]);}}}

/* lp in k5205 in a5160 in string-index-right in k1429 in k1426 */
static void C_fcall f_5255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5255,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1249 criteria */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5266 in lp in k5205 in a5160 in string-index-right in k1429 in k1426 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1250 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5255(t3,((C_word*)t0)[4],t2);}}

/* lp in k5205 in a5160 in string-index-right in k1429 in k1426 */
static void C_fcall f_5216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5216,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1244 char-set-contains? */
t6=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5227 in lp in k5205 in a5160 in string-index-right in k1429 in k1426 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1245 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5216(t3,((C_word*)t0)[4],t2);}}

/* lp in a5160 in string-index-right in k1429 in k1426 */
static C_word C_fcall f_5177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a5154 in string-index-right in k1429 in k1426 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[108]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index in k1429 in k1426 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_5026r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5026r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5026r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5032,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5038,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5037 in string-index in k1429 in k1426 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5038,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5050(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5080,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1221 char-set? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5078 in a5037 in string-index in k1429 in k1426 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5080,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5085(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5120(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1231 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[84],lf[107],*((C_word*)lf[84]+1),((C_word*)t0)[4]);}}}

/* lp in k5078 in a5037 in string-index in k1429 in k1426 */
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5120,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1229 criteria */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5131 in lp in k5078 in a5037 in string-index in k1429 in k1426 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1230 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5120(t3,((C_word*)t0)[4],t2);}}

/* lp in k5078 in a5037 in string-index in k1429 in k1426 */
static void C_fcall f_5085(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5085,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1224 char-set-contains? */
t7=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5096 in lp in k5078 in a5037 in string-index in k1429 in k1426 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1225 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5085(t3,((C_word*)t0)[4],t2);}}

/* lp in a5037 in string-index in k1429 in k1426 */
static C_word C_fcall f_5050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t1);}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a5031 in string-index in k1429 in k1426 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5032,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-filter in k1429 in k1426 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_4918r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4918r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4918r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4924,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4930,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4930,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4943,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1177 make-string */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4973,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1186 char-set? */
t6=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k5010 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4973(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1187 char-set */
t2=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1188 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[105],lf[106],((C_word*)t0)[2]);}}}

/* k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1190 string-fold */
t4=*((C_word*)lf[21]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4998 in k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4999,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5006,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1190 char-set-contains? */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k5004 in a4998 in k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(1)):((C_word*)t0)[2]));}

/* k4974 in k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1194 make-string */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4977 in k4974 in k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4982,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1195 string-fold */
t4=*((C_word*)lf[21]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4983 in k4977 in k4974 in k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4984,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4991,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1195 char-set-contains? */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4989 in a4983 in k4977 in k4974 in k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k4980 in k4977 in k4974 in k4971 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4941 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4946,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4957,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1178 string-fold */
t4=*((C_word*)lf[21]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4956 in k4941 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4957,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4964,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1179 criteria */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4962 in a4956 in k4941 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k4944 in k4941 in a4929 in string-filter in k1429 in k1426 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1184 ##sys#substring */
t4=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a4923 in string-filter in k1429 in k1426 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[105]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-delete in k1429 in k1426 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_4810r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4810r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4810r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4816,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4822,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4822,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4835,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1150 make-string */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4865,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1158 char-set? */
t6=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k4902 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4865(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1159 char-set */
t2=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1160 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[102],lf[104],((C_word*)t0)[2]);}}}

/* k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4891,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1161 string-fold */
t4=*((C_word*)lf[21]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4890 in k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4891,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4898,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1161 char-set-contains? */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4896 in a4890 in k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(1))));}

/* k4866 in k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1165 make-string */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4869 in k4866 in k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4874,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1166 string-fold */
t4=*((C_word*)lf[21]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4875 in k4869 in k4866 in k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4876,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4883,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1166 char-set-contains? */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4881 in a4875 in k4869 in k4866 in k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k4872 in k4869 in k4866 in k4863 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4833 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4838,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1151 string-fold */
t4=*((C_word*)lf[21]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4848 in k4833 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4849,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4856,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1152 criteria */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4854 in a4848 in k4833 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k4836 in k4833 in a4821 in string-delete in k1429 in k1426 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1156 ##sys#substring */
t4=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a4815 in string-delete in k1429 in k1426 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4816,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[102]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad in k1429 in k1426 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_4748r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4748r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4748r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[101]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_u_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4763,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4769,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}

/* a4768 in string-pad in k1429 in k1426 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4769,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[4]);
/* srfi-13.scm: 1125 %substring/shared */
f_1639(t1,((C_word*)t0)[3],t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4789,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1126 make-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4787 in a4768 in string-pad in k1429 in k1426 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=f_5750(t1,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a4762 in string-pad in k1429 in k1426 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4763,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[101]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad-right in k1429 in k1426 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_4690r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4690r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4690r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[100]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_u_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4705,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4711,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}

/* a4710 in string-pad-right in k1429 in k1426 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4711,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[4]);
/* srfi-13.scm: 1114 %substring/shared */
f_1639(t1,((C_word*)t0)[3],t2,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1115 make-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4729 in a4710 in string-pad-right in k1429 in k1426 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_5750(t1,C_fix(0),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4704 in string-pad-right in k1429 in k1426 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[100]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-both in k1429 in k1426 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4640r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4640r(t0,t1,t2,t3);}}

static void C_ccall f_4640r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[93]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4652,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4658,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a4657 in string-trim-both in k1429 in k1426 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4658,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4662,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1102 string-skip */
t5=*((C_word*)lf[83]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4660 in a4657 in string-trim-both in k1429 in k1426 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4676,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1104 string-skip-right */
t3=*((C_word*)lf[97]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[99]);}}

/* k4674 in k4660 in a4657 in string-trim-both in k1429 in k1426 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1104 %substring/shared */
f_1639(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4651 in string-trim-both in k1429 in k1426 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4652,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[98]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-right in k1429 in k1426 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4594r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4594r(t0,t1,t2,t3);}}

static void C_ccall f_4594r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[93]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4612,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a4611 in string-trim-right in k1429 in k1426 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4612,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1095 string-skip-right */
t5=*((C_word*)lf[97]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4614 in a4611 in string-trim-right in k1429 in k1426 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1096 %substring/shared */
f_1639(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[96]);}}

/* a4605 in string-trim-right in k1429 in k1426 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim in k1429 in k1426 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4552r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4552r(t0,t1,t2,t3);}}

static void C_ccall f_4552r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[93]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a4569 in string-trim in k1429 in k1426 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4570,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4574,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1088 string-skip */
t5=*((C_word*)lf[83]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4572 in a4569 in string-trim in k1429 in k1426 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 1089 %substring/shared */
f_1639(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[94]);}}

/* a4563 in string-trim in k1429 in k1426 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4564,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-drop-right in k1429 in k1426 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4525,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[91]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4532,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1078 ##sys#check-range */
t8=*((C_word*)lf[88]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[91]);}

/* k4530 in string-drop-right in k1429 in k1426 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1082 %substring/shared */
f_1639(((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t3);}

/* string-drop in k1429 in k1426 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4502,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[90]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4509,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1069 ##sys#check-range */
t8=*((C_word*)lf[88]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[90]);}

/* k4507 in string-drop in k1429 in k1426 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-13.scm: 1073 %substring/shared */
f_1639(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* string-take-right in k1429 in k1426 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4475,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4482,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1060 ##sys#check-range */
t8=*((C_word*)lf[88]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[89]);}

/* k4480 in string-take-right in k1429 in k1426 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1064 %substring/shared */
f_1639(((C_word*)t0)[2],((C_word*)t0)[4],t3,t2);}

/* string-take in k1429 in k1426 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4455,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[87]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4462,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1054 ##sys#check-range */
t8=*((C_word*)lf[88]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[87]);}

/* k4460 in string-take in k1429 in k1426 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1055 %substring/shared */
f_1639(((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* string-titlecase in k1429 in k1426 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4430r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4430r(t0,t1,t2,t3);}}

static void C_ccall f_4430r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4436,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4442,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4441 in string-titlecase in k1429 in k1426 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4442,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4446,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1025 ##sys#substring */
t5=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t2,t3);}

/* k4444 in a4441 in string-titlecase in k1429 in k1426 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4449,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-13.scm: 1026 %string-titlecase! */
f_4353(t2,t1,C_fix(0),t3);}

/* k4447 in k4444 in a4441 in string-titlecase in k1429 in k1426 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4435 in string-titlecase in k1429 in k1426 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[85]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-titlecase! in k1429 in k1426 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4412r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4412r(t0,t1,t2,t3);}}

static void C_ccall f_4412r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4418,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4424,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4423 in string-titlecase! in k1429 in k1426 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4424,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1021 %string-titlecase! */
f_4353(t1,((C_word*)t0)[2],t2,t3);}

/* a4417 in string-titlecase! in k1429 in k1426 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[85]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-titlecase! in k1429 in k1426 */
static void C_fcall f_4353(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4353,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4359,a[2]=t4,a[3]=t6,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4359(t8,t1,t3);}

/* lp in %string-titlecase! in k1429 in k1426 */
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4359,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4406,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 1009 string-index */
t5=*((C_word*)lf[84]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,((C_word*)t0)[4],t4,t2,((C_word*)t0)[2]);}

/* a4405 in lp in %string-titlecase! in k1429 in k1426 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4406,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k4361 in lp in %string-titlecase! in k1429 in k1426 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_subchar(((C_word*)t0)[5],t1);
t3=(C_word)C_u_i_char_upcase(t2);
t4=(C_word)C_setsubchar(((C_word*)t0)[5],t1,t3);
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4393,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 1013 string-skip */
t8=*((C_word*)lf[83]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,((C_word*)t0)[5],t7,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a4392 in k4361 in lp in %string-titlecase! in k1429 in k1426 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4393,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k4373 in k4361 in lp in %string-titlecase! in k1429 in k1426 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1015 string-downcase! */
t3=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1);}
else{
/* srfi-13.scm: 1017 string-downcase! */
t2=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4379 in k4373 in k4361 in lp in %string-titlecase! in k1429 in k1426 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1016 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4359(t3,((C_word*)t0)[2],t2);}

/* string-downcase! in k1429 in k1426 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4335r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4335r(t0,t1,t2,t3);}}

static void C_ccall f_4335r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4347,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4346 in string-downcase! in k1429 in k1426 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4347,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1005 %string-map! */
f_1758(t1,*((C_word*)lf[80]+1),((C_word*)t0)[2],t2,t3);}

/* a4340 in string-downcase! in k1429 in k1426 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[81]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-downcase in k1429 in k1426 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4317r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4317r(t0,t1,t2,t3);}}

static void C_ccall f_4317r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4323,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4329,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4328 in string-downcase in k1429 in k1426 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4329,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1001 %string-map */
f_1697(t1,*((C_word*)lf[80]+1),((C_word*)t0)[2],t2,t3);}

/* a4322 in string-downcase in k1429 in k1426 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[79]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase! in k1429 in k1426 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4299r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4299r(t0,t1,t2,t3);}}

static void C_ccall f_4299r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4305,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4311,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4310 in string-upcase! in k1429 in k1426 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4311,4,t0,t1,t2,t3);}
/* srfi-13.scm: 997  %string-map! */
f_1758(t1,*((C_word*)lf[77]+1),((C_word*)t0)[2],t2,t3);}

/* a4304 in string-upcase! in k1429 in k1426 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4305,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[78]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase in k1429 in k1426 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4281r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4281r(t0,t1,t2,t3);}}

static void C_ccall f_4281r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4287,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4293,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4292 in string-upcase in k1429 in k1426 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4293,4,t0,t1,t2,t3);}
/* srfi-13.scm: 993  %string-map */
f_1697(t1,*((C_word*)lf[77]+1),((C_word*)t0)[2],t2,t3);}

/* a4286 in string-upcase in k1429 in k1426 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[76]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash-ci in k1429 in k1426 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4225r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4225r(t0,t1,t2,t3);}}

static void C_ccall f_4225r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_u_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4235,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_4235(t13,t12);}
else{
t12=t10;
f_4235(t12,C_SCHEME_UNDEFINED);}}

/* k4233 in string-hash-ci in k1429 in k1426 */
static void C_fcall f_4235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4235,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[75]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 975  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4248 in k4233 in string-hash-ci in k1429 in k1426 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4249,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4255,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 976  %string-hash */
f_4107(t1,((C_word*)t0)[3],t4,((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a4254 in a4248 in k4233 in string-hash-ci in k1429 in k1426 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4255,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_downcase(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t3)));}

/* a4242 in k4233 in string-hash-ci in k1429 in k1426 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
/* srfi-13.scm: 975  string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[75]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash in k1429 in k1426 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4179r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4179r(t0,t1,t2,t3);}}

static void C_ccall f_4179r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_u_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4189,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_4189(t13,t12);}
else{
t12=t10;
f_4189(t12,C_SCHEME_UNDEFINED);}}

/* k4187 in string-hash in k1429 in k1426 */
static void C_fcall f_4189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4189,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[73]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 965  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4202 in k4187 in string-hash in k1429 in k1426 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4203,4,t0,t1,t2,t3);}
/* srfi-13.scm: 966  %string-hash */
f_4107(t1,((C_word*)t0)[3],*((C_word*)lf[74]+1),((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a4196 in k4187 in string-hash in k1429 in k1426 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
/* srfi-13.scm: 965  string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-hash in k1429 in k1426 */
static void C_fcall f_4107(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4107,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4160,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=f_4160(t8,C_fix(65536));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4125,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=t9,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t13=((C_word*)t11)[1];
f_4125(t13,t1,t5,C_fix(0));}

/* lp in %string-hash in k1429 in k1426 */
static void C_fcall f_4125(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4125,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[7];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* srfi-13.scm: 955  modulo */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,((C_word*)t0)[6]);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(C_word)C_fixnum_times(C_fix(37),t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4158,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 956  iref */
t9=((C_word*)t0)[3];
f_4109(t9,t8,((C_word*)t0)[2],t2);}}

/* k4156 in lp in %string-hash in k1429 in k1426 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_and(((C_word*)t0)[5],t2);
/* srfi-13.scm: 956  lp */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4125(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* lp in %string-hash in k1429 in k1426 */
static C_word C_fcall f_4160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=t1;
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_u_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_u_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* iref in %string-hash in k1429 in k1426 */
static void C_fcall f_4109(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4109,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_subchar(t2,t3);
/* srfi-13.scm: 950  char->int */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* string-ci>= in k1429 in k1426 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4059r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4059r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4059r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[70]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4065,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4071,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4070 in string-ci>= in k1429 in k1426 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4071,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4077,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4083,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4082 in a4070 in string-ci>= in k1429 in k1426 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4083,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4090,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4090(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4090(t6,C_SCHEME_FALSE);}}

/* k4088 in a4082 in a4070 in string-ci>= in k1429 in k1426 */
static void C_fcall f_4090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4090,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4098,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 930  %string-compare-ci */
f_3331(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[59]+1),*((C_word*)lf[59]+1));}}

/* a4097 in k4088 in a4082 in a4070 in string-ci>= in k1429 in k1426 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4098,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4076 in a4070 in string-ci>= in k1429 in k1426 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4064 in string-ci>= in k1429 in k1426 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<= in k1429 in k1426 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4011r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4011r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4011r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[69]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4017,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4023,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4022 in string-ci<= in k1429 in k1426 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4023,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4029,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4034 in a4022 in string-ci<= in k1429 in k1426 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4035,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4042,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4042(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4042(t6,C_SCHEME_FALSE);}}

/* k4040 in a4034 in a4022 in string-ci<= in k1429 in k1426 */
static void C_fcall f_4042(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4042,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4050,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 919  %string-compare-ci */
f_3331(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[59]+1),*((C_word*)lf[59]+1),t2);}}

/* a4049 in k4040 in a4034 in a4022 in string-ci<= in k1429 in k1426 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4050,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4028 in a4022 in string-ci<= in k1429 in k1426 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4029,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4016 in string-ci<= in k1429 in k1426 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci> in k1429 in k1426 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3960r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3960r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3960r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[68]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3966,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3971 in string-ci> in k1429 in k1426 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3972,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3978,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3983 in a3971 in string-ci> in k1429 in k1426 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3984,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3991,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3991(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3991(t6,C_SCHEME_FALSE);}}

/* k3989 in a3983 in a3971 in string-ci> in k1429 in k1426 */
static void C_fcall f_3991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3991,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3999,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4002,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 908  %string-compare-ci */
f_3331(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[59]+1));}}

/* a4001 in k3989 in a3983 in a3971 in string-ci> in k1429 in k1426 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4002,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3998 in k3989 in a3983 in a3971 in string-ci> in k1429 in k1426 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3999,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3977 in a3971 in string-ci> in k1429 in k1426 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3965 in string-ci> in k1429 in k1426 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci< in k1429 in k1426 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3909r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3909r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[67]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3915,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3921,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3920 in string-ci< in k1429 in k1426 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3921,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3927,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3932 in a3920 in string-ci< in k1429 in k1426 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3933,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3940,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3940(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3940(t6,C_SCHEME_FALSE);}}

/* k3938 in a3932 in a3920 in string-ci< in k1429 in k1426 */
static void C_fcall f_3940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3940,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3948,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3951,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 897  %string-compare-ci */
f_3331(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[59]+1),t2,t3);}}

/* a3950 in k3938 in a3932 in a3920 in string-ci< in k1429 in k1426 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3951,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3947 in k3938 in a3932 in a3920 in string-ci< in k1429 in k1426 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3948,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3926 in a3920 in string-ci< in k1429 in k1426 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3914 in string-ci< in k1429 in k1426 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<> in k1429 in k1426 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3842r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3842r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3842r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[66]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3848,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3854,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3853 in string-ci<> in k1429 in k1426 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3854,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3860,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3865 in a3853 in string-ci<> in k1429 in k1426 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3866,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3889,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_3889(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_3889(t10,C_SCHEME_FALSE);}}}

/* k3887 in a3865 in a3853 in string-ci<> in k1429 in k1426 */
static void C_fcall f_3889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3889,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3884,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 886  %string-compare-ci */
f_3331(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[59]+1),t2,*((C_word*)lf[59]+1));}}

/* a3883 in k3887 in a3865 in a3853 in string-ci<> in k1429 in k1426 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3884,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3859 in a3853 in string-ci<> in k1429 in k1426 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3847 in string-ci<> in k1429 in k1426 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3848,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci= in k1429 in k1426 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3780r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3780r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3780r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[65]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3786,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3792,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3791 in string-ci= in k1429 in k1426 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3792,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3798,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3803 in a3791 in string-ci= in k1429 in k1426 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3804,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3814,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_3814(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_3814(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k3812 in a3803 in a3791 in string-ci= in k1429 in k1426 */
static void C_fcall f_3814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3814,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3822,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3825,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 876  %string-compare-ci */
f_3331(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[59]+1),t3);}}

/* a3824 in k3812 in a3803 in a3791 in string-ci= in k1429 in k1426 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3825,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3821 in k3812 in a3803 in a3791 in string-ci= in k1429 in k1426 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3822,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3797 in a3791 in string-ci= in k1429 in k1426 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3785 in string-ci= in k1429 in k1426 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string>= in k1429 in k1426 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3732r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3732r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[64]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3738,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3744,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3743 in string>= in k1429 in k1426 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3744,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3750,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3755 in a3743 in string>= in k1429 in k1426 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3756,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3763,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3763(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3763(t6,C_SCHEME_FALSE);}}

/* k3761 in a3755 in a3743 in string>= in k1429 in k1426 */
static void C_fcall f_3763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3763,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3771,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 866  %string-compare */
f_3269(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[59]+1),*((C_word*)lf[59]+1));}}

/* a3770 in k3761 in a3755 in a3743 in string>= in k1429 in k1426 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3771,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3749 in a3743 in string>= in k1429 in k1426 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3737 in string>= in k1429 in k1426 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3738,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<= in k1429 in k1426 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3684r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3684r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[63]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3690,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3696,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3695 in string<= in k1429 in k1426 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3696,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3702,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3707 in a3695 in string<= in k1429 in k1426 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3708,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3715,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3715(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3715(t6,C_SCHEME_FALSE);}}

/* k3713 in a3707 in a3695 in string<= in k1429 in k1426 */
static void C_fcall f_3715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3715,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3723,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 855  %string-compare */
f_3269(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[59]+1),*((C_word*)lf[59]+1),t2);}}

/* a3722 in k3713 in a3707 in a3695 in string<= in k1429 in k1426 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3723,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3701 in a3695 in string<= in k1429 in k1426 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3702,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3689 in string<= in k1429 in k1426 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string> in k1429 in k1426 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3633r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3633r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3633r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[62]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3639,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3645,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3644 in string> in k1429 in k1426 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3645,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3651,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3656 in a3644 in string> in k1429 in k1426 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3657,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3664,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3664(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3664(t6,C_SCHEME_FALSE);}}

/* k3662 in a3656 in a3644 in string> in k1429 in k1426 */
static void C_fcall f_3664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3664,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3672,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3675,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 844  %string-compare */
f_3269(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[59]+1));}}

/* a3674 in k3662 in a3656 in a3644 in string> in k1429 in k1426 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3675,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3671 in k3662 in a3656 in a3644 in string> in k1429 in k1426 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3672,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3650 in a3644 in string> in k1429 in k1426 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3651,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3638 in string> in k1429 in k1426 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3639,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string< in k1429 in k1426 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3582r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3582r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3582r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[61]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3588,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3594,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3593 in string< in k1429 in k1426 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3594,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3600,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3605 in a3593 in string< in k1429 in k1426 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3606,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3613,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3613(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3613(t6,C_SCHEME_FALSE);}}

/* k3611 in a3605 in a3593 in string< in k1429 in k1426 */
static void C_fcall f_3613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3613,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3621,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3624,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 833  %string-compare */
f_3269(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[59]+1),t2,t3);}}

/* a3623 in k3611 in a3605 in a3593 in string< in k1429 in k1426 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3624,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3620 in k3611 in a3605 in a3593 in string< in k1429 in k1426 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3621,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3599 in a3593 in string< in k1429 in k1426 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3587 in string< in k1429 in k1426 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3588,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<> in k1429 in k1426 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3515r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3515r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3515r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[60]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3521,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3527,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3526 in string<> in k1429 in k1426 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3527,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3533,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3538 in a3526 in string<> in k1429 in k1426 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3539,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3562,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_3562(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_3562(t10,C_SCHEME_FALSE);}}}

/* k3560 in a3538 in a3526 in string<> in k1429 in k1426 */
static void C_fcall f_3562(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3562,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3557,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 822  %string-compare */
f_3269(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[59]+1),t2,*((C_word*)lf[59]+1));}}

/* a3556 in k3560 in a3538 in a3526 in string<> in k1429 in k1426 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3557,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3532 in a3526 in string<> in k1429 in k1426 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3520 in string<> in k1429 in k1426 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string= in k1429 in k1426 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3453r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3453r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3453r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[58]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3459,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3465,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3464 in string= in k1429 in k1426 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3465,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3471,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3476 in a3464 in string= in k1429 in k1426 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3477,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3487,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_3487(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_3487(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k3485 in a3476 in a3464 in string= in k1429 in k1426 */
static void C_fcall f_3487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3487,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3495,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3498,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 812  %string-compare */
f_3269(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[59]+1),t3);}}

/* a3497 in k3485 in a3476 in a3464 in string= in k1429 in k1426 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3498,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3494 in k3485 in a3476 in a3464 in string= in k1429 in k1426 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3495,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3470 in a3464 in string= in k1429 in k1426 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3458 in string= in k1429 in k1426 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare-ci in k1429 in k1426 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr7r,(void*)f_3423r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_3423r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_3423r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t8=*((C_word*)lf[57]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3429,a[2]=t7,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3435,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a3434 in string-compare-ci in k1429 in k1426 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3435,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3441,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3446 in a3434 in string-compare-ci in k1429 in k1426 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3447,4,t0,t1,t2,t3);}
/* srfi-13.scm: 796  %string-compare-ci */
f_3331(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3440 in a3434 in string-compare-ci in k1429 in k1426 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3428 in string-compare-ci in k1429 in k1426 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare in k1429 in k1426 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr7r,(void*)f_3393r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_3393r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_3393r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t8=*((C_word*)lf[56]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3399,a[2]=t7,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3405,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a3404 in string-compare in k1429 in k1426 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3405,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3411,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3416 in a3404 in string-compare in k1429 in k1426 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3417,4,t0,t1,t2,t3);}
/* srfi-13.scm: 788  %string-compare */
f_3269(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3410 in a3404 in string-compare in k1429 in k1426 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3398 in string-compare in k1429 in k1426 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare-ci in k1429 in k1426 */
static void C_fcall f_3331(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3331,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_u_fixnum_difference(t4,t3);
t12=(C_word)C_u_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3341,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 773  %string-prefix-length-ci */
f_2779(t13,t2,t3,t4,t5,t6,t7);}

/* k3339 in %string-compare-ci in k1429 in k1426 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3366,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_3366(t8,((C_word*)t0)[5]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t10=(C_word)C_subchar(((C_word*)t0)[4],t9);
t11=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t12=(C_word)C_subchar(((C_word*)t0)[2],t11);
/* srfi-13.scm: 777  char-ci<? */
t13=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t8,t10,t12);}}}

/* k3373 in k3339 in %string-compare-ci in k1429 in k1426 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_3366(t2,(C_truep(t1)?((C_word*)t0)[3]:((C_word*)t0)[2]));}

/* k3364 in k3339 in %string-compare-ci in k1429 in k1426 */
static void C_fcall f_3366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare in k1429 in k1426 */
static void C_fcall f_3269(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3269,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_u_fixnum_difference(t4,t3);
t12=(C_word)C_u_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3279,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 759  %string-prefix-length */
f_2621(t13,t2,t3,t4,t5,t6,t7);}

/* k3277 in %string-compare in k1429 in k1426 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3279,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3304,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_3304(t8,((C_word*)t0)[5]);}
else{
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t9=(C_word)C_subchar(((C_word*)t0)[4],t8);
t10=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t11=(C_word)C_subchar(((C_word*)t0)[2],t10);
t12=(C_word)C_fixnum_lessp(t9,t11);
t13=t5;
f_3304(t13,(C_truep(t12)?((C_word*)t0)[9]:((C_word*)t0)[5]));}}}

/* k3302 in k3277 in %string-compare in k1429 in k1426 */
static void C_fcall f_3304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-ci? in k1429 in k1426 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3147r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3147r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3147r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[52]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3153,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3159,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3158 in string-suffix-ci? in k1429 in k1426 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3159,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3165,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3170 in a3158 in string-suffix-ci? in k1429 in k1426 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3171,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3263,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 743  %string-suffix-length-ci */
f_2852(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3261 in a3170 in a3158 in string-suffix-ci? in k1429 in k1426 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3164 in a3158 in string-suffix-ci? in k1429 in k1426 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3152 in string-suffix-ci? in k1429 in k1426 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-ci? in k1429 in k1426 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3117r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3117r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3117r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[51]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3123,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3129,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3128 in string-prefix-ci? in k1429 in k1426 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3129,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3135,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3141,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3140 in a3128 in string-prefix-ci? in k1429 in k1426 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3141,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3240,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 737  %string-prefix-length-ci */
f_2779(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3238 in a3140 in a3128 in string-prefix-ci? in k1429 in k1426 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3134 in a3128 in string-prefix-ci? in k1429 in k1426 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3122 in string-prefix-ci? in k1429 in k1426 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3123,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix? in k1429 in k1426 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3087r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3087r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3087r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[50]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3093,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3099,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3098 in string-suffix? in k1429 in k1426 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3099,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3105,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3111,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3110 in a3098 in string-suffix? in k1429 in k1426 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3111,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3217,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 731  %string-suffix-length */
f_2694(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3215 in a3110 in a3098 in string-suffix? in k1429 in k1426 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3104 in a3098 in string-suffix? in k1429 in k1426 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3105,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3092 in string-suffix? in k1429 in k1426 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3093,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix? in k1429 in k1426 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3057r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3057r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[49]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3063,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3069,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3068 in string-prefix? in k1429 in k1426 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3069,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3075,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3080 in a3068 in string-prefix? in k1429 in k1426 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3081,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3194,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 724  %string-prefix-length */
f_2621(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3192 in a3080 in a3068 in string-prefix? in k1429 in k1426 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(t1,((C_word*)t0)[2]));}

/* a3074 in a3068 in string-prefix? in k1429 in k1426 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3062 in string-prefix? in k1429 in k1426 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length-ci in k1429 in k1426 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3027r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3027r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3027r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[48]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3033,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3039,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3038 in string-suffix-length-ci in k1429 in k1426 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3039,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3045,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3051,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3050 in a3038 in string-suffix-length-ci in k1429 in k1426 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3051,4,t0,t1,t2,t3);}
/* srfi-13.scm: 688  %string-suffix-length-ci */
f_2852(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3044 in a3038 in string-suffix-length-ci in k1429 in k1426 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3032 in string-suffix-length-ci in k1429 in k1426 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length-ci in k1429 in k1426 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2997r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2997r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2997r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[47]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3003,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3009,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3008 in string-prefix-length-ci in k1429 in k1426 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3009,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3015,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3020 in a3008 in string-prefix-length-ci in k1429 in k1426 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3021,4,t0,t1,t2,t3);}
/* srfi-13.scm: 683  %string-prefix-length-ci */
f_2779(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3014 in a3008 in string-prefix-length-ci in k1429 in k1426 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3002 in string-prefix-length-ci in k1429 in k1426 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length in k1429 in k1426 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2967r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2967r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2967r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[46]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2973,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2979,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a2978 in string-suffix-length in k1429 in k1426 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2979,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2985,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2990 in a2978 in string-suffix-length in k1429 in k1426 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2991,4,t0,t1,t2,t3);}
/* srfi-13.scm: 678  %string-suffix-length */
f_2694(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2984 in a2978 in string-suffix-length in k1429 in k1426 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2972 in string-suffix-length in k1429 in k1426 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length in k1429 in k1426 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2937r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2937r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[45]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2943,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2949,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a2948 in string-prefix-length in k1429 in k1426 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2949,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2955,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2960 in a2948 in string-prefix-length in k1429 in k1426 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2961,4,t0,t1,t2,t3);}
/* srfi-13.scm: 673  %string-prefix-length */
f_2621(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2954 in a2948 in string-prefix-length in k1429 in k1426 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2942 in string-prefix-length in k1429 in k1426 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-suffix-length-ci in k1429 in k1426 */
static void C_fcall f_2852(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2852,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2856,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 656  min */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2854 in %string-suffix-length-ci in k1429 in k1426 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_2865(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2865(t5,C_SCHEME_FALSE);}}

/* k2863 in k2854 in %string-suffix-length-ci in k1429 in k1426 */
static void C_fcall f_2865(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2865,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2878(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k2863 in k2854 in %string-suffix-length-ci in k1429 in k1426 */
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2878,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2888(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2913,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
t9=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 664  char-ci=? */
t10=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k2911 in lp in k2863 in k2854 in %string-suffix-length-ci in k1429 in k1426 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2888(t2,(C_word)C_i_not(t1));}

/* k2886 in lp in k2863 in k2854 in %string-suffix-length-ci in k1429 in k1426 */
static void C_fcall f_2888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 667  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2878(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length-ci in k1429 in k1426 */
static void C_fcall f_2779(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2779,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2783,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 642  min */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2781 in %string-prefix-length-ci in k1429 in k1426 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_2792(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2792(t5,C_SCHEME_FALSE);}}

/* k2790 in k2781 in %string-prefix-length-ci in k1429 in k1426 */
static void C_fcall f_2792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2792,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2797(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k2790 in k2781 in %string-prefix-length-ci in k1429 in k1426 */
static void C_fcall f_2797(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2797,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2807(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
t9=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 650  char-ci=? */
t10=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k2826 in lp in k2790 in k2781 in %string-prefix-length-ci in k1429 in k1426 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2807(t2,(C_word)C_i_not(t1));}

/* k2805 in lp in k2790 in k2781 in %string-prefix-length-ci in k1429 in k1426 */
static void C_fcall f_2807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 653  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2797(t4,((C_word*)t0)[6],t2,t3);}}

/* %string-suffix-length in k1429 in k1426 */
static void C_fcall f_2694(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2694,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2698,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 628  min */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2696 in %string-suffix-length in k1429 in k1426 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_2707(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2707(t5,C_SCHEME_FALSE);}}

/* k2705 in k2696 in %string-suffix-length in k1429 in k1426 */
static void C_fcall f_2707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2707,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2720(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k2705 in k2696 in %string-suffix-length in k1429 in k1426 */
static void C_fcall f_2720(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2720,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2730(t7,t5);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_subchar(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_2730(t10,(C_word)C_i_not(t9));}}

/* k2728 in lp in k2705 in k2696 in %string-suffix-length in k1429 in k1426 */
static void C_fcall f_2730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 639  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2720(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length in k1429 in k1426 */
static void C_fcall f_2621(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2621,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2625,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 614  min */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2623 in %string-prefix-length in k1429 in k1426 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_2634(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2634(t5,C_SCHEME_FALSE);}}

/* k2632 in k2623 in %string-prefix-length in k1429 in k1426 */
static void C_fcall f_2634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2634,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2639(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k2632 in k2623 in %string-prefix-length in k1429 in k1426 */
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2639,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2649(t7,t5);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_subchar(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_2649(t10,(C_word)C_i_not(t9));}}

/* k2647 in lp in k2632 in k2623 in %string-prefix-length in k1429 in k1426 */
static void C_fcall f_2649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 625  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2639(t4,((C_word*)t0)[6],t2,t3);}}

/* string-tabulate in k1429 in k1426 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2582,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[39]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2589,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 596  make-string */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k2587 in string-tabulate in k1429 in k1426 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2598(t7,t2,t3);}

/* do264 in k2587 in string-tabulate in k1429 in k1426 */
static void C_fcall f_2598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2598,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2619,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 599  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k2617 in do264 in k2587 in string-tabulate in k1429 in k1426 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2598(t4,((C_word*)t0)[2],t3);}

/* k2590 in k2587 in string-tabulate in k1429 in k1426 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-any in k1429 in k1426 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2452r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2452r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2458,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2464,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2463 in string-any in k1429 in k1426 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2464,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2476(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2506,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 573  char-set? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k2504 in a2463 in string-any in k1429 in k1426 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2511(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2552,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2552(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
/* srfi-13.scm: 587  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[38],*((C_word*)lf[37]+1),((C_word*)t0)[4]);}}}

/* lp in k2504 in a2463 in string-any in k1429 in k1426 */
static void C_fcall f_2552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2552,NULL,3,t0,t1,t2);}
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 584  criteria */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2571,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 585  criteria */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k2569 in lp in k2504 in a2463 in string-any in k1429 in k1426 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* srfi-13.scm: 585  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2552(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* lp in k2504 in a2463 in string-any in k1429 in k1426 */
static void C_fcall f_2511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2511,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 576  char-set-contains? */
t7=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k2519 in lp in k2504 in a2463 in string-any in k1429 in k1426 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 577  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2511(t3,((C_word*)t0)[4],t2);}}

/* lp in a2463 in string-any in k1429 in k1426 */
static C_word C_fcall f_2476(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a2457 in string-any in k1429 in k1426 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[37]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-every in k1429 in k1426 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2322r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2322r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2322r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2328,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2334,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2333 in string-every in k1429 in k1426 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2334,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2346(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2376,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 547  char-set? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k2374 in a2333 in string-every in k1429 in k1426 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2381(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2422,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2422(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 561  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[33],lf[35],*((C_word*)lf[33]+1),((C_word*)t0)[4]);}}}

/* lp in k2374 in a2333 in string-every in k1429 in k1426 */
static void C_fcall f_2422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2422,NULL,3,t0,t1,t2);}
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 558  criteria */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2444,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 559  criteria */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k2442 in lp in k2374 in a2333 in string-every in k1429 in k1426 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 559  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2422(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in k2374 in a2333 in string-every in k1429 in k1426 */
static void C_fcall f_2381(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2381,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
t5=(C_word)C_fixnum_greater_or_equal_p(t3,t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2394,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 550  char-set-contains? */
t8=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2392 in lp in k2374 in a2333 in string-every in k1429 in k1426 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 551  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2381(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in a2333 in string-every in k1429 in k1426 */
static C_word C_fcall f_2346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=t1;
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_greater_or_equal_p(t2,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[3],t1);
t6=(C_word)C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* a2327 in string-every in k1429 in k1426 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[33]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each-index in k1429 in k1426 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_2285r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2285r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2285r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2296 in string-for-each-index in k1429 in k1426 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2297,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2303(t7,t1,t2);}

/* lp in a2296 in string-for-each-index in k1429 in k1426 */
static void C_fcall f_2303(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2303,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2313,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 537  proc */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k2311 in lp in a2296 in string-for-each-index in k1429 in k1426 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 537  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2303(t3,((C_word*)t0)[2],t2);}

/* a2290 in string-for-each-index in k1429 in k1426 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[32]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each in k1429 in k1426 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2244r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2244r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2244r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2255 in string-for-each in k1429 in k1426 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2256,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2262(t7,t1,t2);}

/* lp in a2255 in string-for-each in k1429 in k1426 */
static void C_fcall f_2262(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2262,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2272,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 530  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k2270 in lp in a2255 in string-for-each in k1429 in k1426 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 531  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2262(t3,((C_word*)t0)[2],t2);}

/* a2249 in string-for-each in k1429 in k1426 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[31]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-unfold-right in k1429 in k1426 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_2058r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2058r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_2058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(11);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[29]:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2226,tmp=(C_word)a,a+=2,tmp):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2081,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 483  make-string */
t16=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}

/* k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2083(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(40),((C_word*)t0)[2]);}

/* lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2083,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t4,a[10]=t3,a[11]=t5,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp));
t11=((C_word*)t9)[1];
f_2089(t11,t1,t6,t7);}

/* lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_fcall f_2089(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2089,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 488  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 505  make-final */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 489  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k2097 in k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 490  g */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2100 in k2097 in k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=((C_word*)t0)[10];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_setsubchar(((C_word*)t0)[9],t3,((C_word*)t0)[8]);
/* srfi-13.scm: 494  lp2 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_2089(t5,((C_word*)t0)[6],t3,t1);}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2123,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 497  min */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(4096),t3);}}

/* k2121 in k2100 in k2097 in k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 498  make-string */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2124 in k2121 in k2100 in k2097 in k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_setsubchar(t1,t2,((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 501  lp */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2083(t6,((C_word*)t0)[3],t4,t5,t1,((C_word*)t0)[10],t2,((C_word*)t0)[2]);}

/* k2144 in k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[8]));
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(t3,((C_word*)t0)[5]),t4);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[4],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_u_fixnum_plus(t5,t2);
/* srfi-13.scm: 510  make-string */
t8=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k2159 in k2144 in k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=f_5750(t1,C_fix(0),((C_word*)t0)[11],C_fix(0),((C_word*)t0)[10]);
t3=f_5750(t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=f_2176(t5,t4,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}

/* lp in k2159 in k2144 in k2211 in lp2 in lp in k2079 in string-unfold-right in k1429 in k1426 */
static C_word C_fcall f_2176(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=f_5750(((C_word*)t0)[4],t1,t3,C_fix(0),t5);
t7=(C_word)C_u_fixnum_plus(t1,t5);
t9=t7;
t10=t4;
t1=t9;
t2=t10;
goto loop;}
else{
return(f_5750(((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]));}}

/* f_2226 in string-unfold-right in k1429 in k1426 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2226,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[30]);}

/* string-unfold in k1429 in k1426 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_1879r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_1879r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_1879r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(11);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[24]:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2040,tmp=(C_word)a,a+=2,tmp):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1902,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 438  make-string */
t16=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}

/* k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1904(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(0),((C_word*)t0)[2]);}

/* lp in k1900 in string-unfold in k1429 in k1426 */
static void C_fcall f_1904(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1904,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t2,a[10]=t4,a[11]=t3,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp));
t11=((C_word*)t9)[1];
f_1910(t11,t1,t6,t7);}

/* lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_fcall f_1910(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1910,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 443  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 458  make-final */
t3=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 444  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k1918 in k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 445  g */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1921 in k1918 in k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[10],((C_word*)t0)[7]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* srfi-13.scm: 448  lp2 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_1910(t6,((C_word*)t0)[5],t5,t1);}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1945,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 451  min */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(4096),t4);}}

/* k1943 in k1921 in k1918 in k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 452  make-string */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1946 in k1943 in k1921 in k1918 in k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(C_word)C_setsubchar(t1,C_fix(0),((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],((C_word*)t0)[6]);
/* srfi-13.scm: 454  lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1904(t5,((C_word*)t0)[4],t3,t4,t1,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}

/* k1963 in k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t4=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(t3,((C_word*)t0)[6]),((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t1,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_u_fixnum_plus(t4,t2);
/* srfi-13.scm: 462  make-string */
t7=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k1975 in k1963 in k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=f_5750(t1,((C_word*)t0)[10],((C_word*)t0)[9],C_fix(0),((C_word*)t0)[8]);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],((C_word*)t0)[7]);
t4=f_5750(t1,t3,((C_word*)t0)[6],C_fix(0),((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1994,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=f_1994(t5,t3,((C_word*)t0)[5]);
t7=f_5750(t1,C_fix(0),((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}

/* lp in k1975 in k1963 in k2025 in lp2 in lp in k1900 in string-unfold in k1429 in k1426 */
static C_word C_fcall f_1994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=(C_word)C_u_fixnum_difference(t1,t5);
t7=f_5750(((C_word*)t0)[2],t6,t3,C_fix(0),t5);
t9=t6;
t10=t4;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* f_2040 in string-unfold in k1429 in k1426 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2040,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[25]);}

/* string-fold-right in k1429 in k1426 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_1833r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1833r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1833r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1839,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1845,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a1844 in string-fold-right in k1429 in k1426 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1845,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1855(t8,t1,((C_word*)t0)[2],t4);}

/* lp in a1844 in string-fold-right in k1429 in k1426 */
static void C_fcall f_1855(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1855,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1869,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 363  kons */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k1867 in lp in a1844 in string-fold-right in k1429 in k1426 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 363  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1855(t3,((C_word*)t0)[2],t1,t2);}

/* a1838 in string-fold-right in k1429 in k1426 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[22]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fold in k1429 in k1426 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_1791r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1791r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1791r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1797,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1803,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a1802 in string-fold in k1429 in k1426 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1803,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1809(t7,t1,((C_word*)t0)[2],t2);}

/* lp in a1802 in string-fold in k1429 in k1426 */
static void C_fcall f_1809(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1809,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1823,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 356  kons */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k1821 in lp in a1802 in string-fold in k1429 in k1426 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 356  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1809(t3,((C_word*)t0)[2],t1,t2);}

/* a1796 in string-fold in k1429 in k1426 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[21]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map! in k1429 in k1426 */
static void C_fcall f_1758(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1758,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1764,a[2]=t2,a[3]=t7,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_1764(t9,t1,t4);}

/* do70 in %string-map! in k1429 in k1426 */
static void C_fcall f_1764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1764,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1785,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
/* srfi-13.scm: 350  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k1783 in do70 in %string-map! in k1429 in k1426 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1764(t4,((C_word*)t0)[2],t3);}

/* string-map! in k1429 in k1426 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_1740r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1740r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1746,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1752,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a1751 in string-map! in k1429 in k1426 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1752,4,t0,t1,t2,t3);}
/* srfi-13.scm: 345  %string-map! */
f_1758(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1745 in string-map! in k1429 in k1426 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[19]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map in k1429 in k1426 */
static void C_fcall f_1697(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1697,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_u_fixnum_difference(t5,t4);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1704,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 335  make-string */
t8=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}

/* k1702 in %string-map in k1429 in k1426 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1707,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1709(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do54 in k1702 in %string-map in k1429 in k1426 */
static void C_fcall f_1709(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1709,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1734,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 339  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k1732 in do54 in k1702 in %string-map in k1429 in k1426 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_1709(t5,((C_word*)t0)[2],t3,t4);}

/* k1705 in k1702 in %string-map in k1429 in k1426 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-map in k1429 in k1426 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_1679r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1679r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1679r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1685,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1691,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a1690 in string-map in k1429 in k1426 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1691,4,t0,t1,t2,t3);}
/* srfi-13.scm: 331  %string-map */
f_1697(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1684 in string-map in k1429 in k1426 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[16]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-copy in k1429 in k1426 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1661r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1661r(t0,t1,t2,t3);}}

static void C_ccall f_1661r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1667,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1673,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a1672 in string-copy in k1429 in k1426 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1673,4,t0,t1,t2,t3);}
/* srfi-13.scm: 296  ##sys#substring */
t4=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* a1666 in string-copy in k1429 in k1426 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[15]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %substring/shared in k1429 in k1426 */
static void C_fcall f_1639(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1639,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1646,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t4;
t9=t5;
f_1646(t9,(C_word)C_eqp(t8,t7));}
else{
t7=t5;
f_1646(t7,C_SCHEME_FALSE);}}

/* k1644 in %substring/shared in k1429 in k1426 */
static void C_fcall f_1646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
/* srfi-13.scm: 292  ##sys#substring */
t2=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring/shared in k1429 in k1426 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1609r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1609r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?t5:(C_word)C_u_i_car(t4));
t8=(C_word)C_i_check_exact_2(t7,lf[12]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1622,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 277  check-substring-spec */
t10=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[12],t2,t3,t7);}

/* k1620 in substring/shared in k1429 in k1426 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 278  %substring/shared */
f_1639(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* check-substring-spec in k1429 in k1426 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1593,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1607,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 245  substring-spec-ok? */
t7=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,t5);}

/* k1605 in check-substring-spec in k1429 in k1426 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* srfi-13.scm: 246  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[6],lf[10],lf[11],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring-spec-ok? in k1429 in k1426 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1553,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_stringp(t2))){
if(C_truep((C_word)C_fixnump(t3))){
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t5))){
t6=t3;
t7=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=(C_word)C_fix((C_word)C_header_size(t2));
t9=t4;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_fixnum_less_or_equal_p(t9,t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* string-parse-final-start+end in k1429 in k1426 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1526,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1532,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a1537 in string-parse-final-start+end in k1429 in k1426 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1538,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
/* srfi-13.scm: 229  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[7],lf[8],((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 230  values */
C_values(4,0,t1,t3,t4);}}

/* a1531 in string-parse-final-start+end in k1429 in k1426 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1532,2,t0,t1);}
/* srfi-13.scm: 228  string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-parse-start+end in k1429 in k1426 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1433,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t3,lf[2]);
t6=(C_word)C_fix((C_word)C_header_size(t3));
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_truep((C_word)C_fixnump(t7))?(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1463,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1499,a[2]=t3,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 211  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}
else{
/* srfi-13.scm: 223  ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t1,lf[2],lf[6],t2,t7,t3);}}
else{
/* srfi-13.scm: 225  values */
C_values(5,0,t1,C_SCHEME_END_OF_LIST,C_fix(0),t6);}}

/* a1498 in string-parse-start+end in k1429 in k1426 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1499,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t4))){
/* srfi-13.scm: 220  values */
C_values(5,0,t1,t3,((C_word*)t0)[4],t2);}
else{
/* srfi-13.scm: 221  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t1,lf[2],lf[5],((C_word*)t0)[3],((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* a1462 in string-parse-start+end in k1429 in k1426 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_truep((C_word)C_fixnump(t2))?(C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-13.scm: 217  values */
C_values(4,0,t1,t2,t3);}
else{
/* srfi-13.scm: 218  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[2],lf[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 219  values */
C_values(4,0,t1,((C_word*)t0)[4],((C_word*)t0)[5]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[540] = {
{"toplevelsrfi-13.scm",(void*)C_srfi_13_toplevel},
{"f_1428srfi-13.scm",(void*)f_1428},
{"f_1431srfi-13.scm",(void*)f_1431},
{"f_7347srfi-13.scm",(void*)f_7347},
{"f_7456srfi-13.scm",(void*)f_7456},
{"f_7426srfi-13.scm",(void*)f_7426},
{"f_7409srfi-13.scm",(void*)f_7409},
{"f_7364srfi-13.scm",(void*)f_7364},
{"f_7370srfi-13.scm",(void*)f_7370},
{"f_7392srfi-13.scm",(void*)f_7392},
{"f_7274srfi-13.scm",(void*)f_7274},
{"f_7345srfi-13.scm",(void*)f_7345},
{"f_7305srfi-13.scm",(void*)f_7305},
{"f_7134srfi-13.scm",(void*)f_7134},
{"f_7187srfi-13.scm",(void*)f_7187},
{"f_7200srfi-13.scm",(void*)f_7200},
{"f_7253srfi-13.scm",(void*)f_7253},
{"f_7249srfi-13.scm",(void*)f_7249},
{"f_7143srfi-13.scm",(void*)f_7143},
{"f_7165srfi-13.scm",(void*)f_7165},
{"f_7155srfi-13.scm",(void*)f_7155},
{"f_6996srfi-13.scm",(void*)f_6996},
{"f_7049srfi-13.scm",(void*)f_7049},
{"f_7112srfi-13.scm",(void*)f_7112},
{"f_7115srfi-13.scm",(void*)f_7115},
{"f_7109srfi-13.scm",(void*)f_7109},
{"f_7105srfi-13.scm",(void*)f_7105},
{"f_7005srfi-13.scm",(void*)f_7005},
{"f_7027srfi-13.scm",(void*)f_7027},
{"f_7017srfi-13.scm",(void*)f_7017},
{"f_6914srfi-13.scm",(void*)f_6914},
{"f_6932srfi-13.scm",(void*)f_6932},
{"f_6938srfi-13.scm",(void*)f_6938},
{"f_6942srfi-13.scm",(void*)f_6942},
{"f_6951srfi-13.scm",(void*)f_6951},
{"f_6976srfi-13.scm",(void*)f_6976},
{"f_6965srfi-13.scm",(void*)f_6965},
{"f_6926srfi-13.scm",(void*)f_6926},
{"f_6863srfi-13.scm",(void*)f_6863},
{"f_6867srfi-13.scm",(void*)f_6867},
{"f_6878srfi-13.scm",(void*)f_6878},
{"f_6891srfi-13.scm",(void*)f_6891},
{"f_6872srfi-13.scm",(void*)f_6872},
{"f_6820srfi-13.scm",(void*)f_6820},
{"f_6824srfi-13.scm",(void*)f_6824},
{"f_6832srfi-13.scm",(void*)f_6832},
{"f_6694srfi-13.scm",(void*)f_6694},
{"f_6718srfi-13.scm",(void*)f_6718},
{"f_6768srfi-13.scm",(void*)f_6768},
{"f_6609srfi-13.scm",(void*)f_6609},
{"f_6636srfi-13.scm",(void*)f_6636},
{"f_6536srfi-13.scm",(void*)f_6536},
{"f_6543srfi-13.scm",(void*)f_6543},
{"f_6548srfi-13.scm",(void*)f_6548},
{"f_6577srfi-13.scm",(void*)f_6577},
{"f_6434srfi-13.scm",(void*)f_6434},
{"f_6440srfi-13.scm",(void*)f_6440},
{"f_6494srfi-13.scm",(void*)f_6494},
{"f_6499srfi-13.scm",(void*)f_6499},
{"f_6428srfi-13.scm",(void*)f_6428},
{"f_6382srfi-13.scm",(void*)f_6382},
{"f_6394srfi-13.scm",(void*)f_6394},
{"f_6404srfi-13.scm",(void*)f_6404},
{"f_6388srfi-13.scm",(void*)f_6388},
{"f_6327srfi-13.scm",(void*)f_6327},
{"f_6339srfi-13.scm",(void*)f_6339},
{"f_6349srfi-13.scm",(void*)f_6349},
{"f_6333srfi-13.scm",(void*)f_6333},
{"f_6272srfi-13.scm",(void*)f_6272},
{"f_6284srfi-13.scm",(void*)f_6284},
{"f_6291srfi-13.scm",(void*)f_6291},
{"f_6300srfi-13.scm",(void*)f_6300},
{"f_6278srfi-13.scm",(void*)f_6278},
{"f_6269srfi-13.scm",(void*)f_6269},
{"f_6148srfi-13.scm",(void*)f_6148},
{"f_6172srfi-13.scm",(void*)f_6172},
{"f_6181srfi-13.scm",(void*)f_6181},
{"f_6213srfi-13.scm",(void*)f_6213},
{"f_6220srfi-13.scm",(void*)f_6220},
{"f_6211srfi-13.scm",(void*)f_6211},
{"f_6166srfi-13.scm",(void*)f_6166},
{"f_6110srfi-13.scm",(void*)f_6110},
{"f_6116srfi-13.scm",(void*)f_6116},
{"f_6123srfi-13.scm",(void*)f_6123},
{"f_5975srfi-13.scm",(void*)f_5975},
{"f_5993srfi-13.scm",(void*)f_5993},
{"f_6000srfi-13.scm",(void*)f_6000},
{"f_6017srfi-13.scm",(void*)f_6017},
{"f_6032srfi-13.scm",(void*)f_6032},
{"f_6065srfi-13.scm",(void*)f_6065},
{"f_6059srfi-13.scm",(void*)f_6059},
{"f_6003srfi-13.scm",(void*)f_6003},
{"f_5987srfi-13.scm",(void*)f_5987},
{"f_5877srfi-13.scm",(void*)f_5877},
{"f_5884srfi-13.scm",(void*)f_5884},
{"f_5893srfi-13.scm",(void*)f_5893},
{"f_5915srfi-13.scm",(void*)f_5915},
{"f_5815srfi-13.scm",(void*)f_5815},
{"f_5827srfi-13.scm",(void*)f_5827},
{"f_5839srfi-13.scm",(void*)f_5839},
{"f_5851srfi-13.scm",(void*)f_5851},
{"f_5864srfi-13.scm",(void*)f_5864},
{"f_5833srfi-13.scm",(void*)f_5833},
{"f_5821srfi-13.scm",(void*)f_5821},
{"f_5753srfi-13.scm",(void*)f_5753},
{"f_5765srfi-13.scm",(void*)f_5765},
{"f_5777srfi-13.scm",(void*)f_5777},
{"f_5789srfi-13.scm",(void*)f_5789},
{"f_5802srfi-13.scm",(void*)f_5802},
{"f_5771srfi-13.scm",(void*)f_5771},
{"f_5759srfi-13.scm",(void*)f_5759},
{"f_5750srfi-13.scm",(void*)f_5750},
{"f_5718srfi-13.scm",(void*)f_5718},
{"f_5730srfi-13.scm",(void*)f_5730},
{"f_5737srfi-13.scm",(void*)f_5737},
{"f_5724srfi-13.scm",(void*)f_5724},
{"f_5677srfi-13.scm",(void*)f_5677},
{"f_5689srfi-13.scm",(void*)f_5689},
{"f_5699srfi-13.scm",(void*)f_5699},
{"f_5683srfi-13.scm",(void*)f_5683},
{"f_5542srfi-13.scm",(void*)f_5542},
{"f_5554srfi-13.scm",(void*)f_5554},
{"f_5600srfi-13.scm",(void*)f_5600},
{"f_5644srfi-13.scm",(void*)f_5644},
{"f_5665srfi-13.scm",(void*)f_5665},
{"f_5605srfi-13.scm",(void*)f_5605},
{"f_5626srfi-13.scm",(void*)f_5626},
{"f_5566srfi-13.scm",(void*)f_5566},
{"f_5548srfi-13.scm",(void*)f_5548},
{"f_5407srfi-13.scm",(void*)f_5407},
{"f_5419srfi-13.scm",(void*)f_5419},
{"f_5465srfi-13.scm",(void*)f_5465},
{"f_5513srfi-13.scm",(void*)f_5513},
{"f_5526srfi-13.scm",(void*)f_5526},
{"f_5474srfi-13.scm",(void*)f_5474},
{"f_5487srfi-13.scm",(void*)f_5487},
{"f_5435srfi-13.scm",(void*)f_5435},
{"f_5413srfi-13.scm",(void*)f_5413},
{"f_5284srfi-13.scm",(void*)f_5284},
{"f_5296srfi-13.scm",(void*)f_5296},
{"f_5338srfi-13.scm",(void*)f_5338},
{"f_5378srfi-13.scm",(void*)f_5378},
{"f_5391srfi-13.scm",(void*)f_5391},
{"f_5343srfi-13.scm",(void*)f_5343},
{"f_5356srfi-13.scm",(void*)f_5356},
{"f_5308srfi-13.scm",(void*)f_5308},
{"f_5290srfi-13.scm",(void*)f_5290},
{"f_5149srfi-13.scm",(void*)f_5149},
{"f_5161srfi-13.scm",(void*)f_5161},
{"f_5207srfi-13.scm",(void*)f_5207},
{"f_5255srfi-13.scm",(void*)f_5255},
{"f_5268srfi-13.scm",(void*)f_5268},
{"f_5216srfi-13.scm",(void*)f_5216},
{"f_5229srfi-13.scm",(void*)f_5229},
{"f_5177srfi-13.scm",(void*)f_5177},
{"f_5155srfi-13.scm",(void*)f_5155},
{"f_5026srfi-13.scm",(void*)f_5026},
{"f_5038srfi-13.scm",(void*)f_5038},
{"f_5080srfi-13.scm",(void*)f_5080},
{"f_5120srfi-13.scm",(void*)f_5120},
{"f_5133srfi-13.scm",(void*)f_5133},
{"f_5085srfi-13.scm",(void*)f_5085},
{"f_5098srfi-13.scm",(void*)f_5098},
{"f_5050srfi-13.scm",(void*)f_5050},
{"f_5032srfi-13.scm",(void*)f_5032},
{"f_4918srfi-13.scm",(void*)f_4918},
{"f_4930srfi-13.scm",(void*)f_4930},
{"f_5012srfi-13.scm",(void*)f_5012},
{"f_4973srfi-13.scm",(void*)f_4973},
{"f_4999srfi-13.scm",(void*)f_4999},
{"f_5006srfi-13.scm",(void*)f_5006},
{"f_4976srfi-13.scm",(void*)f_4976},
{"f_4979srfi-13.scm",(void*)f_4979},
{"f_4984srfi-13.scm",(void*)f_4984},
{"f_4991srfi-13.scm",(void*)f_4991},
{"f_4982srfi-13.scm",(void*)f_4982},
{"f_4943srfi-13.scm",(void*)f_4943},
{"f_4957srfi-13.scm",(void*)f_4957},
{"f_4964srfi-13.scm",(void*)f_4964},
{"f_4946srfi-13.scm",(void*)f_4946},
{"f_4924srfi-13.scm",(void*)f_4924},
{"f_4810srfi-13.scm",(void*)f_4810},
{"f_4822srfi-13.scm",(void*)f_4822},
{"f_4904srfi-13.scm",(void*)f_4904},
{"f_4865srfi-13.scm",(void*)f_4865},
{"f_4891srfi-13.scm",(void*)f_4891},
{"f_4898srfi-13.scm",(void*)f_4898},
{"f_4868srfi-13.scm",(void*)f_4868},
{"f_4871srfi-13.scm",(void*)f_4871},
{"f_4876srfi-13.scm",(void*)f_4876},
{"f_4883srfi-13.scm",(void*)f_4883},
{"f_4874srfi-13.scm",(void*)f_4874},
{"f_4835srfi-13.scm",(void*)f_4835},
{"f_4849srfi-13.scm",(void*)f_4849},
{"f_4856srfi-13.scm",(void*)f_4856},
{"f_4838srfi-13.scm",(void*)f_4838},
{"f_4816srfi-13.scm",(void*)f_4816},
{"f_4748srfi-13.scm",(void*)f_4748},
{"f_4769srfi-13.scm",(void*)f_4769},
{"f_4789srfi-13.scm",(void*)f_4789},
{"f_4763srfi-13.scm",(void*)f_4763},
{"f_4690srfi-13.scm",(void*)f_4690},
{"f_4711srfi-13.scm",(void*)f_4711},
{"f_4731srfi-13.scm",(void*)f_4731},
{"f_4705srfi-13.scm",(void*)f_4705},
{"f_4640srfi-13.scm",(void*)f_4640},
{"f_4658srfi-13.scm",(void*)f_4658},
{"f_4662srfi-13.scm",(void*)f_4662},
{"f_4676srfi-13.scm",(void*)f_4676},
{"f_4652srfi-13.scm",(void*)f_4652},
{"f_4594srfi-13.scm",(void*)f_4594},
{"f_4612srfi-13.scm",(void*)f_4612},
{"f_4616srfi-13.scm",(void*)f_4616},
{"f_4606srfi-13.scm",(void*)f_4606},
{"f_4552srfi-13.scm",(void*)f_4552},
{"f_4570srfi-13.scm",(void*)f_4570},
{"f_4574srfi-13.scm",(void*)f_4574},
{"f_4564srfi-13.scm",(void*)f_4564},
{"f_4525srfi-13.scm",(void*)f_4525},
{"f_4532srfi-13.scm",(void*)f_4532},
{"f_4502srfi-13.scm",(void*)f_4502},
{"f_4509srfi-13.scm",(void*)f_4509},
{"f_4475srfi-13.scm",(void*)f_4475},
{"f_4482srfi-13.scm",(void*)f_4482},
{"f_4455srfi-13.scm",(void*)f_4455},
{"f_4462srfi-13.scm",(void*)f_4462},
{"f_4430srfi-13.scm",(void*)f_4430},
{"f_4442srfi-13.scm",(void*)f_4442},
{"f_4446srfi-13.scm",(void*)f_4446},
{"f_4449srfi-13.scm",(void*)f_4449},
{"f_4436srfi-13.scm",(void*)f_4436},
{"f_4412srfi-13.scm",(void*)f_4412},
{"f_4424srfi-13.scm",(void*)f_4424},
{"f_4418srfi-13.scm",(void*)f_4418},
{"f_4353srfi-13.scm",(void*)f_4353},
{"f_4359srfi-13.scm",(void*)f_4359},
{"f_4406srfi-13.scm",(void*)f_4406},
{"f_4363srfi-13.scm",(void*)f_4363},
{"f_4393srfi-13.scm",(void*)f_4393},
{"f_4375srfi-13.scm",(void*)f_4375},
{"f_4381srfi-13.scm",(void*)f_4381},
{"f_4335srfi-13.scm",(void*)f_4335},
{"f_4347srfi-13.scm",(void*)f_4347},
{"f_4341srfi-13.scm",(void*)f_4341},
{"f_4317srfi-13.scm",(void*)f_4317},
{"f_4329srfi-13.scm",(void*)f_4329},
{"f_4323srfi-13.scm",(void*)f_4323},
{"f_4299srfi-13.scm",(void*)f_4299},
{"f_4311srfi-13.scm",(void*)f_4311},
{"f_4305srfi-13.scm",(void*)f_4305},
{"f_4281srfi-13.scm",(void*)f_4281},
{"f_4293srfi-13.scm",(void*)f_4293},
{"f_4287srfi-13.scm",(void*)f_4287},
{"f_4225srfi-13.scm",(void*)f_4225},
{"f_4235srfi-13.scm",(void*)f_4235},
{"f_4249srfi-13.scm",(void*)f_4249},
{"f_4255srfi-13.scm",(void*)f_4255},
{"f_4243srfi-13.scm",(void*)f_4243},
{"f_4179srfi-13.scm",(void*)f_4179},
{"f_4189srfi-13.scm",(void*)f_4189},
{"f_4203srfi-13.scm",(void*)f_4203},
{"f_4197srfi-13.scm",(void*)f_4197},
{"f_4107srfi-13.scm",(void*)f_4107},
{"f_4125srfi-13.scm",(void*)f_4125},
{"f_4158srfi-13.scm",(void*)f_4158},
{"f_4160srfi-13.scm",(void*)f_4160},
{"f_4109srfi-13.scm",(void*)f_4109},
{"f_4059srfi-13.scm",(void*)f_4059},
{"f_4071srfi-13.scm",(void*)f_4071},
{"f_4083srfi-13.scm",(void*)f_4083},
{"f_4090srfi-13.scm",(void*)f_4090},
{"f_4098srfi-13.scm",(void*)f_4098},
{"f_4077srfi-13.scm",(void*)f_4077},
{"f_4065srfi-13.scm",(void*)f_4065},
{"f_4011srfi-13.scm",(void*)f_4011},
{"f_4023srfi-13.scm",(void*)f_4023},
{"f_4035srfi-13.scm",(void*)f_4035},
{"f_4042srfi-13.scm",(void*)f_4042},
{"f_4050srfi-13.scm",(void*)f_4050},
{"f_4029srfi-13.scm",(void*)f_4029},
{"f_4017srfi-13.scm",(void*)f_4017},
{"f_3960srfi-13.scm",(void*)f_3960},
{"f_3972srfi-13.scm",(void*)f_3972},
{"f_3984srfi-13.scm",(void*)f_3984},
{"f_3991srfi-13.scm",(void*)f_3991},
{"f_4002srfi-13.scm",(void*)f_4002},
{"f_3999srfi-13.scm",(void*)f_3999},
{"f_3978srfi-13.scm",(void*)f_3978},
{"f_3966srfi-13.scm",(void*)f_3966},
{"f_3909srfi-13.scm",(void*)f_3909},
{"f_3921srfi-13.scm",(void*)f_3921},
{"f_3933srfi-13.scm",(void*)f_3933},
{"f_3940srfi-13.scm",(void*)f_3940},
{"f_3951srfi-13.scm",(void*)f_3951},
{"f_3948srfi-13.scm",(void*)f_3948},
{"f_3927srfi-13.scm",(void*)f_3927},
{"f_3915srfi-13.scm",(void*)f_3915},
{"f_3842srfi-13.scm",(void*)f_3842},
{"f_3854srfi-13.scm",(void*)f_3854},
{"f_3866srfi-13.scm",(void*)f_3866},
{"f_3889srfi-13.scm",(void*)f_3889},
{"f_3884srfi-13.scm",(void*)f_3884},
{"f_3860srfi-13.scm",(void*)f_3860},
{"f_3848srfi-13.scm",(void*)f_3848},
{"f_3780srfi-13.scm",(void*)f_3780},
{"f_3792srfi-13.scm",(void*)f_3792},
{"f_3804srfi-13.scm",(void*)f_3804},
{"f_3814srfi-13.scm",(void*)f_3814},
{"f_3825srfi-13.scm",(void*)f_3825},
{"f_3822srfi-13.scm",(void*)f_3822},
{"f_3798srfi-13.scm",(void*)f_3798},
{"f_3786srfi-13.scm",(void*)f_3786},
{"f_3732srfi-13.scm",(void*)f_3732},
{"f_3744srfi-13.scm",(void*)f_3744},
{"f_3756srfi-13.scm",(void*)f_3756},
{"f_3763srfi-13.scm",(void*)f_3763},
{"f_3771srfi-13.scm",(void*)f_3771},
{"f_3750srfi-13.scm",(void*)f_3750},
{"f_3738srfi-13.scm",(void*)f_3738},
{"f_3684srfi-13.scm",(void*)f_3684},
{"f_3696srfi-13.scm",(void*)f_3696},
{"f_3708srfi-13.scm",(void*)f_3708},
{"f_3715srfi-13.scm",(void*)f_3715},
{"f_3723srfi-13.scm",(void*)f_3723},
{"f_3702srfi-13.scm",(void*)f_3702},
{"f_3690srfi-13.scm",(void*)f_3690},
{"f_3633srfi-13.scm",(void*)f_3633},
{"f_3645srfi-13.scm",(void*)f_3645},
{"f_3657srfi-13.scm",(void*)f_3657},
{"f_3664srfi-13.scm",(void*)f_3664},
{"f_3675srfi-13.scm",(void*)f_3675},
{"f_3672srfi-13.scm",(void*)f_3672},
{"f_3651srfi-13.scm",(void*)f_3651},
{"f_3639srfi-13.scm",(void*)f_3639},
{"f_3582srfi-13.scm",(void*)f_3582},
{"f_3594srfi-13.scm",(void*)f_3594},
{"f_3606srfi-13.scm",(void*)f_3606},
{"f_3613srfi-13.scm",(void*)f_3613},
{"f_3624srfi-13.scm",(void*)f_3624},
{"f_3621srfi-13.scm",(void*)f_3621},
{"f_3600srfi-13.scm",(void*)f_3600},
{"f_3588srfi-13.scm",(void*)f_3588},
{"f_3515srfi-13.scm",(void*)f_3515},
{"f_3527srfi-13.scm",(void*)f_3527},
{"f_3539srfi-13.scm",(void*)f_3539},
{"f_3562srfi-13.scm",(void*)f_3562},
{"f_3557srfi-13.scm",(void*)f_3557},
{"f_3533srfi-13.scm",(void*)f_3533},
{"f_3521srfi-13.scm",(void*)f_3521},
{"f_3453srfi-13.scm",(void*)f_3453},
{"f_3465srfi-13.scm",(void*)f_3465},
{"f_3477srfi-13.scm",(void*)f_3477},
{"f_3487srfi-13.scm",(void*)f_3487},
{"f_3498srfi-13.scm",(void*)f_3498},
{"f_3495srfi-13.scm",(void*)f_3495},
{"f_3471srfi-13.scm",(void*)f_3471},
{"f_3459srfi-13.scm",(void*)f_3459},
{"f_3423srfi-13.scm",(void*)f_3423},
{"f_3435srfi-13.scm",(void*)f_3435},
{"f_3447srfi-13.scm",(void*)f_3447},
{"f_3441srfi-13.scm",(void*)f_3441},
{"f_3429srfi-13.scm",(void*)f_3429},
{"f_3393srfi-13.scm",(void*)f_3393},
{"f_3405srfi-13.scm",(void*)f_3405},
{"f_3417srfi-13.scm",(void*)f_3417},
{"f_3411srfi-13.scm",(void*)f_3411},
{"f_3399srfi-13.scm",(void*)f_3399},
{"f_3331srfi-13.scm",(void*)f_3331},
{"f_3341srfi-13.scm",(void*)f_3341},
{"f_3375srfi-13.scm",(void*)f_3375},
{"f_3366srfi-13.scm",(void*)f_3366},
{"f_3269srfi-13.scm",(void*)f_3269},
{"f_3279srfi-13.scm",(void*)f_3279},
{"f_3304srfi-13.scm",(void*)f_3304},
{"f_3147srfi-13.scm",(void*)f_3147},
{"f_3159srfi-13.scm",(void*)f_3159},
{"f_3171srfi-13.scm",(void*)f_3171},
{"f_3263srfi-13.scm",(void*)f_3263},
{"f_3165srfi-13.scm",(void*)f_3165},
{"f_3153srfi-13.scm",(void*)f_3153},
{"f_3117srfi-13.scm",(void*)f_3117},
{"f_3129srfi-13.scm",(void*)f_3129},
{"f_3141srfi-13.scm",(void*)f_3141},
{"f_3240srfi-13.scm",(void*)f_3240},
{"f_3135srfi-13.scm",(void*)f_3135},
{"f_3123srfi-13.scm",(void*)f_3123},
{"f_3087srfi-13.scm",(void*)f_3087},
{"f_3099srfi-13.scm",(void*)f_3099},
{"f_3111srfi-13.scm",(void*)f_3111},
{"f_3217srfi-13.scm",(void*)f_3217},
{"f_3105srfi-13.scm",(void*)f_3105},
{"f_3093srfi-13.scm",(void*)f_3093},
{"f_3057srfi-13.scm",(void*)f_3057},
{"f_3069srfi-13.scm",(void*)f_3069},
{"f_3081srfi-13.scm",(void*)f_3081},
{"f_3194srfi-13.scm",(void*)f_3194},
{"f_3075srfi-13.scm",(void*)f_3075},
{"f_3063srfi-13.scm",(void*)f_3063},
{"f_3027srfi-13.scm",(void*)f_3027},
{"f_3039srfi-13.scm",(void*)f_3039},
{"f_3051srfi-13.scm",(void*)f_3051},
{"f_3045srfi-13.scm",(void*)f_3045},
{"f_3033srfi-13.scm",(void*)f_3033},
{"f_2997srfi-13.scm",(void*)f_2997},
{"f_3009srfi-13.scm",(void*)f_3009},
{"f_3021srfi-13.scm",(void*)f_3021},
{"f_3015srfi-13.scm",(void*)f_3015},
{"f_3003srfi-13.scm",(void*)f_3003},
{"f_2967srfi-13.scm",(void*)f_2967},
{"f_2979srfi-13.scm",(void*)f_2979},
{"f_2991srfi-13.scm",(void*)f_2991},
{"f_2985srfi-13.scm",(void*)f_2985},
{"f_2973srfi-13.scm",(void*)f_2973},
{"f_2937srfi-13.scm",(void*)f_2937},
{"f_2949srfi-13.scm",(void*)f_2949},
{"f_2961srfi-13.scm",(void*)f_2961},
{"f_2955srfi-13.scm",(void*)f_2955},
{"f_2943srfi-13.scm",(void*)f_2943},
{"f_2852srfi-13.scm",(void*)f_2852},
{"f_2856srfi-13.scm",(void*)f_2856},
{"f_2865srfi-13.scm",(void*)f_2865},
{"f_2878srfi-13.scm",(void*)f_2878},
{"f_2913srfi-13.scm",(void*)f_2913},
{"f_2888srfi-13.scm",(void*)f_2888},
{"f_2779srfi-13.scm",(void*)f_2779},
{"f_2783srfi-13.scm",(void*)f_2783},
{"f_2792srfi-13.scm",(void*)f_2792},
{"f_2797srfi-13.scm",(void*)f_2797},
{"f_2828srfi-13.scm",(void*)f_2828},
{"f_2807srfi-13.scm",(void*)f_2807},
{"f_2694srfi-13.scm",(void*)f_2694},
{"f_2698srfi-13.scm",(void*)f_2698},
{"f_2707srfi-13.scm",(void*)f_2707},
{"f_2720srfi-13.scm",(void*)f_2720},
{"f_2730srfi-13.scm",(void*)f_2730},
{"f_2621srfi-13.scm",(void*)f_2621},
{"f_2625srfi-13.scm",(void*)f_2625},
{"f_2634srfi-13.scm",(void*)f_2634},
{"f_2639srfi-13.scm",(void*)f_2639},
{"f_2649srfi-13.scm",(void*)f_2649},
{"f_2582srfi-13.scm",(void*)f_2582},
{"f_2589srfi-13.scm",(void*)f_2589},
{"f_2598srfi-13.scm",(void*)f_2598},
{"f_2619srfi-13.scm",(void*)f_2619},
{"f_2592srfi-13.scm",(void*)f_2592},
{"f_2452srfi-13.scm",(void*)f_2452},
{"f_2464srfi-13.scm",(void*)f_2464},
{"f_2506srfi-13.scm",(void*)f_2506},
{"f_2552srfi-13.scm",(void*)f_2552},
{"f_2571srfi-13.scm",(void*)f_2571},
{"f_2511srfi-13.scm",(void*)f_2511},
{"f_2521srfi-13.scm",(void*)f_2521},
{"f_2476srfi-13.scm",(void*)f_2476},
{"f_2458srfi-13.scm",(void*)f_2458},
{"f_2322srfi-13.scm",(void*)f_2322},
{"f_2334srfi-13.scm",(void*)f_2334},
{"f_2376srfi-13.scm",(void*)f_2376},
{"f_2422srfi-13.scm",(void*)f_2422},
{"f_2444srfi-13.scm",(void*)f_2444},
{"f_2381srfi-13.scm",(void*)f_2381},
{"f_2394srfi-13.scm",(void*)f_2394},
{"f_2346srfi-13.scm",(void*)f_2346},
{"f_2328srfi-13.scm",(void*)f_2328},
{"f_2285srfi-13.scm",(void*)f_2285},
{"f_2297srfi-13.scm",(void*)f_2297},
{"f_2303srfi-13.scm",(void*)f_2303},
{"f_2313srfi-13.scm",(void*)f_2313},
{"f_2291srfi-13.scm",(void*)f_2291},
{"f_2244srfi-13.scm",(void*)f_2244},
{"f_2256srfi-13.scm",(void*)f_2256},
{"f_2262srfi-13.scm",(void*)f_2262},
{"f_2272srfi-13.scm",(void*)f_2272},
{"f_2250srfi-13.scm",(void*)f_2250},
{"f_2058srfi-13.scm",(void*)f_2058},
{"f_2081srfi-13.scm",(void*)f_2081},
{"f_2083srfi-13.scm",(void*)f_2083},
{"f_2089srfi-13.scm",(void*)f_2089},
{"f_2213srfi-13.scm",(void*)f_2213},
{"f_2099srfi-13.scm",(void*)f_2099},
{"f_2102srfi-13.scm",(void*)f_2102},
{"f_2123srfi-13.scm",(void*)f_2123},
{"f_2126srfi-13.scm",(void*)f_2126},
{"f_2146srfi-13.scm",(void*)f_2146},
{"f_2161srfi-13.scm",(void*)f_2161},
{"f_2176srfi-13.scm",(void*)f_2176},
{"f_2226srfi-13.scm",(void*)f_2226},
{"f_1879srfi-13.scm",(void*)f_1879},
{"f_1902srfi-13.scm",(void*)f_1902},
{"f_1904srfi-13.scm",(void*)f_1904},
{"f_1910srfi-13.scm",(void*)f_1910},
{"f_2027srfi-13.scm",(void*)f_2027},
{"f_1920srfi-13.scm",(void*)f_1920},
{"f_1923srfi-13.scm",(void*)f_1923},
{"f_1945srfi-13.scm",(void*)f_1945},
{"f_1948srfi-13.scm",(void*)f_1948},
{"f_1965srfi-13.scm",(void*)f_1965},
{"f_1977srfi-13.scm",(void*)f_1977},
{"f_1994srfi-13.scm",(void*)f_1994},
{"f_2040srfi-13.scm",(void*)f_2040},
{"f_1833srfi-13.scm",(void*)f_1833},
{"f_1845srfi-13.scm",(void*)f_1845},
{"f_1855srfi-13.scm",(void*)f_1855},
{"f_1869srfi-13.scm",(void*)f_1869},
{"f_1839srfi-13.scm",(void*)f_1839},
{"f_1791srfi-13.scm",(void*)f_1791},
{"f_1803srfi-13.scm",(void*)f_1803},
{"f_1809srfi-13.scm",(void*)f_1809},
{"f_1823srfi-13.scm",(void*)f_1823},
{"f_1797srfi-13.scm",(void*)f_1797},
{"f_1758srfi-13.scm",(void*)f_1758},
{"f_1764srfi-13.scm",(void*)f_1764},
{"f_1785srfi-13.scm",(void*)f_1785},
{"f_1740srfi-13.scm",(void*)f_1740},
{"f_1752srfi-13.scm",(void*)f_1752},
{"f_1746srfi-13.scm",(void*)f_1746},
{"f_1697srfi-13.scm",(void*)f_1697},
{"f_1704srfi-13.scm",(void*)f_1704},
{"f_1709srfi-13.scm",(void*)f_1709},
{"f_1734srfi-13.scm",(void*)f_1734},
{"f_1707srfi-13.scm",(void*)f_1707},
{"f_1679srfi-13.scm",(void*)f_1679},
{"f_1691srfi-13.scm",(void*)f_1691},
{"f_1685srfi-13.scm",(void*)f_1685},
{"f_1661srfi-13.scm",(void*)f_1661},
{"f_1673srfi-13.scm",(void*)f_1673},
{"f_1667srfi-13.scm",(void*)f_1667},
{"f_1639srfi-13.scm",(void*)f_1639},
{"f_1646srfi-13.scm",(void*)f_1646},
{"f_1609srfi-13.scm",(void*)f_1609},
{"f_1622srfi-13.scm",(void*)f_1622},
{"f_1593srfi-13.scm",(void*)f_1593},
{"f_1607srfi-13.scm",(void*)f_1607},
{"f_1553srfi-13.scm",(void*)f_1553},
{"f_1526srfi-13.scm",(void*)f_1526},
{"f_1538srfi-13.scm",(void*)f_1538},
{"f_1532srfi-13.scm",(void*)f_1532},
{"f_1433srfi-13.scm",(void*)f_1433},
{"f_1499srfi-13.scm",(void*)f_1499},
{"f_1463srfi-13.scm",(void*)f_1463},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
