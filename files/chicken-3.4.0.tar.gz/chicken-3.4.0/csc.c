/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:57
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: csc.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -output-file csc.c
   used units: library eval data_structures ports extras srfi_69 data_structures ports srfi_1 srfi_13 utils files extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif

#ifndef C_TARGET_CFLAGS
# define C_TARGET_CFLAGS  C_INSTALL_CFLAGS
#endif

#ifndef C_TARGET_LDFLAGS
# define C_TARGET_LDFLAGS  C_INSTALL_LDFLAGS
#endif

#ifndef C_TARGET_BIN_HOME
# define C_TARGET_BIN_HOME  C_INSTALL_BIN_HOME
#endif

#ifndef C_TARGET_LIB_HOME
# define C_TARGET_LIB_HOME  C_INSTALL_LIB_HOME
#endif

#ifndef C_TARGET_STATIC_LIB_HOME
# define C_TARGET_STATIC_LIB_HOME  C_INSTALL_STATIC_LIB_HOME
#endif

#ifndef C_TARGET_INCLUDE_HOME
# define C_TARGET_INCLUDE_HOME  C_INSTALL_INCLUDE_HOME
#endif

#ifndef C_TARGET_SHARE_HOME
# define C_TARGET_SHARE_HOME  C_INSTALL_SHARE_HOME
#endif

#ifndef C_TARGET_RUN_LIB_HOME
# define C_TARGET_RUN_LIB_HOME    C_TARGET_LIB_HOME
#endif

#ifndef C_CHICKEN_PROGRAM
# define C_CHICKEN_PROGRAM     "chicken"
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[369];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_ccall f_391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_394)
static void C_ccall f_394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_403)
static void C_ccall f_403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_409)
static void C_ccall f_409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_ccall f_418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_fcall f_443(C_word t0,C_word t1) C_noret;
C_noret_decl(f_460)
static void C_ccall f_460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_464)
static void C_ccall f_464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_501)
static void C_ccall f_501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_505)
static void C_ccall f_505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_509)
static void C_ccall f_509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_517)
static void C_ccall f_517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_521)
static void C_ccall f_521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_552)
static void C_ccall f_552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_564)
static void C_ccall f_564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_595)
static void C_ccall f_595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_607)
static void C_fcall f_607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_615)
static void C_fcall f_615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_ccall f_624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_fcall f_632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_fcall f_645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_fcall f_743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_fcall f_1410(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_fcall f_1651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_fcall f_1654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_fcall f_1657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_fcall f_1708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_fcall f_1717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_fcall f_1943(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_fcall f_1795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_fcall f_1301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_fcall f_1146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_761)
static void C_ccall f_761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_fcall f_846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_856)
static void C_ccall f_856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_fcall f_849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_fcall f_2362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_fcall f_2322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2230)
static void C_fcall f_2230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_fcall f_2163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_808)
static void C_ccall f_808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_802)
static void C_ccall f_802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_fcall f_2500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_714)
static void C_fcall f_714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_fcall f_675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_668)
static void C_fcall f_668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_ccall f_673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_fcall f_2944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_fcall f_2860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2890)
static void C_fcall f_2890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_fcall f_2758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_fcall f_2706(C_word t0) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_fcall f_2609(C_word t0) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_fcall f_2619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_fcall f_2665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_fcall f_2669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_fcall f_2457(C_word t0) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_487)
static void C_fcall f_487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_fcall f_474(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_445)
static void C_fcall f_445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_456)
static void C_ccall f_456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_449)
static void C_ccall f_449(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_443)
static void C_fcall trf_443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_443(t0,t1);}

C_noret_decl(trf_607)
static void C_fcall trf_607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_607(t0,t1);}

C_noret_decl(trf_615)
static void C_fcall trf_615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_615(t0,t1);}

C_noret_decl(trf_632)
static void C_fcall trf_632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_632(t0,t1);}

C_noret_decl(trf_645)
static void C_fcall trf_645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_645(t0,t1);}

C_noret_decl(trf_743)
static void C_fcall trf_743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_743(t0,t1,t2);}

C_noret_decl(trf_1410)
static void C_fcall trf_1410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1410(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1410(t0,t1);}

C_noret_decl(trf_1651)
static void C_fcall trf_1651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1651(t0,t1);}

C_noret_decl(trf_1654)
static void C_fcall trf_1654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1654(t0,t1);}

C_noret_decl(trf_1657)
static void C_fcall trf_1657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1657(t0,t1);}

C_noret_decl(trf_1708)
static void C_fcall trf_1708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1708(t0,t1);}

C_noret_decl(trf_1717)
static void C_fcall trf_1717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1717(t0,t1);}

C_noret_decl(trf_1943)
static void C_fcall trf_1943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1943(t0,t1);}

C_noret_decl(trf_1795)
static void C_fcall trf_1795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1795(t0,t1);}

C_noret_decl(trf_1301)
static void C_fcall trf_1301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1301(t0,t1);}

C_noret_decl(trf_1146)
static void C_fcall trf_1146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1146(t0,t1);}

C_noret_decl(trf_846)
static void C_fcall trf_846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_846(t0,t1);}

C_noret_decl(trf_849)
static void C_fcall trf_849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_849(t0,t1);}

C_noret_decl(trf_2362)
static void C_fcall trf_2362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2362(t0,t1);}

C_noret_decl(trf_2307)
static void C_fcall trf_2307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2307(t0,t1);}

C_noret_decl(trf_2322)
static void C_fcall trf_2322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2322(t0,t1);}

C_noret_decl(trf_2230)
static void C_fcall trf_2230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2230(t0,t1);}

C_noret_decl(trf_2163)
static void C_fcall trf_2163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2163(t0,t1);}

C_noret_decl(trf_2500)
static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2500(t0,t1);}

C_noret_decl(trf_714)
static void C_fcall trf_714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_714(t0,t1);}

C_noret_decl(trf_675)
static void C_fcall trf_675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_675(t0,t1,t2,t3);}

C_noret_decl(trf_668)
static void C_fcall trf_668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_668(t0,t1);}

C_noret_decl(trf_2944)
static void C_fcall trf_2944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2944(t0,t1);}

C_noret_decl(trf_2860)
static void C_fcall trf_2860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2860(t0,t1,t2);}

C_noret_decl(trf_2890)
static void C_fcall trf_2890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2890(t0,t1);}

C_noret_decl(trf_2758)
static void C_fcall trf_2758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2758(t0,t1);}

C_noret_decl(trf_2706)
static void C_fcall trf_2706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2706(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2706(t0);}

C_noret_decl(trf_2609)
static void C_fcall trf_2609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2609(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2609(t0);}

C_noret_decl(trf_2619)
static void C_fcall trf_2619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2619(t0,t1);}

C_noret_decl(trf_2624)
static void C_fcall trf_2624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2624(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2624(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2665)
static void C_fcall trf_2665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2665(t0,t1);}

C_noret_decl(trf_2669)
static void C_fcall trf_2669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2669(t0,t1);}

C_noret_decl(trf_2457)
static void C_fcall trf_2457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2457(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2457(t0);}

C_noret_decl(trf_487)
static void C_fcall trf_487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_487(t0,t1);}

C_noret_decl(trf_474)
static void C_fcall trf_474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_474(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_474(t0,t1,t2,t3);}

C_noret_decl(trf_445)
static void C_fcall trf_445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_445(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2488)){
C_save(t1);
C_rereclaim2(2488*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,369);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[10]=C_h_intern(&lf[10],4,"exit");
lf[11]=C_h_intern(&lf[11],7,"fprintf");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[13]=C_h_intern(&lf[13],18,"current-error-port");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[22]=C_h_intern(&lf[22],13,"string-append");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[25]=C_h_intern(&lf[25],10,"string-any");
lf[26]=C_h_intern(&lf[26],16,"char-whitespace\077");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[49]=C_h_intern(&lf[49],26,"\003sysload-dynamic-extension");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[107]=C_h_intern(&lf[107],18,"string-intersperse");
lf[108]=C_h_intern(&lf[108],7,"\003sysmap");
lf[110]=C_h_intern(&lf[110],6,"append");
lf[112]=C_h_intern(&lf[112],7,"reverse");
lf[113]=C_h_intern(&lf[113],6,"static");
lf[114]=C_h_intern(&lf[114],14,"static-options");
lf[115]=C_h_intern(&lf[115],21,"extension-information");
lf[116]=C_h_intern(&lf[116],15,"repository-path");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[121]=C_h_intern(&lf[121],9,"\003syserror");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[126]=C_h_intern(&lf[126],17,"string-translate*");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[128]=C_h_intern(&lf[128],16,"\003syslist->string");
lf[129]=C_h_intern(&lf[129],5,"cons*");
lf[130]=C_h_intern(&lf[130],16,"\003sysstring->list");
lf[131]=C_h_intern(&lf[131],3,"any");
lf[134]=C_h_intern(&lf[134],6,"printf");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\0006*** Shell command terminated with exit status ~S: ~A~%");
lf[136]=C_h_intern(&lf[136],6,"system");
lf[137]=C_h_intern(&lf[137],5,"print");
lf[139]=C_h_intern(&lf[139],11,"delete-file");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[141]=C_h_intern(&lf[141],25,"\003sysimplicit-exit-handler");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[156]=C_h_intern(&lf[156],17,"\003syspeek-c-string");
lf[157]=C_h_intern(&lf[157],7,"sprintf");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\014mv ~A ~A.old");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[161]=C_h_intern(&lf[161],26,"pathname-replace-extension");
lf[162]=C_h_intern(&lf[162],4,"last");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[164]=C_h_intern(&lf[164],5,"error");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000!invalid entry in csc control file");
lf[166]=C_h_intern(&lf[166],12,"post-process");
lf[167]=C_h_intern(&lf[167],9,"c-options");
lf[168]=C_h_intern(&lf[168],12,"link-options");
lf[169]=C_h_intern(&lf[169],9,"read-file");
lf[170]=C_h_intern(&lf[170],9,"read-line");
lf[171]=C_h_intern(&lf[171],20,"with-input-from-file");
lf[172]=C_h_intern(&lf[172],12,"file-exists\077");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[174]=C_h_intern(&lf[174],4,"conc");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\006-uses ");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\005#%eof");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[184]=C_h_intern(&lf[184],7,"newline");
lf[185]=C_h_intern(&lf[185],6,"print*");
lf[186]=C_h_intern(&lf[186],5,"-help");
lf[187]=C_h_intern(&lf[187],6,"--help");
lf[188]=C_h_intern(&lf[188],7,"display");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\036\343Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Any Scheme, C or object\012  files and all libraries given on the comm"
"and line are translated, compiled or\012  linked as needed.\012\012  General options:\012\012  "
"  -h  -help                   display this text and exit\012    -v                 "
"         show intermediate compilation stages\012    -v2  -verbose               di"
"splay information about translation progress\012    -v3                         dis"
"play information about all compilation stages\012    -V  -version                di"
"splay Scheme compiler version and exit\012    -release                    display r"
"elease number and exit\012\012  File and pathname options:\012\012    -o -output-file FILENA"
"ME    specifies target executable name\012    -I -include-path PATHNAME   specifies"
" alternative path for included files\012    -to-stdout                  write compi"
"ler to stdout (implies -t)\012    -s -shared -dynamic         generate dynamically "
"loadable shared object file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYM"
"BOL \012                                register feature identifier\012    -c++       "
"                 Compile via a C++ source file (.cpp) \012    -objc                "
"       Compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    "
"-i -case-insensitive        don\047t preserve case of read symbols    \012    -K -keyw"
"ord-style STYLE     allow alternative keyword syntax (prefix, suffix or none)\012  "
"  -run-time-macros            macros are made available at run-time\012\012  Translati"
"on options:\012\012    -x  -explicit-use           do not use units `library\047 and `eva"
"l\047 by default\012    -P  -check-syntax           stop compilation after macro-expan"
"sion\012    -A  -analyze-only           stop compilation after first analysis pass\012"
"\012  Debugging options:\012\012    -w  -no-warnings            disable warnings\012    -dis"
"able-warning CLASS      disable specific class of warnings\012    -d0 -d1 -d2 -debu"
"g-level NUMBER\012                                set level of available debugging "
"information\012    -no-trace                   disable rudimentary debugging inform"
"ation\012    -profile                    executable emits profiling information \012  "
"  -accumulate-profile         executable emits profiling information in append m"
"ode\012    -profile-name FILENAME      name of the generated profile information fi"
"le\012    -emit-debug-info            emit additional debug-information\012    -emit-e"
"xports FILENAME      write exported toplevel variables to FILENAME\012    -G  -chec"
"k-imports          look for undefined toplevel variables\012    -import FILENAME   "
"         read externally exported symbols from FILENAME\012\012  Optimization options:"
"\012\012    -O -O1 -O2 -O3 -optimize-level NUMBER\012\011\011\011        enable certain sets of op"
"timization options\012    -optimize-leaf-routines     enable leaf routine optimizat"
"ion\012    -N  -no-usual-integrations  standard procedures may be redefined\012    -u "
" -unsafe                 disable safety checks\012    -b  -block                  e"
"nable block-compilation\012    -disable-interrupts         disable interrupts in co"
"mpiled code\012    -f  -fixnum-arithmetic      assume all numbers are fixnums\012    -"
"Ob  -benchmark-mode        equivalent to \047-block -optimize-level 3 \012            "
"                     -debug-level 0 -fixnum-arithmetic -lambda-lift \012           "
"                      -disable-interrupts\047\012    -lambda-lift                perfo"
"rm lambda-lifting\012    -unsafe-libraries           link with unsafe runtime syste"
"m\012    -disable-stack-overflow-checks  disables detection of stack-overflows\012    "
"-inline                     enable inlining\012    -inline-limit               set "
"inlining threshold\012    -disable-compiler-macros    disable expansion of compiler"
" macros\012\012  Configuration options:\012\012    -unit NAME                  compile file "
"as a library unit\012    -uses NAME                  declare library unit as used.\012"
"    -heap-size NUMBER           specifies heap-size of compiled executable\012    -"
"heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-growth "
"PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage PERCE"
"NTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-siz"
"e NUMBER\012\011\011                specifies nursery size of compiled executable\012    -X "
"-extend FILENAME         load file before compilation commences\012    -prelude EXP"
"RESSION         add expression to beginning of source file\012    -postlude EXPRESS"
"ION        add expression to end of source file\012    -prologue FILENAME          "
"include file before main source file\012    -epilogue FILENAME          include fil"
"e after main source file\012\012    -e  -embedded               compile as embedded (d"
"on\047t generate `main()\047)\012    -W  -windows                compile as Windows GUI a"
"pplication (MSVC only)\012    -R  -require-extension NAME require extension in comp"
"iled code\012    -E  -extension              compile as extension (dynamic or stati"
"c)\012    -dll -library               compile multiple units into a dynamic library"
"\012\012  Options to other passes:\012\012    -C OPTION                   pass option to C c"
"ompiler\012    -L OPTION                   pass option to linker\012    -I<DIR>       "
"              pass \042-I<DIR>\042 to C compiler (add include path)\012    -L<DIR>       "
"              pass \042-L<DIR>\042 to linker (add library path)\012    -k                "
"          keep intermediate files\012    -c                          stop after com"
"pilation to object files\012    -t                          stop after translation "
"to C\012    -cc COMPILER                select other C compiler than the default on"
"e\012    -cxx COMPILER               select other C++ compiler than the default one"
"\012    -ld COMPILER                select other linker than the default one\012    -l"
"LIBNAME                   link with given library (`libLIBNAME\047 on UNIX,\012       "
"                          `LIBNAME.lib\047 on Windows)                             "
"   \012    -static-libs                link with static CHICKEN libraries\012    -stat"
"ic                     generate completely statically linked executable\012    -sta"
"tic-extensions          link with static extensions (if available)\012    -F<DIR>  "
"                   pass \042-F<DIR>\042 to C compiler (add framework \012                "
"                 header path on Mac OS X)\012    -framework NAME             passed"
" to linker on Mac OS X\012    -rpath PATHNAME             add directory to runtime "
"library search path\012    -Wl,...                     pass linker options\012    -str"
"ip                      strip resulting binary\012\012  Inquiry options:\012\012    -home   "
"                    show home-directory (where support files go)\012    -cflags    "
"                 show required C-compiler flags and exit\012    -ldflags           "
"         show required linker flags and exit\012    -libs                       sho"
"w required libraries and exit\012    -cc-name                    show name of defau"
"lt C compiler used\012    -cxx-name                   show name of default C++ comp"
"iler used\012    -ld-name                    show name of default linker used\012    -"
"dry-run                    just show commands executed, don\047t run them \012        "
"                         (implies `-v\047)\012\012  Obscure options:\012\012    -debug MODES   "
"             display debugging output for the given modes\012    -compiler PATHNAME"
"          use other compiler than default `chicken\047\012    -disable-c-syntax-checks"
"    disable syntax checks of C code fragments\012    -raw                        do"
" not generate implicit init- and exit code\011\011\011       \012    -emit-external-prototyp"
"es-first  emit protoypes for callbacks before foreign\012                          "
"       declarations\012    -keep-shadowed-macros       do not remove shadowed macro"
"\012    -host                       compile for host when configured for cross-comp"
"iling\012\012  Options can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same a"
"s\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The contents of the environment var"
"iable CSC_OPTIONS are implicitly\012  passed to every invocation of `csc\047.\012");
lf[190]=C_h_intern(&lf[190],8,"-release");
lf[191]=C_h_intern(&lf[191],15,"chicken-version");
lf[192]=C_h_intern(&lf[192],8,"-version");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[194]=C_h_intern(&lf[194],4,"-c++");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[196]=C_h_intern(&lf[196],5,"-objc");
lf[197]=C_h_intern(&lf[197],7,"-static");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[200]=C_h_intern(&lf[200],12,"-static-libs");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[203]=C_h_intern(&lf[203],18,"-static-extensions");
lf[204]=C_h_intern(&lf[204],7,"-cflags");
lf[205]=C_h_intern(&lf[205],8,"-ldflags");
lf[206]=C_h_intern(&lf[206],8,"-cc-name");
lf[207]=C_h_intern(&lf[207],9,"-cxx-name");
lf[208]=C_h_intern(&lf[208],8,"-ld-name");
lf[209]=C_h_intern(&lf[209],5,"-home");
lf[210]=C_h_intern(&lf[210],5,"-libs");
lf[211]=C_h_intern(&lf[211],2,"-v");
lf[212]=C_h_intern(&lf[212],3,"-v2");
lf[213]=C_h_intern(&lf[213],8,"-verbose");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[215]=C_h_intern(&lf[215],2,"-w");
lf[216]=C_h_intern(&lf[216],12,"-no-warnings");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[219]=C_h_intern(&lf[219],3,"-v3");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[225]=C_h_intern(&lf[225],2,"-A");
lf[226]=C_h_intern(&lf[226],13,"-analyze-only");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[228]=C_h_intern(&lf[228],2,"-P");
lf[229]=C_h_intern(&lf[229],13,"-check-syntax");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[231]=C_h_intern(&lf[231],2,"-k");
lf[232]=C_h_intern(&lf[232],2,"-c");
lf[233]=C_h_intern(&lf[233],2,"-t");
lf[234]=C_h_intern(&lf[234],2,"-e");
lf[235]=C_h_intern(&lf[235],9,"-embedded");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[237]=C_h_intern(&lf[237],18,"-require-extension");
lf[238]=C_h_intern(&lf[238],2,"-R");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[240]=C_h_intern(&lf[240],8,"-windows");
lf[241]=C_h_intern(&lf[241],2,"-W");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[251]=C_h_intern(&lf[251],10,"-framework");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[253]=C_h_intern(&lf[253],2,"-o");
lf[254]=C_h_intern(&lf[254],2,"-O");
lf[255]=C_h_intern(&lf[255],3,"-O1");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[258]=C_h_intern(&lf[258],3,"-O2");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[261]=C_h_intern(&lf[261],3,"-O3");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[264]=C_h_intern(&lf[264],3,"-d0");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[267]=C_h_intern(&lf[267],3,"-d1");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[270]=C_h_intern(&lf[270],3,"-d2");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[273]=C_h_intern(&lf[273],8,"-dry-run");
lf[274]=C_h_intern(&lf[274],2,"-s");
lf[275]=C_h_intern(&lf[275],4,"-dll");
lf[276]=C_h_intern(&lf[276],8,"-library");
lf[277]=C_h_intern(&lf[277],9,"-compiler");
lf[278]=C_h_intern(&lf[278],3,"-cc");
lf[279]=C_h_intern(&lf[279],4,"-cxx");
lf[280]=C_h_intern(&lf[280],3,"-ld");
lf[281]=C_h_intern(&lf[281],2,"-I");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[283]=C_h_intern(&lf[283],2,"-C");
lf[284]=C_h_intern(&lf[284],12,"string-split");
lf[285]=C_h_intern(&lf[285],6,"-strip");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[287]=C_h_intern(&lf[287],2,"-L");
lf[288]=C_h_intern(&lf[288],17,"-unsafe-libraries");
lf[289]=C_h_intern(&lf[289],6,"-rpath");
lf[290]=C_h_intern(&lf[290],3,"gnu");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[292]=C_h_intern(&lf[292],14,"build-platform");
lf[293]=C_h_intern(&lf[293],5,"-host");
lf[294]=C_h_intern(&lf[294],1,"-");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-E\376\003\000\000\002\376B\000\000\012-extension\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-featu"
"re\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-"
"keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026"
"-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-G\376\003\000\000\002\376B\000\000\016-check-imports\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[298]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\020-run-time-macros\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dyna"
"mic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\020-emit-debug-info\376\003\000\000\002\376\001\000\000\016-"
"check-imports\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000"
"\012-extension\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\022-static-extensions\376\003\000\000\002\376\001\000\000\015-analyze-only"
"\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\030-disable-compiler-macros\376\377\016");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\007-import\376\003\000\000\002\376\001\000\000\031-require-static-extension\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000"
"\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap"
"-initial-size\376\003\000\000\002\376\001\000\000\015-emit-exports\376\003\000\000\002\376\001\000\000\022-compress-literals\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[301]=C_h_intern(&lf[301],9,"substring");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[304]=C_h_intern(&lf[304],15,"lset-difference");
lf[305]=C_h_intern(&lf[305],6,"char=\077");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000G\376\377\016");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[309]=C_h_intern(&lf[309],18,"decompose-pathname");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[324]=C_h_intern(&lf[324],15,"-optimize-level");
lf[325]=C_h_intern(&lf[325],15,"-benchmark-mode");
lf[326]=C_h_intern(&lf[326],10,"-to-stdout");
lf[327]=C_h_intern(&lf[327],7,"-unsafe");
lf[328]=C_h_intern(&lf[328],7,"-shared");
lf[329]=C_h_intern(&lf[329],8,"-dynamic");
lf[330]=C_h_intern(&lf[330],14,"string->symbol");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[332]=C_h_intern(&lf[332],6,"getenv");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\011-LIBPATH:");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[363]=C_h_intern(&lf[363],22,"command-line-arguments");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[365]=C_h_intern(&lf[365],4,"hpux");
lf[366]=C_h_intern(&lf[366],4,"hppa");
lf[367]=C_h_intern(&lf[367],12,"machine-type");
lf[368]=C_h_intern(&lf[368],16,"software-version");
C_register_lf2(lf,369,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k389 */
static void C_ccall f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k392 in k389 */
static void C_ccall f_394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k395 in k392 in k389 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k398 in k395 in k392 in k389 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_427,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 106  build-platform */
t3=C_retrieve(lf[292]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 107  build-platform */
t5=C_retrieve(lf[292]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3330,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 108  software-version */
t5=C_retrieve(lf[368]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 109  software-version */
t6=C_retrieve(lf[368]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3320 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[365]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 110  machine-type */
t4=C_retrieve(lf[367]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_443(t3,C_SCHEME_FALSE);}}

/* k3316 in k3320 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_443(t2,(C_word)C_eqp(t1,lf[366]));}

/* k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_443,NULL,2,t0,t1);}
t2=C_mutate(&lf[8],t1);
t3=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_445,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 116  getenv */
t5=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[364]);}

/* k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=C_mutate(&lf[14],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_464,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 117  command-line-arguments */
t4=C_retrieve(lf[363]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_464,2,t0,t1);}
t2=C_mutate(&lf[15],t1);
t3=(C_word)C_i_member(lf[16],C_retrieve2(lf[15],"arguments"));
t4=C_mutate(&lf[17],t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[18],t5);
t7=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_474,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_487,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3300 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 133  prefix */
f_474(((C_word*)t0)[2],lf[361],lf[362],t1);}

/* k3296 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 132  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_501,2,t0,t1);}
t2=C_mutate(&lf[27],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3276,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3280,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3282 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3288,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3286 in k3282 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 138  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3278 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 137  prefix */
f_474(((C_word*)t0)[2],lf[359],lf[360],t1);}

/* k3274 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 136  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_505,2,t0,t1);}
t2=C_mutate(&lf[28],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3266,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3264 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 142  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_509,2,t0,t1);}
t2=C_mutate(&lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3254 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 143  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_513,2,t0,t1);}
t2=C_mutate(&lf[30],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3243(2,t5,lf[358]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* k3241 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 144  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_517,2,t0,t1);}
t2=C_mutate(&lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3230(2,t5,lf[357]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* k3228 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 145  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_521,2,t0,t1);}
t2=C_mutate(&lf[32],t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[33]:lf[34]);
t4=C_mutate(&lf[35],t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[36]:lf[37]);
t6=C_mutate(&lf[38],t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[39]:lf[40]);
t8=C_mutate(&lf[41],t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[42]:lf[43]);
t10=C_mutate(&lf[44],t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[45]:lf[46]);
t12=C_mutate(&lf[47],t11);
t13=C_mutate(&lf[48],C_retrieve(lf[49]));
t14=(C_truep(lf[3])?lf[3]:C_retrieve2(lf[5],"msvc"));
t15=(C_truep(t14)?lf[50]:lf[51]);
t16=C_mutate(&lf[52],t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_552,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[355]:lf[356]);
/* csc.scm: 156  string-append */
t19=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t18,C_retrieve2(lf[38],"library-extension"));}

/* k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_552,2,t0,t1);}
t2=C_mutate(&lf[53],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[353]:lf[354]);
/* csc.scm: 159  string-append */
t5=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[38],"library-extension"));}

/* k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
t2=C_mutate(&lf[54],t1);
t3=(C_truep(lf[3])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3214,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3209,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[55],t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_564,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3197 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 168  string-split */
t2=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_564,2,t0,t1);}
t2=C_mutate(&lf[56],t1);
t3=C_mutate(&lf[57],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3189,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3187 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 170  string-split */
t2=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_569,2,t0,t1);}
t2=C_mutate(&lf[58],t1);
t3=C_mutate(&lf[59],C_retrieve2(lf[58],"default-linking-optimization-options"));
t4=lf[60]=C_SCHEME_END_OF_LIST;;
t5=lf[61]=C_SCHEME_END_OF_LIST;;
t6=lf[62]=C_SCHEME_END_OF_LIST;;
t7=lf[63]=C_SCHEME_END_OF_LIST;;
t8=lf[64]=C_SCHEME_END_OF_LIST;;
t9=lf[65]=C_SCHEME_FALSE;;
t10=lf[66]=C_SCHEME_FALSE;;
t11=lf[67]=C_SCHEME_FALSE;;
t12=lf[68]=C_SCHEME_FALSE;;
t13=lf[69]=C_SCHEME_FALSE;;
t14=lf[70]=C_SCHEME_FALSE;;
t15=lf[71]=C_SCHEME_FALSE;;
t16=lf[72]=C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_595,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_595,2,t0,t1);}
t2=C_mutate(&lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_599,2,t0,t1);}
t2=C_mutate(&lf[74],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3155,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3159,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3161 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 241  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[352],C_retrieve2(lf[53],"default-library"));}

/* k3165 in k3161 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 239  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3157 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 238  prefix */
f_474(((C_word*)t0)[2],C_retrieve2(lf[53],"default-library"),lf[351],t1);}

/* k3153 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 237  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[75],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3147,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 243  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[349],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_607(t5,lf[350]);}}

/* k3145 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3147,2,t0,t1);}
t2=((C_word*)t0)[2];
f_607(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_607,NULL,2,t0,t1);}
t2=C_mutate(&lf[76],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3126,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3130,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3128 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3134,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 251  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[348],C_retrieve2(lf[54],"default-unsafe-library"));}

/* k3132 in k3128 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 249  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3124 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 248  prefix */
f_474(((C_word*)t0)[2],C_retrieve2(lf[54],"default-unsafe-library"),lf[347],t1);}

/* k3120 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 247  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[77],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_615,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3114,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 253  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[345],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_615(t5,lf[346]);}}

/* k3112 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3114,2,t0,t1);}
t2=((C_word*)t0)[2];
f_615(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_615,NULL,2,t0,t1);}
t2=C_mutate(&lf[78],t1);
t3=C_mutate(&lf[79],C_retrieve2(lf[75],"default-library-files"));
t4=C_mutate(&lf[80],C_retrieve2(lf[76],"default-shared-library-files"));
t5=C_mutate(&lf[81],C_retrieve2(lf[75],"default-library-files"));
t6=C_mutate(&lf[82],C_retrieve2(lf[76],"default-shared-library-files"));
t7=C_mutate(&lf[83],lf[84]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3099 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 263  prefix */
f_474(((C_word*)t0)[2],lf[343],lf[344],t1);}

/* k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_624,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[85]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[86],t3);
t5=lf[87]=C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[86],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3086,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3090,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 270  quotewrap */
f_487(t8,C_retrieve2(lf[86],"include-dir"));}
else{
t7=t6;
f_632(t7,C_SCHEME_END_OF_LIST);}}

/* k3088 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 270  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[342],t1);}

/* k3084 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3086,2,t0,t1);}
t2=((C_word*)t0)[2];
f_632(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_632(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_632,NULL,2,t0,t1);}
t2=C_mutate(&lf[88],t1);
t3=C_mutate(&lf[89],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=C_mutate(&lf[90],C_retrieve2(lf[58],"default-linking-optimization-options"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3073,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3071 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 278  prefix */
f_474(((C_word*)t0)[2],lf[340],lf[341],t1);}

/* k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_640,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=lf[92]=C_SCHEME_END_OF_LIST;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_645,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[7],"osx"):(C_truep(C_retrieve2(lf[8],"hpux-hppa"))?C_retrieve2(lf[8],"hpux-hppa"):lf[3]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 286  quotewrap */
f_487(t7,C_retrieve2(lf[91],"library-dir"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3029,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 288  quotewrap */
f_487(t7,C_retrieve2(lf[91],"library-dir"));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3066,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 291  quotewrap */
f_487(t7,C_retrieve2(lf[91],"library-dir"));}}}

/* k3064 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[339],t1);}

/* k3038 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3048,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k3054 in k3038 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 292  prefix */
f_474(((C_word*)t0)[2],lf[337],lf[338],t1);}

/* k3050 in k3038 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 292  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k3046 in k3038 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 292  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[336],t1);}

/* k3042 in k3038 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=((C_word*)t0)[3];
f_645(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3031 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 288  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[335],t1);}

/* k3027 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
t2=((C_word*)t0)[2];
f_645(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3017 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 286  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[334],t1);}

/* k3013 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=((C_word*)t0)[2];
f_645(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_645,NULL,2,t0,t1);}
t2=C_mutate(&lf[93],t1);
t3=lf[94]=C_SCHEME_FALSE;;
t4=lf[95]=C_SCHEME_FALSE;;
t5=lf[96]=C_SCHEME_FALSE;;
t6=lf[97]=C_SCHEME_FALSE;;
t7=lf[98]=C_SCHEME_FALSE;;
t8=lf[99]=C_SCHEME_FALSE;;
t9=lf[100]=C_SCHEME_FALSE;;
t10=lf[101]=C_SCHEME_FALSE;;
t11=lf[102]=C_SCHEME_FALSE;;
t12=lf[103]=C_SCHEME_FALSE;;
t13=lf[104]=C_SCHEME_END_OF_LIST;;
t14=lf[105]=C_SCHEME_FALSE;;
t15=C_mutate(&lf[106],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2457,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[111],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2609,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[117],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2706,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[120],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2758,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[122],lf[123]);
t20=C_mutate(&lf[109],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2907,tmp=(C_word)a,a+=2,tmp));
t21=lf[132]=C_SCHEME_FALSE;;
t22=C_mutate(&lf[133],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2936,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[138],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2968,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3002,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 953  getenv */
t28=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,lf[333]);}

/* k3000 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[331]);
/* csc.scm: 953  string-split */
t3=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2996 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 953  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[15],"arguments"));}

/* k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_668,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_675,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_714,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_743,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_743(t8,((C_word*)t0)[2],t1);}

/* loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_743,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_754,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 498  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[87],"compile-options"),C_retrieve2(lf[88],"builtin-compile-options"));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_925,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* csc.scm: 540  string->symbol */
t8=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word ab[117],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_928,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[186]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[187]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_940,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 314  display */
t6=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[189]);}
else{
t5=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_952,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 546  chicken-version */
t8=C_retrieve(lf[191]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t6=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 549  sprintf */
t9=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[28],"translator"),lf[193]);}
else{
t7=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t7)){
t8=lf[65]=C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[195],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87],t9);
t11=t2;
f_928(2,t11,t10);}
else{
t9=t2;
f_928(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t8)){
t9=lf[66]=C_SCHEME_TRUE;;
t10=t2;
f_928(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 557  cons* */
t11=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,lf[198],lf[199],C_retrieve2(lf[83],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1017,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 560  cons* */
t12=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[201],lf[202],C_retrieve2(lf[83],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t11)){
t12=lf[103]=C_SCHEME_TRUE;;
t13=t2;
f_928(2,t13,t12);}
else{
t12=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t12)){
t13=lf[68]=C_SCHEME_TRUE;;
t14=lf[69]=C_SCHEME_TRUE;;
t15=t2;
f_928(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t13)){
t14=lf[68]=C_SCHEME_TRUE;;
t15=lf[70]=C_SCHEME_TRUE;;
t16=t2;
f_928(2,t16,t15);}
else{
t14=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1050,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 570  print */
t16=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_retrieve2(lf[29],"compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 571  print */
t17=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,C_retrieve2(lf[30],"c++-compiler"));}
else{
t16=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1074,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 572  print */
t18=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,C_retrieve2(lf[31],"linker"));}
else{
t17=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1086,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 573  print */
t19=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,C_retrieve2(lf[27],"home"));}
else{
t18=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t18)){
t19=lf[68]=C_SCHEME_TRUE;;
t20=lf[71]=C_SCHEME_TRUE;;
t21=t2;
f_928(2,t21,t20);}
else{
t19=(C_word)C_eqp(t1,lf[211]);
if(C_truep(t19)){
t20=lf[95]=C_SCHEME_TRUE;;
t21=t2;
f_928(2,t21,t20);}
else{
t20=(C_word)C_eqp(t1,lf[212]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t1,lf[213]));
if(C_truep(t21)){
t22=lf[95]=C_SCHEME_TRUE;;
/* csc.scm: 581  t-options */
f_668(t2,(C_word)C_a_i_list(&a,1,lf[214]));}
else{
t22=(C_word)C_eqp(t1,lf[215]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[216]));
if(C_truep(t23)){
t24=(C_word)C_a_i_cons(&a,2,lf[217],C_retrieve2(lf[87],"compile-options"));
t25=C_mutate(&lf[87],t24);
/* csc.scm: 584  t-options */
f_668(t2,(C_word)C_a_i_list(&a,1,lf[218]));}
else{
t24=(C_word)C_eqp(t1,lf[219]);
if(C_truep(t24)){
t25=lf[95]=C_SCHEME_TRUE;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1143,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 587  t-options */
f_668(t26,(C_word)C_a_i_list(&a,1,lf[224]));}
else{
t25=(C_word)C_eqp(t1,lf[225]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[226]));
if(C_truep(t26)){
t27=lf[97]=C_SCHEME_TRUE;;
/* csc.scm: 593  t-options */
f_668(t2,(C_word)C_a_i_list(&a,1,lf[227]));}
else{
t27=(C_word)C_eqp(t1,lf[228]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(t1,lf[229]));
if(C_truep(t28)){
t29=lf[97]=C_SCHEME_TRUE;;
/* csc.scm: 596  t-options */
f_668(t2,(C_word)C_a_i_list(&a,1,lf[230]));}
else{
t29=(C_word)C_eqp(t1,lf[231]);
if(C_truep(t29)){
t30=lf[96]=C_SCHEME_TRUE;;
t31=t2;
f_928(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[232]);
if(C_truep(t30)){
t31=lf[98]=C_SCHEME_TRUE;;
t32=t2;
f_928(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[233]);
if(C_truep(t31)){
t32=lf[97]=C_SCHEME_TRUE;;
t33=t2;
f_928(2,t33,t32);}
else{
t32=(C_word)C_eqp(t1,lf[234]);
t33=(C_truep(t32)?t32:(C_word)C_eqp(t1,lf[235]));
if(C_truep(t33)){
t34=lf[67]=C_SCHEME_TRUE;;
t35=(C_word)C_a_i_cons(&a,2,lf[236],C_retrieve2(lf[87],"compile-options"));
t36=C_mutate(&lf[87],t35);
t37=t2;
f_928(2,t37,t36);}
else{
t34=(C_word)C_eqp(t1,lf[237]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[238]));
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 604  check */
f_675(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[240]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[241]));
if(C_truep(t37)){
t38=lf[105]=C_SCHEME_TRUE;;
if(C_truep(lf[3])){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 613  cons* */
t40=C_retrieve(lf[129]);
((C_proc7)C_retrieve_proc(t40))(7,t40,t39,lf[243],lf[244],lf[245],lf[246],C_retrieve2(lf[92],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 618  cons* */
t40=C_retrieve(lf[129]);
((C_proc6)C_retrieve_proc(t40))(6,t40,t39,lf[248],lf[249],lf[250],C_retrieve2(lf[92],"link-options"));}
else{
t39=t2;
f_928(2,t39,C_SCHEME_UNDEFINED);}}}
else{
t38=(C_word)C_eqp(t1,lf[251]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1298,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 621  check */
f_675(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[253]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1322,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 626  check */
f_675(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[254]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[255]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1343,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 630  cons* */
t43=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t43))(5,t43,t42,lf[256],lf[257],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[258]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1353,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 631  cons* */
t44=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t44))(5,t44,t43,lf[259],lf[260],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[261]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1363,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 632  cons* */
t45=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t45))(5,t45,t44,lf[262],lf[263],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[264]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1373,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 633  cons* */
t46=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t45,lf[265],lf[266],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[267]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1383,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 634  cons* */
t47=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t46,lf[268],lf[269],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[270]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1393,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 635  cons* */
t48=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t48))(5,t48,t47,lf[271],lf[272],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[273]);
if(C_truep(t47)){
t48=lf[95]=C_SCHEME_TRUE;;
t49=lf[72]=C_SCHEME_TRUE;;
t50=t2;
f_928(2,t50,t49);}
else{
t48=(C_word)C_eqp(t1,lf[274]);
t49=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t48)){
t50=t49;
f_1410(t50,t48);}
else{
t50=(C_word)C_eqp(t1,lf[328]);
t51=t49;
f_1410(t51,(C_truep(t50)?t50:(C_word)C_eqp(t1,lf[329])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1410,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 640  shared-build */
f_714(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[275]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[276]));
if(C_truep(t3)){
/* csc.scm: 642  shared-build */
f_714(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[277]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 644  check */
f_675(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[278]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 648  check */
f_675(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[279]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 652  check */
f_675(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[280]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 656  check */
f_675(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[281]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 660  check */
f_675(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[283]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 663  check */
f_675(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[285]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[286]);
/* csc.scm: 667  append */
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[92],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[287]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 669  check */
f_675(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[288]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 673  t-options */
f_668(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[289]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 677  check */
f_675(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[293]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_928(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[294]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 683  make-pathname */
t17=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,C_SCHEME_FALSE,lf[296],C_retrieve2(lf[44],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[327]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[325]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[325]);
if(C_truep(t18)){
t19=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t20=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t21=t16;
f_1651(t21,t20);}
else{
t19=t16;
f_1651(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_1651(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1651,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[326]);
if(C_truep(t3)){
t4=lf[99]=C_SCHEME_TRUE;;
t5=lf[97]=C_SCHEME_TRUE;;
t6=t2;
f_1654(t6,t5);}
else{
t4=t2;
f_1654(t4,C_SCHEME_UNDEFINED);}}

/* k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1654,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[324]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[325]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[89],C_retrieve2(lf[57],"best-compilation-optimization-options"));
t5=C_mutate(&lf[90],C_retrieve2(lf[59],"best-linking-optimization-options"));
t6=t2;
f_1657(t6,t5);}
else{
t4=t2;
f_1657(t4,C_SCHEME_UNDEFINED);}}

/* k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1657,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[297]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_928(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[298]))){
/* csc.scm: 697  t-options */
f_668(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[299]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 699  check */
f_675(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 704  substring */
t6=*((C_word*)lf[301]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_1708(t5,C_SCHEME_FALSE);}}}}}

/* k2037 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1708(t2,(C_word)C_i_string_equal_p(lf[323],t1));}

/* k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1708,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 705  t-options */
f_668(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_1717(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_1717(t4,C_SCHEME_FALSE);}}}

/* k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1717,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1727,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 709  append */
t6=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve2(lf[92],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 711  append */
t8=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[92],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 713  append */
t10=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,C_retrieve2(lf[87],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 715  substring */
t11=*((C_word*)lf[301]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 718  append */
t14=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t12,C_retrieve2(lf[87],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_928(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 719  substring */
t15=*((C_word*)lf[301]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_1795(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 728  file-exists? */
t3=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 729  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 745  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[322]);}}

/* k2000 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 746  file-exists? */
t3=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2006 in k2000 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_928(2,t4,t3);}
else{
/* csc.scm: 748  quit */
f_445(((C_word*)t0)[3],lf[321],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[37],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1905,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[310]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[311]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 732  append */
t9=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve2(lf[61],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[312]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[314]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[315]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[316]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[317],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87],t9);
t11=t8;
f_1943(t11,t10);}
else{
t9=t8;
f_1943(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[318]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[319]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[320]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[66]=C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1967,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 739  append */
t12=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,C_retrieve2(lf[61],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[35],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[38],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 742  append */
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[63],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 743  append */
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[60],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 730  append */
t8=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[60],"scheme-files"),t7);}}

/* k1914 in a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1990 in a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1982 in a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1965 in a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1941 in a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1943(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1943,NULL,2,t0,t1);}
t2=lf[65]=C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 736  append */
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_retrieve2(lf[61],"c-files"),t4);}

/* k1946 in k1941 in a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1928 in a1904 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1898 in k1892 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
/* csc.scm: 729  decompose-pathname */
t2=C_retrieve(lf[309]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1862 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1795(t2,(C_word)C_i_string_equal_p(lf[308],t1));}

/* k1793 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1795,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 720  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[92],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->list */
t4=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 727  quit */
f_445(((C_word*)t0)[5],lf[307],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k1845 in k1793 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 723  lset-difference */
t4=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[305]+1),t2,lf[306]);}

/* k1841 in k1845 in k1793 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1828,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
/* csc.scm: 726  quit */
f_445(((C_word*)t0)[4],lf[303],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1827 in k1841 in k1845 in k1793 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1828,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* csc.scm: 725  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[302],t3);}

/* k1824 in k1841 in k1845 in k1793 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 725  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1820 in k1841 in k1845 in k1793 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1797 in k1793 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1783 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1770 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
/* csc.scm: 715  t-options */
f_668(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[300],t1));}

/* k1753 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1739 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1725 in k1715 in k1706 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1687 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1695,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 701  string->number */
C_string_to_number(3,0,t3,t2);}

/* k1693 in k1687 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 702  t-options */
f_668(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1696 in k1693 in k1687 in k1655 in k1652 in k1649 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_928(2,t4,t3);}

/* k1642 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=C_mutate(&lf[94],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 684  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[60],"scheme-files"),lf[295]);}

/* k1646 in k1642 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1596 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 678  build-platform */
t3=C_retrieve(lf[292]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1626 in k1596 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(C_word)C_eqp(lf[290],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 679  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[291],t5);}
else{
t3=((C_word*)t0)[2];
f_928(2,t3,C_SCHEME_UNDEFINED);}}

/* k1618 in k1626 in k1596 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 679  append */
t3=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t2);}

/* k1606 in k1626 in k1596 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_928(2,t5,t4);}

/* k1585 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t3=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_928(2,t4,t3);}

/* k1560 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1574,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 670  string-split */
t5=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1572 in k1560 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 670  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t1);}

/* k1564 in k1560 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_928(2,t5,t4);}

/* k1547 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1521 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 664  string-split */
t5=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1533 in k1521 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 664  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[87],"compile-options"),t1);}

/* k1525 in k1521 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_928(2,t5,t4);}

/* k1500 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 661  cons* */
t5=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[282],t3,t4);}

/* k1504 in k1500 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1483 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[31],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_928(2,t6,t5);}

/* k1466 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[30],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_928(2,t6,t5);}

/* k1449 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[29],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_928(2,t6,t5);}

/* k1432 in k1408 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_928(2,t6,t5);}

/* k1391 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1381 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1371 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1361 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1351 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1341 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_928(2,t3,t2);}

/* k1320 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[94],t2);
t6=((C_word*)t0)[2];
f_928(2,t6,t5);}

/* k1296 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 623  cons* */
t5=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,lf[252],t4,C_retrieve2(lf[92],"link-options"));}
else{
t3=t2;
f_1301(t3,C_SCHEME_UNDEFINED);}}

/* k1307 in k1296 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_1301(t3,t2);}

/* k1299 in k1296 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_928(2,t4,t3);}

/* k1283 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[247],C_retrieve2(lf[87],"compile-options"));
t4=C_mutate(&lf[87],t3);
t5=((C_word*)t0)[2];
f_928(2,t5,t4);}

/* k1272 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1274,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[242],C_retrieve2(lf[87],"compile-options"));
t4=C_mutate(&lf[87],t3);
t5=((C_word*)t0)[2];
f_928(2,t5,t4);}

/* k1232 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 605  append */
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_retrieve2(lf[104],"required-extensions"),t4);}

/* k1236 in k1232 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=C_mutate(&lf[104],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 606  t-options */
f_668(t3,(C_word)C_a_i_list(&a,2,lf[239],t4));}

/* k1239 in k1236 in k1232 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_928(2,t4,t3);}

/* k1141 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t3=t2;
f_1146(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1161,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 589  cons* */
t4=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[222],lf[223],C_retrieve2(lf[87],"compile-options"));}}

/* k1159 in k1141 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
f_1146(t3,t2);}

/* k1144 in k1141 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_1146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1146,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[220]:lf[221]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[92],"link-options"));
t4=C_mutate(&lf[92],t3);
t5=((C_word*)t0)[2];
f_928(2,t5,t4);}

/* k1084 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 573  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1072 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 572  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1060 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 571  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1048 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 570  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1015 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[102]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_928(2,t4,t3);}

/* k1004 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[101]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_928(2,t4,t3);}

/* k973 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 549  system */
t2=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k966 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 550  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k957 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 546  print */
t2=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k950 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 547  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k938 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 544  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k926 in k923 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 749  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_743(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_754,2,t0,t1);}
t2=C_mutate(&lf[87],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 499  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[92],"link-options"),C_retrieve2(lf[93],"builtin-link-options"));}

/* k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_758,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_916,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 502  compiler-options */
f_2457(t5);}
else{
t5=t4;
f_883(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_761(2,t4,C_SCHEME_UNDEFINED);}}

/* k914 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 502  print* */
t2=*((C_word*)lf[185]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k881 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[70],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 503  linker-options */
f_2706(t3);}
else{
t3=t2;
f_886(2,t3,C_SCHEME_UNDEFINED);}}

/* k907 in k881 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 503  print* */
t2=*((C_word*)lf[185]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k884 in k881 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_902,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 504  linker-libraries */
f_2758(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_889(2,t3,C_SCHEME_UNDEFINED);}}

/* k900 in k884 in k881 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 504  print* */
t2=*((C_word*)lf[185]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k887 in k884 in k881 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 505  newline */
t3=*((C_word*)lf[184]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k890 in k887 in k884 in k881 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 506  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_808,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[63],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* csc.scm: 512  quit */
f_445(t3,lf[163],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_808(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[100],"shared"))?(C_word)C_i_not(C_retrieve2(lf[67],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[183],C_retrieve2(lf[83],"translate-options"));
t6=C_mutate(&lf[83],t5);
t7=t3;
f_846(t7,t6);}
else{
t5=t3;
f_846(t5,C_SCHEME_UNDEFINED);}}}

/* k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_846,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[94],"target-filename"))){
t3=t2;
f_849(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_856,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[100],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 525  pathname-replace-extension */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[48],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 526  pathname-replace-extension */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[44],"executable-extension"));}}}

/* k854 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94],t1);
t3=((C_word*)t0)[2];
f_849(t3,t2);}

/* k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_849,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2117,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[60],"scheme-files"));}

/* a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2117,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 757  pathname-replace-extension */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[182]);}

/* k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 758  file-exists? */
t5=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2366 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 759  with-input-from-file */
t3=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_retrieve(lf[170]));}
else{
t2=((C_word*)t0)[3];
f_2362(t2,C_SCHEME_FALSE);}}

/* k2369 in k2366 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
f_2362(t3,(C_truep(t2)?t2:(C_word)C_i_string_equal_p(lf[181],t1)));}

/* k2360 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 761  $delete-file */
t2=C_retrieve2(lf[138],"$delete-file");
f_2968(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2124(2,t2,C_SCHEME_UNDEFINED);}}

/* k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_length(C_retrieve2(lf[60],"scheme-files"));
t4=(C_word)C_i_nequalp(C_fix(1),t3);
t5=(C_truep(t4)?C_retrieve2(lf[94],"target-filename"):((C_word*)t0)[2]);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?lf[178]:(C_truep(C_retrieve2(lf[66],"objc-mode"))?lf[179]:lf[180]));
/* csc.scm: 762  pathname-replace-extension */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,t5,t6);}

/* k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2130,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2295,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2299,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 772  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[99],"to-stdout"))){
t4=t3;
f_2307(t4,lf[176]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2341,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 776  cleanup-filename */
t5=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2339 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2307(t2,(C_word)C_a_i_list(&a,2,lf[177],t1));}

/* k2305 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2307,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2311,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[101],"static");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_2322(t5,t3);}
else{
t5=C_retrieve2(lf[102],"static-libs");
t6=t4;
f_2322(t6,(C_truep(t5)?t5:C_retrieve2(lf[103],"static-extensions")));}}

/* k2320 in k2305 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2322,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2327,tmp=(C_word)a,a+=2,tmp);
/* map */
t3=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[104],"required-extensions"));}
else{
t2=((C_word*)t0)[2];
f_2311(2,t2,C_SCHEME_END_OF_LIST);}}

/* a2326 in k2320 in k2305 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2327,3,t0,t1,t2);}
/* csc.scm: 778  conc */
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[175],t2);}

/* k2309 in k2305 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2315,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2319,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 780  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2317 in k2309 in k2305 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[109],"quote-option"),t1);}

/* k2313 in k2309 in k2305 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 773  append */
t2=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2301 in k2297 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 772  cons* */
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve2(lf[28],"translator"),((C_word*)t0)[2],t1);}

/* k2293 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 771  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[173]);}

/* k2289 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 770  $system */
t2=C_retrieve2(lf[133],"$system");
f_2936(3,t2,((C_word*)t0)[2],t1);}

/* k2285 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2130(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 782  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 783  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_retrieve2(lf[61],"c-files"));}

/* k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=C_mutate(&lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 784  append */
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[62],"generated-c-files"));}

/* k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=C_mutate(&lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 785  file-exists? */
t4=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2152,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 786  with-input-from-file */
t4=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 788  read-line */
t3=C_retrieve(lf[170]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2154 in a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2161,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2269,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 798  read-file */
t4=C_retrieve(lf[169]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2267 in k2154 in a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2160 in k2154 in a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2161,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2163,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(t2);
/* for-each */
t8=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,C_retrieve2(lf[133],"$system"),t7);}
else{
/* g192194 */
f_2163(t1,t2);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[167]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t8))){
t9=(C_word)C_i_cdr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* append */
t11=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,C_retrieve2(lf[87],"compile-options"),t9);}
else{
/* g192194 */
f_2163(t1,t2);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2230,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[168]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t2);
t12=t8;
f_2230(t12,(C_word)C_i_listp(t11));}
else{
t11=t8;
f_2230(t11,C_SCHEME_FALSE);}}}}
else{
/* g192194 */
f_2163(t1,t2);}}

/* k2228 in a2160 in k2154 in a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2230,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[92],"link-options"),t2);}
else{
/* g192194 */
f_2163(((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2235 in k2228 in a2160 in k2154 in a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2215 in a2160 in k2154 in a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g192 in a2160 in k2154 in a2151 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2163(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2163,NULL,2,t1,t2);}
/* csc.scm: 797  error */
t3=*((C_word*)lf[164]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[165],t2);}

/* k2145 in k2142 in k2136 in k2132 in k2128 in k2125 in k2122 in k2119 in a2116 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 799  $delete-file */
t2=C_retrieve2(lf[138],"$delete-file");
f_2968(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2107 in k847 in k844 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t2=((C_word*)t0)[2];
f_764(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k806 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[63],"object-files"):C_retrieve2(lf[61],"c-files"));
/* csc.scm: 513  last */
t5=C_retrieve(lf[162]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k809 in k806 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
if(C_truep(C_retrieve2(lf[94],"target-filename"))){
t2=((C_word*)t0)[2];
f_764(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[100],"shared"))){
/* csc.scm: 517  pathname-replace-extension */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[48],"shared-library-extension"));}
else{
/* csc.scm: 518  pathname-replace-extension */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[44],"executable-extension"));}}}

/* k816 in k809 in k806 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94],t1);
t3=((C_word*)t0)[2];
f_764(2,t3,t2);}

/* k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
if(C_truep(C_retrieve2(lf[97],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[61],"c-files"));}}

/* a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2406,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 810  pathname-replace-extension */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_retrieve2(lf[35],"object-extension"));}

/* k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2431,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2443,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 816  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2441 in k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 817  cleanup-filename */
t4=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2453 in k2441 in k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 817  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[47],"compile-output-flag"),t1);}

/* k2445 in k2441 in k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 819  compiler-options */
f_2457(t2);}

/* k2449 in k2445 in k2441 in k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[160],t1);
/* csc.scm: 813  string-intersperse */
t3=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2429 in k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 812  $system */
t2=C_retrieve2(lf[133],"$system");
f_2936(3,t2,((C_word*)t0)[2],t1);}

/* k2425 in k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2409(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 820  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2407 in k2404 in a2401 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2409,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[64],"generated-object-files"));
t3=C_mutate(&lf[64],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2384 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 824  reverse */
t4=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2398 in k2384 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 824  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[63],"object-files"));}

/* k2388 in k2384 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t3=((C_word*)t0)[2];
f_770(2,t3,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[62],"generated-c-files"));}}

/* k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_770,2,t0,t1);}
if(C_truep(C_retrieve2(lf[98],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_785,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 532  printf */
t4=C_retrieve(lf[134]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[159],C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[94],"target-filename"));}
else{
t3=t2;
f_776(2,t3,C_SCHEME_UNDEFINED);}}}

/* k783 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 534  sprintf */
t4=C_retrieve(lf[157]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[158],C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[94],"target-filename"));}

/* k800 in k783 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 534  $system */
t2=C_retrieve2(lf[133],"$system");
f_2936(3,t2,((C_word*)t0)[2],t1);}

/* k796 in k783 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_776(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 535  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2591,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2595,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2597,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2603,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 841  ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}

/* a2602 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2603r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2603r(t0,t1,t2);}}

static void C_ccall f_2603r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2596 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
/* csc.scm: 841  static-extension-info */
f_2609(t1);}

/* k2593 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 840  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[63],"object-files"),t1);}

/* k2589 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[55],"cleanup-filename"),t1);}

/* k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2485,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 842  cleanup-filename */
t3=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve2(lf[94],"target-filename"));}

/* k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2488,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2559,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[32],"c++-linker"):C_retrieve2(lf[31],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2571,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 850  string-append */
t9=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[41],"link-output-flag"),t1);}

/* k2577 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 851  linker-options */
f_2706(t2);}

/* k2581 in k2577 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 852  linker-libraries */
f_2758(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k2585 in k2581 in k2577 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 848  append */
t3=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2569 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 846  cons* */
t2=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2561 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 845  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2557 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 844  $system */
t2=C_retrieve2(lf[133],"$system");
f_2936(3,t2,((C_word*)t0)[2],t1);}

/* k2553 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2488(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 853  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[18],"cross-chicken"));
t5=t3;
f_2500(t5,(C_truep(t4)?t4:C_retrieve2(lf[17],"host-mode")));}
else{
t4=t3;
f_2500(t4,C_SCHEME_FALSE);}}

/* k2498 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2525,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2529,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2533,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_2491(2,t2,C_SCHEME_UNDEFINED);}}

/* k2531 in k2498 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 860  prefix */
f_474(((C_word*)t0)[2],lf[154],lf[155],t1);}

/* k2527 in k2498 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 859  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[153]);}

/* k2523 in k2498 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 858  quotewrap */
f_487(((C_word*)t0)[2],t1);}

/* k2519 in k2498 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 856  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[151],t1,lf[152],((C_word*)t0)[2]);}

/* k2515 in k2498 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 855  $system */
t2=C_retrieve2(lf[133],"$system");
f_2936(3,t2,((C_word*)t0)[2],t1);}

/* k2511 in k2498 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2491(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 867  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2489 in k2486 in k2483 in k2480 in k774 in k768 in k762 in k759 in k756 in k752 in loop in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[64],"generated-object-files"));}}

/* shared-build in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_714(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_714,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_719,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 486  cons* */
t4=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[148],lf[149],C_retrieve2(lf[83],"translate-options"));}

/* k717 in shared-build in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
t2=C_mutate(&lf[83],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 487  append */
t4=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[52],"pic-options"),lf[147],C_retrieve2(lf[87],"compile-options"));}

/* k721 in k717 in shared-build in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=C_mutate(&lf[87],t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?lf[143]:lf[144]):(C_truep(C_retrieve2(lf[5],"msvc"))?lf[145]:lf[146]));
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[92],"link-options"));
t5=C_mutate(&lf[92],t4);
t6=lf[100]=C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_675(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_675,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_693,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_693(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_693(2,t8,(C_word)C_i_car(t4));}
else{
/* csc.scm: 482  ##sys#error */
t8=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k691 in check in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_693,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 483  quit */
f_445(((C_word*)t0)[3],lf[142],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_668(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_668,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_673,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 479  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),t2);}

/* k671 in t-options in k2992 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2982 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2990,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[141]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2988 in k2982 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2985 in k2982 in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2968,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2972,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[95],"verbose"))){
/* csc.scm: 947  print */
t4=*((C_word*)lf[137]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[140],t2);}
else{
t4=t3;
f_2972(2,t4,C_SCHEME_UNDEFINED);}}

/* k2970 in $delete-file in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 948  delete-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2936,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2940,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[95],"verbose"))){
/* csc.scm: 934  print */
t4=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2940(2,t4,C_SCHEME_UNDEFINED);}}

/* k2938 in $system in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t3=t2;
f_2944(t3,C_fix(0));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 938  system */
t4=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k2961 in k2938 in $system in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_2944(t3,(C_truep(t2)?C_fix(0):C_fix(1)));}

/* k2942 in k2938 in $system in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2944,NULL,2,t0,t1);}
t2=C_mutate(&lf[132],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[132],"last-exit-code")))){
t4=t3;
f_2947(2,t4,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 942  printf */
t4=C_retrieve(lf[134]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[135],C_retrieve2(lf[132],"last-exit-code"),((C_word*)t0)[2]);}}

/* k2945 in k2942 in k2938 in $system in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[132],"last-exit-code"));}

/* quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2907,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2919,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2933,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2931 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 925  any */
t2=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2918 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2919,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[122])));}

/* k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2840,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2856 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2860(t5,((C_word*)t0)[2],t1);}

/* fold in k2856 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2860,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[122]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2883,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 916  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_2890(t6,t5);}
else{
t5=t4;
f_2890(t5,C_SCHEME_UNDEFINED);}}}}

/* k2888 in fold in k2856 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2890,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 919  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2860(t4,t2,t3);}

/* k2895 in k2888 in fold in k2856 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2881 in fold in k2856 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 916  cons* */
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k2852 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2838 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 921  string-translate* */
t3=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[127]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k2848 in k2838 in k2912 in quote-option in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 921  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[124],t1,lf[125]);}

/* linker-libraries in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2758(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2758,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2762,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2762(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2762(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2760 in linker-libraries in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2804,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2810,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 896  ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_2773(2,t4,C_SCHEME_END_OF_LIST);}}

/* a2809 in k2760 in linker-libraries in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2810r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2810r(t0,t1,t2);}}

static void C_ccall f_2810r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2803 in k2760 in linker-libraries in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
/* csc.scm: 896  static-extension-info */
f_2609(t1);}

/* k2771 in k2760 in linker-libraries in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=C_retrieve2(lf[101],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[102],"static-libs"));
t4=(C_truep(t3)?(C_truep(C_retrieve2(lf[105],"gui"))?C_retrieve2(lf[79],"gui-library-files"):C_retrieve2(lf[81],"library-files")):(C_truep(C_retrieve2(lf[105],"gui"))?C_retrieve2(lf[80],"gui-shared-library-files"):C_retrieve2(lf[82],"shared-library-files")));
t5=C_retrieve2(lf[101],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[102],"static-libs"));
t7=(C_truep(t6)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[73],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[74],"extra-shared-libraries")));
/* csc.scm: 895  append */
t8=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* k2767 in k2760 in linker-libraries in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 894  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* linker-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2706(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2706,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2744,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2746,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2752,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 890  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a2751 in linker-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2752r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2752r(t0,t1,t2);}}

static void C_ccall f_2752r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a2745 in linker-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2746,2,t0,t1);}
/* csc.scm: 890  static-extension-info */
f_2609(t1);}

/* k2742 in linker-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 889  append */
t2=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[90],"linking-optimization-options"),C_retrieve2(lf[92],"link-options"),t1);}

/* k2738 in linker-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 888  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2712 in linker-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[101],"static"))?(C_truep(lf[3])?C_SCHEME_FALSE:(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx")))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[118]:lf[119]);
/* csc.scm: 887  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2609(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2609,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2613,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 871  repository-path */
t3=C_retrieve(lf[116]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=C_retrieve2(lf[101],"static");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2619(t4,t2);}
else{
t4=C_retrieve2(lf[102],"static-libs");
t5=t3;
f_2619(t5,(C_truep(t4)?t4:C_retrieve2(lf[103],"static-extensions")));}}

/* k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2624(t5,((C_word*)t0)[2],C_retrieve2(lf[104],"required-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 884  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2624,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 875  reverse */
t6=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 876  extension-information */
t7=C_retrieve(lf[115]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k2643 in loop in k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[113],t1);
t3=(C_word)C_i_assq(lf[114],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2683,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 881  make-pathname */
t8=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_2665(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 883  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2624(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2681 in k2643 in loop in k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2665(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2663 in k2643 in loop in k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2665,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2669,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_2669(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_2669(t3,((C_word*)t0)[2]);}}

/* k2667 in k2663 in k2643 in loop in k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 880  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2624(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2636 in loop in k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2642,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 875  reverse */
t3=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2640 in k2636 in loop in k2617 in k2611 in static-extension-info in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 875  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_2457(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2457,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2465,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2469,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[101],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[102],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
/* csc.scm: 830  append */
t7=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t6,C_retrieve2(lf[89],"compilation-optimization-options"),C_retrieve2(lf[87],"compile-options"));}

/* k2467 in compiler-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[109],"quote-option"),t1);}

/* k2463 in compiler-options in k643 in k638 in k630 in k622 in k613 in k3116 in k605 in k3149 in k597 in k593 in k567 in k562 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 828  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_3209 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3209,3,t0,t1,t2);}
/* csc.scm: 165  quotewrap */
f_487(t1,t2);}

/* f_3214 in k554 in k550 in k519 in k515 in k511 in k507 in k503 in k499 in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3214,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* quotewrap in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_487(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_487,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_494,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 127  string-any */
t4=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[26]+1),t2);}

/* k492 in quotewrap in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 128  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[23],((C_word*)t0)[2],lf[24]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* prefix in k462 in k458 in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_474(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_474,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[14],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[14],"chicken-prefix"),t3);
/* csc.scm: 123  make-pathname */
t6=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_fcall f_445(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_445,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_449,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_456,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 113  current-error-port */
t6=C_retrieve(lf[13]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k454 in quit in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 113  fprintf */
t2=C_retrieve(lf[11]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,lf[12],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k447 in quit in k441 in k3324 in k3328 in k3332 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 */
static void C_ccall f_449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 114  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[320] = {
{"toplevelcsc.scm",(void*)C_toplevel},
{"f_391csc.scm",(void*)f_391},
{"f_394csc.scm",(void*)f_394},
{"f_397csc.scm",(void*)f_397},
{"f_400csc.scm",(void*)f_400},
{"f_403csc.scm",(void*)f_403},
{"f_406csc.scm",(void*)f_406},
{"f_409csc.scm",(void*)f_409},
{"f_412csc.scm",(void*)f_412},
{"f_415csc.scm",(void*)f_415},
{"f_418csc.scm",(void*)f_418},
{"f_421csc.scm",(void*)f_421},
{"f_424csc.scm",(void*)f_424},
{"f_427csc.scm",(void*)f_427},
{"f_3334csc.scm",(void*)f_3334},
{"f_3330csc.scm",(void*)f_3330},
{"f_3326csc.scm",(void*)f_3326},
{"f_3322csc.scm",(void*)f_3322},
{"f_3318csc.scm",(void*)f_3318},
{"f_443csc.scm",(void*)f_443},
{"f_460csc.scm",(void*)f_460},
{"f_464csc.scm",(void*)f_464},
{"f_3302csc.scm",(void*)f_3302},
{"f_3298csc.scm",(void*)f_3298},
{"f_501csc.scm",(void*)f_501},
{"f_3284csc.scm",(void*)f_3284},
{"f_3288csc.scm",(void*)f_3288},
{"f_3280csc.scm",(void*)f_3280},
{"f_3276csc.scm",(void*)f_3276},
{"f_505csc.scm",(void*)f_505},
{"f_3266csc.scm",(void*)f_3266},
{"f_509csc.scm",(void*)f_509},
{"f_3256csc.scm",(void*)f_3256},
{"f_513csc.scm",(void*)f_513},
{"f_3243csc.scm",(void*)f_3243},
{"f_517csc.scm",(void*)f_517},
{"f_3230csc.scm",(void*)f_3230},
{"f_521csc.scm",(void*)f_521},
{"f_552csc.scm",(void*)f_552},
{"f_556csc.scm",(void*)f_556},
{"f_3199csc.scm",(void*)f_3199},
{"f_564csc.scm",(void*)f_564},
{"f_3189csc.scm",(void*)f_3189},
{"f_569csc.scm",(void*)f_569},
{"f_595csc.scm",(void*)f_595},
{"f_599csc.scm",(void*)f_599},
{"f_3163csc.scm",(void*)f_3163},
{"f_3167csc.scm",(void*)f_3167},
{"f_3159csc.scm",(void*)f_3159},
{"f_3155csc.scm",(void*)f_3155},
{"f_3151csc.scm",(void*)f_3151},
{"f_3147csc.scm",(void*)f_3147},
{"f_607csc.scm",(void*)f_607},
{"f_3130csc.scm",(void*)f_3130},
{"f_3134csc.scm",(void*)f_3134},
{"f_3126csc.scm",(void*)f_3126},
{"f_3122csc.scm",(void*)f_3122},
{"f_3118csc.scm",(void*)f_3118},
{"f_3114csc.scm",(void*)f_3114},
{"f_615csc.scm",(void*)f_615},
{"f_3101csc.scm",(void*)f_3101},
{"f_624csc.scm",(void*)f_624},
{"f_3090csc.scm",(void*)f_3090},
{"f_3086csc.scm",(void*)f_3086},
{"f_632csc.scm",(void*)f_632},
{"f_3073csc.scm",(void*)f_3073},
{"f_640csc.scm",(void*)f_640},
{"f_3066csc.scm",(void*)f_3066},
{"f_3040csc.scm",(void*)f_3040},
{"f_3056csc.scm",(void*)f_3056},
{"f_3052csc.scm",(void*)f_3052},
{"f_3048csc.scm",(void*)f_3048},
{"f_3044csc.scm",(void*)f_3044},
{"f_3033csc.scm",(void*)f_3033},
{"f_3029csc.scm",(void*)f_3029},
{"f_3019csc.scm",(void*)f_3019},
{"f_3015csc.scm",(void*)f_3015},
{"f_645csc.scm",(void*)f_645},
{"f_3002csc.scm",(void*)f_3002},
{"f_2998csc.scm",(void*)f_2998},
{"f_2994csc.scm",(void*)f_2994},
{"f_743csc.scm",(void*)f_743},
{"f_925csc.scm",(void*)f_925},
{"f_1410csc.scm",(void*)f_1410},
{"f_1651csc.scm",(void*)f_1651},
{"f_1654csc.scm",(void*)f_1654},
{"f_1657csc.scm",(void*)f_1657},
{"f_2039csc.scm",(void*)f_2039},
{"f_1708csc.scm",(void*)f_1708},
{"f_1717csc.scm",(void*)f_1717},
{"f_1894csc.scm",(void*)f_1894},
{"f_2002csc.scm",(void*)f_2002},
{"f_2008csc.scm",(void*)f_2008},
{"f_1905csc.scm",(void*)f_1905},
{"f_1916csc.scm",(void*)f_1916},
{"f_1992csc.scm",(void*)f_1992},
{"f_1984csc.scm",(void*)f_1984},
{"f_1967csc.scm",(void*)f_1967},
{"f_1943csc.scm",(void*)f_1943},
{"f_1948csc.scm",(void*)f_1948},
{"f_1930csc.scm",(void*)f_1930},
{"f_1899csc.scm",(void*)f_1899},
{"f_1864csc.scm",(void*)f_1864},
{"f_1795csc.scm",(void*)f_1795},
{"f_1847csc.scm",(void*)f_1847},
{"f_1843csc.scm",(void*)f_1843},
{"f_1828csc.scm",(void*)f_1828},
{"f_1826csc.scm",(void*)f_1826},
{"f_1822csc.scm",(void*)f_1822},
{"f_1799csc.scm",(void*)f_1799},
{"f_1785csc.scm",(void*)f_1785},
{"f_1772csc.scm",(void*)f_1772},
{"f_1755csc.scm",(void*)f_1755},
{"f_1741csc.scm",(void*)f_1741},
{"f_1727csc.scm",(void*)f_1727},
{"f_1689csc.scm",(void*)f_1689},
{"f_1695csc.scm",(void*)f_1695},
{"f_1698csc.scm",(void*)f_1698},
{"f_1644csc.scm",(void*)f_1644},
{"f_1648csc.scm",(void*)f_1648},
{"f_1598csc.scm",(void*)f_1598},
{"f_1628csc.scm",(void*)f_1628},
{"f_1620csc.scm",(void*)f_1620},
{"f_1608csc.scm",(void*)f_1608},
{"f_1587csc.scm",(void*)f_1587},
{"f_1562csc.scm",(void*)f_1562},
{"f_1574csc.scm",(void*)f_1574},
{"f_1566csc.scm",(void*)f_1566},
{"f_1549csc.scm",(void*)f_1549},
{"f_1523csc.scm",(void*)f_1523},
{"f_1535csc.scm",(void*)f_1535},
{"f_1527csc.scm",(void*)f_1527},
{"f_1502csc.scm",(void*)f_1502},
{"f_1506csc.scm",(void*)f_1506},
{"f_1485csc.scm",(void*)f_1485},
{"f_1468csc.scm",(void*)f_1468},
{"f_1451csc.scm",(void*)f_1451},
{"f_1434csc.scm",(void*)f_1434},
{"f_1393csc.scm",(void*)f_1393},
{"f_1383csc.scm",(void*)f_1383},
{"f_1373csc.scm",(void*)f_1373},
{"f_1363csc.scm",(void*)f_1363},
{"f_1353csc.scm",(void*)f_1353},
{"f_1343csc.scm",(void*)f_1343},
{"f_1322csc.scm",(void*)f_1322},
{"f_1298csc.scm",(void*)f_1298},
{"f_1309csc.scm",(void*)f_1309},
{"f_1301csc.scm",(void*)f_1301},
{"f_1285csc.scm",(void*)f_1285},
{"f_1274csc.scm",(void*)f_1274},
{"f_1234csc.scm",(void*)f_1234},
{"f_1238csc.scm",(void*)f_1238},
{"f_1241csc.scm",(void*)f_1241},
{"f_1143csc.scm",(void*)f_1143},
{"f_1161csc.scm",(void*)f_1161},
{"f_1146csc.scm",(void*)f_1146},
{"f_1086csc.scm",(void*)f_1086},
{"f_1074csc.scm",(void*)f_1074},
{"f_1062csc.scm",(void*)f_1062},
{"f_1050csc.scm",(void*)f_1050},
{"f_1017csc.scm",(void*)f_1017},
{"f_1006csc.scm",(void*)f_1006},
{"f_975csc.scm",(void*)f_975},
{"f_968csc.scm",(void*)f_968},
{"f_959csc.scm",(void*)f_959},
{"f_952csc.scm",(void*)f_952},
{"f_940csc.scm",(void*)f_940},
{"f_928csc.scm",(void*)f_928},
{"f_754csc.scm",(void*)f_754},
{"f_758csc.scm",(void*)f_758},
{"f_916csc.scm",(void*)f_916},
{"f_883csc.scm",(void*)f_883},
{"f_909csc.scm",(void*)f_909},
{"f_886csc.scm",(void*)f_886},
{"f_902csc.scm",(void*)f_902},
{"f_889csc.scm",(void*)f_889},
{"f_892csc.scm",(void*)f_892},
{"f_761csc.scm",(void*)f_761},
{"f_846csc.scm",(void*)f_846},
{"f_856csc.scm",(void*)f_856},
{"f_849csc.scm",(void*)f_849},
{"f_2117csc.scm",(void*)f_2117},
{"f_2121csc.scm",(void*)f_2121},
{"f_2368csc.scm",(void*)f_2368},
{"f_2371csc.scm",(void*)f_2371},
{"f_2362csc.scm",(void*)f_2362},
{"f_2124csc.scm",(void*)f_2124},
{"f_2127csc.scm",(void*)f_2127},
{"f_2299csc.scm",(void*)f_2299},
{"f_2341csc.scm",(void*)f_2341},
{"f_2307csc.scm",(void*)f_2307},
{"f_2322csc.scm",(void*)f_2322},
{"f_2327csc.scm",(void*)f_2327},
{"f_2311csc.scm",(void*)f_2311},
{"f_2319csc.scm",(void*)f_2319},
{"f_2315csc.scm",(void*)f_2315},
{"f_2303csc.scm",(void*)f_2303},
{"f_2295csc.scm",(void*)f_2295},
{"f_2291csc.scm",(void*)f_2291},
{"f_2287csc.scm",(void*)f_2287},
{"f_2130csc.scm",(void*)f_2130},
{"f_2134csc.scm",(void*)f_2134},
{"f_2138csc.scm",(void*)f_2138},
{"f_2144csc.scm",(void*)f_2144},
{"f_2152csc.scm",(void*)f_2152},
{"f_2156csc.scm",(void*)f_2156},
{"f_2269csc.scm",(void*)f_2269},
{"f_2161csc.scm",(void*)f_2161},
{"f_2230csc.scm",(void*)f_2230},
{"f_2237csc.scm",(void*)f_2237},
{"f_2217csc.scm",(void*)f_2217},
{"f_2163csc.scm",(void*)f_2163},
{"f_2147csc.scm",(void*)f_2147},
{"f_2109csc.scm",(void*)f_2109},
{"f_808csc.scm",(void*)f_808},
{"f_811csc.scm",(void*)f_811},
{"f_818csc.scm",(void*)f_818},
{"f_764csc.scm",(void*)f_764},
{"f_2402csc.scm",(void*)f_2402},
{"f_2406csc.scm",(void*)f_2406},
{"f_2443csc.scm",(void*)f_2443},
{"f_2455csc.scm",(void*)f_2455},
{"f_2447csc.scm",(void*)f_2447},
{"f_2451csc.scm",(void*)f_2451},
{"f_2431csc.scm",(void*)f_2431},
{"f_2427csc.scm",(void*)f_2427},
{"f_2409csc.scm",(void*)f_2409},
{"f_2386csc.scm",(void*)f_2386},
{"f_2400csc.scm",(void*)f_2400},
{"f_2390csc.scm",(void*)f_2390},
{"f_770csc.scm",(void*)f_770},
{"f_785csc.scm",(void*)f_785},
{"f_802csc.scm",(void*)f_802},
{"f_798csc.scm",(void*)f_798},
{"f_776csc.scm",(void*)f_776},
{"f_2603csc.scm",(void*)f_2603},
{"f_2597csc.scm",(void*)f_2597},
{"f_2595csc.scm",(void*)f_2595},
{"f_2591csc.scm",(void*)f_2591},
{"f_2482csc.scm",(void*)f_2482},
{"f_2485csc.scm",(void*)f_2485},
{"f_2579csc.scm",(void*)f_2579},
{"f_2583csc.scm",(void*)f_2583},
{"f_2587csc.scm",(void*)f_2587},
{"f_2571csc.scm",(void*)f_2571},
{"f_2563csc.scm",(void*)f_2563},
{"f_2559csc.scm",(void*)f_2559},
{"f_2555csc.scm",(void*)f_2555},
{"f_2488csc.scm",(void*)f_2488},
{"f_2500csc.scm",(void*)f_2500},
{"f_2533csc.scm",(void*)f_2533},
{"f_2529csc.scm",(void*)f_2529},
{"f_2525csc.scm",(void*)f_2525},
{"f_2521csc.scm",(void*)f_2521},
{"f_2517csc.scm",(void*)f_2517},
{"f_2513csc.scm",(void*)f_2513},
{"f_2491csc.scm",(void*)f_2491},
{"f_714csc.scm",(void*)f_714},
{"f_719csc.scm",(void*)f_719},
{"f_723csc.scm",(void*)f_723},
{"f_675csc.scm",(void*)f_675},
{"f_693csc.scm",(void*)f_693},
{"f_668csc.scm",(void*)f_668},
{"f_673csc.scm",(void*)f_673},
{"f_2984csc.scm",(void*)f_2984},
{"f_2990csc.scm",(void*)f_2990},
{"f_2987csc.scm",(void*)f_2987},
{"f_2968csc.scm",(void*)f_2968},
{"f_2972csc.scm",(void*)f_2972},
{"f_2936csc.scm",(void*)f_2936},
{"f_2940csc.scm",(void*)f_2940},
{"f_2963csc.scm",(void*)f_2963},
{"f_2944csc.scm",(void*)f_2944},
{"f_2947csc.scm",(void*)f_2947},
{"f_2907csc.scm",(void*)f_2907},
{"f_2933csc.scm",(void*)f_2933},
{"f_2919csc.scm",(void*)f_2919},
{"f_2914csc.scm",(void*)f_2914},
{"f_2858csc.scm",(void*)f_2858},
{"f_2860csc.scm",(void*)f_2860},
{"f_2890csc.scm",(void*)f_2890},
{"f_2897csc.scm",(void*)f_2897},
{"f_2883csc.scm",(void*)f_2883},
{"f_2854csc.scm",(void*)f_2854},
{"f_2840csc.scm",(void*)f_2840},
{"f_2850csc.scm",(void*)f_2850},
{"f_2758csc.scm",(void*)f_2758},
{"f_2762csc.scm",(void*)f_2762},
{"f_2810csc.scm",(void*)f_2810},
{"f_2804csc.scm",(void*)f_2804},
{"f_2773csc.scm",(void*)f_2773},
{"f_2769csc.scm",(void*)f_2769},
{"f_2706csc.scm",(void*)f_2706},
{"f_2752csc.scm",(void*)f_2752},
{"f_2746csc.scm",(void*)f_2746},
{"f_2744csc.scm",(void*)f_2744},
{"f_2740csc.scm",(void*)f_2740},
{"f_2714csc.scm",(void*)f_2714},
{"f_2609csc.scm",(void*)f_2609},
{"f_2613csc.scm",(void*)f_2613},
{"f_2619csc.scm",(void*)f_2619},
{"f_2624csc.scm",(void*)f_2624},
{"f_2645csc.scm",(void*)f_2645},
{"f_2683csc.scm",(void*)f_2683},
{"f_2665csc.scm",(void*)f_2665},
{"f_2669csc.scm",(void*)f_2669},
{"f_2638csc.scm",(void*)f_2638},
{"f_2642csc.scm",(void*)f_2642},
{"f_2457csc.scm",(void*)f_2457},
{"f_2469csc.scm",(void*)f_2469},
{"f_2465csc.scm",(void*)f_2465},
{"f_3209csc.scm",(void*)f_3209},
{"f_3214csc.scm",(void*)f_3214},
{"f_487csc.scm",(void*)f_487},
{"f_494csc.scm",(void*)f_494},
{"f_474csc.scm",(void*)f_474},
{"f_445csc.scm",(void*)f_445},
{"f_456csc.scm",(void*)f_456},
{"f_449csc.scm",(void*)f_449},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
