/* Generated from srfi-14.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:56
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: srfi-14.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file usrfi-14.c
   unit: srfi_14
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[109];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_14_toplevel)
C_externexport void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_629)
static void C_ccall f_629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_fcall f_2090(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_fcall f_2105(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2059)
static void C_fcall f_2059(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_fcall f_1936(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1942)
static void C_fcall f_1942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_fcall f_1952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_fcall f_1839(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1882)
static void C_fcall f_1882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static C_word C_fcall f_1858(C_word t0,C_word t1);
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_fcall f_1795(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_fcall f_1805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1731)
static C_word C_fcall f_1731(C_word t0,C_word t1);
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_fcall f_1680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_fcall f_1698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_fcall f_1622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_fcall f_1564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1570)
static void C_fcall f_1570(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_fcall f_1520(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_fcall f_1471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_fcall f_1367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_fcall f_1377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_fcall f_1311(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_fcall f_1260(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_fcall f_1269(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1282)
static void C_fcall f_1282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1166)
static void C_fcall f_1166(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1170)
static void C_ccall f_1170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_fcall f_1140(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1152)
static void C_ccall f_1152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_fcall f_1092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static C_word C_fcall f_1055(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_925)
static void C_fcall f_925(C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_fcall f_939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_960)
static void C_fcall f_960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static C_word C_fcall f_984(C_word t0,C_word t1);
C_noret_decl(f_820)
static void C_ccall f_820(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_820)
static void C_ccall f_820r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_842)
static void C_fcall f_842(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_869)
static void C_fcall f_869(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_786)
static void C_fcall f_786(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_718)
static void C_fcall f_718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_724)
static void C_fcall f_724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_fcall f_671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_661)
static void C_fcall f_661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_643)
static void C_ccall f_643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_637)
static C_word C_fcall f_637(C_word t0);
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_2496)
static void C_fcall trf_2496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2496(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2496(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2090)
static void C_fcall trf_2090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2090(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2090(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2105)
static void C_fcall trf_2105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2105(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2105(t0,t1,t2);}

C_noret_decl(trf_2049)
static void C_fcall trf_2049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2049(t0,t1,t2);}

C_noret_decl(trf_2059)
static void C_fcall trf_2059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2059(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2059(t0,t1,t2);}

C_noret_decl(trf_1936)
static void C_fcall trf_1936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1936(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1936(t0,t1,t2,t3);}

C_noret_decl(trf_1942)
static void C_fcall trf_1942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1942(t0,t1,t2);}

C_noret_decl(trf_1952)
static void C_fcall trf_1952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1952(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1952(t0,t1);}

C_noret_decl(trf_1839)
static void C_fcall trf_1839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1839(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1839(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1882)
static void C_fcall trf_1882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1882(t0,t1);}

C_noret_decl(trf_1795)
static void C_fcall trf_1795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1795(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1795(t0,t1,t2,t3);}

C_noret_decl(trf_1805)
static void C_fcall trf_1805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1805(t0,t1);}

C_noret_decl(trf_1718)
static void C_fcall trf_1718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1718(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1718(t0,t1,t2,t3);}

C_noret_decl(trf_1680)
static void C_fcall trf_1680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1680(t0,t1,t2,t3);}

C_noret_decl(trf_1698)
static void C_fcall trf_1698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1698(t0,t1);}

C_noret_decl(trf_1622)
static void C_fcall trf_1622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1622(t0,t1,t2);}

C_noret_decl(trf_1564)
static void C_fcall trf_1564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1564(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1564(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1570)
static void C_fcall trf_1570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1570(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1570(t0,t1,t2);}

C_noret_decl(trf_1520)
static void C_fcall trf_1520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1520(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1520(t0,t1,t2);}

C_noret_decl(trf_1471)
static void C_fcall trf_1471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1471(t0,t1,t2);}

C_noret_decl(trf_1424)
static void C_fcall trf_1424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1424(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1424(t0,t1,t2,t3);}

C_noret_decl(trf_1367)
static void C_fcall trf_1367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1367(t0,t1,t2);}

C_noret_decl(trf_1377)
static void C_fcall trf_1377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1377(t0,t1);}

C_noret_decl(trf_1311)
static void C_fcall trf_1311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1311(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1311(t0,t1,t2);}

C_noret_decl(trf_1260)
static void C_fcall trf_1260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1260(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1260(t0,t1,t2,t3);}

C_noret_decl(trf_1269)
static void C_fcall trf_1269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1269(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1269(t0,t1,t2);}

C_noret_decl(trf_1282)
static void C_fcall trf_1282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1282(t0,t1);}

C_noret_decl(trf_1166)
static void C_fcall trf_1166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1166(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1166(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1140)
static void C_fcall trf_1140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1140(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1140(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1092)
static void C_fcall trf_1092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1092(t0,t1,t2,t3);}

C_noret_decl(trf_925)
static void C_fcall trf_925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_925(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_925(t0,t1);}

C_noret_decl(trf_939)
static void C_fcall trf_939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_939(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_939(t0,t1,t2,t3);}

C_noret_decl(trf_960)
static void C_fcall trf_960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_960(t0,t1);}

C_noret_decl(trf_842)
static void C_fcall trf_842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_842(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_842(t0,t1,t2,t3);}

C_noret_decl(trf_869)
static void C_fcall trf_869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_869(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_869(t0,t1,t2);}

C_noret_decl(trf_786)
static void C_fcall trf_786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_786(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_786(t0,t1,t2);}

C_noret_decl(trf_718)
static void C_fcall trf_718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_718(t0,t1,t2);}

C_noret_decl(trf_724)
static void C_fcall trf_724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_724(t0,t1,t2);}

C_noret_decl(trf_671)
static void C_fcall trf_671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_671(t0,t1,t2);}

C_noret_decl(trf_661)
static void C_fcall trf_661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_661(t0,t1);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(862)){
C_save(t1);
C_rereclaim2(862*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,109);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"make-char-set");
lf[5]=C_h_intern(&lf[5],8,"char-set");
lf[6]=C_h_intern(&lf[6],10,"char-set:s");
lf[7]=C_h_intern(&lf[7],9,"char-set\077");
lf[9]=C_h_intern(&lf[9],13,"\003syssubstring");
lf[11]=C_h_intern(&lf[11],9,"\003syserror");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000 BASE-CS parameter not a char-set");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\0003Expected final base char set -- too many parameters");
lf[14]=C_h_intern(&lf[14],11,"make-string");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\016Not a char-set");
lf[19]=C_h_intern(&lf[19],13,"char-set-copy");
lf[20]=C_h_intern(&lf[20],9,"char-set=");
lf[21]=C_h_intern(&lf[21],10,"char-set<=");
lf[22]=C_h_intern(&lf[22],13,"char-set-hash");
lf[23]=C_h_intern(&lf[23],6,"modulo");
lf[24]=C_h_intern(&lf[24],18,"char-set-contains\077");
lf[25]=C_h_intern(&lf[25],13,"char-set-size");
lf[26]=C_h_intern(&lf[26],14,"char-set-count");
lf[28]=C_h_intern(&lf[28],12,"\003sysfor-each");
lf[30]=C_h_intern(&lf[30],15,"char-set-adjoin");
lf[31]=C_h_intern(&lf[31],16,"char-set-adjoin!");
lf[32]=C_h_intern(&lf[32],15,"char-set-delete");
lf[33]=C_h_intern(&lf[33],16,"char-set-delete!");
lf[34]=C_h_intern(&lf[34],15,"char-set-cursor");
lf[36]=C_h_intern(&lf[36],16,"end-of-char-set\077");
lf[37]=C_h_intern(&lf[37],12,"char-set-ref");
lf[38]=C_h_intern(&lf[38],20,"char-set-cursor-next");
lf[39]=C_h_intern(&lf[39],17,"char-set-for-each");
lf[40]=C_h_intern(&lf[40],12,"char-set-map");
lf[41]=C_h_intern(&lf[41],13,"char-set-fold");
lf[42]=C_h_intern(&lf[42],14,"char-set-every");
lf[43]=C_h_intern(&lf[43],12,"char-set-any");
lf[45]=C_h_intern(&lf[45],15,"char-set-unfold");
lf[46]=C_h_intern(&lf[46],16,"char-set-unfold!");
lf[48]=C_h_intern(&lf[48],14,"list->char-set");
lf[49]=C_h_intern(&lf[49],15,"list->char-set!");
lf[50]=C_h_intern(&lf[50],14,"char-set->list");
lf[52]=C_h_intern(&lf[52],16,"string->char-set");
lf[53]=C_h_intern(&lf[53],17,"string->char-set!");
lf[54]=C_h_intern(&lf[54],16,"char-set->string");
lf[56]=C_h_intern(&lf[56],3,"min");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000`Requested UCS range contains unavailable characters -- this implementation "
"only supports Latin-1");
lf[58]=C_h_intern(&lf[58],19,"ucs-range->char-set");
lf[59]=C_h_intern(&lf[59],20,"ucs-range->char-set!");
lf[61]=C_h_intern(&lf[61],15,"char-set-filter");
lf[62]=C_h_intern(&lf[62],16,"char-set-filter!");
lf[63]=C_h_intern(&lf[63],10,"->char-set");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\036Not a charset, string or char.");
lf[67]=C_h_intern(&lf[67],19,"char-set-complement");
lf[68]=C_h_intern(&lf[68],20,"char-set-complement!");
lf[69]=C_h_intern(&lf[69],15,"char-set-union!");
lf[70]=C_h_intern(&lf[70],14,"char-set-union");
lf[71]=C_h_intern(&lf[71],14,"char-set:empty");
lf[72]=C_h_intern(&lf[72],22,"char-set-intersection!");
lf[73]=C_h_intern(&lf[73],21,"char-set-intersection");
lf[74]=C_h_intern(&lf[74],13,"char-set:full");
lf[75]=C_h_intern(&lf[75],20,"char-set-difference!");
lf[76]=C_h_intern(&lf[76],19,"char-set-difference");
lf[77]=C_h_intern(&lf[77],13,"char-set-xor!");
lf[78]=C_h_intern(&lf[78],12,"char-set-xor");
lf[80]=C_h_intern(&lf[80],27,"char-set-diff+intersection!");
lf[81]=C_h_intern(&lf[81],26,"char-set-diff+intersection");
lf[82]=C_h_intern(&lf[82],11,"string-copy");
lf[83]=C_h_intern(&lf[83],19,"char-set:lower-case");
lf[84]=C_h_intern(&lf[84],19,"char-set:upper-case");
lf[85]=C_h_intern(&lf[85],19,"char-set:title-case");
lf[86]=C_h_intern(&lf[86],15,"char-set:letter");
lf[87]=C_h_intern(&lf[87],14,"char-set:digit");
lf[88]=C_h_intern(&lf[88],18,"char-set:hex-digit");
lf[89]=C_h_intern(&lf[89],21,"char-set:letter+digit");
lf[90]=C_h_intern(&lf[90],20,"char-set:punctuation");
lf[91]=C_h_intern(&lf[91],15,"char-set:symbol");
lf[92]=C_h_intern(&lf[92],16,"char-set:graphic");
lf[93]=C_h_intern(&lf[93],19,"char-set:whitespace");
lf[94]=C_h_intern(&lf[94],17,"char-set:printing");
lf[95]=C_h_intern(&lf[95],14,"char-set:blank");
lf[96]=C_h_intern(&lf[96],20,"char-set:iso-control");
lf[97]=C_h_intern(&lf[97],14,"char-set:ascii");
lf[98]=C_h_intern(&lf[98],7,"\003sysmap");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001\000\000\000\240\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000\012\376\003\000\000\002\376\377\001\000\000\000\013\376\003\000\000\002\376\377\001\000\000\000\014\376\003\000\000\002\376\377\001\000\000\000\015\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001"
"\000\000\000\240\376\377\016");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\242\376\003\000\000\002\376\377\001\000\000\000\243\376\003\000\000\002\376\377\001\000\000\000\244\376\003\000\000\002\376\377\001\000\000\000\245\376\003\000\000\002\376\377\001\000\000\000\246\376\003\000\000\002\376\377\001\000\000\000\247\376\003\000\000\002\376\377\001"
"\000\000\000\250\376\003\000\000\002\376\377\001\000\000\000\251\376\003\000\000\002\376\377\001\000\000\000\254\376\003\000\000\002\376\377\001\000\000\000\256\376\003\000\000\002\376\377\001\000\000\000\257\376\003\000\000\002\376\377\001\000\000\000\260\376\003\000\000\002\376\377\001\000\000\000\261\376\003\000\000"
"\002\376\377\001\000\000\000\264\376\003\000\000\002\376\377\001\000\000\000\266\376\003\000\000\002\376\377\001\000\000\000\270\376\003\000\000\002\376\377\001\000\000\000\327\376\003\000\000\002\376\377\001\000\000\000\367\376\377\016");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\011$+<=>^`|~");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\241\376\003\000\000\002\376\377\001\000\000\000\253\376\003\000\000\002\376\377\001\000\000\000\255\376\003\000\000\002\376\377\001\000\000\000\267\376\003\000\000\002\376\377\001\000\000\000\273\376\003\000\000\002\376\377\001\000\000\000\277\376\377\016");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\027!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\0260123456789abcdefABCDEF");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\0120123456789");
lf[107]=C_h_intern(&lf[107],17,"register-feature!");
lf[108]=C_h_intern(&lf[108],7,"srfi-14");
C_register_lf2(lf,109,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_629,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 43   register-feature! */
t4=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[108]);}

/* k627 */
static void C_ccall f_629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_629,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_631,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_637,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_643,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_649,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_655,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_661,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_671,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_718,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 169  %latin1->char */
t11=lf[2];
f_631(3,t11,t10,C_fix(0));}

/* k743 in k627 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_745,2,t0,t1);}
t2=C_mutate(&lf[17],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 170  %latin1->char */
t4=lf[2];
f_631(3,t4,t3,C_fix(1));}

/* k747 in k743 in k627 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word ab[117],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_749,2,t0,t1);}
t2=C_mutate(&lf[18],t1);
t3=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_751,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_765,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_820,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_918,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1019,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1046,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1083,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[27],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1140,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[29],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1166,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1185,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1197,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1209,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1221,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1233,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1239,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1245,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1251,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[35],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1260,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1302,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1352,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1415,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1462,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1511,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate(&lf[44],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1564,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1600,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1612,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate(&lf[47],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1622,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1637,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1649,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1661,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1671,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[51],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1718,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1761,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1773,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1783,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate(&lf[55],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1839,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1896,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1926,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate(&lf[60],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1936,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1989,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2005,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2019,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[65],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2049,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate(&lf[66],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2090,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2132,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2160,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2182,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2208,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2257,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2279,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2324,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2350,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2391,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2432,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate(&lf[79],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2496,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2549,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2600,tmp=(C_word)a,a+=2,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 658  char-set */
t61=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t61+1)))(2,t61,t60);}

/* k2627 in k747 in k743 in k627 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2629,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 659  char-set-complement */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[71]+1));}

/* k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2633,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 662  ucs-range->char-set */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(97),C_fix(123));}

/* k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 663  ucs-range->char-set! */
t3=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 664  ucs-range->char-set! */
t3=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2745,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 665  %latin1->char */
t4=lf[2];
f_631(3,t4,t3,C_fix(181));}

/* k2743 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 665  char-set-adjoin! */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 668  ucs-range->char-set */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(65),C_fix(91));}

/* k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 671  ucs-range->char-set! */
t4=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k2739 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 670  ucs-range->char-set! */
t2=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=C_mutate((C_word*)lf[85]+1,*((C_word*)lf[71]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 676  char-set-union */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[84]+1),*((C_word*)lf[83]+1));}

/* k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 678  %latin1->char */
t4=lf[2];
f_631(3,t4,t3,C_fix(170));}

/* k2731 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2737,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 679  %latin1->char */
t3=lf[2];
f_631(3,t3,t2,C_fix(186));}

/* k2735 in k2731 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 677  char-set-adjoin! */
t2=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 681  string->char-set */
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[106]);}

/* k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 682  string->char-set */
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[105]);}

/* k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 685  char-set-union */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[86]+1),*((C_word*)lf[87]+1));}

/* k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 688  string->char-set */
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[104]);}

/* k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2680,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[2],lf[103]);}

/* k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 695  list->char-set! */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 698  string->char-set */
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[102]);}

/* k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2690,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[2],lf[101]);}

/* k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 717  list->char-set! */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 721  char-set-union */
t4=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[89]+1),*((C_word*)lf[90]+1),*((C_word*)lf[91]+1));}

/* k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2729,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[2],lf[100]);}

/* k2727 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 724  list->char-set */
t2=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2699 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2701,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 732  char-set-union */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[93]+1),*((C_word*)lf[92]+1));}

/* k2703 in k2699 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2705,2,t0,t1);}
t2=C_mutate((C_word*)lf[94]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2725,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[2],lf[99]);}

/* k2723 in k2703 in k2699 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 735  list->char-set */
t2=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2707 in k2703 in k2699 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 741  ucs-range->char-set */
t5=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(0),C_fix(32));}

/* k2719 in k2707 in k2703 in k2699 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 741  ucs-range->char-set! */
t2=*((C_word*)lf[59]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k2711 in k2707 in k2703 in k2699 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 743  ucs-range->char-set */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),C_fix(128));}

/* k2715 in k2711 in k2707 in k2703 in k2699 in k2695 in k2691 in k2688 in k2685 in k2681 in k2678 in k2675 in k2671 in k2667 in k2663 in k2659 in k2656 in k2651 in k2648 in k2644 in k2641 in k2638 in k2635 in k2631 in k2627 in k747 in k743 in k627 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[97]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k747 in k743 in k627 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2600r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2600r(t0,t1,t2,t3);}}

static void C_ccall f_2600r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2604,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2625,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 644  %char-set:s/check */
f_718(t5,t2,lf[81]);}

/* k2623 in char-set-diff+intersection in k747 in k743 in k627 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 644  string-copy */
t2=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2602 in char-set-diff+intersection in k747 in k743 in k627 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 645  make-string */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[17]);}

/* k2605 in k2602 in char-set-diff+intersection in k747 in k743 in k627 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 646  %char-set-diff+intersection! */
f_2496(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[81]);}

/* k2608 in k2605 in k2602 in char-set-diff+intersection in k747 in k743 in k627 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 647  make-char-set */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2615 in k2608 in k2605 in k2602 in char-set-diff+intersection in k747 in k743 in k627 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2621,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 647  make-char-set */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2619 in k2615 in k2608 in k2605 in k2602 in char-set-diff+intersection in k747 in k743 in k627 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 647  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2549r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2549r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2549r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2553,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 634  %char-set:s/check */
f_718(t5,t2,lf[80]);}

/* k2551 in char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 635  %char-set:s/check */
f_718(t2,((C_word*)t0)[3],lf[80]);}

/* k2554 in k2551 in char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 636  %string-iter */
f_2049(t2,t3,((C_word*)t0)[3]);}

/* a2566 in k2554 in k2551 in char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2567,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_setsubchar(((C_word*)t0)[3],t5,lf[17]));}
else{
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=f_637(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=t2;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_setsubchar(((C_word*)t0)[2],t9,lf[17]));}}}

/* k2557 in k2554 in k2551 in char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 640  %char-set-diff+intersection! */
f_2496(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[80]);}

/* k2560 in k2557 in k2554 in k2551 in char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 641  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k747 in k743 in k627 */
static void C_fcall f_2496(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2496,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2502,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t4);}

/* a2501 in %char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2502,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2547,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 630  %char-set:s/check */
f_718(t4,t2,((C_word*)t0)[2]);}

/* k2545 in a2501 in %char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 625  %string-iter */
f_2049(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2507 in a2501 in %char-set-diff+intersection! in k747 in k743 in k627 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2508,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_subchar(t5,t6);
t8=f_637(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_setsubchar(t10,t11,lf[17]);
t13=((C_word*)t0)[2];
t14=t2;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_setsubchar(t13,t14,lf[18]));}}}

/* char-set-xor in k747 in k743 in k627 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2432r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2432r(t0,t1,t2);}}

static void C_ccall f_2432r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2442,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2487,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 615  %char-set:s/check */
f_718(t4,t5,lf[78]);}
else{
/* srfi-14.scm: 618  char-set-copy */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[71]+1));}}

/* k2485 in char-set-xor in k747 in k743 in k627 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 615  %string-copy */
f_661(((C_word*)t0)[2],t1);}

/* k2440 in char-set-xor in k747 in k743 in k627 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2445,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2454,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 616  %char-set-algebra */
f_2090(t2,t1,t3,t4,lf[78]);}

/* a2453 in k2440 in char-set-xor in k747 in k743 in k627 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2454,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_subchar(t8,t9);
t11=f_637(t10);
t12=(C_word)C_u_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2471,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* %latin1->char */
t14=lf[2];
f_631(3,t14,t13,t12);}}

/* k2469 in a2453 in k2440 in char-set-xor in k747 in k743 in k627 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2443 in k2440 in char-set-xor in k747 in k743 in k627 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 617  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k747 in k743 in k627 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2391r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2391r(t0,t1,t2,t3);}}

static void C_ccall f_2391r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 609  %char-set:s/check */
f_718(t5,t2,lf[77]);}

/* k2397 in char-set-xor! in k747 in k743 in k627 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2401,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 609  %char-set-algebra */
f_2090(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[77]);}

/* a2400 in k2397 in char-set-xor! in k747 in k743 in k627 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2401,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_subchar(t8,t9);
t11=f_637(t10);
t12=(C_word)C_u_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2418,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* %latin1->char */
t14=lf[2];
f_631(3,t14,t13,t12);}}

/* k2416 in a2400 in k2397 in char-set-xor! in k747 in k743 in k627 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2393 in char-set-xor! in k747 in k743 in k627 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k747 in k743 in k627 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2350r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2350r(t0,t1,t2,t3);}}

static void C_ccall f_2350r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 600  %char-set:s/check */
f_718(t5,t2,lf[76]);}
else{
/* srfi-14.scm: 603  char-set-copy */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k2384 in char-set-difference in k747 in k743 in k627 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 600  %string-copy */
f_661(((C_word*)t0)[2],t1);}

/* k2358 in char-set-difference in k747 in k743 in k627 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2363,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2368,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 601  %char-set-algebra */
f_2090(t2,t1,((C_word*)t0)[2],t3,lf[76]);}

/* a2367 in k2358 in char-set-difference in k747 in k743 in k627 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2368,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[17])));}

/* k2361 in k2358 in char-set-difference in k747 in k743 in k627 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 602  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k747 in k743 in k627 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2324r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2324r(t0,t1,t2,t3);}}

static void C_ccall f_2324r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2328,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2332,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 594  %char-set:s/check */
f_718(t5,t2,lf[75]);}

/* k2330 in char-set-difference! in k747 in k743 in k627 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2334,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 594  %char-set-algebra */
f_2090(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[75]);}

/* a2333 in k2330 in char-set-difference! in k747 in k743 in k627 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2334,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[17])));}

/* k2326 in char-set-difference! in k747 in k743 in k627 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k747 in k743 in k627 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2279r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2279r(t0,t1,t2);}}

static void C_ccall f_2279r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2289,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 585  %char-set:s/check */
f_718(t4,t5,lf[73]);}
else{
/* srfi-14.scm: 588  char-set-copy */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[74]+1));}}

/* k2313 in char-set-intersection in k747 in k743 in k627 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 585  %string-copy */
f_661(((C_word*)t0)[2],t1);}

/* k2287 in char-set-intersection in k747 in k743 in k627 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2301,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 586  %char-set-algebra */
f_2090(t2,t1,t3,t4,lf[73]);}

/* a2300 in k2287 in char-set-intersection in k747 in k743 in k627 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2301,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_setsubchar(t2,t3,lf[17]):C_SCHEME_UNDEFINED));}

/* k2290 in k2287 in char-set-intersection in k747 in k743 in k627 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 587  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k747 in k743 in k627 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2257r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2257r(t0,t1,t2,t3);}}

static void C_ccall f_2257r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2261,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2265,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 579  %char-set:s/check */
f_718(t5,t2,lf[72]);}

/* k2263 in char-set-intersection! in k747 in k743 in k627 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2267,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 579  %char-set-algebra */
f_2090(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[72]);}

/* a2266 in k2263 in char-set-intersection! in k747 in k743 in k627 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2267,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_setsubchar(t2,t3,lf[17]):C_SCHEME_UNDEFINED));}

/* k2259 in char-set-intersection! in k747 in k743 in k627 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k747 in k743 in k627 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2208r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2208r(t0,t1,t2);}}

static void C_ccall f_2208r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2218,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2248,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 570  %char-set:s/check */
f_718(t4,t5,lf[70]);}
else{
/* srfi-14.scm: 573  char-set-copy */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[71]+1));}}

/* k2246 in char-set-union in k747 in k743 in k627 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 570  %string-copy */
f_661(((C_word*)t0)[2],t1);}

/* k2216 in char-set-union in k747 in k743 in k627 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2230,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 571  %char-set-algebra */
f_2090(t2,t1,t3,t4,lf[70]);}

/* a2229 in k2216 in char-set-union in k747 in k743 in k627 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2230,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[18])));}

/* k2219 in k2216 in char-set-union in k747 in k743 in k627 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 572  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k747 in k743 in k627 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2182r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2182r(t0,t1,t2,t3);}}

static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2186,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2190,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 564  %char-set:s/check */
f_718(t5,t2,lf[69]);}

/* k2188 in char-set-union! in k747 in k743 in k627 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2192,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 564  %char-set-algebra */
f_2090(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[69]);}

/* a2191 in k2188 in char-set-union! in k747 in k743 in k627 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2192,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[18])));}

/* k2184 in char-set-union! in k747 in k743 in k627 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k747 in k743 in k627 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2160,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2164,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 556  %char-set:s/check */
f_718(t3,t2,lf[68]);}

/* k2162 in char-set-complement! in k747 in k743 in k627 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2169,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 557  %string-iter */
f_2049(t2,t3,t1);}

/* a2168 in k2162 in char-set-complement! in k747 in k743 in k627 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2169,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2180,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* %latin1->char */
t6=lf[2];
f_631(3,t6,t5,t4);}

/* k2178 in a2168 in k2162 in char-set-complement! in k747 in k743 in k627 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2165 in k2162 in char-set-complement! in k747 in k743 in k627 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k747 in k743 in k627 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2132,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 550  %char-set:s/check */
f_718(t3,t2,lf[67]);}

/* k2134 in char-set-complement in k747 in k743 in k627 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 551  make-string */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2137 in k2134 in char-set-complement in k747 in k743 in k627 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 552  %string-iter */
f_2049(t2,t3,((C_word*)t0)[2]);}

/* a2146 in k2137 in k2134 in char-set-complement in k747 in k743 in k627 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2147,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2158,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* %latin1->char */
t6=lf[2];
f_631(3,t6,t5,t4);}

/* k2156 in a2146 in k2137 in k2134 in char-set-complement in k747 in k743 in k627 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2140 in k2137 in k2134 in char-set-complement in k747 in k743 in k627 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 553  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k747 in k743 in k627 */
static void C_fcall f_2090(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2090,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=t5,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t3);}

/* a2095 in %char-set-algebra in k747 in k743 in k627 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2100,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 539  %char-set:s/check */
f_718(t3,t2,((C_word*)t0)[2]);}

/* k2098 in a2095 in %char-set-algebra in k747 in k743 in k627 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2100,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2105(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2098 in a2095 in %char-set-algebra in k747 in k743 in k627 */
static void C_fcall f_2105(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2105,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2115,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=f_637(t6);
/* srfi-14.scm: 542  op */
t8=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t4,((C_word*)t0)[2],t2,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2113 in lp in k2098 in a2095 in %char-set-algebra in k747 in k743 in k627 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 543  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2105(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k747 in k743 in k627 */
static void C_fcall f_2049(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2049,NULL,3,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2059,a[2]=t2,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2059(t9,t1,t5);}

/* lp in %string-iter in k747 in k743 in k627 */
static void C_fcall f_2059(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2059,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
t6=f_637(t5);
/* srfi-14.scm: 528  p */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t2,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2067 in lp in %string-iter in k747 in k743 in k627 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 529  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2059(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k747 in k743 in k627 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2019,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 505  char-set? */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2024 in ->char-set in k747 in k743 in k627 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* srfi-14.scm: 506  string->char-set */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-14.scm: 507  char-set */
t2=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-14.scm: 508  ##sys#error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[63],lf[64],((C_word*)t0)[2]);}}}}

/* char-set-filter! in k747 in k743 in k627 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2005,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2009,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2013,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 496  %char-set:s/check */
f_718(t6,t3,lf[62]);}

/* k2011 in char-set-filter! in k747 in k743 in k627 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2017,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 497  %char-set:s/check */
f_718(t2,((C_word*)t0)[2],lf[62]);}

/* k2015 in k2011 in char-set-filter! in k747 in k743 in k627 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 495  %char-set-filter! */
f_1936(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2007 in char-set-filter! in k747 in k743 in k627 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k747 in k743 in k627 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1989r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1989r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1989r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 487  %default-base */
f_671(t5,t4,*((C_word*)lf[61]+1));}

/* k1991 in char-set-filter in k747 in k743 in k627 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1996,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2003,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 489  %char-set:s/check */
f_718(t3,((C_word*)t0)[2],lf[62]);}

/* k2001 in k1991 in char-set-filter in k747 in k743 in k627 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 488  %char-set-filter! */
f_1936(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1994 in k1991 in char-set-filter in k747 in k743 in k627 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 492  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k747 in k743 in k627 */
static void C_fcall f_1936(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1936,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1942,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1942(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k747 in k743 in k627 */
static void C_fcall f_1942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1942,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1952,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1962,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=t2;
t8=(C_word)C_subchar(t6,t7);
t9=f_637(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t5;
f_1962(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1975,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 482  %latin1->char */
t12=lf[2];
f_631(3,t12,t11,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1973 in lp in %char-set-filter! in k747 in k743 in k627 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 482  pred */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1960 in lp in %char-set-filter! in k747 in k743 in k627 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_1952(t4,(C_word)C_setsubchar(t2,t3,lf[18]));}
else{
t2=((C_word*)t0)[2];
f_1952(t2,C_SCHEME_UNDEFINED);}}

/* k1950 in lp in %char-set-filter! in k747 in k743 in k627 */
static void C_fcall f_1952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 484  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1942(t3,((C_word*)t0)[2],t2);}

/* ucs-range->char-set! in k747 in k743 in k627 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1926,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1930,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1934,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 471  %char-set:s/check */
f_718(t7,t5,lf[59]);}

/* k1932 in ucs-range->char-set! in k747 in k743 in k627 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 470  %ucs-range->char-set! */
f_1839(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[58]);}

/* k1928 in ucs-range->char-set! in k747 in k743 in k627 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k747 in k743 in k627 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1896r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1896r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1896r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_u_i_car(t4));
t7=(C_word)C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1906,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 465  %default-base */
f_671(t9,t8,*((C_word*)lf[58]+1));}

/* k1904 in ucs-range->char-set in k747 in k743 in k627 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 466  %ucs-range->char-set! */
f_1839(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[58]);}

/* k1907 in k1904 in ucs-range->char-set in k747 in k743 in k627 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 467  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k747 in k743 in k627 */
static void C_fcall f_1839(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1839,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_exact_2(t2,t6);
t8=(C_word)C_i_check_exact_2(t3,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1849,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1882,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=t3;
if(C_truep((C_word)C_fixnum_lessp(t11,t12))){
t13=t3;
t14=(C_word)C_fixnum_lessp(C_fix(256),t13);
t15=t10;
f_1882(t15,(C_truep(t14)?t4:C_SCHEME_FALSE));}
else{
t13=t10;
f_1882(t13,C_SCHEME_FALSE);}}

/* k1880 in %ucs-range->char-set! in k747 in k743 in k627 */
static void C_fcall f_1882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-14.scm: 457  ##sys#error */
t2=*((C_word*)lf[11]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[57],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1849(2,t2,C_SCHEME_UNDEFINED);}}

/* k1847 in %ucs-range->char-set! in k747 in k743 in k627 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 460  min */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(256));}

/* k1877 in k1847 in %ucs-range->char-set! in k747 in k743 in k627 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1858(t3,t2));}

/* lp in k1877 in k1847 in %ucs-range->char-set! in k747 in k743 in k627 */
static C_word C_fcall f_1858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=((C_word*)t0)[3];
t3=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_setsubchar(t4,t5,lf[18]);
t7=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* char-set->string in k747 in k743 in k627 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1787,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 438  %char-set:s/check */
f_718(t3,t2,lf[54]);}

/* k1785 in char-set->string in k747 in k743 in k627 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 439  char-set-size */
t4=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1835 in k1785 in char-set->string in k747 in k743 in k627 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 439  make-string */
t2=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1788 in k1785 in char-set->string in k747 in k743 in k627 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1795(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1788 in k1785 in char-set->string in k747 in k743 in k627 */
static void C_fcall f_1795(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1795,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1805,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t2;
t7=(C_word)C_subchar(((C_word*)t0)[2],t6);
t8=f_637(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t5;
f_1805(t10,t3);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1825,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 443  %latin1->char */
t11=lf[2];
f_631(3,t11,t10,t2);}}}

/* k1823 in lp in k1788 in k1785 in char-set->string in k747 in k743 in k627 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_1805(t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1)));}

/* k1803 in lp in k1788 in k1785 in char-set->string in k747 in k743 in k627 */
static void C_fcall f_1805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 445  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1795(t3,((C_word*)t0)[2],t2,t1);}

/* string->char-set! in k747 in k743 in k627 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1773,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1777,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1781,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 432  %char-set:s/check */
f_718(t5,t3,lf[53]);}

/* k1779 in string->char-set! in k747 in k743 in k627 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 432  %string->char-set! */
f_1718(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[53]);}

/* k1775 in string->char-set! in k747 in k743 in k627 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k747 in k743 in k627 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1761r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1761r(t0,t1,t2,t3);}}

static void C_ccall f_1761r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1765,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 427  %default-base */
f_671(t4,t3,*((C_word*)lf[52]+1));}

/* k1763 in string->char-set in k747 in k743 in k627 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1768,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 428  %string->char-set! */
f_1718(t2,((C_word*)t0)[2],t1,lf[52]);}

/* k1766 in k1763 in string->char-set in k747 in k743 in k627 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 429  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k747 in k743 in k627 */
static void C_fcall f_1718(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1718,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=(C_word)C_u_fixnum_difference(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1731,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,f_1731(t8,t7));}

/* do298 in %string->char-set! in k747 in k743 in k627 */
static C_word C_fcall f_1731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[3];
t4=(C_word)C_subchar(((C_word*)t0)[2],t1);
t5=f_637(t4);
t6=(C_word)C_setsubchar(t3,t5,lf[18]);
t7=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}}

/* char-set->list in k747 in k743 in k627 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1671,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 408  %char-set:s/check */
f_718(t3,t2,lf[50]);}

/* k1673 in char-set->list in k747 in k743 in k627 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1680,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1680(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k1673 in char-set->list in k747 in k743 in k627 */
static void C_fcall f_1680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1680,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1698,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[2],t7);
t9=f_637(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1698(t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1708,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 413  %latin1->char */
t12=lf[2];
f_631(3,t12,t11,t2);}}}

/* k1706 in lp in k1673 in char-set->list in k747 in k743 in k627 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1698(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1696 in lp in k1673 in char-set->list in k747 in k743 in k627 */
static void C_fcall f_1698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 411  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1680(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* list->char-set! in k747 in k743 in k627 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1661,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1669,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 403  %char-set:s/check */
f_718(t5,t3,lf[49]);}

/* k1667 in list->char-set! in k747 in k743 in k627 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 403  %list->char-set! */
f_1622(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1663 in list->char-set! in k747 in k743 in k627 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k747 in k743 in k627 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1649r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1649r(t0,t1,t2,t3);}}

static void C_ccall f_1649r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1653,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 398  %default-base */
f_671(t4,t3,*((C_word*)lf[48]+1));}

/* k1651 in list->char-set in k747 in k743 in k627 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1656,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 399  %list->char-set! */
f_1622(t2,((C_word*)t0)[2],t1);}

/* k1654 in k1651 in list->char-set in k747 in k743 in k627 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 400  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k747 in k743 in k627 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1637r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1637r(t0,t1,t2);}}

static void C_ccall f_1637r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1641,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 393  make-string */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(256),lf[17]);}

/* k1639 in char-set in k747 in k743 in k627 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 394  %list->char-set! */
f_1622(t2,((C_word*)t0)[2],t1);}

/* k1642 in k1639 in char-set in k747 in k743 in k627 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 395  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k747 in k743 in k627 */
static void C_fcall f_1622(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1622,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1628,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1627 in %list->char-set! in k747 in k743 in k627 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1628,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
t4=f_637(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_setsubchar(t3,t4,lf[18]));}

/* char-set-unfold! in k747 in k743 in k627 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1612,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1616,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1620,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 380  %char-set:s/check */
f_718(t8,t6,lf[46]);}

/* k1618 in char-set-unfold! in k747 in k743 in k627 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 379  %char-set-unfold! */
f_1564(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1614 in char-set-unfold! in k747 in k743 in k627 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k747 in k743 in k627 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_1600r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_1600r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_1600r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1604,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 374  %default-base */
f_671(t7,t6,*((C_word*)lf[45]+1));}

/* k1602 in char-set-unfold in k747 in k743 in k627 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1607,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 375  %char-set-unfold! */
f_1564(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1605 in k1602 in char-set-unfold in k747 in k743 in k627 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 376  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k747 in k743 in k627 */
static void C_fcall f_1564(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1564,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1570,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1570(t10,t1,t6);}

/* lp in %char-set-unfold! in k747 in k743 in k627 */
static void C_fcall f_1570(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1570,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-14.scm: 369  p */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1596 in lp in %char-set-unfold! in k747 in k743 in k627 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 370  f */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k1592 in k1596 in lp in %char-set-unfold! in k747 in k743 in k627 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=f_637(t1);
t3=(C_word)C_setsubchar(((C_word*)t0)[6],t2,lf[18]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 371  g */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1588 in k1592 in k1596 in lp in %char-set-unfold! in k747 in k743 in k627 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 371  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1570(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k747 in k743 in k627 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1511,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 357  %char-set:s/check */
f_718(t4,t3,lf[43]);}

/* k1513 in char-set-any in k747 in k743 in k627 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1520(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1513 in char-set-any in k747 in k743 in k627 */
static void C_fcall f_1520(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1520,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=f_637(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1530(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 360  %latin1->char */
t10=lf[2];
f_631(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1548 in lp in k1513 in char-set-any in k747 in k743 in k627 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 360  pred */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1528 in lp in k1513 in char-set-any in k747 in k743 in k627 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-14.scm: 361  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1520(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k747 in k743 in k627 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1462,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1466,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 349  %char-set:s/check */
f_718(t4,t3,lf[42]);}

/* k1464 in char-set-every in k747 in k743 in k627 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1466,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1471(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1464 in char-set-every in k747 in k743 in k627 */
static void C_fcall f_1471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1471,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=f_637(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1487,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_1487(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1501,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 352  %latin1->char */
t11=lf[2];
f_631(3,t11,t10,t2);}}}

/* k1499 in lp in k1464 in char-set-every in k747 in k743 in k627 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 352  pred */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1485 in lp in k1464 in char-set-every in k747 in k743 in k627 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 353  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1471(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k747 in k743 in k627 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1415,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1419,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 340  %char-set:s/check */
f_718(t5,t4,lf[41]);}

/* k1417 in char-set-fold in k747 in k743 in k627 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1424(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k1417 in char-set-fold in k747 in k743 in k627 */
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1424,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1442,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=f_637(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1442(2,t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1452,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 345  %latin1->char */
t12=lf[2];
f_631(3,t12,t11,t2);}}}

/* k1450 in lp in k1417 in char-set-fold in k747 in k743 in k627 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 345  kons */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1440 in lp in k1417 in char-set-fold in k747 in k743 in k627 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 343  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1424(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k747 in k743 in k627 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1352,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1356,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 329  %char-set:s/check */
f_718(t4,t3,lf[40]);}

/* k1354 in char-set-map in k747 in k743 in k627 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 330  make-string */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[17]);}

/* k1357 in k1354 in char-set-map in k747 in k743 in k627 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1362,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1367(t6,t2,C_fix(255));}

/* lp in k1357 in k1354 in char-set-map in k747 in k743 in k627 */
static void C_fcall f_1367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1367,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1377,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=f_637(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1377(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1401,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 334  %latin1->char */
t11=lf[2];
f_631(3,t11,t10,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1399 in lp in k1357 in k1354 in char-set-map in k747 in k743 in k627 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 334  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1395 in lp in k1357 in k1354 in char-set-map in k747 in k743 in k627 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_637(t1);
t3=((C_word*)t0)[3];
f_1377(t3,(C_word)C_setsubchar(((C_word*)t0)[2],t2,lf[18]));}

/* k1375 in lp in k1357 in k1354 in char-set-map in k747 in k743 in k627 */
static void C_fcall f_1377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 335  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1367(t3,((C_word*)t0)[2],t2);}

/* k1360 in k1357 in k1354 in char-set-map in k747 in k743 in k627 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 336  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k747 in k743 in k627 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1302,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1306,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 321  %char-set:s/check */
f_718(t4,t3,lf[39]);}

/* k1304 in char-set-for-each in k747 in k743 in k627 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1311(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1304 in char-set-for-each in k747 in k743 in k627 */
static void C_fcall f_1311(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1311,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1321,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=f_637(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1321(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1338,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 324  %latin1->char */
t10=lf[2];
f_631(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1336 in lp in k1304 in char-set-for-each in k747 in k743 in k627 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 324  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1319 in lp in k1304 in char-set-for-each in k747 in k743 in k627 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 325  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1311(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k747 in k743 in k627 */
static void C_fcall f_1260(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1260,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1264,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 310  %char-set:s/check */
f_718(t5,t2,t4);}

/* k1262 in %char-set-cursor-next in k747 in k743 in k627 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1264,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1269,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1269(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1262 in %char-set-cursor-next in k747 in k743 in k627 */
static void C_fcall f_1269(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1269,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_1282(t6,t4);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[2],t3);
t7=f_637(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=t5;
f_1282(t9,(C_word)C_i_not(t8));}}

/* k1280 in lp in k1262 in %char-set-cursor-next in k747 in k743 in k627 */
static void C_fcall f_1282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 314  lp */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1269(t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* char-set-cursor-next in k747 in k743 in k627 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1251,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[38]);
/* srfi-14.scm: 307  %char-set-cursor-next */
f_1260(t1,t2,t3,lf[38]);}

/* char-set-ref in k747 in k743 in k627 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1245,4,t0,t1,t2,t3);}
/* srfi-14.scm: 301  %latin1->char */
t4=lf[2];
f_631(3,t4,t1,t3);}

/* end-of-char-set? in k747 in k743 in k627 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1239,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k747 in k743 in k627 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1233,3,t0,t1,t2);}
/* srfi-14.scm: 297  %char-set-cursor-next */
f_1260(t1,t2,C_fix(256),lf[34]);}

/* char-set-delete! in k747 in k743 in k627 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1221r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1221r(t0,t1,t2,t3);}}

static void C_ccall f_1221r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1227,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 283  %set-char-set! */
f_1166(t1,t4,lf[33],t2,t3);}

/* a1226 in char-set-delete! in k747 in k743 in k627 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1227,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[17]));}

/* char-set-delete in k747 in k743 in k627 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1209r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1209r(t0,t1,t2,t3);}}

static void C_ccall f_1209r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1215,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 281  %set-char-set */
f_1140(t1,t4,lf[32],t2,t3);}

/* a1214 in char-set-delete in k747 in k743 in k627 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1215,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[17]));}

/* char-set-adjoin! in k747 in k743 in k627 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1197r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1197r(t0,t1,t2,t3);}}

static void C_ccall f_1197r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1203,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 279  %set-char-set! */
f_1166(t1,t4,lf[31],t2,t3);}

/* a1202 in char-set-adjoin! in k747 in k743 in k627 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1203,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[18]));}

/* char-set-adjoin in k747 in k743 in k627 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1185r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1185r(t0,t1,t2,t3);}}

static void C_ccall f_1185r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1191,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 277  %set-char-set */
f_1140(t1,t4,lf[30],t2,t3);}

/* a1190 in char-set-adjoin in k747 in k743 in k627 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1191,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[18]));}

/* %set-char-set! in k747 in k743 in k627 */
static void C_fcall f_1166(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1166,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1170,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 271  %char-set:s/check */
f_718(t6,t4,t3);}

/* k1168 in %set-char-set! in k747 in k743 in k627 */
static void C_ccall f_1170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1173,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1174 in k1168 in %set-char-set! in k747 in k743 in k627 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1175,3,t0,t1,t2);}
t3=f_637(t2);
/* srfi-14.scm: 272  set */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1171 in k1168 in %set-char-set! in k747 in k743 in k627 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k747 in k743 in k627 */
static void C_fcall f_1140(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1140,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1144,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1164,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 265  %char-set:s/check */
f_718(t7,t4,t3);}

/* k1162 in %set-char-set in k747 in k743 in k627 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 265  %string-copy */
f_661(((C_word*)t0)[2],t1);}

/* k1142 in %set-char-set in k747 in k743 in k627 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1147,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1152,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1151 in k1142 in %set-char-set in k747 in k743 in k627 */
static void C_ccall f_1152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1152,3,t0,t1,t2);}
t3=f_637(t2);
/* srfi-14.scm: 266  set */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1145 in k1142 in %set-char-set in k747 in k743 in k627 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 268  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k747 in k743 in k627 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1083,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1087,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 253  %char-set:s/check */
f_718(t4,t3,lf[26]);}

/* k1085 in char-set-count in k747 in k743 in k627 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1087,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1092(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1085 in char-set-count in k747 in k743 in k627 */
static void C_fcall f_1092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1092,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1113,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=f_637(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1113(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1126,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 257  %latin1->char */
t12=lf[2];
f_631(3,t12,t11,t2);}}}

/* k1124 in lp in k1085 in char-set-count in k747 in k743 in k627 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 257  pred */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1111 in lp in k1085 in char-set-count in k747 in k743 in k627 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
/* srfi-14.scm: 256  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1092(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-size in k747 in k743 in k627 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1050,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 246  %char-set:s/check */
f_718(t3,t2,lf[25]);}

/* k1048 in char-set-size in k747 in k743 in k627 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1055(t2,C_fix(255),C_fix(0)));}

/* lp in k1048 in char-set-size in k747 in k743 in k627 */
static C_word C_fcall f_1055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(t2);}
else{
t4=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t1;
t6=(C_word)C_subchar(((C_word*)t0)[2],t5);
t7=f_637(t6);
t8=(C_word)C_u_fixnum_plus(t2,t7);
t10=t4;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* char-set-contains? in k747 in k743 in k627 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1019,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_char_2(t3,lf[24]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1026,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 241  %char-set:s/check */
f_718(t5,t2,lf[24]);}

/* k1024 in char-set-contains? in k747 in k743 in k627 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=f_637(((C_word*)t0)[3]);
t3=(C_word)C_subchar(t1,t2);
t4=f_637(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_not(t5));}

/* char-set-hash in k747 in k743 in k627 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_918r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_918r(t0,t1,t2,t3);}}

static void C_ccall f_918r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_slot(t3,C_fix(0)));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_925,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t9)){
t10=C_set_block_item(t7,0,C_fix(4194304));
t11=t8;
f_925(t11,t10);}
else{
t10=t8;
f_925(t10,C_SCHEME_UNDEFINED);}}

/* k923 in char-set-hash in k747 in k743 in k627 */
static void C_fcall f_925(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_925,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[22]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 228  %char-set:s/check */
f_718(t3,((C_word*)t0)[2],lf[22]);}

/* k929 in k923 in char-set-hash in k747 in k743 in k627 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=f_984(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_939,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_939(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k929 in k923 in char-set-hash in k747 in k743 in k627 */
static void C_fcall f_939(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_939,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-14.scm: 233  modulo */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_960,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=f_637(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_960(t11,t3);}
else{
t11=(C_word)C_fixnum_times(C_fix(37),t3);
t12=(C_word)C_u_fixnum_plus(t11,t2);
t13=t6;
f_960(t13,(C_word)C_u_fixnum_and(((C_word*)t0)[2],t12));}}}

/* k958 in lp in k929 in k923 in char-set-hash in k747 in k743 in k627 */
static void C_fcall f_960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 234  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_939(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in k929 in k923 in char-set-hash in k747 in k743 in k627 */
static C_word C_fcall f_984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_u_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_u_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k747 in k743 in k627 */
static void C_ccall f_820(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_820r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_820r(t0,t1,t2);}}

static void C_ccall f_820r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_840,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 201  %char-set:s/check */
f_718(t6,t4,lf[21]);}}

/* k838 in char-set<= in k747 in k743 in k627 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_842,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_842(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k838 in char-set<= in k747 in k743 in k627 */
static void C_fcall f_842(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_842,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_852,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t3);
/* srfi-14.scm: 203  %char-set:s/check */
f_718(t6,t7,lf[21]);}}

/* k850 in lp in k838 in char-set<= in k747 in k743 in k627 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
/* srfi-14.scm: 205  lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_842(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_869,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_869(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k850 in lp in k838 in char-set<= in k747 in k743 in k627 */
static void C_fcall f_869(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_869,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* srfi-14.scm: 207  lp */
t4=((C_word*)((C_word*)t0)[6])[1];
f_842(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
t5=t2;
t6=(C_word)C_subchar(t4,t5);
t7=f_637(t6);
t8=t2;
t9=(C_word)C_subchar(((C_word*)t0)[5],t8);
t10=f_637(t9);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,t10))){
t11=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm: 209  lp2 */
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}}

/* char-set= in k747 in k743 in k627 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_765r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_765r(t0,t1,t2);}}

static void C_ccall f_765r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_781,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 190  %char-set:s/check */
f_718(t6,t4,lf[20]);}}

/* k779 in char-set= in k747 in k743 in k627 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_781,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_786,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_786(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k779 in char-set= in k747 in k743 in k627 */
static void C_fcall f_786(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_786,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 193  %char-set:s/check */
f_718(t5,t6,lf[20]);}}

/* k808 in lp in k779 in char-set= in k747 in k743 in k627 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_u_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 194  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_786(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k747 in k743 in k627 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_751,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_763,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 183  %char-set:s/check */
f_718(t4,t2,lf[19]);}

/* k761 in char-set-copy in k747 in k743 in k627 */
static void C_ccall f_763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 183  %string-copy */
f_661(((C_word*)t0)[2],t1);}

/* k757 in char-set-copy in k747 in k743 in k627 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 183  make-char-set */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k627 */
static void C_fcall f_718(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_718,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_724,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_724(t7,t1,t2);}

/* lp in %char-set:s/check in k627 */
static void C_fcall f_724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_724,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 154  char-set? */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k729 in lp in %char-set:s/check in k627 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_731,2,t0,t1);}
if(C_truep(t1)){
/* srfi-14.scm: 154  char-set:s */
t2=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 155  ##sys#error */
t3=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[16],((C_word*)t0)[4]);}}

/* k739 in k729 in lp in %char-set:s/check in k627 */
static void C_ccall f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 155  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_724(t2,((C_word*)t0)[2],t1);}

/* %default-base in k627 */
static void C_fcall f_671(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_671,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_696,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 142  char-set? */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
/* srfi-14.scm: 144  ##sys#error */
t6=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[13],t3,t2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_716,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 146  %latin1->char */
t5=lf[2];
f_631(3,t5,t4,C_fix(0));}}

/* k714 in %default-base in k627 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 146  make-string */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(256),t1);}

/* k694 in %default-base in k627 */
static void C_ccall f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_696,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_703,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 142  char-set:s */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 143  ##sys#error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[12],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k701 in k694 in %default-base in k627 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 142  %string-copy */
f_661(((C_word*)t0)[2],t1);}

/* %string-copy in k627 */
static void C_fcall f_661(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_661,NULL,2,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
/* substring */
t4=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_fix(0),t3);}

/* char-set? in k627 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_655,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[5]));}

/* char-set:s in k627 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_649,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-char-set in k627 */
static void C_ccall f_643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_643,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[5],t2));}

/* %char->latin1 in k627 */
static C_word C_fcall f_637(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_fix((C_word)C_character_code(t1)));}

/* %latin1->char in k627 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_631,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[274] = {
{"toplevelsrfi-14.scm",(void*)C_srfi_14_toplevel},
{"f_629srfi-14.scm",(void*)f_629},
{"f_745srfi-14.scm",(void*)f_745},
{"f_749srfi-14.scm",(void*)f_749},
{"f_2629srfi-14.scm",(void*)f_2629},
{"f_2633srfi-14.scm",(void*)f_2633},
{"f_2637srfi-14.scm",(void*)f_2637},
{"f_2640srfi-14.scm",(void*)f_2640},
{"f_2643srfi-14.scm",(void*)f_2643},
{"f_2745srfi-14.scm",(void*)f_2745},
{"f_2646srfi-14.scm",(void*)f_2646},
{"f_2650srfi-14.scm",(void*)f_2650},
{"f_2741srfi-14.scm",(void*)f_2741},
{"f_2653srfi-14.scm",(void*)f_2653},
{"f_2658srfi-14.scm",(void*)f_2658},
{"f_2733srfi-14.scm",(void*)f_2733},
{"f_2737srfi-14.scm",(void*)f_2737},
{"f_2661srfi-14.scm",(void*)f_2661},
{"f_2665srfi-14.scm",(void*)f_2665},
{"f_2669srfi-14.scm",(void*)f_2669},
{"f_2673srfi-14.scm",(void*)f_2673},
{"f_2677srfi-14.scm",(void*)f_2677},
{"f_2680srfi-14.scm",(void*)f_2680},
{"f_2683srfi-14.scm",(void*)f_2683},
{"f_2687srfi-14.scm",(void*)f_2687},
{"f_2690srfi-14.scm",(void*)f_2690},
{"f_2693srfi-14.scm",(void*)f_2693},
{"f_2697srfi-14.scm",(void*)f_2697},
{"f_2729srfi-14.scm",(void*)f_2729},
{"f_2701srfi-14.scm",(void*)f_2701},
{"f_2705srfi-14.scm",(void*)f_2705},
{"f_2725srfi-14.scm",(void*)f_2725},
{"f_2709srfi-14.scm",(void*)f_2709},
{"f_2721srfi-14.scm",(void*)f_2721},
{"f_2713srfi-14.scm",(void*)f_2713},
{"f_2717srfi-14.scm",(void*)f_2717},
{"f_2600srfi-14.scm",(void*)f_2600},
{"f_2625srfi-14.scm",(void*)f_2625},
{"f_2604srfi-14.scm",(void*)f_2604},
{"f_2607srfi-14.scm",(void*)f_2607},
{"f_2610srfi-14.scm",(void*)f_2610},
{"f_2617srfi-14.scm",(void*)f_2617},
{"f_2621srfi-14.scm",(void*)f_2621},
{"f_2549srfi-14.scm",(void*)f_2549},
{"f_2553srfi-14.scm",(void*)f_2553},
{"f_2556srfi-14.scm",(void*)f_2556},
{"f_2567srfi-14.scm",(void*)f_2567},
{"f_2559srfi-14.scm",(void*)f_2559},
{"f_2562srfi-14.scm",(void*)f_2562},
{"f_2496srfi-14.scm",(void*)f_2496},
{"f_2502srfi-14.scm",(void*)f_2502},
{"f_2547srfi-14.scm",(void*)f_2547},
{"f_2508srfi-14.scm",(void*)f_2508},
{"f_2432srfi-14.scm",(void*)f_2432},
{"f_2487srfi-14.scm",(void*)f_2487},
{"f_2442srfi-14.scm",(void*)f_2442},
{"f_2454srfi-14.scm",(void*)f_2454},
{"f_2471srfi-14.scm",(void*)f_2471},
{"f_2445srfi-14.scm",(void*)f_2445},
{"f_2391srfi-14.scm",(void*)f_2391},
{"f_2399srfi-14.scm",(void*)f_2399},
{"f_2401srfi-14.scm",(void*)f_2401},
{"f_2418srfi-14.scm",(void*)f_2418},
{"f_2395srfi-14.scm",(void*)f_2395},
{"f_2350srfi-14.scm",(void*)f_2350},
{"f_2386srfi-14.scm",(void*)f_2386},
{"f_2360srfi-14.scm",(void*)f_2360},
{"f_2368srfi-14.scm",(void*)f_2368},
{"f_2363srfi-14.scm",(void*)f_2363},
{"f_2324srfi-14.scm",(void*)f_2324},
{"f_2332srfi-14.scm",(void*)f_2332},
{"f_2334srfi-14.scm",(void*)f_2334},
{"f_2328srfi-14.scm",(void*)f_2328},
{"f_2279srfi-14.scm",(void*)f_2279},
{"f_2315srfi-14.scm",(void*)f_2315},
{"f_2289srfi-14.scm",(void*)f_2289},
{"f_2301srfi-14.scm",(void*)f_2301},
{"f_2292srfi-14.scm",(void*)f_2292},
{"f_2257srfi-14.scm",(void*)f_2257},
{"f_2265srfi-14.scm",(void*)f_2265},
{"f_2267srfi-14.scm",(void*)f_2267},
{"f_2261srfi-14.scm",(void*)f_2261},
{"f_2208srfi-14.scm",(void*)f_2208},
{"f_2248srfi-14.scm",(void*)f_2248},
{"f_2218srfi-14.scm",(void*)f_2218},
{"f_2230srfi-14.scm",(void*)f_2230},
{"f_2221srfi-14.scm",(void*)f_2221},
{"f_2182srfi-14.scm",(void*)f_2182},
{"f_2190srfi-14.scm",(void*)f_2190},
{"f_2192srfi-14.scm",(void*)f_2192},
{"f_2186srfi-14.scm",(void*)f_2186},
{"f_2160srfi-14.scm",(void*)f_2160},
{"f_2164srfi-14.scm",(void*)f_2164},
{"f_2169srfi-14.scm",(void*)f_2169},
{"f_2180srfi-14.scm",(void*)f_2180},
{"f_2167srfi-14.scm",(void*)f_2167},
{"f_2132srfi-14.scm",(void*)f_2132},
{"f_2136srfi-14.scm",(void*)f_2136},
{"f_2139srfi-14.scm",(void*)f_2139},
{"f_2147srfi-14.scm",(void*)f_2147},
{"f_2158srfi-14.scm",(void*)f_2158},
{"f_2142srfi-14.scm",(void*)f_2142},
{"f_2090srfi-14.scm",(void*)f_2090},
{"f_2096srfi-14.scm",(void*)f_2096},
{"f_2100srfi-14.scm",(void*)f_2100},
{"f_2105srfi-14.scm",(void*)f_2105},
{"f_2115srfi-14.scm",(void*)f_2115},
{"f_2049srfi-14.scm",(void*)f_2049},
{"f_2059srfi-14.scm",(void*)f_2059},
{"f_2069srfi-14.scm",(void*)f_2069},
{"f_2019srfi-14.scm",(void*)f_2019},
{"f_2026srfi-14.scm",(void*)f_2026},
{"f_2005srfi-14.scm",(void*)f_2005},
{"f_2013srfi-14.scm",(void*)f_2013},
{"f_2017srfi-14.scm",(void*)f_2017},
{"f_2009srfi-14.scm",(void*)f_2009},
{"f_1989srfi-14.scm",(void*)f_1989},
{"f_1993srfi-14.scm",(void*)f_1993},
{"f_2003srfi-14.scm",(void*)f_2003},
{"f_1996srfi-14.scm",(void*)f_1996},
{"f_1936srfi-14.scm",(void*)f_1936},
{"f_1942srfi-14.scm",(void*)f_1942},
{"f_1975srfi-14.scm",(void*)f_1975},
{"f_1962srfi-14.scm",(void*)f_1962},
{"f_1952srfi-14.scm",(void*)f_1952},
{"f_1926srfi-14.scm",(void*)f_1926},
{"f_1934srfi-14.scm",(void*)f_1934},
{"f_1930srfi-14.scm",(void*)f_1930},
{"f_1896srfi-14.scm",(void*)f_1896},
{"f_1906srfi-14.scm",(void*)f_1906},
{"f_1909srfi-14.scm",(void*)f_1909},
{"f_1839srfi-14.scm",(void*)f_1839},
{"f_1882srfi-14.scm",(void*)f_1882},
{"f_1849srfi-14.scm",(void*)f_1849},
{"f_1879srfi-14.scm",(void*)f_1879},
{"f_1858srfi-14.scm",(void*)f_1858},
{"f_1783srfi-14.scm",(void*)f_1783},
{"f_1787srfi-14.scm",(void*)f_1787},
{"f_1837srfi-14.scm",(void*)f_1837},
{"f_1790srfi-14.scm",(void*)f_1790},
{"f_1795srfi-14.scm",(void*)f_1795},
{"f_1825srfi-14.scm",(void*)f_1825},
{"f_1805srfi-14.scm",(void*)f_1805},
{"f_1773srfi-14.scm",(void*)f_1773},
{"f_1781srfi-14.scm",(void*)f_1781},
{"f_1777srfi-14.scm",(void*)f_1777},
{"f_1761srfi-14.scm",(void*)f_1761},
{"f_1765srfi-14.scm",(void*)f_1765},
{"f_1768srfi-14.scm",(void*)f_1768},
{"f_1718srfi-14.scm",(void*)f_1718},
{"f_1731srfi-14.scm",(void*)f_1731},
{"f_1671srfi-14.scm",(void*)f_1671},
{"f_1675srfi-14.scm",(void*)f_1675},
{"f_1680srfi-14.scm",(void*)f_1680},
{"f_1708srfi-14.scm",(void*)f_1708},
{"f_1698srfi-14.scm",(void*)f_1698},
{"f_1661srfi-14.scm",(void*)f_1661},
{"f_1669srfi-14.scm",(void*)f_1669},
{"f_1665srfi-14.scm",(void*)f_1665},
{"f_1649srfi-14.scm",(void*)f_1649},
{"f_1653srfi-14.scm",(void*)f_1653},
{"f_1656srfi-14.scm",(void*)f_1656},
{"f_1637srfi-14.scm",(void*)f_1637},
{"f_1641srfi-14.scm",(void*)f_1641},
{"f_1644srfi-14.scm",(void*)f_1644},
{"f_1622srfi-14.scm",(void*)f_1622},
{"f_1628srfi-14.scm",(void*)f_1628},
{"f_1612srfi-14.scm",(void*)f_1612},
{"f_1620srfi-14.scm",(void*)f_1620},
{"f_1616srfi-14.scm",(void*)f_1616},
{"f_1600srfi-14.scm",(void*)f_1600},
{"f_1604srfi-14.scm",(void*)f_1604},
{"f_1607srfi-14.scm",(void*)f_1607},
{"f_1564srfi-14.scm",(void*)f_1564},
{"f_1570srfi-14.scm",(void*)f_1570},
{"f_1598srfi-14.scm",(void*)f_1598},
{"f_1594srfi-14.scm",(void*)f_1594},
{"f_1590srfi-14.scm",(void*)f_1590},
{"f_1511srfi-14.scm",(void*)f_1511},
{"f_1515srfi-14.scm",(void*)f_1515},
{"f_1520srfi-14.scm",(void*)f_1520},
{"f_1550srfi-14.scm",(void*)f_1550},
{"f_1530srfi-14.scm",(void*)f_1530},
{"f_1462srfi-14.scm",(void*)f_1462},
{"f_1466srfi-14.scm",(void*)f_1466},
{"f_1471srfi-14.scm",(void*)f_1471},
{"f_1501srfi-14.scm",(void*)f_1501},
{"f_1487srfi-14.scm",(void*)f_1487},
{"f_1415srfi-14.scm",(void*)f_1415},
{"f_1419srfi-14.scm",(void*)f_1419},
{"f_1424srfi-14.scm",(void*)f_1424},
{"f_1452srfi-14.scm",(void*)f_1452},
{"f_1442srfi-14.scm",(void*)f_1442},
{"f_1352srfi-14.scm",(void*)f_1352},
{"f_1356srfi-14.scm",(void*)f_1356},
{"f_1359srfi-14.scm",(void*)f_1359},
{"f_1367srfi-14.scm",(void*)f_1367},
{"f_1401srfi-14.scm",(void*)f_1401},
{"f_1397srfi-14.scm",(void*)f_1397},
{"f_1377srfi-14.scm",(void*)f_1377},
{"f_1362srfi-14.scm",(void*)f_1362},
{"f_1302srfi-14.scm",(void*)f_1302},
{"f_1306srfi-14.scm",(void*)f_1306},
{"f_1311srfi-14.scm",(void*)f_1311},
{"f_1338srfi-14.scm",(void*)f_1338},
{"f_1321srfi-14.scm",(void*)f_1321},
{"f_1260srfi-14.scm",(void*)f_1260},
{"f_1264srfi-14.scm",(void*)f_1264},
{"f_1269srfi-14.scm",(void*)f_1269},
{"f_1282srfi-14.scm",(void*)f_1282},
{"f_1251srfi-14.scm",(void*)f_1251},
{"f_1245srfi-14.scm",(void*)f_1245},
{"f_1239srfi-14.scm",(void*)f_1239},
{"f_1233srfi-14.scm",(void*)f_1233},
{"f_1221srfi-14.scm",(void*)f_1221},
{"f_1227srfi-14.scm",(void*)f_1227},
{"f_1209srfi-14.scm",(void*)f_1209},
{"f_1215srfi-14.scm",(void*)f_1215},
{"f_1197srfi-14.scm",(void*)f_1197},
{"f_1203srfi-14.scm",(void*)f_1203},
{"f_1185srfi-14.scm",(void*)f_1185},
{"f_1191srfi-14.scm",(void*)f_1191},
{"f_1166srfi-14.scm",(void*)f_1166},
{"f_1170srfi-14.scm",(void*)f_1170},
{"f_1175srfi-14.scm",(void*)f_1175},
{"f_1173srfi-14.scm",(void*)f_1173},
{"f_1140srfi-14.scm",(void*)f_1140},
{"f_1164srfi-14.scm",(void*)f_1164},
{"f_1144srfi-14.scm",(void*)f_1144},
{"f_1152srfi-14.scm",(void*)f_1152},
{"f_1147srfi-14.scm",(void*)f_1147},
{"f_1083srfi-14.scm",(void*)f_1083},
{"f_1087srfi-14.scm",(void*)f_1087},
{"f_1092srfi-14.scm",(void*)f_1092},
{"f_1126srfi-14.scm",(void*)f_1126},
{"f_1113srfi-14.scm",(void*)f_1113},
{"f_1046srfi-14.scm",(void*)f_1046},
{"f_1050srfi-14.scm",(void*)f_1050},
{"f_1055srfi-14.scm",(void*)f_1055},
{"f_1019srfi-14.scm",(void*)f_1019},
{"f_1026srfi-14.scm",(void*)f_1026},
{"f_918srfi-14.scm",(void*)f_918},
{"f_925srfi-14.scm",(void*)f_925},
{"f_931srfi-14.scm",(void*)f_931},
{"f_939srfi-14.scm",(void*)f_939},
{"f_960srfi-14.scm",(void*)f_960},
{"f_984srfi-14.scm",(void*)f_984},
{"f_820srfi-14.scm",(void*)f_820},
{"f_840srfi-14.scm",(void*)f_840},
{"f_842srfi-14.scm",(void*)f_842},
{"f_852srfi-14.scm",(void*)f_852},
{"f_869srfi-14.scm",(void*)f_869},
{"f_765srfi-14.scm",(void*)f_765},
{"f_781srfi-14.scm",(void*)f_781},
{"f_786srfi-14.scm",(void*)f_786},
{"f_810srfi-14.scm",(void*)f_810},
{"f_751srfi-14.scm",(void*)f_751},
{"f_763srfi-14.scm",(void*)f_763},
{"f_759srfi-14.scm",(void*)f_759},
{"f_718srfi-14.scm",(void*)f_718},
{"f_724srfi-14.scm",(void*)f_724},
{"f_731srfi-14.scm",(void*)f_731},
{"f_741srfi-14.scm",(void*)f_741},
{"f_671srfi-14.scm",(void*)f_671},
{"f_716srfi-14.scm",(void*)f_716},
{"f_696srfi-14.scm",(void*)f_696},
{"f_703srfi-14.scm",(void*)f_703},
{"f_661srfi-14.scm",(void*)f_661},
{"f_655srfi-14.scm",(void*)f_655},
{"f_649srfi-14.scm",(void*)f_649},
{"f_643srfi-14.scm",(void*)f_643},
{"f_637srfi-14.scm",(void*)f_637},
{"f_631srfi-14.scm",(void*)f_631},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
