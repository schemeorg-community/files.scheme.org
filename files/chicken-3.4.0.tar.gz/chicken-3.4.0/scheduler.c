/* Generated from scheduler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:55
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: scheduler.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file scheduler.c
   unit: scheduler
*/

#include "chicken.h"

#ifdef HAVE_ERRNO_H
# include <errno.h>
# define C_signal_interrupted_p     C_mk_bool(errno == EINTR)
#else
# define C_signal_interrupted_p     C_SCHEME_FALSE
#endif

#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define C_msleep(n)     (Sleep(C_unfix(n)), C_SCHEME_TRUE)
#else
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <time.h>
static C_word C_msleep(C_word ms);
C_word C_msleep(C_word ms) {
#ifdef __CYGWIN__
  if(usleep(C_unfix(ms) * 1000) == -1) return C_SCHEME_FALSE;
#else
  struct timespec ts;
  unsigned long mss = C_unfix(ms);
  ts.tv_sec = mss / 1000;
  ts.tv_nsec = (mss % 1000) * 1000000;
  
  if(nanosleep(&ts, NULL) == -1) return C_SCHEME_FALSE;
#endif
  return C_SCHEME_TRUE;
}
#endif
static fd_set C_fdset_input, C_fdset_output, C_fdset_input_2, C_fdset_output_2;
#define C_fd_test_input(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_input))
#define C_fd_test_output(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_output))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[77];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,50,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,50,32,116,104,114,101,97,100,115,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,110,49,54,51,32,108,115,116,49,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,56,53,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,49,53,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,49,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,35,35,115,121,115,35,115,99,104,101,100,117,108,101,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,102,111,114,99,101,45,112,114,105,109,111,114,100,105,97,108,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,114,101,97,100,121,45,113,117,101,117,101,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,100,100,45,116,111,45,114,101,97,100,121,45,113,117,101,117,101,32,116,104,114,101,97,100,51,53,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,6),40,97,54,50,53,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,53,56,32,115,116,97,116,101,53,57,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,116,108,54,54,32,112,114,101,118,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,105,109,101,111,117,116,33,32,116,54,51,32,116,109,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,101,114,109,105,110,97,116,105,111,110,33,32,116,55,52,32,116,50,55,53,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,11),40,97,55,54,54,32,116,50,56,53,41,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,116,104,114,101,97,100,45,107,105,108,108,33,32,116,56,50,32,115,56,51,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,97,115,105,99,45,117,110,98,108,111,99,107,33,32,116,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,6),40,97,56,49,56,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,100,101,102,97,117,108,116,45,101,120,99,101,112,116,105,111,110,45,104,97,110,100,108,101,114,32,97,114,103,49,48,48,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,23),40,35,35,115,121,115,35,102,100,115,101,116,45,105,110,112,117,116,45,115,101,116,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,102,100,115,101,116,45,111,117,116,112,117,116,45,115,101,116,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,102,100,115,101,116,45,99,108,101,97,114,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,52,49,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,47),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,105,47,111,33,32,116,49,51,55,32,102,100,49,51,56,32,105,47,111,49,51,57,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,97,108,108,45,116,104,114,101,97,100,115,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,101,116,99,104,45,97,110,100,45,99,108,101,97,114,45,116,104,114,101,97,100,115,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,114,101,115,116,111,114,101,45,116,104,114,101,97,100,115,32,118,101,99,49,57,56,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,100,108,50,48,56,41,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,50,48,52,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,116,104,114,101,97,100,45,117,110,98,108,111,99,107,33,32,116,50,48,50,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,52,52,50,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,52,51,51,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,14),40,97,49,52,54,54,32,46,32,95,50,50,48,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,97,49,51,57,54,32,107,50,49,56,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,98,114,101,97,107,45,101,110,116,114,121,32,110,97,109,101,50,49,52,32,97,114,103,115,50,49,53,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,53,50,51,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,27),40,35,35,115,121,115,35,98,114,101,97,107,45,114,101,115,117,109,101,32,101,120,110,50,50,57,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,8),40,102,95,49,53,51,53,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from ##sys#fdset-clear in k859 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub134(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub134(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_CLR(fd, &C_fdset_input_2);FD_CLR(fd, &C_fdset_output_2);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-output-set in k859 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub130(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub130(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-input-set in k859 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub126(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub126(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_input);
C_ret:
#undef return

return C_r;}

/* from f_1535 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub123(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub123(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
FD_ZERO(&C_fdset_input);FD_ZERO(&C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-restore */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub121(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_fdset_input = C_fdset_input_2;C_fdset_output = C_fdset_output_2;
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-select-timeout */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub117(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int to=(int )C_truep(C_a0);
unsigned long tm=(unsigned long )C_num_to_unsigned_long(C_a1);
struct timeval timeout;timeout.tv_sec = tm / 1000;timeout.tv_usec = (tm % 1000) * 1000;C_fdset_input_2 = C_fdset_input;C_fdset_output_2 = C_fdset_output;return(select(FD_SETSIZE, &C_fdset_input, &C_fdset_output, NULL, to ? &timeout : NULL));
C_ret:
#undef return

return C_r;}

C_noret_decl(C_scheduler_toplevel)
C_externexport void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1401)
static void C_fcall f_1401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1342)
static void C_fcall f_1342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_fcall f_1303(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_933)
static void C_fcall f_933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_879)
static void C_fcall f_879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_869)
static C_word C_fcall f_869(C_word t0);
C_noret_decl(f_866)
static C_word C_fcall f_866(C_word t0);
C_noret_decl(f_863)
static C_word C_fcall f_863(C_word t0);
C_noret_decl(f_857)
static C_word C_fcall f_857();
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_844)
static void C_ccall f_844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_799)
static void C_ccall f_799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_805)
static void C_ccall f_805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_648)
static void C_fcall f_648(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_658)
static void C_fcall f_658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_626)
static void C_ccall f_626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_517)
static void C_fcall f_517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_504)
static void C_ccall f_504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_fcall f_496(C_word t0) C_noret;
C_noret_decl(f_275)
static void C_ccall f_275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_305)
static void C_ccall f_305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_310)
static void C_fcall f_310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_fcall f_389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_441)
static void C_fcall f_441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_fcall f_424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_314)
static void C_ccall f_314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_fcall f_1131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_fcall f_1015(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1116)
static void C_ccall f_1116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_fcall f_1046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1086)
static void C_fcall f_1086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_317)
static void C_ccall f_317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_322)
static void C_fcall f_322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_fcall f_541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_326)
static void C_fcall f_326(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1401)
static void C_fcall trf_1401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1401(t0,t1);}

C_noret_decl(trf_1342)
static void C_fcall trf_1342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1342(t0,t1,t2);}

C_noret_decl(trf_1303)
static void C_fcall trf_1303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1303(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1303(t0,t1,t2);}

C_noret_decl(trf_933)
static void C_fcall trf_933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_933(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_933(t0,t1,t2);}

C_noret_decl(trf_879)
static void C_fcall trf_879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_879(t0,t1);}

C_noret_decl(trf_648)
static void C_fcall trf_648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_648(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_648(t0,t1,t2,t3);}

C_noret_decl(trf_658)
static void C_fcall trf_658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_658(t0,t1);}

C_noret_decl(trf_517)
static void C_fcall trf_517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_517(t0,t1);}

C_noret_decl(trf_496)
static void C_fcall trf_496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_496(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_496(t0);}

C_noret_decl(trf_310)
static void C_fcall trf_310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_310(t0,t1);}

C_noret_decl(trf_389)
static void C_fcall trf_389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_389(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_389(t0,t1,t2);}

C_noret_decl(trf_441)
static void C_fcall trf_441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_441(t0,t1);}

C_noret_decl(trf_1168)
static void C_fcall trf_1168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1168(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1168(t0,t1,t2);}

C_noret_decl(trf_424)
static void C_fcall trf_424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_424(t0,t1);}

C_noret_decl(trf_1131)
static void C_fcall trf_1131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1131(t0,t1);}

C_noret_decl(trf_1015)
static void C_fcall trf_1015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1015(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1015(t0,t1,t2,t3);}

C_noret_decl(trf_1046)
static void C_fcall trf_1046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1046(t0,t1,t2);}

C_noret_decl(trf_1086)
static void C_fcall trf_1086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1086(t0,t1);}

C_noret_decl(trf_322)
static void C_fcall trf_322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_322(t0,t1);}

C_noret_decl(trf_541)
static void C_fcall trf_541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_541(t0,t1);}

C_noret_decl(trf_326)
static void C_fcall trf_326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_326(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scheduler_toplevel"));
C_check_nursery_minimum(44);
if(!C_demand(44)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(763)){
C_save(t1);
C_rereclaim2(763*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(44);
C_initialize_lf(lf,77);
lf[0]=C_h_intern(&lf[0],12,"\003sysschedule");
lf[1]=C_h_intern(&lf[1],18,"\003syscurrent-thread");
lf[2]=C_h_intern(&lf[2],17,"\003sysdynamic-winds");
lf[3]=C_h_intern(&lf[3],18,"\003sysstandard-input");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],18,"\003sysstandard-error");
lf[6]=C_h_intern(&lf[6],29,"\003syscurrent-exception-handler");
lf[7]=C_h_intern(&lf[7],28,"\003syscurrent-parameter-vector");
lf[8]=C_h_intern(&lf[8],5,"ready");
lf[9]=C_h_intern(&lf[9],7,"running");
lf[11]=C_h_intern(&lf[11],11,"\003sysfd-list");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000runtime-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\010deadlock");
lf[20]=C_h_intern(&lf[20],25,"\003systhread-basic-unblock!");
lf[21]=C_h_intern(&lf[21],8,"\003sysdelq");
lf[22]=C_h_intern(&lf[22],22,"\003sysadd-to-ready-queue");
lf[23]=C_h_intern(&lf[23],19,"\003systhread-unblock!");
lf[24]=C_h_intern(&lf[24],21,"\003sysprimordial-thread");
lf[25]=C_h_intern(&lf[25],15,"\003sysready-queue");
lf[26]=C_h_intern(&lf[26],18,"\003sysinterrupt-hook");
lf[27]=C_h_intern(&lf[27],29,"\003systhread-block-for-timeout!");
lf[28]=C_h_intern(&lf[28],7,"blocked");
lf[29]=C_h_intern(&lf[29],33,"\003systhread-block-for-termination!");
lf[30]=C_h_intern(&lf[30],4,"dead");
lf[31]=C_h_intern(&lf[31],10,"terminated");
lf[32]=C_h_intern(&lf[32],16,"\003systhread-kill!");
lf[33]=C_h_intern(&lf[33],12,"\003sysfor-each");
lf[34]=C_h_intern(&lf[34],19,"\003sysabandon-mutexes");
lf[35]=C_h_intern(&lf[35],19,"print-error-message");
lf[36]=C_h_intern(&lf[36],7,"display");
lf[37]=C_h_intern(&lf[37],16,"print-call-chain");
lf[38]=C_h_intern(&lf[38],18,"open-output-string");
lf[39]=C_h_intern(&lf[39],17,"get-output-string");
lf[40]=C_h_intern(&lf[40],29,"\003sysdefault-exception-handler");
lf[41]=C_h_intern(&lf[41],10,"\003syssignal");
lf[42]=C_h_intern(&lf[42],20,"\003syswarnings-enabled");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning (");
lf[47]=C_h_intern(&lf[47],25,"\003systhread-block-for-i/o!");
lf[48]=C_h_intern(&lf[48],6,"\000input");
lf[49]=C_h_intern(&lf[49],7,"\000output");
lf[50]=C_h_intern(&lf[50],4,"\000all");
lf[51]=C_h_intern(&lf[51],15,"\003sysall-threads");
lf[52]=C_h_intern(&lf[52],6,"append");
lf[53]=C_h_intern(&lf[53],7,"\003sysmap");
lf[54]=C_h_intern(&lf[54],3,"cdr");
lf[55]=C_h_intern(&lf[55],27,"\003sysfetch-and-clear-threads");
lf[56]=C_h_intern(&lf[56],19,"\003sysrestore-threads");
lf[57]=C_h_intern(&lf[57],15,"\003sysbreak-entry");
lf[58]=C_h_intern(&lf[58],19,"\003sysbreak-in-thread");
lf[59]=C_h_intern(&lf[59],9,"condition");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\003\000\000\002\376\001\000\000\012breakpoint\376\377\016");
lf[61]=C_h_intern(&lf[61],19,"\003syslast-breakpoint");
lf[62]=C_h_intern(&lf[62],9,"suspended");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\022*** breakpoint ***");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\011arguments");
lf[66]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\010location");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[70]=C_h_intern(&lf[70],16,"\003sysbreak-resume");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[74]=C_h_intern(&lf[74],11,"\000type-error");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
C_register_lf2(lf,77,create_ptable());
t2=C_mutate((C_word*)lf[0]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_275,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_496,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t4=lf[15]=C_SCHEME_END_OF_LIST;;
t5=lf[16]=C_SCHEME_END_OF_LIST;;
t6=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_504,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_507,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[26]+1);
t9=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_608,a[2]=t8,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t10=lf[10]=C_SCHEME_END_OF_LIST;;
t11=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_633,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_696,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_783,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[35]+1);
t16=*((C_word*)lf[36]+1);
t17=*((C_word*)lf[37]+1);
t18=*((C_word*)lf[38]+1);
t19=*((C_word*)lf[39]+1);
t20=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_795,a[2]=t18,a[3]=t16,a[4]=t19,a[5]=t15,a[6]=t17,a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp));
t21=C_set_block_item(lf[11],0,C_SCHEME_END_OF_LIST);
t22=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_857,tmp=(C_word)a,a+=2,tmp));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_861,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,t23);}

/* f_1535 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1535,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub123(C_SCHEME_UNDEFINED));}

/* k859 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_861,2,t0,t1);}
t2=C_mutate(&lf[45],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_863,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[46],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_866,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_869,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_872,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1233,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1251,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1261,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1280,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1382,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1479,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* ##sys#break-resume in k859 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1479,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_member(lf[71],t3);
t5=(C_word)C_i_member(lf[72],t3);
t6=(C_word)C_i_member(lf[73],t3);
t7=(C_truep(t6)?t6:t4);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1498,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t9=(C_word)C_u_i_cadr(t5);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1516,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1524,a[2]=t4,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
t12=t10;
f_1516(2,t12,(C_word)C_i_setslot(t9,C_fix(1),t11));}
else{
/* scheduler.scm: 507  ##sys#signal-hook */
t11=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[74],lf[76],t2);}}
else{
t9=t8;
f_1498(2,t9,C_SCHEME_UNDEFINED);}}

/* a1523 in ##sys#break-resume in k859 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_SCHEME_UNDEFINED);}

/* k1514 in ##sys#break-resume in k859 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 508  ##sys#add-to-ready-queue */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1496 in ##sys#break-resume in k859 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_SCHEME_UNDEFINED);}
else{
/* scheduler.scm: 511  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[74],lf[75],((C_word*)t0)[2]);}}

/* ##sys#break-entry in k859 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1382,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(*((C_word*)lf[58]+1));
t5=(C_truep(t4)?t4:(C_word)C_eqp(*((C_word*)lf[58]+1),*((C_word*)lf[1]+1)));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1397,a[2]=t3,a[3]=t2,a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 466  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a1396 in ##sys#break-entry in k859 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1397,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[24]+1));
if(C_truep(t4)){
t5=t3;
f_1401(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1467,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_1401(t6,(C_word)C_a_i_list(&a,4,lf[68],*((C_word*)lf[1]+1),lf[69],t5));}}

/* a1466 in a1396 in ##sys#break-entry in k859 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1467,2,t0,t1);}
t2=(C_word)C_slot(*((C_word*)lf[24]+1),C_fix(1));
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k1399 in a1396 in ##sys#break-entry in k859 */
static void C_fcall f_1401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1401,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,8,lf[63],lf[64],lf[65],t3,lf[66],((C_word*)t0)[3],lf[67],((C_word*)t0)[4]);
/* scheduler.scm: 476  append */
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}

/* k1449 in k1399 in a1396 in ##sys#break-entry in k859 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,3,lf[59],lf[60],t1);
t3=C_mutate((C_word*)lf[61]+1,t2);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[24]+1));
if(C_truep(t4)){
/* scheduler.scm: 484  ##sys#signal */
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],t2);}
else{
t5=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(3),lf[62]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(1),t6);
t8=(C_word)C_slot(*((C_word*)lf[24]+1),C_fix(1));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1434,a[2]=t2,a[3]=t8,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_setslot(*((C_word*)lf[24]+1),C_fix(1),t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 494  ##sys#thread-unblock! */
t12=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,*((C_word*)lf[24]+1));}}

/* k1427 in k1449 in k1399 in a1396 in ##sys#break-entry in k859 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 495  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1433 in k1449 in k1399 in a1396 in ##sys#break-entry in k859 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1438,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 492  ##sys#signal */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1436 in a1433 in k1449 in k1399 in a1396 in ##sys#break-entry in k859 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 493  old */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1442 in k1449 in k1399 in a1396 in ##sys#break-entry in k859 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
/* scheduler.scm: 487  k */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##sys#thread-unblock! in k859 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1280,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(lf[28],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1342,a[2]=t7,a[3]=t2,a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1342(t9,t5,lf[10]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in ##sys#thread-unblock! in k859 */
static void C_fcall f_1342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1342,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,((C_word*)t0)[3]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t2,C_fix(1)));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1368,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 448  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* k1366 in loop in ##sys#thread-unblock! in k859 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1289 in ##sys#thread-unblock! in k859 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=C_mutate(&lf[10],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1303(t7,t3,*((C_word*)lf[11]+1));}

/* loop in k1289 in ##sys#thread-unblock! in k859 */
static void C_fcall f_1303(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1303,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 456  ##sys#delq */
t7=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k1334 in loop in k1289 in ##sys#thread-unblock! in k859 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1324,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* scheduler.scm: 457  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1303(t5,t3,t4);}

/* k1322 in k1334 in loop in k1289 in ##sys#thread-unblock! in k859 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1293 in k1289 in ##sys#thread-unblock! in k859 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1,t1);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(12),C_SCHEME_END_OF_LIST);
/* scheduler.scm: 459  ##sys#thread-basic-unblock! */
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* ##sys#restore-threads in k859 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1261,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=C_mutate(&lf[15],t3);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_mutate(&lf[16],t5);
t7=(C_word)C_slot(t2,C_fix(2));
t8=C_mutate((C_word*)lf[11]+1,t7);
t9=(C_word)C_slot(t2,C_fix(3));
t10=C_mutate(&lf[10],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}

/* ##sys#fetch-and-clear-threads in k859 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1251,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,lf[15],lf[16],*((C_word*)lf[11]+1),lf[10]);
t3=lf[15]=C_SCHEME_END_OF_LIST;;
t4=lf[16]=C_SCHEME_END_OF_LIST;;
t5=C_set_block_item(lf[11],0,C_SCHEME_END_OF_LIST);
t6=lf[10]=C_SCHEME_END_OF_LIST;;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}

/* ##sys#all-threads in k859 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1241,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1249,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[54]+1),*((C_word*)lf[11]+1));}

/* k1247 in ##sys#all-threads in k859 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[52]+1),t1);}

/* k1239 in ##sys#all-threads in k859 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1245,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[54]+1),lf[10]);}

/* k1243 in k1239 in ##sys#all-threads in k859 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 412  append */
t2=*((C_word*)lf[52]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* ##sys#thread-block-for-i/o! in k859 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_872,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_876,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_933,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=((C_word)li23),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_933(t9,t5,*((C_word*)lf[11]+1));}

/* loop in ##sys#thread-block-for-i/o! in k859 */
static void C_fcall f_933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_933,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,*((C_word*)lf[11]+1));
t5=C_mutate((C_word*)lf[11]+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t3,C_fix(1),t7));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 333  loop */
t13=t1;
t14=t6;
t1=t13;
t2=t14;
goto loop;}}}

/* k874 in ##sys#thread-block-for-i/o! in k859 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_876,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_SCHEME_TRUE);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,lf[48]));
if(C_truep(t5)){
/* scheduler.scm: 335  ##sys#fdset-input-set */
t6=t3;
f_879(t6,f_863(((C_word*)t0)[3]));}
else{
t6=(C_word)C_eqp(t2,C_SCHEME_FALSE);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[49]));
if(C_truep(t7)){
/* scheduler.scm: 336  ##sys#fdset-output-set */
t8=t3;
f_879(t8,f_866(((C_word*)t0)[3]));}
else{
t8=(C_word)C_eqp(t2,lf[50]);
if(C_truep(t8)){
t9=f_863(((C_word*)t0)[3]);
/* scheduler.scm: 339  ##sys#fdset-output-set */
t10=t3;
f_879(t10,f_866(((C_word*)t0)[3]));}
else{
t9=t3;
f_879(t9,C_SCHEME_UNDEFINED);}}}}

/* k877 in k874 in ##sys#thread-block-for-i/o! in k859 */
static void C_fcall f_879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_879,NULL,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(3),lf[28]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(13),C_SCHEME_FALSE);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(11),t4));}

/* ##sys#fdset-clear in k859 */
static C_word C_fcall f_869(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub134(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-output-set in k859 */
static C_word C_fcall f_866(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub130(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-input-set in k859 */
static C_word C_fcall f_863(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub126(C_SCHEME_UNDEFINED,t1));}

/* ##sys#fdset-restore */
static C_word C_fcall f_857(){
C_word tmp;
C_word t1;
return((C_word)stub121(C_SCHEME_UNDEFINED));}

/* ##sys#default-exception-handler */
static void C_ccall f_795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_795,3,t0,t1,t2);}
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_799,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_mk_bool(C_abort_on_thread_exceptions))){
t5=*((C_word*)lf[24]+1);
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_819,a[2]=t2,a[3]=t6,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
/* scheduler.scm: 277  ##sys#thread-unblock! */
t9=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t4,t5);}
else{
if(C_truep(*((C_word*)lf[42]+1))){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 279  open-output-string */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t4;
f_799(2,t5,C_SCHEME_UNDEFINED);}}}

/* k830 in ##sys#default-exception-handler */
static void C_ccall f_832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_835,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 280  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[44],t1);}

/* k833 in k830 in ##sys#default-exception-handler */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 281  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[3]);}

/* k836 in k833 in k830 in ##sys#default-exception-handler */
static void C_ccall f_838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 282  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[43],((C_word*)t0)[3]);}

/* k839 in k836 in k833 in k830 in ##sys#default-exception-handler */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_844,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_851,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 283  get-output-string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k849 in k839 in k836 in k833 in k830 in ##sys#default-exception-handler */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 283  print-error-message */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[5]+1),t1);}

/* k842 in k839 in k836 in k833 in k830 in ##sys#default-exception-handler */
static void C_ccall f_844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 284  print-call-chain */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[5]+1),C_fix(0),((C_word*)t0)[2]);}

/* a818 in ##sys#default-exception-handler */
static void C_ccall f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_823,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 275  ##sys#signal */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k821 in a818 in ##sys#default-exception-handler */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 276  ptx */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k797 in ##sys#default-exception-handler */
static void C_ccall f_799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_799,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 286  ##sys#thread-kill! */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[31]);}

/* k803 in k797 in ##sys#default-exception-handler */
static void C_ccall f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 287  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#thread-basic-unblock! */
static void C_ccall f_783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_783,3,t0,t1,t2);}
t3=(C_word)C_i_set_i_slot(t2,C_fix(11),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(t2,C_fix(4),C_SCHEME_FALSE);
/* scheduler.scm: 258  ##sys#add-to-ready-queue */
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}

/* ##sys#thread-kill! */
static void C_ccall f_734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_734,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_738,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 239  ##sys#abandon-mutexes */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k736 in ##sys#thread-kill! */
static void C_ccall f_738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_738,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),((C_word*)t0)[3]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(11),C_SCHEME_FALSE);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(8),C_SCHEME_END_OF_LIST);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(12));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_756,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t7;
f_756(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_767,a[2]=((C_word*)t0)[4],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t9=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}}

/* a766 in k736 in ##sys#thread-kill! */
static void C_ccall f_767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_767,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(11));
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
/* scheduler.scm: 250  ##sys#thread-basic-unblock! */
t5=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k754 in k736 in ##sys#thread-kill! */
static void C_ccall f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(12),C_SCHEME_END_OF_LIST));}

/* ##sys#thread-block-for-termination! */
static void C_ccall f_696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_696,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_eqp(t4,lf[30]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[31]));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_word)C_slot(t3,C_fix(12));
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_i_setslot(t3,C_fix(12),t8);
t10=(C_word)C_i_setslot(t2,C_fix(3),lf[28]);
t11=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_i_setslot(t2,C_fix(11),t3));}}

/* ##sys#thread-block-for-timeout! */
static void C_ccall f_633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_633,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_637,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_648,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=((C_word)li12),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_648(t8,t4,lf[10],C_SCHEME_FALSE);}

/* loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_648(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_648,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_658,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_658(t6,t4);}
else{
t6=(C_word)C_u_i_caar(t2);
t7=((C_word*)t0)[4];
t8=t5;
f_658(t8,(C_word)C_fixnum_lessp(t7,t6));}}

/* k656 in loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_658,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),t3));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=C_mutate(&lf[10],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 223  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_648(t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}}

/* k635 in ##sys#thread-block-for-timeout! */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[28]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(13),C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),((C_word*)t0)[2]));}

/* ##sys#interrupt-hook */
static void C_ccall f_608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_608,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_612,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(t2,C_fix(255));
if(C_truep(t5)){
t6=*((C_word*)lf[1]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_626,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_setslot(t6,C_fix(1),t7);
/* scheduler.scm: 210  ##sys#schedule */
t9=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t4);}
else{
t6=t4;
f_612(2,t6,C_SCHEME_UNDEFINED);}}

/* a625 in ##sys#interrupt-hook */
static void C_ccall f_626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_626,2,t0,t1);}
/* scheduler.scm: 209  oldhook */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k610 in ##sys#interrupt-hook */
static void C_ccall f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 211  oldhook */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#add-to-ready-queue */
static void C_ccall f_507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_507,3,t0,t1,t2);}
t3=(C_word)C_i_setslot(t2,C_fix(3),lf[8]);
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_517,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,lf[15]);
if(C_truep(t6)){
t7=C_mutate(&lf[15],t4);
t8=t5;
f_517(t8,t7);}
else{
t7=t5;
f_517(t7,(C_word)C_i_setslot(lf[16],C_fix(1),t4));}}

/* k515 in ##sys#add-to-ready-queue */
static void C_fcall f_517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[16],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#ready-queue */
static void C_ccall f_504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_504,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* ##sys#force-primordial */
static void C_fcall f_496(C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_496,NULL,1,t1);}
/* scheduler.scm: 163  ##sys#thread-unblock! */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,*((C_word*)lf[24]+1));}

/* ##sys#schedule */
static void C_ccall f_275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_275,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_slot(t2,C_fix(5));
t7=(C_word)C_i_setslot(t6,C_fix(0),*((C_word*)lf[2]+1));
t8=(C_word)C_i_setslot(t6,C_fix(1),*((C_word*)lf[3]+1));
t9=(C_word)C_i_setslot(t6,C_fix(2),*((C_word*)lf[4]+1));
t10=(C_word)C_i_setslot(t6,C_fix(3),*((C_word*)lf[5]+1));
t11=(C_word)C_i_setslot(t6,C_fix(4),*((C_word*)lf[6]+1));
t12=(C_word)C_i_setslot(t6,C_fix(5),*((C_word*)lf[7]+1));
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_305,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_eqp(t5,lf[9]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[8]));
if(C_truep(t15)){
t16=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
/* scheduler.scm: 111  ##sys#add-to-ready-queue */
t17=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t13,t2);}
else{
t16=t13;
f_305(2,t16,C_SCHEME_UNDEFINED);}}

/* k303 in ##sys#schedule */
static void C_ccall f_305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_305,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_310,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_310(t5,((C_word*)t0)[2]);}

/* loop1 in k303 in ##sys#schedule */
static void C_fcall f_310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_310,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_314,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[10]))){
t3=t2;
f_314(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_fudge(C_fix(16));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=((C_word)li4),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_389(t7,t2,lf[10]);}}

/* loop in loop1 in k303 in ##sys#schedule */
static void C_fcall f_389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_389,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=lf[10]=C_SCHEME_END_OF_LIST;;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_u_i_cdar(t2);
t5=(C_word)C_slot(t4,C_fix(4));
t6=(C_word)C_eqp(t3,t5);
if(C_truep(t6)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[4],t3))){
t7=(C_word)C_i_set_i_slot(t4,C_fix(13),C_SCHEME_TRUE);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_424,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t4,C_fix(11));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_slot(t4,C_fix(11));
t11=(C_word)C_slot(t10,C_fix(0));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1168,a[2]=t14,a[3]=t4,a[4]=t11,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_1168(t16,t12,*((C_word*)lf[11]+1));}
else{
t10=t8;
f_424(t10,C_SCHEME_UNDEFINED);}}
else{
t7=C_mutate(&lf[10],t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_441,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[15]))){
t9=(C_word)C_i_nullp(*((C_word*)lf[11]+1));
t10=t8;
f_441(t10,(C_truep(t9)?(C_word)C_i_pairp(lf[10]):C_SCHEME_FALSE));}
else{
t9=t8;
f_441(t9,C_SCHEME_FALSE);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 144  loop */
t22=t1;
t23=t7;
t1=t22;
t2=t23;
goto loop;}}}

/* k439 in loop in loop1 in k303 in ##sys#schedule */
static void C_fcall f_441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(lf[10]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_fixnum_max(C_fix(0),t3);
t5=(C_truep((C_word)C_msleep(t4))?C_SCHEME_FALSE:C_mk_bool(C_signal_interrupted_p));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in loop in loop1 in k303 in ##sys#schedule */
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1168,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1190,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 397  ##sys#delq */
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1219,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 406  loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* k1217 in loop in loop in loop1 in k303 in ##sys#schedule */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1219,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1188 in loop in loop in loop1 in k303 in ##sys#schedule */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=f_869(((C_word*)t0)[5]);
t3=f_857();
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[3],C_fix(1)));}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1164 in loop in loop1 in k303 in ##sys#schedule */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1,t1);
t3=((C_word*)t0)[2];
f_424(t3,t2);}

/* k422 in loop in loop1 in k303 in ##sys#schedule */
static void C_fcall f_424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_424,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 130  ##sys#thread-basic-unblock! */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k425 in k422 in loop in loop1 in k303 in ##sys#schedule */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 131  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_389(t3,((C_word*)t0)[2],t2);}

/* k312 in loop1 in k303 in ##sys#schedule */
static void C_ccall f_314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* scheduler.scm: 147  ##sys#force-primordial */
f_496(t2);}
else{
if(C_truep((C_word)C_i_nullp(*((C_word*)lf[11]+1)))){
t3=t2;
f_317(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_pairp(lf[10]);
t4=(C_word)C_i_pairp(lf[15]);
t5=(C_truep(t4)?t4:t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1131,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?(C_word)C_i_not(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_u_i_caar(lf[10]);
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_difference(t8,t9);
t11=t6;
f_1131(t11,(C_word)C_i_fixnum_max(C_fix(0),t10));}
else{
t8=t6;
f_1131(t8,C_fix(0));}}}}

/* k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_fcall f_1131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1131,NULL,2,t0,t1);}
t2=(C_word)stub117(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* scheduler.scm: 357  ##sys#force-primordial */
f_496(t3);}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1015,a[2]=t7,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1015(t9,t5,t2,*((C_word*)lf[11]+1));}
else{
t5=t3;
f_994(2,t5,C_SCHEME_UNDEFINED);}}}

/* loop in k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_fcall f_1015(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1015,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_fd_test_input(t7);
t9=(C_word)C_fd_test_output(t7);
t10=(C_truep(t8)?t8:t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t6,C_fix(1));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1046,a[2]=t13,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t7,a[7]=((C_word)li1),tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_1046(t15,t1,t11);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1116,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 381  loop */
t18=t11;
t19=t2;
t20=t12;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1114 in loop in k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_ccall f_1116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1116,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_fcall f_1046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1046,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=f_869(((C_word*)t0)[6]);
t4=(C_word)C_u_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 373  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1015(t6,t1,t4,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t3,C_fix(11));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1076,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_eqp(((C_word*)t0)[6],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(13));
t10=t6;
f_1086(t10,(C_word)C_i_not(t9));}
else{
t9=t6;
f_1086(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1086(t7,C_SCHEME_FALSE);}}}

/* k1084 in loop2 in loop in k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_fcall f_1086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scheduler.scm: 379  ##sys#thread-basic-unblock! */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1076(2,t2,C_SCHEME_UNDEFINED);}}

/* k1074 in loop2 in loop in k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 380  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1046(t3,((C_word*)t0)[2],t2);}

/* k1011 in k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1,t1);
t3=((C_word*)t0)[2];
f_994(2,t3,t2);}

/* k992 in k1129 in k312 in loop1 in k303 in ##sys#schedule */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 382  ##sys#fdset-restore */
t2=((C_word*)t0)[2];
f_317(2,t2,f_857());}

/* k315 in k312 in loop1 in k303 in ##sys#schedule */
static void C_ccall f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_317,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_322,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_322(t5,((C_word*)t0)[2]);}

/* loop2 in k315 in k312 in loop1 in k303 in ##sys#schedule */
static void C_fcall f_322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_322,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=lf[15];
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_326(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
t5=C_mutate(&lf[15],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_541,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t7)){
t8=lf[16]=C_SCHEME_END_OF_LIST;;
t9=t6;
f_541(t9,t8);}
else{
t8=t6;
f_541(t8,C_SCHEME_UNDEFINED);}}}

/* k539 in loop2 in k315 in k312 in loop1 in k303 in ##sys#schedule */
static void C_fcall f_541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_326(t2,(C_word)C_u_i_car(((C_word*)t0)[2]));}

/* k324 in loop2 in k315 in k312 in loop1 in k303 in ##sys#schedule */
static void C_fcall f_326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_slot(t1,C_fix(3));
t4=(C_word)C_eqp(t3,lf[8]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
t6=t1;
t7=C_mutate((C_word*)lf[1]+1,t6);
t8=(C_word)C_i_setslot(t6,C_fix(3),lf[9]);
t9=(C_word)C_slot(t6,C_fix(5));
t10=(C_word)C_slot(t9,C_fix(0));
t11=C_mutate((C_word*)lf[2]+1,t10);
t12=(C_word)C_slot(t9,C_fix(1));
t13=C_mutate((C_word*)lf[3]+1,t12);
t14=(C_word)C_slot(t9,C_fix(2));
t15=C_mutate((C_word*)lf[4]+1,t14);
t16=(C_word)C_slot(t9,C_fix(3));
t17=C_mutate((C_word*)lf[5]+1,t16);
t18=(C_word)C_slot(t9,C_fix(4));
t19=C_mutate((C_word*)lf[6]+1,t18);
t20=(C_word)C_slot(t9,C_fix(5));
t21=C_mutate((C_word*)lf[7]+1,t20);
t22=(C_word)C_slot(t6,C_fix(9));
t23=(C_word)C_set_initial_timer_interrupt_period(t22);
t24=(C_word)C_slot(t6,C_fix(1));
t25=t24;
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,t5);}
else{
/* scheduler.scm: 159  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_322(t5,((C_word*)t0)[4]);}}
else{
t3=(C_word)C_i_nullp(lf[10]);
t4=(C_truep(t3)?(C_word)C_i_nullp(*((C_word*)lf[11]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
/* scheduler.scm: 156  ##sys#signal-hook */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],lf[13],lf[14]);}
else{
/* scheduler.scm: 157  loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_310(t5,((C_word*)t0)[4]);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[91] = {
{"toplevelscheduler.scm",(void*)C_scheduler_toplevel},
{"f_1535scheduler.scm",(void*)f_1535},
{"f_861scheduler.scm",(void*)f_861},
{"f_1479scheduler.scm",(void*)f_1479},
{"f_1524scheduler.scm",(void*)f_1524},
{"f_1516scheduler.scm",(void*)f_1516},
{"f_1498scheduler.scm",(void*)f_1498},
{"f_1382scheduler.scm",(void*)f_1382},
{"f_1397scheduler.scm",(void*)f_1397},
{"f_1467scheduler.scm",(void*)f_1467},
{"f_1401scheduler.scm",(void*)f_1401},
{"f_1451scheduler.scm",(void*)f_1451},
{"f_1429scheduler.scm",(void*)f_1429},
{"f_1434scheduler.scm",(void*)f_1434},
{"f_1438scheduler.scm",(void*)f_1438},
{"f_1443scheduler.scm",(void*)f_1443},
{"f_1280scheduler.scm",(void*)f_1280},
{"f_1342scheduler.scm",(void*)f_1342},
{"f_1368scheduler.scm",(void*)f_1368},
{"f_1291scheduler.scm",(void*)f_1291},
{"f_1303scheduler.scm",(void*)f_1303},
{"f_1336scheduler.scm",(void*)f_1336},
{"f_1324scheduler.scm",(void*)f_1324},
{"f_1295scheduler.scm",(void*)f_1295},
{"f_1261scheduler.scm",(void*)f_1261},
{"f_1251scheduler.scm",(void*)f_1251},
{"f_1233scheduler.scm",(void*)f_1233},
{"f_1249scheduler.scm",(void*)f_1249},
{"f_1241scheduler.scm",(void*)f_1241},
{"f_1245scheduler.scm",(void*)f_1245},
{"f_872scheduler.scm",(void*)f_872},
{"f_933scheduler.scm",(void*)f_933},
{"f_876scheduler.scm",(void*)f_876},
{"f_879scheduler.scm",(void*)f_879},
{"f_869scheduler.scm",(void*)f_869},
{"f_866scheduler.scm",(void*)f_866},
{"f_863scheduler.scm",(void*)f_863},
{"f_857scheduler.scm",(void*)f_857},
{"f_795scheduler.scm",(void*)f_795},
{"f_832scheduler.scm",(void*)f_832},
{"f_835scheduler.scm",(void*)f_835},
{"f_838scheduler.scm",(void*)f_838},
{"f_841scheduler.scm",(void*)f_841},
{"f_851scheduler.scm",(void*)f_851},
{"f_844scheduler.scm",(void*)f_844},
{"f_819scheduler.scm",(void*)f_819},
{"f_823scheduler.scm",(void*)f_823},
{"f_799scheduler.scm",(void*)f_799},
{"f_805scheduler.scm",(void*)f_805},
{"f_783scheduler.scm",(void*)f_783},
{"f_734scheduler.scm",(void*)f_734},
{"f_738scheduler.scm",(void*)f_738},
{"f_767scheduler.scm",(void*)f_767},
{"f_756scheduler.scm",(void*)f_756},
{"f_696scheduler.scm",(void*)f_696},
{"f_633scheduler.scm",(void*)f_633},
{"f_648scheduler.scm",(void*)f_648},
{"f_658scheduler.scm",(void*)f_658},
{"f_637scheduler.scm",(void*)f_637},
{"f_608scheduler.scm",(void*)f_608},
{"f_626scheduler.scm",(void*)f_626},
{"f_612scheduler.scm",(void*)f_612},
{"f_507scheduler.scm",(void*)f_507},
{"f_517scheduler.scm",(void*)f_517},
{"f_504scheduler.scm",(void*)f_504},
{"f_496scheduler.scm",(void*)f_496},
{"f_275scheduler.scm",(void*)f_275},
{"f_305scheduler.scm",(void*)f_305},
{"f_310scheduler.scm",(void*)f_310},
{"f_389scheduler.scm",(void*)f_389},
{"f_441scheduler.scm",(void*)f_441},
{"f_1168scheduler.scm",(void*)f_1168},
{"f_1219scheduler.scm",(void*)f_1219},
{"f_1190scheduler.scm",(void*)f_1190},
{"f_1166scheduler.scm",(void*)f_1166},
{"f_424scheduler.scm",(void*)f_424},
{"f_427scheduler.scm",(void*)f_427},
{"f_314scheduler.scm",(void*)f_314},
{"f_1131scheduler.scm",(void*)f_1131},
{"f_1015scheduler.scm",(void*)f_1015},
{"f_1116scheduler.scm",(void*)f_1116},
{"f_1046scheduler.scm",(void*)f_1046},
{"f_1086scheduler.scm",(void*)f_1086},
{"f_1076scheduler.scm",(void*)f_1076},
{"f_1013scheduler.scm",(void*)f_1013},
{"f_994scheduler.scm",(void*)f_994},
{"f_317scheduler.scm",(void*)f_317},
{"f_322scheduler.scm",(void*)f_322},
{"f_541scheduler.scm",(void*)f_541},
{"f_326scheduler.scm",(void*)f_326},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
