/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:59
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: chicken-bug.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -output-file chicken-bug.c
   used units: library eval data_structures ports extras srfi_69 srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[149];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_153)
static void C_ccall f_153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_156)
static void C_ccall f_156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_159)
static void C_ccall f_159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_162)
static void C_ccall f_162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_165)
static void C_ccall f_165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_168)
static void C_ccall f_168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_171)
static void C_ccall f_171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_174)
static void C_ccall f_174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_177)
static void C_ccall f_177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_180)
static void C_ccall f_180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_183)
static void C_ccall f_183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_186)
static void C_ccall f_186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static void C_ccall f_905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_ccall f_926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_881)
static void C_ccall f_881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_624)
static void C_fcall f_624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_ccall f_628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_fcall f_635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_ccall f_671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_643)
static void C_ccall f_643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_663)
static void C_ccall f_663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_572)
static void C_ccall f_572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_590)
static void C_ccall f_590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_585)
static void C_ccall f_585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_429)
static void C_ccall f_429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_545)
static void C_ccall f_545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_523)
static void C_ccall f_523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_436)
static void C_fcall f_436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_442)
static void C_ccall f_442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_448)
static void C_fcall f_448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_487)
static void C_ccall f_487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_481)
static void C_ccall f_481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_463)
static void C_ccall f_463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_ccall f_391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_408)
static void C_ccall f_408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_192)
static void C_ccall f_192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_196)
static void C_ccall f_196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_199)
static void C_ccall f_199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_202)
static void C_ccall f_202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_372)
static void C_ccall f_372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_205)
static void C_ccall f_205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_208)
static void C_ccall f_208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_364)
static void C_ccall f_364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_211)
static void C_ccall f_211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_214)
static void C_ccall f_214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_217)
static void C_ccall f_217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_220)
static void C_ccall f_220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_223)
static void C_ccall f_223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_226)
static void C_ccall f_226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_229)
static void C_ccall f_229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_232)
static void C_ccall f_232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_299)
static void C_ccall f_299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_308)
static void C_ccall f_308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_316)
static void C_ccall f_316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_235)
static void C_ccall f_235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_238)
static void C_ccall f_238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_283)
static void C_ccall f_283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_285)
static void C_ccall f_285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_293)
static void C_ccall f_293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_241)
static void C_ccall f_241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_244)
static void C_ccall f_244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_279)
static void C_ccall f_279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_253)
static void C_ccall f_253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_256)
static void C_ccall f_256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_261)
static void C_ccall f_261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_269)
static void C_ccall f_269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_247)
static void C_ccall f_247(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_624)
static void C_fcall trf_624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_624(t0,t1);}

C_noret_decl(trf_635)
static void C_fcall trf_635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_635(t0,t1);}

C_noret_decl(trf_436)
static void C_fcall trf_436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_436(t0,t1);}

C_noret_decl(trf_448)
static void C_fcall trf_448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_448(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(636)){
C_save(t1);
C_rereclaim2(636*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,149);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-janitors@nongnu.org");
lf[7]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014mx10.gnu.org\376\003\000\000\002\376B\000\000\014mx20.gnu.org\376\377\016");
lf[8]=C_h_intern(&lf[8],12,"collect-info");
lf[9]=C_h_intern(&lf[9],7,"newline");
lf[10]=C_h_intern(&lf[10],7,"display");
lf[11]=C_h_intern(&lf[11],8,"read-all");
lf[12]=C_h_intern(&lf[12],20,"with-input-from-pipe");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[14]=C_h_intern(&lf[14],5,"print");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[17]=C_h_intern(&lf[17],8,"feature\077");
lf[18]=C_h_intern(&lf[18],4,"unix");
lf[19]=C_h_intern(&lf[19],17,"\003syspeek-c-string");
lf[20]=C_h_intern(&lf[20],20,"with-input-from-file");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[24]=C_h_intern(&lf[24],6,"printf");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[26]=C_h_intern(&lf[26],11,"make-string");
lf[27]=C_h_intern(&lf[27],12,"\003sysfor-each");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[29]=C_h_intern(&lf[29],4,"chop");
lf[30]=C_h_intern(&lf[30],4,"sort");
lf[31]=C_h_intern(&lf[31],8,"string<\077");
lf[32]=C_h_intern(&lf[32],7,"\003sysmap");
lf[33]=C_h_intern(&lf[33],15,"keyword->string");
lf[34]=C_h_intern(&lf[34],12,"\003sysfeatures");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024Include path:\011~s~%~%");
lf[37]=C_h_intern(&lf[37],21,"\003sysinclude-pathnames");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[40]=C_h_intern(&lf[40],12,"chicken-home");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[43]=C_h_intern(&lf[43],15,"chicken-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[46]=C_h_intern(&lf[46],14,"build-platform");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[48]=C_h_intern(&lf[48],16,"software-version");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[50]=C_h_intern(&lf[50],13,"software-type");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[52]=C_h_intern(&lf[52],12,"machine-type");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\030User information:\011~s~%~%");
lf[55]=C_h_intern(&lf[55],16,"user-information");
lf[56]=C_h_intern(&lf[56],15,"current-user-id");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[59]=C_h_intern(&lf[59],15,"seconds->string");
lf[60]=C_h_intern(&lf[60],15,"current-seconds");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[63]=C_h_intern(&lf[63],5,"usage");
lf[64]=C_h_intern(&lf[64],4,"exit");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[66]=C_h_intern(&lf[66],10,"user-input");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\001VThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012once you have fini"
"shed. Press CTRL-C to abort the program. You can\012also pass the description from "
"a file (just abort now and re-invoke\012\042chicken-bug\042 with one or more input files "
"given on the command-line)\012");
lf[68]=C_h_intern(&lf[68],13,"\003systty-port\077");
lf[69]=C_h_intern(&lf[69],18,"current-input-port");
lf[70]=C_h_intern(&lf[70],7,"justify");
lf[71]=C_h_intern(&lf[71],13,"string-append");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[73]=C_h_intern(&lf[73],4,"main");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_h_intern(&lf[75],8,"try-mail");
lf[76]=C_h_intern(&lf[76],21,"with-output-to-string");
lf[77]=C_h_intern(&lf[77],12,"mail-headers");
lf[78]=C_h_intern(&lf[78],7,"sprintf");
lf[79]=C_h_intern(&lf[79],15,"\003sysmatch-error");
lf[80]=C_h_intern(&lf[80],19,"seconds->local-time");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000G\012Could not send mail automatically!\012\012A bug report has been written to `");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[93]=C_h_intern(&lf[93],19,"with-output-to-file");
lf[94]=C_h_intern(&lf[94],9,"send-mail");
lf[95]=C_h_intern(&lf[95],13,"mail-date-str");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[100]=C_h_intern(&lf[100],10,"string-pad");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[125]=C_h_intern(&lf[125],17,"seconds->utc-time");
lf[126]=C_h_intern(&lf[126],9,"mail-read");
lf[127]=C_h_intern(&lf[127],9,"substring");
lf[128]=C_h_intern(&lf[128],9,"condition");
lf[129]=C_h_intern(&lf[129],17,"close-output-port");
lf[130]=C_h_intern(&lf[130],16,"close-input-port");
lf[131]=C_h_intern(&lf[131],9,"read-line");
lf[132]=C_h_intern(&lf[132],22,"with-exception-handler");
lf[133]=C_h_intern(&lf[133],30,"call-with-current-continuation");
lf[134]=C_h_intern(&lf[134],10,"mail-write");
lf[135]=C_h_intern(&lf[135],10,"mail-check");
lf[136]=C_h_intern(&lf[136],11,"tcp-connect");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000QBug report successfully mailed to the Chicken maintainers.\012Thank you very m"
"uch!\012\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[147]=C_h_intern(&lf[147],25,"\003sysimplicit-exit-handler");
lf[148]=C_h_intern(&lf[148],22,"command-line-arguments");
C_register_lf2(lf,149,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_153,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k151 */
static void C_ccall f_153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k154 in k151 */
static void C_ccall f_156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_159,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k157 in k154 in k151 */
static void C_ccall f_159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k160 in k157 in k154 in k151 */
static void C_ccall f_162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_165,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_171,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_186,2,t0,t1);}
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_192,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_382,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_391,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_410,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_429,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_572,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_613,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_801,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_819,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_905,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_974,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_995,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 262  command-line-arguments */
t20=C_retrieve(lf[148]);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}

/* k1086 in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 262  main */
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1076 in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1084,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[147]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1082 in k1076 in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1079 in k1076 in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_995,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_999,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 245  print */
t7=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[145],t2,lf[146]);}

/* k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 246  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1010,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 248  call-with-current-continuation */
t5=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}

/* a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1075,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 250  mail-read */
t5=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1073 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 250  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 251  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[144]);}

/* k1069 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 251  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 252  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[143]);}

/* k1065 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 252  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 253  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[142]);}

/* k1061 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 253  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1059,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 254  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1057 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 254  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 255  string-append */
t5=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[139],((C_word*)t0)[2],lf[140]);}

/* k1053 in k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 255  mail-write */
t2=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1049 in k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 255  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 256  display */
t3=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[138],((C_word*)t0)[3]);}

/* k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 257  close-input-port */
t3=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 258  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 259  print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[137]);}

/* k1045 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in a1015 in a1009 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* a1003 in k997 in send-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
/* chicken-bug.scm: 247  tcp-connect */
t2=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_fix(25));}

/* mail-check in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_974,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?(C_word)C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_984,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 240  close-input-port */
t9=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t2);}}

/* k982 in mail-check in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 241  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k985 in k982 in mail-check in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 242  k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_905,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_909,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_918,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_920,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 230  call-with-current-continuation */
t8=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}

/* a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_920,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_926,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_950,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 230  with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a949 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 230  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a961 in a949 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_962r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_962r(t0,t1,t2);}}

static void C_ccall f_962r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 230  g84 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a967 in a961 in a949 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a955 in a949 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
/* chicken-bug.scm: 230  display */
t2=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a925 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_926,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 230  g84 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a931 in a925 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_932,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[128]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 231  close-input-port */
t5=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k937 in a931 in a925 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 231  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k940 in k937 in a931 in a925 in a919 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k916 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k907 in mail-write in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 233  mail-read */
t2=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_819,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_823,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_849,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_851,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 221  call-with-current-continuation */
t7=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_851,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_857,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_881,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 221  with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a880 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 221  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a892 in a880 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_893r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_893r(t0,t1,t2);}}

static void C_ccall f_893r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_899,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 221  g69 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a898 in a892 in a880 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a886 in a880 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
/* chicken-bug.scm: 221  read-line */
t2=C_retrieve(lf[131]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a856 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_857,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 221  g69 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a862 in a856 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[128]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_870,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 222  close-input-port */
t5=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k868 in a862 in a856 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_873,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 222  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k871 in k868 in a862 in a856 in a850 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k847 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k821 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_823,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 225  substring */
t4=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm: 226  mail-read */
t3=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k837 in k821 in mail-read in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 225  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_809,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_817,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 215  current-seconds */
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k815 in mail-headers in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 215  seconds->utc-time */
t2=C_retrieve(lf[125]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k811 in mail-headers in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 215  mail-date-str */
t2=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k807 in mail-headers in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 214  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[2],lf[120],t1,lf[121],lf[122],lf[123],lf[124]);}

/* mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_613,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_624,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_624(t5,lf[113]);
case C_fix(1):
t5=t4;
f_624(t5,lf[114]);
case C_fix(2):
t5=t4;
f_624(t5,lf[115]);
case C_fix(3):
t5=t4;
f_624(t5,lf[116]);
case C_fix(4):
t5=t4;
f_624(t5,lf[117]);
case C_fix(5):
t5=t4;
f_624(t5,lf[118]);
default:
t5=(C_word)C_eqp(t3,C_fix(6));
t6=t4;
f_624(t6,(C_truep(t5)?lf[119]:C_SCHEME_UNDEFINED));}}

/* k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_fcall f_624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_624,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_628,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_756,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm: 190  number->string */
C_number_to_string(3,0,t3,t4);}

/* k754 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 190  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_628,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_635,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_635(t4,lf[101]);
case C_fix(1):
t4=t3;
f_635(t4,lf[102]);
case C_fix(2):
t4=t3;
f_635(t4,lf[103]);
case C_fix(3):
t4=t3;
f_635(t4,lf[104]);
case C_fix(4):
t4=t3;
f_635(t4,lf[105]);
case C_fix(5):
t4=t3;
f_635(t4,lf[106]);
case C_fix(6):
t4=t3;
f_635(t4,lf[107]);
case C_fix(7):
t4=t3;
f_635(t4,lf[108]);
case C_fix(8):
t4=t3;
f_635(t4,lf[109]);
case C_fix(9):
t4=t3;
f_635(t4,lf[110]);
case C_fix(10):
t4=t3;
f_635(t4,lf[111]);
default:
t4=(C_word)C_eqp(t2,C_fix(11));
t5=t3;
f_635(t5,(C_truep(t4)?lf[112]:C_SCHEME_UNDEFINED));}}

/* k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_fcall f_635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_635,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_639,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=(C_word)C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm: 204  number->string */
C_number_to_string(3,0,t2,t4);}

/* k637 in k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_643,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm: 206  number->string */
C_number_to_string(3,0,t3,t4);}

/* k669 in k637 in k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 206  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k641 in k637 in k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_647,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_663,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm: 208  number->string */
C_number_to_string(3,0,t3,t4);}

/* k661 in k641 in k637 in k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 208  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k645 in k641 in k637 in k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_651,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_655,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm: 210  number->string */
C_number_to_string(3,0,t3,t4);}

/* k653 in k645 in k641 in k637 in k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 210  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k649 in k645 in k641 in k637 in k633 in k626 in k622 in mail-date-str in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 181  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc13)C_retrieve_proc(t2))(13,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[96],((C_word*)t0)[3],lf[97],((C_word*)t0)[2],lf[98],t1,lf[99]);}

/* try-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_572,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_582,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_590,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 173  with-output-to-file */
t8=C_retrieve(lf[93]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_597,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-bug.scm: 177  send-mail */
t8=*((C_word*)lf[94]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t6,t7,t5,t4,t3);}}

/* k595 in try-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm: 178  try-mail */
t3=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a589 in try-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_590,2,t0,t1);}
/* chicken-bug.scm: 174  print */
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k580 in try-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_585,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 175  print */
t3=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[91],((C_word*)t0)[2],lf[92]);}

/* k583 in k580 in try-mail in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 176  print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[90],lf[3]);}

/* main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_429,3,t0,t1,t2);}
t3=lf[74];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_433,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_529,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* for-each */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t2);}

/* a528 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_529,3,t0,t1,t2);}
if(C_truep((C_word)C_i_string_equal_p(lf[82],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_541,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_545,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 130  user-input */
t6=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[85]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[86]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-bug.scm: 132  usage */
t4=*((C_word*)lf[63]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[87],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_566,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_570,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 141  read-all */
t7=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}}}

/* k568 in a528 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 138  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[88],((C_word*)t0)[2],lf[89],t1);}

/* k564 in a528 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k543 in a528 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 130  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[83],t1);}

/* k539 in a528 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_436(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_523,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_527,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 144  user-input */
t5=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k525 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 144  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[81],t1);}

/* k521 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_436(t3,t2);}

/* k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_fcall f_436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_436,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 145  newline */
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 146  current-seconds */
t4=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k517 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 146  seconds->local-time */
t2=C_retrieve(lf[80]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_448(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_448(t3,C_SCHEME_FALSE);}}

/* k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_fcall f_448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_448,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_463,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 149  print */
t6=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_498,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 153  justify */
t8=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
/* chicken-bug.scm: 146  ##sys#match-error */
t2=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k496 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_502,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 153  justify */
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k500 in k496 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 153  sprintf */
t2=C_retrieve(lf[78]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[1],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k471 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_477,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 154  mail-headers */
t3=*((C_word*)lf[77]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k475 in k471 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_481,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_483,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 155  with-output-to-string */
t4=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a482 in k475 in k471 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_487,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 157  print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k485 in a482 in k475 in k471 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 158  collect-info */
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k479 in k475 in k471 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 151  try-mail */
t2=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k461 in k446 in k440 in k437 in k434 in k431 in main in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 150  collect-info */
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* justify in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_410,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_414,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 117  number->string */
C_number_to_string(3,0,t3,t2);}

/* k412 in justify in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(1)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-bug.scm: 120  string-append */
t3=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[72],t1);}}

/* user-input in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_408,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 104  current-input-port */
t5=*((C_word*)lf[69]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k406 in user-input in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 104  ##sys#tty-port? */
t2=C_retrieve(lf[68]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k399 in user-input in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 105  print */
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[67]);}
else{
t2=((C_word*)t0)[2];
f_395(2,t2,C_SCHEME_UNDEFINED);}}

/* k393 in user-input in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 114  read-all */
t2=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* usage in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_382,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_386,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 89   print */
t4=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[65]);}

/* k384 in usage in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 101  exit */
t2=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_196,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 55   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[62]);}

/* k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 56   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[61]);}

/* k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 57   current-seconds */
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k378 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   seconds->string */
t2=C_retrieve(lf[59]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k374 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[57],t1,lf[58]);}

/* k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_205,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_372,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 58   current-user-id */
t5=C_retrieve(lf[56]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k370 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   user-information */
t2=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k366 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   printf */
t2=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[54],t1);}

/* k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 59   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 60   machine-type */
t4=C_retrieve(lf[52]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k362 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 60   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_360,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 61   software-type */
t4=C_retrieve(lf[50]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k358 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 61   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_217,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 62   software-version */
t4=C_retrieve(lf[48]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k354 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 62   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[47],t1);}

/* k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_352,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 63   build-platform */
t4=C_retrieve(lf[46]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k350 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 63   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[44],t1,lf[45]);}

/* k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 64   chicken-version */
t4=C_retrieve(lf[43]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k346 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 64   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[41],t1,lf[42]);}

/* k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_226,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 65   chicken-home */
t4=C_retrieve(lf[40]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k342 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 65   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[38],t1,lf[39]);}

/* k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_229,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 66   printf */
t3=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[36],C_retrieve(lf[37]));}

/* k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 67   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_235,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_299,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_332,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_336,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[33]),C_retrieve(lf[34]));}

/* k338 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 75   sort */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[31]+1));}

/* k334 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 75   chop */
t2=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k330 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a298 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_299,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_303,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 70   display */
t4=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[28]);}

/* k301 in a298 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_308,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a307 in k301 in a298 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_316,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* chicken-bug.scm: 73   make-string */
t7=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k314 in a307 in k301 in a298 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 73   printf */
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[25],((C_word*)t0)[2],t1);}

/* k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 76   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[23]);}

/* k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_241,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_283,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_297,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k295 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 77   make-pathname */
t2=C_retrieve(lf[21]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[22]);}

/* k281 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_285,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 77   with-input-from-file */
t3=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a284 in k281 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_293,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 79   read-all */
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k291 in a284 in k281 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 79   display */
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 80   newline */
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k242 in k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_247,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_253,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_279,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k277 in k242 in k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(t1,lf[16]))){
/* chicken-bug.scm: 81   feature? */
t2=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[18]);}
else{
t2=((C_word*)t0)[2];
f_253(2,t2,C_SCHEME_FALSE);}}

/* k251 in k242 in k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_253,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 82   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[15]);}
else{
t2=((C_word*)t0)[2];
f_247(2,t2,C_SCHEME_UNDEFINED);}}

/* k254 in k251 in k242 in k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_261,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 83   with-input-from-pipe */
t3=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[13],t2);}

/* a260 in k254 in k251 in k242 in k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_269,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 85   read-all */
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k267 in a260 in k254 in k251 in k242 in k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 85   display */
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k245 in k242 in k239 in k236 in k233 in k230 in k227 in k224 in k221 in k218 in k215 in k212 in k209 in k206 in k203 in k200 in k197 in k194 in collect-info in k184 in k181 in k178 in k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 in k151 */
static void C_ccall f_247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 86   newline */
t2=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[164] = {
{"toplevelchicken-bug.scm",(void*)C_toplevel},
{"f_153chicken-bug.scm",(void*)f_153},
{"f_156chicken-bug.scm",(void*)f_156},
{"f_159chicken-bug.scm",(void*)f_159},
{"f_162chicken-bug.scm",(void*)f_162},
{"f_165chicken-bug.scm",(void*)f_165},
{"f_168chicken-bug.scm",(void*)f_168},
{"f_171chicken-bug.scm",(void*)f_171},
{"f_174chicken-bug.scm",(void*)f_174},
{"f_177chicken-bug.scm",(void*)f_177},
{"f_180chicken-bug.scm",(void*)f_180},
{"f_183chicken-bug.scm",(void*)f_183},
{"f_186chicken-bug.scm",(void*)f_186},
{"f_1088chicken-bug.scm",(void*)f_1088},
{"f_1078chicken-bug.scm",(void*)f_1078},
{"f_1084chicken-bug.scm",(void*)f_1084},
{"f_1081chicken-bug.scm",(void*)f_1081},
{"f_995chicken-bug.scm",(void*)f_995},
{"f_999chicken-bug.scm",(void*)f_999},
{"f_1010chicken-bug.scm",(void*)f_1010},
{"f_1016chicken-bug.scm",(void*)f_1016},
{"f_1075chicken-bug.scm",(void*)f_1075},
{"f_1020chicken-bug.scm",(void*)f_1020},
{"f_1071chicken-bug.scm",(void*)f_1071},
{"f_1023chicken-bug.scm",(void*)f_1023},
{"f_1067chicken-bug.scm",(void*)f_1067},
{"f_1026chicken-bug.scm",(void*)f_1026},
{"f_1063chicken-bug.scm",(void*)f_1063},
{"f_1029chicken-bug.scm",(void*)f_1029},
{"f_1059chicken-bug.scm",(void*)f_1059},
{"f_1032chicken-bug.scm",(void*)f_1032},
{"f_1055chicken-bug.scm",(void*)f_1055},
{"f_1051chicken-bug.scm",(void*)f_1051},
{"f_1035chicken-bug.scm",(void*)f_1035},
{"f_1038chicken-bug.scm",(void*)f_1038},
{"f_1041chicken-bug.scm",(void*)f_1041},
{"f_1044chicken-bug.scm",(void*)f_1044},
{"f_1047chicken-bug.scm",(void*)f_1047},
{"f_1004chicken-bug.scm",(void*)f_1004},
{"f_974chicken-bug.scm",(void*)f_974},
{"f_984chicken-bug.scm",(void*)f_984},
{"f_987chicken-bug.scm",(void*)f_987},
{"f_905chicken-bug.scm",(void*)f_905},
{"f_920chicken-bug.scm",(void*)f_920},
{"f_950chicken-bug.scm",(void*)f_950},
{"f_962chicken-bug.scm",(void*)f_962},
{"f_968chicken-bug.scm",(void*)f_968},
{"f_956chicken-bug.scm",(void*)f_956},
{"f_926chicken-bug.scm",(void*)f_926},
{"f_932chicken-bug.scm",(void*)f_932},
{"f_939chicken-bug.scm",(void*)f_939},
{"f_942chicken-bug.scm",(void*)f_942},
{"f_918chicken-bug.scm",(void*)f_918},
{"f_909chicken-bug.scm",(void*)f_909},
{"f_819chicken-bug.scm",(void*)f_819},
{"f_851chicken-bug.scm",(void*)f_851},
{"f_881chicken-bug.scm",(void*)f_881},
{"f_893chicken-bug.scm",(void*)f_893},
{"f_899chicken-bug.scm",(void*)f_899},
{"f_887chicken-bug.scm",(void*)f_887},
{"f_857chicken-bug.scm",(void*)f_857},
{"f_863chicken-bug.scm",(void*)f_863},
{"f_870chicken-bug.scm",(void*)f_870},
{"f_873chicken-bug.scm",(void*)f_873},
{"f_849chicken-bug.scm",(void*)f_849},
{"f_823chicken-bug.scm",(void*)f_823},
{"f_839chicken-bug.scm",(void*)f_839},
{"f_801chicken-bug.scm",(void*)f_801},
{"f_817chicken-bug.scm",(void*)f_817},
{"f_813chicken-bug.scm",(void*)f_813},
{"f_809chicken-bug.scm",(void*)f_809},
{"f_613chicken-bug.scm",(void*)f_613},
{"f_624chicken-bug.scm",(void*)f_624},
{"f_756chicken-bug.scm",(void*)f_756},
{"f_628chicken-bug.scm",(void*)f_628},
{"f_635chicken-bug.scm",(void*)f_635},
{"f_639chicken-bug.scm",(void*)f_639},
{"f_671chicken-bug.scm",(void*)f_671},
{"f_643chicken-bug.scm",(void*)f_643},
{"f_663chicken-bug.scm",(void*)f_663},
{"f_647chicken-bug.scm",(void*)f_647},
{"f_655chicken-bug.scm",(void*)f_655},
{"f_651chicken-bug.scm",(void*)f_651},
{"f_572chicken-bug.scm",(void*)f_572},
{"f_597chicken-bug.scm",(void*)f_597},
{"f_590chicken-bug.scm",(void*)f_590},
{"f_582chicken-bug.scm",(void*)f_582},
{"f_585chicken-bug.scm",(void*)f_585},
{"f_429chicken-bug.scm",(void*)f_429},
{"f_529chicken-bug.scm",(void*)f_529},
{"f_570chicken-bug.scm",(void*)f_570},
{"f_566chicken-bug.scm",(void*)f_566},
{"f_545chicken-bug.scm",(void*)f_545},
{"f_541chicken-bug.scm",(void*)f_541},
{"f_433chicken-bug.scm",(void*)f_433},
{"f_527chicken-bug.scm",(void*)f_527},
{"f_523chicken-bug.scm",(void*)f_523},
{"f_436chicken-bug.scm",(void*)f_436},
{"f_439chicken-bug.scm",(void*)f_439},
{"f_519chicken-bug.scm",(void*)f_519},
{"f_442chicken-bug.scm",(void*)f_442},
{"f_448chicken-bug.scm",(void*)f_448},
{"f_498chicken-bug.scm",(void*)f_498},
{"f_502chicken-bug.scm",(void*)f_502},
{"f_473chicken-bug.scm",(void*)f_473},
{"f_477chicken-bug.scm",(void*)f_477},
{"f_483chicken-bug.scm",(void*)f_483},
{"f_487chicken-bug.scm",(void*)f_487},
{"f_481chicken-bug.scm",(void*)f_481},
{"f_463chicken-bug.scm",(void*)f_463},
{"f_410chicken-bug.scm",(void*)f_410},
{"f_414chicken-bug.scm",(void*)f_414},
{"f_391chicken-bug.scm",(void*)f_391},
{"f_408chicken-bug.scm",(void*)f_408},
{"f_401chicken-bug.scm",(void*)f_401},
{"f_395chicken-bug.scm",(void*)f_395},
{"f_382chicken-bug.scm",(void*)f_382},
{"f_386chicken-bug.scm",(void*)f_386},
{"f_192chicken-bug.scm",(void*)f_192},
{"f_196chicken-bug.scm",(void*)f_196},
{"f_199chicken-bug.scm",(void*)f_199},
{"f_380chicken-bug.scm",(void*)f_380},
{"f_376chicken-bug.scm",(void*)f_376},
{"f_202chicken-bug.scm",(void*)f_202},
{"f_372chicken-bug.scm",(void*)f_372},
{"f_368chicken-bug.scm",(void*)f_368},
{"f_205chicken-bug.scm",(void*)f_205},
{"f_208chicken-bug.scm",(void*)f_208},
{"f_364chicken-bug.scm",(void*)f_364},
{"f_211chicken-bug.scm",(void*)f_211},
{"f_360chicken-bug.scm",(void*)f_360},
{"f_214chicken-bug.scm",(void*)f_214},
{"f_356chicken-bug.scm",(void*)f_356},
{"f_217chicken-bug.scm",(void*)f_217},
{"f_352chicken-bug.scm",(void*)f_352},
{"f_220chicken-bug.scm",(void*)f_220},
{"f_348chicken-bug.scm",(void*)f_348},
{"f_223chicken-bug.scm",(void*)f_223},
{"f_344chicken-bug.scm",(void*)f_344},
{"f_226chicken-bug.scm",(void*)f_226},
{"f_229chicken-bug.scm",(void*)f_229},
{"f_232chicken-bug.scm",(void*)f_232},
{"f_340chicken-bug.scm",(void*)f_340},
{"f_336chicken-bug.scm",(void*)f_336},
{"f_332chicken-bug.scm",(void*)f_332},
{"f_299chicken-bug.scm",(void*)f_299},
{"f_303chicken-bug.scm",(void*)f_303},
{"f_308chicken-bug.scm",(void*)f_308},
{"f_316chicken-bug.scm",(void*)f_316},
{"f_235chicken-bug.scm",(void*)f_235},
{"f_238chicken-bug.scm",(void*)f_238},
{"f_297chicken-bug.scm",(void*)f_297},
{"f_283chicken-bug.scm",(void*)f_283},
{"f_285chicken-bug.scm",(void*)f_285},
{"f_293chicken-bug.scm",(void*)f_293},
{"f_241chicken-bug.scm",(void*)f_241},
{"f_244chicken-bug.scm",(void*)f_244},
{"f_279chicken-bug.scm",(void*)f_279},
{"f_253chicken-bug.scm",(void*)f_253},
{"f_256chicken-bug.scm",(void*)f_256},
{"f_261chicken-bug.scm",(void*)f_261},
{"f_269chicken-bug.scm",(void*)f_269},
{"f_247chicken-bug.scm",(void*)f_247},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
