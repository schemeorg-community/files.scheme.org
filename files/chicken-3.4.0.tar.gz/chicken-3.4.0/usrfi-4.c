/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:56
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: srfi-4.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file usrfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[192];
static double C_possibly_force_alignment;


/* from ext-free in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from ext-alloc */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3207)
static void C_fcall f_3207(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3140)
static void C_fcall f_3140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_fcall f_3176(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_fcall f_3129(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3083)
static void C_fcall f_3083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_fcall f_3078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3033)
static void C_fcall f_3033(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_fcall f_3049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2971)
static void C_fcall f_2971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2957)
static void C_fcall f_2957(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2920)
static void C_fcall f_2920(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_fcall f_2935(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2827)
static void C_fcall f_2827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_fcall f_2476(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_fcall f_2447(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2429)
static void C_fcall f_2429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_fcall f_2418(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2303)
static void C_fcall f_2303(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_fcall f_2314(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2185)
static void C_fcall f_2185(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2125)
static void C_fcall f_2125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2115)
static void C_fcall f_2115(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2063)
static void C_fcall f_2063(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_fcall f_2085(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_fcall f_2090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2001)
static void C_fcall f_2001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1939)
static void C_fcall f_1939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_fcall f_1961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_fcall f_1966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1877)
static void C_fcall f_1877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_fcall f_1872(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1867)
static void C_fcall f_1867(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1822)
static void C_fcall f_1822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static C_word C_fcall f_1846(C_word t0,C_word t1);
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1760)
static void C_fcall f_1760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1750)
static void C_fcall f_1750(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1705)
static void C_fcall f_1705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static C_word C_fcall f_1729(C_word t0,C_word t1);
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1643)
static void C_fcall f_1643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_fcall f_1638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1633)
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1588)
static void C_fcall f_1588(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_fcall f_1612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1526)
static void C_fcall f_1526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_fcall f_1516(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1471)
static void C_fcall f_1471(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_fcall f_1495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1409)
static void C_fcall f_1409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1404)
static void C_fcall f_1404(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1399)
static void C_fcall f_1399(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1354)
static void C_fcall f_1354(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_fcall f_1378(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1292)
static void C_fcall f_1292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1282)
static void C_fcall f_1282(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1237)
static void C_fcall f_1237(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_fcall f_1261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1217)
static void C_fcall f_1217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_fcall f_1192(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_fcall f_1101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_fcall f_1012(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_fcall f_995(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_fcall f_981(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_fcall f_938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_929)
static C_word C_fcall f_929(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_926)
static C_word C_fcall f_926(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3207)
static void C_fcall trf_3207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3207(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3207(t0,t1);}

C_noret_decl(trf_3202)
static void C_fcall trf_3202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3202(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3202(t0,t1,t2);}

C_noret_decl(trf_3140)
static void C_fcall trf_3140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3140(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3140(t0,t1,t2,t3);}

C_noret_decl(trf_3176)
static void C_fcall trf_3176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3176(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3176(t0,t1);}

C_noret_decl(trf_3129)
static void C_fcall trf_3129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3129(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3129(t0,t1,t2);}

C_noret_decl(trf_3083)
static void C_fcall trf_3083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3083(t0,t1);}

C_noret_decl(trf_3078)
static void C_fcall trf_3078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3078(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3078(t0,t1,t2);}

C_noret_decl(trf_3033)
static void C_fcall trf_3033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3033(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3033(t0,t1,t2,t3);}

C_noret_decl(trf_3049)
static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3049(t0,t1);}

C_noret_decl(trf_2971)
static void C_fcall trf_2971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2971(t0,t1);}

C_noret_decl(trf_2966)
static void C_fcall trf_2966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2966(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2966(t0,t1,t2);}

C_noret_decl(trf_2957)
static void C_fcall trf_2957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2957(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2957(t0,t1,t2,t3);}

C_noret_decl(trf_2920)
static void C_fcall trf_2920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2920(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2920(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2935)
static void C_fcall trf_2935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2935(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2935(t0,t1,t2);}

C_noret_decl(trf_2827)
static void C_fcall trf_2827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2827(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2827(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2476)
static void C_fcall trf_2476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2476(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2476(t0,t1,t2,t3);}

C_noret_decl(trf_2447)
static void C_fcall trf_2447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2447(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2447(t0,t1,t2,t3);}

C_noret_decl(trf_2429)
static void C_fcall trf_2429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2429(t0,t1,t2);}

C_noret_decl(trf_2418)
static void C_fcall trf_2418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2418(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2418(t0,t1,t2);}

C_noret_decl(trf_2303)
static void C_fcall trf_2303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2303(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2303(t0,t1,t2);}

C_noret_decl(trf_2314)
static void C_fcall trf_2314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2314(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2314(t0,t1,t2);}

C_noret_decl(trf_2185)
static void C_fcall trf_2185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2185(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2185(t0,t1,t2,t3);}

C_noret_decl(trf_2202)
static void C_fcall trf_2202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2202(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2202(t0,t1,t2,t3);}

C_noret_decl(trf_2125)
static void C_fcall trf_2125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2125(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2125(t0,t1);}

C_noret_decl(trf_2120)
static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2120(t0,t1,t2);}

C_noret_decl(trf_2115)
static void C_fcall trf_2115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2115(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2115(t0,t1,t2,t3);}

C_noret_decl(trf_2063)
static void C_fcall trf_2063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2063(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2063(t0,t1,t2,t3);}

C_noret_decl(trf_2085)
static void C_fcall trf_2085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2085(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2085(t0,t1);}

C_noret_decl(trf_2090)
static void C_fcall trf_2090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2090(t0,t1,t2);}

C_noret_decl(trf_2001)
static void C_fcall trf_2001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2001(t0,t1);}

C_noret_decl(trf_1996)
static void C_fcall trf_1996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1996(t0,t1,t2);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1991(t0,t1,t2,t3);}

C_noret_decl(trf_1939)
static void C_fcall trf_1939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1939(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1939(t0,t1,t2,t3);}

C_noret_decl(trf_1961)
static void C_fcall trf_1961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1961(t0,t1);}

C_noret_decl(trf_1966)
static void C_fcall trf_1966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1966(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1966(t0,t1,t2);}

C_noret_decl(trf_1877)
static void C_fcall trf_1877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1877(t0,t1);}

C_noret_decl(trf_1872)
static void C_fcall trf_1872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1872(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1872(t0,t1,t2);}

C_noret_decl(trf_1867)
static void C_fcall trf_1867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1867(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1867(t0,t1,t2,t3);}

C_noret_decl(trf_1822)
static void C_fcall trf_1822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1822(t0,t1,t2,t3);}

C_noret_decl(trf_1760)
static void C_fcall trf_1760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1760(t0,t1);}

C_noret_decl(trf_1755)
static void C_fcall trf_1755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1755(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1755(t0,t1,t2);}

C_noret_decl(trf_1750)
static void C_fcall trf_1750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1750(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1750(t0,t1,t2,t3);}

C_noret_decl(trf_1705)
static void C_fcall trf_1705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1705(t0,t1,t2,t3);}

C_noret_decl(trf_1643)
static void C_fcall trf_1643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1643(t0,t1);}

C_noret_decl(trf_1638)
static void C_fcall trf_1638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1638(t0,t1,t2);}

C_noret_decl(trf_1633)
static void C_fcall trf_1633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1633(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1633(t0,t1,t2,t3);}

C_noret_decl(trf_1588)
static void C_fcall trf_1588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1588(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1588(t0,t1,t2,t3);}

C_noret_decl(trf_1612)
static void C_fcall trf_1612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1612(t0,t1,t2);}

C_noret_decl(trf_1526)
static void C_fcall trf_1526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1526(t0,t1);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1521(t0,t1,t2);}

C_noret_decl(trf_1516)
static void C_fcall trf_1516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1516(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1516(t0,t1,t2,t3);}

C_noret_decl(trf_1471)
static void C_fcall trf_1471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1471(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1471(t0,t1,t2,t3);}

C_noret_decl(trf_1495)
static void C_fcall trf_1495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1495(t0,t1,t2);}

C_noret_decl(trf_1409)
static void C_fcall trf_1409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1409(t0,t1);}

C_noret_decl(trf_1404)
static void C_fcall trf_1404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1404(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1404(t0,t1,t2);}

C_noret_decl(trf_1399)
static void C_fcall trf_1399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1399(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1399(t0,t1,t2,t3);}

C_noret_decl(trf_1354)
static void C_fcall trf_1354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1354(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1354(t0,t1,t2,t3);}

C_noret_decl(trf_1378)
static void C_fcall trf_1378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1378(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1378(t0,t1,t2);}

C_noret_decl(trf_1292)
static void C_fcall trf_1292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1292(t0,t1);}

C_noret_decl(trf_1287)
static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1287(t0,t1,t2);}

C_noret_decl(trf_1282)
static void C_fcall trf_1282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1282(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1282(t0,t1,t2,t3);}

C_noret_decl(trf_1237)
static void C_fcall trf_1237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1237(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1237(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1261)
static void C_fcall trf_1261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1261(t0,t1,t2);}

C_noret_decl(trf_1217)
static void C_fcall trf_1217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1217(t0,t1);}

C_noret_decl(trf_1192)
static void C_fcall trf_1192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1192(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1192(t0,t1,t2,t3);}

C_noret_decl(trf_1101)
static void C_fcall trf_1101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1101(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1101(t0,t1,t2,t3);}

C_noret_decl(trf_1012)
static void C_fcall trf_1012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1012(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1012(t0,t1,t2,t3);}

C_noret_decl(trf_995)
static void C_fcall trf_995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_995(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_995(t0,t1,t2,t3);}

C_noret_decl(trf_981)
static void C_fcall trf_981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_981(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_981(t0,t1,t2,t3);}

C_noret_decl(trf_938)
static void C_fcall trf_938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_938(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(42);
if(!C_demand(42)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1714)){
C_save(t1);
C_rereclaim2(1714*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(42);
C_initialize_lf(lf,192);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscheck-exact-interval");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[5]=C_h_intern(&lf[5],26,"\003syscheck-inexact-interval");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[14]=C_h_intern(&lf[14],15,"\003syscons-flonum");
lf[24]=C_h_intern(&lf[24],15,"u8vector-length");
lf[25]=C_h_intern(&lf[25],15,"s8vector-length");
lf[26]=C_h_intern(&lf[26],16,"u16vector-length");
lf[27]=C_h_intern(&lf[27],16,"s16vector-length");
lf[28]=C_h_intern(&lf[28],16,"u32vector-length");
lf[29]=C_h_intern(&lf[29],16,"s32vector-length");
lf[30]=C_h_intern(&lf[30],16,"f32vector-length");
lf[31]=C_h_intern(&lf[31],16,"f64vector-length");
lf[32]=C_h_intern(&lf[32],15,"\003syscheck-range");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[34]=C_h_intern(&lf[34],13,"u8vector-set!");
lf[35]=C_h_intern(&lf[35],13,"s8vector-set!");
lf[36]=C_h_intern(&lf[36],14,"u16vector-set!");
lf[37]=C_h_intern(&lf[37],14,"s16vector-set!");
lf[38]=C_h_intern(&lf[38],14,"u32vector-set!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[41]=C_h_intern(&lf[41],14,"s32vector-set!");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[43]=C_h_intern(&lf[43],14,"f32vector-set!");
lf[44]=C_h_intern(&lf[44],14,"f64vector-set!");
lf[45]=C_h_intern(&lf[45],12,"u8vector-ref");
lf[46]=C_h_intern(&lf[46],12,"s8vector-ref");
lf[47]=C_h_intern(&lf[47],13,"u16vector-ref");
lf[48]=C_h_intern(&lf[48],13,"s16vector-ref");
lf[49]=C_h_intern(&lf[49],13,"u32vector-ref");
lf[50]=C_h_intern(&lf[50],13,"s32vector-ref");
lf[51]=C_h_intern(&lf[51],13,"f32vector-ref");
lf[52]=C_h_intern(&lf[52],13,"f64vector-ref");
lf[53]=C_h_intern(&lf[53],14,"set-finalizer!");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000;not enough memory - can not allocate external number vector");
lf[55]=C_h_intern(&lf[55],19,"\003sysallocate-vector");
lf[56]=C_h_intern(&lf[56],21,"release-number-vector");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[59]=C_h_intern(&lf[59],13,"make-u8vector");
lf[60]=C_h_intern(&lf[60],8,"u8vector");
lf[61]=C_h_intern(&lf[61],13,"make-s8vector");
lf[62]=C_h_intern(&lf[62],8,"s8vector");
lf[63]=C_h_intern(&lf[63],4,"fin\077");
lf[64]=C_h_intern(&lf[64],14,"make-u16vector");
lf[65]=C_h_intern(&lf[65],9,"u16vector");
lf[66]=C_h_intern(&lf[66],14,"make-s16vector");
lf[67]=C_h_intern(&lf[67],9,"s16vector");
lf[68]=C_h_intern(&lf[68],14,"make-u32vector");
lf[69]=C_h_intern(&lf[69],9,"u32vector");
lf[70]=C_h_intern(&lf[70],14,"make-s32vector");
lf[71]=C_h_intern(&lf[71],9,"s32vector");
lf[72]=C_h_intern(&lf[72],14,"make-f32vector");
lf[73]=C_h_intern(&lf[73],9,"f32vector");
lf[74]=C_h_intern(&lf[74],14,"make-f64vector");
lf[75]=C_h_intern(&lf[75],9,"f64vector");
lf[76]=C_h_intern(&lf[76],27,"\003sysnot-a-proper-list-error");
lf[77]=C_h_intern(&lf[77],14,"list->u8vector");
lf[78]=C_h_intern(&lf[78],14,"list->s8vector");
lf[79]=C_h_intern(&lf[79],15,"list->u16vector");
lf[80]=C_h_intern(&lf[80],15,"list->s16vector");
lf[81]=C_h_intern(&lf[81],15,"list->u32vector");
lf[82]=C_h_intern(&lf[82],15,"list->s32vector");
lf[83]=C_h_intern(&lf[83],15,"list->f32vector");
lf[84]=C_h_intern(&lf[84],15,"list->f64vector");
lf[85]=C_h_intern(&lf[85],14,"u8vector->list");
lf[86]=C_h_intern(&lf[86],14,"s8vector->list");
lf[87]=C_h_intern(&lf[87],15,"u16vector->list");
lf[88]=C_h_intern(&lf[88],15,"s16vector->list");
lf[89]=C_h_intern(&lf[89],15,"u32vector->list");
lf[90]=C_h_intern(&lf[90],15,"s32vector->list");
lf[91]=C_h_intern(&lf[91],15,"f32vector->list");
lf[92]=C_h_intern(&lf[92],15,"f64vector->list");
lf[93]=C_h_intern(&lf[93],9,"u8vector\077");
lf[94]=C_h_intern(&lf[94],9,"s8vector\077");
lf[95]=C_h_intern(&lf[95],10,"u16vector\077");
lf[96]=C_h_intern(&lf[96],10,"s16vector\077");
lf[97]=C_h_intern(&lf[97],10,"u32vector\077");
lf[98]=C_h_intern(&lf[98],10,"s32vector\077");
lf[99]=C_h_intern(&lf[99],10,"f32vector\077");
lf[100]=C_h_intern(&lf[100],10,"f64vector\077");
lf[101]=C_h_intern(&lf[101],13,"\003sysmake-blob");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[104]=C_h_intern(&lf[104],21,"u8vector->byte-vector");
lf[105]=C_h_intern(&lf[105],21,"s8vector->byte-vector");
lf[106]=C_h_intern(&lf[106],22,"u16vector->byte-vector");
lf[107]=C_h_intern(&lf[107],22,"s16vector->byte-vector");
lf[108]=C_h_intern(&lf[108],22,"u32vector->byte-vector");
lf[109]=C_h_intern(&lf[109],22,"s32vector->byte-vector");
lf[110]=C_h_intern(&lf[110],22,"f32vector->byte-vector");
lf[111]=C_h_intern(&lf[111],22,"f64vector->byte-vector");
lf[112]=C_h_intern(&lf[112],21,"u8vector->blob/shared");
lf[113]=C_h_intern(&lf[113],21,"s8vector->blob/shared");
lf[114]=C_h_intern(&lf[114],22,"u16vector->blob/shared");
lf[115]=C_h_intern(&lf[115],22,"s16vector->blob/shared");
lf[116]=C_h_intern(&lf[116],22,"u32vector->blob/shared");
lf[117]=C_h_intern(&lf[117],22,"s32vector->blob/shared");
lf[118]=C_h_intern(&lf[118],22,"f32vector->blob/shared");
lf[119]=C_h_intern(&lf[119],22,"f64vector->blob/shared");
lf[120]=C_h_intern(&lf[120],14,"u8vector->blob");
lf[121]=C_h_intern(&lf[121],14,"s8vector->blob");
lf[122]=C_h_intern(&lf[122],15,"u16vector->blob");
lf[123]=C_h_intern(&lf[123],15,"s16vector->blob");
lf[124]=C_h_intern(&lf[124],15,"u32vector->blob");
lf[125]=C_h_intern(&lf[125],15,"s32vector->blob");
lf[126]=C_h_intern(&lf[126],15,"f32vector->blob");
lf[127]=C_h_intern(&lf[127],15,"f64vector->blob");
lf[128]=C_h_intern(&lf[128],21,"byte-vector->u8vector");
lf[129]=C_h_intern(&lf[129],21,"byte-vector->s8vector");
lf[130]=C_h_intern(&lf[130],22,"byte-vector->u16vector");
lf[131]=C_h_intern(&lf[131],22,"byte-vector->s16vector");
lf[132]=C_h_intern(&lf[132],22,"byte-vector->u32vector");
lf[133]=C_h_intern(&lf[133],22,"byte-vector->s32vector");
lf[134]=C_h_intern(&lf[134],22,"byte-vector->f32vector");
lf[135]=C_h_intern(&lf[135],22,"byte-vector->f64vector");
lf[136]=C_h_intern(&lf[136],21,"blob->u8vector/shared");
lf[137]=C_h_intern(&lf[137],21,"blob->s8vector/shared");
lf[138]=C_h_intern(&lf[138],22,"blob->u16vector/shared");
lf[139]=C_h_intern(&lf[139],22,"blob->s16vector/shared");
lf[140]=C_h_intern(&lf[140],22,"blob->u32vector/shared");
lf[141]=C_h_intern(&lf[141],22,"blob->s32vector/shared");
lf[142]=C_h_intern(&lf[142],22,"blob->f32vector/shared");
lf[143]=C_h_intern(&lf[143],22,"blob->f64vector/shared");
lf[144]=C_h_intern(&lf[144],14,"blob->u8vector");
lf[145]=C_h_intern(&lf[145],14,"blob->s8vector");
lf[146]=C_h_intern(&lf[146],15,"blob->u16vector");
lf[147]=C_h_intern(&lf[147],15,"blob->s16vector");
lf[148]=C_h_intern(&lf[148],15,"blob->u32vector");
lf[149]=C_h_intern(&lf[149],15,"blob->s32vector");
lf[150]=C_h_intern(&lf[150],15,"blob->f32vector");
lf[151]=C_h_intern(&lf[151],15,"blob->f64vector");
lf[152]=C_h_intern(&lf[152],18,"\003sysuser-read-hook");
lf[153]=C_h_intern(&lf[153],4,"read");
lf[154]=C_h_intern(&lf[154],2,"u8");
lf[155]=C_h_intern(&lf[155],2,"s8");
lf[156]=C_h_intern(&lf[156],3,"u16");
lf[157]=C_h_intern(&lf[157],3,"s16");
lf[158]=C_h_intern(&lf[158],3,"u32");
lf[159]=C_h_intern(&lf[159],3,"s32");
lf[160]=C_h_intern(&lf[160],3,"f32");
lf[161]=C_h_intern(&lf[161],3,"f64");
lf[162]=C_h_intern(&lf[162],1,"f");
lf[163]=C_h_intern(&lf[163],1,"F");
lf[164]=C_h_intern(&lf[164],14,"\003sysread-error");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[166]=C_h_intern(&lf[166],19,"\003sysuser-print-hook");
lf[167]=C_h_intern(&lf[167],9,"\003sysprint");
lf[169]=C_h_intern(&lf[169],11,"subu8vector");
lf[170]=C_h_intern(&lf[170],12,"subu16vector");
lf[171]=C_h_intern(&lf[171],12,"subu32vector");
lf[172]=C_h_intern(&lf[172],11,"subs8vector");
lf[173]=C_h_intern(&lf[173],12,"subs16vector");
lf[174]=C_h_intern(&lf[174],12,"subs32vector");
lf[175]=C_h_intern(&lf[175],12,"subf32vector");
lf[176]=C_h_intern(&lf[176],12,"subf64vector");
lf[177]=C_h_intern(&lf[177],14,"write-u8vector");
lf[178]=C_h_intern(&lf[178],16,"\003syswrite-char-0");
lf[179]=C_h_intern(&lf[179],14,"\003syscheck-port");
lf[180]=C_h_intern(&lf[180],19,"\003sysstandard-output");
lf[181]=C_h_intern(&lf[181],14,"read-u8vector!");
lf[182]=C_h_intern(&lf[182],16,"\003sysread-string!");
lf[183]=C_h_intern(&lf[183],18,"\003sysstandard-input");
lf[184]=C_h_intern(&lf[184],18,"open-output-string");
lf[185]=C_h_intern(&lf[185],17,"get-output-string");
lf[186]=C_h_intern(&lf[186],13,"read-u8vector");
lf[187]=C_h_intern(&lf[187],19,"\003syswrite-char/port");
lf[188]=C_h_intern(&lf[188],15,"\003sysread-char-0");
lf[189]=C_h_intern(&lf[189],17,"register-feature!");
lf[190]=C_h_intern(&lf[190],6,"srfi-4");
lf[191]=C_h_intern(&lf[191],18,"getter-with-setter");
C_register_lf2(lf,192,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_848,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_863,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_884,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_887,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_890,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_893,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_896,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_899,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_902,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_908,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_914,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_917,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_920,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_923,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[20],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_926,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_929,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[22],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_932,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[23],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_935,tmp=(C_word)a,a+=2,tmp));
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_938,tmp=(C_word)a,a+=2,tmp);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=t21,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 155  len */
f_938(t22,lf[60],C_SCHEME_FALSE,lf[24]);}

/* k949 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 156  len */
f_938(t3,lf[62],C_SCHEME_FALSE,lf[25]);}

/* k953 in k949 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 157  len */
f_938(t3,lf[65],C_fix(1),lf[26]);}

/* k957 in k953 in k949 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 158  len */
f_938(t3,lf[67],C_fix(1),lf[27]);}

/* k961 in k957 in k953 in k949 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 159  len */
f_938(t3,lf[69],C_fix(2),lf[28]);}

/* k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 160  len */
f_938(t3,lf[71],C_fix(2),lf[29]);}

/* k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 161  len */
f_938(t3,lf[73],C_fix(2),lf[30]);}

/* k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 162  len */
f_938(t3,lf[75],C_fix(3),lf[31]);}

/* k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_981,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_995,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1012,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1101,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1127,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 218  setu */
f_1012(t7,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 219  set */
f_995(t3,*((C_word*)lf[25]+1),lf[17],lf[35]);}

/* k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 220  setu */
f_1012(t3,*((C_word*)lf[26]+1),lf[18],lf[36]);}

/* k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 221  set */
f_995(t3,*((C_word*)lf[27]+1),lf[19],lf[37]);}

/* k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=*((C_word*)lf[28]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_mutate((C_word*)lf[38]+1,t4);
t6=*((C_word*)lf[29]+1);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_mutate((C_word*)lf[41]+1,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 224  setf */
f_1101(t9,*((C_word*)lf[30]+1),lf[22],lf[43]);}

/* k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 225  setf */
f_1101(t3,*((C_word*)lf[31]+1),lf[23],lf[44]);}

/* k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3285,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 228  get */
f_981(t4,*((C_word*)lf[24]+1),lf[7],lf[45]);}

/* k3283 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 228  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 231  get */
f_981(t4,*((C_word*)lf[25]+1),lf[8],lf[46]);}

/* k3279 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 231  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 234  get */
f_981(t4,*((C_word*)lf[26]+1),lf[9],lf[47]);}

/* k3275 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 234  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 237  get */
f_981(t4,*((C_word*)lf[27]+1),lf[10],lf[48]);}

/* k3271 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 237  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[37]+1));}

/* k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 241  get */
f_981(t4,*((C_word*)lf[28]+1),lf[11],lf[49]);}

/* k3267 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 240  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[38]+1));}

/* k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 245  get */
f_981(t4,*((C_word*)lf[29]+1),lf[12],lf[50]);}

/* k3263 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 244  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3261,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 249  get */
f_981(t4,*((C_word*)lf[30]+1),lf[13],lf[51]);}

/* k3259 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 248  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[43]+1));}

/* k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 253  get */
f_981(t4,*((C_word*)lf[31]+1),lf[15],lf[52]);}

/* k3255 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 252  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[44]+1));}

/* k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1190,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[53]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1192,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1210,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1235,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1352,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1469,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1586,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1703,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1820,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1937,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2061,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2185,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2225,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 412  init */
f_2185(t16,*((C_word*)lf[59]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 413  init */
f_2185(t3,*((C_word*)lf[61]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 414  init */
f_2185(t3,*((C_word*)lf[64]+1),*((C_word*)lf[36]+1),lf[79]);}

/* k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 415  init */
f_2185(t3,*((C_word*)lf[66]+1),*((C_word*)lf[37]+1),lf[80]);}

/* k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 416  init */
f_2185(t3,*((C_word*)lf[68]+1),*((C_word*)lf[38]+1),lf[81]);}

/* k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 417  init */
f_2185(t3,*((C_word*)lf[70]+1),*((C_word*)lf[41]+1),lf[82]);}

/* k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 418  init */
f_2185(t3,*((C_word*)lf[72]+1),*((C_word*)lf[43]+1),lf[83]);}

/* k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 419  init */
f_2185(t3,*((C_word*)lf[74]+1),*((C_word*)lf[44]+1),lf[84]);}

/* k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=*((C_word*)lf[77]+1);
t4=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[78]+1);
t6=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[79]+1);
t8=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[80]+1);
t10=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2273,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[81]+1);
t12=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[82]+1);
t14=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[83]+1);
t16=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[84]+1);
t18=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2303,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2340,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 470  init */
f_2303(t20,*((C_word*)lf[24]+1),lf[7]);}

/* k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 471  init */
f_2303(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 472  init */
f_2303(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 473  init */
f_2303(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2352,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 474  init */
f_2303(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 475  init */
f_2303(t3,*((C_word*)lf[29]+1),lf[12]);}

/* k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 476  init */
f_2303(t3,*((C_word*)lf[30]+1),lf[13]);}

/* k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 477  init */
f_2303(t3,*((C_word*)lf[31]+1),lf[15]);}

/* k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1,t1);
t3=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2370,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2376,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2382,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2388,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2394,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2400,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2406,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2412,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2418,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2429,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2447,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2476,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2510,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 529  pack */
f_2418(t15,lf[60],lf[104]);}

/* k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 530  pack */
f_2418(t3,lf[62],lf[105]);}

/* k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 531  pack */
f_2418(t3,lf[65],lf[106]);}

/* k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 532  pack */
f_2418(t3,lf[67],lf[107]);}

/* k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 533  pack */
f_2418(t3,lf[69],lf[108]);}

/* k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 534  pack */
f_2418(t3,lf[71],lf[109]);}

/* k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 535  pack */
f_2418(t3,lf[73],lf[110]);}

/* k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 536  pack */
f_2418(t3,lf[75],lf[111]);}

/* k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 538  pack */
f_2418(t3,lf[60],lf[112]);}

/* k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 539  pack */
f_2418(t3,lf[62],lf[113]);}

/* k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 540  pack */
f_2418(t3,lf[65],lf[114]);}

/* k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 541  pack */
f_2418(t3,lf[67],lf[115]);}

/* k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 542  pack */
f_2418(t3,lf[69],lf[116]);}

/* k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 543  pack */
f_2418(t3,lf[71],lf[117]);}

/* k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 544  pack */
f_2418(t3,lf[73],lf[118]);}

/* k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 545  pack */
f_2418(t3,lf[75],lf[119]);}

/* k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 547  pack-copy */
f_2429(t3,lf[60],lf[120]);}

/* k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 548  pack-copy */
f_2429(t3,lf[62],lf[121]);}

/* k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2578,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 549  pack-copy */
f_2429(t3,lf[65],lf[122]);}

/* k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 550  pack-copy */
f_2429(t3,lf[67],lf[123]);}

/* k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 551  pack-copy */
f_2429(t3,lf[69],lf[124]);}

/* k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2590,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 552  pack-copy */
f_2429(t3,lf[71],lf[125]);}

/* k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 553  pack-copy */
f_2429(t3,lf[73],lf[126]);}

/* k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 554  pack-copy */
f_2429(t3,lf[75],lf[127]);}

/* k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 556  unpack */
f_2447(t3,lf[60],C_SCHEME_TRUE,lf[128]);}

/* k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 557  unpack */
f_2447(t3,lf[62],C_SCHEME_TRUE,lf[129]);}

/* k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 558  unpack */
f_2447(t3,lf[65],C_fix(2),lf[130]);}

/* k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 559  unpack */
f_2447(t3,lf[67],C_fix(2),lf[131]);}

/* k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 560  unpack */
f_2447(t3,lf[69],C_fix(4),lf[132]);}

/* k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 561  unpack */
f_2447(t3,lf[71],C_fix(4),lf[133]);}

/* k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 562  unpack */
f_2447(t3,lf[73],C_fix(4),lf[134]);}

/* k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=C_mutate((C_word*)lf[134]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 563  unpack */
f_2447(t3,lf[75],C_fix(8),lf[135]);}

/* k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=C_mutate((C_word*)lf[135]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 565  unpack */
f_2447(t3,lf[60],C_SCHEME_TRUE,lf[136]);}

/* k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 566  unpack */
f_2447(t3,lf[62],C_SCHEME_TRUE,lf[137]);}

/* k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=C_mutate((C_word*)lf[137]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 567  unpack */
f_2447(t3,lf[65],C_fix(2),lf[138]);}

/* k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=C_mutate((C_word*)lf[138]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 568  unpack */
f_2447(t3,lf[67],C_fix(2),lf[139]);}

/* k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=C_mutate((C_word*)lf[139]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 569  unpack */
f_2447(t3,lf[69],C_fix(4),lf[140]);}

/* k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=C_mutate((C_word*)lf[140]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 570  unpack */
f_2447(t3,lf[71],C_fix(4),lf[141]);}

/* k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=C_mutate((C_word*)lf[141]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 571  unpack */
f_2447(t3,lf[73],C_fix(4),lf[142]);}

/* k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=C_mutate((C_word*)lf[142]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 572  unpack */
f_2447(t3,lf[75],C_fix(8),lf[143]);}

/* k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=C_mutate((C_word*)lf[143]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 574  unpack-copy */
f_2476(t3,lf[60],C_SCHEME_TRUE,lf[144]);}

/* k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=C_mutate((C_word*)lf[144]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 575  unpack-copy */
f_2476(t3,lf[62],C_SCHEME_TRUE,lf[145]);}

/* k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=C_mutate((C_word*)lf[145]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 576  unpack-copy */
f_2476(t3,lf[65],C_fix(2),lf[146]);}

/* k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=C_mutate((C_word*)lf[146]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 577  unpack-copy */
f_2476(t3,lf[67],C_fix(2),lf[147]);}

/* k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=C_mutate((C_word*)lf[147]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 578  unpack-copy */
f_2476(t3,lf[69],C_fix(4),lf[148]);}

/* k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 579  unpack-copy */
f_2476(t3,lf[71],C_fix(4),lf[149]);}

/* k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=C_mutate((C_word*)lf[149]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 580  unpack-copy */
f_2476(t3,lf[73],C_fix(4),lf[150]);}

/* k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
t2=C_mutate((C_word*)lf[150]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 581  unpack-copy */
f_2476(t3,lf[75],C_fix(8),lf[151]);}

/* k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=C_mutate((C_word*)lf[151]+1,t1);
t3=*((C_word*)lf[152]+1);
t4=*((C_word*)lf[153]+1);
t5=(C_word)C_a_i_list(&a,16,lf[154],*((C_word*)lf[77]+1),lf[155],*((C_word*)lf[78]+1),lf[156],*((C_word*)lf[79]+1),lf[157],*((C_word*)lf[80]+1),lf[158],*((C_word*)lf[81]+1),lf[159],*((C_word*)lf[82]+1),lf[160],*((C_word*)lf[83]+1),lf[161],*((C_word*)lf[84]+1));
t6=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2703,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[166]+1);
t8=C_mutate((C_word*)lf[166]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2759,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[168],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2827,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2870,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2876,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2882,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2888,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2894,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2900,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2906,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2912,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[177]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2918,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3031,tmp=(C_word)a,a+=2,tmp));
t20=*((C_word*)lf[184]+1);
t21=*((C_word*)lf[185]+1);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3129,tmp=(C_word)a,a+=2,tmp);
t23=C_mutate((C_word*)lf[186]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3138,a[2]=t20,a[3]=t21,a[4]=t22,tmp=(C_word)a,a+=5,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 703  register-feature! */
t25=*((C_word*)lf[189]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,lf[190]);}

/* k3251 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_3138r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3138r(t0,t1,t2);}}

static void C_ccall f_3138r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n761781 */
t6=t5;
f_3207(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p762779 */
t8=t4;
f_3202(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body759764 */
t10=t3;
f_3140(t10,t1,t6,t8);}}}

/* def-n761 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3207(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3207,NULL,2,t0,t1);}
/* def-p762779 */
t2=((C_word*)t0)[2];
f_3202(t2,t1,C_SCHEME_FALSE);}

/* def-p762 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3202,NULL,3,t0,t1,t2);}
/* body759764 */
t3=((C_word*)t0)[2];
f_3140(t3,t1,t2,*((C_word*)lf[183]+1));}

/* body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3140,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 683  ##sys#check-port */
t5=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[186]);}

/* k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[186]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 685  ##sys#allocate-vector */
t4=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 692  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3169 in k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3176(t5,((C_word*)t0)[2]);}

/* loop in k3169 in k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3176(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3176,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 694  ##sys#read-char-0 */
t3=*((C_word*)lf[188]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3178 in loop in k3169 in k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 696  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 700  ##sys#write-char/port */
t3=*((C_word*)lf[187]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k3196 in k3178 in loop in k3169 in k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 701  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3176(t2,((C_word*)t0)[2]);}

/* k3187 in k3178 in loop in k3169 in k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 698  wrap */
f_3129(((C_word*)t0)[2],t1,t2);}

/* k3151 in k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3156,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 686  ##sys#read-string! */
t3=*((C_word*)lf[182]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3154 in k3151 in k3142 in body759 in read-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 690  wrap */
f_3129(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3129(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3129,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3137,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 678  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3135 in wrap in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],t1));}

/* read-u8vector! in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3031r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3031r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port728742 */
t9=t8;
f_3083(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start729740 */
t11=t7;
f_3078(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body726731 */
t13=t6;
f_3033(t13,t1,t9,t11);}}}

/* def-port728 in read-u8vector! in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3083,NULL,2,t0,t1);}
/* def-start729740 */
t2=((C_word*)t0)[2];
f_3078(t2,t1,*((C_word*)lf[183]+1));}

/* def-start729 in read-u8vector! in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3078,NULL,3,t0,t1,t2);}
/* body726731 */
t3=((C_word*)t0)[2];
f_3033(t3,t1,t2,C_fix(0));}

/* body726 in read-u8vector! in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3033(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3033,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3037,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 662  ##sys#check-port */
t5=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[181]);}

/* k3035 in body726 in read-u8vector! in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[181]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[60],lf[181]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[181]);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(C_word)C_block_size(t4);
t10=(C_word)C_u_fixnum_difference(t9,((C_word*)t0)[6]);
t11=C_mutate(((C_word *)((C_word*)t0)[3])+1,t10);
t12=t5;
f_3049(t12,t11);}
else{
t9=t5;
f_3049(t9,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_3049(t6,C_SCHEME_UNDEFINED);}}

/* k3047 in k3035 in body726 in read-u8vector! in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 670  ##sys#read-string! */
t2=*((C_word*)lf[182]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2918r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2918r(t0,t1,t2,t3);}}

static void C_ccall f_2918r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2920,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2957,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2966,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port692713 */
t8=t7;
f_2971(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from693711 */
t10=t6;
f_2966(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to694708 */
t12=t5;
f_2957(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body690696 */
t14=t4;
f_2920(t14,t1,t8,t10,t12);}}}}

/* def-port692 in write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2971,NULL,2,t0,t1);}
/* def-from693711 */
t2=((C_word*)t0)[2];
f_2966(t2,t1,*((C_word*)lf[180]+1));}

/* def-from693 in write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2966,NULL,3,t0,t1,t2);}
/* def-to694708 */
t3=((C_word*)t0)[2];
f_2957(t3,t1,t2,C_fix(0));}

/* def-to694 in write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2957(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2957,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_8vector_length(((C_word*)t0)[3]);
/* body690696 */
t5=((C_word*)t0)[2];
f_2920(t5,t1,t2,t3,t4);}

/* body690 in write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2920(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2920,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[60],lf[177]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2927,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 655  ##sys#check-port */
t7=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[177]);}

/* k2925 in body690 in write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2935(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do701 in k2925 in body690 in write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2935(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2935,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2945,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 659  ##sys#write-char-0 */
t5=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* k2943 in do701 in k2925 in body690 in write-u8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2935(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2912,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 651  subvector */
f_2827(t1,t2,lf[75],C_fix(8),t3,t4,lf[176]);}

/* subf32vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2906,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 650  subvector */
f_2827(t1,t2,lf[73],C_fix(4),t3,t4,lf[175]);}

/* subs32vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2900,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 649  subvector */
f_2827(t1,t2,lf[71],C_fix(4),t3,t4,lf[174]);}

/* subs16vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2894,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 648  subvector */
f_2827(t1,t2,lf[67],C_fix(2),t3,t4,lf[173]);}

/* subs8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2888,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 647  subvector */
f_2827(t1,t2,lf[62],C_fix(1),t3,t4,lf[172]);}

/* subu32vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2882,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 646  subvector */
f_2827(t1,t2,lf[69],C_fix(4),t3,t4,lf[171]);}

/* subu16vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2876,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 645  subvector */
f_2827(t1,t2,lf[65],C_fix(2),t3,t4,lf[170]);}

/* subu8vector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2870,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 644  subvector */
f_2827(t1,t2,lf[60],C_fix(1),t3,t4,lf[169]);}

/* subvector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2827(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2827,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2840,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_u_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 635  ##sys#check-range */
t14=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k2838 in subvector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 636  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k2841 in k2838 in subvector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 638  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2847 in k2841 in k2838 in subvector in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2849,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2759,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,3,lf[60],lf[154],*((C_word*)lf[85]+1));
t6=(C_word)C_a_i_list(&a,3,lf[62],lf[155],*((C_word*)lf[86]+1));
t7=(C_word)C_a_i_list(&a,3,lf[65],lf[156],*((C_word*)lf[87]+1));
t8=(C_word)C_a_i_list(&a,3,lf[67],lf[157],*((C_word*)lf[88]+1));
t9=(C_word)C_a_i_list(&a,3,lf[69],lf[158],*((C_word*)lf[89]+1));
t10=(C_word)C_a_i_list(&a,3,lf[71],lf[159],*((C_word*)lf[90]+1));
t11=(C_word)C_a_i_list(&a,3,lf[73],lf[160],*((C_word*)lf[91]+1));
t12=(C_word)C_a_i_list(&a,3,lf[75],lf[161],*((C_word*)lf[92]+1));
t13=(C_word)C_a_i_list(&a,8,t5,t6,t7,t8,t9,t10,t11,t12);
t14=(C_word)C_u_i_assq((C_word)C_slot(t2,C_fix(0)),t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2769,a[2]=t2,a[3]=t14,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 622  ##sys#print */
t16=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 625  old-hook */
t15=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t1,t2,t3,t4);}}

/* k2767 in ##sys#user-print-hook in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* srfi-4.scm: 623  ##sys#print */
t4=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2770 in k2767 in ##sys#user-print-hook in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}

/* k2777 in k2770 in k2767 in ##sys#user-print-hook in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 624  ##sys#print */
t2=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2703,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2713,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 599  read */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 604  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2711 in ##sys#user-read-hook in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[162]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[163]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 602  read */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 603  ##sys#read-error */
t7=*((C_word*)lf[164]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[5],((C_word*)t0)[2],lf[165],t3);}}}

/* k2736 in k2711 in ##sys#user-read-hook in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2516 in k2512 in k2508 in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t1);}

/* unpack-copy in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2476(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2476,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2478,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2478 in unpack-copy in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2478,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 521  ##sys#make-blob */
t6=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2486 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 527  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[103],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2447(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2447,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2449,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2449 in unpack in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2449,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 515  ##sys#error */
t7=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[102],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2429(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2429,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2431,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_2431 in pack-copy in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2431,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2441,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 505  ##sys#make-blob */
t7=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k2439 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* pack in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2418(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2418,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2420,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_2420 in pack in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2420,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2412,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[75]));}

/* f32vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2406,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[73]));}

/* s32vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2400,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* u32vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2394,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[69]));}

/* s16vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2388,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* u16vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2382,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[65]));}

/* s8vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2376,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[62]));}

/* u8vector? in k2366 in k2362 in k2358 in k2354 in k2350 in k2346 in k2342 in k2338 in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2370,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[60]));}

/* init in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2303(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2303,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_2305 in init in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2305,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2309,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 463  length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2307 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2314(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2307 */
static void C_fcall f_2314(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2314,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 467  ref */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2326 in loop in k2307 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2332,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 468  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2314(t4,t2,t3);}

/* k2330 in k2326 in loop in k2307 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2297r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2297r(t0,t1,t2);}}

static void C_ccall f_2297r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 454  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f32vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2291r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2291r(t0,t1,t2);}}

static void C_ccall f_2291r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 450  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s32vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2285r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2285r(t0,t1,t2);}}

static void C_ccall f_2285r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 446  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u32vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2279r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2279r(t0,t1,t2);}}

static void C_ccall f_2279r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 442  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s16vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2273r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2273r(t0,t1,t2);}}

static void C_ccall f_2273r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 438  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u16vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2267r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2267r(t0,t1,t2);}}

static void C_ccall f_2267r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 434  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s8vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2261r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2261r(t0,t1,t2);}}

static void C_ccall f_2261r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 430  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u8vector in k2251 in k2247 in k2243 in k2239 in k2235 in k2231 in k2227 in k2223 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2255r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2255r(t0,t1,t2);}}

static void C_ccall f_2255r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 426  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* init in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2185(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2185,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2187,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2187 in init in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2187,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2197,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 404  make */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2195 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2202(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do486 in k2195 */
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2202,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2209,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 409  set */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 410  ##sys#not-a-proper-list-error */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2207 in do486 in k2195 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2202(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2061r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2061r(t0,t1,t2,t3);}}

static void C_ccall f_2061r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init441464 */
t8=t7;
f_2125(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?442462 */
t10=t6;
f_2120(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin443459 */
t12=t5;
f_2115(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body439445 */
t14=t4;
f_2063(t14,t1,t8,t10);}}}}

/* def-init441 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2125,NULL,2,t0,t1);}
/* def-ext?442462 */
t2=((C_word*)t0)[2];
f_2120(t2,t1,C_SCHEME_FALSE);}

/* def-ext?442 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2120,NULL,3,t0,t1,t2);}
/* def-fin443459 */
t3=((C_word*)t0)[2];
f_2115(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin443 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2115(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2115,NULL,4,t0,t1,t2,t3);}
/* body439445 */
t4=((C_word*)t0)[2];
f_2063(t4,t1,t2,t3);}

/* body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2063(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2063,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[74]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 383  alloc */
f_1192(t6,lf[74],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2112 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2114,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[75],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 384  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2073(2,t5,C_SCHEME_UNDEFINED);}}

/* k2071 in k2112 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[74]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2085(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 390  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2102 in k2071 in k2112 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2085(t3,t2);}

/* k2083 in k2071 in k2112 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2085(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2085,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2090(t5,((C_word*)t0)[2],C_fix(0));}

/* do450 in k2083 in k2071 in k2112 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2090,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2097,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 393  ##sys#f64vector-set! */
t4=lf[23];
f_935(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k2095 in do450 in k2083 in k2071 in k2112 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2090(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1937r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1937r(t0,t1,t2,t3);}}

static void C_ccall f_1937r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1991,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2001,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init403426 */
t8=t7;
f_2001(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?404424 */
t10=t6;
f_1996(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin405421 */
t12=t5;
f_1991(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body401407 */
t14=t4;
f_1939(t14,t1,t8,t10);}}}}

/* def-init403 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2001,NULL,2,t0,t1);}
/* def-ext?404424 */
t2=((C_word*)t0)[2];
f_1996(t2,t1,C_SCHEME_FALSE);}

/* def-ext?404 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1996,NULL,3,t0,t1,t2);}
/* def-fin405421 */
t3=((C_word*)t0)[2];
f_1991(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin405 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1991,NULL,4,t0,t1,t2,t3);}
/* body401407 */
t4=((C_word*)t0)[2];
f_1939(t4,t1,t2,t3);}

/* body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1939(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1939,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 368  alloc */
f_1192(t6,lf[72],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1988 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 369  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1949(2,t5,C_SCHEME_UNDEFINED);}}

/* k1947 in k1988 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_1961(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 375  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1978 in k1947 in k1988 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1961(t3,t2);}

/* k1959 in k1947 in k1988 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1961,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1966(t5,((C_word*)t0)[2],C_fix(0));}

/* do412 in k1959 in k1947 in k1988 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1966,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1973,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 378  ##sys#f32vector-set! */
t4=lf[22];
f_932(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k1971 in do412 in k1959 in k1947 in k1988 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1966(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1820r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1820r(t0,t1,t2,t3);}}

static void C_ccall f_1820r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1867,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init366388 */
t8=t7;
f_1877(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?367386 */
t10=t6;
f_1872(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin368383 */
t12=t5;
f_1867(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body364370 */
t14=t4;
f_1822(t14,t1,t8,t10);}}}}

/* def-init366 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1877,NULL,2,t0,t1);}
/* def-ext?367386 */
t2=((C_word*)t0)[2];
f_1872(t2,t1,C_SCHEME_FALSE);}

/* def-ext?367 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1872(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1872,NULL,3,t0,t1,t2);}
/* def-fin368383 */
t3=((C_word*)t0)[2];
f_1867(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin368 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1867(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1867,NULL,4,t0,t1,t2,t3);}
/* body364370 */
t4=((C_word*)t0)[2];
f_1822(t4,t1,t2,t3);}

/* body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1822,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 355  alloc */
f_1192(t5,lf[70],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1864 in body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[71],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 356  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1832(2,t5,C_SCHEME_UNDEFINED);}}

/* k1830 in k1864 in body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1846(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do375 in k1830 in k1864 in body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static C_word C_fcall f_1846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_929(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1703r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1703r(t0,t1,t2,t3);}}

static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1760,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init329351 */
t8=t7;
f_1760(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?330349 */
t10=t6;
f_1755(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin331346 */
t12=t5;
f_1750(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body327333 */
t14=t4;
f_1705(t14,t1,t8,t10);}}}}

/* def-init329 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1760,NULL,2,t0,t1);}
/* def-ext?330349 */
t2=((C_word*)t0)[2];
f_1755(t2,t1,C_SCHEME_FALSE);}

/* def-ext?330 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1755,NULL,3,t0,t1,t2);}
/* def-fin331346 */
t3=((C_word*)t0)[2];
f_1750(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin331 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1750(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1750,NULL,4,t0,t1,t2,t3);}
/* body327333 */
t4=((C_word*)t0)[2];
f_1705(t4,t1,t2,t3);}

/* body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1705(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1705,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 342  alloc */
f_1192(t5,lf[68],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1747 in body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[69],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 343  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1715(2,t5,C_SCHEME_UNDEFINED);}}

/* k1713 in k1747 in body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1729(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do338 in k1713 in k1747 in body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static C_word C_fcall f_1729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_926(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1586r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1586r(t0,t1,t2,t3);}}

static void C_ccall f_1586r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1638,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1643,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init292314 */
t8=t7;
f_1643(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?293312 */
t10=t6;
f_1638(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin294309 */
t12=t5;
f_1633(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body290296 */
t14=t4;
f_1588(t14,t1,t8,t10);}}}}

/* def-init292 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1643,NULL,2,t0,t1);}
/* def-ext?293312 */
t2=((C_word*)t0)[2];
f_1638(t2,t1,C_SCHEME_FALSE);}

/* def-ext?293 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1638,NULL,3,t0,t1,t2);}
/* def-fin294309 */
t3=((C_word*)t0)[2];
f_1633(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin294 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1633,NULL,4,t0,t1,t2,t3);}
/* body290296 */
t4=((C_word*)t0)[2];
f_1588(t4,t1,t2,t3);}

/* body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1588(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1588,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 329  alloc */
f_1192(t5,lf[66],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1630 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[67],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 330  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1598(2,t5,C_SCHEME_UNDEFINED);}}

/* k1596 in k1630 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 334  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[66]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1605 in k1596 in k1630 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1612(t5,((C_word*)t0)[2],C_fix(0));}

/* do301 in k1605 in k1596 in k1630 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1612,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1619,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 337  ##sys#s16vector-set! */
t4=lf[19];
f_923(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1617 in do301 in k1605 in k1596 in k1630 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1612(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1469r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1469r(t0,t1,t2,t3);}}

static void C_ccall f_1469r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1516,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1526,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init255277 */
t8=t7;
f_1526(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?256275 */
t10=t6;
f_1521(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin257272 */
t12=t5;
f_1516(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body253259 */
t14=t4;
f_1471(t14,t1,t8,t10);}}}}

/* def-init255 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1526,NULL,2,t0,t1);}
/* def-ext?256275 */
t2=((C_word*)t0)[2];
f_1521(t2,t1,C_SCHEME_FALSE);}

/* def-ext?256 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1521,NULL,3,t0,t1,t2);}
/* def-fin257272 */
t3=((C_word*)t0)[2];
f_1516(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin257 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1516(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1516,NULL,4,t0,t1,t2,t3);}
/* body253259 */
t4=((C_word*)t0)[2];
f_1471(t4,t1,t2,t3);}

/* body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1471(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1471,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[64]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 316  alloc */
f_1192(t5,lf[64],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1513 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[65],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 317  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1481(2,t5,C_SCHEME_UNDEFINED);}}

/* k1479 in k1513 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 321  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[64]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1488 in k1479 in k1513 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1495(t5,((C_word*)t0)[2],C_fix(0));}

/* do264 in k1488 in k1479 in k1513 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1495,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1502,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 324  ##sys#u16vector-set! */
t4=lf[18];
f_920(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1500 in do264 in k1488 in k1479 in k1513 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1495(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1352r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1352r(t0,t1,t2,t3);}}

static void C_ccall f_1352r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1399,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1404,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init218240 */
t8=t7;
f_1409(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?219238 */
t10=t6;
f_1404(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin220235 */
t12=t5;
f_1399(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body216222 */
t14=t4;
f_1354(t14,t1,t8,t10);}}}}

/* def-init218 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1409,NULL,2,t0,t1);}
/* def-ext?219238 */
t2=((C_word*)t0)[2];
f_1404(t2,t1,C_SCHEME_FALSE);}

/* def-ext?219 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1404(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1404,NULL,3,t0,t1,t2);}
/* def-fin220235 */
t3=((C_word*)t0)[2];
f_1399(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin220 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1399(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1399,NULL,4,t0,t1,t2,t3);}
/* body216222 */
t4=((C_word*)t0)[2];
f_1354(t4,t1,t2,t3);}

/* body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1354(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1354,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[61]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 303  alloc */
f_1192(t5,lf[61],((C_word*)t0)[5],t3);}

/* k1396 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1398,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1364,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 304  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1364(2,t5,C_SCHEME_UNDEFINED);}}

/* k1362 in k1396 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 308  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[61]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1371 in k1362 in k1396 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1378(t5,((C_word*)t0)[2],C_fix(0));}

/* do227 in k1371 in k1362 in k1396 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1378(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1378,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1385,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 311  ##sys#s8vector-set! */
t4=lf[17];
f_917(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1383 in do227 in k1371 in k1362 in k1396 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1378(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1235r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1235r(t0,t1,t2,t3);}}

static void C_ccall f_1235r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1282,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1287,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1292,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init180202 */
t8=t7;
f_1292(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?181200 */
t10=t6;
f_1287(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?182197 */
t12=t5;
f_1282(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body178184 */
t14=t4;
f_1237(t14,t1,t8,t10,t12);}}}}

/* def-init180 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1292,NULL,2,t0,t1);}
/* def-ext?181200 */
t2=((C_word*)t0)[2];
f_1287(t2,t1,C_SCHEME_FALSE);}

/* def-ext?181 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1287,NULL,3,t0,t1,t2);}
/* def-fin?182197 */
t3=((C_word*)t0)[2];
f_1282(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?182 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1282(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1282,NULL,4,t0,t1,t2,t3);}
/* body178184 */
t4=((C_word*)t0)[2];
f_1237(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1237(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1237,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[59]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 290  alloc */
f_1192(t6,lf[59],((C_word*)t0)[5],t3);}

/* k1279 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[60],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 291  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1247(2,t5,C_SCHEME_UNDEFINED);}}

/* k1245 in k1279 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1247,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 295  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[59]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1254 in k1245 in k1279 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1261(t5,((C_word*)t0)[2],C_fix(0));}

/* do189 in k1254 in k1245 in k1279 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1261,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1268,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 298  ##sys#u8vector-set! */
t4=lf[16];
f_914(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1266 in do189 in k1254 in k1245 in k1279 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1261(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* release-number-vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1210,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1217,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1217(t5,(C_word)C_u_i_memq(t4,lf[58]));}
else{
t4=t3;
f_1217(t4,C_SCHEME_FALSE);}}

/* k1215 in release-number-vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-4.scm: 284  ext-free */
t2=((C_word*)t0)[4];
f_1190(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 285  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[56],lf[57],((C_word*)t0)[2]);}}

/* alloc in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1192(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1192,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)stub153(C_SCHEME_UNDEFINED,t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* srfi-4.scm: 275  ##sys#error */
t7=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[54],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 276  ##sys#allocate-vector */
t6=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1206 in alloc in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1190,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub158(C_SCHEME_UNDEFINED,t2));}

/* f_1040 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1040,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1044,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 193  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1042 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1047,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1047(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 195  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[41],lf[42],((C_word*)t0)[2]);}}

/* k1045 in k1042 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 196  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[41]);}

/* k1048 in k1045 in k1042 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 197  upd */
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_929(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f_1067 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1067,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1071,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 201  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1069 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1074,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 203  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[39],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1074(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 205  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[40],((C_word*)t0)[2]);}}}

/* k1072 in k1069 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 206  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[38]);}

/* k1075 in k1072 in k1069 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 207  upd */
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_926(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* setf in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1101(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1101,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1103,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1103 in setf in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1103,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1107,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 211  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1105 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1107,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 213  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1111 in k1105 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_1120(2,t3,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 216  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1118 in k1111 in k1105 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 214  upd */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1012(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1012,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1014,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1014 in setu in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1014,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1018,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 184  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1016 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 187  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[33],((C_word*)t0)[7]);}
else{
t4=t3;
f_1024(2,t4,C_SCHEME_UNDEFINED);}}

/* k1022 in k1016 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 188  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1025 in k1022 in k1016 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 189  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_995(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_995,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_997,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_997 in set in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_997,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1001,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 177  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k999 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 179  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1005 in k999 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 180  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_981(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_981,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_983,a[2]=t2,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp));}

/* f_983 in get in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_983,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 171  length */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k985 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 172  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k988 in k985 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 173  acc */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_938(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_938,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_940,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));}

/* f_940 in len */
static void C_ccall f_940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_940,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void C_ccall f_935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_935,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_932,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static C_word C_fcall f_929(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)C_s32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#u32vector-set! */
static C_word C_fcall f_926(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)C_u32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#s16vector-set! */
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_923,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_920,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_917,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_914,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_908,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 131  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_902,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 127  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_899,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_896,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_893,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_890,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_887,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_884,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_863,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 113  ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[6],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void C_ccall f_848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_848,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 107  ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[310] = {
{"toplevelsrfi-4.scm",(void*)C_srfi_4_toplevel},
{"f_951srfi-4.scm",(void*)f_951},
{"f_955srfi-4.scm",(void*)f_955},
{"f_959srfi-4.scm",(void*)f_959},
{"f_963srfi-4.scm",(void*)f_963},
{"f_967srfi-4.scm",(void*)f_967},
{"f_971srfi-4.scm",(void*)f_971},
{"f_975srfi-4.scm",(void*)f_975},
{"f_979srfi-4.scm",(void*)f_979},
{"f_1127srfi-4.scm",(void*)f_1127},
{"f_1131srfi-4.scm",(void*)f_1131},
{"f_1135srfi-4.scm",(void*)f_1135},
{"f_1139srfi-4.scm",(void*)f_1139},
{"f_1151srfi-4.scm",(void*)f_1151},
{"f_1155srfi-4.scm",(void*)f_1155},
{"f_3285srfi-4.scm",(void*)f_3285},
{"f_1159srfi-4.scm",(void*)f_1159},
{"f_3281srfi-4.scm",(void*)f_3281},
{"f_1163srfi-4.scm",(void*)f_1163},
{"f_3277srfi-4.scm",(void*)f_3277},
{"f_1167srfi-4.scm",(void*)f_1167},
{"f_3273srfi-4.scm",(void*)f_3273},
{"f_1171srfi-4.scm",(void*)f_1171},
{"f_3269srfi-4.scm",(void*)f_3269},
{"f_1175srfi-4.scm",(void*)f_1175},
{"f_3265srfi-4.scm",(void*)f_3265},
{"f_1179srfi-4.scm",(void*)f_1179},
{"f_3261srfi-4.scm",(void*)f_3261},
{"f_1183srfi-4.scm",(void*)f_1183},
{"f_3257srfi-4.scm",(void*)f_3257},
{"f_1187srfi-4.scm",(void*)f_1187},
{"f_2225srfi-4.scm",(void*)f_2225},
{"f_2229srfi-4.scm",(void*)f_2229},
{"f_2233srfi-4.scm",(void*)f_2233},
{"f_2237srfi-4.scm",(void*)f_2237},
{"f_2241srfi-4.scm",(void*)f_2241},
{"f_2245srfi-4.scm",(void*)f_2245},
{"f_2249srfi-4.scm",(void*)f_2249},
{"f_2253srfi-4.scm",(void*)f_2253},
{"f_2340srfi-4.scm",(void*)f_2340},
{"f_2344srfi-4.scm",(void*)f_2344},
{"f_2348srfi-4.scm",(void*)f_2348},
{"f_2352srfi-4.scm",(void*)f_2352},
{"f_2356srfi-4.scm",(void*)f_2356},
{"f_2360srfi-4.scm",(void*)f_2360},
{"f_2364srfi-4.scm",(void*)f_2364},
{"f_2368srfi-4.scm",(void*)f_2368},
{"f_2510srfi-4.scm",(void*)f_2510},
{"f_2514srfi-4.scm",(void*)f_2514},
{"f_2518srfi-4.scm",(void*)f_2518},
{"f_2522srfi-4.scm",(void*)f_2522},
{"f_2526srfi-4.scm",(void*)f_2526},
{"f_2530srfi-4.scm",(void*)f_2530},
{"f_2534srfi-4.scm",(void*)f_2534},
{"f_2538srfi-4.scm",(void*)f_2538},
{"f_2542srfi-4.scm",(void*)f_2542},
{"f_2546srfi-4.scm",(void*)f_2546},
{"f_2550srfi-4.scm",(void*)f_2550},
{"f_2554srfi-4.scm",(void*)f_2554},
{"f_2558srfi-4.scm",(void*)f_2558},
{"f_2562srfi-4.scm",(void*)f_2562},
{"f_2566srfi-4.scm",(void*)f_2566},
{"f_2570srfi-4.scm",(void*)f_2570},
{"f_2574srfi-4.scm",(void*)f_2574},
{"f_2578srfi-4.scm",(void*)f_2578},
{"f_2582srfi-4.scm",(void*)f_2582},
{"f_2586srfi-4.scm",(void*)f_2586},
{"f_2590srfi-4.scm",(void*)f_2590},
{"f_2594srfi-4.scm",(void*)f_2594},
{"f_2598srfi-4.scm",(void*)f_2598},
{"f_2602srfi-4.scm",(void*)f_2602},
{"f_2606srfi-4.scm",(void*)f_2606},
{"f_2610srfi-4.scm",(void*)f_2610},
{"f_2614srfi-4.scm",(void*)f_2614},
{"f_2618srfi-4.scm",(void*)f_2618},
{"f_2622srfi-4.scm",(void*)f_2622},
{"f_2626srfi-4.scm",(void*)f_2626},
{"f_2630srfi-4.scm",(void*)f_2630},
{"f_2634srfi-4.scm",(void*)f_2634},
{"f_2638srfi-4.scm",(void*)f_2638},
{"f_2642srfi-4.scm",(void*)f_2642},
{"f_2646srfi-4.scm",(void*)f_2646},
{"f_2650srfi-4.scm",(void*)f_2650},
{"f_2654srfi-4.scm",(void*)f_2654},
{"f_2658srfi-4.scm",(void*)f_2658},
{"f_2662srfi-4.scm",(void*)f_2662},
{"f_2666srfi-4.scm",(void*)f_2666},
{"f_2670srfi-4.scm",(void*)f_2670},
{"f_2674srfi-4.scm",(void*)f_2674},
{"f_2678srfi-4.scm",(void*)f_2678},
{"f_2682srfi-4.scm",(void*)f_2682},
{"f_2686srfi-4.scm",(void*)f_2686},
{"f_2690srfi-4.scm",(void*)f_2690},
{"f_2694srfi-4.scm",(void*)f_2694},
{"f_2698srfi-4.scm",(void*)f_2698},
{"f_3253srfi-4.scm",(void*)f_3253},
{"f_3138srfi-4.scm",(void*)f_3138},
{"f_3207srfi-4.scm",(void*)f_3207},
{"f_3202srfi-4.scm",(void*)f_3202},
{"f_3140srfi-4.scm",(void*)f_3140},
{"f_3144srfi-4.scm",(void*)f_3144},
{"f_3171srfi-4.scm",(void*)f_3171},
{"f_3176srfi-4.scm",(void*)f_3176},
{"f_3180srfi-4.scm",(void*)f_3180},
{"f_3198srfi-4.scm",(void*)f_3198},
{"f_3189srfi-4.scm",(void*)f_3189},
{"f_3153srfi-4.scm",(void*)f_3153},
{"f_3156srfi-4.scm",(void*)f_3156},
{"f_3129srfi-4.scm",(void*)f_3129},
{"f_3137srfi-4.scm",(void*)f_3137},
{"f_3031srfi-4.scm",(void*)f_3031},
{"f_3083srfi-4.scm",(void*)f_3083},
{"f_3078srfi-4.scm",(void*)f_3078},
{"f_3033srfi-4.scm",(void*)f_3033},
{"f_3037srfi-4.scm",(void*)f_3037},
{"f_3049srfi-4.scm",(void*)f_3049},
{"f_2918srfi-4.scm",(void*)f_2918},
{"f_2971srfi-4.scm",(void*)f_2971},
{"f_2966srfi-4.scm",(void*)f_2966},
{"f_2957srfi-4.scm",(void*)f_2957},
{"f_2920srfi-4.scm",(void*)f_2920},
{"f_2927srfi-4.scm",(void*)f_2927},
{"f_2935srfi-4.scm",(void*)f_2935},
{"f_2945srfi-4.scm",(void*)f_2945},
{"f_2912srfi-4.scm",(void*)f_2912},
{"f_2906srfi-4.scm",(void*)f_2906},
{"f_2900srfi-4.scm",(void*)f_2900},
{"f_2894srfi-4.scm",(void*)f_2894},
{"f_2888srfi-4.scm",(void*)f_2888},
{"f_2882srfi-4.scm",(void*)f_2882},
{"f_2876srfi-4.scm",(void*)f_2876},
{"f_2870srfi-4.scm",(void*)f_2870},
{"f_2827srfi-4.scm",(void*)f_2827},
{"f_2840srfi-4.scm",(void*)f_2840},
{"f_2843srfi-4.scm",(void*)f_2843},
{"f_2849srfi-4.scm",(void*)f_2849},
{"f_2759srfi-4.scm",(void*)f_2759},
{"f_2769srfi-4.scm",(void*)f_2769},
{"f_2772srfi-4.scm",(void*)f_2772},
{"f_2779srfi-4.scm",(void*)f_2779},
{"f_2703srfi-4.scm",(void*)f_2703},
{"f_2713srfi-4.scm",(void*)f_2713},
{"f_2738srfi-4.scm",(void*)f_2738},
{"f_2476srfi-4.scm",(void*)f_2476},
{"f_2478srfi-4.scm",(void*)f_2478},
{"f_2488srfi-4.scm",(void*)f_2488},
{"f_2447srfi-4.scm",(void*)f_2447},
{"f_2449srfi-4.scm",(void*)f_2449},
{"f_2429srfi-4.scm",(void*)f_2429},
{"f_2431srfi-4.scm",(void*)f_2431},
{"f_2441srfi-4.scm",(void*)f_2441},
{"f_2418srfi-4.scm",(void*)f_2418},
{"f_2420srfi-4.scm",(void*)f_2420},
{"f_2412srfi-4.scm",(void*)f_2412},
{"f_2406srfi-4.scm",(void*)f_2406},
{"f_2400srfi-4.scm",(void*)f_2400},
{"f_2394srfi-4.scm",(void*)f_2394},
{"f_2388srfi-4.scm",(void*)f_2388},
{"f_2382srfi-4.scm",(void*)f_2382},
{"f_2376srfi-4.scm",(void*)f_2376},
{"f_2370srfi-4.scm",(void*)f_2370},
{"f_2303srfi-4.scm",(void*)f_2303},
{"f_2305srfi-4.scm",(void*)f_2305},
{"f_2309srfi-4.scm",(void*)f_2309},
{"f_2314srfi-4.scm",(void*)f_2314},
{"f_2328srfi-4.scm",(void*)f_2328},
{"f_2332srfi-4.scm",(void*)f_2332},
{"f_2297srfi-4.scm",(void*)f_2297},
{"f_2291srfi-4.scm",(void*)f_2291},
{"f_2285srfi-4.scm",(void*)f_2285},
{"f_2279srfi-4.scm",(void*)f_2279},
{"f_2273srfi-4.scm",(void*)f_2273},
{"f_2267srfi-4.scm",(void*)f_2267},
{"f_2261srfi-4.scm",(void*)f_2261},
{"f_2255srfi-4.scm",(void*)f_2255},
{"f_2185srfi-4.scm",(void*)f_2185},
{"f_2187srfi-4.scm",(void*)f_2187},
{"f_2197srfi-4.scm",(void*)f_2197},
{"f_2202srfi-4.scm",(void*)f_2202},
{"f_2209srfi-4.scm",(void*)f_2209},
{"f_2061srfi-4.scm",(void*)f_2061},
{"f_2125srfi-4.scm",(void*)f_2125},
{"f_2120srfi-4.scm",(void*)f_2120},
{"f_2115srfi-4.scm",(void*)f_2115},
{"f_2063srfi-4.scm",(void*)f_2063},
{"f_2114srfi-4.scm",(void*)f_2114},
{"f_2073srfi-4.scm",(void*)f_2073},
{"f_2104srfi-4.scm",(void*)f_2104},
{"f_2085srfi-4.scm",(void*)f_2085},
{"f_2090srfi-4.scm",(void*)f_2090},
{"f_2097srfi-4.scm",(void*)f_2097},
{"f_1937srfi-4.scm",(void*)f_1937},
{"f_2001srfi-4.scm",(void*)f_2001},
{"f_1996srfi-4.scm",(void*)f_1996},
{"f_1991srfi-4.scm",(void*)f_1991},
{"f_1939srfi-4.scm",(void*)f_1939},
{"f_1990srfi-4.scm",(void*)f_1990},
{"f_1949srfi-4.scm",(void*)f_1949},
{"f_1980srfi-4.scm",(void*)f_1980},
{"f_1961srfi-4.scm",(void*)f_1961},
{"f_1966srfi-4.scm",(void*)f_1966},
{"f_1973srfi-4.scm",(void*)f_1973},
{"f_1820srfi-4.scm",(void*)f_1820},
{"f_1877srfi-4.scm",(void*)f_1877},
{"f_1872srfi-4.scm",(void*)f_1872},
{"f_1867srfi-4.scm",(void*)f_1867},
{"f_1822srfi-4.scm",(void*)f_1822},
{"f_1866srfi-4.scm",(void*)f_1866},
{"f_1832srfi-4.scm",(void*)f_1832},
{"f_1846srfi-4.scm",(void*)f_1846},
{"f_1703srfi-4.scm",(void*)f_1703},
{"f_1760srfi-4.scm",(void*)f_1760},
{"f_1755srfi-4.scm",(void*)f_1755},
{"f_1750srfi-4.scm",(void*)f_1750},
{"f_1705srfi-4.scm",(void*)f_1705},
{"f_1749srfi-4.scm",(void*)f_1749},
{"f_1715srfi-4.scm",(void*)f_1715},
{"f_1729srfi-4.scm",(void*)f_1729},
{"f_1586srfi-4.scm",(void*)f_1586},
{"f_1643srfi-4.scm",(void*)f_1643},
{"f_1638srfi-4.scm",(void*)f_1638},
{"f_1633srfi-4.scm",(void*)f_1633},
{"f_1588srfi-4.scm",(void*)f_1588},
{"f_1632srfi-4.scm",(void*)f_1632},
{"f_1598srfi-4.scm",(void*)f_1598},
{"f_1607srfi-4.scm",(void*)f_1607},
{"f_1612srfi-4.scm",(void*)f_1612},
{"f_1619srfi-4.scm",(void*)f_1619},
{"f_1469srfi-4.scm",(void*)f_1469},
{"f_1526srfi-4.scm",(void*)f_1526},
{"f_1521srfi-4.scm",(void*)f_1521},
{"f_1516srfi-4.scm",(void*)f_1516},
{"f_1471srfi-4.scm",(void*)f_1471},
{"f_1515srfi-4.scm",(void*)f_1515},
{"f_1481srfi-4.scm",(void*)f_1481},
{"f_1490srfi-4.scm",(void*)f_1490},
{"f_1495srfi-4.scm",(void*)f_1495},
{"f_1502srfi-4.scm",(void*)f_1502},
{"f_1352srfi-4.scm",(void*)f_1352},
{"f_1409srfi-4.scm",(void*)f_1409},
{"f_1404srfi-4.scm",(void*)f_1404},
{"f_1399srfi-4.scm",(void*)f_1399},
{"f_1354srfi-4.scm",(void*)f_1354},
{"f_1398srfi-4.scm",(void*)f_1398},
{"f_1364srfi-4.scm",(void*)f_1364},
{"f_1373srfi-4.scm",(void*)f_1373},
{"f_1378srfi-4.scm",(void*)f_1378},
{"f_1385srfi-4.scm",(void*)f_1385},
{"f_1235srfi-4.scm",(void*)f_1235},
{"f_1292srfi-4.scm",(void*)f_1292},
{"f_1287srfi-4.scm",(void*)f_1287},
{"f_1282srfi-4.scm",(void*)f_1282},
{"f_1237srfi-4.scm",(void*)f_1237},
{"f_1281srfi-4.scm",(void*)f_1281},
{"f_1247srfi-4.scm",(void*)f_1247},
{"f_1256srfi-4.scm",(void*)f_1256},
{"f_1261srfi-4.scm",(void*)f_1261},
{"f_1268srfi-4.scm",(void*)f_1268},
{"f_1210srfi-4.scm",(void*)f_1210},
{"f_1217srfi-4.scm",(void*)f_1217},
{"f_1192srfi-4.scm",(void*)f_1192},
{"f_1208srfi-4.scm",(void*)f_1208},
{"f_1190srfi-4.scm",(void*)f_1190},
{"f_1040srfi-4.scm",(void*)f_1040},
{"f_1044srfi-4.scm",(void*)f_1044},
{"f_1047srfi-4.scm",(void*)f_1047},
{"f_1050srfi-4.scm",(void*)f_1050},
{"f_1067srfi-4.scm",(void*)f_1067},
{"f_1071srfi-4.scm",(void*)f_1071},
{"f_1074srfi-4.scm",(void*)f_1074},
{"f_1077srfi-4.scm",(void*)f_1077},
{"f_1101srfi-4.scm",(void*)f_1101},
{"f_1103srfi-4.scm",(void*)f_1103},
{"f_1107srfi-4.scm",(void*)f_1107},
{"f_1113srfi-4.scm",(void*)f_1113},
{"f_1120srfi-4.scm",(void*)f_1120},
{"f_1012srfi-4.scm",(void*)f_1012},
{"f_1014srfi-4.scm",(void*)f_1014},
{"f_1018srfi-4.scm",(void*)f_1018},
{"f_1024srfi-4.scm",(void*)f_1024},
{"f_1027srfi-4.scm",(void*)f_1027},
{"f_995srfi-4.scm",(void*)f_995},
{"f_997srfi-4.scm",(void*)f_997},
{"f_1001srfi-4.scm",(void*)f_1001},
{"f_1007srfi-4.scm",(void*)f_1007},
{"f_981srfi-4.scm",(void*)f_981},
{"f_983srfi-4.scm",(void*)f_983},
{"f_987srfi-4.scm",(void*)f_987},
{"f_990srfi-4.scm",(void*)f_990},
{"f_938srfi-4.scm",(void*)f_938},
{"f_940srfi-4.scm",(void*)f_940},
{"f_935srfi-4.scm",(void*)f_935},
{"f_932srfi-4.scm",(void*)f_932},
{"f_929srfi-4.scm",(void*)f_929},
{"f_926srfi-4.scm",(void*)f_926},
{"f_923srfi-4.scm",(void*)f_923},
{"f_920srfi-4.scm",(void*)f_920},
{"f_917srfi-4.scm",(void*)f_917},
{"f_914srfi-4.scm",(void*)f_914},
{"f_908srfi-4.scm",(void*)f_908},
{"f_902srfi-4.scm",(void*)f_902},
{"f_899srfi-4.scm",(void*)f_899},
{"f_896srfi-4.scm",(void*)f_896},
{"f_893srfi-4.scm",(void*)f_893},
{"f_890srfi-4.scm",(void*)f_890},
{"f_887srfi-4.scm",(void*)f_887},
{"f_884srfi-4.scm",(void*)f_884},
{"f_863srfi-4.scm",(void*)f_863},
{"f_848srfi-4.scm",(void*)f_848},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
