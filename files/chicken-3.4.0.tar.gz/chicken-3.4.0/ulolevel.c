/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:56
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: lolevel.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file ulolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_pointer_to_object(ptr)   ((C_word*)C_block_item(ptr, 0))
#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[160];
static double C_possibly_force_alignment;


/* from k2263 */
static C_word C_fcall stub494(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub494(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from f_2175 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static C_word C_fcall stub467(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub467(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from malloc */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub393(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub393(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int size=(int )C_unfix(C_a0);
char *bv;
           if((bv = (char *)C_malloc(size + 3 + sizeof(C_header))) == NULL) return(C_SCHEME_FALSE);
           bv = (char *)C_align((C_word)bv);
           ((C_SCHEME_BLOCK *)bv)->header = C_BYTEVECTOR_TYPE | size;
           return((C_word)bv);
C_ret:
#undef return

return C_r;}

/* from k2914 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub305(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub305(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k2924 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub298(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub298(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k2934 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub291(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub291(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k2944 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub284(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub284(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k2954 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub278(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub278(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k2964 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub272(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub272(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k2974 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub266(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub266(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_ret:
#undef return

return C_r;}

/* from k2984 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub260(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub260(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k1324 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1314 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1304 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub237(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub237(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1294 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub229(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub229(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1284 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub221(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub221(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1274 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub213(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub213(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1264 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub205(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub205(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1254 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1244 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from align in k719 */
static C_word C_fcall stub181(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub181(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1200 */
static C_word C_fcall stub174(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub174(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from allocate in k719 */
static C_word C_fcall stub169(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub169(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from f_1176 in object->pointer in k719 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k772 */
static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k759 */
static C_word C_fcall stub42(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub42(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k746 */
static C_word C_fcall stub26(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub26(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k730 */
static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2831)
static void C_fcall f_2831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2664)
static void C_fcall f_2664(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_fcall f_2542(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_fcall f_2613(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_fcall f_2449(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_fcall f_2483(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_fcall f_2277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_fcall f_2291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2187)
static void C_fcall f_2187(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2232)
static void C_fcall f_2232(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_fcall f_2124(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1993)
static void C_fcall f_1993(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_fcall f_2038(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static C_word C_fcall f_1951(C_word t0,C_word t1);
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1888)
static void C_fcall f_1888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1835)
static void C_fcall f_1835(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1676)
static void C_fcall f_1676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static C_word C_fcall f_1600(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1550)
static C_word C_fcall f_1550(C_word t0,C_word t1);
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static C_word C_fcall f_1207(C_word *a,C_word t0);
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1106)
static void C_fcall f_1106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1039)
static void C_fcall f_1039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_fcall f_1034(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1029)
static void C_fcall f_1029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_777)
static void C_fcall f_777(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_837)
static void C_fcall f_837(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_808)
static void C_fcall f_808(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_815)
static void C_fcall f_815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_792)
static void C_fcall f_792(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_786)
static void C_fcall f_786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_780)
static void C_fcall f_780(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2831)
static void C_fcall trf_2831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2831(t0,t1);}

C_noret_decl(trf_2664)
static void C_fcall trf_2664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2664(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2664(t0,t1,t2);}

C_noret_decl(trf_2542)
static void C_fcall trf_2542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2542(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2542(t0,t1,t2);}

C_noret_decl(trf_2613)
static void C_fcall trf_2613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2613(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2613(t0,t1,t2);}

C_noret_decl(trf_2449)
static void C_fcall trf_2449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2449(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2449(t0,t1,t2);}

C_noret_decl(trf_2483)
static void C_fcall trf_2483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2483(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2483(t0,t1,t2);}

C_noret_decl(trf_2277)
static void C_fcall trf_2277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2277(t0,t1);}

C_noret_decl(trf_2291)
static void C_fcall trf_2291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2291(t0,t1,t2);}

C_noret_decl(trf_2334)
static void C_fcall trf_2334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2334(t0,t1,t2);}

C_noret_decl(trf_2187)
static void C_fcall trf_2187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2187(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2187(t0,t1,t2);}

C_noret_decl(trf_2232)
static void C_fcall trf_2232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2232(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2232(t0,t1,t2);}

C_noret_decl(trf_2083)
static void C_fcall trf_2083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2083(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2083(t0,t1,t2);}

C_noret_decl(trf_2124)
static void C_fcall trf_2124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2124(t0,t1,t2);}

C_noret_decl(trf_1993)
static void C_fcall trf_1993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1993(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1993(t0,t1,t2);}

C_noret_decl(trf_2038)
static void C_fcall trf_2038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2038(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2038(t0,t1,t2);}

C_noret_decl(trf_1888)
static void C_fcall trf_1888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1888(t0,t1);}

C_noret_decl(trf_1835)
static void C_fcall trf_1835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1835(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1835(t0,t1,t2,t3);}

C_noret_decl(trf_1715)
static void C_fcall trf_1715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1715(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1715(t0,t1,t2,t3);}

C_noret_decl(trf_1676)
static void C_fcall trf_1676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1676(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1676(t0,t1,t2);}

C_noret_decl(trf_1106)
static void C_fcall trf_1106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1106(t0,t1);}

C_noret_decl(trf_1039)
static void C_fcall trf_1039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1039(t0,t1);}

C_noret_decl(trf_1034)
static void C_fcall trf_1034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1034(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1034(t0,t1,t2);}

C_noret_decl(trf_1029)
static void C_fcall trf_1029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1029(t0,t1,t2,t3);}

C_noret_decl(trf_777)
static void C_fcall trf_777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_777(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_777(t0,t1,t2,t3,t4);}

C_noret_decl(trf_837)
static void C_fcall trf_837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_837(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_837(t0,t1,t2,t3);}

C_noret_decl(trf_808)
static void C_fcall trf_808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_808(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_808(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_815)
static void C_fcall trf_815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_815(t0,t1);}

C_noret_decl(trf_792)
static void C_fcall trf_792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_792(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_792(t0,t1,t2,t3,t4);}

C_noret_decl(trf_786)
static void C_fcall trf_786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_786(t0,t1);}

C_noret_decl(trf_780)
static void C_fcall trf_780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_780(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1417)){
C_save(t1);
C_rereclaim2(1417*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,160);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[3]=C_h_intern(&lf[3],12,"move-memory!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],11,"\000type-error");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid argument type");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[11]=C_h_intern(&lf[11],15,"\003sysbytevector\077");
lf[12]=C_h_intern(&lf[12],13,"\003syslocative\077");
lf[13]=C_h_intern(&lf[13],17,"\003syscheck-pointer");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[15]=C_h_intern(&lf[15],12,"null-pointer");
lf[16]=C_h_intern(&lf[16],16,"\003sysnull-pointer");
lf[17]=C_h_intern(&lf[17],8,"pointer\077");
lf[18]=C_h_intern(&lf[18],16,"address->pointer");
lf[19]=C_h_intern(&lf[19],20,"\003sysaddress->pointer");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\042bad argument type - not an integer");
lf[21]=C_h_intern(&lf[21],16,"pointer->address");
lf[22]=C_h_intern(&lf[22],20,"\003syspointer->address");
lf[23]=C_h_intern(&lf[23],17,"\003syscheck-special");
lf[24]=C_h_intern(&lf[24],13,"null-pointer\077");
lf[25]=C_h_intern(&lf[25],15,"object->pointer");
lf[26]=C_h_intern(&lf[26],15,"pointer->object");
lf[27]=C_h_intern(&lf[27],9,"pointer=\077");
lf[28]=C_h_intern(&lf[28],8,"allocate");
lf[29]=C_h_intern(&lf[29],4,"free");
lf[30]=C_h_intern(&lf[30],13,"align-to-word");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000+bad argument type - not a pointer or fixnum");
lf[32]=C_h_intern(&lf[32],14,"pointer-offset");
lf[33]=C_h_intern(&lf[33],15,"pointer-u8-set!");
lf[34]=C_h_intern(&lf[34],15,"pointer-s8-set!");
lf[35]=C_h_intern(&lf[35],16,"pointer-u16-set!");
lf[36]=C_h_intern(&lf[36],16,"pointer-s16-set!");
lf[37]=C_h_intern(&lf[37],16,"pointer-u32-set!");
lf[38]=C_h_intern(&lf[38],16,"pointer-s32-set!");
lf[39]=C_h_intern(&lf[39],16,"pointer-f32-set!");
lf[40]=C_h_intern(&lf[40],16,"pointer-f64-set!");
lf[41]=C_h_intern(&lf[41],14,"pointer-u8-ref");
lf[42]=C_h_intern(&lf[42],14,"pointer-s8-ref");
lf[43]=C_h_intern(&lf[43],15,"pointer-u16-ref");
lf[44]=C_h_intern(&lf[44],15,"pointer-s16-ref");
lf[45]=C_h_intern(&lf[45],15,"pointer-u32-ref");
lf[46]=C_h_intern(&lf[46],15,"pointer-s32-ref");
lf[47]=C_h_intern(&lf[47],15,"pointer-f32-ref");
lf[48]=C_h_intern(&lf[48],15,"pointer-f64-ref");
lf[49]=C_h_intern(&lf[49],11,"tag-pointer");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[51]=C_h_intern(&lf[51],23,"\003sysmake-tagged-pointer");
lf[52]=C_h_intern(&lf[52],15,"tagged-pointer\077");
lf[53]=C_h_intern(&lf[53],11,"pointer-tag");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[55]=C_h_intern(&lf[55],8,"extended");
lf[57]=C_h_intern(&lf[57],16,"extend-procedure");
lf[58]=C_h_intern(&lf[58],19,"\003sysdecorate-lambda");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[60]=C_h_intern(&lf[60],19,"extended-procedure\077");
lf[61]=C_h_intern(&lf[61],21,"\003syslambda-decoration");
lf[62]=C_h_intern(&lf[62],14,"procedure-data");
lf[63]=C_h_intern(&lf[63],19,"set-procedure-data!");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[65]=C_h_intern(&lf[65],12,"byte-vector\077");
lf[66]=C_h_intern(&lf[66],5,"blob\077");
lf[67]=C_h_intern(&lf[67],17,"byte-vector-fill!");
lf[68]=C_h_intern(&lf[68],16,"make-byte-vector");
lf[69]=C_h_intern(&lf[69],9,"make-blob");
lf[70]=C_h_intern(&lf[70],11,"byte-vector");
lf[71]=C_h_intern(&lf[71],16,"byte-vector-set!");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\014out of range");
lf[73]=C_h_intern(&lf[73],15,"byte-vector-ref");
lf[74]=C_h_intern(&lf[74],17,"byte-vector->list");
lf[75]=C_h_intern(&lf[75],17,"list->byte-vector");
lf[76]=C_h_intern(&lf[76],27,"\003sysnot-a-proper-list-error");
lf[77]=C_h_intern(&lf[77],19,"string->byte-vector");
lf[78]=C_h_intern(&lf[78],12,"string->blob");
lf[79]=C_h_intern(&lf[79],19,"byte-vector->string");
lf[80]=C_h_intern(&lf[80],12,"blob->string");
lf[81]=C_h_intern(&lf[81],18,"byte-vector-length");
lf[82]=C_h_intern(&lf[82],9,"blob-size");
lf[83]=C_h_intern(&lf[83],23,"make-static-byte-vector");
lf[84]=C_h_intern(&lf[84],13,"\000bounds-error");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\014out of range");
lf[86]=C_h_intern(&lf[86],14,"\000runtime-error");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\0000can not allocate statically allocated bytevector");
lf[88]=C_h_intern(&lf[88],27,"static-byte-vector->pointer");
lf[89]=C_h_intern(&lf[89],16,"\003sysmake-pointer");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\036can not coerce non-static blob");
lf[91]=C_h_intern(&lf[91],17,"byte-vector-move!");
lf[92]=C_h_intern(&lf[92],13,"make-locative");
lf[93]=C_h_intern(&lf[93],18,"byte-vector-append");
lf[94]=C_h_intern(&lf[94],10,"block-set!");
lf[95]=C_h_intern(&lf[95],14,"\003sysblock-set!");
lf[96]=C_h_intern(&lf[96],9,"block-ref");
lf[97]=C_h_intern(&lf[97],15,"number-of-slots");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\024slots not accessible");
lf[99]=C_h_intern(&lf[99],15,"number-of-bytes");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\0003can not compute number of bytes of immediate object");
lf[101]=C_h_intern(&lf[101],20,"make-record-instance");
lf[102]=C_h_intern(&lf[102],18,"\003sysmake-structure");
lf[103]=C_h_intern(&lf[103],16,"record-instance\077");
lf[104]=C_h_intern(&lf[104],14,"record->vector");
lf[105]=C_h_intern(&lf[105],15,"\003sysmake-vector");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a record structure");
lf[107]=C_h_intern(&lf[107],11,"object-copy");
lf[108]=C_h_intern(&lf[108],15,"object-evicted\077");
lf[109]=C_h_intern(&lf[109],12,"object-evict");
lf[110]=C_h_intern(&lf[110],19,"\003syshash-table-set!");
lf[111]=C_h_intern(&lf[111],18,"\003syshash-table-ref");
lf[112]=C_h_intern(&lf[112],14,"object-release");
lf[113]=C_h_intern(&lf[113],24,"object-evict-to-location");
lf[114]=C_h_intern(&lf[114],24,"\003sysset-pointer-address!");
lf[115]=C_h_intern(&lf[115],6,"signal");
lf[116]=C_h_intern(&lf[116],24,"make-composite-condition");
lf[117]=C_h_intern(&lf[117],23,"make-property-condition");
lf[118]=C_h_intern(&lf[118],5,"evict");
lf[119]=C_h_intern(&lf[119],5,"limit");
lf[120]=C_h_intern(&lf[120],3,"exn");
lf[121]=C_h_intern(&lf[121],8,"location");
lf[122]=C_h_intern(&lf[122],7,"message");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000%can not evict object - limit exceeded");
lf[124]=C_h_intern(&lf[124],9,"arguments");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[126]=C_h_intern(&lf[126],11,"object-size");
lf[127]=C_h_intern(&lf[127],14,"object-unevict");
lf[128]=C_h_intern(&lf[128],15,"\003sysmake-string");
lf[129]=C_h_intern(&lf[129],14,"object-become!");
lf[130]=C_h_intern(&lf[130],11,"\003sysbecome!");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - new item is immediate");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - old item is immediate");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not an a-list");
lf[134]=C_h_intern(&lf[134],16,"mutate-procedure");
lf[135]=C_h_intern(&lf[135],17,"\003sysmake-locative");
lf[136]=C_h_intern(&lf[136],18,"make-weak-locative");
lf[137]=C_h_intern(&lf[137],13,"locative-set!");
lf[138]=C_h_intern(&lf[138],12,"locative-ref");
lf[139]=C_h_intern(&lf[139],16,"locative->object");
lf[140]=C_h_intern(&lf[140],9,"locative\077");
lf[142]=C_h_intern(&lf[142],35,"set-invalid-procedure-call-handler!");
lf[143]=C_h_intern(&lf[143],31,"\003sysinvalid-procedure-call-hook");
lf[144]=C_h_intern(&lf[144],26,"\003syslast-invalid-procedure");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[146]=C_h_intern(&lf[146],22,"unbound-variable-value");
lf[147]=C_h_intern(&lf[147],31,"\003sysunbound-variable-value-hook");
lf[148]=C_h_intern(&lf[148],10,"global-ref");
lf[149]=C_h_intern(&lf[149],11,"global-set!");
lf[150]=C_h_intern(&lf[150],13,"global-bound\077");
lf[151]=C_h_intern(&lf[151],32,"\003syssymbol-has-toplevel-binding\077");
lf[152]=C_h_intern(&lf[152],20,"global-make-unbound!");
lf[153]=C_h_intern(&lf[153],28,"\003sysarbitrary-unbound-symbol");
lf[154]=C_h_intern(&lf[154],18,"getter-with-setter");
lf[155]=C_h_intern(&lf[155],13,"\003sysblock-ref");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\014out of range");
lf[157]=C_h_intern(&lf[157],15,"pointer-s6-set!");
lf[158]=C_h_intern(&lf[158],17,"register-feature!");
lf[159]=C_h_intern(&lf[159],7,"lolevel");
C_register_lf2(lf,160,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_721,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 83   register-feature! */
t4=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[159]);}

/* k719 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[51],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
t2=lf[2];
t3=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_775,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1099,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[15]+1,*((C_word*)lf[16]+1));
t6=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1118,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1127,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1146,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1155,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1168,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1179,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1185,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1194,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1197,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1207,tmp=(C_word)a,a+=2,tmp);
t16=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1241,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1251,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1261,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1271,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1281,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1291,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1301,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1311,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1321,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2981,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 203  getter-with-setter */
t28=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t28+1)))(4,t28,t26,t27,*((C_word*)lf[33]+1));}

/* a2980 in k719 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2981,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub260(C_SCHEME_UNDEFINED,t3));}

/* k1331 in k719 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2971,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 208  getter-with-setter */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[34]+1));}

/* a2970 in k1331 in k719 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2971,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub266(C_SCHEME_UNDEFINED,t3));}

/* k1335 in k1331 in k719 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2961,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 213  getter-with-setter */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[35]+1));}

/* a2960 in k1335 in k1331 in k719 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2961,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub272(C_SCHEME_UNDEFINED,t3));}

/* k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1341,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2951,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 218  getter-with-setter */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[157]+1));}

/* a2950 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2951,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub278(C_SCHEME_UNDEFINED,t3));}

/* k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 223  getter-with-setter */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[37]+1));}

/* a2940 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2941,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub284(t3,t4));}

/* k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1349,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2931,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 228  getter-with-setter */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[38]+1));}

/* a2930 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2931,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub291(t3,t4));}

/* k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1353,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2921,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 233  getter-with-setter */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[39]+1));}

/* a2920 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2921,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub298(t3,t4));}

/* k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2911,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 238  getter-with-setter */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[40]+1));}

/* a2910 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2911,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub305(t3,t4));}

/* k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1363,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1378,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1394,tmp=(C_word)a,a+=2,tmp));
t6=(C_word)C_a_i_vector(&a,1,lf[55]);
t7=C_mutate(&lf[56],t6);
t8=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1416,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1454,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1485,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[65]+1,*((C_word*)lf[66]+1));
t14=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1535,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1569,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1588,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1627,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2881,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 335  getter-with-setter */
t20=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,t19,*((C_word*)lf[71]+1));}

/* a2880 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2881,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_bytevector_2(t2,lf[73]);
t5=(C_word)C_i_check_exact_2(t3,lf[73]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_lessp(t3,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t3,t6));
if(C_truep(t8)){
/* lolevel.scm: 341  ##sys#error */
t9=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[73],lf[156],t2,t3);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_subbyte(t2,t3));}}

/* k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1664,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1700,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[77]+1,*((C_word*)lf[78]+1));
t6=C_mutate((C_word*)lf[79]+1,*((C_word*)lf[80]+1));
t7=C_mutate((C_word*)lf[81]+1,*((C_word*)lf[82]+1));
t8=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1795,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1801,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1816,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1832,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[94]+1,*((C_word*)lf[95]+1));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 424  getter-with-setter */
t14=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,*((C_word*)lf[155]+1),*((C_word*)lf[95]+1));}

/* k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1,t1);
t3=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1875,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1896,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1918,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1927,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1933,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1987,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2068,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2071,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2178,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2270,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2440,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2524,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2652,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2715,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2746,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2768,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2790,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)C_locative_ref,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 664  getter-with-setter */
t22=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,t21,*((C_word*)lf[137]+1));}

/* k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=C_mutate((C_word*)lf[138]+1,t1);
t3=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2797,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2800,tmp=(C_word)a,a+=2,tmp));
t5=lf[141]=C_SCHEME_FALSE;;
t6=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2807,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2826,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2843,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2849,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2858,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2867,tmp=(C_word)a,a+=2,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2867,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[152]);
t4=(C_word)C_slot(lf[153],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2858,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[150]);
/* lolevel.scm: 699  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[151]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* global-set! in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2849,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[149]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2843,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[148]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2826r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2826r(t0,t1,t2);}}

static void C_ccall f_2826r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2831,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_2831(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_2831(t4,C_SCHEME_FALSE);}}

/* k2829 in unbound-variable-value in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[147]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* set-invalid-procedure-call-handler! in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2807,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2811,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t4=t3;
f_2811(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 675  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[142],lf[145],t2);}}

/* k2809 in set-invalid-procedure-call-handler! in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=C_mutate(&lf[141],((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[143]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2814,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k2809 in set-invalid-procedure-call-handler! in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2814r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2814r(t0,t1,t2);}}

static void C_ccall f_2814r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 679  ipc-hook-0 */
t3=lf[141];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,*((C_word*)lf[144]+1),t2);}

/* locative? in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2800,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k2793 in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2797,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2790,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2768r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2768r(t0,t1,t2,t3);}}

static void C_ccall f_2768r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(0):(C_word)C_slot(t3,C_fix(0)));
/* lolevel.scm: 661  ##sys#make-locative */
t6=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t5,C_SCHEME_TRUE,lf[136]);}

/* make-locative in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2746r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2746r(t0,t1,t2,t3);}}

static void C_ccall f_2746r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(0):(C_word)C_slot(t3,C_fix(0)));
/* lolevel.scm: 658  ##sys#make-locative */
t6=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t5,C_SCHEME_FALSE,lf[92]);}

/* mutate-procedure in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2715,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=(C_word)C_words(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2726,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 650  ##sys#make-vector */
t7=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k2724 in mutate-procedure in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2741,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 651  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2739 in k2724 in mutate-procedure in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 651  ##sys#become! */
t4=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k2727 in k2724 in mutate-procedure in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2652,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[129]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2659,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2664(t8,t4,t2);}

/* loop in object-become! in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2664(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2664,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_pair_2(t4,lf[129]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2686,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
if(C_truep((C_word)C_blockp(t7))){
t8=t6;
f_2686(2,t8,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 638  ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[7],lf[129],lf[132],t4);}}
else{
/* lolevel.scm: 642  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[7],lf[129],lf[133]);}}}

/* k2684 in loop in object-become! in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_blockp(t3))){
t4=t2;
f_2689(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 640  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[129],lf[131],((C_word*)t0)[2]);}}

/* k2687 in k2684 in loop in object-become! in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 641  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2664(t3,((C_word*)t0)[2],t2);}

/* k2657 in object-become! in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 643  ##sys#become! */
t2=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2524r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2524r(t0,t1,t2,t3);}}

static void C_ccall f_2524r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 599  ##sys#make-vector */
t7=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2542,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2542(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2542(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2542,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 603  ##sys#hash-table-ref */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 606  ##sys#make-string */
t4=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 611  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 616  ##sys#make-vector */
t4=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2599 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 617  ##sys#hash-table-set! */
t4=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2602 in k2599 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2613(t7,t2,t3);}

/* do576 in k2602 in k2599 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2613(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2613,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2634,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 620  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2542(t5,t3,t4);}}

/* k2632 in do576 in k2602 in k2599 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2613(t4,((C_word*)t0)[2],t3);}

/* k2605 in k2602 in k2599 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2585 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2590,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 612  ##sys#hash-table-set! */
t3=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2588 in k2585 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2569 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2571,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2574,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 607  ##sys#hash-table-set! */
t4=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2572 in k2569 in k2556 in copy in k2535 in object-unevict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2444,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 576  ##sys#make-vector */
t4=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2449,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2449(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2449(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2449,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 579  ##sys#hash-table-ref */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2460 in evict in k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2462,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 583  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2519(2,t4,(C_word)C_bytes(t2));}}}

/* k2517 in k2460 in evict in k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 585  ##sys#hash-table-set! */
t6=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2469 in k2517 in k2460 in evict in k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2474(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2483(t9,t2,t5);}}

/* do547 in k2469 in k2517 in k2460 in evict in k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2483(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2483,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2505,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 592  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2449(t5,t3,t4);}}

/* k2503 in do547 in k2469 in k2517 in k2460 in evict in k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2483(t5,((C_word*)t0)[2],t4);}

/* k2472 in k2469 in k2517 in k2460 in evict in k2442 in object-size in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2270r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2270r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2270r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2274,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_2274(2,t7,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 531  ##sys#signal-hook */
t7=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[7],lf[113],lf[125],t3);}}

/* k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[113]);
t5=t2;
f_2277(t5,t3);}
else{
t3=t2;
f_2277(t3,C_SCHEME_FALSE);}}

/* k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2277,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2419,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 539  ##sys#pointer->address */
t6=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2417 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 539  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 540  ##sys#make-vector */
t3=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2286,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2291(t6,t2,((C_word*)t0)[2]);}

/* evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2291,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 544  ##sys#hash-table-ref */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 548  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2412(2,t4,(C_word)C_bytes(t2));}}}

/* k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2313,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 555  make-property-condition */
t9=*((C_word*)lf[117]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[120],lf[121],lf[113],lf[122],lf[123],lf[124],t8);}
else{
t6=t3;
f_2313(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2313(2,t4,C_SCHEME_UNDEFINED);}}

/* k2398 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 559  make-property-condition */
t3=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[118],lf[119],((C_word*)((C_word*)t0)[2])[1]);}

/* k2402 in k2398 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 554  make-composite-condition */
t2=*((C_word*)lf[116]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2394 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 553  signal */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2311 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[8]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 562  ##sys#pointer->address */
t7=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[7]);}

/* k2371 in k2311 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 562  ##sys#set-pointer-address! */
t3=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2317 in k2311 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 563  ##sys#hash-table-set! */
t3=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2320 in k2317 in k2311 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2325(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2334(t9,t2,t5);}}

/* do527 in k2320 in k2317 in k2311 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2334,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2355,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 570  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2291(t5,t3,t4);}}

/* k2353 in do527 in k2320 in k2317 in k2311 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2334(t4,((C_word*)t0)[2],t3);}

/* k2323 in k2320 in k2317 in k2311 in k2410 in k2299 in evict in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2284 in k2281 in k2278 in k2275 in k2272 in object-evict-to-location in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 572  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-release in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2178r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2178r(t0,t1,t2,t3);}}

static void C_ccall f_2178r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2260,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2187,a[2]=t9,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2187(t11,t1,t2);}

/* release in object-release in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2187(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2187,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_u_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2216,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_2216(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2232(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* do502 in release in object-release in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2232(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2232,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2242,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 523  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2187(t5,t3,t4);}}

/* k2240 in do502 in release in object-release in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2232(t3,((C_word*)t0)[2],t2);}

/* k2214 in release in object-release in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 524  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2221 in k2214 in release in object-release in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 524  free */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_2260 in object-release in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2260,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub494(C_SCHEME_UNDEFINED,t3));}

/* object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2071r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2071r(t0,t1,t2,t3);}}

static void C_ccall f_2071r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2175,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2078,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 490  ##sys#make-vector */
t7=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2078,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2083(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2083,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 493  ##sys#hash-table-ref */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2091 in evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 496  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2102(2,t4,(C_word)C_bytes(t2));}}}

/* k2100 in k2091 in evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 497  allocator */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k2104 in k2100 in k2091 in evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(C_word)C_i_symbolp(((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 499  ##sys#hash-table-set! */
t6=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2110 in k2104 in k2100 in k2091 in evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2115(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2124(t9,t2,t5);}}

/* do478 in k2110 in k2104 in k2100 in k2091 in evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2124,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2145,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 504  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2083(t5,t3,t4);}}

/* k2143 in do478 in k2110 in k2104 in k2100 in k2091 in evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2124(t4,((C_word*)t0)[2],t3);}

/* k2113 in k2110 in k2104 in k2100 in k2091 in evict in k2076 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2175 in object-evict in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2175,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub467(t3,t2));}

/* object-evicted? in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2068,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* object-copy in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1987,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1993,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1993(t6,t1,t2);}

/* copy in object-copy in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_1993(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1993,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 466  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 470  ##sys#make-vector */
t6=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2021 in copy in object-copy in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_2026(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2038(t10,t3,t6);}}

/* do454 in k2021 in copy in object-copy in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_2038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2038,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2059,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 474  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1993(t5,t3,t4);}}

/* k2057 in do454 in k2021 in copy in object-copy in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2038(t4,((C_word*)t0)[2],t3);}

/* k2024 in k2021 in copy in object-copy in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* record->vector in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1933,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_structurep(t2));
if(C_truep(t4)){
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1946,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 454  ##sys#make-vector */
t7=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
/* lolevel.scm: 458  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[7],lf[104],lf[106],t2);}}

/* k1944 in record->vector in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1951(t2,C_fix(0)));}

/* do441 in k1944 in record->vector in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static C_word C_fcall f_1951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance? in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1927,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE));}

/* make-record-instance in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1918r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1918r(t0,t1,t2,t3);}}

static void C_ccall f_1918r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[101]);
C_apply(5,0,t1,*((C_word*)lf[102]+1),t2,t3);}

/* number-of-bytes in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1896,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 436  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[99],lf[100],t2);}}

/* number-of-slots in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1875,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1888,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1888(t6,t4);}
else{
t6=(C_word)C_specialp(t2);
t7=t5;
f_1888(t7,(C_truep(t6)?t6:(C_word)C_byteblockp(t2)));}}

/* k1886 in number-of-slots in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_1888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* lolevel.scm: 431  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[7],lf[97],lf[98],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1879(2,t2,C_SCHEME_UNDEFINED);}}

/* k1877 in number-of-slots in k1871 in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* byte-vector-append in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1832r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1832r(t0,t1,t2);}}

static void C_ccall f_1832r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1835,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
/* lolevel.scm: 418  append-rest-at */
t6=((C_word*)t4)[1];
f_1835(t6,t1,C_fix(0),t2);}

/* append-rest-at in byte-vector-append in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_1835(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1835,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1851,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_plus(&a,2,t2,t5);
t8=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 414  append-rest-at */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* lolevel.scm: 417  make-byte-vector */
t4=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k1849 in append-rest-at in byte-vector-append in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1854,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 415  byte-vector-move! */
t3=*((C_word*)lf[91]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1852 in k1849 in append-rest-at in byte-vector-append in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* byte-vector-move! in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1816,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1820,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 405  make-locative */
t8=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k1818 in byte-vector-move! in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1823,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 406  make-locative */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1821 in k1818 in byte-vector-move! in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* lolevel.scm: 407  move-memory! */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* static-byte-vector->pointer in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1801,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[88]);
if(C_truep((C_word)C_permanentp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1811,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 399  ##sys#make-pointer */
t5=*((C_word*)lf[89]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* lolevel.scm: 402  ##sys#error */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[88],lf[90],t2);}}

/* k1809 in static-byte-vector->pointer in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_pointer_to_block(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* make-static-byte-vector in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1795r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1795r(t0,t1,t2,t3);}}

static void C_ccall f_1795r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,lf[83]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix((C_word)C_HEADER_SIZE_MASK)))){
/* lolevel.scm: 386  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[84],lf[83],lf[85],t2,C_fix((C_word)C_HEADER_SIZE_MASK));}
else{
t5=t2;
t6=(C_word)stub393(C_SCHEME_UNDEFINED,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1780,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t8=(C_word)C_slot(t3,C_fix(0));
/* lolevel.scm: 389  byte-vector-fill! */
t9=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t6,t8);}
else{
t8=t7;
f_1780(2,t8,C_SCHEME_UNDEFINED);}}
else{
/* lolevel.scm: 391  ##sys#signal-hook */
t7=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[86],lf[87],t2);}}}

/* k1778 in make-static-byte-vector in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->byte-vector in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1700,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[75]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1710,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 358  make-byte-vector */
t6=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1708 in list->byte-vector in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1715(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do382 in k1708 in list->byte-vector in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1715,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1725,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[75]);
t8=t5;
f_1725(2,t8,(C_word)C_setbyte(((C_word*)t0)[4],t3,t6));}
else{
/* lolevel.scm: 366  ##sys#not-a-proper-list-error */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}}

/* k1723 in do382 in k1708 in list->byte-vector in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1715(t4,((C_word*)t0)[2],t2,t3);}

/* byte-vector->list in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1664,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[74]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1676,a[2]=t6,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1676(t8,t1,C_fix(0));}

/* loop in byte-vector->list in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_fcall f_1676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1676,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_subbyte(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1694,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* lolevel.scm: 352  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k1692 in loop in byte-vector->list in k1660 in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1694,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* byte-vector-set! in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1627,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_bytevector_2(t2,lf[71]);
t6=(C_word)C_i_check_exact_2(t3,lf[71]);
t7=(C_word)C_i_check_exact_2(t4,lf[71]);
t8=(C_word)C_block_size(t2);
t9=(C_word)C_fixnum_lessp(t3,C_fix(0));
t10=(C_truep(t9)?t9:(C_word)C_fixnum_greater_or_equal_p(t3,t8));
if(C_truep(t10)){
/* lolevel.scm: 331  ##sys#error */
t11=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t1,lf[71],lf[72],t2,t3);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_setbyte(t2,t3,t4));}}

/* byte-vector in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1588r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1588r(t0,t1,t2);}}

static void C_ccall f_1588r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1595,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 318  make-byte-vector */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1593 in byte-vector in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1600,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1600(t2,C_fix(0),((C_word*)t0)[2]));}

/* do351 in k1593 in byte-vector in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static C_word C_fcall f_1600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_setbyte(((C_word*)t0)[2],t1,t3);
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* make-byte-vector in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1569r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1569r(t0,t1,t2,t3);}}

static void C_ccall f_1569r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1573,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 311  make-blob */
t5=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1571 in make-byte-vector in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1576,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
/* lolevel.scm: 312  byte-vector-fill! */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,t3);}
else{
t3=t2;
f_1576(2,t3,C_SCHEME_UNDEFINED);}}

/* k1574 in k1571 in make-byte-vector in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* byte-vector-fill! in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1535,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_bytevector_2(t2,lf[67]);
t5=(C_word)C_i_check_exact_2(t3,lf[67]);
t6=(C_word)C_block_size(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1550,a[2]=t3,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_1550(t7,C_fix(0)));}

/* do337 in byte-vector-fill! in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static C_word C_fcall f_1550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_setbyte(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* set-procedure-data! in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1519,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1523,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 291  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k1521 in set-procedure-data! in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 294  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[7],lf[63],lf[64],((C_word*)t0)[3]);}}

/* procedure-data in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1485,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1503,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 285  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1502 in procedure-data in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1503,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1493 in procedure-data in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1454,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1467,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1469,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 279  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1468 in extended-procedure? in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1469,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1465 in extended-procedure? in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1416,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1420,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_closurep(t2))){
t5=t4;
f_1420(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 268  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[57],lf[59],t2);}}

/* k1418 in extend-procedure in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1425,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 269  ##sys#decorate-lambda */
t4=*((C_word*)lf[58]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1440 in k1418 in extend-procedure in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1441,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[56],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a1424 in k1418 in extend-procedure in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1425,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-tag in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1394,3,t0,t1,t2);}
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 258  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[53],lf[54],t2);}}

/* tagged-pointer? in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1378,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_equalp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* tag-pointer in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1363,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1367,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 243  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1365 in tag-pointer in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_blockp(((C_word*)t0)[2]))?(C_word)C_specialp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1370(2,t4,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 246  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[49],lf[50],((C_word*)t0)[2]);}}

/* k1368 in k1365 in tag-pointer in k1359 in k1355 in k1351 in k1347 in k1343 in k1339 in k1335 in k1331 in k719 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pointer-f64-set! in k719 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1321,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub253(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-f32-set! in k719 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1311,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub245(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s32-set! in k719 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1301,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub237(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u32-set! in k719 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1291,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub229(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s16-set! in k719 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1281,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub221(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u16-set! in k719 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1271,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub213(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s8-set! in k719 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1261,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub205(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u8-set! in k719 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1251,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub197(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-offset in k719 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1241,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub188(t4,t5,t3));}

/* align-to-word in k719 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1209,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
/* lolevel.scm: 184  align */
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1207(C_a_i(&a,6),t2));}
else{
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1236,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 186  ##sys#pointer->address */
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* lolevel.scm: 187  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[30],lf[31],t2);}}}

/* k1234 in align-to-word in k719 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1236,2,t0,t1);}
t2=f_1207(C_a_i(&a,6),t1);
/* lolevel.scm: 186  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k719 */
static C_word C_fcall f_1207(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
return((C_word)stub181(t2,t1));}

/* free in k719 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1197,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub174(C_SCHEME_UNDEFINED,t3));}

/* allocate in k719 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1194,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub169(t3,t2));}

/* pointer=? in k719 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1185,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1189,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 174  ##sys#check-special */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[27]);}

/* k1187 in pointer=? in k719 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 175  ##sys#check-special */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[27]);}

/* k1190 in k1187 in pointer=? in k719 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k719 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1179,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1183,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 170  ##sys#check-pointer */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[26]);}

/* k1181 in pointer->object in k719 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k719 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1168,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1176,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1176 in object->pointer in k719 */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1176,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub158(t3,t2));}

/* null-pointer? in k719 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1155,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1159,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 160  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[24]);}

/* k1157 in null-pointer? in k719 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 161  ##sys#pointer->address */
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1164 in k1157 in null-pointer? in k719 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k719 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1146,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1150,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 156  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[21]);}

/* k1148 in pointer->address in k719 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 157  ##sys#pointer->address */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k719 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1127,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1131,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_integerp(t2))){
t4=t3;
f_1131(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 151  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[18],lf[20],t2);}}

/* k1129 in address->pointer in k719 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 153  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer? in k719 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1118,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_pointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_taggedpointerp(t2)));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#check-pointer in k719 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1099,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1106,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t2))){
t5=(C_word)C_pointerp(t2);
if(C_truep(t5)){
t6=t4;
f_1106(t6,t5);}
else{
t6=(C_word)C_swigpointerp(t2);
t7=t4;
f_1106(t7,(C_truep(t6)?t6:(C_word)C_taggedpointerp(t2)));}}
else{
t5=t4;
f_1106(t5,C_SCHEME_FALSE);}}

/* k1104 in ##sys#check-pointer in k719 */
static void C_fcall f_1106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 138  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],lf[14],((C_word*)t0)[2]);}}

/* move-memory! in k719 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr4r,(void*)f_775r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_775r(t0,t1,t2,t3,t4);}}

static void C_ccall f_775r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(14);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n78133 */
t9=t8;
f_1039(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset79131 */
t11=t7;
f_1034(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset80128 */
t13=t6;
f_1029(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body7682 */
t15=t5;
f_777(t15,t1,t9,t11,t13);}}}}

/* def-n78 in move-memory! in k719 */
static void C_fcall f_1039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1039,NULL,2,t0,t1);}
/* def-foffset79131 */
t2=((C_word*)t0)[2];
f_1034(t2,t1,C_SCHEME_FALSE);}

/* def-foffset79 in move-memory! in k719 */
static void C_fcall f_1034(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1034,NULL,3,t0,t1,t2);}
/* def-toffset80128 */
t3=((C_word*)t0)[2];
f_1029(t3,t1,t2,C_fix(0));}

/* def-toffset80 in move-memory! in k719 */
static void C_fcall f_1029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1029,NULL,4,t0,t1,t2,t3);}
/* body7682 */
t4=((C_word*)t0)[2];
f_777(t4,t1,t2,t3,C_fix(0));}

/* body76 in move-memory! in k719 */
static void C_fcall f_777(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_777,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_786,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_837,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t2,a[8]=t6,a[9]=t10,a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_837(t12,t1,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* move in body76 in move-memory! in k719 */
static void C_fcall f_837(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_837,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 108  move */
t11=t1;
t12=t5;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 109  xerr */
f_786(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 112  move */
t11=t1;
t12=t2;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 113  xerr */
f_786(t1,t3);}}
else{
t4=(C_word)C_pointerp(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_899(2,t6,t4);}
else{
/* lolevel.scm: 114  ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}}

/* k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_pointerp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_908(2,t4,t2);}
else{
/* lolevel.scm: 115  ##sys#locative? */
t4=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 120  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k958 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=(C_word)C_pointerp(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_975(2,t6,t4);}
else{
/* lolevel.scm: 122  ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 128  xerr */
f_786(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k973 in k958 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:((C_word*)t0)[5]);
/* lolevel.scm: 123  checkn */
t5=((C_word*)t0)[4];
f_792(t5,t2,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 124  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}}

/* k990 in k973 in k958 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 125  checkn2 */
t7=((C_word*)t0)[3];
f_808(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 127  xerr */
f_786(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1000 in k990 in k973 in k958 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub58(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k980 in k973 in k958 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub26(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k906 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_908,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_915(2,t4,t2);}
else{
/* lolevel.scm: 116  err */
t4=((C_word*)t0)[4];
f_780(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 117  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k922 in k906 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_924,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_934,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_938(2,t6,t4);}
else{
/* lolevel.scm: 118  err */
t6=((C_word*)t0)[3];
f_780(t6,t5);}}
else{
/* lolevel.scm: 119  xerr */
f_786(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k936 in k922 in k906 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 118  checkn */
t3=((C_word*)t0)[4];
f_792(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k932 in k922 in k906 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub42(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k913 in k906 in k897 in move in body76 in move-memory! in k719 */
static void C_ccall f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub10(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* checkn2 in body76 in move-memory! in k719 */
static void C_fcall f_808(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_808,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_815,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_u_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_u_fixnum_difference(t4,t6);
t10=t7;
f_815(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_815(t9,C_SCHEME_FALSE);}}

/* k813 in checkn2 in body76 in move-memory! in k719 */
static void C_fcall f_815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* lolevel.scm: 104  ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[7],lf[3],lf[10],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* checkn in body76 in move-memory! in k719 */
static void C_fcall f_792(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_792,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 100  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t6+1)))(8,t6,t1,lf[3],lf[9],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}}

/* xerr in body76 in move-memory! in k719 */
static void C_fcall f_786(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_786,NULL,2,t1,t2);}
/* lolevel.scm: 96   ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[3],lf[8],t2);}

/* err in body76 in move-memory! in k719 */
static void C_fcall f_780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_780,NULL,2,t0,t1);}
/* lolevel.scm: 95   ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[3],lf[5],((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[219] = {
{"toplevellolevel.scm",(void*)C_lolevel_toplevel},
{"f_721lolevel.scm",(void*)f_721},
{"f_2981lolevel.scm",(void*)f_2981},
{"f_1333lolevel.scm",(void*)f_1333},
{"f_2971lolevel.scm",(void*)f_2971},
{"f_1337lolevel.scm",(void*)f_1337},
{"f_2961lolevel.scm",(void*)f_2961},
{"f_1341lolevel.scm",(void*)f_1341},
{"f_2951lolevel.scm",(void*)f_2951},
{"f_1345lolevel.scm",(void*)f_1345},
{"f_2941lolevel.scm",(void*)f_2941},
{"f_1349lolevel.scm",(void*)f_1349},
{"f_2931lolevel.scm",(void*)f_2931},
{"f_1353lolevel.scm",(void*)f_1353},
{"f_2921lolevel.scm",(void*)f_2921},
{"f_1357lolevel.scm",(void*)f_1357},
{"f_2911lolevel.scm",(void*)f_2911},
{"f_1361lolevel.scm",(void*)f_1361},
{"f_2881lolevel.scm",(void*)f_2881},
{"f_1662lolevel.scm",(void*)f_1662},
{"f_1873lolevel.scm",(void*)f_1873},
{"f_2795lolevel.scm",(void*)f_2795},
{"f_2867lolevel.scm",(void*)f_2867},
{"f_2858lolevel.scm",(void*)f_2858},
{"f_2849lolevel.scm",(void*)f_2849},
{"f_2843lolevel.scm",(void*)f_2843},
{"f_2826lolevel.scm",(void*)f_2826},
{"f_2831lolevel.scm",(void*)f_2831},
{"f_2807lolevel.scm",(void*)f_2807},
{"f_2811lolevel.scm",(void*)f_2811},
{"f_2814lolevel.scm",(void*)f_2814},
{"f_2800lolevel.scm",(void*)f_2800},
{"f_2797lolevel.scm",(void*)f_2797},
{"f_2790lolevel.scm",(void*)f_2790},
{"f_2768lolevel.scm",(void*)f_2768},
{"f_2746lolevel.scm",(void*)f_2746},
{"f_2715lolevel.scm",(void*)f_2715},
{"f_2726lolevel.scm",(void*)f_2726},
{"f_2741lolevel.scm",(void*)f_2741},
{"f_2729lolevel.scm",(void*)f_2729},
{"f_2652lolevel.scm",(void*)f_2652},
{"f_2664lolevel.scm",(void*)f_2664},
{"f_2686lolevel.scm",(void*)f_2686},
{"f_2689lolevel.scm",(void*)f_2689},
{"f_2659lolevel.scm",(void*)f_2659},
{"f_2524lolevel.scm",(void*)f_2524},
{"f_2537lolevel.scm",(void*)f_2537},
{"f_2542lolevel.scm",(void*)f_2542},
{"f_2558lolevel.scm",(void*)f_2558},
{"f_2601lolevel.scm",(void*)f_2601},
{"f_2604lolevel.scm",(void*)f_2604},
{"f_2613lolevel.scm",(void*)f_2613},
{"f_2634lolevel.scm",(void*)f_2634},
{"f_2607lolevel.scm",(void*)f_2607},
{"f_2587lolevel.scm",(void*)f_2587},
{"f_2590lolevel.scm",(void*)f_2590},
{"f_2571lolevel.scm",(void*)f_2571},
{"f_2574lolevel.scm",(void*)f_2574},
{"f_2440lolevel.scm",(void*)f_2440},
{"f_2444lolevel.scm",(void*)f_2444},
{"f_2449lolevel.scm",(void*)f_2449},
{"f_2462lolevel.scm",(void*)f_2462},
{"f_2519lolevel.scm",(void*)f_2519},
{"f_2471lolevel.scm",(void*)f_2471},
{"f_2483lolevel.scm",(void*)f_2483},
{"f_2505lolevel.scm",(void*)f_2505},
{"f_2474lolevel.scm",(void*)f_2474},
{"f_2270lolevel.scm",(void*)f_2270},
{"f_2274lolevel.scm",(void*)f_2274},
{"f_2277lolevel.scm",(void*)f_2277},
{"f_2419lolevel.scm",(void*)f_2419},
{"f_2280lolevel.scm",(void*)f_2280},
{"f_2283lolevel.scm",(void*)f_2283},
{"f_2291lolevel.scm",(void*)f_2291},
{"f_2301lolevel.scm",(void*)f_2301},
{"f_2412lolevel.scm",(void*)f_2412},
{"f_2400lolevel.scm",(void*)f_2400},
{"f_2404lolevel.scm",(void*)f_2404},
{"f_2396lolevel.scm",(void*)f_2396},
{"f_2313lolevel.scm",(void*)f_2313},
{"f_2373lolevel.scm",(void*)f_2373},
{"f_2319lolevel.scm",(void*)f_2319},
{"f_2322lolevel.scm",(void*)f_2322},
{"f_2334lolevel.scm",(void*)f_2334},
{"f_2355lolevel.scm",(void*)f_2355},
{"f_2325lolevel.scm",(void*)f_2325},
{"f_2286lolevel.scm",(void*)f_2286},
{"f_2178lolevel.scm",(void*)f_2178},
{"f_2187lolevel.scm",(void*)f_2187},
{"f_2232lolevel.scm",(void*)f_2232},
{"f_2242lolevel.scm",(void*)f_2242},
{"f_2216lolevel.scm",(void*)f_2216},
{"f_2223lolevel.scm",(void*)f_2223},
{"f_2260lolevel.scm",(void*)f_2260},
{"f_2071lolevel.scm",(void*)f_2071},
{"f_2078lolevel.scm",(void*)f_2078},
{"f_2083lolevel.scm",(void*)f_2083},
{"f_2093lolevel.scm",(void*)f_2093},
{"f_2102lolevel.scm",(void*)f_2102},
{"f_2106lolevel.scm",(void*)f_2106},
{"f_2112lolevel.scm",(void*)f_2112},
{"f_2124lolevel.scm",(void*)f_2124},
{"f_2145lolevel.scm",(void*)f_2145},
{"f_2115lolevel.scm",(void*)f_2115},
{"f_2175lolevel.scm",(void*)f_2175},
{"f_2068lolevel.scm",(void*)f_2068},
{"f_1987lolevel.scm",(void*)f_1987},
{"f_1993lolevel.scm",(void*)f_1993},
{"f_2023lolevel.scm",(void*)f_2023},
{"f_2038lolevel.scm",(void*)f_2038},
{"f_2059lolevel.scm",(void*)f_2059},
{"f_2026lolevel.scm",(void*)f_2026},
{"f_1933lolevel.scm",(void*)f_1933},
{"f_1946lolevel.scm",(void*)f_1946},
{"f_1951lolevel.scm",(void*)f_1951},
{"f_1927lolevel.scm",(void*)f_1927},
{"f_1918lolevel.scm",(void*)f_1918},
{"f_1896lolevel.scm",(void*)f_1896},
{"f_1875lolevel.scm",(void*)f_1875},
{"f_1888lolevel.scm",(void*)f_1888},
{"f_1879lolevel.scm",(void*)f_1879},
{"f_1832lolevel.scm",(void*)f_1832},
{"f_1835lolevel.scm",(void*)f_1835},
{"f_1851lolevel.scm",(void*)f_1851},
{"f_1854lolevel.scm",(void*)f_1854},
{"f_1816lolevel.scm",(void*)f_1816},
{"f_1820lolevel.scm",(void*)f_1820},
{"f_1823lolevel.scm",(void*)f_1823},
{"f_1801lolevel.scm",(void*)f_1801},
{"f_1811lolevel.scm",(void*)f_1811},
{"f_1795lolevel.scm",(void*)f_1795},
{"f_1780lolevel.scm",(void*)f_1780},
{"f_1700lolevel.scm",(void*)f_1700},
{"f_1710lolevel.scm",(void*)f_1710},
{"f_1715lolevel.scm",(void*)f_1715},
{"f_1725lolevel.scm",(void*)f_1725},
{"f_1664lolevel.scm",(void*)f_1664},
{"f_1676lolevel.scm",(void*)f_1676},
{"f_1694lolevel.scm",(void*)f_1694},
{"f_1627lolevel.scm",(void*)f_1627},
{"f_1588lolevel.scm",(void*)f_1588},
{"f_1595lolevel.scm",(void*)f_1595},
{"f_1600lolevel.scm",(void*)f_1600},
{"f_1569lolevel.scm",(void*)f_1569},
{"f_1573lolevel.scm",(void*)f_1573},
{"f_1576lolevel.scm",(void*)f_1576},
{"f_1535lolevel.scm",(void*)f_1535},
{"f_1550lolevel.scm",(void*)f_1550},
{"f_1519lolevel.scm",(void*)f_1519},
{"f_1523lolevel.scm",(void*)f_1523},
{"f_1485lolevel.scm",(void*)f_1485},
{"f_1503lolevel.scm",(void*)f_1503},
{"f_1495lolevel.scm",(void*)f_1495},
{"f_1454lolevel.scm",(void*)f_1454},
{"f_1469lolevel.scm",(void*)f_1469},
{"f_1467lolevel.scm",(void*)f_1467},
{"f_1416lolevel.scm",(void*)f_1416},
{"f_1420lolevel.scm",(void*)f_1420},
{"f_1441lolevel.scm",(void*)f_1441},
{"f_1425lolevel.scm",(void*)f_1425},
{"f_1394lolevel.scm",(void*)f_1394},
{"f_1378lolevel.scm",(void*)f_1378},
{"f_1363lolevel.scm",(void*)f_1363},
{"f_1367lolevel.scm",(void*)f_1367},
{"f_1370lolevel.scm",(void*)f_1370},
{"f_1321lolevel.scm",(void*)f_1321},
{"f_1311lolevel.scm",(void*)f_1311},
{"f_1301lolevel.scm",(void*)f_1301},
{"f_1291lolevel.scm",(void*)f_1291},
{"f_1281lolevel.scm",(void*)f_1281},
{"f_1271lolevel.scm",(void*)f_1271},
{"f_1261lolevel.scm",(void*)f_1261},
{"f_1251lolevel.scm",(void*)f_1251},
{"f_1241lolevel.scm",(void*)f_1241},
{"f_1209lolevel.scm",(void*)f_1209},
{"f_1236lolevel.scm",(void*)f_1236},
{"f_1207lolevel.scm",(void*)f_1207},
{"f_1197lolevel.scm",(void*)f_1197},
{"f_1194lolevel.scm",(void*)f_1194},
{"f_1185lolevel.scm",(void*)f_1185},
{"f_1189lolevel.scm",(void*)f_1189},
{"f_1192lolevel.scm",(void*)f_1192},
{"f_1179lolevel.scm",(void*)f_1179},
{"f_1183lolevel.scm",(void*)f_1183},
{"f_1168lolevel.scm",(void*)f_1168},
{"f_1176lolevel.scm",(void*)f_1176},
{"f_1155lolevel.scm",(void*)f_1155},
{"f_1159lolevel.scm",(void*)f_1159},
{"f_1166lolevel.scm",(void*)f_1166},
{"f_1146lolevel.scm",(void*)f_1146},
{"f_1150lolevel.scm",(void*)f_1150},
{"f_1127lolevel.scm",(void*)f_1127},
{"f_1131lolevel.scm",(void*)f_1131},
{"f_1118lolevel.scm",(void*)f_1118},
{"f_1099lolevel.scm",(void*)f_1099},
{"f_1106lolevel.scm",(void*)f_1106},
{"f_775lolevel.scm",(void*)f_775},
{"f_1039lolevel.scm",(void*)f_1039},
{"f_1034lolevel.scm",(void*)f_1034},
{"f_1029lolevel.scm",(void*)f_1029},
{"f_777lolevel.scm",(void*)f_777},
{"f_837lolevel.scm",(void*)f_837},
{"f_899lolevel.scm",(void*)f_899},
{"f_960lolevel.scm",(void*)f_960},
{"f_975lolevel.scm",(void*)f_975},
{"f_992lolevel.scm",(void*)f_992},
{"f_1002lolevel.scm",(void*)f_1002},
{"f_982lolevel.scm",(void*)f_982},
{"f_908lolevel.scm",(void*)f_908},
{"f_924lolevel.scm",(void*)f_924},
{"f_938lolevel.scm",(void*)f_938},
{"f_934lolevel.scm",(void*)f_934},
{"f_915lolevel.scm",(void*)f_915},
{"f_808lolevel.scm",(void*)f_808},
{"f_815lolevel.scm",(void*)f_815},
{"f_792lolevel.scm",(void*)f_792},
{"f_786lolevel.scm",(void*)f_786},
{"f_780lolevel.scm",(void*)f_780},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
