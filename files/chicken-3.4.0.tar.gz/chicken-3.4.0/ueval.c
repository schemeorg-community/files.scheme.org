/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-23 22:56
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11106	compiled 2008-07-08 on galinha (Linux)
   command line: eval.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[524];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static C_word C_fcall stub1367(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1367(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11475)
static void C_ccall f_11475(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11475)
static void C_ccall f_11475r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11479)
static void C_fcall f_11479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11503)
static void C_ccall f_11503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11497)
static void C_ccall f_11497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11487)
static void C_ccall f_11487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11485)
static void C_ccall f_11485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11469)
static void C_ccall f_11469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11465)
static void C_ccall f_11465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11461)
static void C_ccall f_11461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11457)
static void C_ccall f_11457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11447)
static void C_fcall f_11447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_fcall f_6787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6792)
static void C_ccall f_6792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11425)
static void C_ccall f_11425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11419)
static void C_ccall f_11419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11386)
static void C_ccall f_11386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11406)
static void C_ccall f_11406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11402)
static void C_ccall f_11402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11389)
static void C_ccall f_11389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11332)
static void C_ccall f_11332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11346)
static void C_fcall f_11346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11378)
static void C_ccall f_11378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11366)
static void C_ccall f_11366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11370)
static void C_ccall f_11370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11340)
static void C_ccall f_11340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11211)
static void C_ccall f_11211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11248)
static void C_fcall f_11248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11257)
static void C_ccall f_11257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11276)
static void C_ccall f_11276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11280)
static void C_ccall f_11280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11266)
static void C_ccall f_11266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11263)
static void C_ccall f_11263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_fcall f_11214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11209)
static void C_ccall f_11209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8267)
static void C_ccall f_8267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8271)
static void C_ccall f_8271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11205)
static void C_ccall f_11205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11108)
static void C_ccall f_11108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11114)
static void C_fcall f_11114(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11130)
static void C_ccall f_11130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11133)
static void C_ccall f_11133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11168)
static void C_ccall f_11168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11171)
static void C_ccall f_11171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11155)
static void C_ccall f_11155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11080)
static void C_ccall f_11080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8964)
static void C_ccall f_8964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11037)
static void C_ccall f_11037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11059)
static void C_ccall f_11059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8967)
static void C_ccall f_8967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10840)
static void C_ccall f_10840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10846)
static void C_fcall f_10846(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10862)
static void C_ccall f_10862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10938)
static void C_fcall f_10938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10995)
static void C_ccall f_10995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10941)
static void C_ccall f_10941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10968)
static void C_ccall f_10968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10901)
static void C_ccall f_10901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10920)
static void C_ccall f_10920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10892)
static void C_ccall f_10892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8970)
static void C_ccall f_8970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10737)
static void C_ccall f_10737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10747)
static void C_ccall f_10747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10760)
static void C_fcall f_10760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10776)
static void C_ccall f_10776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10814)
static void C_ccall f_10814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10812)
static void C_ccall f_10812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10804)
static void C_ccall f_10804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10758)
static void C_ccall f_10758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8973)
static void C_ccall f_8973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10684)
static void C_ccall f_10684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10694)
static void C_ccall f_10694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10697)
static void C_ccall f_10697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10702)
static void C_fcall f_10702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8976)
static void C_ccall f_8976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10674)
static void C_ccall f_10674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10638)
static void C_ccall f_10638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10642)
static void C_ccall f_10642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10495)
static void C_ccall f_10495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10495)
static void C_ccall f_10495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10499)
static void C_ccall f_10499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10502)
static void C_ccall f_10502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10505)
static void C_ccall f_10505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10596)
static void C_ccall f_10596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10512)
static void C_ccall f_10512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10535)
static void C_fcall f_10535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10549)
static void C_ccall f_10549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_ccall f_8982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10203)
static void C_ccall f_10203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10413)
static void C_fcall f_10413(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10417)
static void C_ccall f_10417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10438)
static void C_ccall f_10438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10480)
static void C_ccall f_10480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10216)
static void C_fcall f_10216(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10404)
static void C_ccall f_10404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10408)
static void C_ccall f_10408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10387)
static void C_ccall f_10387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10391)
static void C_ccall f_10391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10376)
static void C_ccall f_10376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10357)
static void C_ccall f_10357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10323)
static void C_ccall f_10323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10304)
static void C_ccall f_10304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10277)
static void C_ccall f_10277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10234)
static void C_ccall f_10234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10230)
static void C_ccall f_10230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10206)
static void C_fcall f_10206(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10214)
static void C_ccall f_10214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8985)
static void C_ccall f_8985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10193)
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9947)
static void C_ccall f_9947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10102)
static void C_fcall f_10102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10173)
static void C_ccall f_10173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10116)
static void C_ccall f_10116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9960)
static void C_fcall f_9960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10086)
static void C_ccall f_10086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10048)
static void C_ccall f_10048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10009)
static void C_ccall f_10009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9950)
static void C_fcall f_9950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9944)
static void C_ccall f_9944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9802)
static void C_ccall f_9802(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9802)
static void C_ccall f_9802r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9923)
static void C_ccall f_9923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9910)
static void C_ccall f_9910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9805)
static void C_fcall f_9805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9809)
static void C_fcall f_9809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9820)
static void C_fcall f_9820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9463)
static void C_ccall f_9463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9787)
static void C_ccall f_9787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9796)
static void C_ccall f_9796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9794)
static void C_ccall f_9794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9777)
static void C_ccall f_9777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9469)
static void C_ccall f_9469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9771)
static void C_ccall f_9771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9472)
static void C_ccall f_9472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9762)
static void C_ccall f_9762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9769)
static void C_ccall f_9769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static void C_ccall f_9752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9750)
static void C_ccall f_9750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9724)
static void C_ccall f_9724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9728)
static void C_ccall f_9728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9735)
static void C_ccall f_9735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9689)
static void C_ccall f_9689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9695)
static void C_ccall f_9695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9699)
static void C_ccall f_9699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9702)
static void C_ccall f_9702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9709)
static void C_ccall f_9709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9673)
static void C_ccall f_9673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9679)
static void C_ccall f_9679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9687)
static void C_ccall f_9687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9636)
static void C_ccall f_9636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9640)
static void C_ccall f_9640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9645)
static void C_ccall f_9645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9671)
static void C_ccall f_9671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9667)
static void C_ccall f_9667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9652)
static void C_ccall f_9652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9659)
static void C_ccall f_9659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9610)
static void C_ccall f_9610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9620)
static void C_ccall f_9620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9634)
static void C_ccall f_9634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9623)
static void C_ccall f_9623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9597)
static C_word C_fcall f_9597(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9571)
static void C_ccall f_9571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9575)
static void C_ccall f_9575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9580)
static void C_ccall f_9580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9584)
static void C_ccall f_9584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9595)
static void C_ccall f_9595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9591)
static void C_ccall f_9591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9555)
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9561)
static void C_ccall f_9561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9569)
static void C_ccall f_9569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9549)
static void C_ccall f_9549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9534)
static void C_fcall f_9534(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9538)
static void C_ccall f_9538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9475)
static void C_fcall f_9475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9510)
static void C_ccall f_9510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9528)
static void C_ccall f_9528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9516)
static void C_ccall f_9516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9491)
static void C_ccall f_9491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9497)
static void C_ccall f_9497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9501)
static void C_ccall f_9501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9504)
static void C_ccall f_9504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9508)
static void C_ccall f_9508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9483)
static void C_ccall f_9483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9401)
static void C_ccall f_9401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9415)
static void C_fcall f_9415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9433)
static void C_ccall f_9433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9402)
static void C_fcall f_9402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9082)
static void C_ccall f_9082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9362)
static void C_ccall f_9362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9370)
static void C_ccall f_9370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9167)
static void C_ccall f_9167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9173)
static void C_fcall f_9173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9180)
static void C_ccall f_9180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9183)
static void C_ccall f_9183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9340)
static void C_ccall f_9340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9195)
static void C_ccall f_9195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9231)
static void C_fcall f_9231(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9294)
static void C_ccall f_9294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9247)
static void C_ccall f_9247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9256)
static void C_ccall f_9256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9259)
static void C_ccall f_9259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_fcall f_9063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_ccall f_9068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9204)
static void C_ccall f_9204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9102)
static void C_ccall f_9102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9115)
static void C_ccall f_9115(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9115)
static void C_ccall f_9115r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9137)
static void C_fcall f_9137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9146)
static void C_ccall f_9146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static void C_ccall f_9128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9131)
static void C_ccall f_9131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9093)
static C_word C_fcall f_9093(C_word t0);
C_noret_decl(f_9087)
static C_word C_fcall f_9087(C_word t0);
C_noret_decl(f_9041)
static void C_fcall f_9041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9047)
static void C_ccall f_9047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9033)
static void C_ccall f_9033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9030)
static void C_ccall f_9030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9000)
static void C_ccall f_9000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9009)
static void C_ccall f_9009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8569)
static void C_ccall f_8569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8569)
static void C_ccall f_8569r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8706)
static void C_fcall f_8706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8711)
static void C_fcall f_8711(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8929)
static void C_ccall f_8929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8856)
static void C_ccall f_8856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8727)
static void C_fcall f_8727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static void C_fcall f_8732(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8683)
static C_word C_fcall f_8683(C_word t0);
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8627)
static void C_fcall f_8627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8650)
static void C_ccall f_8650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8572)
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8579)
static void C_ccall f_8579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8584)
static void C_fcall f_8584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8588)
static void C_ccall f_8588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8613)
static void C_ccall f_8613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8606)
static void C_ccall f_8606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8533)
static void C_ccall f_8533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8478)
static void C_ccall f_8478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_ccall f_8484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8487)
static void C_ccall f_8487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8490)
static void C_ccall f_8490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_ccall f_8493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static void C_ccall f_8496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8499)
static void C_ccall f_8499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8450)
static void C_fcall f_8450(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8457)
static void C_ccall f_8457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8426)
static void C_fcall f_8426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8432)
static void C_fcall f_8432(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_fcall f_8373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8397)
static void C_ccall f_8397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8344)
static void C_fcall f_8344(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8309)
static void C_fcall f_8309(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8284)
static void C_fcall f_8284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8288)
static void C_ccall f_8288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_fcall f_8251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8257)
static void C_ccall f_8257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8220)
static void C_ccall f_8220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8166)
static void C_ccall f_8166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8141)
static void C_ccall f_8141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8068)
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8092)
static void C_fcall f_8092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7981)
static void C_fcall f_7981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7888)
static void C_fcall f_7888(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7908)
static void C_fcall f_7908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7433)
static void C_ccall f_7433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7708)
static void C_fcall f_7708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7745)
static void C_fcall f_7745(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_fcall f_7457(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7628)
static void C_fcall f_7628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7648)
static void C_ccall f_7648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_fcall f_7632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_fcall f_7561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_fcall f_7569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_fcall f_7516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7482)
static void C_fcall f_7482(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7436)
static void C_fcall f_7436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7384)
static void C_ccall f_7384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7390)
static void C_fcall f_7390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_fcall f_7407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7372)
static void C_ccall f_7372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7334)
static void C_ccall f_7334(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7334)
static void C_ccall f_7334r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7331)
static void C_ccall f_7331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7306)
static void C_ccall f_7306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_fcall f_7236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_ccall f_7239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7263)
static void C_ccall f_7263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_ccall f_7189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_fcall f_7191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_fcall f_7158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7178)
static void C_ccall f_7178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7097)
static void C_fcall f_7097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_fcall f_7019(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static C_word C_fcall f_7001(C_word t0);
C_noret_decl(f_6995)
static void C_fcall f_6995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6936)
static void C_ccall f_6936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6945)
static void C_fcall f_6945(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6983)
static void C_ccall f_6983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_fcall f_6814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_fcall f_6825(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_fcall f_6841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6776)
static void C_ccall f_6776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6733)
static void C_ccall f_6733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6658)
static void C_fcall f_6658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6653)
static void C_fcall f_6653(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6318)
static void C_fcall f_6318(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_fcall f_6322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_fcall f_6604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6325)
static void C_ccall f_6325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6549)
static void C_ccall f_6549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6389)
static void C_ccall f_6389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_fcall f_6397(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6462)
static void C_ccall f_6462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6466)
static void C_ccall f_6466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6379)
static void C_ccall f_6379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6337)
static void C_ccall f_6337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_fcall f_6270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static C_word C_fcall f_6280(C_word t0,C_word t1);
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6207)
static void C_fcall f_6207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6119)
static void C_fcall f_6119(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_fcall f_6109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5837)
static void C_fcall f_5837(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6016)
static void C_ccall f_6016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_ccall f_5948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static C_word C_fcall f_5811(C_word t0,C_word t1);
C_noret_decl(f_4060)
static void C_fcall f_4060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_fcall f_4227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_fcall f_5631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5472)
static void C_ccall f_5472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_fcall f_5430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5765)
static void C_fcall f_5765(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_fcall f_4944(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4759)
static void C_ccall f_4759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_fcall f_4130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_fcall f_4125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4054)
static void C_fcall f_4054(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4048)
static C_word C_fcall f_4048(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4042)
static C_word C_fcall f_4042(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3989)
static void C_fcall f_3989(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_fcall f_4008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_fcall f_4017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_fcall f_3877(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_fcall f_3835(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3841)
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3959)
static C_word C_fcall f_3959(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_fcall f_3737(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3664)
static void C_fcall f_3664(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3680)
static void C_fcall f_3680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3621)
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_fcall f_3552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static C_word C_fcall f_3508(C_word t0,C_word t1);
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_fcall f_3423(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_fcall f_3332(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3284)
static void C_fcall f_3284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_fcall f_3279(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2848)
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3031)
static void C_fcall f_3031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3037)
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_fcall f_2851(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_fcall f_2863(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2882)
static void C_fcall f_2882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2349)
static void C_fcall f_2349(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2789)
static void C_fcall f_2789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_fcall f_2708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_fcall f_2662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_fcall f_2665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_fcall f_2625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_fcall f_2593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_fcall f_2535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_fcall f_2367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_fcall f_2379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_fcall f_2370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_fcall f_2330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2290)
static void C_fcall f_2290(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2309)
static void C_fcall f_2309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2241)
static void C_fcall f_2241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2159)
static void C_fcall f_2159(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_fcall f_1998(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_fcall f_2026(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_fcall f_1884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1920)
static void C_fcall f_1920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_fcall f_1881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737r(C_word t0,C_word t1,C_word t3) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9752,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9737,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9715,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9689,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9673,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9636,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9610,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9571,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9555,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9543,0));}

C_noret_decl(trf_11479)
static void C_fcall trf_11479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11479(t0,t1);}

C_noret_decl(trf_11447)
static void C_fcall trf_11447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11447(t0,t1);}

C_noret_decl(trf_6787)
static void C_fcall trf_6787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6787(t0,t1);}

C_noret_decl(trf_11346)
static void C_fcall trf_11346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11346(t0,t1,t2);}

C_noret_decl(trf_11248)
static void C_fcall trf_11248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11248(t0,t1);}

C_noret_decl(trf_11214)
static void C_fcall trf_11214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11214(t0,t1);}

C_noret_decl(trf_11114)
static void C_fcall trf_11114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11114(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11114(t0,t1,t2);}

C_noret_decl(trf_10846)
static void C_fcall trf_10846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10846(t0,t1,t2);}

C_noret_decl(trf_10938)
static void C_fcall trf_10938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10938(t0,t1);}

C_noret_decl(trf_10760)
static void C_fcall trf_10760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10760(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10760(t0,t1,t2);}

C_noret_decl(trf_10702)
static void C_fcall trf_10702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10702(t0,t1,t2);}

C_noret_decl(trf_10535)
static void C_fcall trf_10535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10535(t0,t1);}

C_noret_decl(trf_10413)
static void C_fcall trf_10413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10413(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10413(t0,t1,t2);}

C_noret_decl(trf_10216)
static void C_fcall trf_10216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10216(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10216(t0,t1,t2,t3);}

C_noret_decl(trf_10206)
static void C_fcall trf_10206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10206(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10206(t0,t1,t2,t3);}

C_noret_decl(trf_10102)
static void C_fcall trf_10102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10102(t0,t1,t2);}

C_noret_decl(trf_9960)
static void C_fcall trf_9960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9960(t0,t1,t2);}

C_noret_decl(trf_9950)
static void C_fcall trf_9950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9950(t0,t1,t2);}

C_noret_decl(trf_9805)
static void C_fcall trf_9805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9805(t0,t1,t2);}

C_noret_decl(trf_9809)
static void C_fcall trf_9809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9809(t0,t1);}

C_noret_decl(trf_9820)
static void C_fcall trf_9820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9820(t0,t1);}

C_noret_decl(trf_9534)
static void C_fcall trf_9534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9534(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9534(t0,t1,t2);}

C_noret_decl(trf_9475)
static void C_fcall trf_9475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9475(t0,t1);}

C_noret_decl(trf_9415)
static void C_fcall trf_9415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9415(t0,t1);}

C_noret_decl(trf_9402)
static void C_fcall trf_9402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9402(t0,t1);}

C_noret_decl(trf_9173)
static void C_fcall trf_9173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9173(t0,t1);}

C_noret_decl(trf_9231)
static void C_fcall trf_9231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9231(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9231(t0,t1,t2,t3);}

C_noret_decl(trf_9063)
static void C_fcall trf_9063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9063(t0,t1);}

C_noret_decl(trf_9137)
static void C_fcall trf_9137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9137(t0,t1);}

C_noret_decl(trf_9041)
static void C_fcall trf_9041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9041(t0,t1);}

C_noret_decl(trf_8706)
static void C_fcall trf_8706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8706(t0,t1);}

C_noret_decl(trf_8711)
static void C_fcall trf_8711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8711(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8711(t0,t1,t2,t3);}

C_noret_decl(trf_8727)
static void C_fcall trf_8727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8727(t0,t1);}

C_noret_decl(trf_8732)
static void C_fcall trf_8732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8732(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8732(t0,t1,t2,t3);}

C_noret_decl(trf_8627)
static void C_fcall trf_8627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8627(t0,t1,t2);}

C_noret_decl(trf_8572)
static void C_fcall trf_8572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8572(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8572(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8584)
static void C_fcall trf_8584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8584(t0,t1,t2);}

C_noret_decl(trf_8450)
static void C_fcall trf_8450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8450(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8450(t0,t1,t2,t3);}

C_noret_decl(trf_8426)
static void C_fcall trf_8426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8426(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8426(t0,t1,t2);}

C_noret_decl(trf_8432)
static void C_fcall trf_8432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8432(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8432(t0,t1,t2);}

C_noret_decl(trf_8373)
static void C_fcall trf_8373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8373(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8373(t0,t1,t2);}

C_noret_decl(trf_8344)
static void C_fcall trf_8344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8344(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8344(t0,t1,t2);}

C_noret_decl(trf_8309)
static void C_fcall trf_8309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8309(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8309(t0,t1,t2,t3);}

C_noret_decl(trf_8284)
static void C_fcall trf_8284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8284(t0,t1);}

C_noret_decl(trf_8251)
static void C_fcall trf_8251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8251(t0,t1);}

C_noret_decl(trf_8068)
static void C_fcall trf_8068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8068(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8068(t0,t1,t2,t3);}

C_noret_decl(trf_8092)
static void C_fcall trf_8092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8092(t0,t1,t2,t3);}

C_noret_decl(trf_7954)
static void C_fcall trf_7954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7954(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7954(t0,t1,t2);}

C_noret_decl(trf_7981)
static void C_fcall trf_7981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7981(t0,t1,t2);}

C_noret_decl(trf_7888)
static void C_fcall trf_7888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7888(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7888(t0,t1,t2);}

C_noret_decl(trf_7908)
static void C_fcall trf_7908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7908(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7908(t0,t1);}

C_noret_decl(trf_7708)
static void C_fcall trf_7708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7708(t0,t1);}

C_noret_decl(trf_7745)
static void C_fcall trf_7745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7745(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7745(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7457)
static void C_fcall trf_7457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7457(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7457(t0,t1,t2);}

C_noret_decl(trf_7628)
static void C_fcall trf_7628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7628(t0,t1);}

C_noret_decl(trf_7632)
static void C_fcall trf_7632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7632(t0,t1);}

C_noret_decl(trf_7561)
static void C_fcall trf_7561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7561(t0,t1);}

C_noret_decl(trf_7569)
static void C_fcall trf_7569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7569(t0,t1);}

C_noret_decl(trf_7516)
static void C_fcall trf_7516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7516(t0,t1);}

C_noret_decl(trf_7482)
static void C_fcall trf_7482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7482(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7482(t0,t1);}

C_noret_decl(trf_7436)
static void C_fcall trf_7436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7436(t0,t1,t2);}

C_noret_decl(trf_7390)
static void C_fcall trf_7390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7390(t0,t1,t2);}

C_noret_decl(trf_7407)
static void C_fcall trf_7407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7407(t0,t1);}

C_noret_decl(trf_7236)
static void C_fcall trf_7236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7236(t0,t1);}

C_noret_decl(trf_7191)
static void C_fcall trf_7191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7191(t0,t1,t2);}

C_noret_decl(trf_7158)
static void C_fcall trf_7158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7158(t0,t1,t2);}

C_noret_decl(trf_7097)
static void C_fcall trf_7097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7097(t0,t1,t2);}

C_noret_decl(trf_7019)
static void C_fcall trf_7019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7019(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7019(t0,t1,t2);}

C_noret_decl(trf_6995)
static void C_fcall trf_6995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6995(t0,t1);}

C_noret_decl(trf_6945)
static void C_fcall trf_6945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6945(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6945(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6814)
static void C_fcall trf_6814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6814(t0,t1);}

C_noret_decl(trf_6825)
static void C_fcall trf_6825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6825(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6825(t0,t1,t2);}

C_noret_decl(trf_6841)
static void C_fcall trf_6841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6841(t0,t1);}

C_noret_decl(trf_6658)
static void C_fcall trf_6658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6658(t0,t1);}

C_noret_decl(trf_6653)
static void C_fcall trf_6653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6653(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6653(t0,t1,t2);}

C_noret_decl(trf_6318)
static void C_fcall trf_6318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6318(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6318(t0,t1,t2,t3);}

C_noret_decl(trf_6322)
static void C_fcall trf_6322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6322(t0,t1);}

C_noret_decl(trf_6604)
static void C_fcall trf_6604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6604(t0,t1);}

C_noret_decl(trf_6397)
static void C_fcall trf_6397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6397(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6397(t0,t1,t2);}

C_noret_decl(trf_6270)
static void C_fcall trf_6270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6270(t0,t1);}

C_noret_decl(trf_6207)
static void C_fcall trf_6207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6207(t0,t1,t2);}

C_noret_decl(trf_6119)
static void C_fcall trf_6119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6119(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6119(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6109)
static void C_fcall trf_6109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6109(t0,t1);}

C_noret_decl(trf_5837)
static void C_fcall trf_5837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5837(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5837(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4060)
static void C_fcall trf_4060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4060(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4060(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4227)
static void C_fcall trf_4227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4227(t0,t1);}

C_noret_decl(trf_5631)
static void C_fcall trf_5631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5631(t0,t1);}

C_noret_decl(trf_5478)
static void C_fcall trf_5478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5478(t0,t1,t2);}

C_noret_decl(trf_5430)
static void C_fcall trf_5430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5430(t0,t1);}

C_noret_decl(trf_5765)
static void C_fcall trf_5765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5765(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5765(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4944)
static void C_fcall trf_4944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4944(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4944(t0,t1,t2,t3);}

C_noret_decl(trf_4130)
static void C_fcall trf_4130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4130(t0,t1);}

C_noret_decl(trf_4125)
static void C_fcall trf_4125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4125(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4125(t0,t1);}

C_noret_decl(trf_4054)
static void C_fcall trf_4054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4054(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4054(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3989)
static void C_fcall trf_3989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3989(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3989(t0,t1,t2,t3);}

C_noret_decl(trf_4008)
static void C_fcall trf_4008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4008(t0,t1);}

C_noret_decl(trf_4017)
static void C_fcall trf_4017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4017(t0,t1);}

C_noret_decl(trf_3877)
static void C_fcall trf_3877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3877(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3877(t0,t1,t2,t3);}

C_noret_decl(trf_3835)
static void C_fcall trf_3835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3835(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3835(t0,t1,t2);}

C_noret_decl(trf_3841)
static void C_fcall trf_3841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3841(t0,t1,t2,t3);}

C_noret_decl(trf_3737)
static void C_fcall trf_3737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3737(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3737(t0,t1,t2);}

C_noret_decl(trf_3664)
static void C_fcall trf_3664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3664(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3664(t0,t1,t2,t3);}

C_noret_decl(trf_3680)
static void C_fcall trf_3680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3680(t0,t1,t2,t3);}

C_noret_decl(trf_3621)
static void C_fcall trf_3621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3621(t0,t1,t2);}

C_noret_decl(trf_3552)
static void C_fcall trf_3552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3552(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3552(t0,t1,t2);}

C_noret_decl(trf_3423)
static void C_fcall trf_3423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3423(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3423(t0,t1,t2,t3);}

C_noret_decl(trf_3332)
static void C_fcall trf_3332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3332(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3332(t0,t1,t2,t3);}

C_noret_decl(trf_3284)
static void C_fcall trf_3284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3284(t0,t1);}

C_noret_decl(trf_3279)
static void C_fcall trf_3279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3279(t0,t1,t2);}

C_noret_decl(trf_2848)
static void C_fcall trf_2848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2848(t0,t1,t2);}

C_noret_decl(trf_3031)
static void C_fcall trf_3031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3031(t0,t1,t2);}

C_noret_decl(trf_3037)
static void C_fcall trf_3037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3037(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3037(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3088)
static void C_fcall trf_3088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3088(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3088(t0,t1,t2);}

C_noret_decl(trf_2851)
static void C_fcall trf_2851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2851(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2851(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2863)
static void C_fcall trf_2863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2863(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2863(t0,t1,t2,t3);}

C_noret_decl(trf_2882)
static void C_fcall trf_2882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2882(t0,t1);}

C_noret_decl(trf_2349)
static void C_fcall trf_2349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2349(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2349(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2789)
static void C_fcall trf_2789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2789(t0,t1);}

C_noret_decl(trf_2708)
static void C_fcall trf_2708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2708(t0,t1);}

C_noret_decl(trf_2662)
static void C_fcall trf_2662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2662(t0,t1);}

C_noret_decl(trf_2665)
static void C_fcall trf_2665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2665(t0,t1);}

C_noret_decl(trf_2625)
static void C_fcall trf_2625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2625(t0,t1);}

C_noret_decl(trf_2593)
static void C_fcall trf_2593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2593(t0,t1);}

C_noret_decl(trf_2535)
static void C_fcall trf_2535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2535(t0,t1);}

C_noret_decl(trf_2367)
static void C_fcall trf_2367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2367(t0,t1);}

C_noret_decl(trf_2379)
static void C_fcall trf_2379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2379(t0,t1);}

C_noret_decl(trf_2370)
static void C_fcall trf_2370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2370(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2370(t0,t1);}

C_noret_decl(trf_2330)
static void C_fcall trf_2330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2330(t0,t1,t2);}

C_noret_decl(trf_2290)
static void C_fcall trf_2290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2290(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2290(t0,t1,t2);}

C_noret_decl(trf_2309)
static void C_fcall trf_2309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2309(t0,t1);}

C_noret_decl(trf_2241)
static void C_fcall trf_2241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2241(t0,t1,t2);}

C_noret_decl(trf_2159)
static void C_fcall trf_2159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2159(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2159(t0,t1);}

C_noret_decl(trf_1998)
static void C_fcall trf_1998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1998(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1998(t0,t1,t2,t3);}

C_noret_decl(trf_2026)
static void C_fcall trf_2026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2026(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2026(t0,t1,t2);}

C_noret_decl(trf_1852)
static void C_fcall trf_1852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1852(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1852(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1884)
static void C_fcall trf_1884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1884(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1884(t0,t1);}

C_noret_decl(trf_1901)
static void C_fcall trf_1901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1901(t0,t1,t2);}

C_noret_decl(trf_1920)
static void C_fcall trf_1920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1920(t0,t1);}

C_noret_decl(trf_1881)
static void C_fcall trf_1881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1881(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(7695)){
C_save(t1);
C_rereclaim2(7695*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,524);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscore-library-modules");
lf[3]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000\002\376\001\000\000\005regex\376\003\000\000"
"\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005match\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000\002\376\001"
"\000\000\005ports\376\003\000\000\002\376\001\000\000\005files\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000"
"\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\003\000\000\002\376\001\000\000\007srfi-69\376\377\016");
lf[4]=C_h_intern(&lf[4],28,"\003sysexplicit-library-modules");
lf[6]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022chicken-ffi-macros\376\003\000\000\002\376\001\000\000\023chicken-more-macros\376\377\016");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\377\016");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[31]=C_h_intern(&lf[31],18,"\003syschicken-prefix");
lf[32]=C_h_intern(&lf[32],17,"\003sysstring-append");
lf[33]=C_h_intern(&lf[33],6,"getenv");
lf[34]=C_h_intern(&lf[34],12,"chicken-home");
lf[35]=C_h_intern(&lf[35],17,"\003syspeek-c-string");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[37]=C_h_intern(&lf[37],21,"\003sysmacro-environment");
lf[38]=C_h_intern(&lf[38],20,"\003sysregister-macro-2");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],18,"\003sysregister-macro");
lf[41]=C_h_intern(&lf[41],14,"\003syscopy-macro");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],6,"macro\077");
lf[44]=C_h_intern(&lf[44],15,"undefine-macro!");
lf[45]=C_h_intern(&lf[45],13,"string-append");
lf[46]=C_h_intern(&lf[46],17,"\003sysmacroexpand-0");
lf[47]=C_h_intern(&lf[47],9,"\003sysabort");
lf[48]=C_h_intern(&lf[48],9,"condition");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[53]=C_h_intern(&lf[53],3,"exn");
lf[54]=C_h_intern(&lf[54],22,"with-exception-handler");
lf[55]=C_h_intern(&lf[55],30,"call-with-current-continuation");
lf[56]=C_h_intern(&lf[56],21,"\003syssyntax-error-hook");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],16,"\004coreloop-lambda");
lf[60]=C_h_intern(&lf[60],6,"letrec");
lf[61]=C_h_intern(&lf[61],8,"\004coreapp");
lf[62]=C_h_intern(&lf[62],7,"\003sysmap");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[73]=C_h_intern(&lf[73],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[74]=C_h_intern(&lf[74],23,"\003sysmacroexpand-1-local");
lf[75]=C_h_intern(&lf[75],25,"\003sysenable-runtime-macros");
lf[76]=C_h_intern(&lf[76],11,"macroexpand");
lf[77]=C_h_intern(&lf[77],13,"macroexpand-1");
lf[78]=C_h_intern(&lf[78],25,"\003sysextended-lambda-list\077");
lf[79]=C_h_intern(&lf[79],6,"#!rest");
lf[80]=C_h_intern(&lf[80],10,"#!optional");
lf[81]=C_h_intern(&lf[81],5,"#!key");
lf[82]=C_h_intern(&lf[82],7,"reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],31,"\003sysexpand-extended-lambda-list");
lf[85]=C_h_intern(&lf[85],9,":optional");
lf[86]=C_h_intern(&lf[86],13,"let-optionals");
lf[87]=C_h_intern(&lf[87],14,"let-optionals*");
lf[88]=C_h_intern(&lf[88],10,"\003sysappend");
lf[89]=C_h_intern(&lf[89],4,"let*");
lf[90]=C_h_intern(&lf[90],5,"quote");
lf[91]=C_h_intern(&lf[91],15,"\003sysget-keyword");
lf[92]=C_h_intern(&lf[92],6,"lambda");
lf[93]=C_h_intern(&lf[93],15,"string->keyword");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[104]=C_h_intern(&lf[104],3,"map");
lf[105]=C_h_intern(&lf[105],21,"\003syscanonicalize-body");
lf[106]=C_h_intern(&lf[106],5,"begin");
lf[107]=C_h_intern(&lf[107],6,"define");
lf[108]=C_h_intern(&lf[108],13,"define-values");
lf[109]=C_h_intern(&lf[109],20,"\003syscall-with-values");
lf[110]=C_h_intern(&lf[110],14,"\004coreundefined");
lf[111]=C_h_intern(&lf[111],25,"\003sysexpand-curried-define");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[119]=C_h_intern(&lf[119],20,"\003sysmatch-expression");
lf[120]=C_h_intern(&lf[120],15,"\003syshash-symbol");
lf[121]=C_h_intern(&lf[121],22,"\003syshash-table-update!");
lf[122]=C_h_intern(&lf[122],23,"\003syshash-table-for-each");
lf[123]=C_h_intern(&lf[123],12,"\003sysfor-each");
lf[124]=C_h_intern(&lf[124],21,"\003syshash-table->alist");
lf[125]=C_h_intern(&lf[125],3,"vec");
lf[126]=C_h_intern(&lf[126],28,"\003sysarbitrary-unbound-symbol");
lf[127]=C_h_intern(&lf[127],23,"\003syshash-table-location");
lf[128]=C_h_intern(&lf[128],20,"\003syseval-environment");
lf[129]=C_h_intern(&lf[129],26,"\003sysenvironment-is-mutable");
lf[130]=C_h_intern(&lf[130],18,"\003syseval-decorator");
lf[131]=C_h_intern(&lf[131],20,"\003sysmake-lambda-info");
lf[132]=C_h_intern(&lf[132],17,"get-output-string");
lf[133]=C_h_intern(&lf[133],5,"write");
lf[134]=C_h_intern(&lf[134],18,"open-output-string");
lf[135]=C_h_intern(&lf[135],19,"\003sysdecorate-lambda");
lf[136]=C_h_intern(&lf[136],19,"\003sysunbound-in-eval");
lf[137]=C_h_intern(&lf[137],20,"\003syseval-debug-level");
lf[138]=C_h_intern(&lf[138],21,"\003sysalias-global-hook");
lf[139]=C_h_intern(&lf[139],6,"cadadr");
lf[140]=C_h_intern(&lf[140],8,"keyword\077");
lf[141]=C_h_intern(&lf[141],20,"with-input-from-file");
lf[142]=C_h_intern(&lf[142],7,"display");
lf[143]=C_h_intern(&lf[143],22,"\003syscompile-to-closure");
lf[144]=C_h_intern(&lf[144],18,"\003syscurrent-thread");
lf[145]=C_h_intern(&lf[145],9,"\003syserror");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[148]=C_h_intern(&lf[148],32,"\003syssymbol-has-toplevel-binding\077");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[150]=C_h_intern(&lf[150],15,"\004coreglobal-ref");
lf[151]=C_h_intern(&lf[151],10,"\004corecheck");
lf[152]=C_h_intern(&lf[152],14,"\004coreimmutable");
lf[153]=C_h_intern(&lf[153],2,"if");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[161]=C_h_intern(&lf[161],15,"\003sysmake-vector");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[163]=C_h_intern(&lf[163],1,"\077");
lf[164]=C_h_intern(&lf[164],10,"\003sysvector");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[167]=C_h_intern(&lf[167],25,"\003sysdecompose-lambda-list");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[169]=C_h_intern(&lf[169],17,"\004corenamed-lambda");
lf[170]=C_h_intern(&lf[170],23,"\004corerequire-for-syntax");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[172]=C_h_intern(&lf[172],11,"\003sysrequire");
lf[173]=C_h_intern(&lf[173],31,"\003syslookup-runtime-requirements");
lf[174]=C_h_intern(&lf[174],22,"\004corerequire-extension");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[176]=C_h_intern(&lf[176],22,"\003sysdo-the-right-thing");
lf[177]=C_h_intern(&lf[177],24,"\004coreelaborationtimeonly");
lf[178]=C_h_intern(&lf[178],23,"\004coreelaborationtimetoo");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[180]=C_h_intern(&lf[180],19,"\004corecompiletimetoo");
lf[181]=C_h_intern(&lf[181],20,"\004corecompiletimeonly");
lf[182]=C_h_intern(&lf[182],13,"\004corecallunit");
lf[183]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[184]=C_h_intern(&lf[184],12,"\004coredeclare");
lf[185]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[186]=C_h_intern(&lf[186],10,"\000compiling");
lf[187]=C_h_intern(&lf[187],12,"\003sysfeatures");
lf[188]=C_h_intern(&lf[188],28,"\010compilerprocess-declaration");
lf[189]=C_h_intern(&lf[189],8,"\003syswarn");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[191]=C_h_intern(&lf[191],18,"\004coredefine-inline");
lf[192]=C_h_intern(&lf[192],20,"\004coredefine-constant");
lf[193]=C_h_intern(&lf[193],14,"\004coreprimitive");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[195]=C_h_intern(&lf[195],8,"location");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[197]=C_h_intern(&lf[197],11,"\004coreinline");
lf[198]=C_h_intern(&lf[198],20,"\004coreinline_allocate");
lf[199]=C_h_intern(&lf[199],19,"\004coreforeign-lambda");
lf[200]=C_h_intern(&lf[200],28,"\004coredefine-foreign-variable");
lf[201]=C_h_intern(&lf[201],29,"\004coredefine-external-variable");
lf[202]=C_h_intern(&lf[202],17,"\004corelet-location");
lf[203]=C_h_intern(&lf[203],22,"\004coreforeign-primitive");
lf[204]=C_h_intern(&lf[204],20,"\004coreforeign-lambda*");
lf[205]=C_h_intern(&lf[205],24,"\004coredefine-foreign-type");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[207]=C_h_intern(&lf[207],11,"\003sysnumber\077");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[209]=C_h_intern(&lf[209],16,"\003syseval-handler");
lf[210]=C_h_intern(&lf[210],12,"eval-handler");
lf[211]=C_h_intern(&lf[211],4,"eval");
lf[212]=C_h_intern(&lf[212],24,"\003syssyntax-error-culprit");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[214]=C_h_intern(&lf[214],12,"load-verbose");
lf[215]=C_h_intern(&lf[215],14,"\003sysabort-load");
lf[216]=C_h_intern(&lf[216],27,"\003syscurrent-source-filename");
lf[217]=C_h_intern(&lf[217],21,"\003syscurrent-load-path");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[219]=C_h_intern(&lf[219],22,"set-dynamic-load-mode!");
lf[220]=C_h_intern(&lf[220],21,"\003sysset-dlopen-flags!");
lf[221]=C_h_intern(&lf[221],6,"global");
lf[222]=C_h_intern(&lf[222],5,"local");
lf[223]=C_h_intern(&lf[223],4,"lazy");
lf[224]=C_h_intern(&lf[224],3,"now");
lf[225]=C_h_intern(&lf[225],15,"\003syssignal-hook");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[227]=C_h_intern(&lf[227],4,"read");
lf[228]=C_h_intern(&lf[228],7,"newline");
lf[229]=C_h_intern(&lf[229],15,"open-input-file");
lf[230]=C_h_intern(&lf[230],16,"close-input-port");
lf[231]=C_h_intern(&lf[231],8,"\003sysload");
lf[232]=C_h_intern(&lf[232],31,"\003sysread-error-with-line-number");
lf[233]=C_h_intern(&lf[233],19,"\003sysundefined-value");
lf[234]=C_h_intern(&lf[234],17,"\003sysdisplay-times");
lf[235]=C_h_intern(&lf[235],14,"\003sysstop-timer");
lf[236]=C_h_intern(&lf[236],15,"\003sysstart-timer");
lf[237]=C_h_intern(&lf[237],4,"load");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[239]=C_h_intern(&lf[239],9,"peek-char");
lf[240]=C_h_intern(&lf[240],16,"\003sysdynamic-wind");
lf[241]=C_h_intern(&lf[241],13,"\003syssubstring");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_h_intern(&lf[243],9,"\003sysdload");
lf[244]=C_h_intern(&lf[244],17,"\003sysmake-c-string");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[246]=C_h_intern(&lf[246],11,"\000file-error");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\021can not open file");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[250]=C_h_intern(&lf[250],13,"\003sysfile-info");
lf[251]=C_h_intern(&lf[251],26,"\003sysload-dynamic-extension");
lf[252]=C_h_intern(&lf[252],11,"\000type-error");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[254]=C_h_intern(&lf[254],5,"port\077");
lf[255]=C_h_intern(&lf[255],20,"\003sysexpand-home-path");
lf[256]=C_h_intern(&lf[256],13,"load-relative");
lf[257]=C_h_intern(&lf[257],12,"load-noisily");
lf[258]=C_h_intern(&lf[258],8,"\000printer");
lf[259]=C_h_intern(&lf[259],5,"\000time");
lf[260]=C_h_intern(&lf[260],10,"\000evaluator");
lf[261]=C_h_intern(&lf[261],26,"\003sysload-library-extension");
lf[262]=C_h_intern(&lf[262],6,"cygwin");
lf[263]=C_h_intern(&lf[263],34,"\003sysdefault-dynamic-load-libraries");
lf[264]=C_h_intern(&lf[264],22,"dynamic-load-libraries");
lf[265]=C_h_intern(&lf[265],16,"\003sysload-library");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[270]=C_h_intern(&lf[270],24,"\003sysstring->c-identifier");
lf[271]=C_h_intern(&lf[271],16,"\003sys->feature-id");
lf[272]=C_h_intern(&lf[272],12,"load-library");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[275]=C_h_intern(&lf[275],31,"\003syscanonicalize-extension-path");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[277]=C_h_intern(&lf[277],18,"\003syssymbol->string");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[281]=C_h_intern(&lf[281],19,"\003sysrepository-path");
lf[282]=C_h_intern(&lf[282],15,"repository-path");
lf[283]=C_h_intern(&lf[283],12,"file-exists\077");
lf[284]=C_h_intern(&lf[284],18,"\003sysfind-extension");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[286]=C_h_intern(&lf[286],21,"\003sysinclude-pathnames");
lf[287]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[288]=C_h_intern(&lf[288],21,"\003sysloaded-extensions");
lf[289]=C_h_intern(&lf[289],14,"string->symbol");
lf[290]=C_h_intern(&lf[290],18,"\003sysload-extension");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\026can not load extension");
lf[292]=C_h_intern(&lf[292],11,"\003sysprovide");
lf[293]=C_h_intern(&lf[293],7,"provide");
lf[294]=C_h_intern(&lf[294],13,"\003sysprovided\077");
lf[295]=C_h_intern(&lf[295],9,"provided\077");
lf[296]=C_h_intern(&lf[296],7,"require");
lf[297]=C_h_intern(&lf[297],25,"\003sysextension-information");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[300]=C_h_intern(&lf[300],21,"extension-information");
lf[301]=C_h_intern(&lf[301],18,"require-at-runtime");
lf[302]=C_h_intern(&lf[302],12,"vector->list");
lf[303]=C_h_intern(&lf[303],11,"lset-adjoin");
lf[304]=C_h_intern(&lf[304],3,"eq\077");
lf[305]=C_h_intern(&lf[305],26,"\010compilerfile-requirements");
lf[306]=C_h_intern(&lf[306],19,"syntax-requirements");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[308]=C_h_intern(&lf[308],18,"chicken-ffi-macros");
lf[309]=C_h_intern(&lf[309],19,"chicken-more-macros");
lf[310]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[311]=C_h_intern(&lf[311],28,"\003sysresolve-include-filename");
lf[312]=C_h_intern(&lf[312],4,"uses");
lf[313]=C_h_intern(&lf[313],6,"syntax");
lf[314]=C_h_intern(&lf[314],17,"require-extension");
lf[315]=C_h_intern(&lf[315],12,"\003sysfeature\077");
lf[316]=C_h_intern(&lf[316],24,"\003sysextension-specifiers");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[319]=C_h_intern(&lf[319],24,"set-extension-specifier!");
lf[320]=C_h_intern(&lf[320],11,"string-copy");
lf[323]=C_h_intern(&lf[323],11,"environment");
lf[325]=C_h_intern(&lf[325],18,"\003syscopy-env-table");
lf[326]=C_h_intern(&lf[326],23,"\003sysenvironment-symbols");
lf[327]=C_h_intern(&lf[327],18,"\003syswalk-namespace");
lf[328]=C_h_intern(&lf[328],23,"interaction-environment");
lf[329]=C_h_intern(&lf[329],25,"scheme-report-environment");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[331]=C_h_intern(&lf[331],11,"make-vector");
lf[332]=C_h_intern(&lf[332],16,"null-environment");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[341]=C_h_intern(&lf[341],24,"\003sysline-number-database");
lf[342]=C_h_intern(&lf[342],13,"\000syntax-error");
lf[343]=C_h_intern(&lf[343],12,"syntax-error");
lf[344]=C_h_intern(&lf[344],15,"get-line-number");
lf[345]=C_h_intern(&lf[345],14,"symbol->string");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[354]=C_h_intern(&lf[354],1,"_");
lf[355]=C_h_intern(&lf[355],4,"pair");
lf[356]=C_h_intern(&lf[356],5,"pair\077");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[358]=C_h_intern(&lf[358],8,"variable");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],7,"symbol\077");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[363]=C_h_intern(&lf[363],4,"list");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[365]=C_h_intern(&lf[365],6,"number");
lf[366]=C_h_intern(&lf[366],7,"number\077");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[368]=C_h_intern(&lf[368],6,"string");
lf[369]=C_h_intern(&lf[369],7,"string\077");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[371]=C_h_intern(&lf[371],11,"lambda-list");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[376]=C_h_intern(&lf[376],18,"\003sysrepl-eval-hook");
lf[377]=C_h_intern(&lf[377],27,"\003sysrepl-print-length-limit");
lf[378]=C_h_intern(&lf[378],18,"\003sysrepl-read-hook");
lf[379]=C_h_intern(&lf[379],19,"\003sysrepl-print-hook");
lf[380]=C_h_intern(&lf[380],16,"\003syswrite-char-0");
lf[381]=C_h_intern(&lf[381],9,"\003sysprint");
lf[382]=C_h_intern(&lf[382],27,"\003syswith-print-length-limit");
lf[383]=C_h_intern(&lf[383],11,"repl-prompt");
lf[384]=C_h_intern(&lf[384],20,"\003sysread-prompt-hook");
lf[385]=C_h_intern(&lf[385],16,"\003sysflush-output");
lf[386]=C_h_intern(&lf[386],19,"\003sysstandard-output");
lf[387]=C_h_intern(&lf[387],22,"\003sysclear-trace-buffer");
lf[388]=C_h_intern(&lf[388],16,"print-call-chain");
lf[389]=C_h_intern(&lf[389],12,"flush-output");
lf[390]=C_h_intern(&lf[390],5,"reset");
lf[391]=C_h_intern(&lf[391],4,"repl");
lf[392]=C_h_intern(&lf[392],18,"\003sysstandard-error");
lf[393]=C_h_intern(&lf[393],18,"\003sysstandard-input");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\005Error");
lf[397]=C_h_intern(&lf[397],17,"\003syserror-handler");
lf[398]=C_h_intern(&lf[398],20,"\003syswarnings-enabled");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[402]=C_h_intern(&lf[402],15,"\003sysread-char-0");
lf[403]=C_h_intern(&lf[403],15,"\003syspeek-char-0");
lf[404]=C_h_intern(&lf[404],21,"\003sysenable-qualifiers");
lf[405]=C_h_intern(&lf[405],17,"\003sysreset-handler");
lf[406]=C_h_intern(&lf[406],28,"\003syssharp-comma-reader-ctors");
lf[407]=C_h_intern(&lf[407],18,"define-reader-ctor");
lf[408]=C_h_intern(&lf[408],18,"\003sysuser-read-hook");
lf[409]=C_h_intern(&lf[409],9,"read-char");
lf[410]=C_h_intern(&lf[410],14,"\003sysread-error");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[415]=C_h_intern(&lf[415],19,"print-error-message");
lf[417]=C_h_intern(&lf[417],6,"\003sysgc");
lf[419]=C_h_intern(&lf[419],13,"thread-yield!");
lf[422]=C_h_intern(&lf[422],17,"open-input-string");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[433]=C_h_intern(&lf[433],15,"\003sysmake-string");
lf[434]=C_h_intern(&lf[434],6,"module");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\031modules are not supported");
lf[436]=C_h_intern(&lf[436],13,"define-syntax");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\042highlevel macros are not supported");
lf[438]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[439]=C_h_intern(&lf[439],12,"define-macro");
lf[440]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[441]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[444]=C_h_intern(&lf[444],14,"make-parameter");
lf[445]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[446]=C_h_intern(&lf[446],11,"cond-expand");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[448]=C_h_intern(&lf[448],3,"and");
lf[449]=C_h_intern(&lf[449],2,"or");
lf[450]=C_h_intern(&lf[450],3,"not");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[452]=C_h_intern(&lf[452],4,"else");
lf[453]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[454]=C_h_intern(&lf[454],16,"\003sysmake-promise");
lf[455]=C_h_intern(&lf[455],5,"delay");
lf[456]=C_h_intern(&lf[456],16,"\003syslist->vector");
lf[457]=C_h_intern(&lf[457],7,"unquote");
lf[458]=C_h_intern(&lf[458],8,"\003syslist");
lf[459]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[460]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[461]=C_h_intern(&lf[461],10,"quasiquote");
lf[462]=C_h_intern(&lf[462],8,"\003syscons");
lf[463]=C_h_intern(&lf[463],16,"unquote-splicing");
lf[464]=C_h_intern(&lf[464],1,"a");
lf[465]=C_h_intern(&lf[465],1,"b");
lf[466]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[472]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[473]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\002do");
lf[475]=C_h_intern(&lf[475],2,"do");
lf[476]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[477]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[478]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[479]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[480]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[481]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[483]=C_h_intern(&lf[483],4,"eqv\077");
lf[484]=C_h_intern(&lf[484],4,"case");
lf[485]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[486]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[487]=C_h_intern(&lf[487],2,"=>");
lf[488]=C_h_intern(&lf[488],9,"\003sysapply");
lf[489]=C_h_intern(&lf[489],4,"cond");
lf[490]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[491]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[492]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[493]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[494]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[496]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[497]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[498]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[499]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[500]=C_h_intern(&lf[500],18,"\003sysnumber->string");
lf[501]=C_h_intern(&lf[501],5,"error");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[503]=C_h_intern(&lf[503],7,"version");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[505]=C_h_intern(&lf[505],9,"string>=\077");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[507]=C_h_intern(&lf[507],12,"list->vector");
lf[508]=C_h_intern(&lf[508],18,"\003sysstring->symbol");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[510]=C_h_intern(&lf[510],4,"srfi");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[512]=C_h_intern(&lf[512],14,"build-platform");
lf[513]=C_h_intern(&lf[513],7,"windows");
lf[514]=C_h_intern(&lf[514],6,"macosx");
lf[515]=C_h_intern(&lf[515],4,"hpux");
lf[516]=C_h_intern(&lf[516],4,"hppa");
lf[517]=C_h_intern(&lf[517],12,"machine-type");
lf[518]=C_h_intern(&lf[518],16,"software-version");
lf[519]=C_h_intern(&lf[519],13,"software-type");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[521]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
C_register_lf2(lf,524,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,lf[3]);
t4=C_set_block_item(lf[4],0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[5],lf[6]);
t6=C_mutate(&lf[7],lf[8]);
t7=C_mutate(&lf[9],lf[10]);
t8=C_mutate(&lf[11],lf[12]);
t9=C_mutate(&lf[13],lf[14]);
t10=C_mutate(&lf[15],lf[16]);
t11=C_mutate(&lf[17],lf[18]);
t12=C_mutate(&lf[19],lf[20]);
t13=C_mutate(&lf[21],lf[22]);
t14=C_mutate(&lf[23],lf[24]);
t15=C_mutate(&lf[25],lf[26]);
t16=C_mutate(&lf[27],lf[28]);
t17=C_mutate(&lf[29],lf[30]);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 136  getenv */
t19=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[24]);}

/* k1731 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[521]);
t7=(C_truep(t6)?lf[522]:lf[523]);
/* eval.scm: 137  ##sys#string-append */
t8=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_1736(2,t3,C_SCHEME_FALSE);}}

/* k1734 in k1731 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=*((C_word*)lf[33]+1);
t4=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1764,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 157  make-vector */
t6=*((C_word*)lf[331]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1776 in k1734 in k1731 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1780,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1796,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1812,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1822,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1840,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[45]+1);
t9=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2219,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2222,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2225,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2232,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2268,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2284,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[82]+1);
t18=*((C_word*)lf[83]+1);
t19=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2327,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[82]+1);
t21=*((C_word*)lf[104]+1);
t22=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=t21,a[3]=t20,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3329,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3420,tmp=(C_word)a,a+=2,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3480,a[2]=t28,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3495,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3540,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3595,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3615,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3658,tmp=(C_word)a,a+=2,tmp));
t35=(C_word)C_slot(lf[126],C_fix(0));
t36=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3725,a[2]=t35,tmp=(C_word)a,a+=3,tmp));
t37=C_set_block_item(lf[128],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[129],0,C_SCHEME_FALSE);
t39=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3785,tmp=(C_word)a,a+=2,tmp));
t40=C_set_block_item(lf[136],0,C_SCHEME_FALSE);
t41=C_set_block_item(lf[137],0,C_fix(1));
t42=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3826,tmp=(C_word)a,a+=2,tmp));
t43=*((C_word*)lf[43]+1);
t44=*((C_word*)lf[133]+1);
t45=*((C_word*)lf[139]+1);
t46=*((C_word*)lf[82]+1);
t47=*((C_word*)lf[140]+1);
t48=*((C_word*)lf[134]+1);
t49=*((C_word*)lf[132]+1);
t50=*((C_word*)lf[141]+1);
t51=(C_word)C_slot(lf[126],C_fix(0));
t52=*((C_word*)lf[142]+1);
t53=C_mutate((C_word*)lf[143]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3832,a[2]=t45,a[3]=t47,a[4]=t51,tmp=(C_word)a,a+=5,tmp));
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6089,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t55=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11475,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1064 make-parameter */
t56=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t56+1)))(3,t56,t54,t55);}

/* a11474 in k1776 in k1734 in k1731 */
static void C_ccall f_11475(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11475r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11475r(t0,t1,t2,t3);}}

static void C_ccall f_11475r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[129]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11479,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[323]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_11479(t15,t14);}
else{
t10=t8;
f_11479(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_11479(t9,C_SCHEME_UNDEFINED);}}

/* k11477 in a11474 in k1776 in k1734 in k1731 */
static void C_fcall f_11479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11479,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11485,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11487,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11497,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11503,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1074 ##sys#dynamic-wind */
t14=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a11502 in k11477 in a11474 in k1776 in k1734 in k1731 */
static void C_ccall f_11503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11503,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[129]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[128]+1));
t4=C_mutate((C_word*)lf[129]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[128]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[233]+1));}

/* a11496 in k11477 in a11474 in k1776 in k1734 in k1731 */
static void C_ccall f_11497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11497,2,t0,t1);}
/* eval.scm: 1076 ##sys#compile-to-closure */
t2=*((C_word*)lf[143]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a11486 in k11477 in a11474 in k1776 in k1734 in k1731 */
static void C_ccall f_11487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11487,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[129]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[128]+1));
t4=C_mutate((C_word*)lf[129]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[128]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[233]+1));}

/* k11483 in k11477 in a11474 in k1776 in k1734 in k1731 */
static void C_ccall f_11485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6089,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1,t1);
t3=C_mutate((C_word*)lf[210]+1,*((C_word*)lf[209]+1));
t4=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6092,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[82]+1);
t6=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6106,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 1108 make-parameter */
t9=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6188,2,t0,t1);}
t2=C_mutate((C_word*)lf[214]+1,t1);
t3=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6190,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[216],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[217]+1,lf[218]);
t6=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6195,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[227]+1);
t8=*((C_word*)lf[133]+1);
t9=*((C_word*)lf[142]+1);
t10=*((C_word*)lf[228]+1);
t11=*((C_word*)lf[211]+1);
t12=*((C_word*)lf[229]+1);
t13=*((C_word*)lf[230]+1);
t14=*((C_word*)lf[45]+1);
t15=*((C_word*)lf[214]+1);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6268,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t9,a[5]=t12,a[6]=t13,a[7]=t8,a[8]=t10,a[9]=t7,a[10]=t11,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1140 ##sys#make-c-string */
t17=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[520]);}

/* k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6270,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp));
t4=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6703,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6725,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[257]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6761,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11469,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1230 software-type */
t9=*((C_word*)lf[519]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k11467 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11469,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[513]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6787(t3,lf[12]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1231 software-version */
t4=*((C_word*)lf[518]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11463 in k11467 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11465,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[514]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6787(t3,lf[10]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11461,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1232 software-version */
t5=*((C_word*)lf[518]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11459 in k11463 in k11467 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11461,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[515]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1233 machine-type */
t4=*((C_word*)lf[517]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_11447(t3,C_SCHEME_FALSE);}}

/* k11455 in k11459 in k11463 in k11467 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11447(t2,(C_word)C_eqp(t1,lf[516]));}

/* k11445 in k11463 in k11467 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_11447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6787(t2,(C_truep(t1)?lf[14]:lf[15]));}

/* k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6787,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[261]+1,t1);
t3=C_mutate((C_word*)lf[251]+1,lf[15]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1239 build-platform */
t5=*((C_word*)lf[512]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6792,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[262]);
t3=(C_truep(t2)?lf[8]:lf[6]);
t4=C_mutate((C_word*)lf[263]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11417,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11425,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[263]+1));}

/* a11424 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11425,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[261]+1));}

/* k11415 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11419,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1244 make-parameter */
t3=*((C_word*)lf[444]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a11418 in k11415 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11419,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6799,2,t0,t1);}
t2=C_mutate((C_word*)lf[264]+1,t1);
t3=*((C_word*)lf[214]+1);
t4=*((C_word*)lf[45]+1);
t5=*((C_word*)lf[264]+1);
t6=*((C_word*)lf[142]+1);
t7=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6801,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6907,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[82]+1);
t10=C_mutate(&lf[274],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6936,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[45]+1);
t12=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6992,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11386,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1332 getenv */
t15=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[22]);}

/* k11384 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_11389(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11392,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11402,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11406,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:C_fix(3));
/* eval.scm: 1336 ##sys#number->string */
t8=*((C_word*)lf[500]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k11404 in k11384 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1334 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[511],t1);}

/* k11400 in k11384 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1333 ##sys#chicken-prefix */
t2=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11390 in k11384 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11392,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11389(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k11387 in k11384 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1331 make-parameter */
t2=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
t2=C_mutate((C_word*)lf[281]+1,t1);
t3=C_mutate((C_word*)lf[282]+1,*((C_word*)lf[281]+1));
t4=*((C_word*)lf[283]+1);
t5=*((C_word*)lf[45]+1);
t6=C_mutate((C_word*)lf[284]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7155,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[288],0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[289]+1);
t9=C_mutate((C_word*)lf[290]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7232,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7300,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[293]+1,*((C_word*)lf[292]+1));
t12=C_mutate((C_word*)lf[294]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7320,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[295]+1,*((C_word*)lf[294]+1));
t14=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7334,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[296]+1,*((C_word*)lf[172]+1));
t16=*((C_word*)lf[141]+1);
t17=*((C_word*)lf[283]+1);
t18=*((C_word*)lf[45]+1);
t19=*((C_word*)lf[227]+1);
t20=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7347,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7378,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[141]+1);
t23=*((C_word*)lf[227]+1);
t24=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7384,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[302]+1);
t26=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7433,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(lf[316],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[319]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7832,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[507]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11332,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1523 set-extension-specifier! */
t32=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[510],t31);}

/* a11331 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11332,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11340,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11346,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_11346(t9,t4,t5);}

/* loop in a11331 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_11346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11346,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[314]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11366,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11378,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11382,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1533 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k11380 in loop in a11331 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1533 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[509],t1);}

/* k11376 in loop in a11331 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1533 ##sys#string->symbol */
t2=*((C_word*)lf[508]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11364 in loop in a11331 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11370,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1534 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11346(t4,t2,t3);}

/* k11368 in k11364 in loop in a11331 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11370,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11338 in a11331 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1527 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7874,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11211,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1539 set-extension-specifier! */
t4=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[503],t3);}

/* a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11211,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11214,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11248,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[503]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cdddr(t2);
t11=t5;
f_11248(t11,(C_word)C_i_nullp(t10));}
else{
t10=t5;
f_11248(t10,C_SCHEME_FALSE);}}
else{
t9=t5;
f_11248(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_11248(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_11248(t6,C_SCHEME_FALSE);}}

/* k11246 in a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_11248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11257,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1549 extension-information */
t5=*((C_word*)lf[300]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[343]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[314],lf[506],((C_word*)t0)[4]);}}

/* k11255 in k11246 in a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11257,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[503],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11266,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1551 ->string */
f_11214(t5,t6);}
else{
t5=t4;
f_11266(2,t5,C_SCHEME_FALSE);}}

/* k11274 in k11255 in k11246 in a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11280,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1551 ->string */
f_11214(t2,((C_word*)t0)[2]);}

/* k11278 in k11274 in k11255 in k11246 in a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1551 string>=? */
t2=*((C_word*)lf[505]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11264 in k11255 in k11246 in a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11263(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1552 error */
t2=*((C_word*)lf[501]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[504],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11261 in k11255 in k11246 in a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ->string in a11210 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_11214(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11214,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1545 ##sys#number->string */
t3=*((C_word*)lf[500]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1546 error */
t3=*((C_word*)lf[501]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[502],t2);}}}}

/* k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7874,2,t0,t1);}
t2=*((C_word*)lf[320]+1);
t3=C_mutate((C_word*)lf[270]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7876,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1573 make-vector */
t5=*((C_word*)lf[331]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7932,2,t0,t1);}
t2=C_mutate(&lf[321],t1);
t3=lf[322]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[323],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[324],t4);
t6=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7939,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8047,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8166,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8169,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[331]+1);
t11=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8213,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8251,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8267,a[2]=t12,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11209,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1654 initb */
f_8251(t14,lf[321]);}

/* k11207 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[499]);}

/* k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1675 ##sys#copy-env-table */
t3=*((C_word*)lf[325]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[321],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8271,2,t0,t1);}
t2=C_mutate(&lf[322],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11205,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1677 initb */
f_8251(t4,lf[322]);}

/* k11203 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[498]);}

/* k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8278,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1684 chicken-home */
t3=*((C_word*)lf[34]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8278,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[286]+1,t2);
t4=*((C_word*)lf[45]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8284,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8303,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[142]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8426,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8450,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8471,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(lf[341],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8525,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[212],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[343]+1,*((C_word*)lf[56]+1));
t15=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8533,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[45]+1);
t17=*((C_word*)lf[140]+1);
t18=*((C_word*)lf[344]+1);
t19=*((C_word*)lf[345]+1);
t20=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8569,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11108,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1845 ##sys#register-macro-2 */
t23=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[107],t22);}

/* a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11108,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11114,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11114(t6,t1,t2);}

/* loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_11114(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11114,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11155,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1856 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[493]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11168,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1860 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[495]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11130,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1852 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[107],t3,lf[360]);}}

/* k11128 in loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1853 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[4],lf[497]);}

/* k11131 in k11128 in loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11133,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):lf[496]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],((C_word*)t0)[2],t3));}

/* k11166 in loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1861 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[3],lf[494]);}

/* k11169 in k11166 in loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11171,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[71],t2,t5));}

/* k11153 in loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1857 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[2],lf[492]);}

/* k11156 in k11153 in loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11165,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1858 ##sys#expand-curried-define */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11163 in k11156 in k11153 in loop in a11107 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1858 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11114(t2,((C_word*)t0)[2],t1);}

/* k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11080,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1864 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[448],t3);}

/* a11079 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11080,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(C_word)C_a_i_cons(&a,2,lf[448],t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[153],t5,t7,C_SCHEME_FALSE));}}}

/* k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11037,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1875 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[449],t4);}

/* a11036 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11037,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11059,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1885 gensym */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k11057 in a11036 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_11059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11059,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[449],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,4,lf[153],t1,t1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[58],t3,t5));}

/* k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8970,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10840,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1889 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[489],t4);}

/* a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10840,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10846,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10846(t6,t1,t2);}

/* expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10846(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10846,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10862,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1898 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[489],t3,lf[490]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[491]);}}

/* k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10862,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[452],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10892,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1900 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_10846(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_eqp(lf[487],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1902 gensym */
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
t9=(C_word)C_i_length(((C_word*)t0)[6]);
t10=(C_word)C_eqp(t9,C_fix(4));
if(C_truep(t10)){
t11=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
t12=t8;
f_10938(t12,(C_word)C_eqp(lf[487],t11));}
else{
t11=t8;
f_10938(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_10938(t9,C_SCHEME_FALSE);}}}}}

/* k10936 in k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10938,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1908 gensym */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10995,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1917 expand */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10846(t6,t5,((C_word*)t0)[3]);}}

/* k10993 in k10936 in k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10995,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[153],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10939 in k10936 in k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10941,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,lf[488],t4,t1);
t6=(C_word)C_u_i_cadddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_list(&a,3,lf[488],t6,t1);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10968,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1914 expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10846(t9,t8,((C_word*)t0)[2]);}

/* k10966 in k10939 in k10936 in k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10968,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[153],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k10899 in k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10901,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,t5,t1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10920,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1906 expand */
t8=((C_word*)((C_word*)t0)[3])[1];
f_10846(t8,t7,((C_word*)t0)[2]);}

/* k10918 in k10899 in k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10920,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[153],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t2));}

/* k10890 in k10860 in expand in a10839 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10892,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[449],((C_word*)t0)[2],t1));}

/* k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10737,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1919 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[484],t4);}

/* a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10737,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10747,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1925 gensym */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10745 in a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10747,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10758,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10760,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10760(t8,t4,((C_word*)t0)[2]);}

/* expand in k10745 in a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10760(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10760,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10776,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1932 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[484],t3,lf[485]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[486]);}}

/* k10774 in expand in k10745 in a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10776,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[452],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 1935 ##sys#map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a10813 in k10774 in expand in k10745 in a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10814,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[90],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[483],((C_word*)t0)[2],t3));}

/* k10810 in k10774 in expand in k10745 in a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10812,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[449],t1);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10804,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1937 expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10760(t6,t5,((C_word*)t0)[2]);}

/* k10802 in k10810 in k10774 in expand in k10745 in a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10804,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[153],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10756 in k10745 in a10736 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10758,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10684,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1939 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[89],t3);}

/* a10683 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10684,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10694,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1944 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[89],t3,lf[482]);}

/* k10692 in a10683 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1945 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],((C_word*)t0)[4],lf[481]);}

/* k10695 in k10692 in a10683 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10697,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10702,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10702(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k10695 in k10692 in a10683 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10702,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[58],t4));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10727,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1949 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k10725 in expand in k10695 in k10692 in a10683 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10727,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8979,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10614,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1951 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[60],t3);}

/* a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10614,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10624,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1956 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],t3,lf[480]);}

/* k10622 in a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1957 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[60],((C_word*)t0)[3],lf[479]);}

/* k10625 in k10622 in a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10674,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1958 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10673 in k10625 in k10622 in a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10674,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[478]));}

/* k10636 in k10625 in k10622 in a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10642,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10646,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10660,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1959 ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10659 in k10636 in k10625 in k10622 in a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10660,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[71],t3,t4));}

/* k10644 in k10636 in k10625 in k10622 in a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10646,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k10640 in k10636 in k10625 in k10622 in a10613 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10642,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10495,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1962 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[475],t4);}

/* a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_10495r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10495r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10499,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1966 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[475],t2,lf[477]);}

/* k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1967 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[475],((C_word*)t0)[6],lf[476]);}

/* k10500 in k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1968 gensym */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[474]);}

/* k10503 in k10500 in k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10596,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1969 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a10595 in k10503 in k10500 in k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10596,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k10510 in k10503 in k10500 in k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10512,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
t5=(C_truep(t4)?lf[472]:(C_word)C_a_i_cons(&a,2,lf[106],t3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10535,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t6;
f_10535(t8,lf[473]);}
else{
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t9=t6;
f_10535(t9,(C_word)C_a_i_cons(&a,2,lf[58],t8));}}

/* k10533 in k10510 in k10503 in k10500 in k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10535,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10549,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1980 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10548 in k10533 in k10510 in k10503 in k10500 in k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10549,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_i_car(t2));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_i_car(t7));}}

/* k10545 in k10533 in k10510 in k10503 in k10500 in k10497 in a10494 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10547,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,4,lf[153],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[58],((C_word*)t0)[7],((C_word*)t0)[2],t5));}

/* k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[302]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10203,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1986 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[461],t4);}

/* a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10203,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10206,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10216,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10413,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
/* eval.scm: 2047 walk */
t12=((C_word*)t4)[1];
f_10206(t12,t1,t2,C_fix(0));}

/* simplify in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10413(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10413,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10417,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2034 ##sys#match-expression */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[470],lf[471]);}

/* k10415 in simplify in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10417,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[464],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[458],t3);
/* eval.scm: 2035 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10413(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2036 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[468],lf[469]);}}

/* k10436 in k10415 in simplify in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10438,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[465],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_u_i_assq(lf[464],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[458],t7);
/* eval.scm: 2040 simplify */
t9=((C_word*)((C_word*)t0)[4])[1];
f_10413(t9,((C_word*)t0)[3],t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2043 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[466],lf[467]);}}

/* k10478 in k10436 in k10415 in simplify in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[464],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10216(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10216,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10230,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10234,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1996 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[457]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 2008 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_10206(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[460]);}}
else{
t7=(C_word)C_eqp(t4,lf[461]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[461]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10304,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 2013 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_10206(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[461]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10323,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2014 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_10206(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[463]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10357,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2025 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_10206(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[90],lf[463]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10376,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 2027 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_10206(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10387,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2029 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_10206(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10404,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2030 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_10206(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}

/* k10402 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10408,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2030 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10206(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10406 in k10402 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10408,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10385 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10391,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2029 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10206(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10389 in k10385 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10391,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10374 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10376,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[458],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10368,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2028 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10206(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10366 in k10374 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10368,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10355 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10357,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[88],((C_word*)t0)[2],t1));}

/* k10321 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10323,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10302 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10304,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[458],((C_word*)t0)[2],t1));}

/* k10275 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10277,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[458],lf[459],t1));}

/* k10232 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1996 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10206(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10228 in walk1 in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10230,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[456],t1));}

/* walk in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10206(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10206,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10214,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1991 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10216(t5,t4,t2,t3);}

/* k10212 in walk in a10202 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1991 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10413(t2,((C_word*)t0)[2],t1);}

/* k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10193,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2049 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[455],t3);}

/* a10192 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10193,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[454],t3));}

/* k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9947,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2053 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[446],t3);}

/* a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9947,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9950,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9960,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10102,a[2]=t3,a[3]=t5,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_10102(t10,t1,t2);}

/* expand in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_10102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10102,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10116,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10118,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_eqp(t6,lf[452]);
if(C_truep(t7)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(t8,C_SCHEME_END_OF_LIST);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?lf[453]:(C_word)C_a_i_cons(&a,2,lf[106],t8)));}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10173,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2098 test */
t9=((C_word*)((C_word*)t0)[3])[1];
f_9960(t9,t8,t6);}}
else{
/* eval.scm: 2091 err */
t6=((C_word*)t0)[2];
f_9950(t6,t1,t4);}}
else{
/* eval.scm: 2086 err */
t4=((C_word*)t0)[2];
f_9950(t4,t1,t2);}}}

/* k10171 in expand in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10173,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[106],t2));}
else{
/* eval.scm: 2099 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10102(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a10117 in expand in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10118,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k10114 in expand in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[145]+1),lf[451],t1);}

/* test in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9960,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 2061 ##sys#feature? */
t3=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_eqp(t4,lf[448]);
if(C_truep(t5)){
t6=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10009,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2069 test */
t17=t7;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2071 err */
t7=((C_word*)t0)[2];
f_9950(t7,t1,t2);}}}
else{
t6=(C_word)C_eqp(t4,lf[449]);
if(C_truep(t6)){
t7=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10048,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2075 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2077 err */
t8=((C_word*)t0)[2];
f_9950(t8,t1,t2);}}}
else{
t7=(C_word)C_eqp(t4,lf[450]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10086,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_u_i_cadr(t2);
/* eval.scm: 2078 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2079 err */
t8=((C_word*)t0)[2];
f_9950(t8,t1,t2);}}}}
else{
/* eval.scm: 2062 err */
t3=((C_word*)t0)[2];
f_9950(t3,t1,t2);}}}

/* k10084 in test in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k10046 in test in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10048,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[449],t2);
/* eval.scm: 2076 test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9960(t4,((C_word*)t0)[4],t3);}}

/* k10007 in test in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_10009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10009,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[448],t2);
/* eval.scm: 2070 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9960(t4,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* err in a9946 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9950,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[446],((C_word*)t0)[2]);
/* eval.scm: 2058 ##sys#error */
t4=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[447],t2,t3);}

/* k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2105 append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[445],*((C_word*)lf[187]+1));}

/* k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8995,2,t0,t1);}
t2=C_mutate((C_word*)lf[187]+1,t1);
t3=C_set_block_item(lf[376],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[377],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[378],0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9000,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9944,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2119 make-parameter */
t9=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9943 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9944,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[443]);}

/* k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9017,2,t0,t1);}
t2=C_mutate((C_word*)lf[383]+1,t1);
t3=*((C_word*)lf[383]+1);
t4=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9019,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9035,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[211]+1);
t7=*((C_word*)lf[227]+1);
t8=*((C_word*)lf[55]+1);
t9=*((C_word*)lf[388]+1);
t10=*((C_word*)lf[389]+1);
t11=*((C_word*)lf[214]+1);
t12=*((C_word*)lf[390]+1);
t13=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9038,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2235 make-vector */
t15=*((C_word*)lf[331]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9377,2,t0,t1);}
t2=C_mutate((C_word*)lf[406]+1,t1);
t3=C_mutate((C_word*)lf[407]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9379,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[408]+1);
t5=*((C_word*)lf[409]+1);
t6=*((C_word*)lf[227]+1);
t7=C_mutate((C_word*)lf[408]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9388,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9802,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2264 ##sys#register-macro */
t10=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[439],t9);}

/* a9801 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9802(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_9802r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9802r(t0,t1,t2,t3);}}

static void C_ccall f_9802r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9805,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9910,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2275 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[439],t3,lf[440]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9920,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2278 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[439],t2,lf[442]);}}

/* k9918 in a9801 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2279 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[439],((C_word*)t0)[4],lf[441]);}

/* k9921 in k9918 in a9801 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9923,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
/* eval.scm: 2280 expand */
f_9805(((C_word*)t0)[2],t2,t5);}

/* k9908 in a9801 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* eval.scm: 2276 expand */
f_9805(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a9801 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9805(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9805,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9809,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(lf[92],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cadr(t3);
t9=t4;
f_9809(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_9809(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_9809(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9809(t5,C_SCHEME_FALSE);}}

/* k9807 in expand in a9801 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9809,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[75]+1))?lf[178]:lf[177]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9820,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[92],t8);
t10=t3;
f_9820(t10,(C_word)C_a_i_list(&a,3,lf[38],t4,t9));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t6=t3;
f_9820(t6,(C_word)C_a_i_list(&a,3,lf[41],t4,t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=t3;
f_9820(t5,(C_word)C_a_i_list(&a,3,lf[40],t4,((C_word*)t0)[2]));}}}

/* k9818 in k9807 in expand in a9801 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9820,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9783,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2282 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[314],t3);}

/* a9782 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9783r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9783r(t0,t1,t2);}}

static void C_ccall f_9783r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9787,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2285 ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[314],t2,lf[438]);}

/* k9785 in a9782 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9794,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9796,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9795 in k9785 in a9782 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9796,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k9792 in k9785 in a9782 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9794,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[174],t1));}

/* k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9777,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2291 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[436],t3);}

/* a9776 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9777,3,t0,t1,t2);}
/* eval.scm: 2294 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[436],lf[437]);}

/* k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9771,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2296 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[434],t3);}

/* a9770 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9771,3,t0,t1,t2);}
/* eval.scm: 2299 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[434],lf[435]);}

/* k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9472,2,t0,t1);}
t2=lf[413]=C_SCHEME_FALSE;;
t3=C_mutate(&lf[414],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9475,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[416],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9534,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[418],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9543,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[420],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9555,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[421],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9571,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[423],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9597,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[425],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9610,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[426],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9636,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[427],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9673,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[428],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9689,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[429],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9715,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[430],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9737,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[431],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9752,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9762,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9762,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9769,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2406 ##sys#make-string */
t5=*((C_word*)lf[433]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9767 in ##sys#make-lambda-info in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9752,4,t0,t1,t2,t3);}
t4=lf[413];
t5=(C_truep(t4)?t4:lf[432]);
/* eval.scm: 2399 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9597(t5,t3,t2));}

/* CHICKEN_load in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9737,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9741,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9739 in CHICKEN_load in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9746,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2396 run-safe */
f_9475(((C_word*)t0)[2],t2);}

/* a9745 in k9739 in CHICKEN_load in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9750,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2396 load */
t3=*((C_word*)lf[237]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9748 in a9745 in k9739 in CHICKEN_load in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9715,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9719,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9717 in CHICKEN_read in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9719,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9724,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2390 run-safe */
f_9475(((C_word*)t0)[2],t3);}

/* a9723 in k9717 in CHICKEN_read in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9728,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2392 open-input-string */
t3=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9726 in a9723 in k9717 in CHICKEN_read in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2393 read */
t3=*((C_word*)lf[227]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9733 in k9726 in a9723 in k9717 in CHICKEN_read in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2393 store-result */
f_9534(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9689,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9695,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2383 run-safe */
f_9475(t1,t6);}

/* a9694 in CHICKEN_apply_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2385 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9697 in a9694 in CHICKEN_apply_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9702,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9713,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9711 in k9697 in a9694 in CHICKEN_apply_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2386 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9700 in k9697 in a9694 in CHICKEN_apply_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2387 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9707 in k9700 in k9697 in a9694 in CHICKEN_apply_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2387 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9597(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9673,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9679,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2378 run-safe */
f_9475(t1,t5);}

/* a9678 in CHICKEN_apply in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9687,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9685 in a9678 in CHICKEN_apply in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2378 store-result */
f_9534(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9636,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9640,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9640,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9645,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2369 run-safe */
f_9475(((C_word*)t0)[2],t4);}

/* a9644 in k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2371 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9647 in a9644 in k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9652,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9663,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9667,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9671,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2372 open-input-string */
t6=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9669 in k9647 in a9644 in k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2372 read */
t2=*((C_word*)lf[227]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9665 in k9647 in a9644 in k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2372 eval */
t2=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9661 in k9647 in a9644 in k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2372 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9650 in k9647 in a9644 in k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2373 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9657 in k9650 in k9647 in a9644 in k9638 in CHICKEN_eval_string_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2373 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9597(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9610,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9616,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2360 run-safe */
f_9475(t1,t5);}

/* a9615 in CHICKEN_eval_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2362 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9618 in a9615 in CHICKEN_eval_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9623,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9634,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2363 eval */
t4=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9632 in k9618 in a9615 in CHICKEN_eval_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2363 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9621 in k9618 in a9615 in CHICKEN_eval_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2364 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9628 in k9621 in k9618 in a9615 in CHICKEN_eval_to_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2364 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9597(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static C_word C_fcall f_9597(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[413],lf[424]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9571,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9575,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9573 in CHICKEN_eval_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9575,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9580,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2341 run-safe */
f_9475(((C_word*)t0)[2],t3);}

/* a9579 in k9573 in CHICKEN_eval_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9584,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2343 open-input-string */
t3=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9582 in a9579 in k9573 in CHICKEN_eval_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9595,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2344 read */
t4=*((C_word*)lf[227]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9593 in k9582 in a9579 in k9573 in CHICKEN_eval_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2344 eval */
t2=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9589 in k9582 in a9579 in k9573 in CHICKEN_eval_string in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2344 store-result */
f_9534(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9555,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9561,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2336 run-safe */
f_9475(t1,t4);}

/* a9560 in CHICKEN_eval in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9569,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2338 eval */
t3=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9567 in a9560 in CHICKEN_eval in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2338 store-result */
f_9534(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9549,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2333 run-safe */
f_9475(t1,t2);}

/* a9548 in CHICKEN_yield in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9553,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2333 thread-yield! */
t3=*((C_word*)lf[419]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9551 in a9548 in CHICKEN_yield in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9534(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9534,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9538,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2327 ##sys#gc */
t5=*((C_word*)lf[417]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9536 in store-result in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9475(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9475,NULL,2,t1,t2);}
t3=lf[413]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9483,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9485,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2315 call-with-current-continuation */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9485,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9510,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2315 with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9509 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9516,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9522,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2315 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9521 in a9509 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9522r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9522r(t0,t1,t2);}}

static void C_ccall f_9522r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2315 g1483 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9527 in a9521 in a9509 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9528,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9515 in a9509 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9516,2,t0,t1);}
/* eval.scm: 2320 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9490 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9491,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2315 g1483 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9496 in a9490 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9501,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2316 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9499 in a9496 in a9490 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9504,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2317 print-error-message */
t3=*((C_word*)lf[415]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9502 in k9499 in a9496 in a9490 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9508,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2318 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9506 in k9502 in k9499 in a9496 in a9490 in a9484 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[413],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9481 in run-safe in k9470 in k9467 in k9464 in k9461 in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9388,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9398,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2247 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 2259 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9396 in ##sys#user-read-hook in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2248 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9399 in k9396 in ##sys#user-read-hook in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9402,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9415,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9415(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9415(t6,(C_word)C_i_not(t5));}}

/* k9413 in k9399 in k9396 in ##sys#user-read-hook in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9415,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 2251 err */
t2=((C_word*)t0)[5];
f_9402(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9433,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2255 ##sys#hash-table-ref */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[406]+1),t2);}
else{
/* eval.scm: 2254 err */
t3=((C_word*)t0)[5];
f_9402(t3,((C_word*)t0)[4]);}}}

/* k9431 in k9413 in k9399 in k9396 in ##sys#user-read-hook in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 2258 ##sys#read-error */
t2=*((C_word*)lf[410]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[412],((C_word*)t0)[2]);}}

/* err in k9399 in k9396 in ##sys#user-read-hook in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9402,NULL,2,t0,t1);}
/* eval.scm: 2249 ##sys#read-error */
t2=*((C_word*)lf[410]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[411],((C_word*)t0)[2]);}

/* define-reader-ctor in k9375 in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9379,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[407]);
/* eval.scm: 2239 ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[406]+1),t2,t3);}

/* repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9041,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[393]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[386]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[392]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9082,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 2149 ##sys#error-handler */
t10=*((C_word*)lf[397]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9085,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 2150 ##sys#reset-handler */
t3=*((C_word*)lf[405]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9085,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[136]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9087,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9093,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9102,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9167,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9362,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2164 ##sys#dynamic-wind */
t10=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9361 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9366,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2227 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9364 in a9361 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9366,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2229 ##sys#error-handler */
t4=*((C_word*)lf[397]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9368 in k9364 in a9361 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2230 ##sys#reset-handler */
t2=*((C_word*)lf[405]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9167,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9173(t5,t1);}

/* loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9173,NULL,2,t0,t1);}
t2=f_9087(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9345,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2187 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9344 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9345,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9351,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2189 ##sys#reset-handler */
t4=*((C_word*)lf[405]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9350 in a9344 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9351,2,t0,t1);}
t2=C_set_block_item(lf[232],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[404],0,C_SCHEME_TRUE);
t4=f_9093(((C_word*)t0)[3]);
/* eval.scm: 2194 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2195 ##sys#read-prompt-hook */
t3=*((C_word*)lf[384]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[378]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9186,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9195,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2198 ##sys#peek-char-0 */
t4=*((C_word*)lf[403]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[393]+1));}}

/* k9338 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 2199 ##sys#read-char-0 */
t3=*((C_word*)lf[402]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[393]+1));}
else{
t3=((C_word*)t0)[2];
f_9195(2,t3,C_SCHEME_UNDEFINED);}}

/* k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2200 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[387]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9198,2,t0,t1);}
t2=C_set_block_item(lf[136],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9204,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9213,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2202 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9213r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9213r(t0,t1,t2);}}

static void C_ccall f_9213r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9217,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[398]+1))?(C_word)C_i_pairp(*((C_word*)lf[136]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9231,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9231(t8,t3,*((C_word*)lf[136]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9217(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9231(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9231,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9235,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9247,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2207 ##sys#print */
t6=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[401],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t5=t4;
f_9235(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9294,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9294(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 2221 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9292 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9294,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 2222 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9231(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 2223 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9231(t5,((C_word*)t0)[3],t2,t4);}}

/* k9245 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9252,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9251 in k9245 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9256,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2212 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[400],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}

/* k9254 in a9251 in k9245 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 2213 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[392]+1));}

/* k9257 in k9254 in a9251 in k9245 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9262,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9271,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2215 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[399],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t3=t2;
f_9262(2,t3,C_SCHEME_UNDEFINED);}}

/* k9269 in k9257 in k9254 in a9251 in k9245 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9274,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 2216 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[392]+1));}

/* k9272 in k9269 in k9257 in k9254 in a9251 in k9245 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2217 ##sys#write-char-0 */
t2=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[392]+1));}

/* k9260 in k9257 in k9254 in a9251 in k9245 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2218 ##sys#write-char-0 */
t2=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[392]+1));}

/* k9233 in loop in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9215 in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9063,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_9063(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_9063(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k9061 in k9215 in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9063,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9220(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9068,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a9067 in k9061 in k9215 in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9068,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[386]+1));}

/* k9218 in k9215 in a9212 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2225 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9173(t2,((C_word*)t0)[2]);}

/* a9203 in k9196 in k9193 in k9184 in k9181 in k9178 in loop in a9166 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9204,2,t0,t1);}
t2=*((C_word*)lf[376]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 2166 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2167 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2168 ##sys#error-handler */
t3=*((C_word*)lf[397]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9115(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9115r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9115r(t0,t1,t2,t3);}}

static void C_ccall f_9115r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_9093(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9122,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 2171 ##sys#print */
t6=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[396],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}

/* k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9162,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2173 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[395],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t3=t2;
f_9125(2,t3,C_SCHEME_UNDEFINED);}}

/* k9160 in k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2174 ##sys#print */
t2=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}

/* k9123 in k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9128,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9137(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9137(t4,C_SCHEME_FALSE);}}

/* k9135 in k9123 in k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9137,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2177 ##sys#print */
t3=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[394],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2180 ##sys#write-char-0 */
t3=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[392]+1));}}

/* k9144 in k9135 in k9123 in k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2181 write-err */
f_9041(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9138 in k9135 in k9123 in k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2178 write-err */
f_9041(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9126 in k9123 in k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2182 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[392]+1));}

/* k9129 in k9126 in k9123 in k9120 in a9114 in k9108 in k9105 in a9101 in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2183 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[392]+1));}

/* resetports in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static C_word C_fcall f_9093(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[393]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[386]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[392]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k9083 in k9080 in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static C_word C_fcall f_9087(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[393]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[386]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[392]+1));
return(t3);}

/* write-err in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_9041(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9041,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9047,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9046 in write-err in repl in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9047,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[392]+1));}

/* ##sys#clear-trace-buffer in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9035,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1367(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9023,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9030,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9033,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2124 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9031 in ##sys#read-prompt-hook in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9028 in ##sys#read-prompt-hook in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2124 ##sys#print */
t2=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[386]+1));}

/* k9021 in ##sys#read-prompt-hook in k9015 in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2125 ##sys#flush-output */
t2=*((C_word*)lf[385]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[386]+1));}

/* ##sys#repl-print-hook in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9000,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9004,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9009,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2116 ##sys#with-print-length-limit */
t6=*((C_word*)lf[382]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[377]+1),t5);}

/* a9008 in ##sys#repl-print-hook in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9009,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k9002 in ##sys#repl-print-hook in k8993 in k8989 in k8986 in k8983 in k8980 in k8977 in k8974 in k8971 in k8968 in k8965 in k8962 in k8959 in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2117 ##sys#write-char-0 */
t2=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8569r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8569r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8569r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8584,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8572,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8615,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8677,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8706,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_slot(t5,C_fix(0));
t12=C_mutate((C_word*)lf[212]+1,t11);
t13=t10;
f_8706(t13,t12);}
else{
t11=t10;
f_8706(t11,C_SCHEME_UNDEFINED);}}

/* k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8706,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8711(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8711(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(19);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8711,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8727,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_8727(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_8727(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[354]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[355]);
if(C_truep(t7)){
/* eval.scm: 1828 test */
t8=((C_word*)t0)[4];
f_8572(t8,t1,t2,*((C_word*)lf[356]+1),lf[357]);}
else{
t8=(C_word)C_eqp(t5,lf[358]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8856,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1829 test */
t10=((C_word*)t0)[4];
f_8572(t10,t1,t2,t9,lf[359]);}
else{
t9=(C_word)C_eqp(t5,lf[360]);
if(C_truep(t9)){
/* eval.scm: 1830 test */
t10=((C_word*)t0)[4];
f_8572(t10,t1,t2,*((C_word*)lf[361]+1),lf[362]);}
else{
t10=(C_word)C_eqp(t5,lf[363]);
if(C_truep(t10)){
/* eval.scm: 1831 test */
t11=((C_word*)t0)[4];
f_8572(t11,t1,t2,((C_word*)t0)[3],lf[364]);}
else{
t11=(C_word)C_eqp(t5,lf[365]);
if(C_truep(t11)){
/* eval.scm: 1832 test */
t12=((C_word*)t0)[4];
f_8572(t12,t1,t2,*((C_word*)lf[366]+1),lf[367]);}
else{
t12=(C_word)C_eqp(t5,lf[368]);
if(C_truep(t12)){
/* eval.scm: 1833 test */
t13=((C_word*)t0)[4];
f_8572(t13,t1,t2,*((C_word*)lf[369]+1),lf[370]);}
else{
t13=(C_word)C_eqp(t5,lf[371]);
if(C_truep(t13)){
/* eval.scm: 1834 test */
t14=((C_word*)t0)[4];
f_8572(t14,t1,t2,((C_word*)t0)[2],lf[372]);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8910,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1835 test */
t15=((C_word*)t0)[4];
f_8572(t15,t1,t2,t14,lf[373]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1837 err */
t7=((C_word*)t0)[6];
f_8584(t7,t1,lf[374]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8929,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1839 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1824 err */
t6=((C_word*)t0)[6];
f_8584(t6,t1,lf[375]);}}}}

/* k8927 in walk in k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1840 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8711(t4,((C_word*)t0)[2],t2,t3);}

/* a8909 in walk in k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8910,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8855 in walk in k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8856,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k8725 in walk in k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8727,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8732,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8732(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1220 in k8725 in walk in k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8732(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8732,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1817 err */
t5=((C_word*)t0)[6];
f_8584(t5,t1,lf[351]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8751,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1819 err */
t6=((C_word*)t0)[6];
f_8584(t6,t5,lf[352]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1821 err */
t8=((C_word*)t0)[6];
f_8584(t8,t5,lf[353]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1822 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_8711(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8749 in do1220 in k8725 in walk in k8704 in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8732(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8677,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8683,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8683(t2));}

/* loop in proper-list? in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static C_word C_fcall f_8683(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8615,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8619,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1784 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8617 in lambda-list? in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8619,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8627,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_8627(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k8617 in lambda-list? in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8627,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8650,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1788 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1793 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k8648 in loop in k8617 in lambda-list? in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8572,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8579,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1772 pred */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k8577 in test in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1772 err */
t2=((C_word*)t0)[3];
f_8584(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8584,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[212]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1776 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8586 in err in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8595,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8602,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1779 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8613,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1780 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8611 in k8586 in err in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1780 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[349],t1,lf[350],((C_word*)t0)[2]);}

/* k8600 in k8586 in err in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8606,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1779 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k8604 in k8600 in k8586 in err in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1779 string-append */
t2=((C_word*)t0)[5];
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[4],lf[346],((C_word*)t0)[3],lf[347],t1,lf[348],((C_word*)t0)[2]);}

/* k8593 in k8586 in err in ##sys#check-syntax in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1777 ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8533,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[341]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8555,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1758 ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[341]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8553 in get-line-number in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_8525r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8525r(t0,t1,t2);}}

static void C_ccall f_8525r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[225]+1),lf[342],t2);}

/* ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8471,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1733 display-rj */
t5=((C_word*)t0)[2];
f_8450(t5,t3,t4,C_fix(8));}

/* k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1734 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[340]);}

/* k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1735 display-rj */
t4=((C_word*)t0)[2];
f_8450(t4,t2,t3,C_fix(8));}

/* k8479 in k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1736 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[339]);}

/* k8482 in k8479 in k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1737 display-rj */
t4=((C_word*)t0)[2];
f_8450(t4,t2,t3,C_fix(8));}

/* k8485 in k8482 in k8479 in k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1738 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[338]);}

/* k8488 in k8485 in k8482 in k8479 in k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1739 display-rj */
t4=((C_word*)t0)[2];
f_8450(t4,t2,t3,C_fix(8));}

/* k8491 in k8488 in k8485 in k8482 in k8479 in k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1740 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[337]);}

/* k8494 in k8491 in k8488 in k8485 in k8482 in k8479 in k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8499,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1741 display-rj */
t4=((C_word*)t0)[2];
f_8450(t4,t2,t3,C_fix(8));}

/* k8497 in k8494 in k8491 in k8488 in k8485 in k8482 in k8479 in k8476 in k8473 in ##sys#display-times in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1742 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[336]);}

/* display-rj in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8450(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8450,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8454,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_8454(2,t5,lf[335]);}
else{
/* eval.scm: 1728 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k8452 in display-rj in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8454,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8457,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1730 spaces */
t5=((C_word*)t0)[2];
f_8426(t5,t3,t4);}

/* k8455 in k8452 in display-rj in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1731 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8426,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8432,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8432(t6,t1,t2);}

/* do1150 in spaces in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8432(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8432,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8442,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1725 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k8440 in do1150 in spaces in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8432(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8303r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8303r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8303r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8309,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8344,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8361,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1706 test */
t12=t10;
f_8344(t12,t11,t2);}

/* k8359 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8361,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8371,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8412,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1708 ##sys#repository-path */
t4=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8371(2,t3,*((C_word*)lf[286]+1));}}}

/* k8410 in k8359 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8412,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1708 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[286]+1),t2);}

/* k8369 in k8359 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8371,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8373,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8373(t5,((C_word*)t0)[2],t1);}

/* loop in k8369 in k8359 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8373,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8383,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8397,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1711 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[334],((C_word*)t0)[5]);}}

/* k8395 in loop in k8369 in k8359 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1711 test */
t2=((C_word*)t0)[3];
f_8344(t2,((C_word*)t0)[2],t1);}

/* k8381 in loop in k8369 in k8359 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1714 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8373(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8344(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8344,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[17],*((C_word*)lf[251]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[251]+1),lf[17]));
/* eval.scm: 1701 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8309(t4,t1,t2,t3);}

/* test2 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8309(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8309,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8322,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1695 exists? */
f_8284(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8325,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1696 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8323 in test2 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1697 exists? */
f_8284(t2,t1);}

/* k8329 in k8323 in test2 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1699 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8309(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8320 in test2 in ##sys#resolve-include-filename in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8284(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8284,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8288,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1690 ##sys#file-info */
t4=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8286 in exists? in k8276 in k8272 in k8269 in k8265 in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8251(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8251,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8253,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8253 in initb in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8253,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8257,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1651 ##sys#hash-table-location */
t4=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8255 */
static void C_ccall f_8257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8213r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8213r(t0,t1,t2,t3);}}

static void C_ccall f_8213r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[332]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8220,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1642 ##sys#error */
t8=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[332],lf[333],t2);}
else{
t8=t5;
f_8220(2,t8,C_SCHEME_UNDEFINED);}}

/* k8218 in null-environment in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1645 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8225 in k8218 in null-environment in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8227,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[323],t1,t3));}

/* scheme-report-environment in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8169r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8169r(t0,t1,t2,t3);}}

static void C_ccall f_8169r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_exact_2(t2,lf[329]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8189,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1633 ##sys#copy-env-table */
t9=*((C_word*)lf[325]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[321],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8202,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1634 ##sys#copy-env-table */
t9=*((C_word*)lf[325]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[322],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1635 ##sys#error */
t8=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[329],lf[330],t2);}}

/* k8200 in scheme-report-environment in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8202,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[323],t1,((C_word*)t0)[2]));}

/* k8187 in scheme-report-environment in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[323],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8166,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[324]);}

/* ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8047(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8047r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8047r(t0,t1,t2,t3);}}

static void C_ccall f_8047r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t4=(C_word)C_i_check_structure(t2,lf[323]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8068,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8068(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8139,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8141,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1620 ##sys#walk-namespace */
t12=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8140 in ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8141,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8151,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8151(2,t5,t3);}
else{
/* eval.scm: 1622 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8149 in a8140 in ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8151,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8137 in ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* do1081 in ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8068,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8086,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8092,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_8092(t10,t5,t6,t3);}}

/* loop in do1081 in ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_8092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8092,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8111,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_8111(2,t8,t6);}
else{
/* eval.scm: 1614 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k8109 in loop in do1081 in ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8111,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1615 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8092(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1616 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8092(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k8084 in do1081 in ##sys#environment-symbols in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_8068(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7939r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7939r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7949,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1581 ##sys#make-vector */
t10=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k7947 in ##sys#copy-env-table in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7949,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7954(t5,((C_word*)t0)[2],C_fix(0));}

/* do1064 in k7947 in ##sys#copy-env-table in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7954,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7975,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7981,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7981(t8,t3,t4);}}

/* copy in do1064 in k7947 in ##sys#copy-env-table in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7981,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8014,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1596 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1597 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k8012 in copy in do1064 in k7947 in ##sys#copy-env-table in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8014,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7973 in do1064 in k7947 in ##sys#copy-env-table in k7930 in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7954(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7876,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7880,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1562 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7878 in ##sys#string->c-identifier in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7880,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7888,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7888(t6,((C_word*)t0)[2],C_fix(0));}

/* do1049 in k7878 in ##sys#string->c-identifier in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7888,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7908,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7908(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7908(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7906 in do1049 in k7878 in ##sys#string->c-identifier in k7872 in k7869 in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7888(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7832,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[319]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[316]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7850,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7864,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[316]+1));
t9=C_mutate((C_word*)lf[316]+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7863 in set-extension-specifier! in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7864,3,t0,t1,t2);}
/* eval.scm: 1517 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7849 in set-extension-specifier! in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7850,3,t0,t1,t2);}
/* eval.scm: 1515 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7433,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7436,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7457,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7708,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
t8=t6;
f_7708(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7708(t7,C_SCHEME_FALSE);}}

/* k7706 in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7708,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[316]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1503 ##sys#error */
t4=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[317],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1505 doit */
t2=((C_word*)t0)[2];
f_7457(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1506 ##sys#error */
t2=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[318],((C_word*)t0)[6]);}}}

/* k7715 in k7706 in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[237],t1);
/* eval.scm: 1491 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7743,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1493 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1502 ##sys#do-the-right-thing */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7741 in k7715 in k7706 in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7743,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7745,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7745(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7741 in k7715 in k7706 in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7745(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7745,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7763,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1497 reverse */
t6=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7768,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7778,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1498 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a7777 in loop in k7741 in k7715 in k7706 in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7778,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1499 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7745(t7,t1,t4,t5,t6);}

/* a7767 in loop in k7741 in k7715 in k7706 in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7768,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 1498 ##sys#do-the-right-thing */
t3=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7761 in loop in k7741 in k7715 in k7706 in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1497 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7457(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7457,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[28]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7467(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_7467(2,t5,(C_word)C_u_i_memq(t2,lf[30]));}
else{
/* eval.scm: 1444 ##sys#feature? */
t5=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7467,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1445 values */
C_values(4,0,((C_word*)t0)[5],lf[307],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[309]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1447 ##sys#->feature-id */
t4=*((C_word*)lf[271]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[2]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7516,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[312],((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,lf[90],t4);
t6=t3;
f_7516(t6,(C_word)C_a_i_list(&a,2,lf[184],t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[4]);
t5=t3;
f_7516(t5,(C_word)C_a_i_list(&a,2,lf[272],t4));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[4]+1)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7543,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1459 ##sys#extension-information */
t4=*((C_word*)lf[297]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[314]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1469 ##sys#extension-information */
t4=*((C_word*)lf[297]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[314]);}}}}}

/* k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7601,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[313],t1);
t3=(C_word)C_u_i_assq(lf[301],t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7613,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* eval.scm: 1473 add-req */
t5=((C_word*)t0)[2];
f_7436(t5,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_7613(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7682,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1485 add-req */
t3=((C_word*)t0)[2];
f_7436(t3,t2,((C_word*)t0)[3]);}}

/* k7680 in k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7682,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[172],t2);
/* eval.scm: 1486 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7611 in k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7624,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[170],t4);
t6=t3;
f_7628(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_7628(t4,C_SCHEME_END_OF_LIST);}}

/* k7626 in k7611 in k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7628,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7632,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_7632(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7646,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7648,tmp=(C_word)a,a+=2,tmp);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7647 in k7626 in k7611 in k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7648,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k7644 in k7626 in k7611 in k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7646,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[172],t1);
t3=((C_word*)t0)[2];
f_7632(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k7630 in k7626 in k7611 in k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7632(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1430 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7622 in k7611 in k7599 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7624,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1474 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7541 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7543,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[313],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7557,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[170],t5);
t7=t4;
f_7561(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_7561(t5,C_SCHEME_END_OF_LIST);}}

/* k7559 in k7541 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7561,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7569,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[312],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[90],t3);
t5=t2;
f_7569(t5,(C_word)C_a_i_list(&a,2,lf[184],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t4=t2;
f_7569(t4,(C_word)C_a_i_list(&a,2,lf[272],t3));}}

/* k7567 in k7559 in k7541 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7569,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1430 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7555 in k7541 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7557,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1461 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7514 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1453 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7477 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7482,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(t1,*((C_word*)lf[187]+1)))){
t3=t2;
f_7482(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7491,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7499,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7503,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1449 ##sys#symbol->string */
t6=*((C_word*)lf[277]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k7501 in k7477 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1449 ##sys#resolve-include-filename */
t2=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7497 in k7477 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1449 ##sys#load */
t2=*((C_word*)lf[231]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7489 in k7477 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[187]+1));
t3=C_mutate((C_word*)lf[187]+1,t2);
t4=((C_word*)t0)[2];
f_7482(t4,t3);}

/* k7480 in k7477 in k7465 in doit in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7482(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1451 values */
C_values(4,0,((C_word*)t0)[2],lf[310],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7436,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7445,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7451,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1435 ##sys#hash-table-update! */
t5=*((C_word*)lf[121]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,*((C_word*)lf[305]+1),lf[306],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7450 in add-req in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7451,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7444 in add-req in ##sys#do-the-right-thing in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7445,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[303]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[304]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7384,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7390,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7390(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7390,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1424 ##sys#extension-information */
t5=*((C_word*)lf[297]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7402 in loop1 in ##sys#lookup-runtime-requirements in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[301],t1);
t4=t2;
f_7407(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7407(t3,C_SCHEME_FALSE);}}

/* k7405 in k7402 in loop1 in ##sys#lookup-runtime-requirements in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7407,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7414,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1428 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7390(t5,t3,t4);}

/* k7412 in k7405 in k7402 in loop1 in ##sys#lookup-runtime-requirements in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1423 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7378,3,t0,t1,t2);}
/* eval.scm: 1414 ##sys#extension-information */
t3=*((C_word*)lf[297]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[300]);}

/* ##sys#extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7347,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1407 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k7349 in ##sys#extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7376,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1408 ##sys#repository-path */
t4=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7374 in k7349 in ##sys#extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1408 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],t1,lf[298],((C_word*)t0)[2],lf[299]);}

/* k7352 in k7349 in ##sys#extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7357,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7372,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1409 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[20]);}

/* k7370 in k7352 in k7349 in ##sys#extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1409 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7355 in k7352 in k7349 in ##sys#extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7357,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7364 in k7355 in k7352 in k7349 in ##sys#extension-information in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7364,3,t0,t1,t2);}
/* with-input-from-file954 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7334(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7334r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7334r(t0,t1,t2);}}

static void C_ccall f_7334r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7340,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7339 in ##sys#require in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7340,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[290]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[296]);}

/* ##sys#provided? in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7320,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7331,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1388 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[295]);}

/* k7329 in ##sys#provided? in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[288]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7300(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7300r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7300r(t0,t1,t2);}}

static void C_ccall f_7300r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7306,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7305 in ##sys#provide in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7306,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[293]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7313,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1381 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[293]);}

/* k7311 in a7305 in ##sys#provide in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7313,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[288]+1));
t3=C_mutate((C_word*)lf[288]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7232r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7232r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7232r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7236,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7295,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1362 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7236(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7293 in ##sys#load-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7236(t3,t2);}

/* k7234 in ##sys#load-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7236,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1364 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7237 in k7234 in ##sys#load-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7239,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[288]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[2]+1)))){
/* eval.scm: 1367 ##sys#load-library */
t3=*((C_word*)lf[265]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1369 ##sys#find-extension */
t4=*((C_word*)lf[284]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7255 in k7237 in k7234 in ##sys#load-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7257,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7263,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1371 ##sys#load */
t3=*((C_word*)lf[231]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1374 ##sys#error */
t5=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[291],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7261 in k7255 in k7237 in k7234 in ##sys#load-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7263,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[288]+1));
t3=C_mutate((C_word*)lf[288]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7155,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7158,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7189,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7229,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1350 ##sys#repository-path */
t7=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7227 in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7222,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1351 ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[286]+1),lf[287]);}
else{
t4=t3;
f_7222(2,t4,C_SCHEME_END_OF_LIST);}}

/* k7220 in k7227 in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1350 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7187 in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7189,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7191,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7191(t5,((C_word*)t0)[2],t1);}

/* loop in k7187 in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7191,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7204,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1354 check */
t5=((C_word*)t0)[2];
f_7158(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7202 in loop in k7187 in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1355 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7191(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7158,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7162,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1346 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[285],((C_word*)t0)[2]);}

/* k7160 in check in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7168,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7182,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1347 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,*((C_word*)lf[251]+1));}

/* k7180 in k7160 in check in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1347 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7166 in k7160 in check in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7171(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7178,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1348 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[17]);}}

/* k7176 in k7166 in k7160 in check in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1348 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7169 in k7166 in k7160 in check in ##sys#find-extension in k7150 in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6992,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6995,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7001,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7014,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_7014(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1307 ##sys#symbol->string */
t7=*((C_word*)lf[277]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7097,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7097(t10,t6,t2);}
else{
t7=t6;
f_7014(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7097,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[278]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7114,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1314 ##sys#symbol->string */
t5=*((C_word*)lf[277]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_7114(2,t5,t3);}
else{
/* eval.scm: 1316 err */
t5=((C_word*)t0)[2];
f_6995(t5,t4);}}}}

/* k7112 in loop in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7114,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[279]:lf[280]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7122,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1320 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7097(t7,t5,t6);}

/* k7120 in k7112 in loop in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1312 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7012 in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7014,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7019,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7019(t5,((C_word*)t0)[2],t1);}

/* check in k7012 in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_7019(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7019,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1323 err */
t5=((C_word*)t0)[4];
f_6995(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_7001(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7045,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1325 ##sys#substring */
t8=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_7001(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7058,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1327 ##sys#substring */
t12=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k7056 in check in k7012 in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1327 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7019(t2,((C_word*)t0)[2],t1);}

/* k7043 in check in k7012 in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1325 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7019(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static C_word C_fcall f_7001(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6995,NULL,2,t0,t1);}
/* eval.scm: 1304 ##sys#error */
t2=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[276],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6936,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6945,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6945(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6945(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6945,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6963,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1292 ##sys#substring */
t6=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6983,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1295 ##sys#substring */
t8=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1296 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6981 in loop in ##sys#split-at-separator in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6983,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1295 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6945(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6961 in loop in ##sys#split-at-separator in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6963,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1292 reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6907r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6907r(t0,t1,t2,t3);}}

static void C_ccall f_6907r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[272]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6914,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1283 ##sys#load-library */
t8=*((C_word*)lf[265]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6912 in load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6914,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6922 in k6912 in load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1284 ##sys#error */
t2=*((C_word*)lf[145]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[272],lf[273],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6801,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1256 ##sys#->feature-id */
t5=*((C_word*)lf[271]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6805,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[187]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6814(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6897,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1261 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[261]+1));}}}

/* k6895 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6901,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1262 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6899 in k6895 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6901,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6814(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6814,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6879,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6883,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1267 ##sys#string->c-identifier */
t6=*((C_word*)lf[270]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6881 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1265 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[268],t1,lf[269]);}

/* k6877 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1264 ##sys#make-c-string */
t2=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6820,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1269 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6864 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6866,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1270 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[267]);}
else{
t2=((C_word*)t0)[3];
f_6820(2,t2,C_SCHEME_UNDEFINED);}}

/* k6867 in k6864 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1271 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6870 in k6867 in k6864 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1272 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[266]);}

/* k6818 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6820,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6825(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6818 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6825(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6825,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6838,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6859,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1275 ##sys#make-c-string */
t6=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6857 in loop in k6818 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1275 ##sys#dload */
t2=*((C_word*)lf[243]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6836 in loop in k6818 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6841,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[187]+1)))){
t3=t2;
f_6841(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[187]+1));
t4=C_mutate((C_word*)lf[187]+1,t3);
t5=t2;
f_6841(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1278 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6825(t3,((C_word*)t0)[5],t2);}}

/* k6839 in k6836 in loop in k6818 in k6815 in k6812 in k6803 in ##sys#load-library in k6797 in k6790 in k6785 in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6761r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6761r(t0,t1,t2,t3);}}

static void C_ccall f_6761r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6765,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6782,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[260],t3,t5);}

/* a6781 in load-noisily in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6763 in load-noisily in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6779,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[259],((C_word*)t0)[2],t3);}

/* a6778 in k6763 in load-noisily in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6766 in k6763 in load-noisily in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6771,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6776,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[258],((C_word*)t0)[2],t3);}

/* a6775 in k6766 in k6763 in load-noisily in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6776,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6769 in k6766 in k6763 in load-noisily in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1227 ##sys#load */
t2=*((C_word*)lf[231]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6725r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6725r(t0,t1,t2,t3);}}

static void C_ccall f_6725r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6733,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_6733(2,t6,t2);}
else{
/* eval.scm: 1223 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[217]+1),t2);}}

/* k6731 in load-relative in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 1220 ##sys#load */
t5=*((C_word*)lf[231]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6703r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6703r(t0,t1,t2,t3);}}

static void C_ccall f_6703r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 1217 ##sys#load */
t6=*((C_word*)lf[231]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr5r,(void*)f_6316r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6316r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6316r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(23);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6653,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6658,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer751829 */
t10=t9;
f_6658(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer752827 */
t12=t8;
f_6653(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body749754 */
t14=t7;
f_6318(t14,t1,t10,t12);}}}

/* def-timer751 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6658,NULL,2,t0,t1);}
/* def-printer752827 */
t2=((C_word*)t0)[2];
f_6653(t2,t1,C_SCHEME_FALSE);}

/* def-printer752 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6653(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6653,NULL,3,t0,t1,t2);}
/* body749754 */
t3=((C_word*)t0)[2];
f_6318(t3,t1,t2,C_SCHEME_FALSE);}

/* body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6318(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6318,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6652,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1152 ##sys#expand-home-path */
t6=*((C_word*)lf[255]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_6322(t5,C_SCHEME_UNDEFINED);}}

/* k6650 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6322(t3,t2);}

/* k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6322,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6586,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1155 port? */
t6=*((C_word*)lf[254]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}

/* k6584 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6325(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1157 ##sys#file-info */
t3=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 1148 ##sys#signal-hook */
t3=*((C_word*)lf[225]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[252],lf[237],lf[253],t2);}}}

/* k6599 in k6584 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_6604(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6604(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6604(t3,C_SCHEME_FALSE);}}

/* k6602 in k6599 in k6584 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6604,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6325(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1163 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[251]+1));}}

/* k6605 in k6602 in k6599 in k6584 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1164 ##sys#file-info */
t3=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6611 in k6605 in k6602 in k6599 in k6584 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6613,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6325(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1166 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[17]);}}

/* k6614 in k6611 in k6605 in k6602 in k6599 in k6584 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1167 ##sys#file-info */
t3=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6620 in k6614 in k6611 in k6605 in k6602 in k6599 in k6584 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6325(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6325(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6325,2,t0,t1);}
t2=((C_word*)t0)[17];
t3=(C_truep(t2)?t2:((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6331,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1172 ##sys#signal-hook */
t7=*((C_word*)lf[225]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[246],lf[237],lf[247],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6577,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1173 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k6575 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6577,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6568,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1174 display */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[249]);}
else{
t3=((C_word*)t0)[2];
f_6331(2,t3,C_SCHEME_UNDEFINED);}}

/* k6566 in k6575 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1175 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6569 in k6566 in k6575 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1176 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[248]);}

/* k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1178 ##sys#make-c-string */
t5=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6334(2,t3,C_SCHEME_FALSE);}}

/* k6551 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1178 ##sys#dload */
t2=*((C_word*)lf[243]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6523 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6525,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6334(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1179 has-sep? */
f_6270(t2,((C_word*)t0)[3]);}}

/* k6547 in k6523 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6549,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6334(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6545,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1180 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[245],((C_word*)t0)[2]);}}

/* k6543 in k6547 in k6523 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1180 ##sys#make-c-string */
t2=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6539 in k6547 in k6523 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1180 ##sys#dload */
t2=*((C_word*)lf[243]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6337,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6337(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1181 call-with-current-continuation */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6342,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6346,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6512,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1187 has-sep? */
f_6270(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6346(2,t8,C_SCHEME_FALSE);}}

/* k6510 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 1188 ##sys#substring */
t3=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6346(2,t2,lf[242]);}}

/* k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6346,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6356,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6497,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6496 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6497,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[232]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[216]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[217]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[215]+1));
t6=C_mutate((C_word*)lf[232]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[216]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[217]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[215]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[233]+1));}

/* a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6374,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1190 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6374(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6379,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6488,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1191 ##sys#dynamic-wind */
t5=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6487 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6488,2,t0,t1);}
/* eval.scm: 1213 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6386,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1194 peek-char */
t3=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6482,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6389(2,t4,C_SCHEME_UNDEFINED);}}

/* k6480 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1196 ##sys#error */
t2=*((C_word*)lf[145]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[237],lf[238],((C_word*)t0)[2],t1);}

/* k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1197 read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6397(t5,((C_word*)t0)[2],t1);}

/* do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6397(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6397,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1200 printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6407(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1201 ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6452 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6453r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6453r(t0,t1,t2);}}

static void C_ccall f_6453r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6461 in a6452 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6462,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6466,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1210 write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6464 in a6461 in a6452 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1211 newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6418 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6426,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1204 ##sys#start-timer */
t3=*((C_word*)lf[236]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1205 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6424 in a6418 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6437,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1204 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6436 in k6424 in a6418 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6437r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6437r(t0,t1,t2);}}

static void C_ccall f_6437r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6441,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6448,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1204 ##sys#stop-timer */
t5=*((C_word*)lf[235]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6446 in a6436 in k6424 in a6418 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1204 ##sys#display-times */
t2=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6439 in a6436 in k6424 in a6418 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6430 in k6424 in a6418 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
/* eval.scm: 1204 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6408 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1198 read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6415 in k6408 in k6405 in do802 in k6390 in k6387 in k6384 in a6381 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6397(t2,((C_word*)t0)[2],t1);}

/* a6378 in k6372 in a6369 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6379,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6355 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6356,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[232]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[216]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[217]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[215]+1));
t6=C_mutate((C_word*)lf[232]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[216]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[217]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[215]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[233]+1));}

/* f_6347 in k6344 in a6341 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6347,2,t0,t1);}
/* eval.scm: 1189 abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6335 in k6332 in k6329 in k6323 in k6320 in body749 in ##sys#load in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6270(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6270,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6280,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6280(t5,t4));}

/* loop in has-sep? in k6266 in k6186 in k6087 in k1776 in k1734 in k1731 */
static C_word C_fcall f_6280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6195,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6202,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6207,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6207(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6207,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[221]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6220(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[222]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6220(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[223]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6220(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[224]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6220(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1127 ##sys#signal-hook */
t10=*((C_word*)lf[225]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[219],lf[226],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6218 in loop in set-dynamic-load-mode! in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1128 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6207(t3,((C_word*)t0)[2],t2);}

/* k6200 in set-dynamic-load-mode! in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1129 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6190 in k6186 in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6190,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6106,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6119,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6119(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6119(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6119,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6133,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1097 reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6152,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 1099 reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 1101 loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 1100 err */
t6=((C_word*)t0)[2];
f_6109(t6,t1);}}}
else{
/* eval.scm: 1098 err */
t6=((C_word*)t0)[2];
f_6109(t6,t1);}}}

/* k6150 in loop in ##sys#decompose-lambda-list in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1099 k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6131 in loop in ##sys#decompose-lambda-list in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1097 k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k6087 in k1776 in k1734 in k1731 */
static void C_fcall f_6109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6109,NULL,2,t0,t1);}
t2=C_set_block_item(lf[212],0,C_SCHEME_FALSE);
/* eval.scm: 1094 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[213],((C_word*)t0)[2]);}

/* eval in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6092r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6092r(t0,t1,t2,t3);}}

static void C_ccall f_6092r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6100,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1082 ##sys#eval-handler */
t5=*((C_word*)lf[209]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6098 in eval in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6104,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1083 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6102 in k6098 in eval in k6087 in k1776 in k1734 in k1731 */
static void C_ccall f_6104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+38)){
C_save_and_reclaim((void*)tr5r,(void*)f_3832r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3832r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(38);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3835,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3877,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3989,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4042,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4048,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4054,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4060,a[2]=t9,a[3]=t13,a[4]=t7,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t15,a[8]=t17,a[9]=t12,a[10]=((C_word*)t0)[3],a[11]=((C_word*)t0)[4],a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t19=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5837,a[2]=t15,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t20=(C_word)C_fixnum_greaterp(*((C_word*)lf[137]+1),C_fix(0));
t21=(C_word)C_i_nullp(t5);
t22=(C_truep(t21)?C_SCHEME_FALSE:(C_word)C_u_i_car(t5));
/* eval.scm: 1061 compile */
t23=((C_word*)t15)[1];
f_4060(t23,t1,t2,t3,C_SCHEME_FALSE,t20,t22);}

/* compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_5837(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5837,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5841,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1025 compile */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4060(t8,t6,t7,t3,C_SCHEME_FALSE,t4,t5);}

/* k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5811,tmp=(C_word)a,a+=2,tmp);
t4=f_5811(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 1030 ##sys#syntax-error-hook */
t6=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[208],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5863,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5882,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1034 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4060(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5910,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1038 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4060(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1043 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4060(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5987,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1049 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4060(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6030,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6054,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1056 ##sys#map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a6053 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6054,3,t0,t1,t2);}
/* eval.scm: 1056 compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4060(t3,t1,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6028 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6031 in k6028 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6031,3,t0,t1,t2);}
t3=f_4042(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6042,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6040 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6046,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6048,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1059 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6047 in k6040 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6048,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k6044 in k6040 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5985 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1050 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4060(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5988 in k5985 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1051 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4060(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5991 in k5988 in k5985 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5996,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1052 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4060(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(3)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k5994 in k5991 in k5988 in k5985 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5996,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_5997 in k5994 in k5991 in k5988 in k5985 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5997,3,t0,t1,t2);}
t3=f_4042(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6006 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6010 in k6006 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6014 in k6010 in k6006 */
static void C_ccall f_6016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6018 in k6014 in k6010 in k6006 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6023,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6021 in k6018 in k6014 in k6010 in k6006 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5943 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1044 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4060(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5946 in k5943 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5951,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 1045 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4060(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5949 in k5946 in k5943 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5951,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_5952 in k5949 in k5946 in k5943 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5952,3,t0,t1,t2);}
t3=f_4042(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5961 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5965 in k5961 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5969 in k5965 in k5961 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5974,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5972 in k5969 in k5965 in k5961 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5908 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5913,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1039 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4060(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5911 in k5908 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5913,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_5914 in k5911 in k5908 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5914,3,t0,t1,t2);}
t3=f_4042(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5923 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5927 in k5923 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5932,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5930 in k5927 in k5923 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5880 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5883,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5883 in k5880 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5883,3,t0,t1,t2);}
t3=f_4042(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5894,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5892 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5897,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5895 in k5892 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5863 in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5863,3,t0,t1,t2);}
t3=f_4042(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5873,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1033 fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5871 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k5839 in compile-call in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static C_word C_fcall f_5811(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_4060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4060,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_symbolp(t2))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4073,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=((C_word*)t0)[12],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 668  keyword? */
t8=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[12],a[8]=t4,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[8],a[12]=t6,a[13]=t5,a[14]=((C_word*)t0)[9],a[15]=t1,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 692  ##sys#number? */
t8=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4178,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4186,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4194,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4202,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4215,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4217,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4227(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4227(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_4227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4227,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_4048(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[11],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 711  defined? */
t6=((C_word*)t0)[4];
f_3877(t6,t5,t4,((C_word*)t0)[10]);}
else{
t3=f_4048(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 1002 compile-call */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5837(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[10],((C_word*)t0)[13],((C_word*)t0)[12]);}}
else{
/* eval.scm: 707  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[206],((C_word*)t0)[15]);}}}

/* k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 712  compile-call */
t2=((C_word*)((C_word*)t0)[16])[1];
f_5837(t2,((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4262,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 713  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3989(t3,t2,((C_word*)t0)[14],((C_word*)t0)[13]);}}

/* k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[121],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[90]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 718  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[90],((C_word*)t0)[15],lf[149],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[150]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
if(C_truep(*((C_word*)lf[128]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 733  ##sys#hash-table-location */
t7=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[128]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4359,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[151]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 738  compile */
t7=((C_word*)((C_word*)t0)[12])[1];
f_4060(t7,((C_word*)t0)[13],t6,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 741  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_4060(t8,((C_word*)t0)[13],t7,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[110]);
if(C_truep(t7)){
t8=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4393,tmp=(C_word)a,a+=2,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[153]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 746  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[153],((C_word*)t0)[15],lf[155],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[106]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4460,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 755  ##sys#check-syntax */
t11=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[106],((C_word*)t0)[15],lf[157],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[69]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[14],lf[71]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 771  ##sys#check-syntax */
t13=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[69],((C_word*)t0)[15],lf[160],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[58]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 795  ##sys#check-syntax */
t14=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[58],((C_word*)t0)[15],lf[162],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 845  ##sys#check-syntax */
t15=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[92],((C_word*)t0)[15],lf[168],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[59]);
if(C_truep(t14)){
t15=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t16=(C_word)C_a_i_cons(&a,2,lf[92],t15);
/* eval.scm: 939  compile */
t17=((C_word*)((C_word*)t0)[12])[1];
f_4060(t17,((C_word*)t0)[13],t16,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[169]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cddr(((C_word*)t0)[15]);
t17=(C_word)C_a_i_cons(&a,2,lf[92],t16);
t18=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 942  compile */
t19=((C_word*)((C_word*)t0)[12])[1];
f_4060(t19,((C_word*)t0)[13],t17,((C_word*)t0)[11],t18,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[170]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5417,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5448,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* map */
t20=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[174]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5472,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5478,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=((C_word*)t21)[1];
f_5478(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[177]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[14],lf[178]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5530,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 964  ##sys#compile-to-closure */
t23=*((C_word*)lf[143]+1);
((C_proc6)(void*)(*((C_word*)t23+1)))(6,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[180]);
if(C_truep(t20)){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 968  compile */
t22=((C_word*)((C_word*)t0)[12])[1];
f_4060(t22,((C_word*)t0)[13],t21,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[181]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[14],lf[182]));
if(C_truep(t22)){
/* eval.scm: 971  compile */
t23=((C_word*)((C_word*)t0)[12])[1];
f_4060(t23,((C_word*)t0)[13],lf[183],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[184]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[186],*((C_word*)lf[187]+1)))){
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5579,tmp=(C_word)a,a+=2,tmp);
t26=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* for-each */
t27=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 976  ##sys#warn */
t25=*((C_word*)lf[189]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[190],((C_word*)t0)[15]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[191]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[14],lf[192]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 980  cadadr */
t27=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,((C_word*)t0)[15]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[14],lf[193]);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5631,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t26)){
t28=t27;
f_5631(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[14],lf[197]);
if(C_truep(t28)){
t29=t27;
f_5631(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[14],lf[198]);
if(C_truep(t29)){
t30=t27;
f_5631(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[14],lf[199]);
if(C_truep(t30)){
t31=t27;
f_5631(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[14],lf[200]);
if(C_truep(t31)){
t32=t27;
f_5631(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[14],lf[201]);
if(C_truep(t32)){
t33=t27;
f_5631(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[14],lf[202]);
if(C_truep(t33)){
t34=t27;
f_5631(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[14],lf[203]);
if(C_truep(t34)){
t35=t27;
f_5631(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[14],lf[204]);
t36=t27;
f_5631(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[14],lf[205])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 998  compile */
t3=((C_word*)((C_word*)t0)[12])[1];
f_4060(t3,((C_word*)t0)[13],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5629 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_5631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 987  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[194],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[61]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 990  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5837(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[195]);
if(C_truep(t3)){
/* eval.scm: 994  ##sys#syntax-error-hook */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[8],lf[196],((C_word*)t0)[7]);}
else{
/* eval.scm: 996  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5837(t4,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5616 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[69],t3);
/* eval.scm: 980  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4060(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5578 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5579,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
/* eval.scm: 975  ##compiler#process-declaration */
t4=*((C_word*)lf[188]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k5566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 977  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4060(t2,((C_word*)t0)[5],lf[185],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5528 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5522 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 965  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4060(t2,((C_word*)t0)[5],lf[179],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5478,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[175]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 959  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5499 in loop in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5500,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5508,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 960  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5478(t6,t4,t5);}

/* k5506 in a5499 in loop in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5508,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[2],t1));}

/* a5489 in loop in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
t2=(C_word)C_u_i_cadar(((C_word*)t0)[2]);
/* eval.scm: 959  ##sys#do-the-right-thing */
t3=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* k5470 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 955  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4060(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5447 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5448,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5455,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 945  ##sys#compile-to-closure */
t4=*((C_word*)lf[143]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5453 in a5447 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5415 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5420,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_apply(4,0,t2,*((C_word*)lf[172]+1),t1);}

/* k5418 in k5415 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 947  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[173]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5421 in k5418 in k5415 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5430(t3,lf[171]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5442,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5441 in k5421 in k5418 in k5415 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5442,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k5438 in k5421 in k5418 in k5415 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5430(t2,(C_word)C_a_i_cons(&a,2,lf[172],t1));}

/* k5428 in k5421 in k5418 in k5415 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_5430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 948  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4060(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[8];
t9=(C_truep(t8)?t8:lf[163]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5027,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=t10,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5352,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 849  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5350 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 850  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5027(2,t2,C_SCHEME_UNDEFINED);}}

/* a5362 in k5350 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5363,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5356 in k5350 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
/* eval.scm: 852  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[56]+1));}

/* k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 855  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5032,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5341,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[6];
t10=(C_truep(t9)?t9:((C_word*)t0)[5]);
/* eval.scm: 861  ##sys#canonicalize-body */
t11=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4],t10);}

/* a5340 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5341,3,t0,t1,t2);}
/* defined?324 */
t3=((C_word*)t0)[3];
f_3877(t3,t1,t2,((C_word*)t0)[2]);}

/* k5333 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 860  ##sys#compile-to-closure */
t4=*((C_word*)lf[143]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[86],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5297 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5303,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 930  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5302 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5303r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5303r(t0,t1,t2);}}

static void C_ccall f_5303r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5327,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[164]+1),t2);}
else{
/* eval.scm: 934  ##sys#error */
t5=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[166],((C_word*)t0)[4],t3);}}

/* k5325 in a5302 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5274 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5274,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 923  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5279 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr2r,(void*)f_5280r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5280r(t0,t1,t2);}}

static void C_ccall f_5280r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(17);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5292,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5296,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5296(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5765,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5765(t9,t4,t5,C_fix(0),t2,C_SCHEME_FALSE);}}

/* do615 in a5279 */
static void C_fcall f_5765(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5765,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,1,t4);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5794,a[2]=t4,a[3]=t8,a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t10)){
/* eval.scm: 1011 ##sys#error */
t11=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[165],t2,t3);}
else{
t11=t9;
f_5794(2,t11,(C_word)C_slot(t4,C_fix(1)));}}}

/* k5792 in do615 in a5279 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_5765(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5294 in a5279 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[164]+1),t1);}

/* k5290 in a5279 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5292,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5252 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 916  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5257 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5258,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5270,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 918  ##sys#vector */
t7=*((C_word*)lf[164]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5268 in a5257 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5233 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5233,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5239,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 911  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5238 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5239r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5239r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5239r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5205 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5205,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 905  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5210 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5211,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5186 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5186,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 900  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5191 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5192r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5192r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5158 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5158,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 894  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5163 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5164,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5139 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5139,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5145,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 889  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5144 */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5145r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5145r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5145r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5111 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5117,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 883  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5116 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5117,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_5092 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5092,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 878  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5097 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5098r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5098r(t0,t1,t2,t3);}}

static void C_ccall f_5098r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5068 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5068,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5074,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 873  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5073 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5074,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_5049 in k5037 in a5031 in k5025 in k5013 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5049,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 868  decorate */
f_4054(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5054 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5055r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5055r(t0,t1,t2);}}

static void C_ccall f_5055r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[10]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5002,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a5001 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5002,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4686,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4692,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4990,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4996,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 801  ##sys#canonicalize-body */
t7=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,((C_word*)t0)[4],((C_word*)t0)[6]);}

/* a4995 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4996,3,t0,t1,t2);}
/* defined?324 */
t3=((C_word*)t0)[3];
f_3877(t3,t1,t2,((C_word*)t0)[2]);}

/* k4988 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 800  ##sys#compile-to-closure */
t2=*((C_word*)lf[143]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4692,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4701,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 806  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4060(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 809  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4060(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 813  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4060(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 821  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4060(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4973 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4974,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 835  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4060(t5,t1,t3,((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4925 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4928,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4928 in k4925 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4928,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 837  ##sys#make-vector */
t4=*((C_word*)lf[161]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4930 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4944(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do497 in k4930 */
static void C_fcall f_4944(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4944,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4969,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4967 in do497 in k4930 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4944(t5,((C_word*)t0)[2],t3,t4);}

/* k4933 in k4930 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4935,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4849 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 822  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4910 in k4849 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 822  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4060(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4852 in k4849 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4860,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 824  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4060(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4858 in k4852 in k4849 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 825  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4894 in k4858 in k4852 in k4849 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 825  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4060(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4861 in k4858 in k4852 in k4849 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4864 in k4861 in k4858 in k4852 in k4849 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4864,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4878 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4884,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4882 in k4878 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4886 in k4882 in k4878 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4890 in k4886 in k4882 in k4878 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4782 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 814  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4828 in k4782 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 814  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4060(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4785 in k4782 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 816  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4060(t6,t3,t4,((C_word*)t0)[4],t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4791 in k4785 in k4782 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4794 in k4791 in k4785 in k4782 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4808 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4812 in k4808 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4816 in k4812 in k4808 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4733 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4738,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 810  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4761 in k4733 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 810  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4060(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4736 in k4733 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4739 in k4736 in k4733 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4739,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4753 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4757 in k4753 */
static void C_ccall f_4759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4759,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4699 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4702,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4702 in k4699 in k4690 in k4684 in k4675 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4702,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4718,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4716 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4568,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4582,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 774  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4060(t6,t4,t5,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4643,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4656,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 776  ##sys#alias-global-hook */
t4=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k4593 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
if(C_truep(*((C_word*)lf[128]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 778  ##sys#hash-table-location */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[128]+1),t1,*((C_word*)lf[129]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4628 in k4593 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4628,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4634 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4599 in k4593 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4604(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 782  ##sys#error */
t3=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[159],((C_word*)t0)[2]);}}

/* k4602 in k4599 in k4593 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4620 in k4602 in k4599 in k4593 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
/* eval.scm: 785  ##sys#error */
t2=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[158],((C_word*)t0)[2]);}

/* f_4611 in k4602 in k4599 in k4593 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4619,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4617 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4656 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4656,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4662 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4643 in k4584 in a4581 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4643,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4653 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4575 in k4566 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
/* eval.scm: 773  lookup */
f_3835(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 759  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_4060(t4,((C_word*)t0)[5],lf[156],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 760  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4060(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 761  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4060(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 765  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4060(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4517 in k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 766  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4060(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4520 in k4517 in k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,lf[106],t4);
/* eval.scm: 767  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4060(t6,t2,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4523 in k4520 in k4517 in k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4526 in k4523 in k4520 in k4517 in k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4526,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4530,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4528 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4531 in k4528 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4495 in k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4500,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 762  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4060(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4498 in k4495 in k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4501 in k4498 in k4495 in k4458 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4501,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4503 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4401 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 747  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4060(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4404 in k4401 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 748  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4060(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4407 in k4404 in k4401 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[6]);
/* eval.scm: 750  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4060(t5,t2,t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 751  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4060(t4,t2,lf[154],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4410 in k4407 in k4404 in k4401 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4413 in k4410 in k4407 in k4404 in k4401 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4413,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4418 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4393 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4393,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4359 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4351 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4354,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4354 in k4351 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4287,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4295,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4303,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4311,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4319,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4327,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4335,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4337,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4337 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4335 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4335,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4327 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4319 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4311 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4303 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4295 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4287 in k4275 in k4260 in k4254 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4228 in k4225 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4217 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4215 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4215,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4204 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4202 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4194 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4186 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4186,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4178 in k4169 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 670  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[7],t2,t3);}}

/* a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4086,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4161,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 672  ##sys#alias-global-hook */
t6=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
if(C_truep(*((C_word*)lf[128]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4102,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 674  ##sys#hash-table-location */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[128]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4125,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4130,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[136]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4145,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 687  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_4130(t4,C_SCHEME_FALSE);}}}

/* k4143 in k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4130(t2,(C_word)C_i_not(t1));}

/* k4128 in k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_4130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4130,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[136]+1));
t4=C_mutate((C_word*)lf[136]+1,t3);
t5=((C_word*)t0)[2];
f_4125(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_4125(t2,C_SCHEME_UNDEFINED);}}

/* k4123 in k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_4125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4125,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_4126 in k4123 in k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k4100 in k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4105(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 675  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[147],((C_word*)t0)[2]);}}

/* k4103 in k4100 in k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_4106 in k4103 in k4100 in k4094 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4106,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 682  ##sys#error */
t4=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[146],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4161 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4161,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4152 in a4085 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4152,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a4079 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
/* eval.scm: 670  lookup */
f_3835(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_4074 in k4071 in compile in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_4054(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4054,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 664  ##sys#eval-decorator */
t6=*((C_word*)lf[130]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static C_word C_fcall f_4048(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[144]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static C_word C_fcall f_4042(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[144]+1)):C_SCHEME_UNDEFINED));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_3989(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3989,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 644  ##sys#macroexpand-1-local */
t5=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}

/* k3991 in macroexpand-1-checked in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,lf[58]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4040,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 647  defined? */
t6=((C_word*)t0)[2];
f_3877(t6,t5,lf[58],((C_word*)t0)[3]);}
else{
t5=t3;
f_4008(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k4038 in k3991 in macroexpand-1-checked in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4008(t2,(C_word)C_i_not(t1));}

/* k4006 in k3991 in macroexpand-1-checked in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_4008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4008,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_4017(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_4017(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k4015 in k4006 in k3991 in macroexpand-1-checked in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_4017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 650  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3989(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* defined? in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_3877(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3877,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3889,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3888 in defined? in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3889,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3882 in defined? in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
/* eval.scm: 619  lookup */
f_3835(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_3835(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3835,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3841,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3841(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3841,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 614  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3959,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3959(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 615  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 616  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1776 in k1734 in k1731 */
static C_word C_fcall f_3959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#alias-global-hook in k1776 in k1734 in k1731 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3826,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#eval-decorator in k1776 in k1734 in k1731 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3785,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3791,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3804,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 583  ##sys#decorate-lambda */
t8=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3803 in ##sys#eval-decorator in k1776 in k1734 in k1731 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3804,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3812,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 590  open-output-string */
t6=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3814 in a3803 in ##sys#eval-decorator in k1776 in k1734 in k1731 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3819,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 591  write */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3817 in k3814 in a3803 in ##sys#eval-decorator in k1776 in k1734 in k1731 */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3822,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 592  get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3820 in k3817 in k3814 in a3803 in ##sys#eval-decorator in k1776 in k1734 in k1731 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 589  ##sys#make-lambda-info */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3810 in a3803 in ##sys#eval-decorator in k1776 in k1734 in k1731 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3790 in ##sys#eval-decorator in k1776 in k1734 in k1731 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3791,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k1776 in k1734 in k1731 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3725,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3729,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 563  ##sys#hash-symbol */
t7=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3727 in ##sys#hash-table-location in k1776 in k1734 in k1731 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3737,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3737(t6,((C_word*)t0)[2],t2);}

/* loop in k3727 in ##sys#hash-table-location in k1776 in k1734 in k1731 */
static void C_fcall f_3737(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3737,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 574  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table->alist in k1776 in k1734 in k1731 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3658,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3664,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3664(t7,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in ##sys#hash-table->alist in k1776 in k1734 in k1731 */
static void C_fcall f_3664(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3664,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(*((C_word*)lf[125]+1),t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3680,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3680(t8,t1,t4,t3);}}

/* loop2 in loop in ##sys#hash-table->alist in k1776 in k1734 in k1731 */
static void C_fcall f_3680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3680,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 555  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3664(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* eval.scm: 556  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* ##sys#hash-table-for-each in k1776 in k1734 in k1731 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3615,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3621,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3621(t8,t1,C_fix(0));}

/* do269 in ##sys#hash-table-for-each in k1776 in k1734 in k1731 */
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3621,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3631,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 543  ##sys#for-each */
t6=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3639 in do269 in ##sys#hash-table-for-each in k1776 in k1734 in k1731 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3640,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 544  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3629 in do269 in ##sys#hash-table-for-each in k1776 in k1734 in k1731 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3621(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k1776 in k1734 in k1731 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3595,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3603,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3607,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 537  ##sys#hash-table-ref */
t8=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k3605 in ##sys#hash-table-update! in k1776 in k1734 in k1731 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3610(2,t3,t1);}
else{
/* eval.scm: 537  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3608 in k3605 in ##sys#hash-table-update! in k1776 in k1734 in k1731 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 537  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3601 in ##sys#hash-table-update! in k1776 in k1734 in k1731 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 537  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k1776 in k1734 in k1731 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3540,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3544,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 526  ##sys#hash-symbol */
t6=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3542 in ##sys#hash-table-set! in k1776 in k1734 in k1731 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3552,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3552(t6,((C_word*)t0)[2],t2);}

/* loop in k3542 in ##sys#hash-table-set! in k1776 in k1734 in k1731 */
static void C_fcall f_3552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3552,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 534  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1776 in k1734 in k1731 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3495,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3499,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 516  ##sys#hash-symbol */
t5=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3497 in ##sys#hash-table-ref in k1776 in k1734 in k1731 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3508(t3,t2));}

/* loop in k3497 in ##sys#hash-table-ref in k1776 in k1734 in k1731 */
static C_word C_fcall f_3508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1776 in k1734 in k1731 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3480,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1776 in k1734 in k1731 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3420,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3423,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3475,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 493  loop */
t10=((C_word*)t7)[1];
f_3423(t10,t9,t2,t3);}

/* k3473 in ##sys#expand-curried-define in k1776 in k1734 in k1731 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1776 in k1734 in k1731 */
static void C_fcall f_3423(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3423,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[92],t8));}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,lf[92],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* eval.scm: 492  loop */
t15=t1;
t16=t5;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* ##sys#match-expression in k1776 in k1734 in k1731 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3329,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3332,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3418,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 480  mwalk */
t11=((C_word*)t8)[1];
f_3332(t11,t10,t2,t3);}

/* k3416 in ##sys#match-expression in k1776 in k1734 in k1731 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1776 in k1734 in k1731 */
static void C_fcall f_3332(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3332,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_u_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_u_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3387,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 477  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3385 in mwalk in ##sys#match-expression in k1776 in k1734 in k1731 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 478  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3332(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2846r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2846r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2846r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2848,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3279,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-me154207 */
t8=t7;
f_3284(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-container155205 */
t10=t6;
f_3279(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body152157 */
t12=t5;
f_2848(t12,t1,t8);}}}

/* def-me154 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_3284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3284,NULL,2,t0,t1);}
/* def-container155205 */
t2=((C_word*)t0)[2];
f_3279(t2,t1,C_SCHEME_FALSE);}

/* def-container155 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_3279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3279,NULL,3,t0,t1,t2);}
/* body152157 */
t3=((C_word*)t0)[2];
f_2848(t3,t1,t2);}

/* body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2848,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
/* eval.scm: 461  expand */
t9=((C_word*)t6)[1];
f_3031(t9,t1,((C_word*)t0)[2]);}

/* expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_3031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3031,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3037(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3037,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 427  lookup */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t10);}
else{
t12=t11;
f_3071(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 426  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2851(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 422  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2851(t7,t1,t3,t4,t5,t6,t2);}}

/* k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3071,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 428  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2851(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[107],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 430  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[107],((C_word*)t0)[3],lf[116],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[108],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3201,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 451  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[108],((C_word*)t0)[3],lf[117],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[106],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3229,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 454  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[106],((C_word*)t0)[3],lf[118],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 457  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3241 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 459  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2851(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 460  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3037(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3227 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 455  ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3234 in k3227 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 455  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3037(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3199 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3201,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 452  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3037(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k3081 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3088,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3088(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k3081 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3088,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3135,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 442  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[112],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 445  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[113],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 434  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[107],t2,lf[115],C_SCHEME_FALSE);}}

/* k3099 in loop2 in k3081 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3101,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_caddr(((C_word*)t0)[8]):lf[114]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 435  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3037(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3151 in loop2 in k3081 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[7]);
/* eval.scm: 446  loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3037(t9,((C_word*)t0)[5],((C_word*)t0)[4],t3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3133 in loop2 in k3081 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 443  ##sys#expand-curried-define */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3144 in k3133 in loop2 in k3081 in k3069 in loop in expand in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],t1);
/* eval.scm: 443  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3088(t3,((C_word*)t0)[2],t2);}

/* fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_2851(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2851,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2863,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2863(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2933,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 406  reverse */
t10=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}

/* k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3011,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3023,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[88]+1),t1,((C_word*)t0)[3]);}

/* k3021 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 407  ##sys#map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3010 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3011,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[110]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3001,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 409  reverse */
t6=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k3007 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 409  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3000 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3001,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2956,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 416  reverse */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2993 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2999,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 417  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2997 in k2993 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 410  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2961 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2962,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2966,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 411  ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[83]+1),t2);}

/* k2964 in a2961 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2985,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2987,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 415  map */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2986 in k2964 in a2961 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2987,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2983 in k2964 in a2961 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[92],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k2958 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2954 in k2950 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2946 in k2942 in k2931 in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* loop in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_2863(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2863,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[107],lf[108]);
t8=t5;
f_2882(t8,(C_word)C_u_i_memq(t6,t7));}
else{
t6=t5;
f_2882(t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[106],((C_word*)t0)[2]));}}

/* k2880 in loop in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_fcall f_2882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2882,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 404  reverse */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 405  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2863(t4,((C_word*)t0)[8],t2,t3);}}

/* k2891 in k2880 in loop in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 404  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3031(t3,t2,((C_word*)t0)[2]);}

/* k2899 in k2891 in k2880 in loop in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 404  ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2887 in k2880 in loop in fini in body152 in ##sys#canonicalize-body in k1776 in k1734 in k1731 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2327,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2330,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_2349(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2349(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2349,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 322  reverse */
t9=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
/* eval.scm: 322  reverse */
t8=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 345  err */
t7=((C_word*)t0)[4];
f_2330(t7,t1,lf[94]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2593,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2593(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2593(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[80]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2625(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2644,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 357  gensym */
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[79]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2662(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2662(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 369  err */
t11=((C_word*)t0)[4];
f_2330(t11,t1,lf[97]);}}
else{
t11=(C_word)C_eqp(t7,lf[81]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2708,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2708(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2727,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 371  gensym */
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 378  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 379  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 380  err */
t13=((C_word*)t0)[4];
f_2330(t13,t1,lf[99]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 381  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2789,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2789(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2789(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 351  err */
t7=((C_word*)t0)[4];
f_2330(t7,t1,lf[103]);}}}}

/* k2787 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2789,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 384  err */
t3=((C_word*)t0)[9];
f_2330(t3,((C_word*)t0)[8],lf[100]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 385  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2349(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 386  err */
t3=((C_word*)t0)[9];
f_2330(t3,((C_word*)t0)[8],lf[101]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 387  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2349(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 388  err */
t2=((C_word*)t0)[9];
f_2330(t2,((C_word*)t0)[8],lf[102]);}}

/* k2725 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2708(t3,t2);}

/* k2706 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 373  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2349(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 374  err */
t2=((C_word*)t0)[2];
f_2330(t2,((C_word*)t0)[6],lf[98]);}}

/* k2660 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2662,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2665(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2665(t6,t5);}}
else{
/* eval.scm: 368  err */
t2=((C_word*)t0)[2];
f_2330(t2,((C_word*)t0)[6],lf[96]);}}

/* k2663 in k2660 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 367  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2349(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2642 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2625(t3,t2);}

/* k2623 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 359  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2349(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 360  err */
t3=((C_word*)t0)[2];
f_2330(t3,((C_word*)t0)[5],lf[95]);}}

/* k2591 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 349  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2349(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2570 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 322  ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2367(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2565,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 333  reverse */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}}

/* k2563 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2507 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2508,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2561,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 312  string->keyword */
t6=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2559 in a2507 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=t3;
f_2535(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t5=t3;
f_2535(t5,C_SCHEME_END_OF_LIST);}}

/* k2533 in k2559 in a2507 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2535,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t4));}

/* k2504 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[89],t2);
t4=((C_word*)t0)[2];
f_2367(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2365 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2367,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2370(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2379(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=t3;
f_2379(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2379(t5,C_SCHEME_FALSE);}}}}

/* k2377 in k2365 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2379,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(((C_word*)t0)[8]);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[85],((C_word*)((C_word*)t0)[7])[1],t3);
t5=(C_word)C_a_i_list(&a,2,t2,t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,lf[58],t7);
t9=((C_word*)t0)[5];
f_2370(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2435,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 339  reverse */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2458,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 341  reverse */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[8]);}}}

/* k2456 in k2377 in k2365 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 341  ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2452 in k2377 in k2365 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[87],t3);
t5=((C_word*)t0)[2];
f_2370(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2433 in k2377 in k2365 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[86],t3);
t5=((C_word*)t0)[2];
f_2370(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2368 in k2365 in k2361 in loop in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 321  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1776 in k1734 in k1731 */
static void C_fcall f_2330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2330,NULL,3,t0,t1,t2);}
/* eval.scm: 311  errh */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1776 in k1734 in k1731 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2284,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2290(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1776 in k1734 in k1731 */
static void C_fcall f_2290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2290,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[79]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2309(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[80]);
t7=t5;
f_2309(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[81])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2307 in loop in ##sys#extended-lambda-list? in k1776 in k1734 in k1731 */
static void C_fcall f_2309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 305  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2290(t3,((C_word*)t0)[4],t2);}}

/* macroexpand-1 in k1776 in k1734 in k1731 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2268r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2268r(t0,t1,t2,t3);}}

static void C_ccall f_2268r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 285  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t5);}

/* macroexpand in k1776 in k1734 in k1731 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2232r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2232r(t0,t1,t2,t3);}}

static void C_ccall f_2232r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2241(t9,t1,t2);}

/* loop in macroexpand in k1776 in k1734 in k1731 */
static void C_fcall f_2241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2241,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2252 in loop in macroexpand in k1776 in k1734 in k1731 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2253,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 281  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2241(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2246 in loop in macroexpand in k1776 in k1734 in k1731 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
/* eval.scm: 279  ##sys#macroexpand-0 */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1776 in k1734 in k1731 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2225,4,t0,t1,t2,t3);}
/* eval.scm: 266  ##sys#macroexpand-0 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1776 in k1734 in k1731 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2222,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1776 in k1734 in k1731 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2219,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1849,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1998,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[58]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2086,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 235  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[58],t7,lf[66]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2159,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_2159(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_2159(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_2159(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 258  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 259  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k2157 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_2159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2159,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 251  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[69],((C_word*)t0)[6],lf[70]);}
else{
/* eval.scm: 257  expand */
t2=((C_word*)t0)[4];
f_1998(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2163 in k2157 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 253  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t2,t5,t6,t7);}

/* k2170 in k2163 in k2157 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 252  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2084 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 238  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[58],((C_word*)t0)[4],lf[65]);}
else{
/* eval.scm: 246  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2096 in k2084 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2140,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2146,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a2145 in k2096 in k2084 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2146,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k2138 in k2096 in k2084 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[59],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[60],t6,((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  ##sys#map */
t9=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k2118 in k2138 in k2096 in k2084 in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
/* eval.scm: 240  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_1998(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1998,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2012,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 219  ##sys#hash-table-ref */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[37]+1),t3);}}

/* k2016 in expand in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2026,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2026(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* eval.scm: 228  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* scan in k2016 in expand in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_2026(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2026,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 225  call-handler */
t4=((C_word*)t0)[6];
f_1852(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 226  scan */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
/* eval.scm: 227  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[57],((C_word*)t0)[3]);}}}

/* k2038 in scan in k2016 in expand in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 225  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2010 in expand in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 218  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1852,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1861,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1867,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1974,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1973 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1985 in a1973 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1986r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1986r(t0,t1,t2);}}

static void C_ccall f_1986r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1991 in a1985 in a1973 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1979 in a1973 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
/* eval.scm: 215  handler */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1867,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1872 in a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[48]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1884(t5,(C_word)C_i_memv(lf[53],t4));}
else{
t4=t3;
f_1884(t4,C_SCHEME_FALSE);}}

/* k1882 in a1872 in a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_1884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1884,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1901,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1901(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1881(t2,((C_word*)t0)[5]);}}

/* copy in k1882 in a1872 in a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1901,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_equalp(lf[52],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_u_i_car(t4);
t7=t5;
f_1920(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_1920(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_1920(t6,C_SCHEME_FALSE);}}}

/* k1918 in copy in k1882 in a1872 in a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_1920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1920,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 209  string-append */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[50],t3,lf[51],t4);}
else{
/* eval.scm: 213  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1901(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1929 in k1918 in copy in k1882 in a1872 in a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k1893 in k1882 in a1872 in a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1881(t2,(C_word)C_a_i_record(&a,3,lf[48],((C_word*)t0)[2],t1));}

/* k1879 in a1872 in a1866 in a1860 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_fcall f_1881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 193  ##sys#abort */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1857 in call-handler in ##sys#macroexpand-0 in k1776 in k1734 in k1731 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1776 in k1734 in k1731 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1840,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[44]);
t4=t2;
/* eval.scm: 178  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t4,C_SCHEME_FALSE);}

/* macro? in k1776 in k1734 in k1731 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1822,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[43]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1832,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 175  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1830 in macro? in k1776 in k1734 in k1731 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#copy-macro in k1776 in k1734 in k1731 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1812,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1820,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 171  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1818 in ##sys#copy-macro in k1776 in k1734 in k1731 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 171  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* ##sys#register-macro in k1776 in k1734 in k1731 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1796,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 166  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1801 in ##sys#register-macro in k1776 in k1734 in k1731 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1802,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1776 in k1734 in k1731 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1780,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 160  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1785 in ##sys#register-macro-2 in k1776 in k1734 in k1731 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1786,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 162  handler */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* chicken-home in k1734 in k1731 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 151  ##sys#chicken-prefix */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[36]);}

/* k1766 in chicken-home in k1734 in k1731 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k1734 in k1731 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1737r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1737r(t0,t1,t2);}}

static void C_ccall f_1737r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 143  ##sys#string-append */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[940] = {
{"topleveleval.scm",(void*)C_eval_toplevel},
{"f_1733eval.scm",(void*)f_1733},
{"f_1736eval.scm",(void*)f_1736},
{"f_1778eval.scm",(void*)f_1778},
{"f_11475eval.scm",(void*)f_11475},
{"f_11479eval.scm",(void*)f_11479},
{"f_11503eval.scm",(void*)f_11503},
{"f_11497eval.scm",(void*)f_11497},
{"f_11487eval.scm",(void*)f_11487},
{"f_11485eval.scm",(void*)f_11485},
{"f_6089eval.scm",(void*)f_6089},
{"f_6188eval.scm",(void*)f_6188},
{"f_6268eval.scm",(void*)f_6268},
{"f_11469eval.scm",(void*)f_11469},
{"f_11465eval.scm",(void*)f_11465},
{"f_11461eval.scm",(void*)f_11461},
{"f_11457eval.scm",(void*)f_11457},
{"f_11447eval.scm",(void*)f_11447},
{"f_6787eval.scm",(void*)f_6787},
{"f_6792eval.scm",(void*)f_6792},
{"f_11425eval.scm",(void*)f_11425},
{"f_11417eval.scm",(void*)f_11417},
{"f_11419eval.scm",(void*)f_11419},
{"f_6799eval.scm",(void*)f_6799},
{"f_11386eval.scm",(void*)f_11386},
{"f_11406eval.scm",(void*)f_11406},
{"f_11402eval.scm",(void*)f_11402},
{"f_11392eval.scm",(void*)f_11392},
{"f_11389eval.scm",(void*)f_11389},
{"f_7152eval.scm",(void*)f_7152},
{"f_11332eval.scm",(void*)f_11332},
{"f_11346eval.scm",(void*)f_11346},
{"f_11382eval.scm",(void*)f_11382},
{"f_11378eval.scm",(void*)f_11378},
{"f_11366eval.scm",(void*)f_11366},
{"f_11370eval.scm",(void*)f_11370},
{"f_11340eval.scm",(void*)f_11340},
{"f_7871eval.scm",(void*)f_7871},
{"f_11211eval.scm",(void*)f_11211},
{"f_11248eval.scm",(void*)f_11248},
{"f_11257eval.scm",(void*)f_11257},
{"f_11276eval.scm",(void*)f_11276},
{"f_11280eval.scm",(void*)f_11280},
{"f_11266eval.scm",(void*)f_11266},
{"f_11263eval.scm",(void*)f_11263},
{"f_11214eval.scm",(void*)f_11214},
{"f_7874eval.scm",(void*)f_7874},
{"f_7932eval.scm",(void*)f_7932},
{"f_11209eval.scm",(void*)f_11209},
{"f_8267eval.scm",(void*)f_8267},
{"f_8271eval.scm",(void*)f_8271},
{"f_11205eval.scm",(void*)f_11205},
{"f_8274eval.scm",(void*)f_8274},
{"f_8278eval.scm",(void*)f_8278},
{"f_11108eval.scm",(void*)f_11108},
{"f_11114eval.scm",(void*)f_11114},
{"f_11130eval.scm",(void*)f_11130},
{"f_11133eval.scm",(void*)f_11133},
{"f_11168eval.scm",(void*)f_11168},
{"f_11171eval.scm",(void*)f_11171},
{"f_11155eval.scm",(void*)f_11155},
{"f_11158eval.scm",(void*)f_11158},
{"f_11165eval.scm",(void*)f_11165},
{"f_8961eval.scm",(void*)f_8961},
{"f_11080eval.scm",(void*)f_11080},
{"f_8964eval.scm",(void*)f_8964},
{"f_11037eval.scm",(void*)f_11037},
{"f_11059eval.scm",(void*)f_11059},
{"f_8967eval.scm",(void*)f_8967},
{"f_10840eval.scm",(void*)f_10840},
{"f_10846eval.scm",(void*)f_10846},
{"f_10862eval.scm",(void*)f_10862},
{"f_10938eval.scm",(void*)f_10938},
{"f_10995eval.scm",(void*)f_10995},
{"f_10941eval.scm",(void*)f_10941},
{"f_10968eval.scm",(void*)f_10968},
{"f_10901eval.scm",(void*)f_10901},
{"f_10920eval.scm",(void*)f_10920},
{"f_10892eval.scm",(void*)f_10892},
{"f_8970eval.scm",(void*)f_8970},
{"f_10737eval.scm",(void*)f_10737},
{"f_10747eval.scm",(void*)f_10747},
{"f_10760eval.scm",(void*)f_10760},
{"f_10776eval.scm",(void*)f_10776},
{"f_10814eval.scm",(void*)f_10814},
{"f_10812eval.scm",(void*)f_10812},
{"f_10804eval.scm",(void*)f_10804},
{"f_10758eval.scm",(void*)f_10758},
{"f_8973eval.scm",(void*)f_8973},
{"f_10684eval.scm",(void*)f_10684},
{"f_10694eval.scm",(void*)f_10694},
{"f_10697eval.scm",(void*)f_10697},
{"f_10702eval.scm",(void*)f_10702},
{"f_10727eval.scm",(void*)f_10727},
{"f_8976eval.scm",(void*)f_8976},
{"f_10614eval.scm",(void*)f_10614},
{"f_10624eval.scm",(void*)f_10624},
{"f_10627eval.scm",(void*)f_10627},
{"f_10674eval.scm",(void*)f_10674},
{"f_10638eval.scm",(void*)f_10638},
{"f_10660eval.scm",(void*)f_10660},
{"f_10646eval.scm",(void*)f_10646},
{"f_10642eval.scm",(void*)f_10642},
{"f_8979eval.scm",(void*)f_8979},
{"f_10495eval.scm",(void*)f_10495},
{"f_10499eval.scm",(void*)f_10499},
{"f_10502eval.scm",(void*)f_10502},
{"f_10505eval.scm",(void*)f_10505},
{"f_10596eval.scm",(void*)f_10596},
{"f_10512eval.scm",(void*)f_10512},
{"f_10535eval.scm",(void*)f_10535},
{"f_10549eval.scm",(void*)f_10549},
{"f_10547eval.scm",(void*)f_10547},
{"f_8982eval.scm",(void*)f_8982},
{"f_10203eval.scm",(void*)f_10203},
{"f_10413eval.scm",(void*)f_10413},
{"f_10417eval.scm",(void*)f_10417},
{"f_10438eval.scm",(void*)f_10438},
{"f_10480eval.scm",(void*)f_10480},
{"f_10216eval.scm",(void*)f_10216},
{"f_10404eval.scm",(void*)f_10404},
{"f_10408eval.scm",(void*)f_10408},
{"f_10387eval.scm",(void*)f_10387},
{"f_10391eval.scm",(void*)f_10391},
{"f_10376eval.scm",(void*)f_10376},
{"f_10368eval.scm",(void*)f_10368},
{"f_10357eval.scm",(void*)f_10357},
{"f_10323eval.scm",(void*)f_10323},
{"f_10304eval.scm",(void*)f_10304},
{"f_10277eval.scm",(void*)f_10277},
{"f_10234eval.scm",(void*)f_10234},
{"f_10230eval.scm",(void*)f_10230},
{"f_10206eval.scm",(void*)f_10206},
{"f_10214eval.scm",(void*)f_10214},
{"f_8985eval.scm",(void*)f_8985},
{"f_10193eval.scm",(void*)f_10193},
{"f_8988eval.scm",(void*)f_8988},
{"f_9947eval.scm",(void*)f_9947},
{"f_10102eval.scm",(void*)f_10102},
{"f_10173eval.scm",(void*)f_10173},
{"f_10118eval.scm",(void*)f_10118},
{"f_10116eval.scm",(void*)f_10116},
{"f_9960eval.scm",(void*)f_9960},
{"f_10086eval.scm",(void*)f_10086},
{"f_10048eval.scm",(void*)f_10048},
{"f_10009eval.scm",(void*)f_10009},
{"f_9950eval.scm",(void*)f_9950},
{"f_8991eval.scm",(void*)f_8991},
{"f_8995eval.scm",(void*)f_8995},
{"f_9944eval.scm",(void*)f_9944},
{"f_9017eval.scm",(void*)f_9017},
{"f_9377eval.scm",(void*)f_9377},
{"f_9802eval.scm",(void*)f_9802},
{"f_9920eval.scm",(void*)f_9920},
{"f_9923eval.scm",(void*)f_9923},
{"f_9910eval.scm",(void*)f_9910},
{"f_9805eval.scm",(void*)f_9805},
{"f_9809eval.scm",(void*)f_9809},
{"f_9820eval.scm",(void*)f_9820},
{"f_9463eval.scm",(void*)f_9463},
{"f_9783eval.scm",(void*)f_9783},
{"f_9787eval.scm",(void*)f_9787},
{"f_9796eval.scm",(void*)f_9796},
{"f_9794eval.scm",(void*)f_9794},
{"f_9466eval.scm",(void*)f_9466},
{"f_9777eval.scm",(void*)f_9777},
{"f_9469eval.scm",(void*)f_9469},
{"f_9771eval.scm",(void*)f_9771},
{"f_9472eval.scm",(void*)f_9472},
{"f_9762eval.scm",(void*)f_9762},
{"f_9769eval.scm",(void*)f_9769},
{"f_9752eval.scm",(void*)f_9752},
{"f_9737eval.scm",(void*)f_9737},
{"f_9741eval.scm",(void*)f_9741},
{"f_9746eval.scm",(void*)f_9746},
{"f_9750eval.scm",(void*)f_9750},
{"f_9715eval.scm",(void*)f_9715},
{"f_9719eval.scm",(void*)f_9719},
{"f_9724eval.scm",(void*)f_9724},
{"f_9728eval.scm",(void*)f_9728},
{"f_9735eval.scm",(void*)f_9735},
{"f_9689eval.scm",(void*)f_9689},
{"f_9695eval.scm",(void*)f_9695},
{"f_9699eval.scm",(void*)f_9699},
{"f_9713eval.scm",(void*)f_9713},
{"f_9702eval.scm",(void*)f_9702},
{"f_9709eval.scm",(void*)f_9709},
{"f_9673eval.scm",(void*)f_9673},
{"f_9679eval.scm",(void*)f_9679},
{"f_9687eval.scm",(void*)f_9687},
{"f_9636eval.scm",(void*)f_9636},
{"f_9640eval.scm",(void*)f_9640},
{"f_9645eval.scm",(void*)f_9645},
{"f_9649eval.scm",(void*)f_9649},
{"f_9671eval.scm",(void*)f_9671},
{"f_9667eval.scm",(void*)f_9667},
{"f_9663eval.scm",(void*)f_9663},
{"f_9652eval.scm",(void*)f_9652},
{"f_9659eval.scm",(void*)f_9659},
{"f_9610eval.scm",(void*)f_9610},
{"f_9616eval.scm",(void*)f_9616},
{"f_9620eval.scm",(void*)f_9620},
{"f_9634eval.scm",(void*)f_9634},
{"f_9623eval.scm",(void*)f_9623},
{"f_9630eval.scm",(void*)f_9630},
{"f_9597eval.scm",(void*)f_9597},
{"f_9571eval.scm",(void*)f_9571},
{"f_9575eval.scm",(void*)f_9575},
{"f_9580eval.scm",(void*)f_9580},
{"f_9584eval.scm",(void*)f_9584},
{"f_9595eval.scm",(void*)f_9595},
{"f_9591eval.scm",(void*)f_9591},
{"f_9555eval.scm",(void*)f_9555},
{"f_9561eval.scm",(void*)f_9561},
{"f_9569eval.scm",(void*)f_9569},
{"f_9543eval.scm",(void*)f_9543},
{"f_9549eval.scm",(void*)f_9549},
{"f_9553eval.scm",(void*)f_9553},
{"f_9534eval.scm",(void*)f_9534},
{"f_9538eval.scm",(void*)f_9538},
{"f_9475eval.scm",(void*)f_9475},
{"f_9485eval.scm",(void*)f_9485},
{"f_9510eval.scm",(void*)f_9510},
{"f_9522eval.scm",(void*)f_9522},
{"f_9528eval.scm",(void*)f_9528},
{"f_9516eval.scm",(void*)f_9516},
{"f_9491eval.scm",(void*)f_9491},
{"f_9497eval.scm",(void*)f_9497},
{"f_9501eval.scm",(void*)f_9501},
{"f_9504eval.scm",(void*)f_9504},
{"f_9508eval.scm",(void*)f_9508},
{"f_9483eval.scm",(void*)f_9483},
{"f_9388eval.scm",(void*)f_9388},
{"f_9398eval.scm",(void*)f_9398},
{"f_9401eval.scm",(void*)f_9401},
{"f_9415eval.scm",(void*)f_9415},
{"f_9433eval.scm",(void*)f_9433},
{"f_9402eval.scm",(void*)f_9402},
{"f_9379eval.scm",(void*)f_9379},
{"f_9038eval.scm",(void*)f_9038},
{"f_9082eval.scm",(void*)f_9082},
{"f_9085eval.scm",(void*)f_9085},
{"f_9362eval.scm",(void*)f_9362},
{"f_9366eval.scm",(void*)f_9366},
{"f_9370eval.scm",(void*)f_9370},
{"f_9167eval.scm",(void*)f_9167},
{"f_9173eval.scm",(void*)f_9173},
{"f_9345eval.scm",(void*)f_9345},
{"f_9351eval.scm",(void*)f_9351},
{"f_9180eval.scm",(void*)f_9180},
{"f_9183eval.scm",(void*)f_9183},
{"f_9186eval.scm",(void*)f_9186},
{"f_9340eval.scm",(void*)f_9340},
{"f_9195eval.scm",(void*)f_9195},
{"f_9198eval.scm",(void*)f_9198},
{"f_9213eval.scm",(void*)f_9213},
{"f_9231eval.scm",(void*)f_9231},
{"f_9294eval.scm",(void*)f_9294},
{"f_9247eval.scm",(void*)f_9247},
{"f_9252eval.scm",(void*)f_9252},
{"f_9256eval.scm",(void*)f_9256},
{"f_9259eval.scm",(void*)f_9259},
{"f_9271eval.scm",(void*)f_9271},
{"f_9274eval.scm",(void*)f_9274},
{"f_9262eval.scm",(void*)f_9262},
{"f_9235eval.scm",(void*)f_9235},
{"f_9217eval.scm",(void*)f_9217},
{"f_9063eval.scm",(void*)f_9063},
{"f_9068eval.scm",(void*)f_9068},
{"f_9220eval.scm",(void*)f_9220},
{"f_9204eval.scm",(void*)f_9204},
{"f_9102eval.scm",(void*)f_9102},
{"f_9107eval.scm",(void*)f_9107},
{"f_9110eval.scm",(void*)f_9110},
{"f_9115eval.scm",(void*)f_9115},
{"f_9122eval.scm",(void*)f_9122},
{"f_9162eval.scm",(void*)f_9162},
{"f_9125eval.scm",(void*)f_9125},
{"f_9137eval.scm",(void*)f_9137},
{"f_9146eval.scm",(void*)f_9146},
{"f_9140eval.scm",(void*)f_9140},
{"f_9128eval.scm",(void*)f_9128},
{"f_9131eval.scm",(void*)f_9131},
{"f_9093eval.scm",(void*)f_9093},
{"f_9087eval.scm",(void*)f_9087},
{"f_9041eval.scm",(void*)f_9041},
{"f_9047eval.scm",(void*)f_9047},
{"f_9035eval.scm",(void*)f_9035},
{"f_9019eval.scm",(void*)f_9019},
{"f_9033eval.scm",(void*)f_9033},
{"f_9030eval.scm",(void*)f_9030},
{"f_9023eval.scm",(void*)f_9023},
{"f_9000eval.scm",(void*)f_9000},
{"f_9009eval.scm",(void*)f_9009},
{"f_9004eval.scm",(void*)f_9004},
{"f_8569eval.scm",(void*)f_8569},
{"f_8706eval.scm",(void*)f_8706},
{"f_8711eval.scm",(void*)f_8711},
{"f_8929eval.scm",(void*)f_8929},
{"f_8910eval.scm",(void*)f_8910},
{"f_8856eval.scm",(void*)f_8856},
{"f_8727eval.scm",(void*)f_8727},
{"f_8732eval.scm",(void*)f_8732},
{"f_8751eval.scm",(void*)f_8751},
{"f_8677eval.scm",(void*)f_8677},
{"f_8683eval.scm",(void*)f_8683},
{"f_8615eval.scm",(void*)f_8615},
{"f_8619eval.scm",(void*)f_8619},
{"f_8627eval.scm",(void*)f_8627},
{"f_8650eval.scm",(void*)f_8650},
{"f_8572eval.scm",(void*)f_8572},
{"f_8579eval.scm",(void*)f_8579},
{"f_8584eval.scm",(void*)f_8584},
{"f_8588eval.scm",(void*)f_8588},
{"f_8613eval.scm",(void*)f_8613},
{"f_8602eval.scm",(void*)f_8602},
{"f_8606eval.scm",(void*)f_8606},
{"f_8595eval.scm",(void*)f_8595},
{"f_8533eval.scm",(void*)f_8533},
{"f_8555eval.scm",(void*)f_8555},
{"f_8525eval.scm",(void*)f_8525},
{"f_8471eval.scm",(void*)f_8471},
{"f_8475eval.scm",(void*)f_8475},
{"f_8478eval.scm",(void*)f_8478},
{"f_8481eval.scm",(void*)f_8481},
{"f_8484eval.scm",(void*)f_8484},
{"f_8487eval.scm",(void*)f_8487},
{"f_8490eval.scm",(void*)f_8490},
{"f_8493eval.scm",(void*)f_8493},
{"f_8496eval.scm",(void*)f_8496},
{"f_8499eval.scm",(void*)f_8499},
{"f_8450eval.scm",(void*)f_8450},
{"f_8454eval.scm",(void*)f_8454},
{"f_8457eval.scm",(void*)f_8457},
{"f_8426eval.scm",(void*)f_8426},
{"f_8432eval.scm",(void*)f_8432},
{"f_8442eval.scm",(void*)f_8442},
{"f_8303eval.scm",(void*)f_8303},
{"f_8361eval.scm",(void*)f_8361},
{"f_8412eval.scm",(void*)f_8412},
{"f_8371eval.scm",(void*)f_8371},
{"f_8373eval.scm",(void*)f_8373},
{"f_8397eval.scm",(void*)f_8397},
{"f_8383eval.scm",(void*)f_8383},
{"f_8344eval.scm",(void*)f_8344},
{"f_8309eval.scm",(void*)f_8309},
{"f_8325eval.scm",(void*)f_8325},
{"f_8331eval.scm",(void*)f_8331},
{"f_8322eval.scm",(void*)f_8322},
{"f_8284eval.scm",(void*)f_8284},
{"f_8288eval.scm",(void*)f_8288},
{"f_8251eval.scm",(void*)f_8251},
{"f_8253eval.scm",(void*)f_8253},
{"f_8257eval.scm",(void*)f_8257},
{"f_8213eval.scm",(void*)f_8213},
{"f_8220eval.scm",(void*)f_8220},
{"f_8227eval.scm",(void*)f_8227},
{"f_8169eval.scm",(void*)f_8169},
{"f_8202eval.scm",(void*)f_8202},
{"f_8189eval.scm",(void*)f_8189},
{"f_8166eval.scm",(void*)f_8166},
{"f_8047eval.scm",(void*)f_8047},
{"f_8141eval.scm",(void*)f_8141},
{"f_8151eval.scm",(void*)f_8151},
{"f_8139eval.scm",(void*)f_8139},
{"f_8068eval.scm",(void*)f_8068},
{"f_8092eval.scm",(void*)f_8092},
{"f_8111eval.scm",(void*)f_8111},
{"f_8086eval.scm",(void*)f_8086},
{"f_7939eval.scm",(void*)f_7939},
{"f_7949eval.scm",(void*)f_7949},
{"f_7954eval.scm",(void*)f_7954},
{"f_7981eval.scm",(void*)f_7981},
{"f_8014eval.scm",(void*)f_8014},
{"f_7975eval.scm",(void*)f_7975},
{"f_7876eval.scm",(void*)f_7876},
{"f_7880eval.scm",(void*)f_7880},
{"f_7888eval.scm",(void*)f_7888},
{"f_7908eval.scm",(void*)f_7908},
{"f_7832eval.scm",(void*)f_7832},
{"f_7864eval.scm",(void*)f_7864},
{"f_7850eval.scm",(void*)f_7850},
{"f_7433eval.scm",(void*)f_7433},
{"f_7708eval.scm",(void*)f_7708},
{"f_7717eval.scm",(void*)f_7717},
{"f_7743eval.scm",(void*)f_7743},
{"f_7745eval.scm",(void*)f_7745},
{"f_7778eval.scm",(void*)f_7778},
{"f_7768eval.scm",(void*)f_7768},
{"f_7763eval.scm",(void*)f_7763},
{"f_7457eval.scm",(void*)f_7457},
{"f_7467eval.scm",(void*)f_7467},
{"f_7601eval.scm",(void*)f_7601},
{"f_7682eval.scm",(void*)f_7682},
{"f_7613eval.scm",(void*)f_7613},
{"f_7628eval.scm",(void*)f_7628},
{"f_7648eval.scm",(void*)f_7648},
{"f_7646eval.scm",(void*)f_7646},
{"f_7632eval.scm",(void*)f_7632},
{"f_7624eval.scm",(void*)f_7624},
{"f_7543eval.scm",(void*)f_7543},
{"f_7561eval.scm",(void*)f_7561},
{"f_7569eval.scm",(void*)f_7569},
{"f_7557eval.scm",(void*)f_7557},
{"f_7516eval.scm",(void*)f_7516},
{"f_7479eval.scm",(void*)f_7479},
{"f_7503eval.scm",(void*)f_7503},
{"f_7499eval.scm",(void*)f_7499},
{"f_7491eval.scm",(void*)f_7491},
{"f_7482eval.scm",(void*)f_7482},
{"f_7436eval.scm",(void*)f_7436},
{"f_7451eval.scm",(void*)f_7451},
{"f_7445eval.scm",(void*)f_7445},
{"f_7384eval.scm",(void*)f_7384},
{"f_7390eval.scm",(void*)f_7390},
{"f_7404eval.scm",(void*)f_7404},
{"f_7407eval.scm",(void*)f_7407},
{"f_7414eval.scm",(void*)f_7414},
{"f_7378eval.scm",(void*)f_7378},
{"f_7347eval.scm",(void*)f_7347},
{"f_7351eval.scm",(void*)f_7351},
{"f_7376eval.scm",(void*)f_7376},
{"f_7354eval.scm",(void*)f_7354},
{"f_7372eval.scm",(void*)f_7372},
{"f_7357eval.scm",(void*)f_7357},
{"f_7364eval.scm",(void*)f_7364},
{"f_7334eval.scm",(void*)f_7334},
{"f_7340eval.scm",(void*)f_7340},
{"f_7320eval.scm",(void*)f_7320},
{"f_7331eval.scm",(void*)f_7331},
{"f_7300eval.scm",(void*)f_7300},
{"f_7306eval.scm",(void*)f_7306},
{"f_7313eval.scm",(void*)f_7313},
{"f_7232eval.scm",(void*)f_7232},
{"f_7295eval.scm",(void*)f_7295},
{"f_7236eval.scm",(void*)f_7236},
{"f_7239eval.scm",(void*)f_7239},
{"f_7257eval.scm",(void*)f_7257},
{"f_7263eval.scm",(void*)f_7263},
{"f_7155eval.scm",(void*)f_7155},
{"f_7229eval.scm",(void*)f_7229},
{"f_7222eval.scm",(void*)f_7222},
{"f_7189eval.scm",(void*)f_7189},
{"f_7191eval.scm",(void*)f_7191},
{"f_7204eval.scm",(void*)f_7204},
{"f_7158eval.scm",(void*)f_7158},
{"f_7162eval.scm",(void*)f_7162},
{"f_7182eval.scm",(void*)f_7182},
{"f_7168eval.scm",(void*)f_7168},
{"f_7178eval.scm",(void*)f_7178},
{"f_7171eval.scm",(void*)f_7171},
{"f_6992eval.scm",(void*)f_6992},
{"f_7097eval.scm",(void*)f_7097},
{"f_7114eval.scm",(void*)f_7114},
{"f_7122eval.scm",(void*)f_7122},
{"f_7014eval.scm",(void*)f_7014},
{"f_7019eval.scm",(void*)f_7019},
{"f_7058eval.scm",(void*)f_7058},
{"f_7045eval.scm",(void*)f_7045},
{"f_7001eval.scm",(void*)f_7001},
{"f_6995eval.scm",(void*)f_6995},
{"f_6936eval.scm",(void*)f_6936},
{"f_6945eval.scm",(void*)f_6945},
{"f_6983eval.scm",(void*)f_6983},
{"f_6963eval.scm",(void*)f_6963},
{"f_6907eval.scm",(void*)f_6907},
{"f_6914eval.scm",(void*)f_6914},
{"f_6924eval.scm",(void*)f_6924},
{"f_6801eval.scm",(void*)f_6801},
{"f_6805eval.scm",(void*)f_6805},
{"f_6897eval.scm",(void*)f_6897},
{"f_6901eval.scm",(void*)f_6901},
{"f_6814eval.scm",(void*)f_6814},
{"f_6883eval.scm",(void*)f_6883},
{"f_6879eval.scm",(void*)f_6879},
{"f_6817eval.scm",(void*)f_6817},
{"f_6866eval.scm",(void*)f_6866},
{"f_6869eval.scm",(void*)f_6869},
{"f_6872eval.scm",(void*)f_6872},
{"f_6820eval.scm",(void*)f_6820},
{"f_6825eval.scm",(void*)f_6825},
{"f_6859eval.scm",(void*)f_6859},
{"f_6838eval.scm",(void*)f_6838},
{"f_6841eval.scm",(void*)f_6841},
{"f_6761eval.scm",(void*)f_6761},
{"f_6782eval.scm",(void*)f_6782},
{"f_6765eval.scm",(void*)f_6765},
{"f_6779eval.scm",(void*)f_6779},
{"f_6768eval.scm",(void*)f_6768},
{"f_6776eval.scm",(void*)f_6776},
{"f_6771eval.scm",(void*)f_6771},
{"f_6725eval.scm",(void*)f_6725},
{"f_6733eval.scm",(void*)f_6733},
{"f_6703eval.scm",(void*)f_6703},
{"f_6316eval.scm",(void*)f_6316},
{"f_6658eval.scm",(void*)f_6658},
{"f_6653eval.scm",(void*)f_6653},
{"f_6318eval.scm",(void*)f_6318},
{"f_6652eval.scm",(void*)f_6652},
{"f_6322eval.scm",(void*)f_6322},
{"f_6586eval.scm",(void*)f_6586},
{"f_6601eval.scm",(void*)f_6601},
{"f_6604eval.scm",(void*)f_6604},
{"f_6607eval.scm",(void*)f_6607},
{"f_6613eval.scm",(void*)f_6613},
{"f_6616eval.scm",(void*)f_6616},
{"f_6622eval.scm",(void*)f_6622},
{"f_6325eval.scm",(void*)f_6325},
{"f_6577eval.scm",(void*)f_6577},
{"f_6568eval.scm",(void*)f_6568},
{"f_6571eval.scm",(void*)f_6571},
{"f_6331eval.scm",(void*)f_6331},
{"f_6553eval.scm",(void*)f_6553},
{"f_6525eval.scm",(void*)f_6525},
{"f_6549eval.scm",(void*)f_6549},
{"f_6545eval.scm",(void*)f_6545},
{"f_6541eval.scm",(void*)f_6541},
{"f_6334eval.scm",(void*)f_6334},
{"f_6342eval.scm",(void*)f_6342},
{"f_6512eval.scm",(void*)f_6512},
{"f_6346eval.scm",(void*)f_6346},
{"f_6497eval.scm",(void*)f_6497},
{"f_6370eval.scm",(void*)f_6370},
{"f_6374eval.scm",(void*)f_6374},
{"f_6488eval.scm",(void*)f_6488},
{"f_6382eval.scm",(void*)f_6382},
{"f_6386eval.scm",(void*)f_6386},
{"f_6482eval.scm",(void*)f_6482},
{"f_6389eval.scm",(void*)f_6389},
{"f_6392eval.scm",(void*)f_6392},
{"f_6397eval.scm",(void*)f_6397},
{"f_6407eval.scm",(void*)f_6407},
{"f_6453eval.scm",(void*)f_6453},
{"f_6462eval.scm",(void*)f_6462},
{"f_6466eval.scm",(void*)f_6466},
{"f_6419eval.scm",(void*)f_6419},
{"f_6426eval.scm",(void*)f_6426},
{"f_6437eval.scm",(void*)f_6437},
{"f_6448eval.scm",(void*)f_6448},
{"f_6441eval.scm",(void*)f_6441},
{"f_6431eval.scm",(void*)f_6431},
{"f_6410eval.scm",(void*)f_6410},
{"f_6417eval.scm",(void*)f_6417},
{"f_6379eval.scm",(void*)f_6379},
{"f_6356eval.scm",(void*)f_6356},
{"f_6347eval.scm",(void*)f_6347},
{"f_6337eval.scm",(void*)f_6337},
{"f_6270eval.scm",(void*)f_6270},
{"f_6280eval.scm",(void*)f_6280},
{"f_6195eval.scm",(void*)f_6195},
{"f_6207eval.scm",(void*)f_6207},
{"f_6220eval.scm",(void*)f_6220},
{"f_6202eval.scm",(void*)f_6202},
{"f_6190eval.scm",(void*)f_6190},
{"f_6106eval.scm",(void*)f_6106},
{"f_6119eval.scm",(void*)f_6119},
{"f_6152eval.scm",(void*)f_6152},
{"f_6133eval.scm",(void*)f_6133},
{"f_6109eval.scm",(void*)f_6109},
{"f_6092eval.scm",(void*)f_6092},
{"f_6100eval.scm",(void*)f_6100},
{"f_6104eval.scm",(void*)f_6104},
{"f_3832eval.scm",(void*)f_3832},
{"f_5837eval.scm",(void*)f_5837},
{"f_5841eval.scm",(void*)f_5841},
{"f_6054eval.scm",(void*)f_6054},
{"f_6030eval.scm",(void*)f_6030},
{"f_6031eval.scm",(void*)f_6031},
{"f_6042eval.scm",(void*)f_6042},
{"f_6048eval.scm",(void*)f_6048},
{"f_6046eval.scm",(void*)f_6046},
{"f_5987eval.scm",(void*)f_5987},
{"f_5990eval.scm",(void*)f_5990},
{"f_5993eval.scm",(void*)f_5993},
{"f_5996eval.scm",(void*)f_5996},
{"f_5997eval.scm",(void*)f_5997},
{"f_6008eval.scm",(void*)f_6008},
{"f_6012eval.scm",(void*)f_6012},
{"f_6016eval.scm",(void*)f_6016},
{"f_6020eval.scm",(void*)f_6020},
{"f_6023eval.scm",(void*)f_6023},
{"f_5945eval.scm",(void*)f_5945},
{"f_5948eval.scm",(void*)f_5948},
{"f_5951eval.scm",(void*)f_5951},
{"f_5952eval.scm",(void*)f_5952},
{"f_5963eval.scm",(void*)f_5963},
{"f_5967eval.scm",(void*)f_5967},
{"f_5971eval.scm",(void*)f_5971},
{"f_5974eval.scm",(void*)f_5974},
{"f_5910eval.scm",(void*)f_5910},
{"f_5913eval.scm",(void*)f_5913},
{"f_5914eval.scm",(void*)f_5914},
{"f_5925eval.scm",(void*)f_5925},
{"f_5929eval.scm",(void*)f_5929},
{"f_5932eval.scm",(void*)f_5932},
{"f_5882eval.scm",(void*)f_5882},
{"f_5883eval.scm",(void*)f_5883},
{"f_5894eval.scm",(void*)f_5894},
{"f_5897eval.scm",(void*)f_5897},
{"f_5863eval.scm",(void*)f_5863},
{"f_5873eval.scm",(void*)f_5873},
{"f_5811eval.scm",(void*)f_5811},
{"f_4060eval.scm",(void*)f_4060},
{"f_4171eval.scm",(void*)f_4171},
{"f_4227eval.scm",(void*)f_4227},
{"f_4256eval.scm",(void*)f_4256},
{"f_4262eval.scm",(void*)f_4262},
{"f_5631eval.scm",(void*)f_5631},
{"f_5618eval.scm",(void*)f_5618},
{"f_5579eval.scm",(void*)f_5579},
{"f_5568eval.scm",(void*)f_5568},
{"f_5530eval.scm",(void*)f_5530},
{"f_5524eval.scm",(void*)f_5524},
{"f_5478eval.scm",(void*)f_5478},
{"f_5500eval.scm",(void*)f_5500},
{"f_5508eval.scm",(void*)f_5508},
{"f_5490eval.scm",(void*)f_5490},
{"f_5472eval.scm",(void*)f_5472},
{"f_5448eval.scm",(void*)f_5448},
{"f_5455eval.scm",(void*)f_5455},
{"f_5417eval.scm",(void*)f_5417},
{"f_5420eval.scm",(void*)f_5420},
{"f_5423eval.scm",(void*)f_5423},
{"f_5442eval.scm",(void*)f_5442},
{"f_5440eval.scm",(void*)f_5440},
{"f_5430eval.scm",(void*)f_5430},
{"f_5015eval.scm",(void*)f_5015},
{"f_5352eval.scm",(void*)f_5352},
{"f_5363eval.scm",(void*)f_5363},
{"f_5357eval.scm",(void*)f_5357},
{"f_5027eval.scm",(void*)f_5027},
{"f_5032eval.scm",(void*)f_5032},
{"f_5341eval.scm",(void*)f_5341},
{"f_5335eval.scm",(void*)f_5335},
{"f_5039eval.scm",(void*)f_5039},
{"f_5297eval.scm",(void*)f_5297},
{"f_5303eval.scm",(void*)f_5303},
{"f_5327eval.scm",(void*)f_5327},
{"f_5274eval.scm",(void*)f_5274},
{"f_5280eval.scm",(void*)f_5280},
{"f_5765eval.scm",(void*)f_5765},
{"f_5794eval.scm",(void*)f_5794},
{"f_5296eval.scm",(void*)f_5296},
{"f_5292eval.scm",(void*)f_5292},
{"f_5252eval.scm",(void*)f_5252},
{"f_5258eval.scm",(void*)f_5258},
{"f_5270eval.scm",(void*)f_5270},
{"f_5233eval.scm",(void*)f_5233},
{"f_5239eval.scm",(void*)f_5239},
{"f_5205eval.scm",(void*)f_5205},
{"f_5211eval.scm",(void*)f_5211},
{"f_5186eval.scm",(void*)f_5186},
{"f_5192eval.scm",(void*)f_5192},
{"f_5158eval.scm",(void*)f_5158},
{"f_5164eval.scm",(void*)f_5164},
{"f_5139eval.scm",(void*)f_5139},
{"f_5145eval.scm",(void*)f_5145},
{"f_5111eval.scm",(void*)f_5111},
{"f_5117eval.scm",(void*)f_5117},
{"f_5092eval.scm",(void*)f_5092},
{"f_5098eval.scm",(void*)f_5098},
{"f_5068eval.scm",(void*)f_5068},
{"f_5074eval.scm",(void*)f_5074},
{"f_5049eval.scm",(void*)f_5049},
{"f_5055eval.scm",(void*)f_5055},
{"f_4677eval.scm",(void*)f_4677},
{"f_5002eval.scm",(void*)f_5002},
{"f_4686eval.scm",(void*)f_4686},
{"f_4996eval.scm",(void*)f_4996},
{"f_4990eval.scm",(void*)f_4990},
{"f_4692eval.scm",(void*)f_4692},
{"f_4974eval.scm",(void*)f_4974},
{"f_4927eval.scm",(void*)f_4927},
{"f_4928eval.scm",(void*)f_4928},
{"f_4932eval.scm",(void*)f_4932},
{"f_4944eval.scm",(void*)f_4944},
{"f_4969eval.scm",(void*)f_4969},
{"f_4935eval.scm",(void*)f_4935},
{"f_4851eval.scm",(void*)f_4851},
{"f_4912eval.scm",(void*)f_4912},
{"f_4854eval.scm",(void*)f_4854},
{"f_4860eval.scm",(void*)f_4860},
{"f_4896eval.scm",(void*)f_4896},
{"f_4863eval.scm",(void*)f_4863},
{"f_4864eval.scm",(void*)f_4864},
{"f_4880eval.scm",(void*)f_4880},
{"f_4884eval.scm",(void*)f_4884},
{"f_4888eval.scm",(void*)f_4888},
{"f_4892eval.scm",(void*)f_4892},
{"f_4784eval.scm",(void*)f_4784},
{"f_4830eval.scm",(void*)f_4830},
{"f_4787eval.scm",(void*)f_4787},
{"f_4793eval.scm",(void*)f_4793},
{"f_4794eval.scm",(void*)f_4794},
{"f_4810eval.scm",(void*)f_4810},
{"f_4814eval.scm",(void*)f_4814},
{"f_4818eval.scm",(void*)f_4818},
{"f_4735eval.scm",(void*)f_4735},
{"f_4763eval.scm",(void*)f_4763},
{"f_4738eval.scm",(void*)f_4738},
{"f_4739eval.scm",(void*)f_4739},
{"f_4755eval.scm",(void*)f_4755},
{"f_4759eval.scm",(void*)f_4759},
{"f_4701eval.scm",(void*)f_4701},
{"f_4702eval.scm",(void*)f_4702},
{"f_4718eval.scm",(void*)f_4718},
{"f_4568eval.scm",(void*)f_4568},
{"f_4582eval.scm",(void*)f_4582},
{"f_4586eval.scm",(void*)f_4586},
{"f_4595eval.scm",(void*)f_4595},
{"f_4628eval.scm",(void*)f_4628},
{"f_4636eval.scm",(void*)f_4636},
{"f_4601eval.scm",(void*)f_4601},
{"f_4604eval.scm",(void*)f_4604},
{"f_4620eval.scm",(void*)f_4620},
{"f_4611eval.scm",(void*)f_4611},
{"f_4619eval.scm",(void*)f_4619},
{"f_4656eval.scm",(void*)f_4656},
{"f_4664eval.scm",(void*)f_4664},
{"f_4643eval.scm",(void*)f_4643},
{"f_4655eval.scm",(void*)f_4655},
{"f_4576eval.scm",(void*)f_4576},
{"f_4460eval.scm",(void*)f_4460},
{"f_4519eval.scm",(void*)f_4519},
{"f_4522eval.scm",(void*)f_4522},
{"f_4525eval.scm",(void*)f_4525},
{"f_4526eval.scm",(void*)f_4526},
{"f_4530eval.scm",(void*)f_4530},
{"f_4533eval.scm",(void*)f_4533},
{"f_4497eval.scm",(void*)f_4497},
{"f_4500eval.scm",(void*)f_4500},
{"f_4501eval.scm",(void*)f_4501},
{"f_4505eval.scm",(void*)f_4505},
{"f_4403eval.scm",(void*)f_4403},
{"f_4406eval.scm",(void*)f_4406},
{"f_4409eval.scm",(void*)f_4409},
{"f_4412eval.scm",(void*)f_4412},
{"f_4413eval.scm",(void*)f_4413},
{"f_4420eval.scm",(void*)f_4420},
{"f_4393eval.scm",(void*)f_4393},
{"f_4359eval.scm",(void*)f_4359},
{"f_4353eval.scm",(void*)f_4353},
{"f_4354eval.scm",(void*)f_4354},
{"f_4277eval.scm",(void*)f_4277},
{"f_4337eval.scm",(void*)f_4337},
{"f_4335eval.scm",(void*)f_4335},
{"f_4327eval.scm",(void*)f_4327},
{"f_4319eval.scm",(void*)f_4319},
{"f_4311eval.scm",(void*)f_4311},
{"f_4303eval.scm",(void*)f_4303},
{"f_4295eval.scm",(void*)f_4295},
{"f_4287eval.scm",(void*)f_4287},
{"f_4228eval.scm",(void*)f_4228},
{"f_4217eval.scm",(void*)f_4217},
{"f_4215eval.scm",(void*)f_4215},
{"f_4204eval.scm",(void*)f_4204},
{"f_4202eval.scm",(void*)f_4202},
{"f_4194eval.scm",(void*)f_4194},
{"f_4186eval.scm",(void*)f_4186},
{"f_4178eval.scm",(void*)f_4178},
{"f_4073eval.scm",(void*)f_4073},
{"f_4086eval.scm",(void*)f_4086},
{"f_4096eval.scm",(void*)f_4096},
{"f_4145eval.scm",(void*)f_4145},
{"f_4130eval.scm",(void*)f_4130},
{"f_4125eval.scm",(void*)f_4125},
{"f_4126eval.scm",(void*)f_4126},
{"f_4102eval.scm",(void*)f_4102},
{"f_4105eval.scm",(void*)f_4105},
{"f_4106eval.scm",(void*)f_4106},
{"f_4161eval.scm",(void*)f_4161},
{"f_4152eval.scm",(void*)f_4152},
{"f_4080eval.scm",(void*)f_4080},
{"f_4074eval.scm",(void*)f_4074},
{"f_4054eval.scm",(void*)f_4054},
{"f_4048eval.scm",(void*)f_4048},
{"f_4042eval.scm",(void*)f_4042},
{"f_3989eval.scm",(void*)f_3989},
{"f_3993eval.scm",(void*)f_3993},
{"f_4040eval.scm",(void*)f_4040},
{"f_4008eval.scm",(void*)f_4008},
{"f_4017eval.scm",(void*)f_4017},
{"f_3877eval.scm",(void*)f_3877},
{"f_3889eval.scm",(void*)f_3889},
{"f_3883eval.scm",(void*)f_3883},
{"f_3835eval.scm",(void*)f_3835},
{"f_3841eval.scm",(void*)f_3841},
{"f_3959eval.scm",(void*)f_3959},
{"f_3826eval.scm",(void*)f_3826},
{"f_3785eval.scm",(void*)f_3785},
{"f_3804eval.scm",(void*)f_3804},
{"f_3816eval.scm",(void*)f_3816},
{"f_3819eval.scm",(void*)f_3819},
{"f_3822eval.scm",(void*)f_3822},
{"f_3812eval.scm",(void*)f_3812},
{"f_3791eval.scm",(void*)f_3791},
{"f_3725eval.scm",(void*)f_3725},
{"f_3729eval.scm",(void*)f_3729},
{"f_3737eval.scm",(void*)f_3737},
{"f_3658eval.scm",(void*)f_3658},
{"f_3664eval.scm",(void*)f_3664},
{"f_3680eval.scm",(void*)f_3680},
{"f_3615eval.scm",(void*)f_3615},
{"f_3621eval.scm",(void*)f_3621},
{"f_3640eval.scm",(void*)f_3640},
{"f_3631eval.scm",(void*)f_3631},
{"f_3595eval.scm",(void*)f_3595},
{"f_3607eval.scm",(void*)f_3607},
{"f_3610eval.scm",(void*)f_3610},
{"f_3603eval.scm",(void*)f_3603},
{"f_3540eval.scm",(void*)f_3540},
{"f_3544eval.scm",(void*)f_3544},
{"f_3552eval.scm",(void*)f_3552},
{"f_3495eval.scm",(void*)f_3495},
{"f_3499eval.scm",(void*)f_3499},
{"f_3508eval.scm",(void*)f_3508},
{"f_3480eval.scm",(void*)f_3480},
{"f_3420eval.scm",(void*)f_3420},
{"f_3475eval.scm",(void*)f_3475},
{"f_3423eval.scm",(void*)f_3423},
{"f_3329eval.scm",(void*)f_3329},
{"f_3418eval.scm",(void*)f_3418},
{"f_3332eval.scm",(void*)f_3332},
{"f_3387eval.scm",(void*)f_3387},
{"f_2846eval.scm",(void*)f_2846},
{"f_3284eval.scm",(void*)f_3284},
{"f_3279eval.scm",(void*)f_3279},
{"f_2848eval.scm",(void*)f_2848},
{"f_3031eval.scm",(void*)f_3031},
{"f_3037eval.scm",(void*)f_3037},
{"f_3071eval.scm",(void*)f_3071},
{"f_3243eval.scm",(void*)f_3243},
{"f_3229eval.scm",(void*)f_3229},
{"f_3236eval.scm",(void*)f_3236},
{"f_3201eval.scm",(void*)f_3201},
{"f_3083eval.scm",(void*)f_3083},
{"f_3088eval.scm",(void*)f_3088},
{"f_3101eval.scm",(void*)f_3101},
{"f_3153eval.scm",(void*)f_3153},
{"f_3135eval.scm",(void*)f_3135},
{"f_3146eval.scm",(void*)f_3146},
{"f_2851eval.scm",(void*)f_2851},
{"f_2933eval.scm",(void*)f_2933},
{"f_3023eval.scm",(void*)f_3023},
{"f_3011eval.scm",(void*)f_3011},
{"f_2944eval.scm",(void*)f_2944},
{"f_3009eval.scm",(void*)f_3009},
{"f_3001eval.scm",(void*)f_3001},
{"f_2952eval.scm",(void*)f_2952},
{"f_2995eval.scm",(void*)f_2995},
{"f_2999eval.scm",(void*)f_2999},
{"f_2962eval.scm",(void*)f_2962},
{"f_2966eval.scm",(void*)f_2966},
{"f_2987eval.scm",(void*)f_2987},
{"f_2985eval.scm",(void*)f_2985},
{"f_2960eval.scm",(void*)f_2960},
{"f_2956eval.scm",(void*)f_2956},
{"f_2948eval.scm",(void*)f_2948},
{"f_2863eval.scm",(void*)f_2863},
{"f_2882eval.scm",(void*)f_2882},
{"f_2893eval.scm",(void*)f_2893},
{"f_2901eval.scm",(void*)f_2901},
{"f_2889eval.scm",(void*)f_2889},
{"f_2327eval.scm",(void*)f_2327},
{"f_2349eval.scm",(void*)f_2349},
{"f_2789eval.scm",(void*)f_2789},
{"f_2727eval.scm",(void*)f_2727},
{"f_2708eval.scm",(void*)f_2708},
{"f_2662eval.scm",(void*)f_2662},
{"f_2665eval.scm",(void*)f_2665},
{"f_2644eval.scm",(void*)f_2644},
{"f_2625eval.scm",(void*)f_2625},
{"f_2593eval.scm",(void*)f_2593},
{"f_2572eval.scm",(void*)f_2572},
{"f_2363eval.scm",(void*)f_2363},
{"f_2565eval.scm",(void*)f_2565},
{"f_2508eval.scm",(void*)f_2508},
{"f_2561eval.scm",(void*)f_2561},
{"f_2535eval.scm",(void*)f_2535},
{"f_2506eval.scm",(void*)f_2506},
{"f_2367eval.scm",(void*)f_2367},
{"f_2379eval.scm",(void*)f_2379},
{"f_2458eval.scm",(void*)f_2458},
{"f_2454eval.scm",(void*)f_2454},
{"f_2435eval.scm",(void*)f_2435},
{"f_2370eval.scm",(void*)f_2370},
{"f_2330eval.scm",(void*)f_2330},
{"f_2284eval.scm",(void*)f_2284},
{"f_2290eval.scm",(void*)f_2290},
{"f_2309eval.scm",(void*)f_2309},
{"f_2268eval.scm",(void*)f_2268},
{"f_2232eval.scm",(void*)f_2232},
{"f_2241eval.scm",(void*)f_2241},
{"f_2253eval.scm",(void*)f_2253},
{"f_2247eval.scm",(void*)f_2247},
{"f_2225eval.scm",(void*)f_2225},
{"f_2222eval.scm",(void*)f_2222},
{"f_2219eval.scm",(void*)f_2219},
{"f_1849eval.scm",(void*)f_1849},
{"f_2159eval.scm",(void*)f_2159},
{"f_2165eval.scm",(void*)f_2165},
{"f_2172eval.scm",(void*)f_2172},
{"f_2086eval.scm",(void*)f_2086},
{"f_2098eval.scm",(void*)f_2098},
{"f_2146eval.scm",(void*)f_2146},
{"f_2140eval.scm",(void*)f_2140},
{"f_2120eval.scm",(void*)f_2120},
{"f_1998eval.scm",(void*)f_1998},
{"f_2018eval.scm",(void*)f_2018},
{"f_2026eval.scm",(void*)f_2026},
{"f_2040eval.scm",(void*)f_2040},
{"f_2012eval.scm",(void*)f_2012},
{"f_1852eval.scm",(void*)f_1852},
{"f_1861eval.scm",(void*)f_1861},
{"f_1974eval.scm",(void*)f_1974},
{"f_1986eval.scm",(void*)f_1986},
{"f_1992eval.scm",(void*)f_1992},
{"f_1980eval.scm",(void*)f_1980},
{"f_1867eval.scm",(void*)f_1867},
{"f_1873eval.scm",(void*)f_1873},
{"f_1884eval.scm",(void*)f_1884},
{"f_1901eval.scm",(void*)f_1901},
{"f_1920eval.scm",(void*)f_1920},
{"f_1931eval.scm",(void*)f_1931},
{"f_1895eval.scm",(void*)f_1895},
{"f_1881eval.scm",(void*)f_1881},
{"f_1859eval.scm",(void*)f_1859},
{"f_1840eval.scm",(void*)f_1840},
{"f_1822eval.scm",(void*)f_1822},
{"f_1832eval.scm",(void*)f_1832},
{"f_1812eval.scm",(void*)f_1812},
{"f_1820eval.scm",(void*)f_1820},
{"f_1796eval.scm",(void*)f_1796},
{"f_1802eval.scm",(void*)f_1802},
{"f_1780eval.scm",(void*)f_1780},
{"f_1786eval.scm",(void*)f_1786},
{"f_1764eval.scm",(void*)f_1764},
{"f_1768eval.scm",(void*)f_1768},
{"f_1737eval.scm",(void*)f_1737},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
