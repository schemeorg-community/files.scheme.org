/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:52
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: posixunix.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file uposixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[462];
static double C_possibly_force_alignment;


/* from k8881 in set-root-directory! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub3168(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3168(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from sleep in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub2715(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2715(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub2710(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2710(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub2706(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2706(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub2550(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2550(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k7848 */
static C_word C_fcall stub2541(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2541(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub2535(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2535(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k7840 */
static C_word C_fcall stub2526(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2526(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from f_7825 in k7819 in process-fork in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub2512(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2512(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub2494(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2494(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2408(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2408(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7640 */
static C_word C_fcall stub2379(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2379(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from ttyname */
static C_word C_fcall stub2364(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2364(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from set-alarm! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub2315(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2315(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from ex0 */
static C_word C_fcall stub2306(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2306(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2298(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2298(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub2259(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2259(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub2217(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2217(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub2209(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2209(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub2193(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2193(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7227 */
static C_word C_fcall stub2146(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2146(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k7169 */
static C_word C_fcall stub2107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub2107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from get */
static C_word C_fcall stub2058(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2058(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5861 in k5857 in file-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1471(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1471(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5602 in initialize-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1296(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1296(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from _ensure-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1237(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1237(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from _get-groups */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1231(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1231(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from group-member */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1189(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1189(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a8948 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1137(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1137(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a8966 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1128(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1128(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a8984 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1119(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1119(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a9002 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1110(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1110(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from fd_test in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from fd_set in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from fd_zero in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from fcntl */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from ##sys#file-select-one in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub46(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from ##sys#file-nonblocking! in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub40(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub40(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from strerror */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9077)
static void C_ccall f_9077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9089)
static void C_ccall f_9089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9083)
static void C_ccall f_9083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9027)
static void C_ccall f_9027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9043)
static void C_ccall f_9043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9021)
static void C_ccall f_9021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8985)
static void C_ccall f_8985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8970)
static void C_ccall f_8970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8967)
static void C_ccall f_8967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8952)
static void C_ccall f_8952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8962)
static void C_ccall f_8962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8949)
static void C_ccall f_8949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8928)
static void C_ccall f_8928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8887)
static void C_ccall f_8887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8883)
static void C_ccall f_8883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8812)
static void C_fcall f_8812(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8818)
static void C_ccall f_8818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8807)
static void C_fcall f_8807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8802)
static void C_fcall f_8802(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8637)
static void C_fcall f_8637(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8789)
static void C_ccall f_8789(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8797)
static void C_ccall f_8797(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8644)
static void C_fcall f_8644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_ccall f_8777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8656)
static void C_fcall f_8656(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_ccall f_8764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8690)
static void C_ccall f_8690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8731)
static void C_ccall f_8731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8729)
static void C_ccall f_8729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_ccall f_8715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8719)
static void C_ccall f_8719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8702)
static void C_ccall f_8702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8700)
static void C_ccall f_8700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8590)
static void C_fcall f_8590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8585)
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8580)
static void C_fcall f_8580(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8533)
static void C_fcall f_8533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_fcall f_8528(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8523)
static void C_fcall f_8523(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8460)
static void C_fcall f_8460(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8519)
static void C_ccall f_8519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_ccall f_8484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8495)
static void C_ccall f_8495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8489)
static void C_ccall f_8489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8462)
static void C_fcall f_8462(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8402)
static void C_ccall f_8402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8414)
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8445)
static void C_ccall f_8445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8425)
static void C_ccall f_8425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_ccall f_8441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8429)
static void C_ccall f_8429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8437)
static void C_ccall f_8437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8408)
static void C_ccall f_8408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8391)
static void C_fcall f_8391(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_fcall f_8380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_fcall f_8335(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8339)
static void C_ccall f_8339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8342)
static void C_ccall f_8342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8358)
static void C_ccall f_8358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8365)
static void C_ccall f_8365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8368)
static void C_ccall f_8368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8319)
static C_word C_fcall f_8319(C_word *a,C_word t0);
C_noret_decl(f_8302)
static void C_fcall f_8302(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8288)
static void C_fcall f_8288(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8301)
static void C_ccall f_8301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8268)
static void C_fcall f_8268(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8283)
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_fcall f_8231(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8175)
static void C_ccall f_8175(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8175)
static void C_ccall f_8175r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8160)
static void C_ccall f_8160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_ccall f_8124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8049)
static void C_ccall f_8049(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8049)
static void C_ccall f_8049r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7853)
static void C_ccall f_7853(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7853)
static void C_ccall f_7853r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7987)
static void C_fcall f_7987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7982)
static void C_fcall f_7982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7855)
static void C_fcall f_7855(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7873)
static void C_fcall f_7873(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7919)
static C_word C_fcall f_7919(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7886)
static void C_fcall f_7886(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7911)
static void C_ccall f_7911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static C_word C_fcall f_7845(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7837)
static C_word C_fcall f_7837(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7821)
static void C_ccall f_7821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_ccall f_7825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7696)
static void C_fcall f_7696(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7724)
static void C_ccall f_7724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_fcall f_7733(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7678)
static void C_ccall f_7678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7643)
static void C_ccall f_7643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7628)
static void C_ccall f_7628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7597)
static void C_fcall f_7597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7529)
static void C_ccall f_7529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7466)
static void C_ccall f_7466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7283)
static void C_fcall f_7283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7097)
static void C_fcall f_7097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_fcall f_7109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7127)
static void C_ccall f_7127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6997)
static void C_fcall f_6997(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6929)
static void C_ccall f_6929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_fcall f_6892(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6821)
static void C_fcall f_6821(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6840)
static void C_ccall f_6840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_fcall f_6846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6810)
static void C_ccall f_6810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6806)
static void C_ccall f_6806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6722)
static void C_fcall f_6722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_fcall f_6717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6712)
static void C_fcall f_6712(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6528)
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6656)
static void C_fcall f_6656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6580)
static void C_fcall f_6580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6595)
static void C_ccall f_6595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6605)
static void C_ccall f_6605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6589)
static void C_ccall f_6589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6587)
static void C_ccall f_6587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6534)
static void C_fcall f_6534(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6451)
static void C_fcall f_6451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_fcall f_6446(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6441)
static void C_fcall f_6441(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6436)
static void C_fcall f_6436(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6049)
static void C_fcall f_6049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6315)
static void C_fcall f_6315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6367)
static void C_ccall f_6367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6241)
static void C_fcall f_6241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_fcall f_6243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6091)
static void C_fcall f_6091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_fcall f_6103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6083)
static C_word C_fcall f_6083(C_word t0);
C_noret_decl(f_6060)
static void C_fcall f_6060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6027)
static void C_fcall f_6027(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_fcall f_5932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_fcall f_5895(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5852)
static void C_ccall f_5852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5729)
static void C_fcall f_5729(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_fcall f_5551(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_fcall f_5494(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static C_word C_fcall f_5476(C_word t0);
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5408)
static void C_fcall f_5408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_fcall f_5431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_fcall f_5314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_fcall f_5188(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_fcall f_4880(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_fcall f_4874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static C_word C_fcall f_4862(C_word t0);
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_fcall f_4672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_fcall f_4691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_fcall f_4735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4561)
static void C_fcall f_4561(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_fcall f_4629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_fcall f_4489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static C_word C_fcall f_4478(C_word t0);
C_noret_decl(f_4473)
static void C_fcall f_4473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4360)
static void C_fcall f_4360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_fcall f_4355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4257)
static void C_fcall f_4257(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_fcall f_4288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_fcall f_4310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4093)
static void C_ccall f_4093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_fcall f_3923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_fcall f_3756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_fcall f_3795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_fcall f_3799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static C_word C_fcall f_3729(C_word t0,C_word t1);
C_noret_decl(f_3727)
static C_word C_fcall f_3727(C_word t0,C_word t1);
C_noret_decl(f_3725)
static C_word C_fcall f_3725(C_word t0);
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8812)
static void C_fcall trf_8812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8812(t0,t1);}

C_noret_decl(trf_8807)
static void C_fcall trf_8807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8807(t0,t1,t2);}

C_noret_decl(trf_8802)
static void C_fcall trf_8802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8802(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8802(t0,t1,t2,t3);}

C_noret_decl(trf_8637)
static void C_fcall trf_8637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8637(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8637(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8644)
static void C_fcall trf_8644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8644(t0,t1);}

C_noret_decl(trf_8656)
static void C_fcall trf_8656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8656(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8656(t0,t1,t2,t3);}

C_noret_decl(trf_8590)
static void C_fcall trf_8590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8590(t0,t1);}

C_noret_decl(trf_8585)
static void C_fcall trf_8585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8585(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8585(t0,t1,t2);}

C_noret_decl(trf_8580)
static void C_fcall trf_8580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8580(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8580(t0,t1,t2,t3);}

C_noret_decl(trf_8533)
static void C_fcall trf_8533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8533(t0,t1);}

C_noret_decl(trf_8528)
static void C_fcall trf_8528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8528(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8528(t0,t1,t2);}

C_noret_decl(trf_8523)
static void C_fcall trf_8523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8523(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8523(t0,t1,t2,t3);}

C_noret_decl(trf_8460)
static void C_fcall trf_8460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8460(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8460(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8462)
static void C_fcall trf_8462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8462(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8462(t0,t1,t2);}

C_noret_decl(trf_8391)
static void C_fcall trf_8391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8391(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8391(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8380)
static void C_fcall trf_8380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8380(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8380(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8335)
static void C_fcall trf_8335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8335(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8335(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8302)
static void C_fcall trf_8302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8302(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8302(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8288)
static void C_fcall trf_8288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8288(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8288(t0,t1,t2,t3);}

C_noret_decl(trf_8268)
static void C_fcall trf_8268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8268(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8268(t0,t1,t2);}

C_noret_decl(trf_8231)
static void C_fcall trf_8231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8231(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8231(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7987)
static void C_fcall trf_7987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7987(t0,t1);}

C_noret_decl(trf_7982)
static void C_fcall trf_7982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7982(t0,t1,t2);}

C_noret_decl(trf_7855)
static void C_fcall trf_7855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7855(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7855(t0,t1,t2,t3);}

C_noret_decl(trf_7873)
static void C_fcall trf_7873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7873(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7873(t0,t1,t2,t3);}

C_noret_decl(trf_7886)
static void C_fcall trf_7886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7886(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7886(t0,t1);}

C_noret_decl(trf_7696)
static void C_fcall trf_7696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7696(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7696(t0,t1,t2);}

C_noret_decl(trf_7733)
static void C_fcall trf_7733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7733(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7733(t0,t1,t2);}

C_noret_decl(trf_7597)
static void C_fcall trf_7597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7597(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7597(t0,t1,t2);}

C_noret_decl(trf_7283)
static void C_fcall trf_7283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7283(t0,t1,t2);}

C_noret_decl(trf_7097)
static void C_fcall trf_7097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7097(t0,t1,t2);}

C_noret_decl(trf_7109)
static void C_fcall trf_7109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7109(t0,t1,t2);}

C_noret_decl(trf_6997)
static void C_fcall trf_6997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6997(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6997(t0,t1);}

C_noret_decl(trf_6892)
static void C_fcall trf_6892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6892(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6892(t0,t1,t2,t3);}

C_noret_decl(trf_6821)
static void C_fcall trf_6821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6821(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6821(t0,t1,t2,t3);}

C_noret_decl(trf_6846)
static void C_fcall trf_6846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6846(t0,t1);}

C_noret_decl(trf_6722)
static void C_fcall trf_6722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6722(t0,t1);}

C_noret_decl(trf_6717)
static void C_fcall trf_6717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6717(t0,t1,t2);}

C_noret_decl(trf_6712)
static void C_fcall trf_6712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6712(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6712(t0,t1,t2,t3);}

C_noret_decl(trf_6528)
static void C_fcall trf_6528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6528(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6528(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6656)
static void C_fcall trf_6656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6656(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6656(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6580)
static void C_fcall trf_6580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6580(t0,t1);}

C_noret_decl(trf_6534)
static void C_fcall trf_6534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6534(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6534(t0,t1,t2,t3);}

C_noret_decl(trf_6451)
static void C_fcall trf_6451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6451(t0,t1);}

C_noret_decl(trf_6446)
static void C_fcall trf_6446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6446(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6446(t0,t1,t2);}

C_noret_decl(trf_6441)
static void C_fcall trf_6441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6441(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6441(t0,t1,t2,t3);}

C_noret_decl(trf_6436)
static void C_fcall trf_6436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6436(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6436(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6049)
static void C_fcall trf_6049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6049(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6049(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6315)
static void C_fcall trf_6315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6315(t0,t1,t2);}

C_noret_decl(trf_6241)
static void C_fcall trf_6241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6241(t0,t1);}

C_noret_decl(trf_6243)
static void C_fcall trf_6243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6243(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6243(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6091)
static void C_fcall trf_6091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6091(t0,t1);}

C_noret_decl(trf_6103)
static void C_fcall trf_6103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6103(t0,t1);}

C_noret_decl(trf_6060)
static void C_fcall trf_6060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6060(t0,t1);}

C_noret_decl(trf_6027)
static void C_fcall trf_6027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6027(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6027(t0,t1);}

C_noret_decl(trf_5932)
static void C_fcall trf_5932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5932(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5932(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5895)
static void C_fcall trf_5895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5895(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5895(t0,t1,t2);}

C_noret_decl(trf_5729)
static void C_fcall trf_5729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5729(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5729(t0,t1,t2,t3);}

C_noret_decl(trf_5551)
static void C_fcall trf_5551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5551(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5551(t0,t1,t2,t3);}

C_noret_decl(trf_5494)
static void C_fcall trf_5494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5494(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5494(t0,t1,t2);}

C_noret_decl(trf_5408)
static void C_fcall trf_5408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5408(t0,t1);}

C_noret_decl(trf_5431)
static void C_fcall trf_5431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5431(t0,t1,t2);}

C_noret_decl(trf_5314)
static void C_fcall trf_5314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5314(t0,t1);}

C_noret_decl(trf_5188)
static void C_fcall trf_5188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5188(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5188(t0,t1,t2,t3);}

C_noret_decl(trf_4880)
static void C_fcall trf_4880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4880(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4880(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4874)
static void C_fcall trf_4874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4874(t0,t1);}

C_noret_decl(trf_4672)
static void C_fcall trf_4672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4672(t0,t1);}

C_noret_decl(trf_4691)
static void C_fcall trf_4691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4691(t0,t1);}

C_noret_decl(trf_4735)
static void C_fcall trf_4735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4735(t0,t1);}

C_noret_decl(trf_4561)
static void C_fcall trf_4561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4561(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4561(t0,t1,t2,t3);}

C_noret_decl(trf_4629)
static void C_fcall trf_4629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4629(t0,t1);}

C_noret_decl(trf_4489)
static void C_fcall trf_4489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4489(t0,t1);}

C_noret_decl(trf_4473)
static void C_fcall trf_4473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4473(t0,t1);}

C_noret_decl(trf_4360)
static void C_fcall trf_4360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4360(t0,t1);}

C_noret_decl(trf_4355)
static void C_fcall trf_4355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4355(t0,t1,t2);}

C_noret_decl(trf_4257)
static void C_fcall trf_4257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4257(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4257(t0,t1,t2,t3);}

C_noret_decl(trf_4288)
static void C_fcall trf_4288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4288(t0,t1);}

C_noret_decl(trf_4310)
static void C_fcall trf_4310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4310(t0,t1);}

C_noret_decl(trf_3923)
static void C_fcall trf_3923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3923(t0,t1,t2,t3);}

C_noret_decl(trf_3756)
static void C_fcall trf_3756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3756(t0,t1);}

C_noret_decl(trf_3795)
static void C_fcall trf_3795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3795(t0,t1);}

C_noret_decl(trf_3799)
static void C_fcall trf_3799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3799(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3330)){
C_save(t1);
C_rereclaim2(3330*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,462);
lf[0]=C_h_intern(&lf[0],13,"string-append");
lf[2]=C_h_intern(&lf[2],15,"\003syssignal-hook");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[4]=C_h_intern(&lf[4],17,"\003syspeek-c-string");
lf[5]=C_h_intern(&lf[5],16,"\003sysupdate-errno");
lf[6]=C_h_intern(&lf[6],15,"\003sysposix-error");
lf[7]=C_h_intern(&lf[7],21,"\003sysfile-nonblocking!");
lf[8]=C_h_intern(&lf[8],19,"\003sysfile-select-one");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"fcntl/dupfd");
lf[11]=C_h_intern(&lf[11],11,"fcntl/getfd");
lf[12]=C_h_intern(&lf[12],11,"fcntl/setfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfl");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfl");
lf[15]=C_h_intern(&lf[15],11,"open/rdonly");
lf[16]=C_h_intern(&lf[16],11,"open/wronly");
lf[17]=C_h_intern(&lf[17],9,"open/rdwr");
lf[18]=C_h_intern(&lf[18],9,"open/read");
lf[19]=C_h_intern(&lf[19],10,"open/write");
lf[20]=C_h_intern(&lf[20],10,"open/creat");
lf[21]=C_h_intern(&lf[21],11,"open/append");
lf[22]=C_h_intern(&lf[22],9,"open/excl");
lf[23]=C_h_intern(&lf[23],11,"open/noctty");
lf[24]=C_h_intern(&lf[24],13,"open/nonblock");
lf[25]=C_h_intern(&lf[25],10,"open/trunc");
lf[26]=C_h_intern(&lf[26],9,"open/sync");
lf[27]=C_h_intern(&lf[27],10,"open/fsync");
lf[28]=C_h_intern(&lf[28],11,"open/binary");
lf[29]=C_h_intern(&lf[29],9,"open/text");
lf[30]=C_h_intern(&lf[30],10,"perm/irusr");
lf[31]=C_h_intern(&lf[31],10,"perm/iwusr");
lf[32]=C_h_intern(&lf[32],10,"perm/ixusr");
lf[33]=C_h_intern(&lf[33],10,"perm/irgrp");
lf[34]=C_h_intern(&lf[34],10,"perm/iwgrp");
lf[35]=C_h_intern(&lf[35],10,"perm/ixgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iroth");
lf[37]=C_h_intern(&lf[37],10,"perm/iwoth");
lf[38]=C_h_intern(&lf[38],10,"perm/ixoth");
lf[39]=C_h_intern(&lf[39],10,"perm/irwxu");
lf[40]=C_h_intern(&lf[40],10,"perm/irwxg");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxo");
lf[42]=C_h_intern(&lf[42],10,"perm/isvtx");
lf[43]=C_h_intern(&lf[43],10,"perm/isuid");
lf[44]=C_h_intern(&lf[44],10,"perm/isgid");
lf[45]=C_h_intern(&lf[45],12,"file-control");
lf[46]=C_h_intern(&lf[46],11,"\000file-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[48]=C_h_intern(&lf[48],9,"file-open");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[50]=C_h_intern(&lf[50],17,"\003sysmake-c-string");
lf[51]=C_h_intern(&lf[51],20,"\003sysexpand-home-path");
lf[52]=C_h_intern(&lf[52],10,"file-close");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[54]=C_h_intern(&lf[54],11,"make-string");
lf[55]=C_h_intern(&lf[55],9,"file-read");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[57]=C_h_intern(&lf[57],11,"\000type-error");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[59]=C_h_intern(&lf[59],10,"file-write");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],12,"file-mkstemp");
lf[63]=C_h_intern(&lf[63],13,"\003syssubstring");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[65]=C_h_intern(&lf[65],11,"file-select");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[67]=C_h_intern(&lf[67],12,"\003sysfor-each");
lf[68]=C_h_intern(&lf[68],8,"seek/set");
lf[69]=C_h_intern(&lf[69],8,"seek/end");
lf[70]=C_h_intern(&lf[70],8,"seek/cur");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[74]=C_h_intern(&lf[74],9,"file-stat");
lf[75]=C_h_intern(&lf[75],9,"file-size");
lf[76]=C_h_intern(&lf[76],22,"file-modification-time");
lf[77]=C_h_intern(&lf[77],16,"file-access-time");
lf[78]=C_h_intern(&lf[78],16,"file-change-time");
lf[79]=C_h_intern(&lf[79],10,"file-owner");
lf[80]=C_h_intern(&lf[80],16,"file-permissions");
lf[81]=C_h_intern(&lf[81],13,"regular-file\077");
lf[82]=C_h_intern(&lf[82],14,"symbolic-link\077");
lf[83]=C_h_intern(&lf[83],13,"stat-regular\077");
lf[84]=C_h_intern(&lf[84],15,"stat-directory\077");
lf[85]=C_h_intern(&lf[85],17,"stat-char-device\077");
lf[86]=C_h_intern(&lf[86],18,"stat-block-device\077");
lf[87]=C_h_intern(&lf[87],10,"stat-fifo\077");
lf[88]=C_h_intern(&lf[88],13,"stat-symlink\077");
lf[89]=C_h_intern(&lf[89],12,"stat-socket\077");
lf[90]=C_h_intern(&lf[90],13,"file-position");
lf[91]=C_h_intern(&lf[91],16,"create-directory");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[96]=C_h_intern(&lf[96],12,"file-exists\077");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[98]=C_h_intern(&lf[98],12,"string-split");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[100]=C_h_intern(&lf[100],14,"canonical-path");
lf[101]=C_h_intern(&lf[101],16,"change-directory");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[103]=C_h_intern(&lf[103],16,"delete-directory");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[105]=C_h_intern(&lf[105],10,"string-ref");
lf[106]=C_h_intern(&lf[106],6,"string");
lf[107]=C_h_intern(&lf[107],9,"directory");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[109]=C_h_intern(&lf[109],16,"\003sysmake-pointer");
lf[110]=C_h_intern(&lf[110],17,"current-directory");
lf[111]=C_h_intern(&lf[111],10,"directory\077");
lf[112]=C_h_intern(&lf[112],13,"\003sysfile-info");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[114]=C_h_intern(&lf[114],5,"null\077");
lf[115]=C_h_intern(&lf[115],6,"char=\077");
lf[116]=C_h_intern(&lf[116],8,"string=\077");
lf[117]=C_h_intern(&lf[117],16,"char-alphabetic\077");
lf[118]=C_h_intern(&lf[118],18,"string-intersperse");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[120]=C_h_intern(&lf[120],6,"getenv");
lf[121]=C_h_intern(&lf[121],17,"current-user-name");
lf[122]=C_h_intern(&lf[122],9,"condition");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[124]=C_h_intern(&lf[124],22,"with-exception-handler");
lf[125]=C_h_intern(&lf[125],30,"call-with-current-continuation");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[129]=C_h_intern(&lf[129],7,"reverse");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[140]=C_h_intern(&lf[140],5,"\000text");
lf[141]=C_h_intern(&lf[141],9,"\003syserror");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[144]=C_h_intern(&lf[144],13,"\003sysmake-port");
lf[145]=C_h_intern(&lf[145],21,"\003sysstream-port-class");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[147]=C_h_intern(&lf[147],6,"stream");
lf[148]=C_h_intern(&lf[148],15,"open-input-pipe");
lf[149]=C_h_intern(&lf[149],7,"\000binary");
lf[150]=C_h_intern(&lf[150],16,"open-output-pipe");
lf[151]=C_h_intern(&lf[151],16,"close-input-pipe");
lf[152]=C_h_intern(&lf[152],23,"close-input/output-pipe");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[154]=C_h_intern(&lf[154],14,"\003syscheck-port");
lf[155]=C_h_intern(&lf[155],17,"close-output-pipe");
lf[156]=C_h_intern(&lf[156],20,"call-with-input-pipe");
lf[157]=C_h_intern(&lf[157],21,"call-with-output-pipe");
lf[158]=C_h_intern(&lf[158],20,"with-input-from-pipe");
lf[159]=C_h_intern(&lf[159],18,"\003sysstandard-input");
lf[160]=C_h_intern(&lf[160],19,"with-output-to-pipe");
lf[161]=C_h_intern(&lf[161],19,"\003sysstandard-output");
lf[162]=C_h_intern(&lf[162],11,"create-pipe");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[164]=C_h_intern(&lf[164],11,"signal/term");
lf[165]=C_h_intern(&lf[165],11,"signal/kill");
lf[166]=C_h_intern(&lf[166],10,"signal/int");
lf[167]=C_h_intern(&lf[167],10,"signal/hup");
lf[168]=C_h_intern(&lf[168],10,"signal/fpe");
lf[169]=C_h_intern(&lf[169],10,"signal/ill");
lf[170]=C_h_intern(&lf[170],11,"signal/segv");
lf[171]=C_h_intern(&lf[171],11,"signal/abrt");
lf[172]=C_h_intern(&lf[172],11,"signal/trap");
lf[173]=C_h_intern(&lf[173],11,"signal/quit");
lf[174]=C_h_intern(&lf[174],11,"signal/alrm");
lf[175]=C_h_intern(&lf[175],13,"signal/vtalrm");
lf[176]=C_h_intern(&lf[176],11,"signal/prof");
lf[177]=C_h_intern(&lf[177],9,"signal/io");
lf[178]=C_h_intern(&lf[178],10,"signal/urg");
lf[179]=C_h_intern(&lf[179],11,"signal/chld");
lf[180]=C_h_intern(&lf[180],11,"signal/cont");
lf[181]=C_h_intern(&lf[181],11,"signal/stop");
lf[182]=C_h_intern(&lf[182],11,"signal/tstp");
lf[183]=C_h_intern(&lf[183],11,"signal/pipe");
lf[184]=C_h_intern(&lf[184],11,"signal/xcpu");
lf[185]=C_h_intern(&lf[185],11,"signal/xfsz");
lf[186]=C_h_intern(&lf[186],11,"signal/usr1");
lf[187]=C_h_intern(&lf[187],11,"signal/usr2");
lf[188]=C_h_intern(&lf[188],12,"signal/winch");
lf[189]=C_h_intern(&lf[189],12,"signals-list");
lf[190]=C_h_intern(&lf[190],18,"\003sysinterrupt-hook");
lf[191]=C_h_intern(&lf[191],14,"signal-handler");
lf[192]=C_h_intern(&lf[192],19,"set-signal-handler!");
lf[193]=C_h_intern(&lf[193],16,"set-signal-mask!");
lf[194]=C_h_intern(&lf[194],14,"\000process-error");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[196]=C_h_intern(&lf[196],11,"signal-mask");
lf[197]=C_h_intern(&lf[197],14,"signal-masked\077");
lf[198]=C_h_intern(&lf[198],12,"signal-mask!");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[200]=C_h_intern(&lf[200],14,"signal-unmask!");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[202]=C_h_intern(&lf[202],18,"system-information");
lf[203]=C_h_intern(&lf[203],25,"\003syspeek-nonnull-c-string");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[205]=C_h_intern(&lf[205],15,"current-user-id");
lf[206]=C_h_intern(&lf[206],25,"current-effective-user-id");
lf[207]=C_h_intern(&lf[207],16,"current-group-id");
lf[208]=C_h_intern(&lf[208],26,"current-effective-group-id");
lf[209]=C_h_intern(&lf[209],16,"user-information");
lf[210]=C_h_intern(&lf[210],6,"vector");
lf[211]=C_h_intern(&lf[211],4,"list");
lf[212]=C_h_intern(&lf[212],27,"current-effective-user-name");
lf[213]=C_h_intern(&lf[213],17,"group-information");
lf[215]=C_h_intern(&lf[215],10,"get-groups");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[219]=C_h_intern(&lf[219],11,"set-groups!");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[222]=C_h_intern(&lf[222],17,"initialize-groups");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[224]=C_h_intern(&lf[224],10,"errno/perm");
lf[225]=C_h_intern(&lf[225],11,"errno/noent");
lf[226]=C_h_intern(&lf[226],10,"errno/srch");
lf[227]=C_h_intern(&lf[227],10,"errno/intr");
lf[228]=C_h_intern(&lf[228],8,"errno/io");
lf[229]=C_h_intern(&lf[229],12,"errno/noexec");
lf[230]=C_h_intern(&lf[230],10,"errno/badf");
lf[231]=C_h_intern(&lf[231],11,"errno/child");
lf[232]=C_h_intern(&lf[232],11,"errno/nomem");
lf[233]=C_h_intern(&lf[233],11,"errno/acces");
lf[234]=C_h_intern(&lf[234],11,"errno/fault");
lf[235]=C_h_intern(&lf[235],10,"errno/busy");
lf[236]=C_h_intern(&lf[236],12,"errno/notdir");
lf[237]=C_h_intern(&lf[237],11,"errno/isdir");
lf[238]=C_h_intern(&lf[238],11,"errno/inval");
lf[239]=C_h_intern(&lf[239],11,"errno/mfile");
lf[240]=C_h_intern(&lf[240],11,"errno/nospc");
lf[241]=C_h_intern(&lf[241],11,"errno/spipe");
lf[242]=C_h_intern(&lf[242],10,"errno/pipe");
lf[243]=C_h_intern(&lf[243],11,"errno/again");
lf[244]=C_h_intern(&lf[244],10,"errno/rofs");
lf[245]=C_h_intern(&lf[245],11,"errno/exist");
lf[246]=C_h_intern(&lf[246],16,"errno/wouldblock");
lf[247]=C_h_intern(&lf[247],10,"errno/2big");
lf[248]=C_h_intern(&lf[248],12,"errno/deadlk");
lf[249]=C_h_intern(&lf[249],9,"errno/dom");
lf[250]=C_h_intern(&lf[250],10,"errno/fbig");
lf[251]=C_h_intern(&lf[251],11,"errno/ilseq");
lf[252]=C_h_intern(&lf[252],11,"errno/mlink");
lf[253]=C_h_intern(&lf[253],17,"errno/nametoolong");
lf[254]=C_h_intern(&lf[254],11,"errno/nfile");
lf[255]=C_h_intern(&lf[255],11,"errno/nodev");
lf[256]=C_h_intern(&lf[256],11,"errno/nolck");
lf[257]=C_h_intern(&lf[257],11,"errno/nosys");
lf[258]=C_h_intern(&lf[258],14,"errno/notempty");
lf[259]=C_h_intern(&lf[259],11,"errno/notty");
lf[260]=C_h_intern(&lf[260],10,"errno/nxio");
lf[261]=C_h_intern(&lf[261],11,"errno/range");
lf[262]=C_h_intern(&lf[262],10,"errno/xdev");
lf[263]=C_h_intern(&lf[263],16,"change-file-mode");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[265]=C_h_intern(&lf[265],17,"change-file-owner");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[267]=C_h_intern(&lf[267],17,"file-read-access\077");
lf[268]=C_h_intern(&lf[268],18,"file-write-access\077");
lf[269]=C_h_intern(&lf[269],20,"file-execute-access\077");
lf[270]=C_h_intern(&lf[270],14,"create-session");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[272]=C_h_intern(&lf[272],16,"process-group-id");
lf[273]=C_h_intern(&lf[273],20,"create-symbolic-link");
lf[274]=C_h_intern(&lf[274],18,"create-symbol-link");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[276]=C_h_intern(&lf[276],9,"substring");
lf[277]=C_h_intern(&lf[277],18,"read-symbolic-link");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[279]=C_h_intern(&lf[279],9,"file-link");
lf[280]=C_h_intern(&lf[280],9,"hard-link");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[282]=C_h_intern(&lf[282],12,"fileno/stdin");
lf[283]=C_h_intern(&lf[283],13,"fileno/stdout");
lf[284]=C_h_intern(&lf[284],13,"fileno/stderr");
lf[285]=C_h_intern(&lf[285],7,"\000append");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[293]=C_h_intern(&lf[293],16,"open-input-file*");
lf[294]=C_h_intern(&lf[294],17,"open-output-file*");
lf[295]=C_h_intern(&lf[295],12,"port->fileno");
lf[296]=C_h_intern(&lf[296],6,"socket");
lf[297]=C_h_intern(&lf[297],20,"\003systcp-port->fileno");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[300]=C_h_intern(&lf[300],25,"\003syspeek-unsigned-integer");
lf[301]=C_h_intern(&lf[301],16,"duplicate-fileno");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[303]=C_h_intern(&lf[303],15,"make-input-port");
lf[304]=C_h_intern(&lf[304],14,"set-port-name!");
lf[305]=C_h_intern(&lf[305],21,"\003syscustom-input-port");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[307]=C_h_intern(&lf[307],17,"\003systhread-yield!");
lf[308]=C_h_intern(&lf[308],25,"\003systhread-block-for-i/o!");
lf[309]=C_h_intern(&lf[309],18,"\003syscurrent-thread");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[314]=C_h_intern(&lf[314],17,"\003sysstring-append");
lf[315]=C_h_intern(&lf[315],15,"\003sysmake-string");
lf[316]=C_h_intern(&lf[316],20,"\003sysscan-buffer-line");
lf[317]=C_h_intern(&lf[317],4,"noop");
lf[318]=C_h_intern(&lf[318],16,"make-output-port");
lf[319]=C_h_intern(&lf[319],22,"\003syscustom-output-port");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[322]=C_h_intern(&lf[322],13,"file-truncate");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[325]=C_h_intern(&lf[325],4,"lock");
lf[326]=C_h_intern(&lf[326],9,"file-lock");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[328]=C_h_intern(&lf[328],18,"file-lock/blocking");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[330]=C_h_intern(&lf[330],14,"file-test-lock");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[332]=C_h_intern(&lf[332],11,"file-unlock");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[334]=C_h_intern(&lf[334],11,"create-fifo");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[336]=C_h_intern(&lf[336],5,"fifo\077");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[338]=C_h_intern(&lf[338],6,"setenv");
lf[339]=C_h_intern(&lf[339],8,"unsetenv");
lf[340]=C_h_intern(&lf[340],25,"get-environment-variables");
lf[341]=C_h_intern(&lf[341],19,"current-environment");
lf[342]=C_h_intern(&lf[342],9,"prot/read");
lf[343]=C_h_intern(&lf[343],10,"prot/write");
lf[344]=C_h_intern(&lf[344],9,"prot/exec");
lf[345]=C_h_intern(&lf[345],9,"prot/none");
lf[346]=C_h_intern(&lf[346],9,"map/fixed");
lf[347]=C_h_intern(&lf[347],10,"map/shared");
lf[348]=C_h_intern(&lf[348],11,"map/private");
lf[349]=C_h_intern(&lf[349],13,"map/anonymous");
lf[350]=C_h_intern(&lf[350],8,"map/file");
lf[351]=C_h_intern(&lf[351],18,"map-file-to-memory");
lf[352]=C_h_intern(&lf[352],4,"mmap");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[354]=C_h_intern(&lf[354],20,"\003syspointer->address");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[356]=C_h_intern(&lf[356],16,"\003sysnull-pointer");
lf[357]=C_h_intern(&lf[357],22,"unmap-file-from-memory");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[359]=C_h_intern(&lf[359],26,"memory-mapped-file-pointer");
lf[360]=C_h_intern(&lf[360],19,"memory-mapped-file\077");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[363]=C_h_intern(&lf[363],19,"seconds->local-time");
lf[364]=C_h_intern(&lf[364],18,"\003sysdecode-seconds");
lf[365]=C_h_intern(&lf[365],17,"seconds->utc-time");
lf[366]=C_h_intern(&lf[366],15,"seconds->string");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[368]=C_h_intern(&lf[368],12,"time->string");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[371]=C_h_intern(&lf[371],12,"string->time");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[373]=C_h_intern(&lf[373],19,"local-time->seconds");
lf[374]=C_h_intern(&lf[374],15,"\003syscons-flonum");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[376]=C_h_intern(&lf[376],17,"utc-time->seconds");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[378]=C_h_intern(&lf[378],27,"local-timezone-abbreviation");
lf[379]=C_h_intern(&lf[379],5,"_exit");
lf[380]=C_h_intern(&lf[380],10,"set-alarm!");
lf[381]=C_h_intern(&lf[381],19,"set-buffering-mode!");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[383]=C_h_intern(&lf[383],5,"\000full");
lf[384]=C_h_intern(&lf[384],5,"\000line");
lf[385]=C_h_intern(&lf[385],5,"\000none");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[387]=C_h_intern(&lf[387],14,"terminal-port\077");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[390]=C_h_intern(&lf[390],13,"terminal-name");
lf[391]=C_h_intern(&lf[391],13,"terminal-size");
lf[392]=C_h_intern(&lf[392],6,"\000error");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[394]=C_h_intern(&lf[394],17,"\003sysmake-locative");
lf[395]=C_h_intern(&lf[395],8,"location");
lf[396]=C_h_intern(&lf[396],13,"get-host-name");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[398]=C_h_intern(&lf[398],6,"regexp");
lf[399]=C_h_intern(&lf[399],12,"string-match");
lf[400]=C_h_intern(&lf[400],12,"glob->regexp");
lf[401]=C_h_intern(&lf[401],13,"make-pathname");
lf[402]=C_h_intern(&lf[402],18,"decompose-pathname");
lf[403]=C_h_intern(&lf[403],4,"glob");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[406]=C_h_intern(&lf[406],12,"process-fork");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[408]=C_h_intern(&lf[408],24,"pathname-strip-directory");
lf[409]=C_h_intern(&lf[409],15,"process-execute");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[411]=C_h_intern(&lf[411],16,"\003sysprocess-wait");
lf[412]=C_h_intern(&lf[412],12,"process-wait");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[414]=C_h_intern(&lf[414],18,"current-process-id");
lf[415]=C_h_intern(&lf[415],17,"parent-process-id");
lf[416]=C_h_intern(&lf[416],5,"sleep");
lf[417]=C_h_intern(&lf[417],14,"process-signal");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[419]=C_h_intern(&lf[419],17,"\003sysshell-command");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[422]=C_h_intern(&lf[422],27,"\003sysshell-command-arguments");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[424]=C_h_intern(&lf[424],11,"process-run");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[426]=C_h_intern(&lf[426],11,"\003sysprocess");
lf[427]=C_h_intern(&lf[427],7,"process");
lf[428]=C_h_intern(&lf[428],8,"process*");
lf[429]=C_h_intern(&lf[429],10,"find-files");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[433]=C_h_intern(&lf[433],16,"\003sysdynamic-wind");
lf[434]=C_h_intern(&lf[434],13,"pathname-file");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[436]=C_h_intern(&lf[436],7,"regexp\077");
lf[437]=C_h_intern(&lf[437],19,"set-root-directory!");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[440]=C_h_intern(&lf[440],21,"set-process-group-id!");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[442]=C_h_intern(&lf[442],18,"getter-with-setter");
lf[443]=C_h_intern(&lf[443],26,"effective-group-id!-setter");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[445]=C_h_intern(&lf[445],12,"set-user-id!");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[447]=C_h_intern(&lf[447],25,"effective-user-id!-setter");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[450]=C_h_intern(&lf[450],23,"\003sysuser-interrupt-hook");
lf[451]=C_h_intern(&lf[451],11,"make-vector");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[454]=C_h_intern(&lf[454],5,"port\077");
lf[455]=C_h_intern(&lf[455],18,"set-file-position!");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[458]=C_h_intern(&lf[458],13,"\000bounds-error");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[460]=C_h_intern(&lf[460],17,"register-feature!");
lf[461]=C_h_intern(&lf[461],5,"posix");
C_register_lf2(lf,462,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3431 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3434 in k3431 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3437 in k3434 in k3431 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 501  register-feature! */
t3=*((C_word*)lf[460]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[461]);}

/* k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[81],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3458,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! posix-error ...) */,lf[1]);
t5=C_mutate((C_word*)lf[7]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3476,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3479,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[10]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[11]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[15]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[16]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[17]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[18]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[19]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[20]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[21]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[22]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[23]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[24]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[25]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[26]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[27]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[28]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[29]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[30]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[31]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[32]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[33]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[34]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[35]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[36]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[37]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[38]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[39]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[40]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[42]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[43]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[44]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[45]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3520,tmp=(C_word)a,a+=2,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[48]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[52]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3597,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[54]+1);
t49=C_mutate((C_word*)lf[55]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[59]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3654,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[62]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3693,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3725,tmp=(C_word)a,a+=2,tmp);
t53=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3727,tmp=(C_word)a,a+=2,tmp);
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3729,tmp=(C_word)a,a+=2,tmp);
t55=C_mutate((C_word*)lf[65]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3731,a[2]=t53,a[3]=t54,a[4]=t52,tmp=(C_word)a,a+=5,tmp));
t56=C_mutate((C_word*)lf[68]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[69]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[70]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[71] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3923,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[74]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3960,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[75]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3985,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[76]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3991,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[77]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3997,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[78]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4003,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[79]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4009,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[80]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4015,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[81]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4021,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[82]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4030,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[83]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4039,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[84]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4048,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[85]+1 /* (set! stat-char-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4057,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[86]+1 /* (set! stat-block-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4066,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[87]+1 /* (set! stat-fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4075,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[88]+1 /* (set! stat-symlink? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4084,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[89]+1 /* (set! stat-socket? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4093,tmp=(C_word)a,a+=2,tmp));
t76=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4104,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t77=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9027,tmp=(C_word)a,a+=2,tmp);
t78=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9064,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 828  getter-with-setter */
t79=*((C_word*)lf[442]+1);
((C_proc4)(void*)(*((C_word*)t79+1)))(4,t79,t76,t77,t78);}

/* a9063 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_9064r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_9064r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9064r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[455]);
t8=(C_word)C_i_check_exact_2(t6,lf[455]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9077,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 843  ##sys#signal-hook */
t10=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[458],lf[455],lf[459],t3,t2);}
else{
t10=t9;
f_9077(2,t10,C_SCHEME_UNDEFINED);}}

/* k9075 in a9063 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 844  port? */
t4=*((C_word*)lf[454]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k9087 in k9075 in a9063 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[147]);
t4=((C_word*)t0)[4];
f_9083(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_9083(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 848  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[57],lf[455],lf[457],((C_word*)t0)[5]);}}}

/* k9081 in k9075 in a9063 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 849  posix-error */
t2=lf[1];
f_3458(7,t2,((C_word*)t0)[4],lf[46],lf[455],lf[456],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a9026 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9027,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9031,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9043,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 830  port? */
t5=*((C_word*)lf[454]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9041 in a9026 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[147]);
t4=((C_word*)t0)[2];
f_9031(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_9031(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 835  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[57],lf[90],lf[453],((C_word*)t0)[3]);}}}

/* k9029 in a9026 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9034,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 837  posix-error */
t3=lf[1];
f_3458(6,t3,t2,lf[46],lf[90],lf[452],((C_word*)t0)[2]);}
else{
t3=t2;
f_9034(2,t3,C_SCHEME_UNDEFINED);}}

/* k9032 in k9029 in a9026 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[150],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4104,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[91]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4106,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[101]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4207,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[103]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4231,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[105]+1);
t7=*((C_word*)lf[54]+1);
t8=*((C_word*)lf[106]+1);
t9=C_mutate((C_word*)lf[107]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4255,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[111]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4409,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[54]+1);
t12=C_mutate((C_word*)lf[110]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4432,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[114]+1);
t14=*((C_word*)lf[115]+1);
t15=*((C_word*)lf[116]+1);
t16=*((C_word*)lf[117]+1);
t17=*((C_word*)lf[105]+1);
t18=*((C_word*)lf[0]+1);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4473,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4478,tmp=(C_word)a,a+=2,tmp);
t21=*((C_word*)lf[120]+1);
t22=*((C_word*)lf[121]+1);
t23=*((C_word*)lf[110]+1);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4489,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=C_mutate((C_word*)lf[100]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4545,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,tmp=(C_word)a,a+=13,tmp));
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4862,tmp=(C_word)a,a+=2,tmp);
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4874,tmp=(C_word)a,a+=2,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4880,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[148]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4895,a[2]=t27,a[3]=t28,a[4]=t26,tmp=(C_word)a,a+=5,tmp));
t30=C_mutate((C_word*)lf[150]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4931,a[2]=t27,a[3]=t28,a[4]=t26,tmp=(C_word)a,a+=5,tmp));
t31=C_mutate((C_word*)lf[151]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4967,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[155]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[151]+1));
t33=*((C_word*)lf[148]+1);
t34=*((C_word*)lf[150]+1);
t35=*((C_word*)lf[151]+1);
t36=*((C_word*)lf[155]+1);
t37=C_mutate((C_word*)lf[156]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4983,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t38=C_mutate((C_word*)lf[157]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5007,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[158]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5031,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[160]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5051,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[162]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5071,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[164]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[165]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[166]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[167]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[168]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[169]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[170]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[171]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[172]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[173]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[174]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[175]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[176]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[177]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[178]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[179]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[180]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[181]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[182]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[183]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[184]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[185]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[186]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[187]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[188]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[164]+1),*((C_word*)lf[165]+1),*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1));
t68=C_mutate((C_word*)lf[189]+1 /* (set! signals-list ...) */,t67);
t69=*((C_word*)lf[190]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1171 make-vector */
t71=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=C_mutate((C_word*)lf[191]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5118,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[192]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5127,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[190]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5140,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[193]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5158,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[196]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5182,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[197]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5214,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[198]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5220,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[200]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5235,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9021,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1227 set-signal-handler! */
t12=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,*((C_word*)lf[166]+1),t11);}

/* a9020 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9021,3,t0,t1,t2);}
/* posixunix.scm: 1229 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[450]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5251,2,t0,t1);}
t2=C_mutate((C_word*)lf[202]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5253,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9003,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9006,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1253 getter-with-setter */
t6=*((C_word*)lf[442]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a9005 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9006,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9016,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1257 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9014 in a9005 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1258 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[445],lf[449],((C_word*)t0)[2]);}

/* a9002 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9003,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1110(C_SCHEME_UNDEFINED));}

/* k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=C_mutate((C_word*)lf[205]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8985,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8988,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1261 getter-with-setter */
t6=*((C_word*)lf[442]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8987 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8988,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8998,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1265 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8996 in a8987 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1266 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[447],lf[448],((C_word*)t0)[2]);}

/* a8984 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8985,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1119(C_SCHEME_UNDEFINED));}

/* k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5297,2,t0,t1);}
t2=C_mutate((C_word*)lf[206]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8967,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8970,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1270 getter-with-setter */
t6=*((C_word*)lf[442]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8969 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8970,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8980,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1274 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8978 in a8969 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1275 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[445],lf[446],((C_word*)t0)[2]);}

/* a8966 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8967,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1128(C_SCHEME_UNDEFINED));}

/* k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8949,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8952,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1278 getter-with-setter */
t6=*((C_word*)lf[442]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8951 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8952,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8962,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1282 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8960 in a8951 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1283 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[443],lf[444],((C_word*)t0)[2]);}

/* a8948 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8949,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1137(C_SCHEME_UNDEFINED));}

/* k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[209]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5307,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[121]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5367,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[212]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5381,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[213]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5401,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[214] /* (set! _ensure-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5476,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[215]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5479,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[219]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5542,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[222]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5608,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[224]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[225]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[226]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[227]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[228]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[229]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[230]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[231]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[232]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[233]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[234]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[235]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[236]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[237]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[238]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[239]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[240]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[241]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[242]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[243]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[244]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[245]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[246]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[247] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[248] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[249] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[250] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[251] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[252] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[253] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[254] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[255] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[256] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[257] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[258] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[259] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[260] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[261] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[262] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[263]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5672,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[265]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5699,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5729,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[267]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5753,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[268]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5759,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[269]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5765,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[270]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5771,tmp=(C_word)a,a+=2,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8910,tmp=(C_word)a,a+=2,tmp);
t59=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8928,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1498 getter-with-setter */
t60=*((C_word*)lf[442]+1);
((C_proc4)(void*)(*((C_word*)t60+1)))(4,t60,t57,t58,t59);}

/* a8927 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8928,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[440]);
t5=(C_word)C_i_check_exact_2(t3,lf[440]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8944,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1510 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k8942 in a8927 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1511 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[440],lf[441],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8909 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8910,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[272]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8917,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8923,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1503 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_8917(2,t6,C_SCHEME_UNDEFINED);}}

/* k8921 in a8909 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1504 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[272],lf[439],((C_word*)t0)[2]);}

/* k8915 in a8909 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5788,2,t0,t1);}
t2=C_mutate((C_word*)lf[272]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[273]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5790,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[276]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_u_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1531 make-string */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word ab[190],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=C_mutate((C_word*)lf[277]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[279]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5870,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[282]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[283]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[284]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5895,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5932,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[293]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5947,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[294]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5961,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[295]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5975,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[301]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6020,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[303]+1);
t14=*((C_word*)lf[304]+1);
t15=C_mutate((C_word*)lf[305]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6047,a[2]=t13,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[318]+1);
t17=*((C_word*)lf[304]+1);
t18=C_mutate((C_word*)lf[319]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=C_mutate((C_word*)lf[322]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6782,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6821,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6892,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[326]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6910,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[328]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6925,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[330]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6940,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[332]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6962,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[334]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6990,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[336]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7033,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[338]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7059,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[339]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7076,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[340]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7091,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[341]+1 /* (set! current-environment ...) */,*((C_word*)lf[340]+1));
t32=C_mutate((C_word*)lf[342]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[343]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[344]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[345]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[346]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[347]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[348]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[349]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[350]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[351]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7175,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[357]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7233,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[359]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7268,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[360]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7277,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[361] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7283,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[363]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7302,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[365]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7311,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[366]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7325,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[368]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7361,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[371]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7423,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[373]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7462,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[376]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7477,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[378]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7492,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[379]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7500,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[380]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7516,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[381]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7519,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[387]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7578,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate(&lf[388] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7597,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[390]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7624,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[391]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7643,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[396]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7678,tmp=(C_word)a,a+=2,tmp));
t62=*((C_word*)lf[398]+1);
t63=*((C_word*)lf[399]+1);
t64=*((C_word*)lf[400]+1);
t65=*((C_word*)lf[107]+1);
t66=*((C_word*)lf[401]+1);
t67=*((C_word*)lf[402]+1);
t68=C_mutate((C_word*)lf[403]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7690,a[2]=t64,a[3]=t62,a[4]=t65,a[5]=t63,a[6]=t66,a[7]=t67,tmp=(C_word)a,a+=8,tmp));
t69=C_mutate((C_word*)lf[406]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7799,tmp=(C_word)a,a+=2,tmp));
t70=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7837,tmp=(C_word)a,a+=2,tmp);
t71=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7845,tmp=(C_word)a,a+=2,tmp);
t72=*((C_word*)lf[408]+1);
t73=C_mutate((C_word*)lf[409]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7853,a[2]=t72,a[3]=t71,a[4]=t70,tmp=(C_word)a,a+=5,tmp));
t74=C_mutate((C_word*)lf[411]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8032,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[412]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8049,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[414]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8124,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[415]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8127,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[416]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8130,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[417]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8133,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[419]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8160,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[422]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8169,tmp=(C_word)a,a+=2,tmp));
t82=*((C_word*)lf[406]+1);
t83=*((C_word*)lf[409]+1);
t84=*((C_word*)lf[120]+1);
t85=C_mutate((C_word*)lf[424]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8175,a[2]=t82,a[3]=t83,tmp=(C_word)a,a+=4,tmp));
t86=*((C_word*)lf[162]+1);
t87=*((C_word*)lf[412]+1);
t88=*((C_word*)lf[406]+1);
t89=*((C_word*)lf[409]+1);
t90=*((C_word*)lf[301]+1);
t91=*((C_word*)lf[52]+1);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8231,a[2]=t87,tmp=(C_word)a,a+=3,tmp);
t93=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8268,a[2]=t86,tmp=(C_word)a,a+=3,tmp);
t94=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8288,a[2]=t91,tmp=(C_word)a,a+=3,tmp);
t95=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8302,a[2]=t91,tmp=(C_word)a,a+=3,tmp);
t96=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8319,tmp=(C_word)a,a+=2,tmp);
t97=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8335,a[2]=t93,a[3]=t88,a[4]=t95,a[5]=t89,a[6]=t96,tmp=(C_word)a,a+=7,tmp);
t98=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8380,a[2]=t94,tmp=(C_word)a,a+=3,tmp);
t99=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8391,a[2]=t94,tmp=(C_word)a,a+=3,tmp);
t100=C_mutate((C_word*)lf[426]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8402,a[2]=t99,a[3]=t92,a[4]=t98,a[5]=t97,tmp=(C_word)a,a+=6,tmp));
t101=C_set_block_item(lf[427] /* process */,0,C_SCHEME_UNDEFINED);
t102=C_set_block_item(lf[428] /* process* */,0,C_SCHEME_UNDEFINED);
t103=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8460,tmp=(C_word)a,a+=2,tmp);
t104=C_mutate((C_word*)lf[427]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8521,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t105=C_mutate((C_word*)lf[428]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8578,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t106=*((C_word*)lf[403]+1);
t107=*((C_word*)lf[399]+1);
t108=*((C_word*)lf[401]+1);
t109=*((C_word*)lf[111]+1);
t110=C_mutate((C_word*)lf[429]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8635,a[2]=t109,a[3]=t108,a[4]=t106,a[5]=t107,tmp=(C_word)a,a+=6,tmp));
t111=C_mutate((C_word*)lf[437]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8887,tmp=(C_word)a,a+=2,tmp));
t112=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t112+1)))(2,t112,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8887,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[437]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8883,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* ##sys#make-c-string */
t6=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t6=t5;
f_8883(2,t6,C_SCHEME_FALSE);}}

/* k8881 in set-root-directory! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub3168(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2393 posix-error */
t3=lf[1];
f_3458(6,t3,((C_word*)t0)[3],lf[46],lf[437],lf[438],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_8635r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8635r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8635r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8802,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8807,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8812,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action30583149 */
t9=t8;
f_8812(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id30593145 */
t11=t7;
f_8807(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit30603140 */
t13=t6;
f_8802(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body30563066 */
t15=t5;
f_8637(t15,t1,t9,t11,t13);}}}}

/* def-action3058 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8812,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8818,tmp=(C_word)a,a+=2,tmp);
/* def-id30593145 */
t3=((C_word*)t0)[2];
f_8807(t3,t1,t2);}

/* a8817 in def-action3058 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8818,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id3059 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8807,NULL,3,t0,t1,t2);}
/* def-limit30603140 */
t3=((C_word*)t0)[2];
f_8802(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit3060 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8802(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8802,NULL,4,t0,t1,t2,t3);}
/* body30563066 */
t4=((C_word*)t0)[2];
f_8637(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8637(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8637,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[429]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8644,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_8644(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8797,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_8644(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8789,tmp=(C_word)a,a+=2,tmp));}}

/* f_8789 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8789(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8789,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_8797 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8797(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8797,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8644,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_8777(2,t4,t2);}
else{
/* posixunix.scm: 2365 regexp? */
t4=*((C_word*)lf[436]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}

/* k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8777,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8778,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8771,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2368 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[435]);}

/* k8769 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2368 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8654,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8656,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8656(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8656(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8656,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2374 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8675,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2375 pathname-file */
t3=*((C_word*)lf[434]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8757,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2382 pproc */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8755 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8757,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2382 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2383 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8656(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k8762 in k8755 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2382 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8656(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[430]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[431]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2375 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8656(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2376 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8690,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8700,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8702,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8731,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[433]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8741,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2381 pproc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8742 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2381 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8741(2,t2,((C_word*)t0)[2]);}}

/* k8739 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2381 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8656(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8730 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8731,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8706 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8715,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8729,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2379 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[432]);}

/* k8727 in a8706 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2379 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8713 in a8706 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8719,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2380 pproc */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k8720 in k8713 in a8706 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2380 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8719(2,t2,((C_word*)t0)[2]);}}

/* k8717 in k8713 in a8706 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2379 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8656(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8701 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8702,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8698 in k8688 in k8749 in k8673 in loop in k8652 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2377 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8656(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8778 in k8775 in k8642 in body3056 in find-files in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8778,3,t0,t1,t2);}
/* posixunix.scm: 2366 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8578(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_8578r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8578r(t0,t1,t2,t3);}}

static void C_ccall f_8578r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8580,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8585,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8590,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args30113027 */
t7=t6;
f_8590(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env30123023 */
t9=t5;
f_8585(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body30093018 */
t11=t4;
f_8580(t11,t1,t7,t9);}}}

/* def-args3011 in process* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8590,NULL,2,t0,t1);}
/* def-env30123023 */
t2=((C_word*)t0)[2];
f_8585(t2,t1,C_SCHEME_FALSE);}

/* def-env3012 in process* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8585,NULL,3,t0,t1,t2);}
/* body30093018 */
t3=((C_word*)t0)[2];
f_8580(t3,t1,t2,C_SCHEME_FALSE);}

/* body3009 in process* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8580(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8580,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2343 %process */
f_8460(t1,lf[428],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8521(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_8521r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8521r(t0,t1,t2,t3);}}

static void C_ccall f_8521r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8523,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8528,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8533,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args29672983 */
t7=t6;
f_8533(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env29682979 */
t9=t5;
f_8528(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body29652974 */
t11=t4;
f_8523(t11,t1,t7,t9);}}}

/* def-args2967 in process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8533,NULL,2,t0,t1);}
/* def-env29682979 */
t2=((C_word*)t0)[2];
f_8528(t2,t1,C_SCHEME_FALSE);}

/* def-env2968 in process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8528(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8528,NULL,3,t0,t1,t2);}
/* body29652974 */
t3=((C_word*)t0)[2];
f_8523(t3,t1,t2,C_SCHEME_FALSE);}

/* body2965 in process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8523(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8523,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2340 %process */
f_8460(t1,lf[427],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8460(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8460,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8462,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8481,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2329 chkstrlst */
t12=t9;
f_8462(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8515,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2331 ##sys#shell-command-arguments */
t13=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t7)[1]);}}

/* k8513 in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8515,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2332 ##sys#shell-command */
t4=*((C_word*)lf[419]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k8517 in k8513 in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8481(2,t3,t2);}

/* k8479 in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2333 chkstrlst */
t3=((C_word*)t0)[2];
f_8462(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8484(2,t3,C_SCHEME_UNDEFINED);}}

/* k8482 in k8479 in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8495,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8494 in k8482 in k8479 in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8495,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2336 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2337 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8488 in k8482 in k8479 in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8489,2,t0,t1);}
/* posixunix.scm: 2334 ##sys#process */
t2=*((C_word*)lf[426]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8462(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8462,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8470 in chkstrlst in %process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8471,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8402,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8408,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a8413 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8414,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8425,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8445,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2310 make-on-close */
t12=((C_word*)t0)[3];
f_8231(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8443 in a8413 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2309 input-port */
t2=((C_word*)t0)[7];
f_8380(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8423 in a8413 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8429,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2312 make-on-close */
t4=((C_word*)t0)[6];
f_8231(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8439 in k8423 in a8413 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2311 output-port */
t2=((C_word*)t0)[7];
f_8391(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8427 in k8423 in a8413 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8433,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2315 make-on-close */
t4=((C_word*)t0)[3];
f_8231(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8435 in k8427 in k8423 in a8413 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2314 input-port */
t2=((C_word*)t0)[7];
f_8380(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8431 in k8427 in k8423 in a8413 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2308 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8407 in ##sys#process in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8408,2,t0,t1);}
/* posixunix.scm: 2303 spawn */
t2=((C_word*)t0)[8];
f_8335(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8391(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8391,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8395,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2299 connect-parent */
t8=((C_word*)t0)[2];
f_8288(t8,t7,t4,t5);}

/* k8393 in output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2300 ##sys#custom-output-port */
t2=*((C_word*)lf[319]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8380,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8384,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2295 connect-parent */
t8=((C_word*)t0)[2];
f_8288(t8,t7,t4,t5);}

/* k8382 in input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2296 ##sys#custom-input-port */
t2=*((C_word*)lf[305]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8335(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8335,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2282 needed-pipe */
t9=((C_word*)t0)[2];
f_8268(t9,t8,t6);}

/* k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2283 needed-pipe */
t3=((C_word*)t0)[2];
f_8268(t3,t2,((C_word*)t0)[5]);}

/* k8340 in k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2284 needed-pipe */
t3=((C_word*)t0)[2];
f_8268(t3,t2,((C_word*)t0)[6]);}

/* k8343 in k8340 in k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8345,2,t0,t1);}
t2=f_8319(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8356,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2287 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8357 in k8343 in k8340 in k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8362,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2289 connect-child */
t3=((C_word*)t0)[7];
f_8302(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[282]+1));}

/* k8360 in a8357 in k8343 in k8340 in k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_8319(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2290 connect-child */
t4=((C_word*)t0)[5];
f_8302(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[283]+1));}

/* k8363 in k8360 in a8357 in k8343 in k8340 in k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8368,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_8319(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2291 connect-child */
t4=((C_word*)t0)[3];
f_8302(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[284]+1));}

/* k8366 in k8363 in k8360 in a8357 in k8343 in k8340 in k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2292 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8354 in k8343 in k8340 in k8337 in spawn in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2285 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_8319(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_u_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8302(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8302,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8315,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2273 file-close */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k8313 in connect-child in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8315,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2247 duplicate-fileno */
t6=*((C_word*)lf[301]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k8225 in k8313 in connect-child in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2248 file-close */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8288(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8288,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8301,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2267 file-close */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8299 in connect-parent in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8268(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8268,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8283,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a8282 in needed-pipe in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8283,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a8276 in needed-pipe in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8277,2,t0,t1);}
/* posixunix.scm: 2262 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* make-on-close in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8231(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8231,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8233,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,tmp=(C_word)a,a+=9,tmp));}

/* f_8233 in make-on-close in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8233,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a8253 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8254,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2257 ##sys#signal-hook */
t5=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[194],((C_word*)t0)[3],lf[425],((C_word*)t0)[2],t4);}}

/* a8247 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8248,2,t0,t1);}
/* posixunix.scm: 2255 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8175(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8175r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8175r(t0,t1,t2,t3);}}

static void C_ccall f_8175r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8182,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2211 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k8180 in process-run in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8182,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2213 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2215 ##sys#shell-command */
t4=*((C_word*)lf[419]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8199 in k8180 in process-run in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8205,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2215 ##sys#shell-command-arguments */
t3=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8203 in k8199 in k8180 in process-run in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2215 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8169,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[423],t2));}

/* ##sys#shell-command in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8164,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2200 getenv */
t3=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[421]);}

/* k8162 in ##sys#shell-command in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[420]));}

/* process-signal in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8133r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8133r(t0,t1,t2,t3);}}

static void C_ccall f_8133r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[417]);
t7=(C_word)C_i_check_exact_2(t5,lf[417]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2197 posix-error */
t10=lf[1];
f_3458(7,t10,t1,lf[194],lf[417],lf[418],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8130,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub2715(C_SCHEME_UNDEFINED,t2));}

/* parent-process-id in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8127,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2710(C_SCHEME_UNDEFINED));}

/* current-process-id in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8124,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2706(C_SCHEME_UNDEFINED));}

/* process-wait in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8049(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_8049r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8049r(t0,t1,t2);}}

static void C_ccall f_8049r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t2,C_fix(1)));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[412]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8076,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8082,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t13,t14);}

/* a8081 in process-wait in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8082,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2183 posix-error */
t6=lf[1];
f_3458(6,t6,t1,lf[194],lf[412],lf[413],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8075 in process-wait in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8076,2,t0,t1);}
/* posixunix.scm: 2181 ##sys#process-wait */
t2=*((C_word*)lf[411]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8032,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2168 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7853(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_7853r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7853r(t0,t1,t2,t3);}}

static void C_ccall f_7853r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7982,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7987,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist25722640 */
t7=t6;
f_7987(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist25732636 */
t9=t5;
f_7982(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body25702579 */
t11=t4;
f_7855(t11,t1,t7,t9);}}}

/* def-arglist2572 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7987,NULL,2,t0,t1);}
/* def-envlist25732636 */
t2=((C_word*)t0)[2];
f_7982(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist2573 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7982,NULL,3,t0,t1,t2);}
/* body25702579 */
t3=((C_word*)t0)[2];
f_7855(t3,t1,t2,C_SCHEME_FALSE);}

/* body2570 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7855(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7855,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[409]);
t5=(C_word)C_i_check_list_2(t2,lf[409]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7865,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2136 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}

/* k7863 in body2570 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7865,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_7837(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7873,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7873(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop2585 in k7863 in body2570 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7873(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7873,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_7837(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[409]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7919,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=t5;
f_7886(t8,f_7919(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_7886(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[409]);
t6=(C_word)C_block_size(t4);
t7=f_7837(t3,t4,t6);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop2596 in doloop2585 in k7863 in body2570 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_7919(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(f_7845(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[409]);
t5=(C_word)C_block_size(t3);
t6=f_7845(t2,t3,t5);
t7=(C_word)C_slot(t1,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k7884 in doloop2585 in k7863 in body2570 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7886(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7886,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2150 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7909 in k7884 in doloop2585 in k7863 in body2570 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2150 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7887 in k7884 in doloop2585 in k7863 in body2570 in process-execute in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub2535(C_SCHEME_UNDEFINED);
t5=(C_word)stub2550(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2157 posix-error */
t6=lf[1];
f_3458(6,t6,((C_word*)t0)[3],lf[194],lf[409],lf[410],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_7845(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub2541(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* setarg in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_7837(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub2526(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* process-fork in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7799r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7799r(t0,t1,t2);}}

static void C_ccall f_7799r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub2494(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2121 posix-error */
t5=lf[1];
f_3458(5,t5,t1,lf[194],lf[406],lf[407]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7821,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k7819 in process-fork in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7825,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_7825 in k7819 in process-fork in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7825,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub2512(C_SCHEME_UNDEFINED,t2));}

/* glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7690(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_7690r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7690r(t0,t1,t2);}}

static void C_ccall f_7690r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_7696(t6,t1,t2);}

/* conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7696(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7696,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7711,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7717,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7791,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[405]);
/* posixunix.scm: 2106 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k7789 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2106 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7719 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2107 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7722 in k7719 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7731,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[404]);
/* posixunix.scm: 2108 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7729 in k7722 in k7719 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7733(t5,((C_word*)t0)[2],t1);}

/* loop in k7729 in k7722 in k7719 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7733(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7733,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixunix.scm: 2109 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7696(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixunix.scm: 2110 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7748 in loop in k7729 in k7722 in k7719 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7760,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixunix.scm: 2111 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixunix.scm: 2112 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7733(t3,((C_word*)t0)[6],t2);}}

/* k7758 in k7748 in loop in k7729 in k7722 in k7719 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7764,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 2111 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7733(t4,t2,t3);}

/* k7762 in k7758 in k7748 in loop in k7729 in k7722 in k7719 in a7716 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7764,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7710 in conc-loop in glob in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7711,2,t0,t1);}
/* posixunix.scm: 2105 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7682,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub2408(t3),C_fix(0));}

/* k7680 in get-host-name in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7685,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7685(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2087 posix-error */
t3=lf[1];
f_3458(5,t3,t2,lf[392],lf[396],lf[397]);}}

/* k7683 in k7680 in get-host-name in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7643,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7647,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2068 ##sys#terminal-check */
f_7597(t3,lf[391],t2);}

/* k7645 in terminal-size in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7647,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7667,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[394]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[395]);}

/* k7665 in k7645 in terminal-size in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[394]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[395]);}

/* k7669 in k7665 in k7645 in terminal-size in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_pointer_argumentp(t3);
t5=(C_word)C_i_foreign_pointer_argumentp(t1);
t6=(C_word)stub2379(C_SCHEME_UNDEFINED,t2,t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* posixunix.scm: 2075 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2076 posix-error */
t8=lf[1];
f_3458(6,t8,((C_word*)t0)[4],lf[392],lf[391],lf[393],((C_word*)t0)[6]);}}

/* terminal-name in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7624,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7628,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2060 ##sys#terminal-check */
f_7597(t3,lf[390],t2);}

/* k7626 in terminal-name in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7628,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t5=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2364(t4,t3),C_fix(0));}

/* ##sys#terminal-check in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7597(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7597,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7601,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2052 ##sys#check-port */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7599 in ##sys#terminal-check in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[147],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2055 ##sys#error */
t5=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[389],((C_word*)t0)[4]);}}

/* terminal-port? in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7578,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7582,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2047 ##sys#check-port */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[387]);}

/* k7580 in terminal-port? in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2048 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[300]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7583 in k7580 in terminal-port? in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7519r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7519r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7523,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2032 ##sys#check-port */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[381]);}

/* k7521 in set-buffering-mode! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7523,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[383]);
if(C_truep(t6)){
t7=t5;
f_7529(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[384]);
if(C_truep(t7)){
t8=t5;
f_7529(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[385]);
if(C_truep(t8)){
t9=t5;
f_7529(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2038 ##sys#error */
t9=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[381],lf[386],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k7527 in k7521 in set-buffering-mode! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[381]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[147],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2044 ##sys#error */
t6=*((C_word*)lf[141]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[381],lf[382],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7516,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub2315(C_SCHEME_UNDEFINED,t2));}

/* _exit in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7500(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7500r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7500r(t0,t1,t2);}}

static void C_ccall f_7500r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2306(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7492,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub2298(t2),C_fix(0));}

/* utc-time->seconds in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7477,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7481,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2000 check-time-vector */
f_7283(t3,lf[376],t2);}

/* k7479 in utc-time->seconds in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 2002 ##sys#cons-flonum */
t2=*((C_word*)lf[374]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2003 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[376],lf[377],((C_word*)t0)[3]);}}

/* local-time->seconds in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7462,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7466,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1994 check-time-vector */
f_7283(t3,lf[373],t2);}

/* k7464 in local-time->seconds in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1996 ##sys#cons-flonum */
t2=*((C_word*)lf[374]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1997 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[373],lf[375],((C_word*)t0)[3]);}}

/* string->time in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7423r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7423r(t0,t1,t2,t3);}}

static void C_ccall f_7423r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[372]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[371]);
t7=(C_word)C_i_check_string_2(t5,lf[371]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7440,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1991 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k7438 in string->time in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7444,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1991 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7442 in k7438 in string->time in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7444,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2259(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7361r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7361r(t0,t1,t2,t3);}}

static void C_ccall f_7361r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7368,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1975 check-time-vector */
f_7283(t6,lf[368],t2);}

/* k7366 in time->string in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7368,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[368]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7387,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1979 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2209(t4,t3),C_fix(0));}}

/* k7388 in k7366 in time->string in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1983 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1984 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[370],((C_word*)t0)[2]);}}

/* k7385 in k7366 in time->string in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7387,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub2217(t3,t2,t1),C_fix(0));}

/* k7375 in k7366 in time->string in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1980 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[369],((C_word*)t0)[2]);}}

/* seconds->string in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7325,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[366]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7332,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,(C_word)stub2193(t6,t5),C_fix(0));}

/* k7330 in seconds->string in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1968 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1969 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[366],lf[367],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7311,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[365]);
/* posixunix.scm: 1960 ##sys#decode-seconds */
t4=*((C_word*)lf[364]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7302,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[363]);
/* posixunix.scm: 1956 ##sys#decode-seconds */
t4=*((C_word*)lf[364]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7283(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7283,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1952 ##sys#error */
t6=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[362],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* memory-mapped-file? in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7277,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[352]));}

/* memory-mapped-file-pointer in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7268,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[352],lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7233r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7233r(t0,t1,t2,t3);}}

static void C_ccall f_7233r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_i_check_structure_2(t2,lf[352],lf[357]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)stub2146(C_SCHEME_UNDEFINED,t8,t6);
t10=(C_word)C_eqp(C_fix(0),t9);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1938 posix-error */
t11=lf[1];
f_3458(7,t11,t1,lf[46],lf[357],lf[358],t2,t6);}}

/* map-file-to-memory in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_7175r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_7175r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_7175r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7179,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_7179(2,t10,t2);}
else{
/* posixunix.scm: 1923 ##sys#null-pointer */
t10=*((C_word*)lf[356]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k7177 in map-file-to-memory in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7179,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7185,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_7185(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1926 ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[57],lf[351],lf[355],t1);}}

/* k7183 in k7177 in map-file-to-memory in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7185,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)stub2107(t7,t8,t3,t4,t5,t6,((C_word*)t0)[3]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7191,a[2]=((C_word*)t0)[7],a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1928 ##sys#pointer->address */
t12=*((C_word*)lf[354]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t9);}

/* k7202 in k7183 in k7177 in map-file-to-memory in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1929 posix-error */
t3=lf[1];
f_3458(11,t3,((C_word*)t0)[8],lf[46],lf[351],lf[353],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_7191(2,t3,C_SCHEME_UNDEFINED);}}

/* k7189 in k7183 in k7177 in map-file-to-memory in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7191,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[352],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7097,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7097(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7097,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7101,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub2058(t5,t4),C_fix(0));}

/* k7099 in loop in get-environment-variables in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7109,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7109(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k7099 in loop in get-environment-variables in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7109,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7135,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1887 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1890 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k7133 in scan in k7099 in loop in get-environment-variables in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7139,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1888 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k7137 in k7133 in scan in k7099 in loop in get-environment-variables in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7139,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7127,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1889 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7097(t5,t3,t4);}

/* k7125 in k7137 in k7133 in scan in k7099 in loop in get-environment-variables in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7127,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7076,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[339]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7084,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1876 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7082 in unsetenv in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7059,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[338]);
t5=(C_word)C_i_check_string_2(t3,lf[338]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7070,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1871 ##sys#make-c-string */
t7=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7068 in setenv in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1871 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7072 in k7068 in setenv in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7033,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[336]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7040,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7057,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1859 ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7055 in fifo? in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1859 ##sys#file-info */
t2=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7038 in fifo? in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1862 posix-error */
t2=lf[1];
f_3458(6,t2,((C_word*)t0)[3],lf[46],lf[336],lf[337],((C_word*)t0)[2]);}}

/* create-fifo in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6990r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6990r(t0,t1,t2,t3);}}

static void C_ccall f_6990r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[334]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6997,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_6997(t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_6997(t7,(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k6995 in create-fifo in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6997,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[334]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7018,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1853 ##sys#expand-home-path */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k7016 in k6995 in create-fifo in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1853 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7012 in k6995 in create-fifo in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1854 posix-error */
t3=lf[1];
f_3458(7,t3,((C_word*)t0)[3],lf[46],lf[334],lf[335],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6962,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[325],lf[332]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1843 posix-error */
t9=lf[1];
f_3458(6,t9,t1,lf[46],lf[332],lf[333],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6940(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6940r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6940r(t0,t1,t2,t3);}}

static void C_ccall f_6940r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6944,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1834 setup */
f_6821(t4,t2,t3,lf[330]);}

/* k6942 in file-test-lock in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1836 err */
f_6892(((C_word*)t0)[3],lf[331],t1,lf[330]);}}

/* file-lock/blocking in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6925r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6925r(t0,t1,t2,t3);}}

static void C_ccall f_6925r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6929,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1828 setup */
f_6821(t4,t2,t3,lf[328]);}

/* k6927 in file-lock/blocking in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1830 err */
f_6892(((C_word*)t0)[2],lf[329],t1,lf[328]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6910r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6910r(t0,t1,t2,t3);}}

static void C_ccall f_6910r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6914,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1822 setup */
f_6821(t4,t2,t3,lf[326]);}

/* k6912 in file-lock in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1824 err */
f_6892(((C_word*)t0)[2],lf[327],t1,lf[326]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6892(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6892,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1819 posix-error */
t8=lf[1];
f_3458(8,t8,t1,lf[46],t4,t2,t5,t6,t7);}

/* setup in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6821(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6821,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_u_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_u_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t8,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6840,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1811 ##sys#check-port */
t16=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}

/* k6838 in setup in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6840,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6846(t6,t5);}
else{
t5=t3;
f_6846(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6844 in k6838 in setup in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6846,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[325],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6782,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[322]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6799,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6806,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6810,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1794 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6799(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1796 ##sys#error */
t6=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[322],lf[324],t2);}}}

/* k6808 in file-truncate in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1794 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6804 in file-truncate in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6799(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6797 in file-truncate in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1798 posix-error */
t2=lf[1];
f_3458(7,t2,((C_word*)t0)[4],lf[46],lf[322],lf[323],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr5r,(void*)f_6526r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6526r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6526r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6712,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6717,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6722,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?18321923 */
t10=t9;
f_6722(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi18331919 */
t12=t8;
f_6717(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close18341914 */
t14=t7;
f_6712(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body18301840 */
t16=t6;
f_6528(t16,t1,t10,t12,t14);}}}}

/* def-nonblocking?1832 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6722,NULL,2,t0,t1);}
/* def-bufi18331919 */
t2=((C_word*)t0)[2];
f_6717(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1833 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6717,NULL,3,t0,t1,t2);}
/* def-on-close18341914 */
t3=((C_word*)t0)[2];
f_6712(t3,t1,t2,C_fix(0));}

/* def-on-close1834 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6712(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6712,NULL,4,t0,t1,t2,t3);}
/* body18301840 */
t4=((C_word*)t0)[2];
f_6528(t4,t1,t2,t3,*((C_word*)lf[317]+1));}

/* body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6528,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6532,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1736 ##sys#file-nonblocking! */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_6532(2,t6,C_SCHEME_UNDEFINED);}}

/* k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6532,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6534,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6580(t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6624,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6638,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1755 ##sys#make-string */
t12=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6638(2,t12,((C_word*)t0)[6]);}}}

/* k6636 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6580(t4,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6639,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));}

/* f_6639 in k6636 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6639,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6656,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6656(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1771 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6534(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6656,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6666,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1761 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6534(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_difference(t4,t2);
/* posixunix.scm: 1766 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6664 in loop */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1763 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6656(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6624 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6624,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1754 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6534(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6578 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6580,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6595,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1774 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}

/* a6615 in k6578 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
/* posixunix.scm: 1784 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* a6594 in k6578 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6595,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6605,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1781 posix-error */
t3=lf[1];
f_3458(7,t3,t2,lf[46],((C_word*)t0)[3],lf[321],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6605(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6603 in a6594 in k6578 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1782 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6588 in k6578 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6589,3,t0,t1,t2);}
/* posixunix.scm: 1776 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k6582 in k6578 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6584,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6587,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1785 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6585 in k6582 in k6578 in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6534(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6534,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6550,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1744 ##sys#thread-yield! */
t8=*((C_word*)lf[307]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1746 posix-error */
t7=lf[1];
f_3458(7,t7,t1,((C_word*)t0)[3],lf[46],lf[320],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6569,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1748 ##sys#substring */
t7=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6567 in poke in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1748 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6534(t3,((C_word*)t0)[2],t1,t2);}

/* k6548 in poke in k6530 in body1830 in ##sys#custom-output-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1745 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6534(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_6047r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6047r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6047r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(19);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6436,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6441,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6446,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6451,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?15931791 */
t11=t10;
f_6451(t11,t1);}
else{
t11=(C_word)C_u_i_car(t5);
t12=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi15941787 */
t13=t9;
f_6446(t13,t1,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close15951782 */
t15=t8;
f_6441(t15,t1,t11,t13);}
else{
t15=(C_word)C_u_i_car(t14);
t16=(C_word)C_slot(t14,C_fix(1));
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?15961776 */
t17=t7;
f_6436(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_u_i_car(t16);
t18=(C_word)C_slot(t16,C_fix(1));
/* body15911602 */
t19=t6;
f_6049(t19,t1,t11,t13,t15,t17);}}}}}

/* def-nonblocking?1593 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6451,NULL,2,t0,t1);}
/* def-bufi15941787 */
t2=((C_word*)t0)[2];
f_6446(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1594 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6446(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6446,NULL,3,t0,t1,t2);}
/* def-on-close15951782 */
t3=((C_word*)t0)[2];
f_6441(t3,t1,t2,C_fix(1));}

/* def-on-close1595 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6441(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6441,NULL,4,t0,t1,t2,t3);}
/* def-more?15961776 */
t4=((C_word*)t0)[2];
f_6436(t4,t1,t2,t3,*((C_word*)lf[317]+1));}

/* def-more?1596 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6436(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6436,NULL,5,t0,t1,t2,t3,t4);}
/* body15911602 */
t5=((C_word*)t0)[2];
f_6049(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6049,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6053,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1610 ##sys#file-nonblocking! */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_6053(2,t7,C_SCHEME_UNDEFINED);}}

/* k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1612 ##sys#make-string */
t5=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_6059(2,t5,((C_word*)t0)[10]);}}

/* k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6083,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6091,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6173,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6178,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6191,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6224,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6233,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6309,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1660 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t18+1)))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6309,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6315,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_6315(t7,t1,C_SCHEME_FALSE);}

/* loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6315,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6395,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6411,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1725 fetch */
t5=((C_word*)t0)[5];
f_6091(t5,t4);}}

/* k6409 in loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1727 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6315(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a6400 in loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6401,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1722 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6315(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a6394 in loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
/* posixunix.scm: 1720 ##sys#scan-buffer-line */
t2=*((C_word*)lf[316]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6317,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_6324(2,t8,(C_truep(t7)?t7:lf[313]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6367,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1702 ##sys#make-string */
t8=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k6365 in bumper in loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1708 ##sys#string-append */
t6=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_6324(2,t6,t1);}}

/* k6322 in bumper in loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6334,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1712 fetch */
t5=((C_word*)t0)[3];
f_6091(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_u_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1717 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k6332 in k6322 in bumper in loop in a6308 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1713 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6232 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6233,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6241,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_6241(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_6241(t8,(C_word)C_u_fixnum_difference(t7,t5));}}

/* k6239 in a6232 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6241,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6243(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k6239 in a6232 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6243,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* posixunix.scm: 1688 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6291,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1690 fetch */
t7=((C_word*)t0)[2];
f_6091(t7,t6);}}}

/* k6289 in loop in k6239 in a6232 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1693 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6243(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a6223 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6228,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1678 fetch */
t3=((C_word*)t0)[2];
f_6091(t3,t2);}

/* k6226 in a6223 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1679 peek */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_6083(((C_word*)t0)[2]));}

/* a6202 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6203,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6213,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1675 posix-error */
t3=lf[1];
f_3458(7,t3,t2,lf[46],((C_word*)t0)[3],lf[312],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6213(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6211 in a6202 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1676 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6190 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1670 ready? */
t3=((C_word*)t0)[2];
f_6060(t3,t1);}}

/* a6177 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6182,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1662 fetch */
t3=((C_word*)t0)[2];
f_6091(t3,t2);}

/* k6180 in a6177 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_6083(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k6171 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6173,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1729 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6174 in k6171 in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6091,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6103(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6103,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6119,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1637 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[308]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[309]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1640 posix-error */
t5=lf[1];
f_3458(7,t5,t1,lf[46],((C_word*)t0)[6],lf[310],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1644 more? */
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k6138 in loop in fetch in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1646 ##sys#thread-yield! */
t3=*((C_word*)lf[307]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6149,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_6149(2,t8,t7);}
else{
/* posixunix.scm: 1652 posix-error */
t7=lf[1];
f_3458(7,t7,t4,lf[46],((C_word*)t0)[3],lf[311],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_6149(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6147 in k6138 in loop in fetch in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6141 in k6138 in loop in fetch in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1647 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6103(t2,((C_word*)t0)[2]);}

/* k6117 in loop in fetch in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1638 ##sys#thread-yield! */
t3=*((C_word*)lf[307]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6120 in k6117 in loop in fetch in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1639 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6103(t2,((C_word*)t0)[2]);}

/* peek in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_6083(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6060,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1618 ##sys#file-select-one */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6062 in ready? in k6057 in k6051 in body1591 in ##sys#custom-input-port in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1622 posix-error */
t4=lf[1];
f_3458(7,t4,((C_word*)t0)[5],lf[46],((C_word*)t0)[4],lf[306],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6020r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6020r(t0,t1,t2,t3);}}

static void C_ccall f_6020r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[301]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6027,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_6027(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[301]);
t8=t5;
f_6027(t8,(C_word)C_dup2(t2,t6));}}

/* k6025 in duplicate-fileno in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6027(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6027,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6030,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1603 posix-error */
t3=lf[1];
f_3458(6,t3,t2,lf[46],lf[301],lf[302],((C_word*)t0)[2]);}
else{
t3=t2;
f_6030(2,t3,C_SCHEME_UNDEFINED);}}

/* k6028 in k6025 in duplicate-fileno in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5979,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1585 ##sys#check-port */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[295]);}

/* k5977 in port->fileno in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5979,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[296],t2);
if(C_truep(t3)){
/* posixunix.scm: 1586 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1587 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[300]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k6012 in k5977 in port->fileno in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1592 posix-error */
t2=lf[1];
f_3458(6,t2,((C_word*)t0)[3],lf[57],lf[295],lf[298],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5997,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1590 posix-error */
t4=lf[1];
f_3458(6,t4,t3,lf[46],lf[295],lf[299],((C_word*)t0)[2]);}
else{
t4=t3;
f_5997(2,t4,C_SCHEME_UNDEFINED);}}}

/* k5995 in k6012 in k5977 in port->fileno in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5961r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5961r(t0,t1,t2,t3);}}

static void C_ccall f_5961r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[294]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5973,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1581 mode */
f_5895(t5,C_SCHEME_FALSE,t3);}

/* k5971 in open-output-file* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5973,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1581 check */
f_5932(((C_word*)t0)[2],lf[294],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5947r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5947r(t0,t1,t2,t3);}}

static void C_ccall f_5947r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[293]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5959,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1577 mode */
f_5895(t5,C_SCHEME_TRUE,t3);}

/* k5957 in open-input-file* in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5959,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1577 check */
f_5932(((C_word*)t0)[2],lf[293],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5932(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5932,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1570 posix-error */
t6=lf[1];
f_3458(6,t6,t1,lf[46],t2,lf[291],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5945,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1571 ##sys#make-port */
t7=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[145]+1),lf[292],lf[147]);}}

/* k5943 in check in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5895(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5895,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5903,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[285]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1564 ##sys#error */
t8=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[286],t5);}
else{
t8=t4;
f_5903(2,t8,lf[287]);}}
else{
/* posixunix.scm: 1565 ##sys#error */
t7=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[288],t5);}}
else{
t5=t4;
f_5903(2,t5,(C_truep(t2)?lf[289]:lf[290]));}}

/* k5901 in mode in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1560 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5870,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[279]);
t5=(C_word)C_i_check_string_2(t3,lf[279]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5859,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_5859(2,t9,C_SCHEME_FALSE);}}

/* k5857 in file-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_5863(2,t3,C_SCHEME_FALSE);}}

/* k5861 in k5857 in file-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1471(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1545 posix-error */
t3=lf[1];
f_3458(7,t3,((C_word*)t0)[4],lf[46],lf[280],lf[281],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5828,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[277]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5836,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5852,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1534 ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5850 in read-symbolic-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1534 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5834 in read-symbolic-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5839,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1536 posix-error */
t4=lf[1];
f_3458(6,t4,t3,lf[46],lf[277],lf[278],((C_word*)t0)[2]);}
else{
t4=t3;
f_5839(2,t4,C_SCHEME_UNDEFINED);}}

/* k5837 in k5834 in read-symbolic-link in k5825 in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1537 substring */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5790,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[273]);
t5=(C_word)C_i_check_string_2(t3,lf[273]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5811,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5823,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1522 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5821 in create-symbolic-link in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1522 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5809 in create-symbolic-link in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1523 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5817 in k5809 in create-symbolic-link in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1523 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5813 in k5809 in create-symbolic-link in k5786 in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1525 posix-error */
t3=lf[1];
f_3458(7,t3,((C_word*)t0)[4],lf[46],lf[274],lf[275],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5775,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5781,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1493 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5775(2,t4,C_SCHEME_UNDEFINED);}}

/* k5779 in create-session in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1494 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[270],lf[271]);}

/* k5773 in create-session in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5765,3,t0,t1,t2);}
/* posixunix.scm: 1488 check */
f_5729(t1,t2,C_fix((C_word)X_OK),lf[269]);}

/* file-write-access? in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5759,3,t0,t1,t2);}
/* posixunix.scm: 1487 check */
f_5729(t1,t2,C_fix((C_word)W_OK),lf[268]);}

/* file-read-access? in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5753,3,t0,t1,t2);}
/* posixunix.scm: 1486 check */
f_5729(t1,t2,C_fix((C_word)R_OK),lf[267]);}

/* check in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5729(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5729,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5747,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5751,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1483 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5749 in check in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1483 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5745 in check in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5747,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5739,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5739(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1484 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5737 in k5745 in check in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5699,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[265]);
t6=(C_word)C_i_check_exact_2(t3,lf[265]);
t7=(C_word)C_i_check_exact_2(t4,lf[265]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5723,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5727,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1473 ##sys#expand-home-path */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5725 in change-file-owner in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1473 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5721 in change-file-owner in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1474 posix-error */
t3=lf[1];
f_3458(8,t3,((C_word*)t0)[3],lf[46],lf[265],lf[266],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5672,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[263]);
t5=(C_word)C_i_check_exact_2(t3,lf[263]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5693,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5697,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1465 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5695 in change-file-mode in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1465 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5691 in change-file-mode in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1466 posix-error */
t3=lf[1];
f_3458(7,t3,((C_word*)t0)[3],lf[46],lf[263],lf[264],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5608,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[222]);
t5=(C_word)C_i_check_exact_2(t3,lf[222]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5604,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_5604(2,t9,C_SCHEME_FALSE);}}

/* k5602 in initialize-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5604,2,t0,t1);}
t2=(C_word)stub1296(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1386 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5622 in k5602 in initialize-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1387 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[222],lf[223],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5542,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5546,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_5476(t4);
if(C_truep(t5)){
t6=t3;
f_5546(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1369 ##sys#error */
t6=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[219],lf[221]);}}

/* k5544 in set-groups! in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5546,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5551,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5551(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop1272 in k5544 in set-groups! in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5551(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5551,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5567,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1374 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[219]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5565 in doloop1272 in k5544 in set-groups! in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1375 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[219],lf[220],((C_word*)t0)[2]);}

/* get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5483,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5537,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1355 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5483(2,t4,C_SCHEME_UNDEFINED);}}

/* k5535 in get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1356 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[215],lf[218]);}

/* k5481 in get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_5476(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_5486(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1358 ##sys#error */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[215],lf[217]);}}

/* k5484 in k5481 in get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)stub1231(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5518,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1360 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_5489(2,t4,C_SCHEME_UNDEFINED);}}

/* k5516 in k5484 in k5481 in get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1361 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[215],lf[216]);}

/* k5487 in k5484 in k5481 in get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5489,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5494,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5494(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5487 in k5484 in k5481 in get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5494(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5494,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5508,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1365 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k5506 in loop in k5487 in k5484 in k5481 in get-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5508,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_5476(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub1237(C_SCHEME_UNDEFINED,t1));}

/* group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5401r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5401r(t0,t1,t2,t3);}}

static void C_ccall f_5401r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5408,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_5408(t7,(C_word)C_getgrgid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[213]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5459,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1329 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k5457 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5408(t2,(C_word)C_getgrnam(t1));}

/* k5406 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5408,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5416 in k5406 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5422,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k5420 in k5416 in k5406 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5426,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5431,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5431(t6,t2,C_fix(0));}

/* loop in k5420 in k5416 in k5406 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5431,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1189(t5,t4),C_fix(0));}

/* k5433 in loop in k5420 in k5416 in k5406 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5435,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5445,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1338 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5431(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5443 in k5433 in loop in k5420 in k5416 in k5406 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5424 in k5420 in k5416 in k5406 in group-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[210]+1):*((C_word*)lf[211]+1));
t3=t2;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5389,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1314 current-effective-user-id */
t4=*((C_word*)lf[206]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5391 in current-effective-user-name in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1314 user-information */
t2=*((C_word*)lf[209]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5387 in current-effective-user-name in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5375,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1311 current-user-id */
t4=*((C_word*)lf[205]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5377 in current-user-name in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1311 user-information */
t2=*((C_word*)lf[209]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5373 in current-user-name in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5307r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5307r(t0,t1,t2,t3);}}

static void C_ccall f_5307r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5314,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_5314(t7,(C_word)C_getpwuid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[209]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5353,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1299 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k5351 in user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5314(t2,(C_word)C_getpwnam(t1));}

/* k5312 in user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5314,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5322 in k5312 in user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5328,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k5326 in k5322 in k5312 in user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5332,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k5330 in k5326 in k5322 in k5312 in user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5336,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5334 in k5330 in k5326 in k5322 in k5312 in user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5340,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k5338 in k5334 in k5330 in k5326 in k5322 in k5312 in user-information in k5303 in k5299 in k5295 in k5291 in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[210]+1):*((C_word*)lf[211]+1));
t3=t2;
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5257,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1244 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_5257(2,t3,C_SCHEME_UNDEFINED);}}

/* k5284 in system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1245 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[202],lf[204]);}

/* k5255 in system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k5262 in k5255 in system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5268,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k5266 in k5262 in k5255 in system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5272,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k5270 in k5266 in k5262 in k5255 in system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5276,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k5274 in k5270 in k5266 in k5262 in k5255 in system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5280,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k5278 in k5274 in k5270 in k5266 in k5262 in k5255 in system-information in k5249 in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5280,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5235,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[200]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1223 posix-error */
t5=lf[1];
f_3458(5,t5,t1,lf[194],lf[200],lf[201]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5220,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[198]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1217 posix-error */
t5=lf[1];
f_3458(5,t5,t1,lf[194],lf[198],lf[199]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5214,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[197]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5182,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5188,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5188(t5,t1,*((C_word*)lf[189]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5188(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5188,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1207 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5158,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[193]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5176,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5175 in set-signal-mask! in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5176,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[193]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k5163 in set-signal-mask! in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1200 posix-error */
t2=lf[1];
f_3458(5,t2,((C_word*)t0)[2],lf[194],lf[193],lf[195]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5140,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5150,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1186 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1188 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k5148 in ##sys#interrupt-hook in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1187 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5127,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[192]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k5114 in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5118,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[191]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1103 posix-error */
t3=lf[1];
f_3458(5,t3,t2,lf[46],lf[162],lf[163]);}
else{
t3=t2;
f_5075(2,t3,C_SCHEME_UNDEFINED);}}

/* k5073 in create-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1104 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5051r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5051r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[161]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5055,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5053 in with-output-to-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5061,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1091 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5060 in k5053 in with-output-to-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5061r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5061r(t0,t1,t2);}}

static void C_ccall f_5061r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5065,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1093 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5063 in a5060 in k5053 in with-output-to-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5031r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5031r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[159]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5035,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5033 in with-input-from-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=C_mutate((C_word*)lf[159]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5041,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1081 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5040 in k5033 in with-input-from-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5041r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5041r(t0,t1,t2);}}

static void C_ccall f_5041r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5045,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1083 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5043 in a5040 in k5033 in with-input-from-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[159]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5007r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5007r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5007r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5011,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5009 in call-with-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5016,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5022,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1071 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5021 in k5009 in call-with-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5022r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5022r(t0,t1,t2);}}

static void C_ccall f_5022r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5026,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1074 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5024 in a5021 in k5009 in call-with-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5015 in k5009 in call-with-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
/* posixunix.scm: 1072 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4983r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4983r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4983r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4987,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4985 in call-with-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4992,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4998,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1063 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4997 in k4985 in call-with-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4998r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4998r(t0,t1,t2);}}

static void C_ccall f_4998r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5002,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1066 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5000 in a4997 in k4985 in call-with-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4991 in k4985 in call-with-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
/* posixunix.scm: 1064 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4967,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4971,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1050 ##sys#check-port */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[151]);}

/* k4969 in close-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4974,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1052 posix-error */
t5=lf[1];
f_3458(6,t5,t3,lf[46],lf[152],lf[153],((C_word*)t0)[3]);}
else{
t5=t3;
f_4974(2,t5,C_SCHEME_UNDEFINED);}}

/* k4972 in k4969 in close-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4931r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4931r(t0,t1,t2,t3);}}

static void C_ccall f_4931r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[150]);
t5=f_4862(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4945,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[140]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4952,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1045 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[149]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4962,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1046 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1047 badmode */
f_4874(t6,t5);}}}

/* k4960 in open-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4945(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4950 in open-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4945(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4943 in open-output-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1041 check */
f_4880(((C_word*)t0)[3],lf[150],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4895r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4895r(t0,t1,t2,t3);}}

static void C_ccall f_4895r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[148]);
t5=f_4862(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4909,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[140]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4916,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1034 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[149]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4926,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1035 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1036 badmode */
f_4874(t6,t5);}}}

/* k4924 in open-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4926,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4909(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4914 in open-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4909(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4907 in open-input-pipe in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1030 check */
f_4880(((C_word*)t0)[3],lf[148],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4880(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4880,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1022 posix-error */
t6=lf[1];
f_3458(6,t6,t1,lf[46],t2,lf[143],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4893,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1023 ##sys#make-port */
t7=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[145]+1),lf[146],lf[147]);}}

/* k4891 in check in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4874(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4874,NULL,2,t1,t2);}
/* posixunix.scm: 1019 ##sys#error */
t3=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[142],t2);}

/* mode in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_4862(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[140]));}

/* canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4545,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4552,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4666,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 967  cwd */
t8=((C_word*)t0)[6];
f_4489(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 969  sref */
t10=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_4672(t9,C_SCHEME_FALSE);}}}

/* k4850 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 969  sep? */
t2=((C_word*)t0)[3];
f_4672(t2,f_4478(t1));}

/* k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4672,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_4552(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 972  cwd */
t5=((C_word*)t0)[8];
f_4489(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4838,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 973  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4836 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 973  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4825 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 974  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4691(t2,C_SCHEME_FALSE);}}

/* k4832 in k4825 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  sep? */
t2=((C_word*)t0)[3];
f_4691(t2,f_4478(t1));}

/* k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4691,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4698,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 976  getenv */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[137]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 981  cwd */
t5=((C_word*)t0)[6];
f_4489(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4820,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 982  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4818 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 982  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4797 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4816,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 983  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_4735(t2,C_SCHEME_FALSE);}}

/* k4814 in k4797 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 983  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4803 in k4797 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4805,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 984  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_4735(t2,C_SCHEME_FALSE);}}

/* k4810 in k4803 in k4797 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 984  sep? */
t2=((C_word*)t0)[3];
f_4735(t2,f_4478(t1));}

/* k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4735,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 985  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4796,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 986  sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k4794 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4773 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4792,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4748(2,t2,C_SCHEME_FALSE);}}

/* k4790 in k4773 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 987  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4779 in k4773 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 988  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4748(2,t2,C_SCHEME_FALSE);}}

/* k4786 in k4779 in k4773 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4746 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 989  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 990  sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k4770 in k4746 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4772,2,t0,t1);}
t2=f_4478(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_4552(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4768,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 993  cwd */
t4=((C_word*)t0)[2];
f_4489(t4,t3);}}

/* k4766 in k4770 in k4746 in k4733 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 993  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[139],((C_word*)t0)[2]);}

/* k4727 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 981  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k4696 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4701(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4716,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 977  user */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4714 in k4696 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k4699 in k4696 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4705,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 978  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4703 in k4699 in k4696 in k4689 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 975  sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4683 in k4670 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 972  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[135],((C_word*)t0)[2]);}

/* k4664 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 967  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[134]);}

/* k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
t4=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[133]);}

/* k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_4561(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4561(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4561,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 996  null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4568,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 997  null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4629,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1008 string=? */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[132],t5);}}

/* k4630 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4629(t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1010 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[131],t3);}}

/* k4639 in k4630 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4629(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4629(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k4627 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1006 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4561(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4572 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4574,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[126]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 999  sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k4608 in k4572 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
t2=f_4478(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4591,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[128],((C_word*)t0)[2]);
/* posixunix.scm: 1002 reverse */
t6=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1005 reverse */
t5=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4604 in k4608 in k4572 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1005 isperse */
f_4473(((C_word*)t0)[2],t1);}

/* k4600 in k4608 in k4572 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1003 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* k4589 in k4608 in k4572 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1002 isperse */
f_4473(((C_word*)t0)[2],t1);}

/* k4585 in k4608 in k4572 in k4566 in loop in k4557 in k4550 in canonical-path in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1000 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[127],t1);}

/* cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4489,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4496,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a4497 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4498,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4504,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4522,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a4521 in a4497 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a4533 in a4521 in a4497 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4534r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4534r(t0,t1,t2);}}

static void C_ccall f_4534r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4540,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k792798 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a4539 in a4533 in a4521 in a4497 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4540,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4527 in a4521 in a4497 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
/* posixunix.scm: 962  cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a4503 in a4497 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4504,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4510,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k792798 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a4509 in a4503 in a4497 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[122]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[123]);}

/* k4494 in cwd in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* sep? in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_4478(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4473(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4473,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[119]);}

/* current-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4432r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4432r(t0,t1,t2);}}

static void C_ccall f_4432r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixunix.scm: 940  change-directory */
t5=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 941  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k4443 in current-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 944  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 945  posix-error */
t3=lf[1];
f_3458(5,t3,((C_word*)t0)[2],lf[46],lf[110],lf[113]);}}

/* directory? in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4409,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[111]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4416,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4430,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 933  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4428 in directory? in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 933  ##sys#file-info */
t2=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4414 in directory? in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_4255r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4255r(t0,t1,t2);}}

static void C_ccall f_4255r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4355,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4360,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec640697 */
t6=t5;
f_4360(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?641693 */
t8=t4;
f_4355(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body638647 */
t10=t3;
f_4257(t10,t1,t6,t8);}}}

/* def-spec640 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4360,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4368,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 906  current-directory */
t3=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4366 in def-spec640 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?641693 */
t2=((C_word*)t0)[3];
f_4355(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?641 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4355,NULL,3,t0,t1,t2);}
/* body638647 */
t3=((C_word*)t0)[2];
f_4257(t3,t1,t2,C_SCHEME_FALSE);}

/* body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4257(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4257,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[107]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 908  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 909  ##sys#make-pointer */
t3=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 910  ##sys#make-pointer */
t3=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4354,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 911  ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4352 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 911  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4272 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 913  posix-error */
t3=lf[1];
f_3458(6,t3,((C_word*)t0)[7],lf[46],lf[107],lf[108],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4288(t6,((C_word*)t0)[7]);}}

/* loop in k4272 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4288,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 921  ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k4296 in loop in k4272 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 922  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k4299 in k4296 in loop in k4272 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 923  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_4304(2,t3,C_SCHEME_FALSE);}}

/* k4302 in k4299 in k4296 in loop in k4272 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_4310(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_4310(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_4310(t4,C_SCHEME_FALSE);}}

/* k4308 in k4302 in k4299 in k4296 in loop in k4272 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4310,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 928  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4288(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 929  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4288(t3,t2);}}

/* k4318 in k4308 in k4302 in k4299 in k4296 in loop in k4272 in k4268 in k4265 in k4262 in body638 in directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4231,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4249,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4253,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 899  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4251 in delete-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 899  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4247 in delete-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 900  posix-error */
t3=lf[1];
f_3458(6,t3,((C_word*)t0)[3],lf[46],lf[103],lf[104],((C_word*)t0)[2]);}}

/* change-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4207,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[101]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4225,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 893  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4227 in change-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 893  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4223 in change-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 894  posix-error */
t3=lf[1];
f_3458(6,t3,((C_word*)t0)[3],lf[46],lf[101],lf[102],((C_word*)t0)[2]);}}

/* create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4106r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4106r(t0,t1,t2,t3);}}

static void C_ccall f_4106r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[91]);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4119,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 885  canonical-path */
t8=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4179,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 886  canonical-path */
t8=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k4177 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4193,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 855  ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4191 in k4177 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 856  posix-error */
t3=lf[1];
f_3458(6,t3,((C_word*)t0)[3],lf[46],lf[91],lf[93],((C_word*)t0)[2]);}}

/* k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=lf[92];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4176,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 879  string-split */
t6=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[99]);}

/* k4174 in k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4123 in k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4124,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 877  string-append */
t4=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[97],t2);}

/* k4127 in a4123 in k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 860  file-exists? */
t6=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k4150 in k4127 in a4123 in k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 861  ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4135(2,t2,C_SCHEME_FALSE);}}

/* k4170 in k4150 in k4127 in a4123 in k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 862  posix-error */
t3=lf[1];
f_3458(6,t3,((C_word*)t0)[3],lf[46],lf[91],lf[94],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4135(2,t4,t3);}
else{
/* posixunix.scm: 865  posix-error */
t4=lf[1];
f_3458(6,t4,((C_word*)t0)[3],lf[46],lf[91],lf[95],((C_word*)t0)[2]);}}}

/* k4133 in k4127 in a4123 in k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 855  ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4147 in k4133 in k4127 in a4123 in k4117 in create-directory in k4102 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 856  posix-error */
t3=lf[1];
f_3458(6,t3,((C_word*)t0)[3],lf[46],lf[91],lf[93],((C_word*)t0)[2]);}}

/* stat-socket? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4093,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4100,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 824  ##sys#stat */
f_3923(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k4098 in stat-socket? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4084,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4091,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 819  ##sys#stat */
f_3923(t4,t2,C_SCHEME_TRUE,lf[88]);}

/* k4089 in stat-symlink? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4075,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4082,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 814  ##sys#stat */
f_3923(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k4080 in stat-fifo? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4066,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 809  ##sys#stat */
f_3923(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k4071 in stat-block-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4057,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 804  ##sys#stat */
f_3923(t4,t2,C_SCHEME_FALSE,lf[85]);}

/* k4062 in stat-char-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4048,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 799  ##sys#stat */
f_3923(t4,t2,C_SCHEME_FALSE,lf[84]);}

/* k4053 in stat-directory? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4039,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4046,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 794  ##sys#stat */
f_3923(t4,t2,C_SCHEME_FALSE,lf[83]);}

/* k4044 in stat-regular? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4030,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[82]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4037,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 789  ##sys#stat */
f_3923(t4,t2,C_SCHEME_TRUE,lf[82]);}

/* k4035 in symbolic-link? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4021,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[81]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4028,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 784  ##sys#stat */
f_3923(t4,t2,C_SCHEME_TRUE,lf[81]);}

/* k4026 in regular-file? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4015,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4019,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_3923(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k4017 in file-permissions in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4009,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_3923(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k4011 in file-owner in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4003,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_3923(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k4005 in file-change-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3997,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4001,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_3923(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k3999 in file-access-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3991,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3995,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_3923(t3,t2,C_SCHEME_FALSE,lf[76]);}

/* k3993 in file-modification-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3989,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 775  ##sys#stat */
f_3923(t3,t2,C_SCHEME_FALSE,lf[75]);}

/* k3987 in file-size in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3960r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3960r(t0,t1,t2,t3);}}

static void C_ccall f_3960r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3964,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* posixunix.scm: 768  ##sys#stat */
f_3923(t4,t2,t6,lf[74]);}

/* k3962 in file-stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3923(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3923,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3927,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3927(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3948,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3955,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 759  ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 763  ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[57],lf[73],t2);}}}

/* k3953 in ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 759  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3946 in ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3927(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3925 in ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 765  posix-error */
t2=lf[1];
f_3458(6,t2,((C_word*)t0)[4],lf[46],((C_word*)t0)[3],lf[72],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3731r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3731r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(15);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_3725(C_fix(0));
t10=f_3725(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_3747(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 688  fd_set */
t14=t12;
f_3747(2,t14,f_3727(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[65]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a3903 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3904,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[65]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 695  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3727(C_fix(0),t2));}

/* k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3753(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 700  fd_set */
t5=t3;
f_3753(2,t5,f_3727(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[65]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a3877 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3878,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[65]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 707  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3727(C_fix(1),t2));}

/* k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[65]);
t4=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_3756(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_3756(t4,(C_word)C_C_select(t3));}}

/* k3754 in k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3756,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 714  posix-error */
t2=lf[1];
f_3458(7,t2,((C_word*)t0)[5],lf[46],lf[65],lf[66],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 715  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 720  fd_test */
t4=t3;
f_3795(t4,f_3729(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3836,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3838,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t8=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_3795(t4,C_SCHEME_FALSE);}}}}

/* a3837 in k3754 in k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3838,3,t0,t1,t2);}
t3=f_3729(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3834 in k3754 in k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3795(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3793 in k3754 in k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3795,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3799,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 726  fd_test */
t3=t2;
f_3799(t3,f_3729(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3811,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_3799(t3,C_SCHEME_FALSE);}}

/* a3812 in k3793 in k3754 in k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3813,3,t0,t1,t2);}
t3=f_3729(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3809 in k3793 in k3754 in k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3799(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3797 in k3793 in k3754 in k3751 in k3745 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 717  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_3729(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub252(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_set in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_3727(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub245(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_zero in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_3725(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub239(C_SCHEME_UNDEFINED,t1));}

/* file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3693,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[62]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 666  ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3698 in file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3706,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 670  posix-error */
t6=lf[1];
f_3458(6,t6,t4,lf[46],lf[62],lf[64],((C_word*)t0)[2]);}
else{
t6=t4;
f_3706(2,t6,C_SCHEME_UNDEFINED);}}

/* k3704 in k3698 in file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 671  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k3711 in k3704 in k3698 in file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 671  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3654r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3654r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[59]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3661,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_3661(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 655  ##sys#signal-hook */
t8=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[57],lf[59],lf[61],t3);}}

/* k3659 in file-write in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3661,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[59]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3670,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 660  posix-error */
t8=lf[1];
f_3458(7,t8,t6,lf[46],lf[59],lf[60],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_3670(2,t8,C_SCHEME_UNDEFINED);}}

/* k3668 in k3659 in file-write in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3612r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3612r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3612r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[55]);
t6=(C_word)C_i_check_exact_2(t3,lf[55]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3622,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_3622(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixunix.scm: 643  make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k3620 in file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_3625(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 645  ##sys#signal-hook */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[57],lf[55],lf[58],t1);}}

/* k3623 in k3620 in file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3628,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 648  posix-error */
t5=lf[1];
f_3458(7,t5,t3,lf[46],lf[55],lf[56],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_3628(2,t5,C_SCHEME_UNDEFINED);}}

/* k3626 in k3623 in k3620 in file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3597,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[52]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 636  posix-error */
t4=lf[1];
f_3458(6,t4,t1,lf[46],lf[52],lf[53],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3559r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3559r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[48]);
t8=(C_word)C_i_check_exact_2(t3,lf[48]);
t9=(C_word)C_i_check_exact_2(t6,lf[48]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3576,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 627  ##sys#expand-home-path */
t12=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k3587 in file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 627  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3574 in file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3579,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 629  posix-error */
t5=lf[1];
f_3458(8,t5,t3,lf[46],lf[48],lf[49],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_3579(2,t5,C_SCHEME_UNDEFINED);}}

/* k3577 in k3574 in file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3520r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3520r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_exact_2(t2,lf[45]);
t8=(C_word)C_i_check_exact_2(t3,lf[45]);
t9=t2;
t10=t3;
t11=(C_word)stub124(C_SCHEME_UNDEFINED,t9,t10,t6);
t12=(C_word)C_eqp(t11,C_fix(-1));
if(C_truep(t12)){
/* posixunix.scm: 617  posix-error */
t13=lf[1];
f_3458(7,t13,t1,lf[46],lf[45],lf[47],t2,t3);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t11);}}

/* ##sys#file-select-one in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3479,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub46(C_SCHEME_UNDEFINED,t2));}

/* ##sys#file-nonblocking! in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3476,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub40(C_SCHEME_UNDEFINED,t2));}

/* posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_3458r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3458r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3458r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3462,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 507  ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3460 in posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub23(t4,t1),C_fix(0));}

/* k3471 in k3460 in posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 508  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[3],t1);}

/* k3467 in k3460 in posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[2]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[610] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_3433:posixunix_scm",(void*)f_3433},
{"f_3436:posixunix_scm",(void*)f_3436},
{"f_3439:posixunix_scm",(void*)f_3439},
{"f_3442:posixunix_scm",(void*)f_3442},
{"f_3445:posixunix_scm",(void*)f_3445},
{"f_3448:posixunix_scm",(void*)f_3448},
{"f_3451:posixunix_scm",(void*)f_3451},
{"f_9064:posixunix_scm",(void*)f_9064},
{"f_9077:posixunix_scm",(void*)f_9077},
{"f_9089:posixunix_scm",(void*)f_9089},
{"f_9083:posixunix_scm",(void*)f_9083},
{"f_9027:posixunix_scm",(void*)f_9027},
{"f_9043:posixunix_scm",(void*)f_9043},
{"f_9031:posixunix_scm",(void*)f_9031},
{"f_9034:posixunix_scm",(void*)f_9034},
{"f_4104:posixunix_scm",(void*)f_4104},
{"f_5116:posixunix_scm",(void*)f_5116},
{"f_9021:posixunix_scm",(void*)f_9021},
{"f_5251:posixunix_scm",(void*)f_5251},
{"f_9006:posixunix_scm",(void*)f_9006},
{"f_9016:posixunix_scm",(void*)f_9016},
{"f_9003:posixunix_scm",(void*)f_9003},
{"f_5293:posixunix_scm",(void*)f_5293},
{"f_8988:posixunix_scm",(void*)f_8988},
{"f_8998:posixunix_scm",(void*)f_8998},
{"f_8985:posixunix_scm",(void*)f_8985},
{"f_5297:posixunix_scm",(void*)f_5297},
{"f_8970:posixunix_scm",(void*)f_8970},
{"f_8980:posixunix_scm",(void*)f_8980},
{"f_8967:posixunix_scm",(void*)f_8967},
{"f_5301:posixunix_scm",(void*)f_5301},
{"f_8952:posixunix_scm",(void*)f_8952},
{"f_8962:posixunix_scm",(void*)f_8962},
{"f_8949:posixunix_scm",(void*)f_8949},
{"f_5305:posixunix_scm",(void*)f_5305},
{"f_8928:posixunix_scm",(void*)f_8928},
{"f_8944:posixunix_scm",(void*)f_8944},
{"f_8910:posixunix_scm",(void*)f_8910},
{"f_8923:posixunix_scm",(void*)f_8923},
{"f_8917:posixunix_scm",(void*)f_8917},
{"f_5788:posixunix_scm",(void*)f_5788},
{"f_5827:posixunix_scm",(void*)f_5827},
{"f_8887:posixunix_scm",(void*)f_8887},
{"f_8883:posixunix_scm",(void*)f_8883},
{"f_8635:posixunix_scm",(void*)f_8635},
{"f_8812:posixunix_scm",(void*)f_8812},
{"f_8818:posixunix_scm",(void*)f_8818},
{"f_8807:posixunix_scm",(void*)f_8807},
{"f_8802:posixunix_scm",(void*)f_8802},
{"f_8637:posixunix_scm",(void*)f_8637},
{"f_8789:posixunix_scm",(void*)f_8789},
{"f_8797:posixunix_scm",(void*)f_8797},
{"f_8644:posixunix_scm",(void*)f_8644},
{"f_8777:posixunix_scm",(void*)f_8777},
{"f_8771:posixunix_scm",(void*)f_8771},
{"f_8654:posixunix_scm",(void*)f_8654},
{"f_8656:posixunix_scm",(void*)f_8656},
{"f_8675:posixunix_scm",(void*)f_8675},
{"f_8757:posixunix_scm",(void*)f_8757},
{"f_8764:posixunix_scm",(void*)f_8764},
{"f_8751:posixunix_scm",(void*)f_8751},
{"f_8690:posixunix_scm",(void*)f_8690},
{"f_8744:posixunix_scm",(void*)f_8744},
{"f_8741:posixunix_scm",(void*)f_8741},
{"f_8731:posixunix_scm",(void*)f_8731},
{"f_8707:posixunix_scm",(void*)f_8707},
{"f_8729:posixunix_scm",(void*)f_8729},
{"f_8715:posixunix_scm",(void*)f_8715},
{"f_8722:posixunix_scm",(void*)f_8722},
{"f_8719:posixunix_scm",(void*)f_8719},
{"f_8702:posixunix_scm",(void*)f_8702},
{"f_8700:posixunix_scm",(void*)f_8700},
{"f_8778:posixunix_scm",(void*)f_8778},
{"f_8578:posixunix_scm",(void*)f_8578},
{"f_8590:posixunix_scm",(void*)f_8590},
{"f_8585:posixunix_scm",(void*)f_8585},
{"f_8580:posixunix_scm",(void*)f_8580},
{"f_8521:posixunix_scm",(void*)f_8521},
{"f_8533:posixunix_scm",(void*)f_8533},
{"f_8528:posixunix_scm",(void*)f_8528},
{"f_8523:posixunix_scm",(void*)f_8523},
{"f_8460:posixunix_scm",(void*)f_8460},
{"f_8515:posixunix_scm",(void*)f_8515},
{"f_8519:posixunix_scm",(void*)f_8519},
{"f_8481:posixunix_scm",(void*)f_8481},
{"f_8484:posixunix_scm",(void*)f_8484},
{"f_8495:posixunix_scm",(void*)f_8495},
{"f_8489:posixunix_scm",(void*)f_8489},
{"f_8462:posixunix_scm",(void*)f_8462},
{"f_8471:posixunix_scm",(void*)f_8471},
{"f_8402:posixunix_scm",(void*)f_8402},
{"f_8414:posixunix_scm",(void*)f_8414},
{"f_8445:posixunix_scm",(void*)f_8445},
{"f_8425:posixunix_scm",(void*)f_8425},
{"f_8441:posixunix_scm",(void*)f_8441},
{"f_8429:posixunix_scm",(void*)f_8429},
{"f_8437:posixunix_scm",(void*)f_8437},
{"f_8433:posixunix_scm",(void*)f_8433},
{"f_8408:posixunix_scm",(void*)f_8408},
{"f_8391:posixunix_scm",(void*)f_8391},
{"f_8395:posixunix_scm",(void*)f_8395},
{"f_8380:posixunix_scm",(void*)f_8380},
{"f_8384:posixunix_scm",(void*)f_8384},
{"f_8335:posixunix_scm",(void*)f_8335},
{"f_8339:posixunix_scm",(void*)f_8339},
{"f_8342:posixunix_scm",(void*)f_8342},
{"f_8345:posixunix_scm",(void*)f_8345},
{"f_8358:posixunix_scm",(void*)f_8358},
{"f_8362:posixunix_scm",(void*)f_8362},
{"f_8365:posixunix_scm",(void*)f_8365},
{"f_8368:posixunix_scm",(void*)f_8368},
{"f_8356:posixunix_scm",(void*)f_8356},
{"f_8319:posixunix_scm",(void*)f_8319},
{"f_8302:posixunix_scm",(void*)f_8302},
{"f_8315:posixunix_scm",(void*)f_8315},
{"f_8227:posixunix_scm",(void*)f_8227},
{"f_8288:posixunix_scm",(void*)f_8288},
{"f_8301:posixunix_scm",(void*)f_8301},
{"f_8268:posixunix_scm",(void*)f_8268},
{"f_8283:posixunix_scm",(void*)f_8283},
{"f_8277:posixunix_scm",(void*)f_8277},
{"f_8231:posixunix_scm",(void*)f_8231},
{"f_8233:posixunix_scm",(void*)f_8233},
{"f_8254:posixunix_scm",(void*)f_8254},
{"f_8248:posixunix_scm",(void*)f_8248},
{"f_8175:posixunix_scm",(void*)f_8175},
{"f_8182:posixunix_scm",(void*)f_8182},
{"f_8201:posixunix_scm",(void*)f_8201},
{"f_8205:posixunix_scm",(void*)f_8205},
{"f_8169:posixunix_scm",(void*)f_8169},
{"f_8160:posixunix_scm",(void*)f_8160},
{"f_8164:posixunix_scm",(void*)f_8164},
{"f_8133:posixunix_scm",(void*)f_8133},
{"f_8130:posixunix_scm",(void*)f_8130},
{"f_8127:posixunix_scm",(void*)f_8127},
{"f_8124:posixunix_scm",(void*)f_8124},
{"f_8049:posixunix_scm",(void*)f_8049},
{"f_8082:posixunix_scm",(void*)f_8082},
{"f_8076:posixunix_scm",(void*)f_8076},
{"f_8032:posixunix_scm",(void*)f_8032},
{"f_7853:posixunix_scm",(void*)f_7853},
{"f_7987:posixunix_scm",(void*)f_7987},
{"f_7982:posixunix_scm",(void*)f_7982},
{"f_7855:posixunix_scm",(void*)f_7855},
{"f_7865:posixunix_scm",(void*)f_7865},
{"f_7873:posixunix_scm",(void*)f_7873},
{"f_7919:posixunix_scm",(void*)f_7919},
{"f_7886:posixunix_scm",(void*)f_7886},
{"f_7911:posixunix_scm",(void*)f_7911},
{"f_7889:posixunix_scm",(void*)f_7889},
{"f_7845:posixunix_scm",(void*)f_7845},
{"f_7837:posixunix_scm",(void*)f_7837},
{"f_7799:posixunix_scm",(void*)f_7799},
{"f_7821:posixunix_scm",(void*)f_7821},
{"f_7825:posixunix_scm",(void*)f_7825},
{"f_7690:posixunix_scm",(void*)f_7690},
{"f_7696:posixunix_scm",(void*)f_7696},
{"f_7717:posixunix_scm",(void*)f_7717},
{"f_7791:posixunix_scm",(void*)f_7791},
{"f_7721:posixunix_scm",(void*)f_7721},
{"f_7724:posixunix_scm",(void*)f_7724},
{"f_7731:posixunix_scm",(void*)f_7731},
{"f_7733:posixunix_scm",(void*)f_7733},
{"f_7750:posixunix_scm",(void*)f_7750},
{"f_7760:posixunix_scm",(void*)f_7760},
{"f_7764:posixunix_scm",(void*)f_7764},
{"f_7711:posixunix_scm",(void*)f_7711},
{"f_7678:posixunix_scm",(void*)f_7678},
{"f_7682:posixunix_scm",(void*)f_7682},
{"f_7685:posixunix_scm",(void*)f_7685},
{"f_7643:posixunix_scm",(void*)f_7643},
{"f_7647:posixunix_scm",(void*)f_7647},
{"f_7667:posixunix_scm",(void*)f_7667},
{"f_7671:posixunix_scm",(void*)f_7671},
{"f_7624:posixunix_scm",(void*)f_7624},
{"f_7628:posixunix_scm",(void*)f_7628},
{"f_7597:posixunix_scm",(void*)f_7597},
{"f_7601:posixunix_scm",(void*)f_7601},
{"f_7578:posixunix_scm",(void*)f_7578},
{"f_7582:posixunix_scm",(void*)f_7582},
{"f_7585:posixunix_scm",(void*)f_7585},
{"f_7519:posixunix_scm",(void*)f_7519},
{"f_7523:posixunix_scm",(void*)f_7523},
{"f_7529:posixunix_scm",(void*)f_7529},
{"f_7516:posixunix_scm",(void*)f_7516},
{"f_7500:posixunix_scm",(void*)f_7500},
{"f_7492:posixunix_scm",(void*)f_7492},
{"f_7477:posixunix_scm",(void*)f_7477},
{"f_7481:posixunix_scm",(void*)f_7481},
{"f_7462:posixunix_scm",(void*)f_7462},
{"f_7466:posixunix_scm",(void*)f_7466},
{"f_7423:posixunix_scm",(void*)f_7423},
{"f_7440:posixunix_scm",(void*)f_7440},
{"f_7444:posixunix_scm",(void*)f_7444},
{"f_7361:posixunix_scm",(void*)f_7361},
{"f_7368:posixunix_scm",(void*)f_7368},
{"f_7390:posixunix_scm",(void*)f_7390},
{"f_7387:posixunix_scm",(void*)f_7387},
{"f_7377:posixunix_scm",(void*)f_7377},
{"f_7325:posixunix_scm",(void*)f_7325},
{"f_7332:posixunix_scm",(void*)f_7332},
{"f_7311:posixunix_scm",(void*)f_7311},
{"f_7302:posixunix_scm",(void*)f_7302},
{"f_7283:posixunix_scm",(void*)f_7283},
{"f_7277:posixunix_scm",(void*)f_7277},
{"f_7268:posixunix_scm",(void*)f_7268},
{"f_7233:posixunix_scm",(void*)f_7233},
{"f_7175:posixunix_scm",(void*)f_7175},
{"f_7179:posixunix_scm",(void*)f_7179},
{"f_7185:posixunix_scm",(void*)f_7185},
{"f_7204:posixunix_scm",(void*)f_7204},
{"f_7191:posixunix_scm",(void*)f_7191},
{"f_7091:posixunix_scm",(void*)f_7091},
{"f_7097:posixunix_scm",(void*)f_7097},
{"f_7101:posixunix_scm",(void*)f_7101},
{"f_7109:posixunix_scm",(void*)f_7109},
{"f_7135:posixunix_scm",(void*)f_7135},
{"f_7139:posixunix_scm",(void*)f_7139},
{"f_7127:posixunix_scm",(void*)f_7127},
{"f_7076:posixunix_scm",(void*)f_7076},
{"f_7084:posixunix_scm",(void*)f_7084},
{"f_7059:posixunix_scm",(void*)f_7059},
{"f_7070:posixunix_scm",(void*)f_7070},
{"f_7074:posixunix_scm",(void*)f_7074},
{"f_7033:posixunix_scm",(void*)f_7033},
{"f_7057:posixunix_scm",(void*)f_7057},
{"f_7040:posixunix_scm",(void*)f_7040},
{"f_6990:posixunix_scm",(void*)f_6990},
{"f_6997:posixunix_scm",(void*)f_6997},
{"f_7018:posixunix_scm",(void*)f_7018},
{"f_7014:posixunix_scm",(void*)f_7014},
{"f_6962:posixunix_scm",(void*)f_6962},
{"f_6940:posixunix_scm",(void*)f_6940},
{"f_6944:posixunix_scm",(void*)f_6944},
{"f_6925:posixunix_scm",(void*)f_6925},
{"f_6929:posixunix_scm",(void*)f_6929},
{"f_6910:posixunix_scm",(void*)f_6910},
{"f_6914:posixunix_scm",(void*)f_6914},
{"f_6892:posixunix_scm",(void*)f_6892},
{"f_6821:posixunix_scm",(void*)f_6821},
{"f_6840:posixunix_scm",(void*)f_6840},
{"f_6846:posixunix_scm",(void*)f_6846},
{"f_6782:posixunix_scm",(void*)f_6782},
{"f_6810:posixunix_scm",(void*)f_6810},
{"f_6806:posixunix_scm",(void*)f_6806},
{"f_6799:posixunix_scm",(void*)f_6799},
{"f_6526:posixunix_scm",(void*)f_6526},
{"f_6722:posixunix_scm",(void*)f_6722},
{"f_6717:posixunix_scm",(void*)f_6717},
{"f_6712:posixunix_scm",(void*)f_6712},
{"f_6528:posixunix_scm",(void*)f_6528},
{"f_6532:posixunix_scm",(void*)f_6532},
{"f_6638:posixunix_scm",(void*)f_6638},
{"f_6639:posixunix_scm",(void*)f_6639},
{"f_6656:posixunix_scm",(void*)f_6656},
{"f_6666:posixunix_scm",(void*)f_6666},
{"f_6624:posixunix_scm",(void*)f_6624},
{"f_6580:posixunix_scm",(void*)f_6580},
{"f_6616:posixunix_scm",(void*)f_6616},
{"f_6595:posixunix_scm",(void*)f_6595},
{"f_6605:posixunix_scm",(void*)f_6605},
{"f_6589:posixunix_scm",(void*)f_6589},
{"f_6584:posixunix_scm",(void*)f_6584},
{"f_6587:posixunix_scm",(void*)f_6587},
{"f_6534:posixunix_scm",(void*)f_6534},
{"f_6569:posixunix_scm",(void*)f_6569},
{"f_6550:posixunix_scm",(void*)f_6550},
{"f_6047:posixunix_scm",(void*)f_6047},
{"f_6451:posixunix_scm",(void*)f_6451},
{"f_6446:posixunix_scm",(void*)f_6446},
{"f_6441:posixunix_scm",(void*)f_6441},
{"f_6436:posixunix_scm",(void*)f_6436},
{"f_6049:posixunix_scm",(void*)f_6049},
{"f_6053:posixunix_scm",(void*)f_6053},
{"f_6059:posixunix_scm",(void*)f_6059},
{"f_6309:posixunix_scm",(void*)f_6309},
{"f_6315:posixunix_scm",(void*)f_6315},
{"f_6411:posixunix_scm",(void*)f_6411},
{"f_6401:posixunix_scm",(void*)f_6401},
{"f_6395:posixunix_scm",(void*)f_6395},
{"f_6317:posixunix_scm",(void*)f_6317},
{"f_6367:posixunix_scm",(void*)f_6367},
{"f_6324:posixunix_scm",(void*)f_6324},
{"f_6334:posixunix_scm",(void*)f_6334},
{"f_6233:posixunix_scm",(void*)f_6233},
{"f_6241:posixunix_scm",(void*)f_6241},
{"f_6243:posixunix_scm",(void*)f_6243},
{"f_6291:posixunix_scm",(void*)f_6291},
{"f_6224:posixunix_scm",(void*)f_6224},
{"f_6228:posixunix_scm",(void*)f_6228},
{"f_6203:posixunix_scm",(void*)f_6203},
{"f_6213:posixunix_scm",(void*)f_6213},
{"f_6191:posixunix_scm",(void*)f_6191},
{"f_6178:posixunix_scm",(void*)f_6178},
{"f_6182:posixunix_scm",(void*)f_6182},
{"f_6173:posixunix_scm",(void*)f_6173},
{"f_6176:posixunix_scm",(void*)f_6176},
{"f_6091:posixunix_scm",(void*)f_6091},
{"f_6103:posixunix_scm",(void*)f_6103},
{"f_6140:posixunix_scm",(void*)f_6140},
{"f_6149:posixunix_scm",(void*)f_6149},
{"f_6143:posixunix_scm",(void*)f_6143},
{"f_6119:posixunix_scm",(void*)f_6119},
{"f_6122:posixunix_scm",(void*)f_6122},
{"f_6083:posixunix_scm",(void*)f_6083},
{"f_6060:posixunix_scm",(void*)f_6060},
{"f_6064:posixunix_scm",(void*)f_6064},
{"f_6020:posixunix_scm",(void*)f_6020},
{"f_6027:posixunix_scm",(void*)f_6027},
{"f_6030:posixunix_scm",(void*)f_6030},
{"f_5975:posixunix_scm",(void*)f_5975},
{"f_5979:posixunix_scm",(void*)f_5979},
{"f_6014:posixunix_scm",(void*)f_6014},
{"f_5997:posixunix_scm",(void*)f_5997},
{"f_5961:posixunix_scm",(void*)f_5961},
{"f_5973:posixunix_scm",(void*)f_5973},
{"f_5947:posixunix_scm",(void*)f_5947},
{"f_5959:posixunix_scm",(void*)f_5959},
{"f_5932:posixunix_scm",(void*)f_5932},
{"f_5945:posixunix_scm",(void*)f_5945},
{"f_5895:posixunix_scm",(void*)f_5895},
{"f_5903:posixunix_scm",(void*)f_5903},
{"f_5870:posixunix_scm",(void*)f_5870},
{"f_5859:posixunix_scm",(void*)f_5859},
{"f_5863:posixunix_scm",(void*)f_5863},
{"f_5828:posixunix_scm",(void*)f_5828},
{"f_5852:posixunix_scm",(void*)f_5852},
{"f_5836:posixunix_scm",(void*)f_5836},
{"f_5839:posixunix_scm",(void*)f_5839},
{"f_5790:posixunix_scm",(void*)f_5790},
{"f_5823:posixunix_scm",(void*)f_5823},
{"f_5811:posixunix_scm",(void*)f_5811},
{"f_5819:posixunix_scm",(void*)f_5819},
{"f_5815:posixunix_scm",(void*)f_5815},
{"f_5771:posixunix_scm",(void*)f_5771},
{"f_5781:posixunix_scm",(void*)f_5781},
{"f_5775:posixunix_scm",(void*)f_5775},
{"f_5765:posixunix_scm",(void*)f_5765},
{"f_5759:posixunix_scm",(void*)f_5759},
{"f_5753:posixunix_scm",(void*)f_5753},
{"f_5729:posixunix_scm",(void*)f_5729},
{"f_5751:posixunix_scm",(void*)f_5751},
{"f_5747:posixunix_scm",(void*)f_5747},
{"f_5739:posixunix_scm",(void*)f_5739},
{"f_5699:posixunix_scm",(void*)f_5699},
{"f_5727:posixunix_scm",(void*)f_5727},
{"f_5723:posixunix_scm",(void*)f_5723},
{"f_5672:posixunix_scm",(void*)f_5672},
{"f_5697:posixunix_scm",(void*)f_5697},
{"f_5693:posixunix_scm",(void*)f_5693},
{"f_5608:posixunix_scm",(void*)f_5608},
{"f_5604:posixunix_scm",(void*)f_5604},
{"f_5624:posixunix_scm",(void*)f_5624},
{"f_5542:posixunix_scm",(void*)f_5542},
{"f_5546:posixunix_scm",(void*)f_5546},
{"f_5551:posixunix_scm",(void*)f_5551},
{"f_5567:posixunix_scm",(void*)f_5567},
{"f_5479:posixunix_scm",(void*)f_5479},
{"f_5537:posixunix_scm",(void*)f_5537},
{"f_5483:posixunix_scm",(void*)f_5483},
{"f_5486:posixunix_scm",(void*)f_5486},
{"f_5518:posixunix_scm",(void*)f_5518},
{"f_5489:posixunix_scm",(void*)f_5489},
{"f_5494:posixunix_scm",(void*)f_5494},
{"f_5508:posixunix_scm",(void*)f_5508},
{"f_5476:posixunix_scm",(void*)f_5476},
{"f_5401:posixunix_scm",(void*)f_5401},
{"f_5459:posixunix_scm",(void*)f_5459},
{"f_5408:posixunix_scm",(void*)f_5408},
{"f_5418:posixunix_scm",(void*)f_5418},
{"f_5422:posixunix_scm",(void*)f_5422},
{"f_5431:posixunix_scm",(void*)f_5431},
{"f_5435:posixunix_scm",(void*)f_5435},
{"f_5445:posixunix_scm",(void*)f_5445},
{"f_5426:posixunix_scm",(void*)f_5426},
{"f_5381:posixunix_scm",(void*)f_5381},
{"f_5393:posixunix_scm",(void*)f_5393},
{"f_5389:posixunix_scm",(void*)f_5389},
{"f_5367:posixunix_scm",(void*)f_5367},
{"f_5379:posixunix_scm",(void*)f_5379},
{"f_5375:posixunix_scm",(void*)f_5375},
{"f_5307:posixunix_scm",(void*)f_5307},
{"f_5353:posixunix_scm",(void*)f_5353},
{"f_5314:posixunix_scm",(void*)f_5314},
{"f_5324:posixunix_scm",(void*)f_5324},
{"f_5328:posixunix_scm",(void*)f_5328},
{"f_5332:posixunix_scm",(void*)f_5332},
{"f_5336:posixunix_scm",(void*)f_5336},
{"f_5340:posixunix_scm",(void*)f_5340},
{"f_5253:posixunix_scm",(void*)f_5253},
{"f_5286:posixunix_scm",(void*)f_5286},
{"f_5257:posixunix_scm",(void*)f_5257},
{"f_5264:posixunix_scm",(void*)f_5264},
{"f_5268:posixunix_scm",(void*)f_5268},
{"f_5272:posixunix_scm",(void*)f_5272},
{"f_5276:posixunix_scm",(void*)f_5276},
{"f_5280:posixunix_scm",(void*)f_5280},
{"f_5235:posixunix_scm",(void*)f_5235},
{"f_5220:posixunix_scm",(void*)f_5220},
{"f_5214:posixunix_scm",(void*)f_5214},
{"f_5182:posixunix_scm",(void*)f_5182},
{"f_5188:posixunix_scm",(void*)f_5188},
{"f_5158:posixunix_scm",(void*)f_5158},
{"f_5176:posixunix_scm",(void*)f_5176},
{"f_5165:posixunix_scm",(void*)f_5165},
{"f_5140:posixunix_scm",(void*)f_5140},
{"f_5150:posixunix_scm",(void*)f_5150},
{"f_5127:posixunix_scm",(void*)f_5127},
{"f_5118:posixunix_scm",(void*)f_5118},
{"f_5071:posixunix_scm",(void*)f_5071},
{"f_5075:posixunix_scm",(void*)f_5075},
{"f_5051:posixunix_scm",(void*)f_5051},
{"f_5055:posixunix_scm",(void*)f_5055},
{"f_5061:posixunix_scm",(void*)f_5061},
{"f_5065:posixunix_scm",(void*)f_5065},
{"f_5031:posixunix_scm",(void*)f_5031},
{"f_5035:posixunix_scm",(void*)f_5035},
{"f_5041:posixunix_scm",(void*)f_5041},
{"f_5045:posixunix_scm",(void*)f_5045},
{"f_5007:posixunix_scm",(void*)f_5007},
{"f_5011:posixunix_scm",(void*)f_5011},
{"f_5022:posixunix_scm",(void*)f_5022},
{"f_5026:posixunix_scm",(void*)f_5026},
{"f_5016:posixunix_scm",(void*)f_5016},
{"f_4983:posixunix_scm",(void*)f_4983},
{"f_4987:posixunix_scm",(void*)f_4987},
{"f_4998:posixunix_scm",(void*)f_4998},
{"f_5002:posixunix_scm",(void*)f_5002},
{"f_4992:posixunix_scm",(void*)f_4992},
{"f_4967:posixunix_scm",(void*)f_4967},
{"f_4971:posixunix_scm",(void*)f_4971},
{"f_4974:posixunix_scm",(void*)f_4974},
{"f_4931:posixunix_scm",(void*)f_4931},
{"f_4962:posixunix_scm",(void*)f_4962},
{"f_4952:posixunix_scm",(void*)f_4952},
{"f_4945:posixunix_scm",(void*)f_4945},
{"f_4895:posixunix_scm",(void*)f_4895},
{"f_4926:posixunix_scm",(void*)f_4926},
{"f_4916:posixunix_scm",(void*)f_4916},
{"f_4909:posixunix_scm",(void*)f_4909},
{"f_4880:posixunix_scm",(void*)f_4880},
{"f_4893:posixunix_scm",(void*)f_4893},
{"f_4874:posixunix_scm",(void*)f_4874},
{"f_4862:posixunix_scm",(void*)f_4862},
{"f_4545:posixunix_scm",(void*)f_4545},
{"f_4852:posixunix_scm",(void*)f_4852},
{"f_4672:posixunix_scm",(void*)f_4672},
{"f_4838:posixunix_scm",(void*)f_4838},
{"f_4827:posixunix_scm",(void*)f_4827},
{"f_4834:posixunix_scm",(void*)f_4834},
{"f_4691:posixunix_scm",(void*)f_4691},
{"f_4820:posixunix_scm",(void*)f_4820},
{"f_4799:posixunix_scm",(void*)f_4799},
{"f_4816:posixunix_scm",(void*)f_4816},
{"f_4805:posixunix_scm",(void*)f_4805},
{"f_4812:posixunix_scm",(void*)f_4812},
{"f_4735:posixunix_scm",(void*)f_4735},
{"f_4796:posixunix_scm",(void*)f_4796},
{"f_4775:posixunix_scm",(void*)f_4775},
{"f_4792:posixunix_scm",(void*)f_4792},
{"f_4781:posixunix_scm",(void*)f_4781},
{"f_4788:posixunix_scm",(void*)f_4788},
{"f_4748:posixunix_scm",(void*)f_4748},
{"f_4772:posixunix_scm",(void*)f_4772},
{"f_4768:posixunix_scm",(void*)f_4768},
{"f_4729:posixunix_scm",(void*)f_4729},
{"f_4698:posixunix_scm",(void*)f_4698},
{"f_4716:posixunix_scm",(void*)f_4716},
{"f_4701:posixunix_scm",(void*)f_4701},
{"f_4705:posixunix_scm",(void*)f_4705},
{"f_4685:posixunix_scm",(void*)f_4685},
{"f_4666:posixunix_scm",(void*)f_4666},
{"f_4552:posixunix_scm",(void*)f_4552},
{"f_4559:posixunix_scm",(void*)f_4559},
{"f_4561:posixunix_scm",(void*)f_4561},
{"f_4568:posixunix_scm",(void*)f_4568},
{"f_4632:posixunix_scm",(void*)f_4632},
{"f_4641:posixunix_scm",(void*)f_4641},
{"f_4629:posixunix_scm",(void*)f_4629},
{"f_4574:posixunix_scm",(void*)f_4574},
{"f_4610:posixunix_scm",(void*)f_4610},
{"f_4606:posixunix_scm",(void*)f_4606},
{"f_4602:posixunix_scm",(void*)f_4602},
{"f_4591:posixunix_scm",(void*)f_4591},
{"f_4587:posixunix_scm",(void*)f_4587},
{"f_4489:posixunix_scm",(void*)f_4489},
{"f_4498:posixunix_scm",(void*)f_4498},
{"f_4522:posixunix_scm",(void*)f_4522},
{"f_4534:posixunix_scm",(void*)f_4534},
{"f_4540:posixunix_scm",(void*)f_4540},
{"f_4528:posixunix_scm",(void*)f_4528},
{"f_4504:posixunix_scm",(void*)f_4504},
{"f_4510:posixunix_scm",(void*)f_4510},
{"f_4496:posixunix_scm",(void*)f_4496},
{"f_4478:posixunix_scm",(void*)f_4478},
{"f_4473:posixunix_scm",(void*)f_4473},
{"f_4432:posixunix_scm",(void*)f_4432},
{"f_4445:posixunix_scm",(void*)f_4445},
{"f_4409:posixunix_scm",(void*)f_4409},
{"f_4430:posixunix_scm",(void*)f_4430},
{"f_4416:posixunix_scm",(void*)f_4416},
{"f_4255:posixunix_scm",(void*)f_4255},
{"f_4360:posixunix_scm",(void*)f_4360},
{"f_4368:posixunix_scm",(void*)f_4368},
{"f_4355:posixunix_scm",(void*)f_4355},
{"f_4257:posixunix_scm",(void*)f_4257},
{"f_4264:posixunix_scm",(void*)f_4264},
{"f_4267:posixunix_scm",(void*)f_4267},
{"f_4270:posixunix_scm",(void*)f_4270},
{"f_4354:posixunix_scm",(void*)f_4354},
{"f_4274:posixunix_scm",(void*)f_4274},
{"f_4288:posixunix_scm",(void*)f_4288},
{"f_4298:posixunix_scm",(void*)f_4298},
{"f_4301:posixunix_scm",(void*)f_4301},
{"f_4304:posixunix_scm",(void*)f_4304},
{"f_4310:posixunix_scm",(void*)f_4310},
{"f_4320:posixunix_scm",(void*)f_4320},
{"f_4231:posixunix_scm",(void*)f_4231},
{"f_4253:posixunix_scm",(void*)f_4253},
{"f_4249:posixunix_scm",(void*)f_4249},
{"f_4207:posixunix_scm",(void*)f_4207},
{"f_4229:posixunix_scm",(void*)f_4229},
{"f_4225:posixunix_scm",(void*)f_4225},
{"f_4106:posixunix_scm",(void*)f_4106},
{"f_4179:posixunix_scm",(void*)f_4179},
{"f_4193:posixunix_scm",(void*)f_4193},
{"f_4119:posixunix_scm",(void*)f_4119},
{"f_4176:posixunix_scm",(void*)f_4176},
{"f_4124:posixunix_scm",(void*)f_4124},
{"f_4129:posixunix_scm",(void*)f_4129},
{"f_4152:posixunix_scm",(void*)f_4152},
{"f_4172:posixunix_scm",(void*)f_4172},
{"f_4135:posixunix_scm",(void*)f_4135},
{"f_4149:posixunix_scm",(void*)f_4149},
{"f_4093:posixunix_scm",(void*)f_4093},
{"f_4100:posixunix_scm",(void*)f_4100},
{"f_4084:posixunix_scm",(void*)f_4084},
{"f_4091:posixunix_scm",(void*)f_4091},
{"f_4075:posixunix_scm",(void*)f_4075},
{"f_4082:posixunix_scm",(void*)f_4082},
{"f_4066:posixunix_scm",(void*)f_4066},
{"f_4073:posixunix_scm",(void*)f_4073},
{"f_4057:posixunix_scm",(void*)f_4057},
{"f_4064:posixunix_scm",(void*)f_4064},
{"f_4048:posixunix_scm",(void*)f_4048},
{"f_4055:posixunix_scm",(void*)f_4055},
{"f_4039:posixunix_scm",(void*)f_4039},
{"f_4046:posixunix_scm",(void*)f_4046},
{"f_4030:posixunix_scm",(void*)f_4030},
{"f_4037:posixunix_scm",(void*)f_4037},
{"f_4021:posixunix_scm",(void*)f_4021},
{"f_4028:posixunix_scm",(void*)f_4028},
{"f_4015:posixunix_scm",(void*)f_4015},
{"f_4019:posixunix_scm",(void*)f_4019},
{"f_4009:posixunix_scm",(void*)f_4009},
{"f_4013:posixunix_scm",(void*)f_4013},
{"f_4003:posixunix_scm",(void*)f_4003},
{"f_4007:posixunix_scm",(void*)f_4007},
{"f_3997:posixunix_scm",(void*)f_3997},
{"f_4001:posixunix_scm",(void*)f_4001},
{"f_3991:posixunix_scm",(void*)f_3991},
{"f_3995:posixunix_scm",(void*)f_3995},
{"f_3985:posixunix_scm",(void*)f_3985},
{"f_3989:posixunix_scm",(void*)f_3989},
{"f_3960:posixunix_scm",(void*)f_3960},
{"f_3964:posixunix_scm",(void*)f_3964},
{"f_3923:posixunix_scm",(void*)f_3923},
{"f_3955:posixunix_scm",(void*)f_3955},
{"f_3948:posixunix_scm",(void*)f_3948},
{"f_3927:posixunix_scm",(void*)f_3927},
{"f_3731:posixunix_scm",(void*)f_3731},
{"f_3904:posixunix_scm",(void*)f_3904},
{"f_3747:posixunix_scm",(void*)f_3747},
{"f_3878:posixunix_scm",(void*)f_3878},
{"f_3753:posixunix_scm",(void*)f_3753},
{"f_3756:posixunix_scm",(void*)f_3756},
{"f_3838:posixunix_scm",(void*)f_3838},
{"f_3836:posixunix_scm",(void*)f_3836},
{"f_3795:posixunix_scm",(void*)f_3795},
{"f_3813:posixunix_scm",(void*)f_3813},
{"f_3811:posixunix_scm",(void*)f_3811},
{"f_3799:posixunix_scm",(void*)f_3799},
{"f_3729:posixunix_scm",(void*)f_3729},
{"f_3727:posixunix_scm",(void*)f_3727},
{"f_3725:posixunix_scm",(void*)f_3725},
{"f_3693:posixunix_scm",(void*)f_3693},
{"f_3700:posixunix_scm",(void*)f_3700},
{"f_3706:posixunix_scm",(void*)f_3706},
{"f_3713:posixunix_scm",(void*)f_3713},
{"f_3654:posixunix_scm",(void*)f_3654},
{"f_3661:posixunix_scm",(void*)f_3661},
{"f_3670:posixunix_scm",(void*)f_3670},
{"f_3612:posixunix_scm",(void*)f_3612},
{"f_3622:posixunix_scm",(void*)f_3622},
{"f_3625:posixunix_scm",(void*)f_3625},
{"f_3628:posixunix_scm",(void*)f_3628},
{"f_3597:posixunix_scm",(void*)f_3597},
{"f_3559:posixunix_scm",(void*)f_3559},
{"f_3589:posixunix_scm",(void*)f_3589},
{"f_3576:posixunix_scm",(void*)f_3576},
{"f_3579:posixunix_scm",(void*)f_3579},
{"f_3520:posixunix_scm",(void*)f_3520},
{"f_3479:posixunix_scm",(void*)f_3479},
{"f_3476:posixunix_scm",(void*)f_3476},
{"f_3458:posixunix_scm",(void*)f_3458},
{"f_3462:posixunix_scm",(void*)f_3462},
{"f_3473:posixunix_scm",(void*)f_3473},
{"f_3469:posixunix_scm",(void*)f_3469},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
