/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:46
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: eval.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[396];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static C_word C_fcall stub2772(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2772(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10180)
static void C_ccall f_10180(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10180)
static void C_ccall f_10180r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10184)
static void C_fcall f_10184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10209)
static void C_ccall f_10209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10199)
static void C_ccall f_10199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10207)
static void C_ccall f_10207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10192)
static void C_ccall f_10192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10190)
static void C_ccall f_10190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10170)
static void C_ccall f_10170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10166)
static void C_ccall f_10166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10162)
static void C_ccall f_10162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10152)
static void C_fcall f_10152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7269)
static void C_fcall f_7269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_ccall f_7274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10122)
static void C_ccall f_10122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10124)
static void C_ccall f_10124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7281)
static void C_ccall f_7281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10091)
static void C_ccall f_10091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10111)
static void C_ccall f_10111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10107)
static void C_ccall f_10107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10097)
static void C_ccall f_10097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10094)
static void C_ccall f_10094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7634)
static void C_ccall f_7634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10037)
static void C_ccall f_10037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10051)
static void C_fcall f_10051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10087)
static void C_ccall f_10087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10083)
static void C_ccall f_10083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10071)
static void C_ccall f_10071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10075)
static void C_ccall f_10075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10045)
static void C_ccall f_10045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8472)
static void C_ccall f_8472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9940)
static void C_ccall f_9940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9977)
static void C_fcall f_9977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9980)
static void C_ccall f_9980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10003)
static void C_ccall f_10003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10007)
static void C_ccall f_10007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9989)
static void C_ccall f_9989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9986)
static void C_ccall f_9986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9943)
static void C_fcall f_9943(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8533)
static void C_ccall f_8533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9938)
static void C_ccall f_9938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9934)
static void C_ccall f_9934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8891)
static void C_ccall f_8891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8895)
static void C_ccall f_8895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9926)
static void C_ccall f_9926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9544)
static void C_ccall f_9544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9917)
static void C_ccall f_9917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9924)
static void C_ccall f_9924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9907)
static void C_ccall f_9907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9892)
static void C_ccall f_9892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9901)
static void C_ccall f_9901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9905)
static void C_ccall f_9905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9879)
static void C_ccall f_9879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9883)
static void C_ccall f_9883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9844)
static void C_ccall f_9844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9850)
static void C_ccall f_9850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9868)
static void C_ccall f_9868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9857)
static void C_ccall f_9857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9864)
static void C_ccall f_9864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9842)
static void C_ccall f_9842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_ccall f_9791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9804)
static void C_ccall f_9804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9826)
static void C_ccall f_9826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9818)
static void C_ccall f_9818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9807)
static void C_ccall f_9807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9771)
static void C_ccall f_9771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9775)
static void C_ccall f_9775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9785)
static void C_ccall f_9785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static C_word C_fcall f_9752(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9726)
static void C_ccall f_9726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9730)
static void C_ccall f_9730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9735)
static void C_ccall f_9735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9739)
static void C_ccall f_9739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9750)
static void C_ccall f_9750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9710)
static void C_ccall f_9710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9716)
static void C_ccall f_9716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9724)
static void C_ccall f_9724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9698)
static void C_ccall f_9698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9704)
static void C_ccall f_9704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9689)
static void C_fcall f_9689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9693)
static void C_ccall f_9693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9630)
static void C_fcall f_9630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9640)
static void C_ccall f_9640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9677)
static void C_ccall f_9677(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9677)
static void C_ccall f_9677r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9683)
static void C_ccall f_9683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9671)
static void C_ccall f_9671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9646)
static void C_ccall f_9646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9652)
static void C_ccall f_9652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9659)
static void C_ccall f_9659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9638)
static void C_ccall f_9638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9555)
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9565)
static void C_ccall f_9565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9568)
static void C_ccall f_9568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9582)
static void C_fcall f_9582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9600)
static void C_ccall f_9600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9569)
static void C_fcall f_9569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9546)
static void C_ccall f_9546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9205)
static void C_ccall f_9205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9529)
static void C_ccall f_9529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9533)
static void C_ccall f_9533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9537)
static void C_ccall f_9537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9340)
static void C_fcall f_9340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9347)
static void C_ccall f_9347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9350)
static void C_ccall f_9350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9353)
static void C_ccall f_9353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9362)
static void C_ccall f_9362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9365)
static void C_ccall f_9365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9380)
static void C_ccall f_9380(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9380)
static void C_ccall f_9380r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9398)
static void C_fcall f_9398(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9414)
static void C_ccall f_9414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9423)
static void C_ccall f_9423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9426)
static void C_ccall f_9426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9438)
static void C_ccall f_9438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9429)
static void C_ccall f_9429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9402)
static void C_ccall f_9402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9384)
static void C_ccall f_9384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_fcall f_9230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9387)
static void C_ccall f_9387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9371)
static void C_ccall f_9371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9269)
static void C_ccall f_9269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9282)
static void C_ccall f_9282(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9282)
static void C_ccall f_9282r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9289)
static void C_ccall f_9289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9329)
static void C_ccall f_9329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9292)
static void C_ccall f_9292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9304)
static void C_fcall f_9304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9313)
static void C_ccall f_9313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9307)
static void C_ccall f_9307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9295)
static void C_ccall f_9295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9298)
static void C_ccall f_9298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9260)
static C_word C_fcall f_9260(C_word t0);
C_noret_decl(f_9254)
static C_word C_fcall f_9254(C_word t0);
C_noret_decl(f_9208)
static void C_fcall f_9208(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9214)
static void C_ccall f_9214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9200)
static void C_ccall f_9200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9197)
static void C_ccall f_9197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9190)
static void C_ccall f_9190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9167)
static void C_ccall f_9167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9111)
static void C_ccall f_9111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9114)
static void C_ccall f_9114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9117)
static void C_ccall f_9117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9120)
static void C_ccall f_9120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9123)
static void C_ccall f_9123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_ccall f_9129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9135)
static void C_ccall f_9135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_fcall f_9086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9090)
static void C_ccall f_9090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9093)
static void C_ccall f_9093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_fcall f_9062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9068)
static void C_fcall f_9068(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9048)
static void C_ccall f_9048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9041)
static void C_fcall f_9041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9001)
static void C_ccall f_9001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_fcall f_9003(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9027)
static void C_ccall f_9027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_fcall f_8961(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8926)
static void C_fcall f_8926(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8948)
static void C_ccall f_8948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8939)
static void C_ccall f_8939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8901)
static void C_fcall f_8901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8868)
static void C_fcall f_8868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8874)
static void C_ccall f_8874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8830)
static void C_ccall f_8830(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8830)
static void C_ccall f_8830r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8837)
static void C_ccall f_8837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8844)
static void C_ccall f_8844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8819)
static void C_ccall f_8819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8806)
static void C_ccall f_8806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8758)
static void C_ccall f_8758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8768)
static void C_ccall f_8768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8685)
static void C_fcall f_8685(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8709)
static void C_fcall f_8709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8566)
static void C_ccall f_8566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8571)
static void C_fcall f_8571(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8598)
static void C_fcall f_8598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8631)
static void C_ccall f_8631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8592)
static void C_ccall f_8592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8489)
static void C_fcall f_8489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8509)
static void C_fcall f_8509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8465)
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8451)
static void C_ccall f_8451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8301)
static void C_fcall f_8301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8310)
static void C_ccall f_8310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8342)
static void C_fcall f_8342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8003)
static void C_fcall f_8003(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8158)
static void C_ccall f_8158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8270)
static void C_ccall f_8270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_fcall f_8189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8215)
static void C_ccall f_8215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8211)
static void C_ccall f_8211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8197)
static void C_fcall f_8197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8193)
static void C_ccall f_8193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8185)
static void C_ccall f_8185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8177)
static void C_ccall f_8177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_fcall f_8094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_fcall f_8106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8102)
static void C_ccall f_8102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_fcall f_8037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8033)
static void C_ccall f_8033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7962)
static void C_fcall f_7962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7981)
static void C_ccall f_7981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7978)
static void C_fcall f_7978(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7974)
static void C_ccall f_7974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7937)
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7891)
static void C_fcall f_7891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7905)
static void C_ccall f_7905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_fcall f_7908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7862)
static void C_ccall f_7862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7819)
static void C_ccall f_7819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7805)
static void C_ccall f_7805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7637)
static void C_ccall f_7637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7722)
static void C_ccall f_7722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_fcall f_7691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7643)
static void C_fcall f_7643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7656)
static void C_ccall f_7656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7579)
static void C_fcall f_7579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7501)
static void C_fcall f_7501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static C_word C_fcall f_7483(C_word t0);
C_noret_decl(f_7477)
static void C_fcall f_7477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7283)
static void C_ccall f_7283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7296)
static void C_fcall f_7296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7299)
static void C_ccall f_7299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_fcall f_7307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7323)
static void C_fcall f_7323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7264)
static void C_ccall f_7264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7247)
static void C_ccall f_7247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7250)
static void C_ccall f_7250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7258)
static void C_ccall f_7258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7215)
static void C_ccall f_7215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6792)
static void C_ccall f_6792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6792)
static void C_ccall f_6792r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7140)
static void C_fcall f_7140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_fcall f_7135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6794)
static void C_fcall f_6794(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6798)
static void C_fcall f_6798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7056)
static void C_ccall f_7056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_fcall f_7074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6810)
static void C_ccall f_6810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_fcall f_6870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_ccall f_6890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6823)
static void C_ccall f_6823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_fcall f_6746(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static C_word C_fcall f_6756(C_word t0,C_word t1);
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6683)
static void C_fcall f_6683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6594)
static void C_fcall f_6594(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_fcall f_6584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6320)
static void C_fcall f_6320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6513)
static void C_ccall f_6513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6476)
static void C_ccall f_6476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6506)
static void C_ccall f_6506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6446)
static void C_ccall f_6446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static C_word C_fcall f_6294(C_word t0,C_word t1);
C_noret_decl(f_3916)
static void C_fcall f_3916(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_fcall f_4099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_fcall f_6097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_fcall f_5939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_fcall f_5883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5767)
static C_word C_fcall f_5767(C_word t0);
C_noret_decl(f_5756)
static void C_fcall f_5756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5735)
static void C_ccall f_5735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5651)
static void C_fcall f_5651(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5671)
static void C_fcall f_5671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_fcall f_5578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_fcall f_5497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5277)
static void C_ccall f_5277(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5277)
static void C_ccall f_5277r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6248)
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_fcall f_4845(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_fcall f_3986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_fcall f_3981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3865)
static void C_fcall f_3865(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_fcall f_3859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3853)
static C_word C_fcall f_3853(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3847)
static C_word C_fcall f_3847(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3763)
static void C_fcall f_3763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_fcall f_3775(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3817)
static C_word C_fcall f_3817(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3748)
static void C_fcall f_3748(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3722)
static void C_fcall f_3722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_fcall f_3611(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3559)
static void C_fcall f_3559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_fcall f_3485(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static C_word C_fcall f_3428(C_word t0,C_word t1);
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9907,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9892,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9870,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9844,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9828,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9791,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9765,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9726,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9710,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9698,0));}

C_noret_decl(trf_10184)
static void C_fcall trf_10184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10184(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10184(t0,t1);}

C_noret_decl(trf_10152)
static void C_fcall trf_10152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10152(t0,t1);}

C_noret_decl(trf_7269)
static void C_fcall trf_7269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7269(t0,t1);}

C_noret_decl(trf_10051)
static void C_fcall trf_10051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10051(t0,t1,t2);}

C_noret_decl(trf_9977)
static void C_fcall trf_9977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9977(t0,t1);}

C_noret_decl(trf_9943)
static void C_fcall trf_9943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9943(t0,t1);}

C_noret_decl(trf_9689)
static void C_fcall trf_9689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9689(t0,t1,t2);}

C_noret_decl(trf_9630)
static void C_fcall trf_9630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9630(t0,t1);}

C_noret_decl(trf_9582)
static void C_fcall trf_9582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9582(t0,t1);}

C_noret_decl(trf_9569)
static void C_fcall trf_9569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9569(t0,t1);}

C_noret_decl(trf_9340)
static void C_fcall trf_9340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9340(t0,t1);}

C_noret_decl(trf_9398)
static void C_fcall trf_9398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9398(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9398(t0,t1,t2,t3);}

C_noret_decl(trf_9230)
static void C_fcall trf_9230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9230(t0,t1);}

C_noret_decl(trf_9304)
static void C_fcall trf_9304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9304(t0,t1);}

C_noret_decl(trf_9208)
static void C_fcall trf_9208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9208(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9208(t0,t1);}

C_noret_decl(trf_9086)
static void C_fcall trf_9086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9086(t0,t1,t2,t3);}

C_noret_decl(trf_9062)
static void C_fcall trf_9062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9062(t0,t1,t2);}

C_noret_decl(trf_9068)
static void C_fcall trf_9068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9068(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9068(t0,t1,t2);}

C_noret_decl(trf_9041)
static void C_fcall trf_9041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9041(t0,t1);}

C_noret_decl(trf_9003)
static void C_fcall trf_9003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9003(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9003(t0,t1,t2);}

C_noret_decl(trf_8961)
static void C_fcall trf_8961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8961(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8961(t0,t1,t2);}

C_noret_decl(trf_8926)
static void C_fcall trf_8926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8926(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8926(t0,t1,t2,t3);}

C_noret_decl(trf_8901)
static void C_fcall trf_8901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8901(t0,t1);}

C_noret_decl(trf_8868)
static void C_fcall trf_8868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8868(t0,t1);}

C_noret_decl(trf_8685)
static void C_fcall trf_8685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8685(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8685(t0,t1,t2,t3);}

C_noret_decl(trf_8709)
static void C_fcall trf_8709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8709(t0,t1,t2,t3);}

C_noret_decl(trf_8571)
static void C_fcall trf_8571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8571(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8571(t0,t1,t2);}

C_noret_decl(trf_8598)
static void C_fcall trf_8598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8598(t0,t1,t2);}

C_noret_decl(trf_8489)
static void C_fcall trf_8489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8489(t0,t1,t2);}

C_noret_decl(trf_8509)
static void C_fcall trf_8509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8509(t0,t1);}

C_noret_decl(trf_8301)
static void C_fcall trf_8301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8301(t0,t1);}

C_noret_decl(trf_8342)
static void C_fcall trf_8342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8342(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8342(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8003)
static void C_fcall trf_8003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8003(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8003(t0,t1,t2);}

C_noret_decl(trf_8189)
static void C_fcall trf_8189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8189(t0,t1);}

C_noret_decl(trf_8197)
static void C_fcall trf_8197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8197(t0,t1);}

C_noret_decl(trf_8094)
static void C_fcall trf_8094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8094(t0,t1);}

C_noret_decl(trf_8106)
static void C_fcall trf_8106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8106(t0,t1);}

C_noret_decl(trf_8037)
static void C_fcall trf_8037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8037(t0,t1);}

C_noret_decl(trf_7962)
static void C_fcall trf_7962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7962(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7962(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7978)
static void C_fcall trf_7978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7978(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7978(t0,t1);}

C_noret_decl(trf_7937)
static void C_fcall trf_7937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7937(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7937(t0,t1,t2,t3);}

C_noret_decl(trf_7891)
static void C_fcall trf_7891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7891(t0,t1,t2);}

C_noret_decl(trf_7908)
static void C_fcall trf_7908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7908(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7908(t0,t1);}

C_noret_decl(trf_7735)
static void C_fcall trf_7735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7735(t0,t1);}

C_noret_decl(trf_7691)
static void C_fcall trf_7691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7691(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7691(t0,t1,t2);}

C_noret_decl(trf_7643)
static void C_fcall trf_7643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7643(t0,t1,t2);}

C_noret_decl(trf_7579)
static void C_fcall trf_7579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7579(t0,t1,t2);}

C_noret_decl(trf_7501)
static void C_fcall trf_7501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7501(t0,t1,t2);}

C_noret_decl(trf_7477)
static void C_fcall trf_7477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7477(t0,t1);}

C_noret_decl(trf_7296)
static void C_fcall trf_7296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7296(t0,t1);}

C_noret_decl(trf_7307)
static void C_fcall trf_7307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7307(t0,t1,t2);}

C_noret_decl(trf_7323)
static void C_fcall trf_7323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7323(t0,t1);}

C_noret_decl(trf_7140)
static void C_fcall trf_7140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7140(t0,t1);}

C_noret_decl(trf_7135)
static void C_fcall trf_7135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7135(t0,t1,t2);}

C_noret_decl(trf_6794)
static void C_fcall trf_6794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6794(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6794(t0,t1,t2,t3);}

C_noret_decl(trf_6798)
static void C_fcall trf_6798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6798(t0,t1);}

C_noret_decl(trf_7074)
static void C_fcall trf_7074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7074(t0,t1);}

C_noret_decl(trf_6870)
static void C_fcall trf_6870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6870(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6870(t0,t1,t2);}

C_noret_decl(trf_6746)
static void C_fcall trf_6746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6746(t0,t1);}

C_noret_decl(trf_6683)
static void C_fcall trf_6683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6683(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6683(t0,t1,t2);}

C_noret_decl(trf_6594)
static void C_fcall trf_6594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6594(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6594(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6584)
static void C_fcall trf_6584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6584(t0,t1);}

C_noret_decl(trf_6320)
static void C_fcall trf_6320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6320(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6320(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3916)
static void C_fcall trf_3916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3916(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3916(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_4099)
static void C_fcall trf_4099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4099(t0,t1);}

C_noret_decl(trf_6097)
static void C_fcall trf_6097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6097(t0,t1);}

C_noret_decl(trf_5939)
static void C_fcall trf_5939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5939(t0,t1,t2);}

C_noret_decl(trf_5883)
static void C_fcall trf_5883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5883(t0,t1);}

C_noret_decl(trf_5756)
static void C_fcall trf_5756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5756(t0,t1);}

C_noret_decl(trf_5651)
static void C_fcall trf_5651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5651(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5651(t0,t1,t2,t3);}

C_noret_decl(trf_5671)
static void C_fcall trf_5671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5671(t0,t1,t2);}

C_noret_decl(trf_5578)
static void C_fcall trf_5578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5578(t0,t1);}

C_noret_decl(trf_5497)
static void C_fcall trf_5497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5497(t0,t1);}

C_noret_decl(trf_6248)
static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6248(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4845)
static void C_fcall trf_4845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4845(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4845(t0,t1,t2,t3);}

C_noret_decl(trf_3986)
static void C_fcall trf_3986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3986(t0,t1);}

C_noret_decl(trf_3981)
static void C_fcall trf_3981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3981(t0,t1);}

C_noret_decl(trf_3865)
static void C_fcall trf_3865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3865(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3865(t0,t1);}

C_noret_decl(trf_3859)
static void C_fcall trf_3859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3859(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3859(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3763)
static void C_fcall trf_3763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3763(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3763(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3775)
static void C_fcall trf_3775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3775(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3775(t0,t1,t2,t3);}

C_noret_decl(trf_3748)
static void C_fcall trf_3748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3748(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3748(t0,t1,t2,t3);}

C_noret_decl(trf_3709)
static void C_fcall trf_3709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3709(t0,t1,t2,t3);}

C_noret_decl(trf_3722)
static void C_fcall trf_3722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3722(t0,t1);}

C_noret_decl(trf_3611)
static void C_fcall trf_3611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3611(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3611(t0,t1,t2);}

C_noret_decl(trf_3559)
static void C_fcall trf_3559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3559(t0,t1,t2);}

C_noret_decl(trf_3485)
static void C_fcall trf_3485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3485(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3485(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6485)){
C_save(t1);
C_rereclaim2(6485*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,396);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],2,"pp");
lf[2]=C_h_intern(&lf[2],5,"print");
lf[3]=C_h_intern(&lf[3],24,"\003syscore-library-modules");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005files\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000"
"\002\376\001\000\000\005regex\376\003\000\000\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4"
"\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000"
"\002\376\001\000\000\005ports\376\003\000\000\002\376\001\000\000\016chicken-syntax\376\377\016");
lf[5]=C_h_intern(&lf[5],28,"\003sysexplicit-library-modules");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[10]=C_h_intern(&lf[10],18,"\003syschicken-prefix");
lf[11]=C_h_intern(&lf[11],17,"\003sysstring-append");
lf[12]=C_h_intern(&lf[12],12,"chicken-home");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[15]=C_h_intern(&lf[15],15,"\003syshash-symbol");
lf[16]=C_h_intern(&lf[16],18,"\003syshash-table-ref");
lf[17]=C_h_intern(&lf[17],19,"\003syshash-table-set!");
lf[18]=C_h_intern(&lf[18],22,"\003syshash-table-update!");
lf[19]=C_h_intern(&lf[19],23,"\003syshash-table-for-each");
lf[20]=C_h_intern(&lf[20],12,"\003sysfor-each");
lf[21]=C_h_intern(&lf[21],28,"\003sysarbitrary-unbound-symbol");
lf[22]=C_h_intern(&lf[22],23,"\003syshash-table-location");
lf[23]=C_h_intern(&lf[23],20,"\003syseval-environment");
lf[24]=C_h_intern(&lf[24],26,"\003sysenvironment-is-mutable");
lf[25]=C_h_intern(&lf[25],18,"\003syseval-decorator");
lf[26]=C_h_intern(&lf[26],20,"\003sysmake-lambda-info");
lf[27]=C_h_intern(&lf[27],17,"get-output-string");
lf[28]=C_h_intern(&lf[28],5,"write");
lf[29]=C_h_intern(&lf[29],18,"open-output-string");
lf[30]=C_h_intern(&lf[30],19,"\003sysdecorate-lambda");
lf[31]=C_h_intern(&lf[31],19,"\003sysunbound-in-eval");
lf[32]=C_h_intern(&lf[32],20,"\003syseval-debug-level");
lf[33]=C_h_intern(&lf[33],7,"reverse");
lf[34]=C_h_intern(&lf[34],20,"with-input-from-file");
lf[35]=C_h_intern(&lf[35],7,"display");
lf[36]=C_h_intern(&lf[36],22,"\003syscompile-to-closure");
lf[37]=C_h_intern(&lf[37],7,"\003sysget");
lf[38]=C_h_intern(&lf[38],16,"\004coremacro-alias");
lf[39]=C_h_intern(&lf[39],19,"\003sysundefined-value");
lf[40]=C_h_intern(&lf[40],18,"\003syscurrent-thread");
lf[41]=C_h_intern(&lf[41],18,"\003syscurrent-module");
lf[42]=C_h_intern(&lf[42],21,"\003sysmacro-environment");
lf[43]=C_h_intern(&lf[43],28,"\003syscurrent-meta-environment");
lf[44]=C_h_intern(&lf[44],16,"\003sysdynamic-wind");
lf[45]=C_h_intern(&lf[45],26,"\003sysmeta-macro-environment");
lf[46]=C_h_intern(&lf[46],9,"\003syserror");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[48]=C_h_intern(&lf[48],21,"\003syssyntax-error-hook");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[50]=C_h_intern(&lf[50],32,"\003syssymbol-has-toplevel-binding\077");
lf[51]=C_h_intern(&lf[51],14,"\004coreprimitive");
lf[52]=C_h_intern(&lf[52],21,"\003sysalias-global-hook");
lf[53]=C_h_intern(&lf[53],5,"quote");
lf[54]=C_h_intern(&lf[54],16,"\003sysstrip-syntax");
lf[55]=C_h_intern(&lf[55],16,"\003syscheck-syntax");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[57]=C_h_intern(&lf[57],6,"syntax");
lf[58]=C_h_intern(&lf[58],15,"\004coreglobal-ref");
lf[59]=C_h_intern(&lf[59],10,"\004corecheck");
lf[60]=C_h_intern(&lf[60],14,"\004coreimmutable");
lf[61]=C_h_intern(&lf[61],14,"\004coreundefined");
lf[62]=C_h_intern(&lf[62],2,"if");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[65]=C_h_intern(&lf[65],5,"begin");
lf[66]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[67]=C_h_intern(&lf[67],10,"\003sysappend");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_h_intern(&lf[70],9,"\004coreset!");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[74]=C_h_intern(&lf[74],3,"let");
lf[75]=C_h_intern(&lf[75],8,"\004corelet");
lf[76]=C_h_intern(&lf[76],15,"\003sysmake-vector");
lf[77]=C_h_intern(&lf[77],7,"\003sysmap");
lf[78]=C_h_intern(&lf[78],21,"\003syscanonicalize-body");
lf[79]=C_h_intern(&lf[79],6,"append");
lf[80]=C_h_intern(&lf[80],3,"map");
lf[81]=C_h_intern(&lf[81],4,"cons");
lf[82]=C_h_intern(&lf[82],6,"gensym");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[84]=C_h_intern(&lf[84],6,"letrec");
lf[85]=C_h_intern(&lf[85],11,"\004coreletrec");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[88]=C_h_intern(&lf[88],6,"lambda");
lf[89]=C_h_intern(&lf[89],11,"\004corelambda");
lf[90]=C_h_intern(&lf[90],1,"\077");
lf[91]=C_h_intern(&lf[91],10,"\003sysvector");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[94]=C_h_intern(&lf[94],25,"\003sysdecompose-lambda-list");
lf[95]=C_h_intern(&lf[95],31,"\003sysexpand-extended-lambda-list");
lf[96]=C_h_intern(&lf[96],25,"\003sysextended-lambda-list\077");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[98]=C_h_intern(&lf[98],10,"let-syntax");
lf[99]=C_h_intern(&lf[99],18,"\003syser-transformer");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012let-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_"
"\376\377\001\000\000\000\001");
lf[101]=C_h_intern(&lf[101],13,"letrec-syntax");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015letrec-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000"
"\000\001_\376\377\001\000\000\000\001");
lf[103]=C_h_intern(&lf[103],13,"define-syntax");
lf[104]=C_h_intern(&lf[104],22,"define-compiled-syntax");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[106]=C_h_intern(&lf[106],28,"\003sysextend-macro-environment");
lf[107]=C_h_intern(&lf[107],23,"\003syscurrent-environment");
lf[108]=C_h_intern(&lf[108],26,"\003sysregister-syntax-export");
lf[109]=C_h_intern(&lf[109],5,"caadr");
lf[110]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[112]=C_h_intern(&lf[112],11,"\004coremodule");
lf[113]=C_h_intern(&lf[113],29,"\003sysinitial-macro-environment");
lf[114]=C_h_intern(&lf[114],19,"\003sysfinalize-module");
lf[115]=C_h_intern(&lf[115],19,"\003sysregister-module");
lf[116]=C_h_intern(&lf[116],6,"module");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\031modules may not be nested");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[119]=C_h_intern(&lf[119],16,"\004coreloop-lambda");
lf[120]=C_h_intern(&lf[120],17,"\004corenamed-lambda");
lf[121]=C_h_intern(&lf[121],23,"\004corerequire-for-syntax");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[123]=C_h_intern(&lf[123],11,"\003sysrequire");
lf[124]=C_h_intern(&lf[124],31,"\003syslookup-runtime-requirements");
lf[125]=C_h_intern(&lf[125],22,"\004corerequire-extension");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[127]=C_h_intern(&lf[127],22,"\003sysdo-the-right-thing");
lf[128]=C_h_intern(&lf[128],24,"\004coreelaborationtimeonly");
lf[129]=C_h_intern(&lf[129],23,"\004coreelaborationtimetoo");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[131]=C_h_intern(&lf[131],19,"\004corecompiletimetoo");
lf[132]=C_h_intern(&lf[132],20,"\004corecompiletimeonly");
lf[133]=C_h_intern(&lf[133],13,"\004corecallunit");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[135]=C_h_intern(&lf[135],12,"\004coredeclare");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[137]=C_h_intern(&lf[137],10,"\000compiling");
lf[138]=C_h_intern(&lf[138],12,"\003sysfeatures");
lf[139]=C_h_intern(&lf[139],28,"\010compilerprocess-declaration");
lf[140]=C_h_intern(&lf[140],8,"\003syswarn");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[142]=C_h_intern(&lf[142],13,"define-inline");
lf[143]=C_h_intern(&lf[143],15,"define-constant");
lf[144]=C_h_intern(&lf[144],6,"define");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[146]=C_h_intern(&lf[146],8,"\004coreapp");
lf[147]=C_h_intern(&lf[147],8,"location");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[149]=C_h_intern(&lf[149],11,"\004coreinline");
lf[150]=C_h_intern(&lf[150],20,"\004coreinline_allocate");
lf[151]=C_h_intern(&lf[151],19,"\004coreforeign-lambda");
lf[152]=C_h_intern(&lf[152],28,"\004coredefine-foreign-variable");
lf[153]=C_h_intern(&lf[153],29,"\004coredefine-external-variable");
lf[154]=C_h_intern(&lf[154],17,"\004corelet-location");
lf[155]=C_h_intern(&lf[155],22,"\004coreforeign-primitive");
lf[156]=C_h_intern(&lf[156],20,"\004coreforeign-lambda*");
lf[157]=C_h_intern(&lf[157],24,"\004coredefine-foreign-type");
lf[158]=C_h_intern(&lf[158],10,"\003sysexpand");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[160]=C_h_intern(&lf[160],11,"\003sysnumber\077");
lf[161]=C_h_intern(&lf[161],8,"keyword\077");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[163]=C_h_intern(&lf[163],16,"\003syseval-handler");
lf[164]=C_h_intern(&lf[164],12,"eval-handler");
lf[165]=C_h_intern(&lf[165],4,"eval");
lf[166]=C_h_intern(&lf[166],24,"\003syssyntax-error-culprit");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[168]=C_h_intern(&lf[168],12,"load-verbose");
lf[169]=C_h_intern(&lf[169],14,"\003sysabort-load");
lf[170]=C_h_intern(&lf[170],27,"\003syscurrent-source-filename");
lf[171]=C_h_intern(&lf[171],21,"\003syscurrent-load-path");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[173]=C_h_intern(&lf[173],18,"\003sysdload-disabled");
lf[174]=C_h_intern(&lf[174],22,"set-dynamic-load-mode!");
lf[175]=C_h_intern(&lf[175],21,"\003sysset-dlopen-flags!");
lf[176]=C_h_intern(&lf[176],6,"global");
lf[177]=C_h_intern(&lf[177],5,"local");
lf[178]=C_h_intern(&lf[178],4,"lazy");
lf[179]=C_h_intern(&lf[179],3,"now");
lf[180]=C_h_intern(&lf[180],15,"\003syssignal-hook");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[182]=C_h_intern(&lf[182],4,"read");
lf[183]=C_h_intern(&lf[183],7,"newline");
lf[184]=C_h_intern(&lf[184],15,"open-input-file");
lf[185]=C_h_intern(&lf[185],16,"close-input-port");
lf[186]=C_h_intern(&lf[186],13,"string-append");
lf[187]=C_h_intern(&lf[187],8,"\003sysload");
lf[188]=C_h_intern(&lf[188],31,"\003sysread-error-with-line-number");
lf[189]=C_h_intern(&lf[189],17,"\003sysdisplay-times");
lf[190]=C_h_intern(&lf[190],14,"\003sysstop-timer");
lf[191]=C_h_intern(&lf[191],15,"\003sysstart-timer");
lf[192]=C_h_intern(&lf[192],4,"load");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[194]=C_h_intern(&lf[194],9,"peek-char");
lf[195]=C_h_intern(&lf[195],13,"\003syssubstring");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[197]=C_h_intern(&lf[197],30,"call-with-current-continuation");
lf[198]=C_h_intern(&lf[198],9,"\003sysdload");
lf[199]=C_h_intern(&lf[199],17,"\003sysmake-c-string");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[201]=C_h_intern(&lf[201],11,"\000file-error");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[205]=C_h_intern(&lf[205],13,"\003sysfile-info");
lf[206]=C_h_intern(&lf[206],26,"\003sysload-dynamic-extension");
lf[207]=C_h_intern(&lf[207],11,"\000type-error");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[209]=C_h_intern(&lf[209],5,"port\077");
lf[210]=C_h_intern(&lf[210],20,"\003sysexpand-home-path");
lf[211]=C_h_intern(&lf[211],13,"load-relative");
lf[212]=C_h_intern(&lf[212],12,"load-noisily");
lf[213]=C_h_intern(&lf[213],15,"\003sysget-keyword");
lf[214]=C_h_intern(&lf[214],8,"\000printer");
lf[215]=C_h_intern(&lf[215],5,"\000time");
lf[216]=C_h_intern(&lf[216],10,"\000evaluator");
lf[217]=C_h_intern(&lf[217],26,"\003sysload-library-extension");
lf[218]=C_h_intern(&lf[218],6,"cygwin");
lf[219]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[221]=C_h_intern(&lf[221],34,"\003sysdefault-dynamic-load-libraries");
lf[222]=C_h_intern(&lf[222],22,"dynamic-load-libraries");
lf[223]=C_h_intern(&lf[223],16,"\003sysload-library");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[228]=C_h_intern(&lf[228],24,"\003sysstring->c-identifier");
lf[229]=C_h_intern(&lf[229],16,"\003sys->feature-id");
lf[230]=C_h_intern(&lf[230],12,"load-library");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[232]=C_h_intern(&lf[232],31,"\003syscanonicalize-extension-path");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[234]=C_h_intern(&lf[234],18,"\003syssymbol->string");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[238]=C_h_intern(&lf[238],19,"\003sysrepository-path");
lf[239]=C_h_intern(&lf[239],15,"repository-path");
lf[240]=C_h_intern(&lf[240],12,"file-exists\077");
lf[241]=C_h_intern(&lf[241],18,"\003sysfind-extension");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[244]=C_h_intern(&lf[244],21,"\003sysinclude-pathnames");
lf[245]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[246]=C_h_intern(&lf[246],21,"\003sysloaded-extensions");
lf[247]=C_h_intern(&lf[247],14,"string->symbol");
lf[248]=C_h_intern(&lf[248],18,"\003sysload-extension");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot load extension");
lf[250]=C_h_intern(&lf[250],11,"\003sysprovide");
lf[251]=C_h_intern(&lf[251],7,"provide");
lf[252]=C_h_intern(&lf[252],13,"\003sysprovided\077");
lf[253]=C_h_intern(&lf[253],9,"provided\077");
lf[254]=C_h_intern(&lf[254],7,"require");
lf[255]=C_h_intern(&lf[255],25,"\003sysextension-information");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[259]=C_h_intern(&lf[259],21,"extension-information");
lf[260]=C_h_intern(&lf[260],18,"require-at-runtime");
lf[261]=C_h_intern(&lf[261],12,"vector->list");
lf[262]=C_h_intern(&lf[262],14,"dynamic/syntax");
lf[263]=C_h_intern(&lf[263],7,"dynamic");
lf[264]=C_h_intern(&lf[264],11,"lset-adjoin");
lf[265]=C_h_intern(&lf[265],3,"eq\077");
lf[266]=C_h_intern(&lf[266],26,"\010compilerfile-requirements");
lf[267]=C_h_intern(&lf[267],6,"import");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\003\000\000\002\376\001\000\000\007srfi-69\376\003\000\000\002\376\001\000\000\007srfi-98\376\377\016");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[270]=C_h_intern(&lf[270],4,"uses");
lf[271]=C_h_intern(&lf[271],17,"require-extension");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[273]=C_h_intern(&lf[273],12,"\003sysfeature\077");
lf[274]=C_h_intern(&lf[274],24,"\003sysextension-specifiers");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[277]=C_h_intern(&lf[277],24,"set-extension-specifier!");
lf[278]=C_h_intern(&lf[278],11,"string-copy");
lf[281]=C_h_intern(&lf[281],11,"environment");
lf[283]=C_h_intern(&lf[283],16,"\003sysenvironment\077");
lf[284]=C_h_intern(&lf[284],18,"\003syscopy-env-table");
lf[285]=C_h_intern(&lf[285],23,"\003sysenvironment-symbols");
lf[286]=C_h_intern(&lf[286],18,"\003syswalk-namespace");
lf[287]=C_h_intern(&lf[287],23,"interaction-environment");
lf[288]=C_h_intern(&lf[288],25,"scheme-report-environment");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[290]=C_h_intern(&lf[290],11,"make-vector");
lf[291]=C_h_intern(&lf[291],16,"null-environment");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[293]=C_h_intern(&lf[293],28,"\003sysresolve-include-filename");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[301]=C_h_intern(&lf[301],18,"\003sysrepl-eval-hook");
lf[302]=C_h_intern(&lf[302],27,"\003sysrepl-print-length-limit");
lf[303]=C_h_intern(&lf[303],18,"\003sysrepl-read-hook");
lf[304]=C_h_intern(&lf[304],19,"\003sysrepl-print-hook");
lf[305]=C_h_intern(&lf[305],16,"\003syswrite-char-0");
lf[306]=C_h_intern(&lf[306],9,"\003sysprint");
lf[307]=C_h_intern(&lf[307],27,"\003syswith-print-length-limit");
lf[308]=C_h_intern(&lf[308],11,"repl-prompt");
lf[309]=C_h_intern(&lf[309],20,"\003sysread-prompt-hook");
lf[310]=C_h_intern(&lf[310],16,"\003sysflush-output");
lf[311]=C_h_intern(&lf[311],19,"\003sysstandard-output");
lf[312]=C_h_intern(&lf[312],22,"\003sysclear-trace-buffer");
lf[313]=C_h_intern(&lf[313],16,"print-call-chain");
lf[314]=C_h_intern(&lf[314],12,"flush-output");
lf[315]=C_h_intern(&lf[315],5,"reset");
lf[316]=C_h_intern(&lf[316],4,"repl");
lf[317]=C_h_intern(&lf[317],18,"\003sysstandard-error");
lf[318]=C_h_intern(&lf[318],18,"\003sysstandard-input");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\006\012Error");
lf[322]=C_h_intern(&lf[322],17,"\003syserror-handler");
lf[323]=C_h_intern(&lf[323],20,"\003syswarnings-enabled");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[327]=C_h_intern(&lf[327],15,"\003sysread-char-0");
lf[328]=C_h_intern(&lf[328],15,"\003syspeek-char-0");
lf[329]=C_h_intern(&lf[329],21,"\003sysenable-qualifiers");
lf[330]=C_h_intern(&lf[330],17,"\003sysreset-handler");
lf[331]=C_h_intern(&lf[331],28,"\003syssharp-comma-reader-ctors");
lf[332]=C_h_intern(&lf[332],18,"define-reader-ctor");
lf[333]=C_h_intern(&lf[333],18,"\003sysuser-read-hook");
lf[334]=C_h_intern(&lf[334],9,"read-char");
lf[335]=C_h_intern(&lf[335],14,"\003sysread-error");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[340]=C_h_intern(&lf[340],19,"print-error-message");
lf[341]=C_h_intern(&lf[341],22,"with-exception-handler");
lf[343]=C_h_intern(&lf[343],6,"\003sysgc");
lf[345]=C_h_intern(&lf[345],13,"thread-yield!");
lf[348]=C_h_intern(&lf[348],17,"open-input-string");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[359]=C_h_intern(&lf[359],15,"\003sysmake-string");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[361]=C_h_intern(&lf[361],14,"make-parameter");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[365]=C_h_intern(&lf[365],18,"\003sysnumber->string");
lf[366]=C_h_intern(&lf[366],5,"error");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[368]=C_h_intern(&lf[368],7,"version");
lf[369]=C_h_intern(&lf[369],2,"id");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[371]=C_h_intern(&lf[371],9,"string>=\077");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[373]=C_h_intern(&lf[373],12,"list->vector");
lf[374]=C_h_intern(&lf[374],18,"\003sysstring->symbol");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[376]=C_h_intern(&lf[376],4,"srfi");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[378]=C_h_intern(&lf[378],6,"getenv");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[380]=C_h_intern(&lf[380],14,"build-platform");
lf[381]=C_h_intern(&lf[381],7,"windows");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[383]=C_h_intern(&lf[383],6,"macosx");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[386]=C_h_intern(&lf[386],4,"hpux");
lf[387]=C_h_intern(&lf[387],4,"hppa");
lf[388]=C_h_intern(&lf[388],12,"machine-type");
lf[389]=C_h_intern(&lf[389],16,"software-version");
lf[390]=C_h_intern(&lf[390],13,"software-type");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[392]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
C_register_lf2(lf,396,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3327,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_expand_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3325 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3329,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! core-library-modules ...) */,lf[4]);
t4=C_set_block_item(lf[5] /* explicit-library-modules */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[6] /* (set! constant108 ...) */,lf[7]);
t6=C_mutate(&lf[8] /* (set! constant120 ...) */,lf[9]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 133  getenv */
t8=*((C_word*)lf[378]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[395]);}

/* k3358 in k3325 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[392]);
t7=(C_truep(t6)?lf[393]:lf[394]);
/* eval.scm: 134  ##sys#string-append */
t8=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_3363(2,t3,C_SCHEME_FALSE);}}

/* k3361 in k3358 in k3325 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1 /* (set! chicken-prefix ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[12]+1 /* (set! chicken-home ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3391,tmp=(C_word)a,a+=2,tmp));
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[15]+1 /* (set! hash-symbol ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[16]+1 /* (set! hash-table-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3418,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3473,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[18]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3533,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[19]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3553,tmp=(C_word)a,a+=2,tmp));
t13=(C_word)C_slot(lf[21],C_fix(0));
t14=C_mutate((C_word*)lf[22]+1 /* (set! hash-table-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3599,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[23] /* eval-environment */,0,C_SCHEME_FALSE);
t16=C_set_block_item(lf[24] /* environment-is-mutable */,0,C_SCHEME_FALSE);
t17=C_mutate((C_word*)lf[25]+1 /* (set! eval-decorator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3659,tmp=(C_word)a,a+=2,tmp));
t18=C_set_block_item(lf[31] /* unbound-in-eval */,0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[32] /* eval-debug-level */,0,C_fix(1));
t20=*((C_word*)lf[28]+1);
t21=*((C_word*)lf[33]+1);
t22=*((C_word*)lf[29]+1);
t23=*((C_word*)lf[27]+1);
t24=*((C_word*)lf[34]+1);
t25=(C_word)C_slot(lf[21],C_fix(0));
t26=*((C_word*)lf[35]+1);
t27=C_mutate((C_word*)lf[36]+1 /* (set! compile-to-closure ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=t21,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6568,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10180,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 812  make-parameter */
t30=*((C_word*)lf[361]+1);
((C_proc3)(void*)(*((C_word*)t30+1)))(3,t30,t28,t29);}

/* a10179 in k3361 in k3358 in k3325 */
static void C_ccall f_10180(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10180r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10180r(t0,t1,t2,t3);}}

static void C_ccall f_10180r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[24]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10184,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[281]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_10184(t15,t14);}
else{
t10=t8;
f_10184(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_10184(t9,C_SCHEME_UNDEFINED);}}

/* k10182 in a10179 in k3361 in k3358 in k3325 */
static void C_fcall f_10184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10184,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10190,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10192,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10209,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t14=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a10208 in k10182 in a10179 in k3361 in k3358 in k3325 */
static void C_ccall f_10209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10209,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[24]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[23]+1));
t4=C_mutate((C_word*)lf[24]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[23]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a10198 in k10182 in a10179 in k3361 in k3358 in k3325 */
static void C_ccall f_10199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10207,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 824  ##sys#current-environment */
t3=*((C_word*)lf[107]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10205 in a10198 in k10182 in a10179 in k3361 in k3358 in k3325 */
static void C_ccall f_10207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 824  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* a10191 in k10182 in a10179 in k3361 in k3358 in k3325 */
static void C_ccall f_10192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10192,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[24]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[23]+1));
t4=C_mutate((C_word*)lf[24]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[23]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k10188 in k10182 in a10179 in k3361 in k3358 in k3325 */
static void C_ccall f_10190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6568,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1 /* (set! eval-handler ...) */,t1);
t3=C_mutate((C_word*)lf[164]+1 /* (set! eval-handler ...) */,*((C_word*)lf[163]+1));
t4=C_mutate((C_word*)lf[165]+1 /* (set! eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6571,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[33]+1);
t6=C_mutate((C_word*)lf[94]+1 /* (set! decompose-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6581,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 856  make-parameter */
t9=*((C_word*)lf[361]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6663,2,t0,t1);}
t2=C_mutate((C_word*)lf[168]+1 /* (set! load-verbose ...) */,t1);
t3=C_mutate((C_word*)lf[169]+1 /* (set! abort-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6665,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[170] /* current-source-filename */,0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[171]+1 /* (set! current-load-path ...) */,lf[172]);
t6=C_set_block_item(lf[173] /* dload-disabled */,0,C_SCHEME_FALSE);
t7=C_mutate((C_word*)lf[174]+1 /* (set! set-dynamic-load-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6671,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[182]+1);
t9=*((C_word*)lf[28]+1);
t10=*((C_word*)lf[35]+1);
t11=*((C_word*)lf[183]+1);
t12=*((C_word*)lf[165]+1);
t13=*((C_word*)lf[184]+1);
t14=*((C_word*)lf[185]+1);
t15=*((C_word*)lf[186]+1);
t16=*((C_word*)lf[168]+1);
t17=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6744,a[2]=((C_word*)t0)[2],a[3]=t16,a[4]=t10,a[5]=t13,a[6]=t14,a[7]=t9,a[8]=t11,a[9]=t8,a[10]=t12,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 889  ##sys#make-c-string */
t18=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,t17,lf[391]);}

/* k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6746,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[187]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp));
t4=C_mutate((C_word*)lf[192]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7185,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[211]+1 /* (set! load-relative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7207,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[212]+1 /* (set! load-noisily ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7243,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7269,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10174,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 981  software-type */
t9=*((C_word*)lf[390]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k10172 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10174,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[381]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7269(t3,lf[382]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10170,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 982  software-version */
t4=*((C_word*)lf[389]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10168 in k10172 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10170,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[383]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7269(t3,lf[384]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10166,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 983  software-version */
t5=*((C_word*)lf[389]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10164 in k10168 in k10172 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10166,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[386]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 984  machine-type */
t4=*((C_word*)lf[388]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_10152(t3,C_SCHEME_FALSE);}}

/* k10160 in k10164 in k10168 in k10172 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10152(t2,(C_word)C_eqp(t1,lf[387]));}

/* k10150 in k10168 in k10172 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_10152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7269(t2,(C_truep(t1)?lf[385]:lf[6]));}

/* k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7269,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[217]+1 /* (set! load-library-extension ...) */,t1);
t3=C_mutate((C_word*)lf[206]+1 /* (set! load-dynamic-extension ...) */,lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 990  build-platform */
t5=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7274,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[218]);
t3=(C_truep(t2)?lf[219]:lf[220]);
t4=C_mutate((C_word*)lf[221]+1 /* (set! default-dynamic-load-libraries ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7281,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10122,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10130,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[221]+1));}

/* a10129 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10130,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[217]+1));}

/* k10120 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10124,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 995  make-parameter */
t3=*((C_word*)lf[361]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a10123 in k10120 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10124,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7281,2,t0,t1);}
t2=C_mutate((C_word*)lf[222]+1 /* (set! dynamic-load-libraries ...) */,t1);
t3=*((C_word*)lf[168]+1);
t4=*((C_word*)lf[186]+1);
t5=*((C_word*)lf[222]+1);
t6=*((C_word*)lf[35]+1);
t7=C_mutate((C_word*)lf[223]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7283,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[230]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7389,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[33]+1);
t10=*((C_word*)lf[186]+1);
t11=C_mutate((C_word*)lf[232]+1 /* (set! canonicalize-extension-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7474,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10091,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1083 getenv */
t14=*((C_word*)lf[378]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,lf[379]);}

/* k10089 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_10094(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10097,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10107,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10111,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:C_fix(4));
/* eval.scm: 1087 ##sys#number->string */
t8=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k10109 in k10089 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1085 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[377],t1);}

/* k10105 in k10089 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1084 ##sys#chicken-prefix */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10095 in k10089 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10097,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10094(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k10092 in k10089 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1082 make-parameter */
t2=*((C_word*)lf[361]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7634,2,t0,t1);}
t2=C_mutate((C_word*)lf[238]+1 /* (set! repository-path ...) */,t1);
t3=C_mutate((C_word*)lf[239]+1 /* (set! repository-path ...) */,*((C_word*)lf[238]+1));
t4=*((C_word*)lf[240]+1);
t5=*((C_word*)lf[186]+1);
t6=C_mutate((C_word*)lf[241]+1 /* (set! find-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7637,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[246] /* loaded-extensions */,0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[247]+1);
t9=C_mutate((C_word*)lf[248]+1 /* (set! load-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7731,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[250]+1 /* (set! provide ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7799,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[251]+1 /* (set! provide ...) */,*((C_word*)lf[250]+1));
t12=C_mutate((C_word*)lf[252]+1 /* (set! provided? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7819,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[253]+1 /* (set! provided? ...) */,*((C_word*)lf[252]+1));
t14=C_mutate((C_word*)lf[123]+1 /* (set! require ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7833,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[254]+1 /* (set! require ...) */,*((C_word*)lf[123]+1));
t16=*((C_word*)lf[34]+1);
t17=*((C_word*)lf[240]+1);
t18=*((C_word*)lf[186]+1);
t19=*((C_word*)lf[182]+1);
t20=C_mutate((C_word*)lf[255]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7846,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=C_mutate((C_word*)lf[259]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7879,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[34]+1);
t23=*((C_word*)lf[182]+1);
t24=C_mutate((C_word*)lf[124]+1 /* (set! lookup-runtime-requirements ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7885,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[261]+1);
t26=C_mutate((C_word*)lf[127]+1 /* (set! do-the-right-thing ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7934,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(lf[274] /* extension-specifiers */,0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[277]+1 /* (set! set-extension-specifier! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8433,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[373]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10037,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1290 set-extension-specifier! */
t32=*((C_word*)lf[277]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[376],t31);}

/* a10036 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10037,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10045,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10051,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_10051(t9,t4,t5);}

/* loop in a10036 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_10051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10051,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[271]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10071,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10083,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10087,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1300 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k10085 in loop in a10036 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1300 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[375],t1);}

/* k10081 in loop in a10036 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1300 ##sys#string->symbol */
t2=*((C_word*)lf[374]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10069 in loop in a10036 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10075,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1301 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10051(t4,t2,t3);}

/* k10073 in k10069 in loop in a10036 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10075,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10043 in a10036 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1294 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9940,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1306 set-extension-specifier! */
t4=*((C_word*)lf[277]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[368],t3);}

/* a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9940,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9943,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9977,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_a_i_list(&a,1,t2);
if(C_truep(t6)){
t7=(C_word)C_i_length(t2);
t8=t5;
f_9977(t8,(C_word)C_eqp(C_fix(3),t7));}
else{
t7=t5;
f_9977(t7,C_SCHEME_FALSE);}}

/* k9975 in a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9977,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* eval.scm: 1315 extension-information */
t4=*((C_word*)lf[259]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
/* eval.scm: 1320 ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[372],((C_word*)t0)[3]);}}

/* k9978 in k9975 in a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9980,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[368],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9986,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9989,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1317 ->string */
f_9943(t5,t6);}
else{
t5=t4;
f_9989(2,t5,C_SCHEME_FALSE);}}

/* k10001 in k9978 in k9975 in a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10007,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1317 ->string */
f_9943(t2,t3);}

/* k10005 in k10001 in k9978 in k9975 in a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_10007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1317 string>=? */
t2=*((C_word*)lf[371]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9987 in k9978 in k9975 in a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9986(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1318 error */
t3=*((C_word*)lf[366]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[370],*((C_word*)lf[369]+1),((C_word*)t0)[2],t2);}}

/* k9984 in k9978 in k9975 in a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[369]+1));}

/* ->string in a9939 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9943(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9943,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1312 ##sys#number->string */
t3=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1313 error */
t3=*((C_word*)lf[366]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[367],t2);}}}}

/* k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8475,2,t0,t1);}
t2=*((C_word*)lf[278]+1);
t3=C_mutate((C_word*)lf[228]+1 /* (set! string->c-identifier ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8477,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1339 make-vector */
t5=*((C_word*)lf[290]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8533,2,t0,t1);}
t2=C_mutate(&lf[279] /* (set! r4rs-environment ...) */,t1);
t3=lf[280] /* r5rs-environment */ =C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[281],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[282] /* (set! interaction-environment ...) */,t4);
t6=C_mutate((C_word*)lf[283]+1 /* (set! environment? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8540,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[284]+1 /* (set! copy-env-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8556,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[285]+1 /* (set! environment-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8664,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[287]+1 /* (set! interaction-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8783,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[288]+1 /* (set! scheme-report-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8786,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[290]+1);
t12=C_mutate((C_word*)lf[291]+1 /* (set! null-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8830,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8868,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8884,a[2]=t13,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9938,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1423 initb */
f_8868(t15,lf[279]);}

/* k9936 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[364]);}

/* k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1444 ##sys#copy-env-table */
t3=*((C_word*)lf[284]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[279],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8888,2,t0,t1);}
t2=C_mutate(&lf[280] /* (set! r5rs-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8891,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9934,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1446 initb */
f_8868(t4,lf[280]);}

/* k9932 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[363]);}

/* k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1453 chicken-home */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8895,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[244]+1 /* (set! include-pathnames ...) */,t2);
t4=*((C_word*)lf[186]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8901,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[293]+1 /* (set! resolve-include-filename ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8920,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[35]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9062,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9086,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[189]+1 /* (set! display-times ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9107,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1522 append */
t12=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,lf[362],*((C_word*)lf[138]+1));}

/* k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9162,2,t0,t1);}
t2=C_mutate((C_word*)lf[138]+1 /* (set! features ...) */,t1);
t3=C_set_block_item(lf[301] /* repl-eval-hook */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[302] /* repl-print-length-limit */,0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[303] /* repl-read-hook */,0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[304]+1 /* (set! repl-print-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9167,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9184,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9926,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1536 make-parameter */
t9=*((C_word*)lf[361]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9925 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9926,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[360]);}

/* k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9184,2,t0,t1);}
t2=C_mutate((C_word*)lf[308]+1 /* (set! repl-prompt ...) */,t1);
t3=*((C_word*)lf[308]+1);
t4=C_mutate((C_word*)lf[309]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9186,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[312]+1 /* (set! clear-trace-buffer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9202,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[165]+1);
t7=*((C_word*)lf[182]+1);
t8=*((C_word*)lf[197]+1);
t9=*((C_word*)lf[313]+1);
t10=*((C_word*)lf[314]+1);
t11=*((C_word*)lf[168]+1);
t12=*((C_word*)lf[315]+1);
t13=C_mutate((C_word*)lf[316]+1 /* (set! repl ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9205,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1652 make-vector */
t15=*((C_word*)lf[290]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9544,2,t0,t1);}
t2=C_mutate((C_word*)lf[331]+1 /* (set! sharp-comma-reader-ctors ...) */,t1);
t3=C_mutate((C_word*)lf[332]+1 /* (set! define-reader-ctor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9546,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[333]+1);
t5=*((C_word*)lf[334]+1);
t6=*((C_word*)lf[182]+1);
t7=C_mutate((C_word*)lf[333]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9555,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=lf[338] /* last-error */ =C_SCHEME_FALSE;;
t9=C_mutate(&lf[339] /* (set! run-safe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9630,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[342] /* (set! store-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9689,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[344] /* (set! CHICKEN_yield ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9698,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[346] /* (set! CHICKEN_eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9710,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[347] /* (set! CHICKEN_eval_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9726,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[349] /* (set! store-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9752,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[351] /* (set! CHICKEN_eval_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9765,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[352] /* (set! CHICKEN_eval_string_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9791,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[353] /* (set! CHICKEN_apply ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9828,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[354] /* (set! CHICKEN_apply_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9844,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[355] /* (set! CHICKEN_read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9870,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[356] /* (set! CHICKEN_load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9892,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[357] /* (set! CHICKEN_get_error_message ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9907,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[26]+1 /* (set! make-lambda-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9917,tmp=(C_word)a,a+=2,tmp));
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9917,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9924,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1783 ##sys#make-string */
t5=*((C_word*)lf[359]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9922 in ##sys#make-lambda-info in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9907,4,t0,t1,t2,t3);}
t4=lf[338];
t5=(C_truep(t4)?t4:lf[358]);
/* eval.scm: 1776 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9752(t5,t3,t2));}

/* CHICKEN_load in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9892,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9896,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9894 in CHICKEN_load in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9901,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1773 run-safe */
f_9630(((C_word*)t0)[2],t2);}

/* a9900 in k9894 in CHICKEN_load in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9905,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1773 load */
t3=*((C_word*)lf[192]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9903 in a9900 in k9894 in CHICKEN_load in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9870,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9874,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9872 in CHICKEN_read in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9874,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9879,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1767 run-safe */
f_9630(((C_word*)t0)[2],t3);}

/* a9878 in k9872 in CHICKEN_read in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9883,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1769 open-input-string */
t3=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9881 in a9878 in k9872 in CHICKEN_read in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1770 read */
t3=*((C_word*)lf[182]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9888 in k9881 in a9878 in k9872 in CHICKEN_read in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1770 store-result */
f_9689(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9844,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9850,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1760 run-safe */
f_9630(t1,t6);}

/* a9849 in CHICKEN_apply_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1762 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9852 in a9849 in CHICKEN_apply_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9857,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9868,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9866 in k9852 in a9849 in CHICKEN_apply_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1763 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9855 in k9852 in a9849 in CHICKEN_apply_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1764 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9862 in k9855 in k9852 in a9849 in CHICKEN_apply_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1764 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9752(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9828,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9834,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1755 run-safe */
f_9630(t1,t5);}

/* a9833 in CHICKEN_apply in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9842,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9840 in a9833 in CHICKEN_apply in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1755 store-result */
f_9689(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9791,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9795,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9795,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9800,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1746 run-safe */
f_9630(((C_word*)t0)[2],t4);}

/* a9799 in k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1748 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9802 in a9799 in k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9807,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9818,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9822,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9826,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1749 open-input-string */
t6=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9824 in k9802 in a9799 in k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1749 read */
t2=*((C_word*)lf[182]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9820 in k9802 in a9799 in k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1749 eval */
t2=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9816 in k9802 in a9799 in k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1749 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9805 in k9802 in a9799 in k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1750 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9812 in k9805 in k9802 in a9799 in k9793 in CHICKEN_eval_string_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1750 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9752(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9765,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9771,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1737 run-safe */
f_9630(t1,t5);}

/* a9770 in CHICKEN_eval_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1739 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9773 in a9770 in CHICKEN_eval_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9778,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9789,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1740 eval */
t4=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9787 in k9773 in a9770 in CHICKEN_eval_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1740 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9776 in k9773 in a9770 in CHICKEN_eval_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1741 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9783 in k9776 in k9773 in a9770 in CHICKEN_eval_to_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1741 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9752(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static C_word C_fcall f_9752(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[338] /* (set! last-error ...) */,lf[350]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9726,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9730,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9728 in CHICKEN_eval_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9730,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9735,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1718 run-safe */
f_9630(((C_word*)t0)[2],t3);}

/* a9734 in k9728 in CHICKEN_eval_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9739,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1720 open-input-string */
t3=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9737 in a9734 in k9728 in CHICKEN_eval_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9750,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1721 read */
t4=*((C_word*)lf[182]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9748 in k9737 in a9734 in k9728 in CHICKEN_eval_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1721 eval */
t2=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9744 in k9737 in a9734 in k9728 in CHICKEN_eval_string in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1721 store-result */
f_9689(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9710,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9716,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1713 run-safe */
f_9630(t1,t4);}

/* a9715 in CHICKEN_eval in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9724,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1715 eval */
t3=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9722 in a9715 in CHICKEN_eval in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1715 store-result */
f_9689(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9704,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1710 run-safe */
f_9630(t1,t2);}

/* a9703 in CHICKEN_yield in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9708,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1710 thread-yield! */
t3=*((C_word*)lf[345]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9706 in a9703 in CHICKEN_yield in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9689(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9689,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9693,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1704 ##sys#gc */
t5=*((C_word*)lf[343]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9691 in store-result in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9630(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9630,NULL,2,t1,t2);}
t3=lf[338] /* last-error */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9638,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9640,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t6=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9640,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9646,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9665,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9664 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9671,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9677,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9676 in a9664 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9677(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9677r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9677r(t0,t1,t2);}}

static void C_ccall f_9677r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9683,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k29862991 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9682 in a9676 in a9664 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9683,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9670 in a9664 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9671,2,t0,t1);}
/* eval.scm: 1697 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9645 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9646,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9652,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k29862991 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9651 in a9645 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9656,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1693 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9654 in a9651 in a9645 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9659,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1694 print-error-message */
t3=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9657 in k9654 in a9651 in a9645 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9663,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1695 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9661 in k9657 in k9654 in a9651 in a9645 in a9639 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[338] /* (set! last-error ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9636 in run-safe in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9555,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9565,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1664 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 1676 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9563 in ##sys#user-read-hook in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1665 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9566 in k9563 in ##sys#user-read-hook in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9569,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9582,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9582(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9582(t6,(C_word)C_i_not(t5));}}

/* k9580 in k9566 in k9563 in ##sys#user-read-hook in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9582,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1668 err */
t2=((C_word*)t0)[5];
f_9569(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9600,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1672 ##sys#hash-table-ref */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[331]+1),t2);}
else{
/* eval.scm: 1671 err */
t3=((C_word*)t0)[5];
f_9569(t3,((C_word*)t0)[4]);}}}

/* k9598 in k9580 in k9566 in k9563 in ##sys#user-read-hook in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 1675 ##sys#read-error */
t2=*((C_word*)lf[335]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[337],((C_word*)t0)[2]);}}

/* err in k9566 in k9563 in ##sys#user-read-hook in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9569,NULL,2,t0,t1);}
/* eval.scm: 1666 ##sys#read-error */
t2=*((C_word*)lf[335]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[336],((C_word*)t0)[2]);}

/* define-reader-ctor in k9542 in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9546,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[332]);
/* eval.scm: 1656 ##sys#hash-table-set! */
t5=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[331]+1),t2,t3);}

/* repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9208,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[318]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[311]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[317]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9249,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1566 ##sys#error-handler */
t10=*((C_word*)lf[322]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9252,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1567 ##sys#reset-handler */
t3=*((C_word*)lf[330]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9252,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[31]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9254,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9260,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9269,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9334,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9529,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1581 ##sys#dynamic-wind */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9528 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9533,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1644 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9531 in a9528 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9533,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! unbound-in-eval ...) */,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1646 ##sys#error-handler */
t4=*((C_word*)lf[322]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9535 in k9531 in a9528 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1647 ##sys#reset-handler */
t2=*((C_word*)lf[330]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9334,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9340(t5,t1);}

/* loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9340,NULL,2,t0,t1);}
t2=f_9254(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9512,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1604 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9511 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9512,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9518,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1606 ##sys#reset-handler */
t4=*((C_word*)lf[330]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9517 in a9511 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
t2=C_set_block_item(lf[188] /* read-error-with-line-number */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[329] /* enable-qualifiers */,0,C_SCHEME_TRUE);
t4=f_9260(((C_word*)t0)[3]);
/* eval.scm: 1611 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1612 ##sys#read-prompt-hook */
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[303]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9353,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9362,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9507,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1615 ##sys#peek-char-0 */
t4=*((C_word*)lf[328]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[318]+1));}}

/* k9505 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 1616 ##sys#read-char-0 */
t3=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[318]+1));}
else{
t3=((C_word*)t0)[2];
f_9362(2,t3,C_SCHEME_UNDEFINED);}}

/* k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1617 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[312]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9365,2,t0,t1);}
t2=C_set_block_item(lf[31] /* unbound-in-eval */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9371,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9380,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9380(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9380r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9380r(t0,t1,t2);}}

static void C_ccall f_9380r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9384,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[323]+1))?(C_word)C_i_pairp(*((C_word*)lf[31]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9398,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9398(t8,t3,*((C_word*)lf[31]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9384(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9398(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9398,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9402,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9414,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1624 ##sys#print */
t6=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[326],C_SCHEME_FALSE,*((C_word*)lf[317]+1));}
else{
t5=t4;
f_9402(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9461,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9461(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 1638 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9459 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9461,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1639 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9398(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 1640 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9398(t5,((C_word*)t0)[3],t2,t4);}}

/* k9412 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9419,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9418 in k9412 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9419,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9423,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1629 ##sys#print */
t4=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[325],C_SCHEME_FALSE,*((C_word*)lf[317]+1));}

/* k9421 in a9418 in k9412 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 1630 ##sys#print */
t4=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[317]+1));}

/* k9424 in k9421 in a9418 in k9412 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9429,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9438,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1632 ##sys#print */
t4=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[324],C_SCHEME_FALSE,*((C_word*)lf[317]+1));}
else{
t3=t2;
f_9429(2,t3,C_SCHEME_UNDEFINED);}}

/* k9436 in k9424 in k9421 in a9418 in k9412 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9441,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 1633 ##sys#print */
t4=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[317]+1));}

/* k9439 in k9436 in k9424 in k9421 in a9418 in k9412 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1634 ##sys#write-char-0 */
t2=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[317]+1));}

/* k9427 in k9424 in k9421 in a9418 in k9412 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1635 ##sys#write-char-0 */
t2=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[317]+1));}

/* k9400 in loop in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9382 in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9230,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_9230(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_9230(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k9228 in k9382 in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9230,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9387(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9235,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a9234 in k9228 in k9382 in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9235,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[304]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[311]+1));}

/* k9385 in k9382 in a9379 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1642 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9340(t2,((C_word*)t0)[2]);}

/* a9370 in k9363 in k9360 in k9351 in k9348 in k9345 in loop in a9333 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9371,2,t0,t1);}
t2=*((C_word*)lf[301]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9274,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1583 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9274,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1584 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1585 ##sys#error-handler */
t3=*((C_word*)lf[322]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9282(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9282r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9282r(t0,t1,t2,t3);}}

static void C_ccall f_9282r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_9260(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9289,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1588 ##sys#print */
t6=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[321],C_SCHEME_FALSE,*((C_word*)lf[317]+1));}

/* k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9329,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1590 ##sys#print */
t4=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[320],C_SCHEME_FALSE,*((C_word*)lf[317]+1));}
else{
t3=t2;
f_9292(2,t3,C_SCHEME_UNDEFINED);}}

/* k9327 in k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1591 ##sys#print */
t2=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[317]+1));}

/* k9290 in k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9295,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9304,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9304(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9304(t4,C_SCHEME_FALSE);}}

/* k9302 in k9290 in k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9304,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1594 ##sys#print */
t3=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[319],C_SCHEME_FALSE,*((C_word*)lf[317]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1597 ##sys#write-char-0 */
t3=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[317]+1));}}

/* k9311 in k9302 in k9290 in k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1598 write-err */
f_9208(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9305 in k9302 in k9290 in k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1595 write-err */
f_9208(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9293 in k9290 in k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1599 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[317]+1));}

/* k9296 in k9293 in k9290 in k9287 in a9281 in k9275 in k9272 in a9268 in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1600 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[317]+1));}

/* resetports in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static C_word C_fcall f_9260(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[318]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[311]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[317]+1 /* (set! standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k9250 in k9247 in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static C_word C_fcall f_9254(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[318]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[311]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[317]+1));
return(t3);}

/* write-err in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9208(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9208,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9214,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9213 in write-err in repl in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9214,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[304]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[317]+1));}

/* ##sys#clear-trace-buffer in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9202,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2772(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9190,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9200,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1541 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9198 in ##sys#read-prompt-hook in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9195 in ##sys#read-prompt-hook in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1541 ##sys#print */
t2=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[311]+1));}

/* k9188 in ##sys#read-prompt-hook in k9182 in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1542 ##sys#flush-output */
t2=*((C_word*)lf[310]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[311]+1));}

/* ##sys#repl-print-hook in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9167,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9171,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9176,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1533 ##sys#with-print-length-limit */
t6=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[302]+1),t5);}

/* a9175 in ##sys#repl-print-hook in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[306]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k9169 in ##sys#repl-print-hook in k9160 in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1534 ##sys#write-char-0 */
t2=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9107,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9111,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1507 display-rj */
t5=((C_word*)t0)[2];
f_9086(t5,t3,t4,C_fix(8));}

/* k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1508 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[300]);}

/* k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1509 display-rj */
t4=((C_word*)t0)[2];
f_9086(t4,t2,t3,C_fix(8));}

/* k9115 in k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1510 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[299]);}

/* k9118 in k9115 in k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1511 display-rj */
t4=((C_word*)t0)[2];
f_9086(t4,t2,t3,C_fix(8));}

/* k9121 in k9118 in k9115 in k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1512 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[298]);}

/* k9124 in k9121 in k9118 in k9115 in k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1513 display-rj */
t4=((C_word*)t0)[2];
f_9086(t4,t2,t3,C_fix(8));}

/* k9127 in k9124 in k9121 in k9118 in k9115 in k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1514 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[297]);}

/* k9130 in k9127 in k9124 in k9121 in k9118 in k9115 in k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9135,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1515 display-rj */
t4=((C_word*)t0)[2];
f_9086(t4,t2,t3,C_fix(8));}

/* k9133 in k9130 in k9127 in k9124 in k9121 in k9118 in k9115 in k9112 in k9109 in ##sys#display-times in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1516 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[296]);}

/* display-rj in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9086,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9090,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_9090(2,t5,lf[295]);}
else{
/* eval.scm: 1502 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k9088 in display-rj in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9090,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9093,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1504 spaces */
t5=((C_word*)t0)[2];
f_9062(t5,t3,t4);}

/* k9091 in k9088 in display-rj in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1505 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9062,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9068,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9068(t6,t1,t2);}

/* doloop2710 in spaces in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9068(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9068,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9078,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1499 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k9076 in doloop2710 in spaces in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9068(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8920r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8920r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8920r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8926,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8961,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8991,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1475 test */
t12=t10;
f_8961(t12,t11,t2);}

/* k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8991,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9001,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9038,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1479 ##sys#repository-path */
t4=*((C_word*)lf[238]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_9001(2,t3,*((C_word*)lf[244]+1));}}}

/* k9036 in k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9048,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1481 ##sys#repository-path */
t4=*((C_word*)lf[238]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_9041(t3,C_SCHEME_END_OF_LIST);}}

/* k9046 in k9036 in k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9048,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9041(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9039 in k9036 in k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1477 ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[244]+1),t1);}

/* k8999 in k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9001,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_9003(t5,((C_word*)t0)[2],t1);}

/* loop in k8999 in k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_9003(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9003,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9027,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1485 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[294],((C_word*)t0)[5]);}}

/* k9025 in loop in k8999 in k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1485 test */
t2=((C_word*)t0)[3];
f_8961(t2,((C_word*)t0)[2],t1);}

/* k9011 in loop in k8999 in k8989 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1488 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9003(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8961(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8961,NULL,3,t0,t1,t2);}
t3=(C_word)C_fudge(C_fix(24));
t4=(C_truep(t3)?(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[8],*((C_word*)lf[206]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[206]+1),lf[8])):(C_word)C_a_i_list(&a,1,lf[8]));
/* eval.scm: 1470 test2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8926(t5,t1,t2,t4);}

/* test2 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8926(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8926,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8939,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1464 exists? */
f_8901(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1465 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8940 in test2 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1466 exists? */
f_8901(t2,t1);}

/* k8946 in k8940 in test2 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1468 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8926(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8937 in test2 in ##sys#resolve-include-filename in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8901(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8901,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8905,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1459 ##sys#file-info */
t4=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8903 in exists? in k8893 in k8889 in k8886 in k8882 in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8868(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8868,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8870,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8870 in initb in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8870,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8874,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1420 ##sys#hash-table-location */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8872 */
static void C_ccall f_8874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8830(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8830r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8830r(t0,t1,t2,t3);}}

static void C_ccall f_8830r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[291]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1411 ##sys#error */
t8=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[291],lf[292],t2);}
else{
t8=t5;
f_8837(2,t8,C_SCHEME_UNDEFINED);}}

/* k8835 in null-environment in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1414 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8842 in k8835 in null-environment in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8844,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[281],t1,t3));}

/* scheme-report-environment in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8786r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8786r(t0,t1,t2,t3);}}

static void C_ccall f_8786r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,lf[288]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8806,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1402 ##sys#copy-env-table */
t9=*((C_word*)lf[284]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[279],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8819,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1403 ##sys#copy-env-table */
t9=*((C_word*)lf[284]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[280],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1404 ##sys#error */
t8=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[288],lf[289],t2);}}

/* k8817 in scheme-report-environment in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8819,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[281],t1,((C_word*)t0)[2]));}

/* k8804 in scheme-report-environment in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8806,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[281],t1,((C_word*)t0)[2]));}

/* interaction-environment in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8783,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[282]);}

/* ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8664r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8664r(t0,t1,t2,t3);}}

static void C_ccall f_8664r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_structure(t2,lf[281]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8685,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8685(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8756,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8758,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1389 ##sys#walk-namespace */
t12=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8757 in ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8758,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8768,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8768(2,t5,t3);}
else{
/* eval.scm: 1391 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8766 in a8757 in ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8768,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8754 in ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* doloop2533 in ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8685(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8685,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8703,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8709,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_8709(t10,t5,t6,t3);}}

/* loop in doloop2533 in ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8709(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8709,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8728,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_8728(2,t8,t6);}
else{
/* eval.scm: 1383 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k8726 in loop in doloop2533 in ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1384 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8709(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1385 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8709(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k8701 in doloop2533 in ##sys#environment-symbols in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_8685(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8556r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8556r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8556r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8566,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1350 ##sys#make-vector */
t10=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k8564 in ##sys#copy-env-table in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8566,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_8571(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop2493 in k8564 in ##sys#copy-env-table in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8571(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8571,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8592,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8598,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8598(t8,t3,t4);}}

/* copy in doloop2493 in k8564 in ##sys#copy-env-table in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8598,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8631,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1365 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1366 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k8629 in copy in doloop2493 in k8564 in ##sys#copy-env-table in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8631,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8590 in doloop2493 in k8564 in ##sys#copy-env-table in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8571(t4,((C_word*)t0)[2],t3);}

/* ##sys#environment? in k8531 in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8540,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[281]))){
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#string->c-identifier in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8477,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8481,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1328 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8479 in ##sys#string->c-identifier in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8481,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8489,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8489(t6,((C_word*)t0)[2],C_fix(0));}

/* doloop2444 in k8479 in ##sys#string->c-identifier in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8489,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8509,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_8509(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_8509(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k8507 in doloop2444 in k8479 in ##sys#string->c-identifier in k8473 in k8470 in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8489(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8433,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[277]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[274]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8451,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8465,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[274]+1));
t9=C_mutate((C_word*)lf[274]+1 /* (set! extension-specifiers ...) */,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a8464 in set-extension-specifier! in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8465,3,t0,t1,t2);}
/* eval.scm: 1284 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a8450 in set-extension-specifier! in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8451,3,t0,t1,t2);}
/* eval.scm: 1282 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7934,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7937,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7962,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8003,a[2]=t5,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8301,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_u_i_car(t2);
t10=t8;
f_8301(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_8301(t9,C_SCHEME_FALSE);}}

/* k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8301,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[274]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[7]);}
else{
/* eval.scm: 1270 ##sys#error */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],lf[275],((C_word*)t0)[7]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
/* eval.scm: 1272 doit */
t2=((C_word*)t0)[2];
f_8003(t2,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* eval.scm: 1273 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[276],((C_word*)t0)[7]);}}}

/* k8308 in k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8310,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[192],t2);
/* eval.scm: 1258 values */
C_values(4,0,((C_word*)t0)[5],t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8340,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1260 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1269 ##sys#do-the-right-thing */
t2=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k8338 in k8308 in k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8340,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8342,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8342(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k8338 in k8308 in k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8342,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8360,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8364,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1264 reverse */
t7=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8379,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a8378 in loop in k8338 in k8308 in k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8379,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1266 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8342(t7,t1,t4,t5,t6);}

/* a8368 in loop in k8338 in k8308 in k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* eval.scm: 1265 ##sys#do-the-right-thing */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8362 in loop in k8338 in k8308 in k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8358 in loop in k8338 in k8308 in k8299 in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8360,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[65],t1);
/* eval.scm: 1264 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8003(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8003,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[268]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8013(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_8013(2,t5,(C_word)C_u_i_memq(t2,lf[272]));}
else{
/* eval.scm: 1207 ##sys#feature? */
t5=*((C_word*)lf[273]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8020,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1208 impform */
t3=((C_word*)t0)[5];
f_7962(t3,t2,lf[269],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[3]+1)))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8033,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8037,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[270],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8037(t7,(C_word)C_a_i_cons(&a,2,lf[135],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[53],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8037(t7,(C_word)C_a_i_cons(&a,2,lf[230],t6));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[5]+1)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1218 ##sys#extension-information */
t3=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[271]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1230 ##sys#extension-information */
t3=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[271]);}}}}

/* k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8158,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[57],t1);
t3=(C_word)C_u_i_assq(lf[260],t1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8170,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
/* eval.scm: 1234 add-req */
t5=((C_word*)t0)[2];
f_7937(t5,t4,((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t5=t4;
f_8170(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1248 add-req */
t3=((C_word*)t0)[2];
f_7937(t3,t2,((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k8261 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8270,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[53],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[123],t5);
/* eval.scm: 1250 impform */
t7=((C_word*)t0)[2];
f_7962(t7,t2,t6,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k8268 in k8261 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1249 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8177,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8185,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8189,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[53],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[121],t7);
t9=t4;
f_8189(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_8189(t5,C_SCHEME_END_OF_LIST);}}

/* k8187 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8189,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8193,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t4)){
t5=t3;
f_8197(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8211,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8215,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8217,tmp=(C_word)a,a+=2,tmp);
t8=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t9=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* a8216 in k8187 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8217,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[53],t3));}

/* k8213 in k8187 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8209 in k8187 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8211,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[123],t1);
t3=((C_word*)t0)[2];
f_8197(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k8195 in k8187 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8191 in k8187 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8183 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8185,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[65],t1);
/* eval.scm: 1236 impform */
t3=((C_word*)t0)[4];
f_7962(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8175 in k8168 in k8156 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1235 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8074 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8076,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[53],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[121],t7);
t9=t4;
f_8094(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_8094(t5,C_SCHEME_END_OF_LIST);}}

/* k8092 in k8074 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8094,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8102,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[270],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8106(t7,(C_word)C_a_i_cons(&a,2,lf[135],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[53],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8106(t7,(C_word)C_a_i_cons(&a,2,lf[230],t6));}}

/* k8104 in k8092 in k8074 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1223 impform */
t2=((C_word*)t0)[4];
f_7962(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8100 in k8092 in k8074 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8102,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8088 in k8074 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8090,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[65],t1);
/* eval.scm: 1220 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8035 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_8037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1211 impform */
t2=((C_word*)t0)[4];
f_7962(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k8031 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1210 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8018 in k8011 in doit in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1208 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* impform in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7962,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7974,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7978,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7981,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(C_word)C_i_not(t4);
if(C_truep(t8)){
t9=t7;
f_7981(2,t9,t8);}
else{
/* eval.scm: 1200 ##sys#current-module */
t9=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}}
else{
t8=t7;
f_7981(2,t8,C_SCHEME_FALSE);}}

/* k7979 in impform in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7981,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[267],t2);
t4=((C_word*)t0)[2];
f_7978(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[2];
f_7978(t2,C_SCHEME_END_OF_LIST);}}

/* k7976 in impform in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7978(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7972 in impform in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7974,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[65],t2));}

/* add-req in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7937,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=(C_truep(t3)?lf[262]:lf[263]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7950,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7956,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1192 ##sys#hash-table-update! */
t7=*((C_word*)lf[18]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,*((C_word*)lf[266]+1),t4,t5,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* a7955 in add-req in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7949 in add-req in ##sys#do-the-right-thing in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7950,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[264]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[265]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7885,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7891,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7891(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7891,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7905,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1181 ##sys#extension-information */
t5=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7903 in loop1 in ##sys#lookup-runtime-requirements in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[260],t1);
t4=t2;
f_7908(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7908(t3,C_SCHEME_FALSE);}}

/* k7906 in k7903 in loop1 in ##sys#lookup-runtime-requirements in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7908,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7915,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1185 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7891(t5,t3,t4);}

/* k7913 in k7906 in k7903 in loop1 in ##sys#lookup-runtime-requirements in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1180 append */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7879,3,t0,t1,t2);}
/* eval.scm: 1171 ##sys#extension-information */
t3=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[259]);}

/* ##sys#extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7846,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7850,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1163 ##sys#repository-path */
t5=*((C_word*)lf[238]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7848 in ##sys#extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7850,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7856,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1164 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7854 in k7848 in ##sys#extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1165 string-append */
t3=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],lf[257],t1,lf[258]);}

/* k7857 in k7854 in k7848 in ##sys#extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7862,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7877,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1166 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[256]);}

/* k7875 in k7857 in k7854 in k7848 in ##sys#extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1166 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7860 in k7857 in k7854 in k7848 in ##sys#extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7862,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7869 in k7860 in k7857 in k7854 in k7848 in ##sys#extension-information in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7869,3,t0,t1,t2);}
/* with-input-from-file2119 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7833(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7833r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7833r(t0,t1,t2);}}

static void C_ccall f_7833r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7839,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7838 in ##sys#require in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7839,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[248]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[254]);}

/* ##sys#provided? in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7819,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7830,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1144 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[253]);}

/* k7828 in ##sys#provided? in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[246]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7799r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7799r(t0,t1,t2);}}

static void C_ccall f_7799r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7805,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7804 in ##sys#provide in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7805,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[251]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7812,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1137 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[251]);}

/* k7810 in a7804 in ##sys#provide in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7812,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[246]+1));
t3=C_mutate((C_word*)lf[246]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7731r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7731r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7735,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7794,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1118 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7735(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7792 in ##sys#load-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7735(t3,t2);}

/* k7733 in ##sys#load-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7735,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1120 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7736 in k7733 in ##sys#load-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[246]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[3]+1)))){
/* eval.scm: 1123 ##sys#load-library */
t3=*((C_word*)lf[223]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7756,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1125 ##sys#find-extension */
t4=*((C_word*)lf[241]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7754 in k7736 in k7733 in ##sys#load-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1127 ##sys#load */
t3=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1130 ##sys#error */
t5=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[249],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7760 in k7754 in k7736 in k7733 in ##sys#load-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[246]+1));
t3=C_mutate((C_word*)lf[246]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7637,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7641,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1096 ##sys#repository-path */
t5=*((C_word*)lf[238]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7689,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):lf[243]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7722,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1107 ##sys#append */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[244]+1),lf[245]);}
else{
t6=t5;
f_7722(2,t6,C_SCHEME_END_OF_LIST);}}

/* k7720 in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1105 ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7687 in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7689,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7691(t5,((C_word*)t0)[2],t1);}

/* loop in k7687 in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7691,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7704,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1110 check */
t5=((C_word*)t0)[2];
f_7643(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7702 in loop in k7687 in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1111 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7691(t3,((C_word*)t0)[4],t2);}}

/* check in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7643,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1098 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[242],((C_word*)t0)[2]);}

/* k7645 in check in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7653,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[173]+1);
if(C_truep(t3)){
t4=t2;
f_7653(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7682,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1102 ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,*((C_word*)lf[206]+1));}
else{
t4=t2;
f_7653(2,t4,C_SCHEME_FALSE);}}}
else{
t3=t2;
f_7653(2,t3,C_SCHEME_FALSE);}}

/* k7680 in k7645 in check in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1102 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7651 in k7645 in check in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7656(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7663,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1103 ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[8]);}}

/* k7661 in k7651 in k7645 in check in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1103 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7654 in k7651 in k7645 in check in k7639 in ##sys#find-extension in k7632 in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7474,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7477,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7483,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7496,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_7496(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1058 ##sys#symbol->string */
t7=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7579,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7579(t10,t6,t2);}
else{
t7=t6;
f_7496(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7579,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[235]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7596,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1065 ##sys#symbol->string */
t5=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_7596(2,t5,t3);}
else{
/* eval.scm: 1067 err */
t5=((C_word*)t0)[2];
f_7477(t5,t4);}}}}

/* k7594 in loop in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7596,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[236]:lf[237]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7604,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1071 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7579(t7,t5,t6);}

/* k7602 in k7594 in loop in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1063 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7494 in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7496,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7501,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7501(t5,((C_word*)t0)[2],t1);}

/* check in k7494 in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7501,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1074 err */
t5=((C_word*)t0)[4];
f_7477(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_7483(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7527,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1076 ##sys#substring */
t8=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_7483(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7540,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1078 ##sys#substring */
t12=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k7538 in check in k7494 in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1078 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7501(t2,((C_word*)t0)[2],t1);}

/* k7525 in check in k7494 in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1076 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7501(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static C_word C_fcall f_7483(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7477,NULL,2,t0,t1);}
/* eval.scm: 1055 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[233],((C_word*)t0)[2]);}

/* load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7389r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7389r(t0,t1,t2,t3);}}

static void C_ccall f_7389r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[230]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7396,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1034 ##sys#load-library */
t8=*((C_word*)lf[223]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k7394 in load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k7404 in k7394 in load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1035 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[230],lf[231],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7283,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7287,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1007 ##sys#->feature-id */
t5=*((C_word*)lf[229]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7287,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[138]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_7296(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7379,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1012 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[217]+1));}}}

/* k7377 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7383,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1013 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7381 in k7377 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7383,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7296(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7296,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7361,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7365,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1018 ##sys#string->c-identifier */
t6=*((C_word*)lf[228]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k7363 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1016 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[226],t1,lf[227]);}

/* k7359 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1015 ##sys#make-c-string */
t2=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7302,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7348,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1020 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7346 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7348,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1021 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[225]);}
else{
t2=((C_word*)t0)[3];
f_7302(2,t2,C_SCHEME_UNDEFINED);}}

/* k7349 in k7346 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1022 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7352 in k7349 in k7346 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1023 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[224]);}

/* k7300 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7302,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7307(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k7300 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7307,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7320,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1026 ##sys#make-c-string */
t6=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k7339 in loop in k7300 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1026 ##sys#dload */
t2=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7318 in loop in k7300 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7320,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7323,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[138]+1)))){
t3=t2;
f_7323(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[138]+1));
t4=C_mutate((C_word*)lf[138]+1 /* (set! features ...) */,t3);
t5=t2;
f_7323(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1029 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7307(t3,((C_word*)t0)[5],t2);}}

/* k7321 in k7318 in loop in k7300 in k7297 in k7294 in k7285 in ##sys#load-library in k7279 in k7272 in k7267 in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7243r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7243r(t0,t1,t2,t3);}}

static void C_ccall f_7243r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7247,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7264,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[213]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[216],t3,t5);}

/* a7263 in load-noisily in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7264,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7245 in load-noisily in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7250,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7261,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[213]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[215],((C_word*)t0)[2],t3);}

/* a7260 in k7245 in load-noisily in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7261,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7248 in k7245 in load-noisily in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7253,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7258,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[213]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[214],((C_word*)t0)[2],t3);}

/* a7257 in k7248 in k7245 in load-noisily in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7258,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7251 in k7248 in k7245 in load-noisily in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 978  ##sys#load */
t2=*((C_word*)lf[187]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7207r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7207r(t0,t1,t2,t3);}}

static void C_ccall f_7207r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7215,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_7215(2,t6,t2);}
else{
/* eval.scm: 974  ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[171]+1),t2);}}

/* k7213 in load-relative in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 971  ##sys#load */
t5=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7185r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7185r(t0,t1,t2,t3);}}

static void C_ccall f_7185r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 968  ##sys#load */
t6=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr5r,(void*)f_6792r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6792r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6792r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(23);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7135,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7140,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer15621747 */
t10=t9;
f_7140(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer15631743 */
t12=t8;
f_7135(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body15601569 */
t14=t7;
f_6794(t14,t1,t10,t12);}}}

/* def-timer1562 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7140,NULL,2,t0,t1);}
/* def-printer15631743 */
t2=((C_word*)t0)[2];
f_7135(t2,t1,C_SCHEME_FALSE);}

/* def-printer1563 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7135,NULL,3,t0,t1,t2);}
/* body15601569 */
t3=((C_word*)t0)[2];
f_6794(t3,t1,t2,C_SCHEME_FALSE);}

/* body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_6794(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6794,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7134,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 901  ##sys#expand-home-path */
t6=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_6798(t5,C_SCHEME_UNDEFINED);}}

/* k7132 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6798(t3,t2);}

/* k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_6798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6798,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7056,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 904  port? */
t6=*((C_word*)lf[209]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}

/* k7054 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7056,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6801(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 906  ##sys#file-info */
t3=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 897  ##sys#signal-hook */
t3=*((C_word*)lf[180]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[207],lf[192],lf[208],t2);}}}

/* k7069 in k7054 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_7074(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_7074(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7074(t3,C_SCHEME_FALSE);}}

/* k7072 in k7069 in k7054 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_7074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7074,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6801(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 912  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[206]+1));}}

/* k7075 in k7072 in k7069 in k7054 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[173]+1);
if(C_truep(t3)){
t4=t2;
f_7083(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
/* eval.scm: 915  ##sys#file-info */
t4=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t1);}
else{
t4=t2;
f_7083(2,t4,C_SCHEME_FALSE);}}}

/* k7081 in k7075 in k7072 in k7069 in k7054 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7083,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6801(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 917  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[8]);}}

/* k7084 in k7081 in k7075 in k7072 in k7069 in k7054 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 918  ##sys#file-info */
t3=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7090 in k7084 in k7081 in k7075 in k7072 in k7069 in k7054 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6801(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6801(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=((C_word*)t0)[17];
t3=(C_truep(t2)?t2:((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 923  ##sys#signal-hook */
t7=*((C_word*)lf[180]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[201],lf[192],lf[202],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7047,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 924  load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k7045 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7047,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7038,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 925  display */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[204]);}
else{
t3=((C_word*)t0)[2];
f_6807(2,t3,C_SCHEME_UNDEFINED);}}

/* k7036 in k7045 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 926  display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7039 in k7036 in k7045 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 927  display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[203]);}

/* k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 929  ##sys#make-c-string */
t5=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6810(2,t3,C_SCHEME_FALSE);}}

/* k7021 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 929  ##sys#dload */
t2=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6993 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6995,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6810(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 930  has-sep? */
f_6746(t2,((C_word*)t0)[3]);}}

/* k7017 in k6993 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6810(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7015,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 931  ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[200],((C_word*)t0)[2]);}}

/* k7013 in k7017 in k6993 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 931  ##sys#make-c-string */
t2=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7009 in k7017 in k6993 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 931  ##sys#dload */
t2=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6813,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6813(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 932  call-with-current-continuation */
t4=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6818,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6822,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6982,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 938  has-sep? */
f_6746(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6822(2,t8,C_SCHEME_FALSE);}}

/* k6980 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 939  ##sys#substring */
t3=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6822(2,t2,lf[196]);}}

/* k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6822,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6823,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6832,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6970,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6969 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6970,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[188]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[170]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[171]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[169]+1));
t6=C_mutate((C_word*)lf[188]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[170]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[171]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[169]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6847,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 941  open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6847(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6852,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6961,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 942  ##sys#dynamic-wind */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6960 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
/* eval.scm: 964  close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6859,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 945  peek-char */
t3=*((C_word*)lf[194]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6862(2,t4,C_SCHEME_UNDEFINED);}}

/* k6953 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 947  ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[192],lf[193],((C_word*)t0)[2],t1);}

/* k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 948  read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6870(t5,((C_word*)t0)[2],t1);}

/* doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_6870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6870,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 951  printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6880(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6892,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 952  ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6925 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6926r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6926r(t0,t1,t2);}}

static void C_ccall f_6926r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6934 in a6925 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6935,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6939,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 961  write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6937 in a6934 in a6925 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 962  newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6891 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6899,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[191]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 956  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6897 in a6891 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6910,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6909 in k6897 in a6891 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6910r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6910r(t0,t1,t2);}}

static void C_ccall f_6910r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6914,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6921,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[190]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6919 in a6909 in k6897 in a6891 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=*((C_word*)lf[189]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6912 in a6909 in k6897 in a6891 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6903 in k6897 in a6891 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6904,2,t0,t1);}
/* eval.scm: 955  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6881 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6890,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 949  read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6888 in k6881 in k6878 in doloop1696 in k6863 in k6860 in k6857 in a6854 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6870(t2,((C_word*)t0)[2],t1);}

/* a6851 in k6845 in a6842 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6831 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6832,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[188]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[170]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[171]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[169]+1));
t6=C_mutate((C_word*)lf[188]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[170]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[171]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[169]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* f_6823 in k6820 in a6817 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6823,2,t0,t1);}
/* eval.scm: 940  abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6811 in k6808 in k6805 in k6799 in k6796 in body1560 in ##sys#load in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_6746(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6746,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6756,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6756(t5,t4));}

/* loop in has-sep? in k6742 in k6661 in k6566 in k3361 in k3358 in k3325 */
static C_word C_fcall f_6756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6671,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6678,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6683,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6683(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_6683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6683,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6696,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[176]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6696(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[177]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6696(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[178]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6696(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[179]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6696(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 876  ##sys#signal-hook */
t10=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[174],lf[181],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6694 in loop in set-dynamic-load-mode! in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 877  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6683(t3,((C_word*)t0)[2],t2);}

/* k6676 in set-dynamic-load-mode! in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 878  ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6665 in k6661 in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6581,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6584,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6594,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6594(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_6594(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6594,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6608,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 845  reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6627,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 847  reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 849  loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 848  err */
t6=((C_word*)t0)[2];
f_6584(t6,t1);}}}
else{
/* eval.scm: 846  err */
t6=((C_word*)t0)[2];
f_6584(t6,t1);}}}

/* k6625 in loop in ##sys#decompose-lambda-list in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 847  k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6606 in loop in ##sys#decompose-lambda-list in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 845  k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k6566 in k3361 in k3358 in k3325 */
static void C_fcall f_6584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6584,NULL,2,t0,t1);}
t2=C_set_block_item(lf[166] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
/* eval.scm: 842  ##sys#syntax-error-hook */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[167],((C_word*)t0)[2]);}

/* eval in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6571r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6571r(t0,t1,t2,t3);}}

static void C_ccall f_6571r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6579,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 830  ##sys#eval-handler */
t5=*((C_word*)lf[163]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6577 in eval in k6566 in k3361 in k3358 in k3325 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+38)){
C_save_and_reclaim((void*)tr5rv,(void*)f_3703r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_3703r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3703r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a=C_alloc(38);
t6=(C_word)C_vemptyp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:(C_word)C_slot(t5,C_fix(0)));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3709,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3748,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3847,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3853,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3859,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3865,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3916,a[2]=t20,a[3]=((C_word*)t0)[2],a[4]=t16,a[5]=t15,a[6]=t11,a[7]=t18,a[8]=t14,a[9]=((C_word*)t0)[3],a[10]=t12,tmp=(C_word)a,a+=11,tmp));
t22=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6320,a[2]=t18,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t23=(C_word)C_fixnum_greaterp(*((C_word*)lf[32]+1),C_fix(0));
/* eval.scm: 809  compile */
t24=((C_word*)t18)[1];
f_3916(t24,t1,t2,t3,C_SCHEME_FALSE,t23,t7,t4);}

/* compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_6320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6320,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6324,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[3],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 773  compile */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3916(t9,t7,t8,t3,C_SCHEME_FALSE,t4,t5,t6);}

/* k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6294,tmp=(C_word)a,a+=2,tmp);
t4=f_6294(t2,C_fix(0));
t5=((C_word*)t0)[9];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 778  ##sys#syntax-error-hook */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],lf[162],((C_word*)t0)[9]);
case C_fix(0):
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6346,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6365,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 782  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3916(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 786  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3916(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 791  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3916(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 797  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3916(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6513,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 804  ##sys#map */
t8=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a6536 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6537,3,t0,t1,t2);}
/* eval.scm: 804  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3916(t3,t1,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6511 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6513,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6514 in k6511 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6514,3,t0,t1,t2);}
t3=f_3847(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6523 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6529,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 807  ##sys#map */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6530 in k6523 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6531,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k6527 in k6523 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6468 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 798  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3916(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6471 in k6468 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 799  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3916(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6474 in k6471 in k6468 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 800  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3916(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(3)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[11],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k6477 in k6474 in k6471 in k6468 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_6480 in k6477 in k6474 in k6471 in k6468 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6480,3,t0,t1,t2);}
t3=f_3847(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6489 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6493 in k6489 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6497 in k6493 in k6489 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6501 in k6497 in k6493 in k6489 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6506,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6504 in k6501 in k6497 in k6493 in k6489 */
static void C_ccall f_6506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6426 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 792  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3916(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6429 in k6426 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 793  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3916(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6432 in k6429 in k6426 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6434,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_6435 in k6432 in k6429 in k6426 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6435,3,t0,t1,t2);}
t3=f_3847(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6444 */
static void C_ccall f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6448 in k6444 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6452 in k6448 in k6444 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6457,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6455 in k6452 in k6448 in k6444 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6391 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6396,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 787  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3916(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6394 in k6391 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_6397 in k6394 in k6391 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6397,3,t0,t1,t2);}
t3=f_3847(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6406 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6410 in k6406 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6415,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6413 in k6410 in k6406 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6363 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6366,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6366 in k6363 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6366,3,t0,t1,t2);}
t3=f_3847(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6377,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6375 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6380,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6378 in k6375 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_6346 in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6346,3,t0,t1,t2);}
t3=f_3847(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6356,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 781  fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6354 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k6322 in compile-call in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static C_word C_fcall f_6294(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3916(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3916,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=((C_word*)t0)[8],a[11]=t6,a[12]=((C_word*)t0)[9],a[13]=t7,a[14]=t3,a[15]=((C_word*)t0)[10],a[16]=t2,a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* eval.scm: 289  keyword? */
t9=*((C_word*)lf[161]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[17];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[16]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[17],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 315  ##sys#number? */
t3=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[16]);}}}

/* k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4050,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4058,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4066,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4074,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4087,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4089,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4099(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4099(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_4099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4100,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_3853(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 333  ##sys#expand */
t5=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[15],((C_word*)t0)[11]);}
else{
t3=f_3853(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 750  compile-call */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6320(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[9],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}}
else{
/* eval.scm: 330  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[159],((C_word*)t0)[15]);}}}

/* k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=*((C_word*)lf[39]+1);
t3=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
/* eval.scm: 337  rename */
t6=((C_word*)t0)[7];
f_3748(t6,t4,t5,((C_word*)t0)[13]);}
else{
/* eval.scm: 336  compile */
t4=((C_word*)((C_word*)t0)[12])[1];
f_3916(t4,((C_word*)t0)[14],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}}

/* k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4137,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[53]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4146,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 343  ##sys#check-syntax */
t4=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,lf[53],((C_word*)t0)[14],lf[56],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(t1,lf[57]);
if(C_truep(t3)){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t5=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4221,a[2]=t4,tmp=(C_word)a,a+=3,tmp));}
else{
t4=(C_word)C_eqp(t1,lf[58]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
if(C_truep(*((C_word*)lf[23]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 362  ##sys#hash-table-location */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[23]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4243,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}}
else{
t5=(C_word)C_eqp(t1,lf[59]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 367  compile */
t7=((C_word*)((C_word*)t0)[12])[1];
f_3916(t7,((C_word*)t0)[15],t6,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t6=(C_word)C_eqp(t1,lf[60]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 370  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_3916(t8,((C_word*)t0)[15],t7,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t7=(C_word)C_eqp(t1,lf[61]);
if(C_truep(t7)){
t8=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4277,tmp=(C_word)a,a+=2,tmp));}
else{
t8=(C_word)C_eqp(t1,lf[62]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4287,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 375  ##sys#check-syntax */
t10=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[62],((C_word*)t0)[14],lf[64],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t9=(C_word)C_eqp(t1,lf[65]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 384  ##sys#check-syntax */
t11=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t10,lf[65],((C_word*)t0)[14],lf[68],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t10=(C_word)C_eqp(t1,lf[69]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t1,lf[70]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4460,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 400  ##sys#check-syntax */
t13=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t13+1)))(7,t13,t12,lf[69],((C_word*)t0)[14],lf[73],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t12=(C_word)C_eqp(t1,lf[74]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t1,lf[75]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 424  ##sys#check-syntax */
t15=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t15+1)))(7,t15,t14,lf[74],((C_word*)t0)[14],lf[83],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t14=(C_word)C_eqp(t1,lf[84]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t1,lf[85]));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 476  ##sys#check-syntax */
t17=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t16,lf[84],((C_word*)t0)[14],lf[87]);}
else{
t16=(C_word)C_eqp(t1,lf[88]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t1,lf[89]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 491  ##sys#check-syntax */
t19=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t19+1)))(7,t19,t18,lf[88],((C_word*)t0)[14],lf[97],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t18=(C_word)C_eqp(t1,lf[98]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 586  ##sys#check-syntax */
t20=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t20+1)))(7,t20,t19,lf[98],((C_word*)t0)[14],lf[100],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t19=(C_word)C_eqp(t1,lf[101]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5423,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 601  ##sys#check-syntax */
t21=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t21+1)))(7,t21,t20,lf[101],((C_word*)t0)[14],lf[102],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t20=(C_word)C_eqp(t1,lf[103]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t1,lf[104]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5491,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t26=t23;
f_5578(t26,(C_word)C_i_pairp(t25));}
else{
t25=t23;
f_5578(t25,C_SCHEME_FALSE);}}
else{
t22=(C_word)C_eqp(t1,lf[112]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
t24=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 640  rename */
t25=((C_word*)t0)[7];
f_3748(t25,t23,t24,((C_word*)t0)[13]);}
else{
t23=(C_word)C_eqp(t1,lf[119]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 685  rename */
t25=((C_word*)t0)[7];
f_3748(t25,t24,lf[88],((C_word*)t0)[13]);}
else{
t24=(C_word)C_eqp(t1,lf[120]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5853,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 688  rename */
t26=((C_word*)t0)[7];
f_3748(t26,t25,lf[88],((C_word*)t0)[13]);}
else{
t25=(C_word)C_eqp(t1,lf[121]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5870,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5909,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t28=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
/* map */
t29=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t29+1)))(4,t29,t26,t27,t28);}
else{
t26=(C_word)C_eqp(t1,lf[125]);
if(C_truep(t26)){
t27=(C_word)C_u_i_caddr(((C_word*)t0)[14]);
t28=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t29=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t31,a[5]=t27,tmp=(C_word)a,a+=6,tmp));
t33=((C_word*)t31)[1];
f_5939(t33,t28,t29);}
else{
t27=(C_word)C_eqp(t1,lf[128]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(t1,lf[129]));
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5997,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t30=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 714  eval/meta */
f_3865(t29,t30);}
else{
t29=(C_word)C_eqp(t1,lf[131]);
if(C_truep(t29)){
t30=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 718  compile */
t31=((C_word*)((C_word*)t0)[12])[1];
f_3916(t31,((C_word*)t0)[15],t30,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t30=(C_word)C_eqp(t1,lf[132]);
t31=(C_truep(t30)?t30:(C_word)C_eqp(t1,lf[133]));
if(C_truep(t31)){
/* eval.scm: 721  compile */
t32=((C_word*)((C_word*)t0)[12])[1];
f_3916(t32,((C_word*)t0)[15],lf[134],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t32=(C_word)C_eqp(t1,lf[135]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6038,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_u_i_memq(lf[137],*((C_word*)lf[138]+1)))){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
/* for-each */
t36=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t36+1)))(4,t36,t33,t34,t35);}
else{
/* eval.scm: 726  ##sys#warn */
t34=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t33,lf[141],((C_word*)t0)[14]);}}
else{
t33=(C_word)C_eqp(t1,lf[142]);
t34=(C_truep(t33)?t33:(C_word)C_eqp(t1,lf[143]));
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6080,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 730  rename */
t36=((C_word*)t0)[7];
f_3748(t36,t35,lf[144],((C_word*)t0)[13]);}
else{
t35=(C_word)C_eqp(t1,lf[51]);
t36=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6097,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t35)){
t37=t36;
f_6097(t37,t35);}
else{
t37=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t37)){
t38=t36;
f_6097(t38,t37);}
else{
t38=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t38)){
t39=t36;
f_6097(t39,t38);}
else{
t39=(C_word)C_eqp(t1,lf[151]);
if(C_truep(t39)){
t40=t36;
f_6097(t40,t39);}
else{
t40=(C_word)C_eqp(t1,lf[152]);
if(C_truep(t40)){
t41=t36;
f_6097(t41,t40);}
else{
t41=(C_word)C_eqp(t1,lf[153]);
if(C_truep(t41)){
t42=t36;
f_6097(t42,t41);}
else{
t42=(C_word)C_eqp(t1,lf[154]);
if(C_truep(t42)){
t43=t36;
f_6097(t43,t42);}
else{
t43=(C_word)C_eqp(t1,lf[155]);
if(C_truep(t43)){
t44=t36;
f_6097(t44,t43);}
else{
t44=(C_word)C_eqp(t1,lf[156]);
t45=t36;
f_6097(t45,(C_truep(t44)?t44:(C_word)C_eqp(t1,lf[157])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k6095 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_6097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 737  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[145],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[146]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* eval.scm: 740  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6320(t4,((C_word*)t0)[9],t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[147]);
if(C_truep(t3)){
/* eval.scm: 744  ##sys#syntax-error-hook */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],lf[148],((C_word*)t0)[8]);}
else{
/* eval.scm: 746  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6320(t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k6078 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6082 in k6078 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6084,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 730  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3916(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6048 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6049,3,t0,t1,t2);}
/* eval.scm: 725  ##compiler#process-declaration */
t3=*((C_word*)lf[139]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k6036 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 727  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3916(t2,((C_word*)t0)[6],lf[136],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5995 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 715  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3916(t2,((C_word*)t0)[6],lf[130],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_5939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5939,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[126]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5951,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5960 in loop in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5961,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5969,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 710  rename */
t5=((C_word*)t0)[3];
f_3748(t5,t4,lf[65],((C_word*)t0)[2]);}

/* k5967 in a5960 in loop in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5981,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 710  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5939(t4,t2,t3);}

/* k5979 in k5967 in a5960 in loop in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5981,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a5950 in loop in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5951,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 709  ##sys#do-the-right-thing */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5931 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 704  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3916(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5908 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5909,3,t0,t1,t2);}
/* eval.scm: 692  eval/meta */
f_3865(t1,t2);}

/* k5868 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5873,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[123]+1),t1);}

/* k5871 in k5868 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 695  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5874 in k5871 in k5868 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5883(t3,lf[122]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5893,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5897,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5899,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}}

/* a5898 in k5874 in k5871 in k5868 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5899,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[53],t3));}

/* k5895 in k5874 in k5871 in k5868 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5891 in k5874 in k5871 in k5868 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5893,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5883(t2,(C_word)C_a_i_cons(&a,2,lf[123],t1));}

/* k5881 in k5874 in k5871 in k5868 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_5883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 696  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3916(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5851 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5855 in k5851 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* eval.scm: 688  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3916(t4,((C_word*)t0)[6],t2,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5822 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5826 in k5822 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 685  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3916(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5601,2,t0,t1);}
t2=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5607,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_5607(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5743,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5795,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 655  ##sys#strip-syntax */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5793 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5742 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5743,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5767,tmp=(C_word)a,a+=2,tmp);
t5=t3;
f_5756(t5,f_5767(t2));}
else{
t4=t3;
f_5756(t4,C_SCHEME_FALSE);}}}

/* loop in a5742 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static C_word C_fcall f_5767(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k5754 in a5742 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_5756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* eval.scm: 652  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[116],lf[118],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5610,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5735,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 656  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5733 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 657  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[116],lf[117],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5610(2,t2,C_SCHEME_UNDEFINED);}}

/* k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5610,2,t0,t1);}
t2=*((C_word*)lf[41]+1);
t3=*((C_word*)lf[107]+1);
t4=*((C_word*)lf[42]+1);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 659  ##sys#register-module */
t6=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5613,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[113]+1);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5614,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t8,t9,t8);}

/* a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5651(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_5651(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5651,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5661,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 664  reverse */
t5=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5724,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 681  ##sys#current-environment */
t8=*((C_word*)lf[107]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5730 in loop in a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 678  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3916(t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5722 in loop in a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 676  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5651(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5659 in loop in a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5664,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5709,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 665  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5707 in k5659 in loop in a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 665  ##sys#finalize-module */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5662 in k5659 in loop in a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5664,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_5665 in k5662 in k5659 in loop in a5640 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5665,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5671,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5671(t6,t1,((C_word*)t0)[2]);}

/* loop2 */
static void C_fcall f_5671(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5671,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[39]+1));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5693,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[2]);}}}

/* k5691 in loop2 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 673  loop2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5671(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap1085 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* g108810891100 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5616 in swap1085 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g108810891100 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k5619 in k5616 in swap1085 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5621,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g109010911101 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5623 in k5619 in k5616 in swap1085 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g109010911101 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k5626 in k5623 in k5619 in k5616 in swap1085 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g109210931102 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5630 in k5626 in k5623 in k5619 in k5616 in swap1085 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5635,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g109210931102 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k5633 in k5630 in k5626 in k5623 in k5619 in k5616 in swap1085 in k5611 in k5608 in k5605 in k5599 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5576 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_5578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[110]:lf[111]);
/* eval.scm: 619  ##sys#check-syntax */
t3=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,((C_word*)t0)[4],lf[103],((C_word*)t0)[3],t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
/* eval.scm: 625  caadr */
t4=*((C_word*)lf[109]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}
else{
t4=t2;
f_5494(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[2]));}}

/* k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5497,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5535,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 627  rename */
t5=((C_word*)t0)[3];
f_3748(t5,t4,lf[88],((C_word*)t0)[5]);}
else{
t4=t2;
f_5497(t4,(C_word)C_u_i_caddr(((C_word*)t0)[2]));}}

/* k5533 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(C_word)C_u_i_cdadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5547,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k5545 in k5533 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5547,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_5497(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_5497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5497,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5500,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 629  rename */
t3=((C_word*)t0)[3];
f_3748(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k5498 in k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 631  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5523 in k5498 in k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 630  ##sys#register-syntax-export */
t2=*((C_word*)lf[108]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5501 in k5498 in k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 635  ##sys#current-environment */
t4=*((C_word*)lf[107]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5511 in k5501 in k5498 in k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5517,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 636  eval/meta */
f_3865(t3,((C_word*)t0)[2]);}

/* k5519 in k5511 in k5501 in k5498 in k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 636  ##sys#er-transformer */
t2=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5515 in k5511 in k5501 in k5498 in k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 633  ##sys#extend-macro-environment */
t2=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 637  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3916(t2,((C_word*)t0)[6],lf[105],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5454 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5455,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5467,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5471,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 607  eval/meta */
f_3865(t5,t6);}

/* k5469 in a5454 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 606  ##sys#er-transformer */
t2=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5465 in a5454 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k5424 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5429,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 609  append */
t3=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5427 in k5424 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5444 in k5427 in k5424 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5445,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t3,C_fix(0),((C_word*)t0)[2]));}

/* k5430 in k5427 in k5424 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 615  ##sys#canonicalize-body */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* k5437 in k5430 in k5427 in k5424 in k5421 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 614  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3916(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5368 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t6=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5389 in k5368 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5390,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5406,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 593  eval/meta */
f_3865(t5,t6);}

/* k5404 in a5389 in k5368 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 592  ##sys#er-transformer */
t2=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5400 in a5389 in k5368 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5402,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5386 in k5368 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 587  append */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5371 in k5368 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5380,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 597  ##sys#canonicalize-body */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* k5378 in k5371 in k5368 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 596  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3916(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[7];
t9=(C_truep(t8)?t8:lf[90]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5018,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=t10,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5343,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 495  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5341 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5343,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5018(2,t2,C_SCHEME_UNDEFINED);}}

/* a5353 in k5341 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5354,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5347 in k5341 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
/* eval.scm: 498  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[95]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[48]+1),((C_word*)t0)[2]);}

/* k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5023,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 500  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5023,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5027,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=t1,a[11]=t3,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* map */
t6=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[82]+1),t2);}

/* k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 504  map */
t4=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1);}

/* k5338 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 504  append */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5332,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 508  ##sys#canonicalize-body */
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],t1);}

/* k5330 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 507  ##sys#compile-to-closure */
t4=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5036,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5294 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5294,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5300,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 577  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5299 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5300r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5300r(t0,t1,t2);}}

static void C_ccall f_5300r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5324,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[91]+1),t2);}
else{
/* eval.scm: 581  ##sys#error */
t5=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[93],((C_word*)t0)[4],t3);}}

/* k5322 in a5299 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5271 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5271,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 570  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5276 */
static void C_ccall f_5277(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_5277r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5277r(t0,t1,t2);}}

static void C_ccall f_5277r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5289,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5293,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5293(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6248,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6248(t9,t4,t5,C_fix(0),t2,C_SCHEME_FALSE);}}

/* doloop1294 in a5276 */
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,1,t4);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6277,a[2]=t4,a[3]=t8,a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t10)){
/* eval.scm: 759  ##sys#error */
t11=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[92],t2,t3);}
else{
t11=t9;
f_6277(2,t11,(C_word)C_slot(t4,C_fix(1)));}}}

/* k6275 in doloop1294 in a5276 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_6248(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5291 in a5276 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[91]+1),t1);}

/* k5287 in a5276 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5289,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5249 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5249,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 563  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5254 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5255,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5267,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 565  ##sys#vector */
t7=*((C_word*)lf[91]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5265 in a5254 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5230 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5230,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 558  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5235 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5236r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5236r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5236r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5202 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5202,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 552  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5207 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5208,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5183 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5183,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 547  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5188 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5189r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5189r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5155 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5155,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 541  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5160 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5161,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5136 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5136,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5142,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 536  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5141 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5142r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5142r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5108 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5108,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 530  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5113 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5114,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_5089 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5089,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 525  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5094 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5095r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5095r(t0,t1,t2,t3);}}

static void C_ccall f_5095r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5065 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5065,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5071,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 520  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5070 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5071,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_5046 in k5034 in k5028 in k5025 in a5022 in k5016 in k5004 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5052,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 515  decorate */
f_3859(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5051 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5052r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5052r(t0,t1,t2);}}

static void C_ccall f_5052r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4915 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4917,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4938,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4986,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 481  ##sys#map */
t6=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4985 in k4915 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4986,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[86]));}

/* k4936 in k4915 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4964,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 484  ##sys#map */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4963 in k4936 in k4915 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4964,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[70],t6));}

/* k4944 in k4936 in k4915 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4962,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4960 in k4944 in k4936 in k4915 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[75],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4940 in k4936 in k4915 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[75],t2);
/* eval.scm: 479  compile */
t4=((C_word*)((C_word*)t0)[8])[1];
f_3916(t4,((C_word*)t0)[7],t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4901,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4900 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4901,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[82]+1),t1);}

/* k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 430  map */
t5=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[81]+1),((C_word*)t0)[7],t1);}

/* k4897 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 430  append */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 432  ##sys#canonicalize-body */
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* k4889 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 431  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 437  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 440  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 444  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 452  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4828,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* map */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4874 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4875,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 466  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4826 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4829,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4829 in k4826 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4829,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 468  ##sys#make-vector */
t4=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4831 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4845(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop844 in k4831 */
static void C_fcall f_4845(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4845,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4870,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4868 in doloop844 in k4831 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4845(t5,((C_word*)t0)[2],t3,t4);}

/* k4834 in k4831 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4750 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 453  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4753 in k4750 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 455  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3916(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4759 in k4753 in k4750 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4764,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 456  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4762 in k4759 in k4753 in k4750 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4765 in k4762 in k4759 in k4753 in k4750 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4765,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4779 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4783 in k4779 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4787 in k4783 in k4779 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4791 in k4787 in k4783 in k4779 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4683 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 445  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4686 in k4683 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4688,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 447  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3916(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4692 in k4686 in k4683 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4695 in k4692 in k4686 in k4683 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4695,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4709 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4713 in k4709 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4717 in k4713 in k4709 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4719,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4634 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4639,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 441  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4637 in k4634 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4639,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4640 in k4637 in k4634 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4640,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4654 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4658 in k4654 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4660,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4600 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4603,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4603 in k4600 in k4591 in k4588 in k4582 in k4579 in k4570 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4619,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4617 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4619,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4474,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4478,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
/* eval.scm: 403  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3916(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4478,2,t0,t1);}
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4548,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4487,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 405  ##sys#alias-global-hook */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_TRUE);}}

/* k4485 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
if(C_truep(*((C_word*)lf[23]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4493,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 407  ##sys#hash-table-location */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[23]+1),t1,*((C_word*)lf[24]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4520 in k4485 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4520,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4526 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4491 in k4485 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4496(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 411  ##sys#error */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[72],((C_word*)t0)[2]);}}

/* k4494 in k4491 in k4485 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4496,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4512 in k4494 in k4491 in k4485 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
/* eval.scm: 414  ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[71],((C_word*)t0)[2]);}

/* f_4503 in k4494 in k4491 in k4485 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4503,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4509 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4548 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4548,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4554 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4535 in k4476 in a4473 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4535,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4545 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4467 in k4458 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
/* eval.scm: 402  lookup */
t2=((C_word*)t0)[5];
f_3763(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 388  compile */
t4=((C_word*)((C_word*)t0)[8])[1];
f_3916(t4,((C_word*)t0)[7],lf[66],((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 389  compile */
t5=((C_word*)((C_word*)t0)[8])[1];
f_3916(t5,((C_word*)t0)[7],t4,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 390  compile */
t6=((C_word*)((C_word*)t0)[8])[1];
f_3916(t6,t4,t5,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
default:
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 394  compile */
t6=((C_word*)((C_word*)t0)[8])[1];
f_3916(t6,t4,t5,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k4401 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* eval.scm: 395  compile */
t4=((C_word*)((C_word*)t0)[8])[1];
f_3916(t4,t2,t3,((C_word*)t0)[7],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k4404 in k4401 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 396  rename */
t4=((C_word*)t0)[2];
f_3748(t4,t3,lf[65],((C_word*)t0)[4]);}

/* k4426 in k4404 in k4401 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
/* ##sys#append */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,C_SCHEME_END_OF_LIST);}

/* k4430 in k4426 in k4404 in k4401 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 396  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3916(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4407 in k4404 in k4401 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4410 in k4407 in k4404 in k4401 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4410,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4412 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4417,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4415 in k4412 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4379 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4384,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 391  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3916(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4382 in k4379 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4385 in k4382 in k4379 in k4342 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4385,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4389,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4387 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4285 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 376  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3916(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4288 in k4285 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 377  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3916(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4291 in k4288 in k4285 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 379  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3916(t5,t2,t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 380  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3916(t4,t2,lf[63],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4294 in k4291 in k4288 in k4285 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4297,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4297 in k4294 in k4291 in k4288 in k4285 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4302 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4277 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4277,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4243 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4235 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4238,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4238 in k4235 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* f_4221 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 344  ##sys#strip-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
switch(t1){
case C_fix(-1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4156,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4164,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4172,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4180,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4188,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4196,tmp=(C_word)a,a+=2,tmp));
default:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4204,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4206,a[2]=t1,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4206 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4204 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4196 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4188 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4180 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4172 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4164 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4156 in k4147 in k4144 in k4135 in k4120 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4100 in k4097 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4100,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4089 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4087 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4076 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4074 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4066 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4058 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4050 in k4041 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3942,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4033,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_u_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4010,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 295  ##sys#get */
t7=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[51]);}
else{
/* eval.scm: 294  ##sys#alias-global-hook */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_FALSE);}}}

/* k4008 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3952(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
if(C_truep(*((C_word*)lf[23]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3958,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 297  ##sys#hash-table-location */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[23]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3981,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3986,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[31]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4001,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 310  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_3986(t4,C_SCHEME_FALSE);}}}

/* k3999 in k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3986(t2,(C_word)C_i_not(t1));}

/* k3984 in k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3986,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[31]+1));
t4=C_mutate((C_word*)lf[31]+1 /* (set! unbound-in-eval ...) */,t3);
t5=((C_word*)t0)[2];
f_3981(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_3981(t2,C_SCHEME_UNDEFINED);}}

/* k3979 in k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3981,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_3982 in k3979 in k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3956 in k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3961(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 298  ##sys#syntax-error-hook */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[49],((C_word*)t0)[2]);}}

/* k3959 in k3956 in k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_3962 in k3959 in k3956 in k3950 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 305  ##sys#error */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[47],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4033 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4033,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4024 in a3941 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4024,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3935 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
/* eval.scm: 291  lookup */
t2=((C_word*)t0)[5];
f_3763(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3924 in k3921 in compile in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3865(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3865,NULL,2,t1,t2);}
t3=*((C_word*)lf[41]+1);
t4=*((C_word*)lf[42]+1);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3869,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 274  ##sys#meta-macro-environment */
t8=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3869,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3890,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t6=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[2],t4,t5,t4);}

/* a3889 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3897,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 278  ##sys#current-meta-environment */
t4=*((C_word*)lf[43]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3899 in a3889 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 275  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k3895 in a3889 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* swap494 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* g497498506 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3872 in swap494 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g497498506 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k3875 in k3872 in swap494 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g499500507 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3879 in k3875 in k3872 in swap494 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g499500507 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3882 in k3879 in k3875 in k3872 in swap494 in k3867 in eval/meta in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* decorate in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3859(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3859,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 270  ##sys#eval-decorator */
t6=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static C_word C_fcall f_3853(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[40]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static C_word C_fcall f_3847(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[40]+1)):C_SCHEME_UNDEFINED));}

/* lookup in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3763,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3767,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 248  rename */
t6=((C_word*)t0)[2];
f_3748(t6,t5,t2,t4);}

/* k3765 in lookup in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=*((C_word*)lf[39]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3775,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3775(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* loop in k3765 in lookup in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3775(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3775,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 251  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3817,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3817(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 252  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 253  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in k3765 in lookup in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static C_word C_fcall f_3817(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* rename in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3748(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3748,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3752,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 243  find-id */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3709(t5,t4,t2,t3);}

/* k3750 in rename in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3752,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  ##sys#get */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[38]);}}

/* k3756 in k3750 in rename in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* find-id in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3709,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3722,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caar(t3);
t6=(C_word)C_eqp(t2,t5);
if(C_truep(t6)){
t7=(C_word)C_u_i_cdar(t3);
t8=t4;
f_3722(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t4;
f_3722(t7,C_SCHEME_FALSE);}}}

/* k3720 in find-id in ##sys#compile-to-closure in k3361 in k3358 in k3325 */
static void C_fcall f_3722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_cdar(((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 240  find-id */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3709(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* ##sys#eval-decorator in k3361 in k3358 in k3325 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3659,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3665,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 212  ##sys#decorate-lambda */
t8=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3677 in ##sys#eval-decorator in k3361 in k3358 in k3325 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3686,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3690,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 219  open-output-string */
t6=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3688 in a3677 in ##sys#eval-decorator in k3361 in k3358 in k3325 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3693,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 220  write */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3691 in k3688 in a3677 in ##sys#eval-decorator in k3361 in k3358 in k3325 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 221  get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3694 in k3691 in k3688 in a3677 in ##sys#eval-decorator in k3361 in k3358 in k3325 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 218  ##sys#make-lambda-info */
t2=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3684 in a3677 in ##sys#eval-decorator in k3361 in k3358 in k3325 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3664 in ##sys#eval-decorator in k3361 in k3358 in k3325 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3665,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k3361 in k3358 in k3325 */
static void C_ccall f_3599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3599,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3603,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 192  ##sys#hash-symbol */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3601 in ##sys#hash-table-location in k3361 in k3358 in k3325 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3611,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3611(t6,((C_word*)t0)[2],t2);}

/* loop in k3601 in ##sys#hash-table-location in k3361 in k3358 in k3325 */
static void C_fcall f_3611(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3611,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 203  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k3361 in k3358 in k3325 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3553,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3559,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3559(t8,t1,C_fix(0));}

/* doloop291 in ##sys#hash-table-for-each in k3361 in k3358 in k3325 */
static void C_fcall f_3559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3559,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3569,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 186  ##sys#for-each */
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3577 in doloop291 in ##sys#hash-table-for-each in k3361 in k3358 in k3325 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3578,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 186  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3567 in doloop291 in ##sys#hash-table-for-each in k3361 in k3358 in k3325 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3559(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k3361 in k3358 in k3325 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3533,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3541,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3545,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 180  ##sys#hash-table-ref */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k3543 in ##sys#hash-table-update! in k3361 in k3358 in k3325 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3548(2,t3,t1);}
else{
/* eval.scm: 180  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3546 in k3543 in ##sys#hash-table-update! in k3361 in k3358 in k3325 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 180  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3539 in ##sys#hash-table-update! in k3361 in k3358 in k3325 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 180  ##sys#hash-table-set! */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k3361 in k3358 in k3325 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3473,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3477,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 170  ##sys#hash-symbol */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3475 in ##sys#hash-table-set! in k3361 in k3358 in k3325 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3485,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3485(t6,((C_word*)t0)[2],t2);}

/* loop in k3475 in ##sys#hash-table-set! in k3361 in k3358 in k3325 */
static void C_fcall f_3485(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3485,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t7,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 177  loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* ##sys#hash-table-ref in k3361 in k3358 in k3325 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3418,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3471,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 163  ##sys#hash-symbol */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3469 in ##sys#hash-table-ref in k3361 in k3358 in k3325 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3428(t3,t2));}

/* loop in k3469 in ##sys#hash-table-ref in k3361 in k3358 in k3325 */
static C_word C_fcall f_3428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t1);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t1,C_fix(0));
return((C_word)C_slot(t6,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t9=t6;
t1=t9;
goto loop;}}}

/* ##sys#hash-symbol in k3361 in k3358 in k3325 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3403,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_hash_string(t6));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}}

/* chicken-home in k3361 in k3358 in k3325 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3395,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 145  ##sys#chicken-prefix */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[14]);}

/* k3393 in chicken-home in k3361 in k3358 in k3325 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k3361 in k3358 in k3325 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3364r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3364r(t0,t1,t2);}}

static void C_ccall f_3364r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 139  ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* d in k3325 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3329r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3329r(t0,t1,t2,t3);}}

static void C_ccall f_3329r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_i_nullp(t3))){
/* eval.scm: 38   pp */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[2]+1),t2,t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[767] = {
{"toplevel:eval_scm",(void*)C_eval_toplevel},
{"f_3327:eval_scm",(void*)f_3327},
{"f_3360:eval_scm",(void*)f_3360},
{"f_3363:eval_scm",(void*)f_3363},
{"f_10180:eval_scm",(void*)f_10180},
{"f_10184:eval_scm",(void*)f_10184},
{"f_10209:eval_scm",(void*)f_10209},
{"f_10199:eval_scm",(void*)f_10199},
{"f_10207:eval_scm",(void*)f_10207},
{"f_10192:eval_scm",(void*)f_10192},
{"f_10190:eval_scm",(void*)f_10190},
{"f_6568:eval_scm",(void*)f_6568},
{"f_6663:eval_scm",(void*)f_6663},
{"f_6744:eval_scm",(void*)f_6744},
{"f_10174:eval_scm",(void*)f_10174},
{"f_10170:eval_scm",(void*)f_10170},
{"f_10166:eval_scm",(void*)f_10166},
{"f_10162:eval_scm",(void*)f_10162},
{"f_10152:eval_scm",(void*)f_10152},
{"f_7269:eval_scm",(void*)f_7269},
{"f_7274:eval_scm",(void*)f_7274},
{"f_10130:eval_scm",(void*)f_10130},
{"f_10122:eval_scm",(void*)f_10122},
{"f_10124:eval_scm",(void*)f_10124},
{"f_7281:eval_scm",(void*)f_7281},
{"f_10091:eval_scm",(void*)f_10091},
{"f_10111:eval_scm",(void*)f_10111},
{"f_10107:eval_scm",(void*)f_10107},
{"f_10097:eval_scm",(void*)f_10097},
{"f_10094:eval_scm",(void*)f_10094},
{"f_7634:eval_scm",(void*)f_7634},
{"f_10037:eval_scm",(void*)f_10037},
{"f_10051:eval_scm",(void*)f_10051},
{"f_10087:eval_scm",(void*)f_10087},
{"f_10083:eval_scm",(void*)f_10083},
{"f_10071:eval_scm",(void*)f_10071},
{"f_10075:eval_scm",(void*)f_10075},
{"f_10045:eval_scm",(void*)f_10045},
{"f_8472:eval_scm",(void*)f_8472},
{"f_9940:eval_scm",(void*)f_9940},
{"f_9977:eval_scm",(void*)f_9977},
{"f_9980:eval_scm",(void*)f_9980},
{"f_10003:eval_scm",(void*)f_10003},
{"f_10007:eval_scm",(void*)f_10007},
{"f_9989:eval_scm",(void*)f_9989},
{"f_9986:eval_scm",(void*)f_9986},
{"f_9943:eval_scm",(void*)f_9943},
{"f_8475:eval_scm",(void*)f_8475},
{"f_8533:eval_scm",(void*)f_8533},
{"f_9938:eval_scm",(void*)f_9938},
{"f_8884:eval_scm",(void*)f_8884},
{"f_8888:eval_scm",(void*)f_8888},
{"f_9934:eval_scm",(void*)f_9934},
{"f_8891:eval_scm",(void*)f_8891},
{"f_8895:eval_scm",(void*)f_8895},
{"f_9162:eval_scm",(void*)f_9162},
{"f_9926:eval_scm",(void*)f_9926},
{"f_9184:eval_scm",(void*)f_9184},
{"f_9544:eval_scm",(void*)f_9544},
{"f_9917:eval_scm",(void*)f_9917},
{"f_9924:eval_scm",(void*)f_9924},
{"f_9907:eval_scm",(void*)f_9907},
{"f_9892:eval_scm",(void*)f_9892},
{"f_9896:eval_scm",(void*)f_9896},
{"f_9901:eval_scm",(void*)f_9901},
{"f_9905:eval_scm",(void*)f_9905},
{"f_9870:eval_scm",(void*)f_9870},
{"f_9874:eval_scm",(void*)f_9874},
{"f_9879:eval_scm",(void*)f_9879},
{"f_9883:eval_scm",(void*)f_9883},
{"f_9890:eval_scm",(void*)f_9890},
{"f_9844:eval_scm",(void*)f_9844},
{"f_9850:eval_scm",(void*)f_9850},
{"f_9854:eval_scm",(void*)f_9854},
{"f_9868:eval_scm",(void*)f_9868},
{"f_9857:eval_scm",(void*)f_9857},
{"f_9864:eval_scm",(void*)f_9864},
{"f_9828:eval_scm",(void*)f_9828},
{"f_9834:eval_scm",(void*)f_9834},
{"f_9842:eval_scm",(void*)f_9842},
{"f_9791:eval_scm",(void*)f_9791},
{"f_9795:eval_scm",(void*)f_9795},
{"f_9800:eval_scm",(void*)f_9800},
{"f_9804:eval_scm",(void*)f_9804},
{"f_9826:eval_scm",(void*)f_9826},
{"f_9822:eval_scm",(void*)f_9822},
{"f_9818:eval_scm",(void*)f_9818},
{"f_9807:eval_scm",(void*)f_9807},
{"f_9814:eval_scm",(void*)f_9814},
{"f_9765:eval_scm",(void*)f_9765},
{"f_9771:eval_scm",(void*)f_9771},
{"f_9775:eval_scm",(void*)f_9775},
{"f_9789:eval_scm",(void*)f_9789},
{"f_9778:eval_scm",(void*)f_9778},
{"f_9785:eval_scm",(void*)f_9785},
{"f_9752:eval_scm",(void*)f_9752},
{"f_9726:eval_scm",(void*)f_9726},
{"f_9730:eval_scm",(void*)f_9730},
{"f_9735:eval_scm",(void*)f_9735},
{"f_9739:eval_scm",(void*)f_9739},
{"f_9750:eval_scm",(void*)f_9750},
{"f_9746:eval_scm",(void*)f_9746},
{"f_9710:eval_scm",(void*)f_9710},
{"f_9716:eval_scm",(void*)f_9716},
{"f_9724:eval_scm",(void*)f_9724},
{"f_9698:eval_scm",(void*)f_9698},
{"f_9704:eval_scm",(void*)f_9704},
{"f_9708:eval_scm",(void*)f_9708},
{"f_9689:eval_scm",(void*)f_9689},
{"f_9693:eval_scm",(void*)f_9693},
{"f_9630:eval_scm",(void*)f_9630},
{"f_9640:eval_scm",(void*)f_9640},
{"f_9665:eval_scm",(void*)f_9665},
{"f_9677:eval_scm",(void*)f_9677},
{"f_9683:eval_scm",(void*)f_9683},
{"f_9671:eval_scm",(void*)f_9671},
{"f_9646:eval_scm",(void*)f_9646},
{"f_9652:eval_scm",(void*)f_9652},
{"f_9656:eval_scm",(void*)f_9656},
{"f_9659:eval_scm",(void*)f_9659},
{"f_9663:eval_scm",(void*)f_9663},
{"f_9638:eval_scm",(void*)f_9638},
{"f_9555:eval_scm",(void*)f_9555},
{"f_9565:eval_scm",(void*)f_9565},
{"f_9568:eval_scm",(void*)f_9568},
{"f_9582:eval_scm",(void*)f_9582},
{"f_9600:eval_scm",(void*)f_9600},
{"f_9569:eval_scm",(void*)f_9569},
{"f_9546:eval_scm",(void*)f_9546},
{"f_9205:eval_scm",(void*)f_9205},
{"f_9249:eval_scm",(void*)f_9249},
{"f_9252:eval_scm",(void*)f_9252},
{"f_9529:eval_scm",(void*)f_9529},
{"f_9533:eval_scm",(void*)f_9533},
{"f_9537:eval_scm",(void*)f_9537},
{"f_9334:eval_scm",(void*)f_9334},
{"f_9340:eval_scm",(void*)f_9340},
{"f_9512:eval_scm",(void*)f_9512},
{"f_9518:eval_scm",(void*)f_9518},
{"f_9347:eval_scm",(void*)f_9347},
{"f_9350:eval_scm",(void*)f_9350},
{"f_9353:eval_scm",(void*)f_9353},
{"f_9507:eval_scm",(void*)f_9507},
{"f_9362:eval_scm",(void*)f_9362},
{"f_9365:eval_scm",(void*)f_9365},
{"f_9380:eval_scm",(void*)f_9380},
{"f_9398:eval_scm",(void*)f_9398},
{"f_9461:eval_scm",(void*)f_9461},
{"f_9414:eval_scm",(void*)f_9414},
{"f_9419:eval_scm",(void*)f_9419},
{"f_9423:eval_scm",(void*)f_9423},
{"f_9426:eval_scm",(void*)f_9426},
{"f_9438:eval_scm",(void*)f_9438},
{"f_9441:eval_scm",(void*)f_9441},
{"f_9429:eval_scm",(void*)f_9429},
{"f_9402:eval_scm",(void*)f_9402},
{"f_9384:eval_scm",(void*)f_9384},
{"f_9230:eval_scm",(void*)f_9230},
{"f_9235:eval_scm",(void*)f_9235},
{"f_9387:eval_scm",(void*)f_9387},
{"f_9371:eval_scm",(void*)f_9371},
{"f_9269:eval_scm",(void*)f_9269},
{"f_9274:eval_scm",(void*)f_9274},
{"f_9277:eval_scm",(void*)f_9277},
{"f_9282:eval_scm",(void*)f_9282},
{"f_9289:eval_scm",(void*)f_9289},
{"f_9329:eval_scm",(void*)f_9329},
{"f_9292:eval_scm",(void*)f_9292},
{"f_9304:eval_scm",(void*)f_9304},
{"f_9313:eval_scm",(void*)f_9313},
{"f_9307:eval_scm",(void*)f_9307},
{"f_9295:eval_scm",(void*)f_9295},
{"f_9298:eval_scm",(void*)f_9298},
{"f_9260:eval_scm",(void*)f_9260},
{"f_9254:eval_scm",(void*)f_9254},
{"f_9208:eval_scm",(void*)f_9208},
{"f_9214:eval_scm",(void*)f_9214},
{"f_9202:eval_scm",(void*)f_9202},
{"f_9186:eval_scm",(void*)f_9186},
{"f_9200:eval_scm",(void*)f_9200},
{"f_9197:eval_scm",(void*)f_9197},
{"f_9190:eval_scm",(void*)f_9190},
{"f_9167:eval_scm",(void*)f_9167},
{"f_9176:eval_scm",(void*)f_9176},
{"f_9171:eval_scm",(void*)f_9171},
{"f_9107:eval_scm",(void*)f_9107},
{"f_9111:eval_scm",(void*)f_9111},
{"f_9114:eval_scm",(void*)f_9114},
{"f_9117:eval_scm",(void*)f_9117},
{"f_9120:eval_scm",(void*)f_9120},
{"f_9123:eval_scm",(void*)f_9123},
{"f_9126:eval_scm",(void*)f_9126},
{"f_9129:eval_scm",(void*)f_9129},
{"f_9132:eval_scm",(void*)f_9132},
{"f_9135:eval_scm",(void*)f_9135},
{"f_9086:eval_scm",(void*)f_9086},
{"f_9090:eval_scm",(void*)f_9090},
{"f_9093:eval_scm",(void*)f_9093},
{"f_9062:eval_scm",(void*)f_9062},
{"f_9068:eval_scm",(void*)f_9068},
{"f_9078:eval_scm",(void*)f_9078},
{"f_8920:eval_scm",(void*)f_8920},
{"f_8991:eval_scm",(void*)f_8991},
{"f_9038:eval_scm",(void*)f_9038},
{"f_9048:eval_scm",(void*)f_9048},
{"f_9041:eval_scm",(void*)f_9041},
{"f_9001:eval_scm",(void*)f_9001},
{"f_9003:eval_scm",(void*)f_9003},
{"f_9027:eval_scm",(void*)f_9027},
{"f_9013:eval_scm",(void*)f_9013},
{"f_8961:eval_scm",(void*)f_8961},
{"f_8926:eval_scm",(void*)f_8926},
{"f_8942:eval_scm",(void*)f_8942},
{"f_8948:eval_scm",(void*)f_8948},
{"f_8939:eval_scm",(void*)f_8939},
{"f_8901:eval_scm",(void*)f_8901},
{"f_8905:eval_scm",(void*)f_8905},
{"f_8868:eval_scm",(void*)f_8868},
{"f_8870:eval_scm",(void*)f_8870},
{"f_8874:eval_scm",(void*)f_8874},
{"f_8830:eval_scm",(void*)f_8830},
{"f_8837:eval_scm",(void*)f_8837},
{"f_8844:eval_scm",(void*)f_8844},
{"f_8786:eval_scm",(void*)f_8786},
{"f_8819:eval_scm",(void*)f_8819},
{"f_8806:eval_scm",(void*)f_8806},
{"f_8783:eval_scm",(void*)f_8783},
{"f_8664:eval_scm",(void*)f_8664},
{"f_8758:eval_scm",(void*)f_8758},
{"f_8768:eval_scm",(void*)f_8768},
{"f_8756:eval_scm",(void*)f_8756},
{"f_8685:eval_scm",(void*)f_8685},
{"f_8709:eval_scm",(void*)f_8709},
{"f_8728:eval_scm",(void*)f_8728},
{"f_8703:eval_scm",(void*)f_8703},
{"f_8556:eval_scm",(void*)f_8556},
{"f_8566:eval_scm",(void*)f_8566},
{"f_8571:eval_scm",(void*)f_8571},
{"f_8598:eval_scm",(void*)f_8598},
{"f_8631:eval_scm",(void*)f_8631},
{"f_8592:eval_scm",(void*)f_8592},
{"f_8540:eval_scm",(void*)f_8540},
{"f_8477:eval_scm",(void*)f_8477},
{"f_8481:eval_scm",(void*)f_8481},
{"f_8489:eval_scm",(void*)f_8489},
{"f_8509:eval_scm",(void*)f_8509},
{"f_8433:eval_scm",(void*)f_8433},
{"f_8465:eval_scm",(void*)f_8465},
{"f_8451:eval_scm",(void*)f_8451},
{"f_7934:eval_scm",(void*)f_7934},
{"f_8301:eval_scm",(void*)f_8301},
{"f_8310:eval_scm",(void*)f_8310},
{"f_8340:eval_scm",(void*)f_8340},
{"f_8342:eval_scm",(void*)f_8342},
{"f_8379:eval_scm",(void*)f_8379},
{"f_8369:eval_scm",(void*)f_8369},
{"f_8364:eval_scm",(void*)f_8364},
{"f_8360:eval_scm",(void*)f_8360},
{"f_8003:eval_scm",(void*)f_8003},
{"f_8013:eval_scm",(void*)f_8013},
{"f_8158:eval_scm",(void*)f_8158},
{"f_8263:eval_scm",(void*)f_8263},
{"f_8270:eval_scm",(void*)f_8270},
{"f_8170:eval_scm",(void*)f_8170},
{"f_8189:eval_scm",(void*)f_8189},
{"f_8217:eval_scm",(void*)f_8217},
{"f_8215:eval_scm",(void*)f_8215},
{"f_8211:eval_scm",(void*)f_8211},
{"f_8197:eval_scm",(void*)f_8197},
{"f_8193:eval_scm",(void*)f_8193},
{"f_8185:eval_scm",(void*)f_8185},
{"f_8177:eval_scm",(void*)f_8177},
{"f_8076:eval_scm",(void*)f_8076},
{"f_8094:eval_scm",(void*)f_8094},
{"f_8106:eval_scm",(void*)f_8106},
{"f_8102:eval_scm",(void*)f_8102},
{"f_8090:eval_scm",(void*)f_8090},
{"f_8037:eval_scm",(void*)f_8037},
{"f_8033:eval_scm",(void*)f_8033},
{"f_8020:eval_scm",(void*)f_8020},
{"f_7962:eval_scm",(void*)f_7962},
{"f_7981:eval_scm",(void*)f_7981},
{"f_7978:eval_scm",(void*)f_7978},
{"f_7974:eval_scm",(void*)f_7974},
{"f_7937:eval_scm",(void*)f_7937},
{"f_7956:eval_scm",(void*)f_7956},
{"f_7950:eval_scm",(void*)f_7950},
{"f_7885:eval_scm",(void*)f_7885},
{"f_7891:eval_scm",(void*)f_7891},
{"f_7905:eval_scm",(void*)f_7905},
{"f_7908:eval_scm",(void*)f_7908},
{"f_7915:eval_scm",(void*)f_7915},
{"f_7879:eval_scm",(void*)f_7879},
{"f_7846:eval_scm",(void*)f_7846},
{"f_7850:eval_scm",(void*)f_7850},
{"f_7856:eval_scm",(void*)f_7856},
{"f_7859:eval_scm",(void*)f_7859},
{"f_7877:eval_scm",(void*)f_7877},
{"f_7862:eval_scm",(void*)f_7862},
{"f_7869:eval_scm",(void*)f_7869},
{"f_7833:eval_scm",(void*)f_7833},
{"f_7839:eval_scm",(void*)f_7839},
{"f_7819:eval_scm",(void*)f_7819},
{"f_7830:eval_scm",(void*)f_7830},
{"f_7799:eval_scm",(void*)f_7799},
{"f_7805:eval_scm",(void*)f_7805},
{"f_7812:eval_scm",(void*)f_7812},
{"f_7731:eval_scm",(void*)f_7731},
{"f_7794:eval_scm",(void*)f_7794},
{"f_7735:eval_scm",(void*)f_7735},
{"f_7738:eval_scm",(void*)f_7738},
{"f_7756:eval_scm",(void*)f_7756},
{"f_7762:eval_scm",(void*)f_7762},
{"f_7637:eval_scm",(void*)f_7637},
{"f_7641:eval_scm",(void*)f_7641},
{"f_7722:eval_scm",(void*)f_7722},
{"f_7689:eval_scm",(void*)f_7689},
{"f_7691:eval_scm",(void*)f_7691},
{"f_7704:eval_scm",(void*)f_7704},
{"f_7643:eval_scm",(void*)f_7643},
{"f_7647:eval_scm",(void*)f_7647},
{"f_7682:eval_scm",(void*)f_7682},
{"f_7653:eval_scm",(void*)f_7653},
{"f_7663:eval_scm",(void*)f_7663},
{"f_7656:eval_scm",(void*)f_7656},
{"f_7474:eval_scm",(void*)f_7474},
{"f_7579:eval_scm",(void*)f_7579},
{"f_7596:eval_scm",(void*)f_7596},
{"f_7604:eval_scm",(void*)f_7604},
{"f_7496:eval_scm",(void*)f_7496},
{"f_7501:eval_scm",(void*)f_7501},
{"f_7540:eval_scm",(void*)f_7540},
{"f_7527:eval_scm",(void*)f_7527},
{"f_7483:eval_scm",(void*)f_7483},
{"f_7477:eval_scm",(void*)f_7477},
{"f_7389:eval_scm",(void*)f_7389},
{"f_7396:eval_scm",(void*)f_7396},
{"f_7406:eval_scm",(void*)f_7406},
{"f_7283:eval_scm",(void*)f_7283},
{"f_7287:eval_scm",(void*)f_7287},
{"f_7379:eval_scm",(void*)f_7379},
{"f_7383:eval_scm",(void*)f_7383},
{"f_7296:eval_scm",(void*)f_7296},
{"f_7365:eval_scm",(void*)f_7365},
{"f_7361:eval_scm",(void*)f_7361},
{"f_7299:eval_scm",(void*)f_7299},
{"f_7348:eval_scm",(void*)f_7348},
{"f_7351:eval_scm",(void*)f_7351},
{"f_7354:eval_scm",(void*)f_7354},
{"f_7302:eval_scm",(void*)f_7302},
{"f_7307:eval_scm",(void*)f_7307},
{"f_7341:eval_scm",(void*)f_7341},
{"f_7320:eval_scm",(void*)f_7320},
{"f_7323:eval_scm",(void*)f_7323},
{"f_7243:eval_scm",(void*)f_7243},
{"f_7264:eval_scm",(void*)f_7264},
{"f_7247:eval_scm",(void*)f_7247},
{"f_7261:eval_scm",(void*)f_7261},
{"f_7250:eval_scm",(void*)f_7250},
{"f_7258:eval_scm",(void*)f_7258},
{"f_7253:eval_scm",(void*)f_7253},
{"f_7207:eval_scm",(void*)f_7207},
{"f_7215:eval_scm",(void*)f_7215},
{"f_7185:eval_scm",(void*)f_7185},
{"f_6792:eval_scm",(void*)f_6792},
{"f_7140:eval_scm",(void*)f_7140},
{"f_7135:eval_scm",(void*)f_7135},
{"f_6794:eval_scm",(void*)f_6794},
{"f_7134:eval_scm",(void*)f_7134},
{"f_6798:eval_scm",(void*)f_6798},
{"f_7056:eval_scm",(void*)f_7056},
{"f_7071:eval_scm",(void*)f_7071},
{"f_7074:eval_scm",(void*)f_7074},
{"f_7077:eval_scm",(void*)f_7077},
{"f_7083:eval_scm",(void*)f_7083},
{"f_7086:eval_scm",(void*)f_7086},
{"f_7092:eval_scm",(void*)f_7092},
{"f_6801:eval_scm",(void*)f_6801},
{"f_7047:eval_scm",(void*)f_7047},
{"f_7038:eval_scm",(void*)f_7038},
{"f_7041:eval_scm",(void*)f_7041},
{"f_6807:eval_scm",(void*)f_6807},
{"f_7023:eval_scm",(void*)f_7023},
{"f_6995:eval_scm",(void*)f_6995},
{"f_7019:eval_scm",(void*)f_7019},
{"f_7015:eval_scm",(void*)f_7015},
{"f_7011:eval_scm",(void*)f_7011},
{"f_6810:eval_scm",(void*)f_6810},
{"f_6818:eval_scm",(void*)f_6818},
{"f_6982:eval_scm",(void*)f_6982},
{"f_6822:eval_scm",(void*)f_6822},
{"f_6970:eval_scm",(void*)f_6970},
{"f_6843:eval_scm",(void*)f_6843},
{"f_6847:eval_scm",(void*)f_6847},
{"f_6961:eval_scm",(void*)f_6961},
{"f_6855:eval_scm",(void*)f_6855},
{"f_6859:eval_scm",(void*)f_6859},
{"f_6955:eval_scm",(void*)f_6955},
{"f_6862:eval_scm",(void*)f_6862},
{"f_6865:eval_scm",(void*)f_6865},
{"f_6870:eval_scm",(void*)f_6870},
{"f_6880:eval_scm",(void*)f_6880},
{"f_6926:eval_scm",(void*)f_6926},
{"f_6935:eval_scm",(void*)f_6935},
{"f_6939:eval_scm",(void*)f_6939},
{"f_6892:eval_scm",(void*)f_6892},
{"f_6899:eval_scm",(void*)f_6899},
{"f_6910:eval_scm",(void*)f_6910},
{"f_6921:eval_scm",(void*)f_6921},
{"f_6914:eval_scm",(void*)f_6914},
{"f_6904:eval_scm",(void*)f_6904},
{"f_6883:eval_scm",(void*)f_6883},
{"f_6890:eval_scm",(void*)f_6890},
{"f_6852:eval_scm",(void*)f_6852},
{"f_6832:eval_scm",(void*)f_6832},
{"f_6823:eval_scm",(void*)f_6823},
{"f_6813:eval_scm",(void*)f_6813},
{"f_6746:eval_scm",(void*)f_6746},
{"f_6756:eval_scm",(void*)f_6756},
{"f_6671:eval_scm",(void*)f_6671},
{"f_6683:eval_scm",(void*)f_6683},
{"f_6696:eval_scm",(void*)f_6696},
{"f_6678:eval_scm",(void*)f_6678},
{"f_6665:eval_scm",(void*)f_6665},
{"f_6581:eval_scm",(void*)f_6581},
{"f_6594:eval_scm",(void*)f_6594},
{"f_6627:eval_scm",(void*)f_6627},
{"f_6608:eval_scm",(void*)f_6608},
{"f_6584:eval_scm",(void*)f_6584},
{"f_6571:eval_scm",(void*)f_6571},
{"f_6579:eval_scm",(void*)f_6579},
{"f_3703:eval_scm",(void*)f_3703},
{"f_6320:eval_scm",(void*)f_6320},
{"f_6324:eval_scm",(void*)f_6324},
{"f_6537:eval_scm",(void*)f_6537},
{"f_6513:eval_scm",(void*)f_6513},
{"f_6514:eval_scm",(void*)f_6514},
{"f_6525:eval_scm",(void*)f_6525},
{"f_6531:eval_scm",(void*)f_6531},
{"f_6529:eval_scm",(void*)f_6529},
{"f_6470:eval_scm",(void*)f_6470},
{"f_6473:eval_scm",(void*)f_6473},
{"f_6476:eval_scm",(void*)f_6476},
{"f_6479:eval_scm",(void*)f_6479},
{"f_6480:eval_scm",(void*)f_6480},
{"f_6491:eval_scm",(void*)f_6491},
{"f_6495:eval_scm",(void*)f_6495},
{"f_6499:eval_scm",(void*)f_6499},
{"f_6503:eval_scm",(void*)f_6503},
{"f_6506:eval_scm",(void*)f_6506},
{"f_6428:eval_scm",(void*)f_6428},
{"f_6431:eval_scm",(void*)f_6431},
{"f_6434:eval_scm",(void*)f_6434},
{"f_6435:eval_scm",(void*)f_6435},
{"f_6446:eval_scm",(void*)f_6446},
{"f_6450:eval_scm",(void*)f_6450},
{"f_6454:eval_scm",(void*)f_6454},
{"f_6457:eval_scm",(void*)f_6457},
{"f_6393:eval_scm",(void*)f_6393},
{"f_6396:eval_scm",(void*)f_6396},
{"f_6397:eval_scm",(void*)f_6397},
{"f_6408:eval_scm",(void*)f_6408},
{"f_6412:eval_scm",(void*)f_6412},
{"f_6415:eval_scm",(void*)f_6415},
{"f_6365:eval_scm",(void*)f_6365},
{"f_6366:eval_scm",(void*)f_6366},
{"f_6377:eval_scm",(void*)f_6377},
{"f_6380:eval_scm",(void*)f_6380},
{"f_6346:eval_scm",(void*)f_6346},
{"f_6356:eval_scm",(void*)f_6356},
{"f_6294:eval_scm",(void*)f_6294},
{"f_3916:eval_scm",(void*)f_3916},
{"f_3923:eval_scm",(void*)f_3923},
{"f_4043:eval_scm",(void*)f_4043},
{"f_4099:eval_scm",(void*)f_4099},
{"f_4122:eval_scm",(void*)f_4122},
{"f_4137:eval_scm",(void*)f_4137},
{"f_6097:eval_scm",(void*)f_6097},
{"f_6080:eval_scm",(void*)f_6080},
{"f_6084:eval_scm",(void*)f_6084},
{"f_6049:eval_scm",(void*)f_6049},
{"f_6038:eval_scm",(void*)f_6038},
{"f_5997:eval_scm",(void*)f_5997},
{"f_5939:eval_scm",(void*)f_5939},
{"f_5961:eval_scm",(void*)f_5961},
{"f_5969:eval_scm",(void*)f_5969},
{"f_5981:eval_scm",(void*)f_5981},
{"f_5951:eval_scm",(void*)f_5951},
{"f_5933:eval_scm",(void*)f_5933},
{"f_5909:eval_scm",(void*)f_5909},
{"f_5870:eval_scm",(void*)f_5870},
{"f_5873:eval_scm",(void*)f_5873},
{"f_5876:eval_scm",(void*)f_5876},
{"f_5899:eval_scm",(void*)f_5899},
{"f_5897:eval_scm",(void*)f_5897},
{"f_5893:eval_scm",(void*)f_5893},
{"f_5883:eval_scm",(void*)f_5883},
{"f_5853:eval_scm",(void*)f_5853},
{"f_5857:eval_scm",(void*)f_5857},
{"f_5824:eval_scm",(void*)f_5824},
{"f_5828:eval_scm",(void*)f_5828},
{"f_5601:eval_scm",(void*)f_5601},
{"f_5795:eval_scm",(void*)f_5795},
{"f_5743:eval_scm",(void*)f_5743},
{"f_5767:eval_scm",(void*)f_5767},
{"f_5756:eval_scm",(void*)f_5756},
{"f_5607:eval_scm",(void*)f_5607},
{"f_5735:eval_scm",(void*)f_5735},
{"f_5610:eval_scm",(void*)f_5610},
{"f_5613:eval_scm",(void*)f_5613},
{"f_5641:eval_scm",(void*)f_5641},
{"f_5651:eval_scm",(void*)f_5651},
{"f_5732:eval_scm",(void*)f_5732},
{"f_5724:eval_scm",(void*)f_5724},
{"f_5661:eval_scm",(void*)f_5661},
{"f_5709:eval_scm",(void*)f_5709},
{"f_5664:eval_scm",(void*)f_5664},
{"f_5665:eval_scm",(void*)f_5665},
{"f_5671:eval_scm",(void*)f_5671},
{"f_5693:eval_scm",(void*)f_5693},
{"f_5614:eval_scm",(void*)f_5614},
{"f_5618:eval_scm",(void*)f_5618},
{"f_5621:eval_scm",(void*)f_5621},
{"f_5625:eval_scm",(void*)f_5625},
{"f_5628:eval_scm",(void*)f_5628},
{"f_5632:eval_scm",(void*)f_5632},
{"f_5635:eval_scm",(void*)f_5635},
{"f_5578:eval_scm",(void*)f_5578},
{"f_5491:eval_scm",(void*)f_5491},
{"f_5494:eval_scm",(void*)f_5494},
{"f_5535:eval_scm",(void*)f_5535},
{"f_5547:eval_scm",(void*)f_5547},
{"f_5497:eval_scm",(void*)f_5497},
{"f_5500:eval_scm",(void*)f_5500},
{"f_5525:eval_scm",(void*)f_5525},
{"f_5503:eval_scm",(void*)f_5503},
{"f_5513:eval_scm",(void*)f_5513},
{"f_5521:eval_scm",(void*)f_5521},
{"f_5517:eval_scm",(void*)f_5517},
{"f_5506:eval_scm",(void*)f_5506},
{"f_5423:eval_scm",(void*)f_5423},
{"f_5455:eval_scm",(void*)f_5455},
{"f_5471:eval_scm",(void*)f_5471},
{"f_5467:eval_scm",(void*)f_5467},
{"f_5426:eval_scm",(void*)f_5426},
{"f_5429:eval_scm",(void*)f_5429},
{"f_5445:eval_scm",(void*)f_5445},
{"f_5432:eval_scm",(void*)f_5432},
{"f_5439:eval_scm",(void*)f_5439},
{"f_5370:eval_scm",(void*)f_5370},
{"f_5390:eval_scm",(void*)f_5390},
{"f_5406:eval_scm",(void*)f_5406},
{"f_5402:eval_scm",(void*)f_5402},
{"f_5388:eval_scm",(void*)f_5388},
{"f_5373:eval_scm",(void*)f_5373},
{"f_5380:eval_scm",(void*)f_5380},
{"f_5006:eval_scm",(void*)f_5006},
{"f_5343:eval_scm",(void*)f_5343},
{"f_5354:eval_scm",(void*)f_5354},
{"f_5348:eval_scm",(void*)f_5348},
{"f_5018:eval_scm",(void*)f_5018},
{"f_5023:eval_scm",(void*)f_5023},
{"f_5027:eval_scm",(void*)f_5027},
{"f_5340:eval_scm",(void*)f_5340},
{"f_5030:eval_scm",(void*)f_5030},
{"f_5332:eval_scm",(void*)f_5332},
{"f_5036:eval_scm",(void*)f_5036},
{"f_5294:eval_scm",(void*)f_5294},
{"f_5300:eval_scm",(void*)f_5300},
{"f_5324:eval_scm",(void*)f_5324},
{"f_5271:eval_scm",(void*)f_5271},
{"f_5277:eval_scm",(void*)f_5277},
{"f_6248:eval_scm",(void*)f_6248},
{"f_6277:eval_scm",(void*)f_6277},
{"f_5293:eval_scm",(void*)f_5293},
{"f_5289:eval_scm",(void*)f_5289},
{"f_5249:eval_scm",(void*)f_5249},
{"f_5255:eval_scm",(void*)f_5255},
{"f_5267:eval_scm",(void*)f_5267},
{"f_5230:eval_scm",(void*)f_5230},
{"f_5236:eval_scm",(void*)f_5236},
{"f_5202:eval_scm",(void*)f_5202},
{"f_5208:eval_scm",(void*)f_5208},
{"f_5183:eval_scm",(void*)f_5183},
{"f_5189:eval_scm",(void*)f_5189},
{"f_5155:eval_scm",(void*)f_5155},
{"f_5161:eval_scm",(void*)f_5161},
{"f_5136:eval_scm",(void*)f_5136},
{"f_5142:eval_scm",(void*)f_5142},
{"f_5108:eval_scm",(void*)f_5108},
{"f_5114:eval_scm",(void*)f_5114},
{"f_5089:eval_scm",(void*)f_5089},
{"f_5095:eval_scm",(void*)f_5095},
{"f_5065:eval_scm",(void*)f_5065},
{"f_5071:eval_scm",(void*)f_5071},
{"f_5046:eval_scm",(void*)f_5046},
{"f_5052:eval_scm",(void*)f_5052},
{"f_4917:eval_scm",(void*)f_4917},
{"f_4986:eval_scm",(void*)f_4986},
{"f_4938:eval_scm",(void*)f_4938},
{"f_4964:eval_scm",(void*)f_4964},
{"f_4946:eval_scm",(void*)f_4946},
{"f_4962:eval_scm",(void*)f_4962},
{"f_4942:eval_scm",(void*)f_4942},
{"f_4572:eval_scm",(void*)f_4572},
{"f_4901:eval_scm",(void*)f_4901},
{"f_4581:eval_scm",(void*)f_4581},
{"f_4584:eval_scm",(void*)f_4584},
{"f_4899:eval_scm",(void*)f_4899},
{"f_4590:eval_scm",(void*)f_4590},
{"f_4891:eval_scm",(void*)f_4891},
{"f_4593:eval_scm",(void*)f_4593},
{"f_4875:eval_scm",(void*)f_4875},
{"f_4828:eval_scm",(void*)f_4828},
{"f_4829:eval_scm",(void*)f_4829},
{"f_4833:eval_scm",(void*)f_4833},
{"f_4845:eval_scm",(void*)f_4845},
{"f_4870:eval_scm",(void*)f_4870},
{"f_4836:eval_scm",(void*)f_4836},
{"f_4752:eval_scm",(void*)f_4752},
{"f_4755:eval_scm",(void*)f_4755},
{"f_4761:eval_scm",(void*)f_4761},
{"f_4764:eval_scm",(void*)f_4764},
{"f_4765:eval_scm",(void*)f_4765},
{"f_4781:eval_scm",(void*)f_4781},
{"f_4785:eval_scm",(void*)f_4785},
{"f_4789:eval_scm",(void*)f_4789},
{"f_4793:eval_scm",(void*)f_4793},
{"f_4685:eval_scm",(void*)f_4685},
{"f_4688:eval_scm",(void*)f_4688},
{"f_4694:eval_scm",(void*)f_4694},
{"f_4695:eval_scm",(void*)f_4695},
{"f_4711:eval_scm",(void*)f_4711},
{"f_4715:eval_scm",(void*)f_4715},
{"f_4719:eval_scm",(void*)f_4719},
{"f_4636:eval_scm",(void*)f_4636},
{"f_4639:eval_scm",(void*)f_4639},
{"f_4640:eval_scm",(void*)f_4640},
{"f_4656:eval_scm",(void*)f_4656},
{"f_4660:eval_scm",(void*)f_4660},
{"f_4602:eval_scm",(void*)f_4602},
{"f_4603:eval_scm",(void*)f_4603},
{"f_4619:eval_scm",(void*)f_4619},
{"f_4460:eval_scm",(void*)f_4460},
{"f_4474:eval_scm",(void*)f_4474},
{"f_4478:eval_scm",(void*)f_4478},
{"f_4487:eval_scm",(void*)f_4487},
{"f_4520:eval_scm",(void*)f_4520},
{"f_4528:eval_scm",(void*)f_4528},
{"f_4493:eval_scm",(void*)f_4493},
{"f_4496:eval_scm",(void*)f_4496},
{"f_4512:eval_scm",(void*)f_4512},
{"f_4503:eval_scm",(void*)f_4503},
{"f_4511:eval_scm",(void*)f_4511},
{"f_4548:eval_scm",(void*)f_4548},
{"f_4556:eval_scm",(void*)f_4556},
{"f_4535:eval_scm",(void*)f_4535},
{"f_4547:eval_scm",(void*)f_4547},
{"f_4468:eval_scm",(void*)f_4468},
{"f_4344:eval_scm",(void*)f_4344},
{"f_4403:eval_scm",(void*)f_4403},
{"f_4406:eval_scm",(void*)f_4406},
{"f_4428:eval_scm",(void*)f_4428},
{"f_4432:eval_scm",(void*)f_4432},
{"f_4409:eval_scm",(void*)f_4409},
{"f_4410:eval_scm",(void*)f_4410},
{"f_4414:eval_scm",(void*)f_4414},
{"f_4417:eval_scm",(void*)f_4417},
{"f_4381:eval_scm",(void*)f_4381},
{"f_4384:eval_scm",(void*)f_4384},
{"f_4385:eval_scm",(void*)f_4385},
{"f_4389:eval_scm",(void*)f_4389},
{"f_4287:eval_scm",(void*)f_4287},
{"f_4290:eval_scm",(void*)f_4290},
{"f_4293:eval_scm",(void*)f_4293},
{"f_4296:eval_scm",(void*)f_4296},
{"f_4297:eval_scm",(void*)f_4297},
{"f_4304:eval_scm",(void*)f_4304},
{"f_4277:eval_scm",(void*)f_4277},
{"f_4243:eval_scm",(void*)f_4243},
{"f_4237:eval_scm",(void*)f_4237},
{"f_4238:eval_scm",(void*)f_4238},
{"f_4221:eval_scm",(void*)f_4221},
{"f_4146:eval_scm",(void*)f_4146},
{"f_4149:eval_scm",(void*)f_4149},
{"f_4206:eval_scm",(void*)f_4206},
{"f_4204:eval_scm",(void*)f_4204},
{"f_4196:eval_scm",(void*)f_4196},
{"f_4188:eval_scm",(void*)f_4188},
{"f_4180:eval_scm",(void*)f_4180},
{"f_4172:eval_scm",(void*)f_4172},
{"f_4164:eval_scm",(void*)f_4164},
{"f_4156:eval_scm",(void*)f_4156},
{"f_4100:eval_scm",(void*)f_4100},
{"f_4089:eval_scm",(void*)f_4089},
{"f_4087:eval_scm",(void*)f_4087},
{"f_4076:eval_scm",(void*)f_4076},
{"f_4074:eval_scm",(void*)f_4074},
{"f_4066:eval_scm",(void*)f_4066},
{"f_4058:eval_scm",(void*)f_4058},
{"f_4050:eval_scm",(void*)f_4050},
{"f_3942:eval_scm",(void*)f_3942},
{"f_4010:eval_scm",(void*)f_4010},
{"f_3952:eval_scm",(void*)f_3952},
{"f_4001:eval_scm",(void*)f_4001},
{"f_3986:eval_scm",(void*)f_3986},
{"f_3981:eval_scm",(void*)f_3981},
{"f_3982:eval_scm",(void*)f_3982},
{"f_3958:eval_scm",(void*)f_3958},
{"f_3961:eval_scm",(void*)f_3961},
{"f_3962:eval_scm",(void*)f_3962},
{"f_4033:eval_scm",(void*)f_4033},
{"f_4024:eval_scm",(void*)f_4024},
{"f_3936:eval_scm",(void*)f_3936},
{"f_3924:eval_scm",(void*)f_3924},
{"f_3865:eval_scm",(void*)f_3865},
{"f_3869:eval_scm",(void*)f_3869},
{"f_3890:eval_scm",(void*)f_3890},
{"f_3901:eval_scm",(void*)f_3901},
{"f_3897:eval_scm",(void*)f_3897},
{"f_3870:eval_scm",(void*)f_3870},
{"f_3874:eval_scm",(void*)f_3874},
{"f_3877:eval_scm",(void*)f_3877},
{"f_3881:eval_scm",(void*)f_3881},
{"f_3884:eval_scm",(void*)f_3884},
{"f_3859:eval_scm",(void*)f_3859},
{"f_3853:eval_scm",(void*)f_3853},
{"f_3847:eval_scm",(void*)f_3847},
{"f_3763:eval_scm",(void*)f_3763},
{"f_3767:eval_scm",(void*)f_3767},
{"f_3775:eval_scm",(void*)f_3775},
{"f_3817:eval_scm",(void*)f_3817},
{"f_3748:eval_scm",(void*)f_3748},
{"f_3752:eval_scm",(void*)f_3752},
{"f_3758:eval_scm",(void*)f_3758},
{"f_3709:eval_scm",(void*)f_3709},
{"f_3722:eval_scm",(void*)f_3722},
{"f_3659:eval_scm",(void*)f_3659},
{"f_3678:eval_scm",(void*)f_3678},
{"f_3690:eval_scm",(void*)f_3690},
{"f_3693:eval_scm",(void*)f_3693},
{"f_3696:eval_scm",(void*)f_3696},
{"f_3686:eval_scm",(void*)f_3686},
{"f_3665:eval_scm",(void*)f_3665},
{"f_3599:eval_scm",(void*)f_3599},
{"f_3603:eval_scm",(void*)f_3603},
{"f_3611:eval_scm",(void*)f_3611},
{"f_3553:eval_scm",(void*)f_3553},
{"f_3559:eval_scm",(void*)f_3559},
{"f_3578:eval_scm",(void*)f_3578},
{"f_3569:eval_scm",(void*)f_3569},
{"f_3533:eval_scm",(void*)f_3533},
{"f_3545:eval_scm",(void*)f_3545},
{"f_3548:eval_scm",(void*)f_3548},
{"f_3541:eval_scm",(void*)f_3541},
{"f_3473:eval_scm",(void*)f_3473},
{"f_3477:eval_scm",(void*)f_3477},
{"f_3485:eval_scm",(void*)f_3485},
{"f_3418:eval_scm",(void*)f_3418},
{"f_3471:eval_scm",(void*)f_3471},
{"f_3428:eval_scm",(void*)f_3428},
{"f_3403:eval_scm",(void*)f_3403},
{"f_3391:eval_scm",(void*)f_3391},
{"f_3395:eval_scm",(void*)f_3395},
{"f_3364:eval_scm",(void*)f_3364},
{"f_3329:eval_scm",(void*)f_3329},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
