/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-25 13:03
   Version 4.0.0x5
   windows-mingw32-x86 [ manyargs ptables applyhook ]
   compiled 28.01.2009  on lenovo-1 (MinGW)
   command line: support.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[511];
static double C_possibly_force_alignment;


/* from k4454 */
static C_word C_fcall stub338(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub338(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4447 */
static C_word C_fcall stub333(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub333(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11898)
static void C_ccall f_11898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11912)
static void C_ccall f_11912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11916)
static void C_ccall f_11916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11927)
static void C_ccall f_11927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11939)
static void C_ccall f_11939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11947)
static void C_ccall f_11947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11951)
static void C_ccall f_11951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11910)
static void C_ccall f_11910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11901)
static void C_ccall f_11901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11904)
static void C_ccall f_11904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11885)
static void C_ccall f_11885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11890)
static void C_ccall f_11890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11874)
static void C_ccall f_11874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11879)
static void C_ccall f_11879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11868)
static void C_ccall f_11868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11840)
static void C_ccall f_11840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11840)
static void C_ccall f_11840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11844)
static void C_ccall f_11844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11819)
static void C_ccall f_11819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11823)
static void C_ccall f_11823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11786)
static void C_ccall f_11786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11791)
static void C_ccall f_11791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11791)
static void C_ccall f_11791r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11795)
static void C_ccall f_11795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11753)
static void C_ccall f_11753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11758)
static void C_ccall f_11758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11758)
static void C_ccall f_11758r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11762)
static void C_ccall f_11762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11729)
static void C_ccall f_11729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11660)
static void C_ccall f_11660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11664)
static void C_ccall f_11664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11669)
static void C_fcall f_11669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11673)
static void C_ccall f_11673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11724)
static void C_ccall f_11724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11703)
static void C_ccall f_11703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11715)
static void C_ccall f_11715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11718)
static void C_ccall f_11718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11691)
static void C_ccall f_11691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11627)
static void C_ccall f_11627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11637)
static void C_ccall f_11637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11640)
static void C_ccall f_11640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11525)
static void C_ccall f_11525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11534)
static void C_fcall f_11534(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11621)
static void C_ccall f_11621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11538)
static void C_ccall f_11538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11616)
static void C_ccall f_11616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11541)
static void C_ccall f_11541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11611)
static void C_ccall f_11611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11544)
static void C_ccall f_11544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11547)
static void C_ccall f_11547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11553)
static void C_ccall f_11553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11606)
static void C_ccall f_11606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11556)
static void C_ccall f_11556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11571)
static void C_ccall f_11571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11579)
static void C_fcall f_11579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11589)
static void C_ccall f_11589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11574)
static void C_ccall f_11574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11562)
static void C_ccall f_11562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11529)
static void C_ccall f_11529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11519)
static void C_ccall f_11519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11473)
static void C_ccall f_11473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11492)
static void C_ccall f_11492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11503)
static void C_ccall f_11503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11499)
static void C_ccall f_11499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11461)
static void C_ccall f_11461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11467)
static void C_ccall f_11467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11449)
static void C_ccall f_11449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11453)
static void C_ccall f_11453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11370)
static void C_ccall f_11370(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11370)
static void C_ccall f_11370r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11389)
static void C_ccall f_11389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11414)
static void C_ccall f_11414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11418)
static void C_ccall f_11418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11420)
static void C_fcall f_11420(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11427)
static void C_ccall f_11427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11440)
static void C_ccall f_11440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11444)
static void C_ccall f_11444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11373)
static void C_fcall f_11373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11377)
static void C_ccall f_11377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11383)
static void C_ccall f_11383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11364)
static void C_ccall f_11364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11320)
static void C_ccall f_11320(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11320)
static void C_ccall f_11320r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11332)
static void C_ccall f_11332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11336)
static void C_ccall f_11336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11340)
static void C_ccall f_11340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11328)
static void C_ccall f_11328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11311)
static void C_ccall f_11311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11299)
static void C_ccall f_11299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11287)
static void C_ccall f_11287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11291)
static void C_ccall f_11291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11294)
static void C_ccall f_11294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11249)
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11249)
static void C_ccall f_11249r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11253)
static void C_ccall f_11253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11256)
static void C_ccall f_11256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11263)
static void C_ccall f_11263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11207)
static void C_ccall f_11207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11216)
static void C_fcall f_11216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11178)
static void C_ccall f_11178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11188)
static void C_fcall f_11188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10981)
static void C_ccall f_10981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11160)
static void C_ccall f_11160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11109)
static void C_ccall f_11109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11154)
static void C_ccall f_11154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11112)
static void C_ccall f_11112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11117)
static void C_ccall f_11117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11121)
static void C_ccall f_11121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11115)
static void C_ccall f_11115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11072)
static void C_fcall f_11072(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11076)
static void C_ccall f_11076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11089)
static void C_ccall f_11089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11079)
static void C_ccall f_11079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11037)
static void C_fcall f_11037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11043)
static void C_fcall f_11043(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11070)
static void C_ccall f_11070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10990)
static void C_fcall f_10990(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10996)
static void C_fcall f_10996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11035)
static void C_ccall f_11035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11017)
static void C_ccall f_11017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10794)
static void C_ccall f_10794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10976)
static void C_ccall f_10976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10963)
static void C_fcall f_10963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10969)
static void C_ccall f_10969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10797)
static void C_fcall f_10797(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10957)
static void C_ccall f_10957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10801)
static void C_ccall f_10801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10952)
static void C_ccall f_10952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10804)
static void C_ccall f_10804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10947)
static void C_ccall f_10947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10807)
static void C_ccall f_10807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10816)
static void C_fcall f_10816(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10922)
static void C_ccall f_10922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10880)
static void C_ccall f_10880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10891)
static void C_ccall f_10891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10871)
static void C_ccall f_10871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10857)
static void C_fcall f_10857(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10835)
static void C_ccall f_10835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_ccall f_10841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10845)
static void C_ccall f_10845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10701)
static void C_ccall f_10701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10707)
static void C_ccall f_10707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10788)
static void C_ccall f_10788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10711)
static void C_ccall f_10711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10783)
static void C_ccall f_10783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10714)
static void C_ccall f_10714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_fcall f_10767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10754)
static void C_ccall f_10754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10753)
static void C_ccall f_10753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10735)
static void C_fcall f_10735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10729)
static void C_fcall f_10729(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10409)
static void C_ccall f_10409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10605)
static void C_fcall f_10605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10626)
static void C_fcall f_10626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10099)
static void C_ccall f_10099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10403)
static void C_ccall f_10403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10111)
static void C_ccall f_10111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10121)
static void C_fcall f_10121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10173)
static void C_fcall f_10173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10102)
static void C_fcall f_10102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9780)
static void C_ccall f_9780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10093)
static void C_ccall f_10093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9796)
static void C_fcall f_9796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9805)
static void C_fcall f_9805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9817)
static void C_fcall f_9817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9829)
static void C_fcall f_9829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9835)
static void C_ccall f_9835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9869)
static void C_fcall f_9869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9750)
static void C_ccall f_9750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9709)
static void C_ccall f_9709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9713)
static void C_fcall f_9713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9678)
static void C_ccall f_9678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9691)
static void C_ccall f_9691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9682)
static void C_fcall f_9682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8631)
static void C_ccall f_8631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9672)
static void C_ccall f_9672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8637)
static void C_ccall f_8637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8643)
static void C_fcall f_8643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8672)
static void C_fcall f_8672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8691)
static void C_fcall f_8691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8710)
static void C_fcall f_8710(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_fcall f_8780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8799)
static void C_fcall f_8799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_fcall f_8881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_fcall f_8920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8939)
static void C_fcall f_8939(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_fcall f_8958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_fcall f_9038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9123)
static void C_fcall f_9123(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9232)
static void C_fcall f_9232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_fcall f_9072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8802)
static void C_ccall f_8802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8833)
static void C_fcall f_8833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8713)
static void C_ccall f_8713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_fcall f_8744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8616)
static void C_ccall f_8616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8620)
static void C_ccall f_8620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8584)
static void C_ccall f_8584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8587)
static void C_ccall f_8587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8590)
static void C_ccall f_8590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8470)
static void C_ccall f_8470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8485)
static void C_ccall f_8485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8527)
static void C_ccall f_8527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8474)
static void C_ccall f_8474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8449)
static void C_ccall f_8449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8431)
static void C_fcall f_8431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8434)
static void C_ccall f_8434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8296)
static void C_ccall f_8296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8401)
static void C_ccall f_8401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8396)
static void C_ccall f_8396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8378)
static void C_ccall f_8378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8290)
static void C_ccall f_8290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8285)
static void C_ccall f_8285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8208)
static void C_ccall f_8208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_fcall f_8217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8184)
static void C_ccall f_8184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8183)
static void C_ccall f_8183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8175)
static void C_ccall f_8175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8050)
static void C_fcall f_8050(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8149)
static void C_ccall f_8149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8144)
static void C_ccall f_8144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8072)
static void C_ccall f_8072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8085)
static void C_fcall f_8085(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8007)
static void C_fcall f_8007(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7978)
static void C_fcall f_7978(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7906)
static void C_ccall f_7906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7918)
static void C_fcall f_7918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_ccall f_7922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7947)
static void C_ccall f_7947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7754)
static void C_ccall f_7754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7891)
static void C_ccall f_7891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7886)
static void C_ccall f_7886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_fcall f_7778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_fcall f_7811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7829)
static void C_ccall f_7829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7714)
static void C_ccall f_7714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7620)
static void C_ccall f_7620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7626)
static void C_ccall f_7626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7665)
static void C_ccall f_7665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7634)
static void C_ccall f_7634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7660)
static void C_ccall f_7660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7642)
static void C_ccall f_7642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7655)
static void C_ccall f_7655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7614)
static void C_ccall f_7614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7550)
static void C_ccall f_7550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7553)
static void C_ccall f_7553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static C_word C_fcall f_7564(C_word t0,C_word t1);
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7515)
static void C_fcall f_7515(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7529)
static void C_ccall f_7529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7300)
static void C_fcall f_7300(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7304)
static void C_ccall f_7304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7490)
static void C_ccall f_7490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7415)
static void C_ccall f_7415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7433)
static void C_ccall f_7433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7323)
static void C_ccall f_7323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7294)
static void C_fcall f_7294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7181)
static void C_ccall f_7181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7264)
static void C_ccall f_7264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7250)
static void C_ccall f_7250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7226)
static void C_ccall f_7226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7218)
static void C_ccall f_7218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7127)
static void C_fcall f_7127(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7157)
static void C_ccall f_7157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7145)
static void C_ccall f_7145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6804)
static void C_ccall f_6804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_fcall f_6813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_fcall f_7047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6985)
static void C_fcall f_6985(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6621)
static void C_fcall f_6621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_fcall f_6699(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6672)
static void C_ccall f_6672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6659)
static void C_ccall f_6659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6510)
static void C_ccall f_6510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6446)
static void C_fcall f_6446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6280)
static void C_fcall f_6280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_fcall f_6277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6075)
static void C_ccall f_6075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_fcall f_5603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_fcall f_5766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5792)
static void C_fcall f_5792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5865)
static void C_fcall f_5865(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_fcall f_5656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_fcall f_5687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_fcall f_5718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5562)
static void C_fcall f_5562(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_fcall f_5530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4819)
static void C_fcall f_4819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_fcall f_4847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_fcall f_4711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4586)
static void C_fcall f_4586(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_fcall f_4533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_fcall f_4541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_fcall f_4486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_fcall f_4312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4334)
static void C_fcall f_4334(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_fcall f_4341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4256)
static void C_fcall f_4256(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4174)
static C_word C_fcall f_4174(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4124)
static void C_fcall f_4124(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4103)
static void C_fcall f_4103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4063)
static void C_fcall f_4063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3968)
static void C_fcall f_3968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11669)
static void C_fcall trf_11669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11669(t0,t1);}

C_noret_decl(trf_11534)
static void C_fcall trf_11534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11534(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11534(t0,t1,t2,t3);}

C_noret_decl(trf_11579)
static void C_fcall trf_11579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11579(t0,t1,t2);}

C_noret_decl(trf_11420)
static void C_fcall trf_11420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11420(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11420(t0,t1,t2,t3);}

C_noret_decl(trf_11373)
static void C_fcall trf_11373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11373(t0,t1);}

C_noret_decl(trf_11216)
static void C_fcall trf_11216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11216(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11216(t0,t1,t2);}

C_noret_decl(trf_11188)
static void C_fcall trf_11188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11188(t0,t1);}

C_noret_decl(trf_11072)
static void C_fcall trf_11072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11072(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11072(t0,t1,t2,t3);}

C_noret_decl(trf_11037)
static void C_fcall trf_11037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11037(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11037(t0,t1,t2);}

C_noret_decl(trf_11043)
static void C_fcall trf_11043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11043(t0,t1,t2);}

C_noret_decl(trf_10990)
static void C_fcall trf_10990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10990(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10990(t0,t1,t2,t3);}

C_noret_decl(trf_10996)
static void C_fcall trf_10996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10996(t0,t1,t2);}

C_noret_decl(trf_10963)
static void C_fcall trf_10963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10963(t0,t1,t2,t3);}

C_noret_decl(trf_10797)
static void C_fcall trf_10797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10797(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10797(t0,t1,t2,t3);}

C_noret_decl(trf_10816)
static void C_fcall trf_10816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10816(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10816(t0,t1);}

C_noret_decl(trf_10857)
static void C_fcall trf_10857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10857(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10857(t0,t1);}

C_noret_decl(trf_10767)
static void C_fcall trf_10767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10767(t0,t1);}

C_noret_decl(trf_10735)
static void C_fcall trf_10735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10735(t0,t1);}

C_noret_decl(trf_10729)
static void C_fcall trf_10729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10729(t0,t1);}

C_noret_decl(trf_10605)
static void C_fcall trf_10605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10605(t0,t1);}

C_noret_decl(trf_10626)
static void C_fcall trf_10626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10626(t0,t1);}

C_noret_decl(trf_10121)
static void C_fcall trf_10121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10121(t0,t1);}

C_noret_decl(trf_10173)
static void C_fcall trf_10173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10173(t0,t1);}

C_noret_decl(trf_10102)
static void C_fcall trf_10102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10102(t0,t1);}

C_noret_decl(trf_9796)
static void C_fcall trf_9796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9796(t0,t1);}

C_noret_decl(trf_9805)
static void C_fcall trf_9805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9805(t0,t1);}

C_noret_decl(trf_9817)
static void C_fcall trf_9817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9817(t0,t1);}

C_noret_decl(trf_9829)
static void C_fcall trf_9829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9829(t0,t1);}

C_noret_decl(trf_9869)
static void C_fcall trf_9869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9869(t0,t1);}

C_noret_decl(trf_9713)
static void C_fcall trf_9713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9713(t0,t1);}

C_noret_decl(trf_9682)
static void C_fcall trf_9682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9682(t0,t1);}

C_noret_decl(trf_8643)
static void C_fcall trf_8643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8643(t0,t1,t2);}

C_noret_decl(trf_8672)
static void C_fcall trf_8672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8672(t0,t1);}

C_noret_decl(trf_8691)
static void C_fcall trf_8691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8691(t0,t1);}

C_noret_decl(trf_8710)
static void C_fcall trf_8710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8710(t0,t1);}

C_noret_decl(trf_8780)
static void C_fcall trf_8780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8780(t0,t1);}

C_noret_decl(trf_8799)
static void C_fcall trf_8799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8799(t0,t1);}

C_noret_decl(trf_8881)
static void C_fcall trf_8881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8881(t0,t1);}

C_noret_decl(trf_8920)
static void C_fcall trf_8920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8920(t0,t1);}

C_noret_decl(trf_8939)
static void C_fcall trf_8939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8939(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8939(t0,t1);}

C_noret_decl(trf_8958)
static void C_fcall trf_8958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8958(t0,t1);}

C_noret_decl(trf_9038)
static void C_fcall trf_9038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9038(t0,t1);}

C_noret_decl(trf_9123)
static void C_fcall trf_9123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9123(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9123(t0,t1);}

C_noret_decl(trf_9232)
static void C_fcall trf_9232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9232(t0,t1);}

C_noret_decl(trf_9072)
static void C_fcall trf_9072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9072(t0,t1);}

C_noret_decl(trf_8833)
static void C_fcall trf_8833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8833(t0,t1);}

C_noret_decl(trf_8744)
static void C_fcall trf_8744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8744(t0,t1);}

C_noret_decl(trf_8431)
static void C_fcall trf_8431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8431(t0,t1);}

C_noret_decl(trf_8217)
static void C_fcall trf_8217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8217(t0,t1);}

C_noret_decl(trf_8050)
static void C_fcall trf_8050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8050(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8050(t0,t1,t2,t3);}

C_noret_decl(trf_8085)
static void C_fcall trf_8085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8085(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8085(t0,t1,t2,t3);}

C_noret_decl(trf_8007)
static void C_fcall trf_8007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8007(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8007(t0,t1,t2,t3);}

C_noret_decl(trf_7978)
static void C_fcall trf_7978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7978(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7978(t0,t1,t2,t3);}

C_noret_decl(trf_7918)
static void C_fcall trf_7918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7918(t0,t1);}

C_noret_decl(trf_7778)
static void C_fcall trf_7778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7778(t0,t1);}

C_noret_decl(trf_7811)
static void C_fcall trf_7811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7811(t0,t1);}

C_noret_decl(trf_7515)
static void C_fcall trf_7515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7515(t0,t1,t2);}

C_noret_decl(trf_7300)
static void C_fcall trf_7300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7300(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7300(t0,t1,t2,t3);}

C_noret_decl(trf_7294)
static void C_fcall trf_7294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7294(t0,t1,t2);}

C_noret_decl(trf_7127)
static void C_fcall trf_7127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7127(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7127(t0,t1,t2);}

C_noret_decl(trf_6813)
static void C_fcall trf_6813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6813(t0,t1);}

C_noret_decl(trf_7047)
static void C_fcall trf_7047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7047(t0,t1);}

C_noret_decl(trf_6985)
static void C_fcall trf_6985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6985(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6985(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6621)
static void C_fcall trf_6621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6621(t0,t1);}

C_noret_decl(trf_6699)
static void C_fcall trf_6699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6699(t0,t1);}

C_noret_decl(trf_6446)
static void C_fcall trf_6446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6446(t0,t1);}

C_noret_decl(trf_6280)
static void C_fcall trf_6280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6280(t0,t1);}

C_noret_decl(trf_6277)
static void C_fcall trf_6277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6277(t0,t1);}

C_noret_decl(trf_5603)
static void C_fcall trf_5603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5603(t0,t1);}

C_noret_decl(trf_5766)
static void C_fcall trf_5766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5766(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5766(t0,t1,t2);}

C_noret_decl(trf_5792)
static void C_fcall trf_5792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5792(t0,t1);}

C_noret_decl(trf_5865)
static void C_fcall trf_5865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5865(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5865(t0,t1);}

C_noret_decl(trf_5656)
static void C_fcall trf_5656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5656(t0,t1);}

C_noret_decl(trf_5687)
static void C_fcall trf_5687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5687(t0,t1);}

C_noret_decl(trf_5718)
static void C_fcall trf_5718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5718(t0,t1);}

C_noret_decl(trf_5562)
static void C_fcall trf_5562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5562(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5562(t0,t1,t2);}

C_noret_decl(trf_5530)
static void C_fcall trf_5530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5530(t0,t1);}

C_noret_decl(trf_4819)
static void C_fcall trf_4819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4819(t0,t1,t2);}

C_noret_decl(trf_4847)
static void C_fcall trf_4847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4847(t0,t1);}

C_noret_decl(trf_4711)
static void C_fcall trf_4711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4711(t0,t1);}

C_noret_decl(trf_4586)
static void C_fcall trf_4586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4586(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4586(t0,t1,t2,t3);}

C_noret_decl(trf_4533)
static void C_fcall trf_4533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4533(t0,t1,t2);}

C_noret_decl(trf_4541)
static void C_fcall trf_4541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4541(t0,t1);}

C_noret_decl(trf_4486)
static void C_fcall trf_4486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4486(t0,t1);}

C_noret_decl(trf_4312)
static void C_fcall trf_4312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4312(t0,t1,t2);}

C_noret_decl(trf_4334)
static void C_fcall trf_4334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4334(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4334(t0,t1);}

C_noret_decl(trf_4341)
static void C_fcall trf_4341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4341(t0,t1);}

C_noret_decl(trf_4256)
static void C_fcall trf_4256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4256(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4256(t0,t1,t2,t3);}

C_noret_decl(trf_4124)
static void C_fcall trf_4124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4124(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4124(t0,t1,t2,t3);}

C_noret_decl(trf_4103)
static void C_fcall trf_4103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4103(t0,t1);}

C_noret_decl(trf_4063)
static void C_fcall trf_4063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4063(t0,t1,t2);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4016(t0,t1);}

C_noret_decl(trf_3968)
static void C_fcall trf_3968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3968(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5190)){
C_save(t1);
C_rereclaim2(5190*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,511);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],12,"flush-output");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],6,"printf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[15]=C_h_intern(&lf[15],5,"force");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[20]=C_h_intern(&lf[20],25,"\010compilercompiler-warning");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\012\012Warning: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],20,"\003syswarnings-enabled");
lf[25]=C_h_intern(&lf[25],4,"quit");
lf[26]=C_h_intern(&lf[26],4,"exit");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[28]=C_h_intern(&lf[28],21,"\003syssyntax-error-hook");
lf[29]=C_h_intern(&lf[29],16,"print-call-chain");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\031Syntax error (~a): ~a~%~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[35]=C_h_intern(&lf[35],12,"syntax-error");
lf[36]=C_h_intern(&lf[36],31,"\010compileremit-syntax-trace-info");
lf[37]=C_h_intern(&lf[37],9,"map-llist");
lf[38]=C_h_intern(&lf[38],24,"\010compilercheck-signature");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[40]=C_h_intern(&lf[40],18,"\010compilerreal-name");
lf[41]=C_h_intern(&lf[41],13,"\010compilerposq");
lf[42]=C_h_intern(&lf[42],18,"\010compilerstringify");
lf[43]=C_h_intern(&lf[43],14,"symbol->string");
lf[44]=C_h_intern(&lf[44],7,"sprintf");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[46]=C_h_intern(&lf[46],18,"\010compilersymbolify");
lf[47]=C_h_intern(&lf[47],14,"string->symbol");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[49]=C_h_intern(&lf[49],26,"\010compilerbuild-lambda-list");
lf[50]=C_h_intern(&lf[50],29,"\010compilerstring->c-identifier");
lf[51]=C_h_intern(&lf[51],24,"\003sysstring->c-identifier");
lf[52]=C_h_intern(&lf[52],21,"\010compilerc-ify-string");
lf[53]=C_h_intern(&lf[53],16,"\003syslist->string");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[55]=C_h_intern(&lf[55],6,"append");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[57]=C_h_intern(&lf[57],16,"\003sysstring->list");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[61]=C_h_intern(&lf[61],28,"\010compilervalid-c-identifier\077");
lf[62]=C_h_intern(&lf[62],3,"any");
lf[63]=C_h_intern(&lf[63],8,"->string");
lf[64]=C_h_intern(&lf[64],14,"\010compilerwords");
lf[65]=C_h_intern(&lf[65],21,"\010compilerwords->bytes");
lf[66]=C_h_intern(&lf[66],34,"\010compilercheck-and-open-input-file");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[68]=C_h_intern(&lf[68],18,"current-input-port");
lf[69]=C_h_intern(&lf[69],15,"open-input-file");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[72]=C_h_intern(&lf[72],12,"file-exists\077");
lf[73]=C_h_intern(&lf[73],33,"\010compilerclose-checked-input-file");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[75]=C_h_intern(&lf[75],16,"close-input-port");
lf[76]=C_h_intern(&lf[76],19,"\010compilerfold-inner");
lf[77]=C_h_intern(&lf[77],7,"reverse");
lf[78]=C_h_intern(&lf[78],28,"\010compilerfollow-without-loop");
lf[79]=C_h_intern(&lf[79],21,"\010compilersort-symbols");
lf[80]=C_h_intern(&lf[80],8,"string<\077");
lf[81]=C_h_intern(&lf[81],4,"sort");
lf[82]=C_h_intern(&lf[82],18,"\010compilerconstant\077");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_h_intern(&lf[84],29,"\010compilercollapsable-literal\077");
lf[85]=C_h_intern(&lf[85],19,"\010compilerimmediate\077");
lf[86]=C_h_intern(&lf[86],20,"\010compilerbig-fixnum\077");
lf[87]=C_h_intern(&lf[87],23,"\010compilerbasic-literal\077");
lf[88]=C_h_intern(&lf[88],5,"every");
lf[89]=C_h_intern(&lf[89],12,"vector->list");
lf[90]=C_h_intern(&lf[90],32,"\010compilercanonicalize-begin-body");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[93]=C_h_intern(&lf[93],3,"let");
lf[94]=C_h_intern(&lf[94],6,"gensym");
lf[95]=C_h_intern(&lf[95],1,"t");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[97]=C_h_intern(&lf[97],21,"\010compilerstring->expr");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[100]=C_h_intern(&lf[100],5,"begin");
lf[101]=C_h_intern(&lf[101],10,"\003sysappend");
lf[102]=C_h_intern(&lf[102],4,"read");
lf[103]=C_h_intern(&lf[103],6,"unfold");
lf[104]=C_h_intern(&lf[104],11,"eof-object\077");
lf[105]=C_h_intern(&lf[105],6,"values");
lf[106]=C_h_intern(&lf[106],22,"with-input-from-string");
lf[107]=C_h_intern(&lf[107],22,"with-exception-handler");
lf[108]=C_h_intern(&lf[108],30,"call-with-current-continuation");
lf[109]=C_h_intern(&lf[109],30,"\010compilerdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],25,"\003sysdecompose-lambda-list");
lf[111]=C_h_intern(&lf[111],37,"\010compilerprocess-lambda-documentation");
lf[112]=C_h_intern(&lf[112],21,"\010compilerllist-length");
lf[113]=C_h_intern(&lf[113],30,"\010compilerexpand-profile-lambda");
lf[114]=C_h_intern(&lf[114],29,"\010compilerprofile-lambda-index");
lf[115]=C_h_intern(&lf[115],28,"\010compilerprofile-lambda-list");
lf[116]=C_h_intern(&lf[116],33,"\010compilerprofile-info-vector-name");
lf[117]=C_h_intern(&lf[117],17,"\003sysprofile-entry");
lf[118]=C_h_intern(&lf[118],6,"lambda");
lf[119]=C_h_intern(&lf[119],5,"apply");
lf[120]=C_h_intern(&lf[120],16,"\003sysprofile-exit");
lf[121]=C_h_intern(&lf[121],16,"\003sysdynamic-wind");
lf[122]=C_h_intern(&lf[122],10,"alist-cons");
lf[123]=C_h_intern(&lf[123],37,"\010compilerinitialize-analysis-database");
lf[124]=C_h_intern(&lf[124],8,"\003sysput!");
lf[125]=C_h_intern(&lf[125],9,"\003syserror");
lf[126]=C_h_intern(&lf[126],18,"\010compilerintrinsic");
lf[127]=C_h_intern(&lf[127],8,"internal");
lf[128]=C_h_intern(&lf[128],26,"\010compilerinternal-bindings");
lf[129]=C_h_intern(&lf[129],8,"extended");
lf[130]=C_h_intern(&lf[130],17,"extended-bindings");
lf[131]=C_h_intern(&lf[131],26,"\010compilerfoldable-bindings");
lf[132]=C_h_intern(&lf[132],17,"\010compilerfoldable");
lf[133]=C_h_intern(&lf[133],8,"standard");
lf[134]=C_h_intern(&lf[134],17,"standard-bindings");
lf[135]=C_h_intern(&lf[135],12,"\010compilerget");
lf[136]=C_h_intern(&lf[136],18,"\003syshash-table-ref");
lf[137]=C_h_intern(&lf[137],16,"\010compilerget-all");
lf[138]=C_h_intern(&lf[138],10,"filter-map");
lf[139]=C_h_intern(&lf[139],13,"\010compilerput!");
lf[140]=C_h_intern(&lf[140],19,"\003syshash-table-set!");
lf[141]=C_h_intern(&lf[141],17,"\010compilercollect!");
lf[142]=C_h_intern(&lf[142],15,"\010compilercount!");
lf[143]=C_h_intern(&lf[143],17,"\010compilerget-line");
lf[144]=C_h_intern(&lf[144],24,"\003sysline-number-database");
lf[145]=C_h_intern(&lf[145],19,"\010compilerget-line-2");
lf[146]=C_h_intern(&lf[146],30,"\010compilerfind-lambda-container");
lf[147]=C_h_intern(&lf[147],12,"contained-in");
lf[148]=C_h_intern(&lf[148],37,"\010compilerdisplay-line-number-database");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[150]=C_h_intern(&lf[150],7,"\003sysmap");
lf[151]=C_h_intern(&lf[151],3,"cdr");
lf[152]=C_h_intern(&lf[152],23,"\003syshash-table-for-each");
lf[153]=C_h_intern(&lf[153],34,"\010compilerdisplay-analysis-database");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010\011lval=~s");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[159]=C_h_intern(&lf[159],7,"unknown");
lf[160]=C_h_intern(&lf[160],8,"captured");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\011undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003"
"uud\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[163]=C_h_intern(&lf[163],4,"caar");
lf[164]=C_h_intern(&lf[164],5,"value");
lf[165]=C_h_intern(&lf[165],4,"cdar");
lf[166]=C_h_intern(&lf[166],11,"local-value");
lf[167]=C_h_intern(&lf[167],15,"potential-value");
lf[168]=C_h_intern(&lf[168],10,"replacable");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[170]=C_h_intern(&lf[170],10,"references");
lf[171]=C_h_intern(&lf[171],10,"call-sites");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[173]=C_h_intern(&lf[173],4,"home");
lf[174]=C_h_intern(&lf[174],8,"contains");
lf[175]=C_h_intern(&lf[175],8,"use-expr");
lf[176]=C_h_intern(&lf[176],12,"closure-size");
lf[177]=C_h_intern(&lf[177],14,"rest-parameter");
lf[178]=C_h_intern(&lf[178],16,"o-r/access-count");
lf[179]=C_h_intern(&lf[179],18,"captured-variables");
lf[180]=C_h_intern(&lf[180],13,"explicit-rest");
lf[181]=C_h_intern(&lf[181],8,"assigned");
lf[182]=C_h_intern(&lf[182],5,"boxed");
lf[183]=C_h_intern(&lf[183],6,"global");
lf[184]=C_h_intern(&lf[184],12,"contractable");
lf[185]=C_h_intern(&lf[185],16,"standard-binding");
lf[186]=C_h_intern(&lf[186],16,"assigned-locally");
lf[187]=C_h_intern(&lf[187],11,"collapsable");
lf[188]=C_h_intern(&lf[188],9,"removable");
lf[189]=C_h_intern(&lf[189],9,"undefined");
lf[190]=C_h_intern(&lf[190],9,"replacing");
lf[191]=C_h_intern(&lf[191],6,"unused");
lf[192]=C_h_intern(&lf[192],6,"simple");
lf[193]=C_h_intern(&lf[193],9,"inlinable");
lf[194]=C_h_intern(&lf[194],13,"inline-export");
lf[195]=C_h_intern(&lf[195],21,"has-unused-parameters");
lf[196]=C_h_intern(&lf[196],16,"extended-binding");
lf[197]=C_h_intern(&lf[197],12,"customizable");
lf[198]=C_h_intern(&lf[198],8,"constant");
lf[199]=C_h_intern(&lf[199],10,"boxed-rest");
lf[200]=C_h_intern(&lf[200],11,"hidden-refs");
lf[201]=C_h_intern(&lf[201],5,"write");
lf[202]=C_h_intern(&lf[202],34,"\010compilerdefault-standard-bindings");
lf[203]=C_h_intern(&lf[203],34,"\010compilerdefault-extended-bindings");
lf[204]=C_h_intern(&lf[204],9,"make-node");
lf[205]=C_h_intern(&lf[205],4,"node");
lf[206]=C_h_intern(&lf[206],5,"node\077");
lf[207]=C_h_intern(&lf[207],15,"node-class-set!");
lf[208]=C_h_intern(&lf[208],14,"\003sysblock-set!");
lf[209]=C_h_intern(&lf[209],10,"node-class");
lf[210]=C_h_intern(&lf[210],20,"node-parameters-set!");
lf[211]=C_h_intern(&lf[211],15,"node-parameters");
lf[212]=C_h_intern(&lf[212],24,"node-subexpressions-set!");
lf[213]=C_h_intern(&lf[213],19,"node-subexpressions");
lf[214]=C_h_intern(&lf[214],16,"\010compilervarnode");
lf[215]=C_h_intern(&lf[215],13,"\004corevariable");
lf[216]=C_h_intern(&lf[216],14,"\010compilerqnode");
lf[217]=C_h_intern(&lf[217],25,"\010compilerbuild-node-graph");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[219]=C_h_intern(&lf[219],15,"\004coreglobal-ref");
lf[220]=C_h_intern(&lf[220],2,"if");
lf[221]=C_h_intern(&lf[221],14,"\004coreundefined");
lf[222]=C_h_intern(&lf[222],8,"truncate");
lf[223]=C_h_intern(&lf[223],4,"type");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[225]=C_h_intern(&lf[225],6,"fixnum");
lf[226]=C_h_intern(&lf[226],11,"number-type");
lf[227]=C_h_intern(&lf[227],6,"unzip1");
lf[228]=C_h_intern(&lf[228],11,"\004corelambda");
lf[229]=C_h_intern(&lf[229],14,"\004coreprimitive");
lf[230]=C_h_intern(&lf[230],11,"\004coreinline");
lf[231]=C_h_intern(&lf[231],13,"\004corecallunit");
lf[232]=C_h_intern(&lf[232],9,"\004coreproc");
lf[233]=C_h_intern(&lf[233],4,"set!");
lf[234]=C_h_intern(&lf[234],9,"\004coreset!");
lf[235]=C_h_intern(&lf[235],29,"\004coreforeign-callback-wrapper");
lf[236]=C_h_intern(&lf[236],5,"sixth");
lf[237]=C_h_intern(&lf[237],5,"fifth");
lf[238]=C_h_intern(&lf[238],20,"\004coreinline_allocate");
lf[239]=C_h_intern(&lf[239],8,"\004coreapp");
lf[240]=C_h_intern(&lf[240],9,"\004corecall");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[242]=C_h_intern(&lf[242],24,"\010compilersource-filename");
lf[243]=C_h_intern(&lf[243],28,"\003syssymbol->qualified-string");
lf[244]=C_h_intern(&lf[244],7,"\003sysget");
lf[245]=C_h_intern(&lf[245],34,"\010compileralways-bound-to-procedure");
lf[246]=C_h_intern(&lf[246],15,"\004coreinline_ref");
lf[247]=C_h_intern(&lf[247],18,"\004coreinline_update");
lf[248]=C_h_intern(&lf[248],19,"\004coreinline_loc_ref");
lf[249]=C_h_intern(&lf[249],22,"\004coreinline_loc_update");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[251]=C_h_intern(&lf[251],1,"o");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[253]=C_h_intern(&lf[253],30,"\010compilerbuild-expression-tree");
lf[254]=C_h_intern(&lf[254],12,"\004coreclosure");
lf[255]=C_h_intern(&lf[255],4,"last");
lf[256]=C_h_intern(&lf[256],3,"map");
lf[257]=C_h_intern(&lf[257],4,"list");
lf[258]=C_h_intern(&lf[258],7,"butlast");
lf[259]=C_h_intern(&lf[259],5,"cons*");
lf[260]=C_h_intern(&lf[260],9,"\004corebind");
lf[261]=C_h_intern(&lf[261],10,"\004coreunbox");
lf[262]=C_h_intern(&lf[262],8,"\004coreref");
lf[263]=C_h_intern(&lf[263],11,"\004coreupdate");
lf[264]=C_h_intern(&lf[264],13,"\004coreupdate_i");
lf[265]=C_h_intern(&lf[265],8,"\004corebox");
lf[266]=C_h_intern(&lf[266],9,"\004corecond");
lf[267]=C_h_intern(&lf[267],21,"\010compilerfold-boolean");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[269]=C_h_intern(&lf[269],31,"\010compilerinline-lambda-bindings");
lf[270]=C_h_intern(&lf[270],8,"split-at");
lf[271]=C_h_intern(&lf[271],10,"fold-right");
lf[272]=C_h_intern(&lf[272],4,"take");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[274]=C_h_intern(&lf[274],34,"\010compilercopy-node-tree-and-rename");
lf[275]=C_h_intern(&lf[275],9,"alist-ref");
lf[276]=C_h_intern(&lf[276],3,"eq\077");
lf[277]=C_h_intern(&lf[277],1,"f");
lf[278]=C_h_intern(&lf[278],18,"\010compilertree-copy");
lf[279]=C_h_intern(&lf[279],4,"cons");
lf[280]=C_h_intern(&lf[280],19,"\010compilercopy-node!");
lf[281]=C_h_intern(&lf[281],20,"\010compilernode->sexpr");
lf[282]=C_h_intern(&lf[282],20,"\010compilersexpr->node");
lf[283]=C_h_intern(&lf[283],32,"\010compileremit-global-inline-file");
lf[284]=C_h_intern(&lf[284],5,"print");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[286]=C_h_intern(&lf[286],1,"i");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[289]=C_h_intern(&lf[289],2,"pp");
lf[290]=C_h_intern(&lf[290],3,"yes");
lf[291]=C_h_intern(&lf[291],2,"no");
lf[292]=C_h_intern(&lf[292],24,"\010compilerinline-max-size");
lf[293]=C_h_intern(&lf[293],15,"\010compilerinline");
lf[294]=C_h_intern(&lf[294],22,"\010compilerinline-global");
lf[295]=C_h_intern(&lf[295],26,"\010compilervariable-visible\077");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[299]=C_h_intern(&lf[299],15,"chicken-version");
lf[300]=C_h_intern(&lf[300],19,"with-output-to-file");
lf[301]=C_h_intern(&lf[301],25,"\010compilerload-inline-file");
lf[302]=C_h_intern(&lf[302],20,"with-input-from-file");
lf[303]=C_h_intern(&lf[303],19,"\010compilermatch-node");
lf[304]=C_h_intern(&lf[304],1,"a");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[306]=C_h_intern(&lf[306],37,"\010compilerexpression-has-side-effects\077");
lf[307]=C_h_intern(&lf[307],24,"foreign-callback-stub-id");
lf[308]=C_h_intern(&lf[308],4,"find");
lf[309]=C_h_intern(&lf[309],22,"foreign-callback-stubs");
lf[310]=C_h_intern(&lf[310],28,"\010compilersimple-lambda-node\077");
lf[311]=C_h_intern(&lf[311],31,"\010compilerdump-undefined-globals");
lf[312]=C_h_intern(&lf[312],28,"\003systoplevel-definition-hook");
lf[313]=C_h_intern(&lf[313],22,"\010compilerhide-variable");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[315]=C_h_intern(&lf[315],36,"\010compilercompute-database-statistics");
lf[316]=C_h_intern(&lf[316],29,"\010compilercurrent-program-size");
lf[317]=C_h_intern(&lf[317],30,"\010compileroriginal-program-size");
lf[318]=C_h_intern(&lf[318],33,"\010compilerprint-program-statistics");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[325]=C_h_intern(&lf[325],1,"s");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[327]=C_h_intern(&lf[327],35,"\010compilerpprint-expressions-to-file");
lf[328]=C_h_intern(&lf[328],17,"close-output-port");
lf[329]=C_h_intern(&lf[329],12,"pretty-print");
lf[330]=C_h_intern(&lf[330],19,"with-output-to-port");
lf[331]=C_h_intern(&lf[331],16,"open-output-file");
lf[332]=C_h_intern(&lf[332],19,"current-output-port");
lf[333]=C_h_intern(&lf[333],27,"\010compilerforeign-type-check");
lf[334]=C_h_intern(&lf[334],4,"char");
lf[335]=C_h_intern(&lf[335],13,"unsigned-char");
lf[336]=C_h_intern(&lf[336],6,"unsafe");
lf[337]=C_h_intern(&lf[337],25,"\003sysforeign-char-argument");
lf[338]=C_h_intern(&lf[338],3,"int");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-fixnum-argument");
lf[340]=C_h_intern(&lf[340],5,"float");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-flonum-argument");
lf[342]=C_h_intern(&lf[342],7,"pointer");
lf[343]=C_h_intern(&lf[343],26,"\003sysforeign-block-argument");
lf[344]=C_h_intern(&lf[344],15,"nonnull-pointer");
lf[345]=C_h_intern(&lf[345],8,"u8vector");
lf[346]=C_h_intern(&lf[346],34,"\003sysforeign-number-vector-argument");
lf[347]=C_h_intern(&lf[347],16,"nonnull-u8vector");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[349]=C_h_intern(&lf[349],7,"integer");
lf[350]=C_h_intern(&lf[350],28,"\003sysforeign-integer-argument");
lf[351]=C_h_intern(&lf[351],16,"unsigned-integer");
lf[352]=C_h_intern(&lf[352],37,"\003sysforeign-unsigned-integer-argument");
lf[353]=C_h_intern(&lf[353],9,"c-pointer");
lf[354]=C_h_intern(&lf[354],28,"\003sysforeign-pointer-argument");
lf[355]=C_h_intern(&lf[355],17,"nonnull-c-pointer");
lf[356]=C_h_intern(&lf[356],8,"c-string");
lf[357]=C_h_intern(&lf[357],17,"\003sysmake-c-string");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-string-argument");
lf[359]=C_h_intern(&lf[359],16,"nonnull-c-string");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],18,"\003syssymbol->string");
lf[362]=C_h_intern(&lf[362],3,"ref");
lf[363]=C_h_intern(&lf[363],8,"instance");
lf[364]=C_h_intern(&lf[364],12,"instance-ref");
lf[365]=C_h_intern(&lf[365],4,"this");
lf[366]=C_h_intern(&lf[366],8,"slot-ref");
lf[367]=C_h_intern(&lf[367],16,"nonnull-instance");
lf[368]=C_h_intern(&lf[368],5,"const");
lf[369]=C_h_intern(&lf[369],4,"enum");
lf[370]=C_h_intern(&lf[370],8,"function");
lf[371]=C_h_intern(&lf[371],27,"\010compilerforeign-type-table");
lf[372]=C_h_intern(&lf[372],17,"nonnull-c-string*");
lf[373]=C_h_intern(&lf[373],26,"nonnull-unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],9,"c-string*");
lf[375]=C_h_intern(&lf[375],18,"unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],13,"c-string-list");
lf[377]=C_h_intern(&lf[377],14,"c-string-list*");
lf[378]=C_h_intern(&lf[378],18,"unsigned-integer32");
lf[379]=C_h_intern(&lf[379],13,"unsigned-long");
lf[380]=C_h_intern(&lf[380],4,"long");
lf[381]=C_h_intern(&lf[381],9,"integer32");
lf[382]=C_h_intern(&lf[382],17,"nonnull-u16vector");
lf[383]=C_h_intern(&lf[383],16,"nonnull-s8vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s16vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-u32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-f32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f64vector");
lf[389]=C_h_intern(&lf[389],9,"u16vector");
lf[390]=C_h_intern(&lf[390],8,"s8vector");
lf[391]=C_h_intern(&lf[391],9,"s16vector");
lf[392]=C_h_intern(&lf[392],9,"u32vector");
lf[393]=C_h_intern(&lf[393],9,"s32vector");
lf[394]=C_h_intern(&lf[394],9,"f32vector");
lf[395]=C_h_intern(&lf[395],9,"f64vector");
lf[396]=C_h_intern(&lf[396],22,"nonnull-scheme-pointer");
lf[397]=C_h_intern(&lf[397],12,"nonnull-blob");
lf[398]=C_h_intern(&lf[398],19,"nonnull-byte-vector");
lf[399]=C_h_intern(&lf[399],11,"byte-vector");
lf[400]=C_h_intern(&lf[400],4,"blob");
lf[401]=C_h_intern(&lf[401],14,"scheme-pointer");
lf[402]=C_h_intern(&lf[402],6,"double");
lf[403]=C_h_intern(&lf[403],6,"number");
lf[404]=C_h_intern(&lf[404],12,"unsigned-int");
lf[405]=C_h_intern(&lf[405],5,"short");
lf[406]=C_h_intern(&lf[406],14,"unsigned-short");
lf[407]=C_h_intern(&lf[407],4,"byte");
lf[408]=C_h_intern(&lf[408],13,"unsigned-byte");
lf[409]=C_h_intern(&lf[409],5,"int32");
lf[410]=C_h_intern(&lf[410],14,"unsigned-int32");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[412]=C_h_intern(&lf[412],36,"\010compilerforeign-type-convert-result");
lf[413]=C_h_intern(&lf[413],38,"\010compilerforeign-type-convert-argument");
lf[414]=C_h_intern(&lf[414],27,"\010compilerfinal-foreign-type");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[416]=C_h_intern(&lf[416],37,"\010compilerestimate-foreign-result-size");
lf[417]=C_h_intern(&lf[417],9,"integer64");
lf[418]=C_h_intern(&lf[418],4,"bool");
lf[419]=C_h_intern(&lf[419],4,"void");
lf[420]=C_h_intern(&lf[420],13,"scheme-object");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[422]=C_h_intern(&lf[422],46,"\010compilerestimate-foreign-result-location-size");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[425]=C_h_intern(&lf[425],30,"\010compilerfinish-foreign-result");
lf[426]=C_h_intern(&lf[426],17,"\003syspeek-c-string");
lf[427]=C_h_intern(&lf[427],25,"\003syspeek-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],26,"\003syspeek-and-free-c-string");
lf[429]=C_h_intern(&lf[429],34,"\003syspeek-and-free-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],17,"\003sysintern-symbol");
lf[431]=C_h_intern(&lf[431],22,"\003syspeek-c-string-list");
lf[432]=C_h_intern(&lf[432],31,"\003syspeek-and-free-c-string-list");
lf[433]=C_h_intern(&lf[433],35,"\010tinyclosmake-instance-from-pointer");
lf[434]=C_h_intern(&lf[434],4,"make");
lf[435]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[436]=C_h_intern(&lf[436],28,"\010compilerscan-used-variables");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-free-variables");
lf[438]=C_h_intern(&lf[438],11,"lset-adjoin");
lf[439]=C_h_intern(&lf[439],25,"\010compilertopological-sort");
lf[440]=C_h_intern(&lf[440],7,"colored");
lf[441]=C_h_intern(&lf[441],23,"\010compilerchop-separator");
lf[442]=C_h_intern(&lf[442],9,"substring");
lf[443]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[444]=C_h_intern(&lf[444],23,"\010compilerchop-extension");
lf[445]=C_h_intern(&lf[445],22,"\010compilerprint-version");
lf[446]=C_h_intern(&lf[446],6,"print*");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[448]=C_h_intern(&lf[448],20,"\010compilerprint-usage");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\025>Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012\012  Syntax related options:\012\012  "
"  -case-insensitive            don\047t preserve case of read symbols\012    -keyword-"
"style STYLE         allow alternative keyword syntax\012                           "
"       (prefix, suffix or none)\012    -no-parentheses-synonyms     disables list d"
"elimiter synonyms\012    -no-symbol-escape            disables support for escaped "
"symbols\012    -r5rs-syntax                 disables the Chicken extensions to\012    "
"                              R5RS syntax\012    -compile-syntax              macro"
"s are made available at run-time\012    -emit-import-library MODULE  write compile-"
"time module information into\012                                  separate file\012\012  "
"Translation options:\012\012    -explicit-use                do not use units \047library"
"\047 and \047eval\047 by\012                                  default\012    -check-syntax     "
"           stop compilation after macro-expansion\012    -analyze-only             "
"   stop compilation after first analysis pass\012\012  Debugging options:\012\012    -no-war"
"nings                 disable warnings\012    -disable-warning CLASS       disable "
"specific class of warnings\012    -debug-level NUMBER          set level of availab"
"le debugging information\012    -no-trace                    disable tracing inform"
"ation\012    -profile                     executable emits profiling information \012 "
"   -profile-name FILENAME       name of the generated profile information file\012 "
"   -accumulate-profile          executable emits profiling information in\012      "
"                            append mode\012    -no-lambda-info              omit ad"
"ditional procedure-information\012\012  Optimization options:\012\012    -optimize-level NUM"
"BER       enable certain sets of optimization options\012    -optimize-leaf-routine"
"s      enable leaf routine optimization\012    -lambda-lift                 enable "
"lambda-lifting\012    -no-usual-integrations       standard procedures may be redef"
"ined\012    -unsafe                      disable safety checks\012    -local          "
"             assume globals are only modified in current\012                       "
"           file\012    -block                       enable block-compilation\012    -d"
"isable-interrupts          disable interrupts in compiled code\012    -fixnum-arith"
"metic           assume all numbers are fixnums\012    -benchmark-mode              "
"equivalent to \047block -optimize-level 4\012                                  -debug-"
"level 0 -fixnum-arithmetic -lambda-lift\012                                  -inlin"
"e -disable-interrupts\047\012    -disable-stack-overflow-checks  disables detection of"
" stack-overflows\012    -inline                      enable inlining\012    -inline-li"
"mit                set inlining threshold\012    -inline-global               enabl"
"e cross-module inlining\012    -emit-inline-file FILENAME   generate file with glob"
"ally inlinable\012                                  procedures (implies -inline -lo"
"cal)\012\012  Configuration options:\012\012    -unit NAME                   compile file as"
" a library unit\012    -uses NAME                   declare library unit as used.\012 "
"   -heap-size NUMBER            specifies heap-size of compiled executable\012    -"
"heap-initial-size NUMBER    specifies heap-size at startup time\012    -heap-growth"
" PERCENTAGE      specifies growth-rate of expanding heap\012    -heap-shrinkage PER"
"CENTAGE   specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-"
"size NUMBER\012                                 specifies nursery size of compiled "
"executable\012    -extend FILENAME             load file before compilation commenc"
"es\012    -prelude EXPRESSION          add expression to front of source file\012    -"
"postlude EXPRESSION         add expression to end of source file\012    -prologue F"
"ILENAME           include file before main source file\012    -epilogue FILENAME   "
"        include file after main source file\012    -dynamic                     com"
"pile as dynamically loadable code\012    -require-extension NAME      require and i"
"mport extension NAME\012    -static-extension NAME       import extension NAME but "
"link statically\012                                  (if available)\012\012  Obscure opti"
"ons:\012\012    -debug MODES                 display debugging output for the given mo"
"des\012    -unsafe-libraries            marks the generated file as being linked wi"
"th\012                                  the unsafe runtime system\012    -raw         "
"                do not generate implicit init- and exit code                    "
"       \012    -emit-external-prototypes-first\012                                 emi"
"t protoypes for callbacks before foreign\012                                  decla"
"rations\012    -ignore-repository           do not refer to repository for extensio"
"ns\012");
lf[450]=C_h_intern(&lf[450],36,"\010compilermake-block-variable-literal");
lf[451]=C_h_intern(&lf[451],22,"block-variable-literal");
lf[452]=C_h_intern(&lf[452],32,"\010compilerblock-variable-literal\077");
lf[453]=C_h_intern(&lf[453],36,"\010compilerblock-variable-literal-name");
lf[454]=C_h_intern(&lf[454],25,"\010compilermake-random-name");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[456]=C_h_intern(&lf[456],6,"random");
lf[457]=C_h_intern(&lf[457],15,"current-seconds");
lf[458]=C_h_intern(&lf[458],23,"\010compilerset-real-name!");
lf[459]=C_h_intern(&lf[459],24,"\010compilerreal-name-table");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[461]=C_h_intern(&lf[461],19,"\010compilerreal-name2");
lf[462]=C_h_intern(&lf[462],32,"\010compilerdisplay-real-name-table");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[464]=C_h_intern(&lf[464],28,"\010compilersource-info->string");
lf[465]=C_h_intern(&lf[465],4,"conc");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[468]=C_h_intern(&lf[468],11,"make-string");
lf[469]=C_h_intern(&lf[469],3,"max");
lf[470]=C_h_intern(&lf[470],12,"string-null\077");
lf[471]=C_h_intern(&lf[471],19,"\010compilerdump-nodes");
lf[472]=C_h_intern(&lf[472],19,"\003syswrite-char/port");
lf[473]=C_h_intern(&lf[473],19,"\003sysstandard-output");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[477]=C_h_intern(&lf[477],18,"\003sysuser-read-hook");
lf[478]=C_h_intern(&lf[478],15,"foreign-declare");
lf[479]=C_h_intern(&lf[479],7,"declare");
lf[480]=C_h_intern(&lf[480],34,"\010compilerscan-sharp-greater-string");
lf[481]=C_h_intern(&lf[481],18,"\003sysread-char/port");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[483]=C_h_intern(&lf[483],17,"get-output-string");
lf[484]=C_h_intern(&lf[484],18,"open-output-string");
lf[485]=C_h_intern(&lf[485],19,"\010compilervisibility");
lf[486]=C_h_intern(&lf[486],6,"hidden");
lf[487]=C_h_intern(&lf[487],24,"\010compilerexport-variable");
lf[488]=C_h_intern(&lf[488],8,"exported");
lf[489]=C_h_intern(&lf[489],26,"\010compilerblock-compilation");
lf[490]=C_h_intern(&lf[490],22,"\010compilermark-variable");
lf[491]=C_h_intern(&lf[491],22,"\010compilervariable-mark");
lf[492]=C_h_intern(&lf[492],19,"\010compilerintrinsic\077");
lf[493]=C_h_intern(&lf[493],9,"foldable\077");
lf[494]=C_h_intern(&lf[494],35,"\010compilercompiler-macro-environment");
lf[495]=C_h_intern(&lf[495],7,"cdb-get");
lf[496]=C_h_intern(&lf[496],8,"cdb-put!");
lf[497]=C_h_intern(&lf[497],16,"\003sysmacro-subset");
lf[498]=C_h_intern(&lf[498],28,"\003sysextend-macro-environment");
lf[499]=C_h_intern(&lf[499],19,"define-rewrite-rule");
lf[500]=C_h_intern(&lf[500],24,"\004coredefine-rewrite-rule");
lf[501]=C_h_intern(&lf[501],5,"cdadr");
lf[502]=C_h_intern(&lf[502],5,"caadr");
lf[503]=C_h_intern(&lf[503],16,"\003syscheck-syntax");
lf[504]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[505]=C_h_intern(&lf[505],18,"\003syser-transformer");
lf[506]=C_h_intern(&lf[506],21,"\003sysmacro-environment");
lf[507]=C_h_intern(&lf[507],27,"condition-property-accessor");
lf[508]=C_h_intern(&lf[508],3,"exn");
lf[509]=C_h_intern(&lf[509],7,"message");
lf[510]=C_h_intern(&lf[510],19,"condition-predicate");
C_register_lf2(lf,511,create_ptable());
t2=C_mutate(&lf[0] /* (set! c666 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3868 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3871 in k3868 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3874 in k3871 in k3868 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3889,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3894,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3921,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[20]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3961,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3990,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[28]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4009,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[35]+1 /* (set! syntax-error ...) */,C_retrieve(lf[28]));
t11=C_mutate((C_word*)lf[36]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4054,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[37]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4057,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[38]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4100,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[41]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4168,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[42]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4204,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[46]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4225,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[49]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4250,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[50]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[51]));
t19=C_mutate((C_word*)lf[52]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4294,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[61]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4388,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[64]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4444,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[65]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4451,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[66]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4458,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[73]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4505,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[76]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4517,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[78]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4580,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[79]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4611,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[82]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4631,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[84]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4677,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[85]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4707,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[87]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4753,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[90]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4813,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 293  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[510]))(3,*((C_word*)lf[510]+1),t33,lf[508]);}

/* k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 294  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[507]))(4,*((C_word*)lf[507]+1),t2,lf[508],lf[509]);}

/* k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word ab[172],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=C_mutate((C_word*)lf[97]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[109]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[110]));
t4=C_mutate((C_word*)lf[111]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5021,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[112]+1 /* (set! llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5024,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[113]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5027,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[123]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[135]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5319,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[137]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5337,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[139]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5355,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[141]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5401,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[142]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5453,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[143]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5510,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[145]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5520,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[146]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5556,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[148]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5580,tmp=(C_word)a,a+=2,tmp));
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_mutate((C_word*)lf[153]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5599,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6077,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[206]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6083,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[207]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6089,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[209]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6098,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[210]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6107,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[211]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6116,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[212]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6125,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[213]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6134,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6143,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[214]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6149,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[216]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6164,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[217]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6179,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[253]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6788,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[267]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7121,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[269]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7175,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[274]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7288,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[278]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7509,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[280]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7543,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[281]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7620,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[282]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7671,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[283]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7704,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[301]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7906,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[303]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7975,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[306]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8195,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[310]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8296,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[311]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8418,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[312]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8449,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[315]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8470,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[318]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8556,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[327]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8595,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[333]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8631,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[412]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9678,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[413]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9709,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[414]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9740,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[416]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9780,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[422]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10099,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[425]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10409,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[436]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10701,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[437]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10794,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[439]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10981,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[441]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11178,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[444]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11207,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[445]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11249,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[448]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11287,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[450]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11299,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[452]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11305,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[453]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11311,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[454]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11320,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[458]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11364,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[40]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11370,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[461]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11449,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[462]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11461,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[464]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11473,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[470]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11519,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[471]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11525,tmp=(C_word)a,a+=2,tmp));
t77=C_retrieve(lf[477]);
t78=C_mutate((C_word*)lf[477]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11627,a[2]=t77,tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[480]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11660,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[86]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11729,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[313]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11753,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[487]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11786,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[295]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11819,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[490]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11840,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[491]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11868,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[492]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11874,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[493]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11885,tmp=(C_word)a,a+=2,tmp));
t88=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1509 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[506]))(2,*((C_word*)lf[506]+1),t88);}

/* k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11901,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11912,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1513 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[505]))(3,*((C_word*)lf[505]+1),t3,t4);}

/* a11911 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11912,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11916,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1515 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[503]))(5,*((C_word*)lf[503]+1),t5,lf[499],t2,lf[504]);}

/* k11914 in a11911 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1517 caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[502]+1)))(3,*((C_word*)lf[502]+1),t2,((C_word*)t0)[3]);}

/* k11925 in k11914 in a11911 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1517 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[118]);}

/* k11937 in k11925 in k11914 in a11911 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1517 cdadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[501]+1)))(3,*((C_word*)lf[501]+1),t2,((C_word*)t0)[2]);}

/* k11945 in k11937 in k11925 in k11914 in a11911 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11949 in k11945 in k11937 in k11925 in k11914 in a11911 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11951,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[500],t5));}

/* k11908 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1510 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[498]))(5,*((C_word*)lf[498]+1),((C_word*)t0)[2],lf[499],C_SCHEME_END_OF_LIST,t1);}

/* k11899 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11904,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1518 ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[497]))(3,*((C_word*)lf[497]+1),t2,((C_word*)t0)[2]);}

/* k11902 in k11899 in k11896 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate((C_word*)lf[494]+1 /* (set! compiler-macro-environment ...) */,t1);
t3=C_mutate((C_word*)lf[495]+1 /* (set! cdb-get ...) */,C_retrieve(lf[135]));
t4=C_mutate((C_word*)lf[496]+1 /* (set! cdb-put! ...) */,C_retrieve(lf[139]));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* foldable? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11885,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11890,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[132]);}

/* f_11890 in foldable? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11890,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#intrinsic? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11874,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11879,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[126]);}

/* f_11879 in ##compiler#intrinsic? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11879,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#variable-mark in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11868,4,t0,t1,t2,t3);}
/* support.scm: 1500 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11840r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11840r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11844,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11844(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11844(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11842 in ##compiler#mark-variable in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1497 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11819,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11823,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1490 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t3,t2,lf[485]);}

/* k11821 in ##compiler#variable-visible? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[486]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[488]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[489]))));}}

/* ##compiler#export-variable in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11786,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11791,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[485],lf[488]);}

/* f_11791 in ##compiler#export-variable in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11791r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11791r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11791r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11795,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11795(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11795(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11793 */
static void C_ccall f_11795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#hide-variable in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11753,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11758,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[485],lf[486]);}

/* f_11758 in ##compiler#hide-variable in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11758r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11758r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11758r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11762,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11762(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11762(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11760 */
static void C_ccall f_11762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#big-fixnum? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11729,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11660,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11664,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1452 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[484]))(2,*((C_word*)lf[484]+1),t3);}

/* k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11664,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11669,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11669(t5,((C_word*)t0)[2]);}

/* loop in k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11669,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11671 in loop in k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11673,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1455 quit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[5],lf[482]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11691,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1457 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11703,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11724,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11722 in k11671 in loop in k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1469 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11669(t2,((C_word*)t0)[2]);}

/* k11701 in k11671 in loop in k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11703,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1462 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[483]))(3,*((C_word*)lf[483]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11715,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11713 in k11701 in k11671 in loop in k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11718,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11716 in k11713 in k11701 in k11671 in loop in k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1466 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11669(t2,((C_word*)t0)[2]);}

/* k11689 in k11671 in loop in k11662 in ##compiler#scan-sharp-greater-string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1458 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11669(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11627,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11637,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1449 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k11635 in ##sys#user-read-hook in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11640,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1447 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[480]))(3,*((C_word*)lf[480]+1),t2,((C_word*)t0)[2]);}

/* k11638 in k11635 in ##sys#user-read-hook in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11640,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[478],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[479],t4));}

/* ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11525,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11529,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11534,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11534(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11534(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11534,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11538,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11621,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_11621 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11621,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11541,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11616,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_11616 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11616,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11544,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11611,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11611 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11611,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1425 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[468]+1)))(4,*((C_word*)lf[468]+1),t2,((C_word*)t0)[7],C_make_character(32));}

/* k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11547,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11553,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1427 printf */
((C_proc6)C_retrieve_symbol_proc(lf[13]))(6,*((C_word*)lf[13]+1),t3,lf[476],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11605 in k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11606,3,t0,t1,t2);}
/* loop3516 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11534(t3,t1,((C_word*)t0)[2],t2);}

/* k11554 in k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11556,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11562,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11571,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1431 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t4,lf[475],t5);}
else{
t4=t3;
f_11562(2,t4,C_SCHEME_UNDEFINED);}}

/* k11569 in k11554 in k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11574,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11579,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11579(t6,t2,C_fix(5));}

/* doloop3546 in k11569 in k11554 in k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11579,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11589,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1434 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,lf[474],t4);}}

/* k11587 in doloop3546 in k11569 in k11554 in k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11579(t3,((C_word*)t0)[2],t2);}

/* k11572 in k11569 in k11554 in k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[473]+1));}

/* k11560 in k11554 in k11551 in k11545 in k11542 in k11539 in k11536 in loop in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[473]+1));}

/* k11527 in ##compiler#dump-nodes in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1437 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* string-null? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11519,3,t0,t1,t2);}
/* support.scm: 1415 string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[470]))(3,*((C_word*)lf[470]+1),t1,t2);}

/* ##compiler#source-info->string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11473,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11492,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1408 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1410 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11490 in ##compiler#source-info->string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11499,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11503,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1409 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[469]+1)))(4,*((C_word*)lf[469]+1),t3,C_fix(0),t5);}

/* k11501 in k11490 in ##compiler#source-info->string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1409 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[468]+1)))(4,*((C_word*)lf[468]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k11497 in k11490 in ##compiler#source-info->string in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1409 conc */
((C_proc8)C_retrieve_symbol_proc(lf[465]))(8,*((C_word*)lf[465]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[466],((C_word*)t0)[3],t1,lf[467],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11467,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1398 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t2,C_retrieve(lf[459]));}

/* a11466 in ##compiler#display-real-name-table in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11467,4,t0,t1,t2,t3);}
/* support.scm: 1400 printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t1,lf[463],t2,t3);}

/* ##compiler#real-name2 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11449,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11453,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1394 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[459]),t2);}

/* k11451 in ##compiler#real-name2 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1395 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11370(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11370r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11370r(t0,t1,t2,t3);}}

static void C_ccall f_11370r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11373,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11389,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1378 resolve */
f_11373(t5,t2);}

/* k11387 in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11389,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1382 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t4,t1);}
else{
/* support.scm: 1391 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1379 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11412 in k11387 in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11418,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1383 get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[147]);}

/* k11416 in k11412 in k11387 in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11418,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11420,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11420(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11416 in k11412 in k11387 in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11420(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11420,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1385 resolve */
f_11373(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11425 in loop in k11416 in k11412 in k11387 in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11427,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11440,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1388 sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),t3,lf[460],((C_word*)t0)[4],t1);}}

/* k11438 in k11425 in loop in k11416 in k11412 in k11387 in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11444,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1389 get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[147]);}

/* k11442 in k11438 in k11425 in loop in k11416 in k11412 in k11387 in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1388 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11420(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11373(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11373,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11377,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1373 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t3,C_retrieve(lf[459]),t2);}

/* k11375 in resolve in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11377,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11383,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1375 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,C_retrieve(lf[459]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11381 in k11375 in resolve in ##compiler#real-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11364,4,t0,t1,t2,t3);}
/* support.scm: 1369 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),t1,C_retrieve(lf[459]),t2,t3);}

/* ##compiler#make-random-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11320(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_11320r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11320r(t0,t1,t2);}}

static void C_ccall f_11320r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11328,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11332,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1356 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11332(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k11330 in ##compiler#make-random-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11336,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1357 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[457]))(2,*((C_word*)lf[457]+1),t2);}

/* k11334 in k11330 in ##compiler#make-random-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11340,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1358 random */
((C_proc3)C_retrieve_symbol_proc(lf[456]))(3,*((C_word*)lf[456]+1),t2,C_fix(1000));}

/* k11338 in k11334 in k11330 in ##compiler#make-random-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1355 sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[44]))(6,*((C_word*)lf[44]+1),((C_word*)t0)[4],lf[455],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11326 in ##compiler#make-random-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1354 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11311,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[451]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11305,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[451]));}

/* ##compiler#make-block-variable-literal in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11299,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[451],t2));}

/* ##compiler#print-usage in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11291,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1227 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[445]))(2,*((C_word*)lf[445]+1),t2);}

/* k11289 in ##compiler#print-usage in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1228 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k11292 in k11289 in ##compiler#print-usage in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1229 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[449]);}

/* ##compiler#print-version in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_11249r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11249r(t0,t1,t2);}}

static void C_ccall f_11249r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11253,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_11253(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_11253(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k11251 in ##compiler#print-version in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1223 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[446]+1)))(3,*((C_word*)lf[446]+1),t2,lf[447]);}
else{
t3=t2;
f_11256(2,t3,C_SCHEME_UNDEFINED);}}

/* k11254 in k11251 in ##compiler#print-version in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1224 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),t2,C_SCHEME_TRUE);}

/* k11261 in k11254 in k11251 in ##compiler#print-version in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1224 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[284]+1)))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11207,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11216,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11216(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11216,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1216 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[442]+1)))(5,*((C_word*)lf[442]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1217 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11178,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11188,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_11188(t7,(C_word)C_i_memq(t6,lf[443]));}
else{
t6=t5;
f_11188(t6,C_SCHEME_FALSE);}}

/* k11186 in ##compiler#chop-separator in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1209 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[442]+1)))(5,*((C_word*)lf[442]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10981,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10990,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11037,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11072,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11109,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11160,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a11159 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11160,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1191 insert */
t5=((C_word*)t0)[2];
f_10990(t5,t1,t3,t4);}

/* k11107 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11154,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1194 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t3,((C_word*)t0)[2]);}

/* k11152 in k11107 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11158,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1194 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2]);}

/* k11156 in k11152 in k11107 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1194 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11072(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11110 in k11107 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11115,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a11116 in k11110 in k11107 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11117,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11121,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1196 lookup */
t5=((C_word*)t0)[2];
f_11037(t5,t3,t4);}

/* k11119 in a11116 in k11110 in k11107 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[440]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1198 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11072(t5,((C_word*)t0)[4],t3,t4);}}

/* k11113 in k11110 in k11107 in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11072(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11072,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11076,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1179 insert */
t5=((C_word*)t0)[2];
f_10990(t5,t4,t2,lf[440]);}

/* k11074 in visit in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11079,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11084 in k11074 in visit in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11085,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11089,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1182 lookup */
t4=((C_word*)t0)[2];
f_11037(t4,t3,t2);}

/* k11087 in a11084 in k11074 in visit in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[440]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1184 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11072(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k11077 in k11074 in visit in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11079,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11037,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11043,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11043(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_11043(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11043,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11056,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11070,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1174 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t4,t2);}}

/* k11068 in loop in lookup in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1174 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11054 in loop in lookup in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1174 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1175 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11043(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10990(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10990,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10996,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10996(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10996,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11035,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1168 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t4,t2);}}

/* k11033 in loop in insert in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1168 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11015 in loop in insert in ##compiler#topological-sort in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_11017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1169 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10996(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10794,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10797,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10963,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10976,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1151 walk */
t14=((C_word*)t8)[1];
f_10797(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10974 in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1152 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10963,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10969,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10968 in walkeach in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10969,3,t0,t1,t2);}
/* support.scm: 1149 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10797(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10797(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10797,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10801,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10957,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10957 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10957,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10952,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10952 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10952,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10947,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10947 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10947,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10807,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[83]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_10816(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[221]);
if(C_truep(t4)){
t5=t3;
f_10816(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[229]);
if(C_truep(t5)){
t6=t3;
f_10816(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[232]);
t7=t3;
f_10816(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[246])));}}}}

/* k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10816(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10816,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[215]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10835,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1131 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[438]))(5,*((C_word*)lf[438]+1),t4,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[233]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10857,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10857(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10871,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1136 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[438]))(5,*((C_word*)lf[438]+1),t6,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[93]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10880,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1139 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10797(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[228]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10910,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1142 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1146 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10963(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10909 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10910,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10922,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1145 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t6,t2,((C_word*)t0)[2]);}

/* k10920 in a10909 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1145 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10797(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10878 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10880,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10891,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1140 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10889 in k10878 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1140 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10797(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10869 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10857(t3,t2);}

/* k10855 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10857(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1137 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10797(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10833 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10835,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1132 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t3,((C_word*)t0)[2]);}

/* k10839 in k10833 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10841,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10845,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1133 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[438]))(5,*((C_word*)lf[438]+1),t2,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10843 in k10839 in k10833 in k10814 in k10805 in k10802 in k10799 in walk in ##compiler#scan-free-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10701,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10705,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10707,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10707(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10707,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10711,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10788,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10788 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10788,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10783,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10783 in k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10783,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10712 in k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10714,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[215]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[233]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10754,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_eqp(t1,lf[83]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10767,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_10767(t6,t4);}
else{
t6=(C_word)C_eqp(t1,lf[221]);
t7=t5;
f_10767(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[229])));}}}

/* k10765 in k10712 in k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* f_10754 in k10712 in k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10754,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10751 in k10712 in k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10753,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10729,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10735,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_10735(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_10735(t5,C_SCHEME_FALSE);}}

/* k10733 in k10751 in k10712 in k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10735,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10729(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10729(t2,C_SCHEME_UNDEFINED);}}

/* k10727 in k10751 in k10712 in k10709 in walk in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10703 in ##compiler#scan-used-variables in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10409,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[426],t9));}
else{
t6=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[427],t10));}
else{
t7=(C_word)C_eqp(t4,lf[374]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[83],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[428],t12));}
else{
t9=(C_word)C_eqp(t4,lf[372]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[83],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[429],t14));}
else{
t11=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[83],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[426],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[430],t17));}
else{
t12=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[83],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[431],t16));}
else{
t13=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[83],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[432],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10605,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_10605(t18,(C_word)C_i_memq(t17,lf[435]));}
else{
t17=t14;
f_10605(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_10605(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k10603 in ##compiler#finish-foreign-result in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10605,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[433],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_10626(t6,(C_word)C_eqp(lf[367],t5));}
else{
t5=t2;
f_10626(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10626(t3,C_SCHEME_FALSE);}}}

/* k10624 in k10603 in ##compiler#finish-foreign-result in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10626,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[434],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10099,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10102,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10111,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10403,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1055 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t4,t5);}

/* a10402 in ##compiler#estimate-foreign-result-location-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10403,2,t0,t1);}
/* support.scm: 1076 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[424],((C_word*)t0)[2]);}

/* a10110 in ##compiler#estimate-foreign-result-location-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10111,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10121,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_10121(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_10121(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_10121(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_10121(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t10)){
t11=t6;
f_10121(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t11)){
t12=t6;
f_10121(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t12)){
t13=t6;
f_10121(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t13)){
t14=t6;
f_10121(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t14)){
t15=t6;
f_10121(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_10121(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_10121(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t17)){
t18=t6;
f_10121(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t18)){
t19=t6;
f_10121(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t19)){
t20=t6;
f_10121(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t20)){
t21=t6;
f_10121(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t21)){
t22=t6;
f_10121(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t22)){
t23=t6;
f_10121(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t23)){
t24=t6;
f_10121(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_10121(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[401]);
if(C_truep(t25)){
t26=t6;
f_10121(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[396]);
if(C_truep(t26)){
t27=t6;
f_10121(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t27)){
t28=t6;
f_10121(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t28)){
t29=t6;
f_10121(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t29)){
t30=t6;
f_10121(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t30)){
t31=t6;
f_10121(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t31)){
t32=t6;
f_10121(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t32)){
t33=t6;
f_10121(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t33)){
t34=t6;
f_10121(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t34)){
t35=t6;
f_10121(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t35)){
t36=t6;
f_10121(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[376]);
t37=t6;
f_10121(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[377])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k10119 in a10110 in ##compiler#estimate-foreign-result-location-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10121,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[403]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub338(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1068 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t5=t4;
f_10139(2,t5,C_SCHEME_FALSE);}}}}

/* k10137 in k10119 in a10110 in ##compiler#estimate-foreign-result-location-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10139,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1070 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_10173(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_10173(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_10173(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_10173(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
t9=t4;
f_10173(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[370])));}}}}}
else{
/* support.scm: 1075 err */
f_10102(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k10171 in k10137 in k10119 in a10110 in ##compiler#estimate-foreign-result-location-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1074 err */
f_10102(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_10102(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10102,NULL,2,t1,t2);}
/* support.scm: 1054 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[423],t2);}

/* ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9780,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9786,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10093,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1025 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t3,t4);}

/* a10092 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_10093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10093,2,t0,t1);}
/* support.scm: 1050 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[421],((C_word*)t0)[2]);}

/* a9785 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9786,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9796,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9796(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9796(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_9796(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_9796(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t10)){
t11=t6;
f_9796(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t11)){
t12=t6;
f_9796(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t12)){
t13=t6;
f_9796(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t13)){
t14=t6;
f_9796(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t14)){
t15=t6;
f_9796(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_9796(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_9796(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[409]);
t18=t6;
f_9796(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[410])));}}}}}}}}}}}}

/* k9794 in a9785 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9796,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9805(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=t3;
f_9805(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t5)){
t6=t3;
f_9805(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_9805(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t7)){
t8=t3;
f_9805(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t8)){
t9=t3;
f_9805(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t9)){
t10=t3;
f_9805(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t10)){
t11=t3;
f_9805(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t11)){
t12=t3;
f_9805(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
t13=t3;
f_9805(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[377])));}}}}}}}}}}}

/* k9803 in k9794 in a9785 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9805,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9817(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_9817(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t5)){
t6=t3;
f_9817(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t6)){
t7=t3;
f_9817(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t8=t3;
f_9817(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}

/* k9815 in k9803 in k9794 in a9785 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[340]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9829(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[402]);
if(C_truep(t4)){
t5=t3;
f_9829(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
t6=t3;
f_9829(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[417])));}}}}

/* k9827 in k9815 in k9803 in k9794 in a9785 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9829,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1041 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9835(2,t3,C_SCHEME_FALSE);}}}

/* k9833 in k9827 in k9815 in k9803 in k9794 in a9785 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9835,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1043 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9869,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9869(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9869(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_9869(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_9869(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t8)){
t9=t4;
f_9869(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[370]);
if(C_truep(t9)){
t10=t4;
f_9869(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[363]);
if(C_truep(t10)){
t11=t4;
f_9869(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[364]);
t12=t4;
f_9869(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[367])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9867 in k9833 in k9827 in k9815 in k9803 in k9794 in a9785 in ##compiler#estimate-foreign-result-size in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9740,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9746,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9774,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1012 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t3,t4);}

/* a9773 in ##compiler#final-foreign-type in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9774,2,t0,t1);}
/* support.scm: 1019 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[415],((C_word*)t0)[2]);}

/* a9745 in ##compiler#final-foreign-type in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9746,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9750,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1015 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[371]),t2);}
else{
t5=t4;
f_9750(2,t5,C_SCHEME_FALSE);}}

/* k9748 in a9745 in ##compiler#final-foreign-type in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1017 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9709,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9713,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9722,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1006 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_9713(t5,C_SCHEME_FALSE);}}

/* k9720 in ##compiler#foreign-type-convert-argument in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9722,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9713(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9713(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9713(t2,C_SCHEME_FALSE);}}

/* k9711 in ##compiler#foreign-type-convert-argument in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9682,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9691,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 999  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_9682(t5,C_SCHEME_FALSE);}}

/* k9689 in ##compiler#foreign-type-convert-result in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9691,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_9682(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9682(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9682(t2,C_SCHEME_FALSE);}}

/* k9680 in ##compiler#foreign-type-convert-result in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8631,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8637,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9672,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 900  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t3,t4,t5);}

/* a9671 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9672,2,t0,t1);}
/* support.scm: 992  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[411],((C_word*)t0)[2]);}

/* a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8637,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8643,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8643(t7,t1,t2);}

/* repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8643,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[334]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[335]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[336]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[337],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8672(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[404]);
if(C_truep(t8)){
t9=t7;
f_8672(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t9)){
t10=t7;
f_8672(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t10)){
t11=t7;
f_8672(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t11)){
t12=t7;
f_8672(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t12)){
t13=t7;
f_8672(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[409]);
t14=t7;
f_8672(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[410])));}}}}}}}}

/* k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8672,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[339],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8691(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t5=t3;
f_8691(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[403])));}}}

/* k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8691,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[341],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8710(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
if(C_truep(t4)){
t5=t3;
f_8710(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t6=t3;
f_8710(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[401])));}}}}

/* k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8710,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 910  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8780(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
if(C_truep(t4)){
t5=t3;
f_8780(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
t6=t3;
f_8780(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[398])));}}}}

/* k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8780,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[343],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8799(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t4)){
t5=t3;
f_8799(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t5)){
t6=t3;
f_8799(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t6)){
t7=t3;
f_8799(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t7)){
t8=t3;
f_8799(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t8)){
t9=t3;
f_8799(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
t10=t3;
f_8799(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[395])));}}}}}}}}

/* k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8799,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8802,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 922  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8881(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_8881(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t5)){
t6=t3;
f_8881(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t6)){
t7=t3;
f_8881(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t7)){
t8=t3;
f_8881(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t8)){
t9=t3;
f_8881(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
t10=t3;
f_8881(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[388])));}}}}}}}}

/* k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8881,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[348]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[346],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8920(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
t5=t3;
f_8920(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[381])));}}}

/* k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8920,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[350],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8939(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_8939(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8939(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8939,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[352],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8958(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_8958(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8958,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 942  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[354],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_9038(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t6=t4;
f_9038(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}}

/* k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9038,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9041,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 950  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9123(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t5=t3;
f_9123(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}

/* k9121 in k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9123(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9123,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[357],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[358],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[357],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[336]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[357],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[358],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[357],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 966  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t3,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t4=t3;
f_9198(2,t4,C_SCHEME_FALSE);}}}}

/* k9196 in k9121 in k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9198,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 968  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9232(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
t6=t4;
f_9232(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[370]);
t7=t4;
f_9232(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[353])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k9230 in k9196 in k9121 in k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9232,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9235,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 972  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[363]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[364]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9302,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 978  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[366],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 985  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8643(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[336]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[350],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[344]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[355]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[354],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9300 in k9230 in k9196 in k9121 in k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9302,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[366],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[83],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[220],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[93],t17));}

/* k9233 in k9230 in k9196 in k9121 in k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9235,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k9039 in k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9041,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9072,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_9072(t7,(C_word)C_a_i_cons(&a,2,lf[357],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[358],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_9072(t9,(C_word)C_a_i_cons(&a,2,lf[357],t8));}}

/* k9070 in k9039 in k9036 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_9072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9072,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k8959 in k8956 in k8937 in k8918 in k8879 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k8800 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8802,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8833,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8833(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8833(t10,(C_word)C_a_i_cons(&a,2,lf[346],t9));}}

/* k8831 in k8800 in k8797 in k8778 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8833,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k8711 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8744(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8744(t7,(C_word)C_a_i_cons(&a,2,lf[343],t6));}}

/* k8742 in k8711 in k8708 in k8689 in k8670 in repeat in a8636 in ##compiler#foreign-type-check in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8744,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* ##compiler#pprint-expressions-to-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8595,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8599,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 881  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[331]+1)))(3,*((C_word*)lf[331]+1),t4,t3);}
else{
/* support.scm: 881  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[332]+1)))(2,*((C_word*)lf[332]+1),t4);}}

/* k8597 in ##compiler#pprint-expressions-to-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8602,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 882  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),t2,t1,t3);}

/* a8609 in k8597 in ##compiler#pprint-expressions-to-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8616,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a8615 in a8609 in k8597 in ##compiler#pprint-expressions-to-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8616,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8620,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 886  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t3,t2);}

/* k8618 in a8615 in a8609 in k8597 in ##compiler#pprint-expressions-to-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 887  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k8600 in k8597 in ##compiler#pprint-expressions-to-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 889  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[328]+1)))(3,*((C_word*)lf[328]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8556,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8562,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8568,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a8567 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8568,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8575,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 869  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t9,lf[325],lf[326]);}

/* k8573 in a8567 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8575,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8578,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 870  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t2,lf[324],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8576 in k8573 in a8567 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 871  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[323],((C_word*)t0)[2]);}

/* k8579 in k8576 in k8573 in a8567 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 872  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[322],((C_word*)t0)[2]);}

/* k8582 in k8579 in k8576 in k8573 in a8567 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 873  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[321],((C_word*)t0)[2]);}

/* k8585 in k8582 in k8579 in k8576 in k8573 in a8567 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 874  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[320],((C_word*)t0)[2]);}

/* k8588 in k8585 in k8582 in k8579 in k8576 in k8573 in a8567 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 875  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[319],((C_word*)t0)[2]);}

/* a8561 in ##compiler#print-program-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8562,2,t0,t1);}
/* support.scm: 868  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8470,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8474,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8479,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 844  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t13,t14,t2);}

/* a8478 in ##compiler#compute-database-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8479,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a8484 in a8478 in ##compiler#compute-database-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8485,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[183]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[164]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8527,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cdr(t2);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8532,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t8=(C_word)C_eqp(t5,lf[171]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* f_8532 in a8484 in a8478 in ##compiler#compute-database-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8532,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8525 in a8484 in a8478 in ##compiler#compute-database-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[228],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8472 in ##compiler#compute-database-statistics in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 858  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[316]),C_retrieve(lf[317]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8449,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8459,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 821  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t7,lf[251],lf[314],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k8457 in ##sys#toplevel-definition-hook in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 822  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8418,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8424,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 807  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t3,t2);}

/* a8423 in ##compiler#dump-undefined-globals in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8424,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8431,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[183],t3))){
t5=(C_word)C_i_assq(lf[181],t3);
t6=t4;
f_8431(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8431(t5,C_SCHEME_FALSE);}}

/* k8429 in a8423 in ##compiler#dump-undefined-globals in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8431,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8434,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 811  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8432 in k8429 in a8423 in ##compiler#dump-undefined-globals in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 812  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8296,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8300,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8412,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8412 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8412,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8300,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
if(C_truep((C_word)C_i_cadr(t1))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8320,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8320(3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8320,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8324,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8401,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8401 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8401,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8324,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[240]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8378,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(t1,lf[231]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8396,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}}

/* f_8396 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8396,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8393 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 801  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* f_8378 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8378,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8331 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8333,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8372,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8373,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8373 in k8331 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8373,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8370 in k8331 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8372,2,t0,t1);}
t2=(C_word)C_eqp(lf[215],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8364,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8364 in k8370 in k8331 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8364,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8361 in k8370 in k8331 in k8322 in rec in k8298 in ##compiler#simple-lambda-node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 799  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8195,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8201,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8201(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8201,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8290,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8290 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8290,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8208,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8285,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_8285 in k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8285,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8206 in k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8208,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[215]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8217(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[83]);
if(C_truep(t4)){
t5=t3;
f_8217(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[221]);
if(C_truep(t5)){
t6=t3;
f_8217(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[232]);
t7=t3;
f_8217(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[219])));}}}}

/* k8215 in k8206 in k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8217,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8244,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[220]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[93]));
if(C_truep(t4)){
/* support.scm: 783  any */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* f_8244 in k8215 in k8206 in k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8244,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8241 in k8215 in k8206 in k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8243,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8231,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 782  find */
((C_proc4)C_retrieve_symbol_proc(lf[308]))(4,*((C_word*)lf[308]+1),((C_word*)t0)[2],t3,C_retrieve(lf[309]));}

/* a8230 in k8241 in k8215 in k8206 in k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8231,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8239,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 782  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t3,t2);}

/* k8237 in a8230 in k8241 in k8215 in k8206 in k8203 in walk in ##compiler#expression-has-side-effects? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7975,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7978,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8007,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8050,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8169,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 766  matchn */
t15=((C_word*)t12)[1];
f_8050(t15,t14,t2,t3);}

/* k8167 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8169,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8175,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8189,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8189 in k8167 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8189,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8177 in k8167 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8183,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8184,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8184 in k8177 in k8167 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8184,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8181 in k8177 in k8167 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 769  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[10]))(7,*((C_word*)lf[10]+1),((C_word*)t0)[4],lf[304],lf[305],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8173 in k8167 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8050(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8050,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 755  resolve */
t4=((C_word*)t0)[4];
f_7978(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8157,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8162,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* f_8162 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8162,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8157,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8144,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8149,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_8149 in k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8149,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8142 in k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* support.scm: 757  match1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8007(t3,((C_word*)t0)[2],t1,t2);}

/* k8070 in k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8072,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8136,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8136 in k8070 in k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8136,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8077 in k8070 in k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8079,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8085,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8085(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8077 in k8070 in k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8085(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8085,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 761  resolve */
t4=((C_word*)t0)[4];
f_7978(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8116,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 763  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8050(t7,t4,t5,t6);}}}}

/* k8114 in loop in k8077 in k8070 in k8155 in matchn in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 764  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8085(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_8007(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8007,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 748  resolve */
t4=((C_word*)t0)[3];
f_7978(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8029,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 750  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k8027 in match1 in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 750  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8007(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7978(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7978,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8002,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 743  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k8000 in resolve in ##compiler#match-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7906,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7912,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 723  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[302]))(4,*((C_word*)lf[302]+1),t1,t2,t3);}

/* a7911 in ##compiler#load-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7912,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7918,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7918(t5,t1);}

/* loop in a7911 in ##compiler#load-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7918,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 726  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t2);}

/* k7920 in loop in a7911 in ##compiler#load-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7922,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7942,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 731  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t4,t5);}}

/* k7940 in k7920 in loop in a7911 in ##compiler#load-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7943,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[294],t1);}

/* f_7943 in k7940 in k7920 in loop in a7911 in ##compiler#load-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_7943r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7943r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7943r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7947,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7947(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7947(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k7945 */
static void C_ccall f_7947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7929 in k7920 in loop in a7911 in ##compiler#load-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 732  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7918(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7704,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7708,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7735,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 692  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[300]))(4,*((C_word*)lf[300]+1),t6,t2,t7);}

/* a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7904,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 694  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[299]))(2,*((C_word*)lf[299]+1),t3);}

/* k7902 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 694  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[284]+1)))(7,*((C_word*)lf[284]+1),((C_word*)t0)[2],lf[296],t1,lf[297],C_retrieve(lf[242]),lf[298]);}

/* k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7742,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 696  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t2,t3,((C_word*)t0)[2]);}

/* a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7747,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 698  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t4,t2);}

/* k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7754,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[166],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7890,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7896,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],lf[294]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_7896 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7896,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* k7888 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7891,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_7891 in k7888 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7891,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[205]));}

/* k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7886,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[164],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7778(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[159],t5);
t7=t4;
f_7778(t7,(C_word)C_i_not(t6));}}}

/* k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7778,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[193],((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7867,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7867 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7867,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7796,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(t1);
/* support.scm: 706  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[2],t3,lf[192]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7794 in k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7796,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 707  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[200]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7856 in k7794 in k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7850,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[293]);}}

/* f_7850 in k7856 in k7794 in k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7850,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* k7806 in k7856 in k7794 in k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[290]);
if(C_truep(t3)){
t4=t2;
f_7811(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[291]);
if(C_truep(t4)){
t5=t2;
f_7811(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[292]);
t7=t2;
f_7811(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7809 in k7806 in k7856 in k7794 in k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7818,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7829,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 714  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7827 in k7809 in k7806 in k7856 in k7794 in k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7829,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 714  pp */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),((C_word*)t0)[2],t2);}

/* k7816 in k7809 in k7806 in k7856 in k7794 in k7785 in k7776 in k7884 in k7752 in a7746 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 715  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k7740 in k7737 in a7734 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 717  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[284]+1)))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],lf[288]);}

/* k7706 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 719  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t2,lf[286],lf[287]);}
else{
t3=t2;
f_7714(2,t3,C_SCHEME_FALSE);}}

/* k7712 in k7706 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7714,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7719,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7727,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 720  sort-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7725 in k7712 in k7706 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7718 in k7712 in k7706 in ##compiler#emit-global-inline-file in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7719,3,t0,t1,t2);}
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[284]+1)))(4,*((C_word*)lf[284]+1),t1,lf[285],t2);}

/* ##compiler#sexpr->node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7671,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7677,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7677(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7677,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7693,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k7691 in walk in ##compiler#sexpr->node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7694,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7694 in k7691 in walk in ##compiler#sexpr->node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7694,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7620,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7626,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7626(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7626,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7634,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7665,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7665 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7665,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7632 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7660,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7660 in k7632 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7660,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7640 in k7632 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7650,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7655,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_7655 in k7640 in k7632 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7655,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7652 in k7640 in k7632 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k7648 in k7640 in k7632 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7644 in k7640 in k7632 in walk in ##compiler#node->sexpr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7646,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7543,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7547,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7613,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7614,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_7614 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7614,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7611 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 671  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7604,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7605,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7605 in k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7605,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7602 in k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 672  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7548 in k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7595,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7596,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7596 in k7548 in k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7596,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7593 in k7548 in k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 673  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[212]))(4,*((C_word*)lf[212]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7551 in k7548 in k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7553,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7564(t4,C_fix(4)));}

/* doloop1633 in k7551 in k7548 in k7545 in ##compiler#copy-node! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static C_word C_fcall f_7564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7509,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7515,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7515(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7515,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 667  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7527 in rec in ##compiler#tree-copy in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7533,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 667  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7515(t4,t2,t3);}

/* k7531 in k7527 in rec in ##compiler#tree-copy in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7533,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7288,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7292,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 635  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[256]+1)))(5,*((C_word*)lf[256]+1),t5,*((C_word*)lf[279]+1),t3,t4);}

/* k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7294,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7300,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 662  walk */
t6=((C_word*)t4)[1];
f_7300(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7300(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7300,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7304,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7500,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7500 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7500,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7495,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7495 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7495,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7490,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7490 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7490,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7310,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[215]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7323,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 642  rename */
f_7294(t3,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(t1,lf[233]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 643  rename */
f_7294(t4,t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(t1,lf[93]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7375,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 646  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t6,t5);}
else{
t5=(C_word)C_eqp(t1,lf[228]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 650  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[7],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 661  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t6,((C_word*)t0)[6]);}}}}}

/* k7472 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7478,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7484 in k7472 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7485,3,t0,t1,t2);}
/* walk1511 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7300(t3,t1,t2,((C_word*)t0)[2]);}

/* k7476 in k7472 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7479,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7479 in k7476 in k7472 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7479,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7415,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[94]),t2);}

/* k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 654  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t2,t1,((C_word*)t0)[2]);}

/* k7420 in k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 657  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,lf[277]);}

/* k7446 in k7420 in k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7448,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7456,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 658  rename */
f_7294(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_7464(2,t5,C_SCHEME_FALSE);}}

/* k7462 in k7446 in k7420 in k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 658  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[49]))(5,*((C_word*)lf[49]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7454 in k7446 in k7420 in k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7456,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7433,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7439 in k7454 in k7446 in k7420 in k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7440,3,t0,t1,t2);}
/* walk1511 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7300(t3,t1,t2,((C_word*)t0)[2]);}

/* k7431 in k7454 in k7446 in k7420 in k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7434,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[228],((C_word*)t0)[2],t1);}

/* f_7434 in k7431 in k7454 in k7446 in k7420 in k7417 in a7414 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7434,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7373 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 647  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7376 in k7373 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7378,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7389,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7396,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7395 in k7376 in k7373 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7396,3,t0,t1,t2);}
/* walk1511 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7300(t3,t1,t2,((C_word*)t0)[2]);}

/* k7387 in k7376 in k7373 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7390,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],t1);}

/* f_7390 in k7387 in k7376 in k7373 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7390,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7357 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7359,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7344,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7350 in k7357 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7351,3,t0,t1,t2);}
/* walk1511 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7300(t3,t1,t2,((C_word*)t0)[2]);}

/* k7342 in k7357 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7345,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[233],((C_word*)t0)[2],t1);}

/* f_7345 in k7342 in k7357 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7345,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7321 in k7308 in k7305 in k7302 in walk in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 642  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),((C_word*)t0)[2],t1);}

/* rename in k7290 in ##compiler#copy-node-tree-and-rename in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7294(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7294,NULL,3,t1,t2,t3);}
/* support.scm: 636  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[275]))(6,*((C_word*)lf[275]+1),t1,t2,t3,*((C_word*)lf[276]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7175,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7181,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 613  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t1,t2,t6);}

/* a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7181,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7187,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7193,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7193,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[94]),((C_word*)t0)[2]);}
else{
t5=t4;
f_7197(2,t5,((C_word*)t0)[2]);}}

/* k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7200,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 619  copy-node-tree-and-rename */
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_7200(2,t3,((C_word*)t0)[3]);}}

/* k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7205,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7280,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 625  last */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7226(2,t4,t1);}}

/* k7278 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7250,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 627  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[273],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7264,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[238],t6,((C_word*)t0)[2]);}}

/* f_7264 in k7278 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7264,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7248 in k7278 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7250,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7242,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],t2);}

/* f_7242 in k7248 in k7278 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7242,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7224 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7230,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 631  take */
((C_proc4)C_retrieve_symbol_proc(lf[272]))(4,*((C_word*)lf[272]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7228 in k7224 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 621  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[271]))(6,*((C_word*)lf[271]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7204 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7205,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7218,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[93],t5,t6);}

/* f_7218 in a7204 in k7198 in k7195 in a7192 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7218,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* a7186 in a7180 in ##compiler#inline-lambda-bindings in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7187,2,t0,t1);}
/* support.scm: 616  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[270]))(4,*((C_word*)lf[270]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7121,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7127,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7127(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7127(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7127,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7153,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 609  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k7151 in fold in ##compiler#fold-boolean in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7157,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 610  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7127(t4,t2,t3);}

/* k7155 in k7151 in fold in ##compiler#fold-boolean in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7157,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7145,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[230],lf[268],t2);}

/* f_7145 in k7155 in k7151 in fold in ##compiler#fold-boolean in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7145,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6788,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6794,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6794(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6798,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7115,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7115 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7115,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7110,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7110 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7110,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6804,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7105,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7105 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7105,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6804,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[220]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6813(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[265]);
t5=t3;
f_6813(t5,(C_truep(t4)?t4:(C_word)C_eqp(t1,lf[266])));}}

/* k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_6813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6813,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6820,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[254]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6837,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6841,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[215]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[219]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[83]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[83],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[93]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6903,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 583  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[258]))(3,*((C_word*)lf[258]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[118]:lf[228]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6928,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 590  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6794(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[240]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[231]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6961,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[221]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6985,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6985(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_7047(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t14)){
t15=t13;
f_7047(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t16=t13;
f_7047(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[264])));}}}}}}}}}}}}}

/* k7045 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_7047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7047,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 600  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6794(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7073,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k7075 in k7045 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 601  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7071 in k7045 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7073,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7052 in k7045 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k7056 in k7052 in k7045 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 600  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[259]))(6,*((C_word*)lf[259]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_6985(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6985,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7003,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 597  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7034,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 598  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6794(3,t10,t8,t9);}}

/* k7032 in loop in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7034,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 598  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6985(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7001 in loop in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 597  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6794(3,t4,t2,t3);}

/* k7009 in k7001 in loop in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[260],t3));}

/* k6959 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[259]))(5,*((C_word*)lf[259]+1),((C_word*)t0)[3],lf[231],((C_word*)t0)[2],t1);}

/* k6926 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6928,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6905 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6901 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 583  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[256]+1)))(5,*((C_word*)lf[256]+1),((C_word*)t0)[3],*((C_word*)lf[257]+1),((C_word*)t0)[2],t1);}

/* k6885 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6899,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 584  last */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t3,((C_word*)t0)[2]);}

/* k6897 in k6885 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 584  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6794(3,t2,((C_word*)t0)[2],t1);}

/* k6893 in k6885 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* k6839 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6835 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6837,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[254],t2));}

/* k6818 in k6811 in k6802 in k6799 in k6796 in walk in ##compiler#build-expression-tree in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6820,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6179,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6182,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6783,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 567  walk */
t9=((C_word*)t6)[1];
f_6182(3,t9,t8,t2);}

/* k6781 in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6786,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 568  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,lf[251],lf[252],((C_word*)((C_word*)t0)[2])[1]);}

/* k6784 in k6781 in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word *a;
loop:
a=C_alloc(8);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_6182,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 501  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 502  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t1,lf[218],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[219]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6224,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[219],t7,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(t4,lf[220]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[221]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6252,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[83]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6280,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[225],C_retrieve(lf[226]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_6280(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_6280(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_6280(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[93]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 522  walk */
t65=t1;
t66=t11;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6334,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 523  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[227]))(3,*((C_word*)lf[227]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[118]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[228]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6398,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 527  walk */
t65=t14;
t66=t15;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[229]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6446(t17,(C_word)C_eqp(lf[83],t16));}
else{
t16=t15;
f_6446(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[230]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[231]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6483,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[232]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6510,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,lf[232],t17,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t4,lf[233]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[234]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6538,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6600,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 546  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[238]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6621,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6621(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[246]);
if(C_truep(t21)){
t22=t20;
f_6621(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[247]);
if(C_truep(t22)){
t23=t20;
f_6621(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[248]);
t24=t20;
f_6621(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[249])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6771,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6769 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6772,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[240],lf[250],t1);}

/* f_6772 in k6769 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6772,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_6621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6621,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6636,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[239]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6658,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6672,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6699,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6722,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6727,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[245]);}

/* f_6727 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6727,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* k6720 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6699(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6699(t2,C_SCHEME_FALSE);}}

/* k6697 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_6699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6699,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6703,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 562  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 564  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[2]);}}

/* k6704 in k6697 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6713(2,t3,t1);}
else{
/* support.scm: 563  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[2]);}}

/* k6711 in k6704 in k6697 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6713,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6703(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[242]),((C_word*)t0)[2],t1));}

/* k6701 in k6697 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6690,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6688 in k6701 in k6697 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6691,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[240],((C_word*)t0)[2],t1);}

/* f_6691 in k6688 in k6701 in k6697 in a6677 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6691,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* a6671 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6672,2,t0,t1);}
/* support.scm: 554  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t1,((C_word*)t0)[2]);}

/* k6656 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6659,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[240],lf[241],t1);}

/* f_6659 in k6656 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6659,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6634 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6637,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6637 in k6634 in k6619 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6637,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6598 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6600,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6580,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6584,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 547  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[236]))(3,*((C_word*)lf[236]+1),t5,((C_word*)t0)[2]);}

/* k6582 in k6598 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 547  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6182(3,t2,((C_word*)t0)[2],t1);}

/* k6578 in k6598 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6572,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[235],((C_word*)t0)[2],t2);}

/* f_6572 in k6578 in k6598 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6572,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6536 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6539,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[233],((C_word*)t0)[2],t1);}

/* f_6539 in k6536 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6539,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* f_6510 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6510,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6481 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6484,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6484 in k6481 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6484,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6444 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_6446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6446,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6430,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6428 in k6444 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6431,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6431 in k6428 in k6444 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6431,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6396 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6390,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[118],((C_word*)t0)[2],t2);}

/* f_6390 in k6396 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6390,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6332 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6338,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6356 in k6332 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6357,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 524  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6182(3,t4,t1,t3);}

/* k6345 in k6332 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6355,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 525  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6182(3,t3,t2,((C_word*)t0)[2]);}

/* k6353 in k6345 in k6332 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 524  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6336 in k6332 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6339,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],t1);}

/* f_6339 in k6336 in k6332 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6339,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6278 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_6280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6280,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 513  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,lf[223],lf[224],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6277(t2,((C_word*)t0)[2]);}}

/* k6281 in k6278 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 516  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[2]);}

/* k6288 in k6281 in k6278 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6277(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k6275 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_6277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 509  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1);}

/* k6250 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6253,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* f_6253 in k6250 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6253,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* f_6224 in walk in ##compiler#build-node-graph in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6224,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#qnode in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6164,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6173,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[83],t3,C_SCHEME_END_OF_LIST);}

/* f_6173 in ##compiler#qnode in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6173,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#varnode in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6149,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6158,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[215],t3,C_SCHEME_END_OF_LIST);}

/* f_6158 in ##compiler#varnode in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6158,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* make-node in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6143,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* node-subexpressions in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6134,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6125,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6116,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6107,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6098,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6089,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6083,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[205]));}

/* f_6077 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6077,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5599,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5603,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5603(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6075,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 432  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[55]+1)))(5,*((C_word*)lf[55]+1),t4,C_retrieve(lf[202]),C_retrieve(lf[203]),C_retrieve(lf[128]));}}

/* k6073 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_6075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5603(t3,t2);}

/* k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5603,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5608,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 435  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5608,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5618,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 443  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),t14,t2);}}

/* k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5766,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5766(t6,t2,((C_word*)t0)[2]);}

/* loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5766,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 447  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5779,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[160]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5792(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t5)){
t6=t4;
f_5792(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t6)){
t7=t4;
f_5792(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t7)){
t8=t4;
f_5792(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t8)){
t9=t4;
f_5792(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t9)){
t10=t4;
f_5792(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t10)){
t11=t4;
f_5792(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t11)){
t12=t4;
f_5792(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t12)){
t13=t4;
f_5792(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t13)){
t14=t4;
f_5792(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t14)){
t15=t4;
f_5792(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t15)){
t16=t4;
f_5792(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t16)){
t17=t4;
f_5792(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t17)){
t18=t4;
f_5792(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t18)){
t19=t4;
f_5792(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t19)){
t20=t4;
f_5792(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t20)){
t21=t4;
f_5792(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t21)){
t22=t4;
f_5792(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t22)){
t23=t4;
f_5792(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[199]);
t24=t4;
f_5792(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[200])));}}}}}}}}}}}}}}}}}}}}

/* k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5792,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 451  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[159]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[159]);
t4=((C_word*)t0)[9];
f_5779(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[164]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[159]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5779(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5830,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 455  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[166]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[159]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5779(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 457  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[167]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5856,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 459  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[168]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5865(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t8)){
t9=t7;
f_5865(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t9)){
t10=t7;
f_5865(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[147]);
if(C_truep(t10)){
t11=t7;
f_5865(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t11)){
t12=t7;
f_5865(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t12)){
t13=t7;
f_5865(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
if(C_truep(t13)){
t14=t7;
f_5865(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[178]);
if(C_truep(t14)){
t15=t7;
f_5865(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[179]);
t16=t7;
f_5865(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[180])));}}}}}}}}}}}}}}

/* k5863 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5865(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5865,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 462  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[170]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 464  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[171]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5896,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 466  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 467  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[6],lf[172],t4);}}}}

/* k5894 in k5863 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5779(2,t3,t2);}

/* k5884 in k5863 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5779(2,t3,t2);}

/* k5870 in k5863 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 462  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2]);}

/* k5874 in k5870 in k5863 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 462  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[169],((C_word*)t0)[2],t1);}

/* k5854 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5779(2,t3,t2);}

/* k5844 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5779(2,t3,t2);}

/* k5828 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5779(2,t3,t2);}

/* k5805 in k5790 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[161]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 451  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[162],t3);}

/* k5777 in k5774 in loop in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 468  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5766(t3,((C_word*)t0)[2],t2);}

/* k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[159]);
t5=t3;
f_5656(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5656(t4,C_SCHEME_FALSE);}}

/* k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5656,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5667,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5677,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5687,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[159]);
t4=t2;
f_5687(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5687(t3,C_SCHEME_FALSE);}}}

/* k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5687,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5708,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[159]);
t4=t2;
f_5718(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5718(t3,C_SCHEME_FALSE);}}}

/* k5716 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5718,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5739,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_5624(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5739 in k5716 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5739,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5727 in k5716 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5734,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5734 in k5727 in k5716 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5734,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5731 in k5727 in k5716 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 474  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[158],t2);}

/* f_5708 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5708,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5696 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5703,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5703 in k5696 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5703,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5700 in k5696 in k5685 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 472  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[157],t2);}

/* f_5677 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5677,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5665 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5672,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5672 in k5665 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5672,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5669 in k5665 in k5654 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 470  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[156],t2);}

/* k5622 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 475  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[155],t3);}
else{
t3=t2;
f_5627(2,t3,C_SCHEME_UNDEFINED);}}

/* k5625 in k5622 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 476  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[154],t3);}
else{
t3=t2;
f_5630(2,t3,C_SCHEME_UNDEFINED);}}

/* k5628 in k5625 in k5622 in k5619 in k5616 in a5607 in k5601 in ##compiler#display-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 477  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5586,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 414  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t2,C_retrieve(lf[144]));}

/* a5585 in ##compiler#display-line-number-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5586,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5597,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[151]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5595 in a5585 in ##compiler#display-line-number-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 416  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5556,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5562,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5562(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5562(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5562,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5572,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 410  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t4,((C_word*)t0)[2],t2,lf[147]);}}

/* k5570 in loop in ##compiler#find-lambda-container in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 411  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5562(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5520,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5527,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 402  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[144]),t3);}

/* k5525 in ##compiler#get-line-2 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5530(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5530(t3,C_SCHEME_FALSE);}}

/* k5528 in k5525 in ##compiler#get-line-2 in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_5530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 404  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 405  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5510,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 398  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t1,C_retrieve(lf[144]),t3,t2);}

/* ##compiler#count! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5453r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5453r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5453r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5457,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 386  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5455 in ##compiler#count! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5457,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5487,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 391  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 392  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5485 in k5455 in ##compiler#count! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5401,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5405,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 378  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5403 in ##compiler#collect! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5405,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 382  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 383  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5430 in k5403 in ##compiler#collect! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5355,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5359,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 370  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5357 in ##compiler#put! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5359,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5381,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 374  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 375  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5379 in k5357 in ##compiler#put! in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5337r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5337r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5337r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5341,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 364  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,t2,t3);}

/* k5339 in ##compiler#get-all in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5349,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 366  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5348 in k5339 in ##compiler#get-all in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5349,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5319,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5323,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 358  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,t2,t3);}

/* k5321 in ##compiler#get in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5168,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5172,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5176,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5250,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[134]));}
else{
t4=t3;
f_5172(2,t4,C_SCHEME_UNDEFINED);}}

/* a5249 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5250,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5254,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5291,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[126],lf[133]);}

/* f_5291 in a5249 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5291r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5291r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5291r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5295,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5295(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5295(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5293 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5252 in a5249 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5254,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],C_retrieve(lf[131])))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5264,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[132],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5264 in k5252 in a5249 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5264r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5264r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5264r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5268,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5268(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5268(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5266 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5174 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5217,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[130]));}

/* a5216 in k5174 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5222,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[126],lf[129]);}

/* f_5222 in a5216 in k5174 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5222r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5222r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5226(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5226(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5224 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5177 in k5174 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5184,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[128]));}

/* a5183 in k5177 in k5174 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5184,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5189,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[126],lf[127]);}

/* f_5189 in a5183 in k5177 in k5174 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5189r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5189r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5193,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5193(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5193(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5191 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5170 in ##compiler#initialize-analysis-database in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5027,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[114]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5031,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 320  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t6);}

/* k5029 in ##compiler#expand-profile-lambda in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 321  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[115]));}

/* k5033 in k5029 in ##compiler#expand-profile-lambda in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[114]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[117],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[118],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[118],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[119],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[118],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[83],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[120],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[118],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[121],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[118],t35));}

/* ##compiler#llist-length in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5024,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_length(t2));}

/* ##compiler#process-lambda-documentation in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5021,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4914,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4921,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),t3,t4);}

/* a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4923,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4929,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4954,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t3,t4);}

/* a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a5007 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5008r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5008r(t0,t1,t2);}}

static void C_ccall f_5008r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5014,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k580586 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5013 in a5007 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4959 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4992,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 302  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t2,((C_word*)t0)[2],t3);}

/* a4991 in a4959 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4998,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5006,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 302  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t3);}

/* k5004 in a4991 in a4959 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 302  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[103]))(6,*((C_word*)lf[103]+1),((C_word*)t0)[3],*((C_word*)lf[104]+1),*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* a4997 in a4991 in a4959 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4998,3,t0,t1,t2);}
/* support.scm: 302  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t1);}

/* k4962 in a4959 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[99]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4984 in k4962 in a4959 in a4953 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4986,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[100],t1));}

/* a4928 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4929,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k580586 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4934 in a4928 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4943,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 299  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4944 in a4934 in a4928 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 300  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 301  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4941 in a4934 in a4928 in a4922 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 297  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[98],((C_word*)t0)[2],t1);}

/* k4919 in ##compiler#string->expr in k4911 in k4908 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4813,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4819,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4819(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4819,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[91]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[92]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4847,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4847(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4896,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 286  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t7,t4);}}}}

/* k4894 in loop in ##compiler#canonicalize-begin-body in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4847(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[96])));}

/* k4845 in loop in ##compiler#canonicalize-begin-body in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4847,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 288  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4819(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 289  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,lf[95]);}}

/* k4883 in k4845 in loop in ##compiler#canonicalize-begin-body in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 290  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4819(t8,t6,t7);}

/* k4871 in k4883 in k4845 in loop in ##compiler#canonicalize-begin-body in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* ##compiler#basic-literal? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4753,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4769,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 271  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t5,t2);}}}

/* k4767 in ##compiler#basic-literal? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 272  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4775(2,t3,C_SCHEME_FALSE);}}}

/* k4809 in k4767 in ##compiler#basic-literal? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 272  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[2],C_retrieve(lf[87]),t1);}

/* k4773 in k4767 in ##compiler#basic-literal? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 274  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4788 in k4773 in k4767 in ##compiler#basic-literal? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 275  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4707,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4711,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 261  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t4,t2);}
else{
t4=t3;
f_4711(t4,C_SCHEME_FALSE);}}

/* k4749 in ##compiler#immediate? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4711(t2,(C_word)C_i_not(t1));}

/* k4709 in ##compiler#immediate? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4677,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4631,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[83],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4617,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 240  sort */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t1,t2,t3);}

/* a4616 in ##compiler#sort-symbols in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4617,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4625,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 240  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t4,t2);}

/* k4623 in a4616 in ##compiler#sort-symbols in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4629,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 240  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k4627 in k4623 in a4616 in ##compiler#sort-symbols in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 240  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[80]+1)))(4,*((C_word*)lf[80]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4580,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4586,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4586(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4586(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4586,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 236  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 237  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4600 in loop in ##compiler#follow-without-loop in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4601,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 237  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4586(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4517,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 226  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t5,t3);}}

/* k4529 in ##compiler#fold-inner in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4531,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4533,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4533(t5,((C_word*)t0)[2],t1);}

/* fold in k4529 in ##compiler#fold-inner in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4533,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4541(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4562,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 231  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4560 in fold in k4529 in ##compiler#fold-inner in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4541(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4539 in fold in k4529 in ##compiler#fold-inner in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4505,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[74]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 221  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4458r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4458r(t0,t1,t2,t3);}}

static void C_ccall f_4458r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[67]))){
/* support.scm: 215  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[68]+1)))(2,*((C_word*)lf[68]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4474,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 216  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t4,t2);}}

/* k4472 in ##compiler#check-and-open-input-file in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4474,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 216  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4486(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4486(t5,(C_word)C_i_not(t4));}}}

/* k4484 in k4472 in ##compiler#check-and-open-input-file in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 217  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[70],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 218  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[71],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4451,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4444,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub333(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4388,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4392,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4442,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 196  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t4,t2);}

/* k4440 in ##compiler#valid-c-identifier? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4390 in ##compiler#valid-c-identifier? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4415,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 200  any */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4414 in k4390 in ##compiler#valid-c-identifier? in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4415,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4294,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4310,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4312(t5,((C_word*)t0)[2],t1);}

/* loop in k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4312,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[54]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4334,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4334(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4334(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[60])));}}}

/* k4332 in loop in k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4334(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4334,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4341(t3,lf[58]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4341(t4,(C_truep(t3)?lf[59]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 193  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4312(t4,t2,t3);}}

/* k4371 in k4332 in loop in k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4339 in k4332 in loop in k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4341,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 191  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4355 in k4339 in k4332 in loop in k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4343 in k4339 in k4332 in loop in k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 192  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4312(t4,t2,t3);}

/* k4347 in k4343 in k4339 in k4332 in loop in k4308 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 187  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[55]+1)))(6,*((C_word*)lf[55]+1),((C_word*)t0)[4],lf[56],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4304 in ##compiler#c-ify-string in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[53]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4250,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4256,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4256(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4256(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4256,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4280,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 173  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4278 in loop in ##compiler#build-lambda-list in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4225,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 167  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4248,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 168  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t3,lf[48],t2);}}}

/* k4246 in ##compiler#symbolify in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 168  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4204,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 162  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t1,t2);}
else{
/* support.scm: 163  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,lf[45],t2);}}}

/* ##compiler#posq in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4168,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4174,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4174(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static C_word C_fcall f_4174(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4100,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4103,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4124,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4124(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4124(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4124,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 146  err */
t4=((C_word*)t0)[3];
f_4103(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 148  err */
t5=((C_word*)t0)[3];
f_4103(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 149  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4103,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 143  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}

/* k4109 in err in ##compiler#check-signature in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 144  map-llist */
((C_proc4)C_retrieve_symbol_proc(lf[37]))(4,*((C_word*)lf[37]+1),t2,C_retrieve(lf[40]),t3);}

/* k4113 in k4109 in err in ##compiler#check-signature in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 142  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[39],((C_word*)t0)[2],t1);}

/* map-llist in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4057,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4063,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4063(t7,t1,t3);}

/* loop in map-llist in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4063,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 137  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 138  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4084 in loop in map-llist in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4090,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 138  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4063(t4,t2,t3);}

/* k4088 in k4084 in loop in map-llist in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4054,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[30])));}

/* ##sys#syntax-error-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4009r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4009r(t0,t1,t2,t3);}}

static void C_ccall f_4009r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4013,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 116  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t6);}

/* k4011 in ##sys#syntax-error-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t2;
f_4016(t8,t3);}
else{
t3=t2;
f_4016(t3,C_SCHEME_FALSE);}}

/* k4014 in k4011 in ##sys#syntax-error-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_4016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
/* support.scm: 123  fprintf */
((C_proc6)C_retrieve_symbol_proc(lf[21]))(6,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[33],t1,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* support.scm: 124  fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[34],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4017 in k4014 in k4011 in ##sys#syntax-error-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4029 in k4017 in k4014 in k4011 in ##sys#syntax-error-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4030,3,t0,t1,t2);}
/* fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t1,((C_word*)t0)[2],lf[32],t2);}

/* k4020 in k4017 in k4014 in k4011 in ##sys#syntax-error-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 126  print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[29]))(6,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[30]),lf[31]);}

/* k4023 in k4020 in k4017 in k4014 in k4011 in ##sys#syntax-error-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 127  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3990r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3990r(t0,t1,t2,t3);}}

static void C_ccall f_3990r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3994,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 109  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k3992 in quit in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3997,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[27],((C_word*)t0)[2]);}

/* k4005 in k3992 in quit in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3995 in k3992 in quit in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 111  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2]);}

/* k3998 in k3995 in k3992 in quit in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 112  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3961r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3961r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3961r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3968,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[24]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_3968(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3968(t6,C_SCHEME_FALSE);}}

/* k3966 in ##compiler#compiler-warning in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_fcall f_3968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3968,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 104  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3969 in k3966 in ##compiler#compiler-warning in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[22],((C_word*)t0)[2]);}

/* k3979 in k3969 in k3966 in ##compiler#compiler-warning in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3972 in k3969 in k3966 in ##compiler#compiler-warning in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 106  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3921r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3921r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3921r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3931,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 93   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t5,lf[19],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3929 in ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3946,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 96   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_3934(2,t3,C_SCHEME_UNDEFINED);}}

/* k3944 in k3929 in ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3951,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3950 in k3944 in k3929 in ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3951,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3959,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 97   force */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k3957 in a3950 in k3944 in k3929 in ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 97   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14],t1);}

/* k3932 in k3929 in ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k3935 in k3932 in k3929 in ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t2);}

/* k3938 in k3935 in k3932 in k3929 in ##compiler#debugging in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3894r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3894r(t0,t1,t2);}}

static void C_ccall f_3894r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 87   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 88   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k3906 in ##compiler#bomb in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[684] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3870:support_scm",(void*)f_3870},
{"f_3873:support_scm",(void*)f_3873},
{"f_3876:support_scm",(void*)f_3876},
{"f_3879:support_scm",(void*)f_3879},
{"f_3882:support_scm",(void*)f_3882},
{"f_3885:support_scm",(void*)f_3885},
{"f_4910:support_scm",(void*)f_4910},
{"f_4913:support_scm",(void*)f_4913},
{"f_11898:support_scm",(void*)f_11898},
{"f_11912:support_scm",(void*)f_11912},
{"f_11916:support_scm",(void*)f_11916},
{"f_11927:support_scm",(void*)f_11927},
{"f_11939:support_scm",(void*)f_11939},
{"f_11947:support_scm",(void*)f_11947},
{"f_11951:support_scm",(void*)f_11951},
{"f_11910:support_scm",(void*)f_11910},
{"f_11901:support_scm",(void*)f_11901},
{"f_11904:support_scm",(void*)f_11904},
{"f_11885:support_scm",(void*)f_11885},
{"f_11890:support_scm",(void*)f_11890},
{"f_11874:support_scm",(void*)f_11874},
{"f_11879:support_scm",(void*)f_11879},
{"f_11868:support_scm",(void*)f_11868},
{"f_11840:support_scm",(void*)f_11840},
{"f_11844:support_scm",(void*)f_11844},
{"f_11819:support_scm",(void*)f_11819},
{"f_11823:support_scm",(void*)f_11823},
{"f_11786:support_scm",(void*)f_11786},
{"f_11791:support_scm",(void*)f_11791},
{"f_11795:support_scm",(void*)f_11795},
{"f_11753:support_scm",(void*)f_11753},
{"f_11758:support_scm",(void*)f_11758},
{"f_11762:support_scm",(void*)f_11762},
{"f_11729:support_scm",(void*)f_11729},
{"f_11660:support_scm",(void*)f_11660},
{"f_11664:support_scm",(void*)f_11664},
{"f_11669:support_scm",(void*)f_11669},
{"f_11673:support_scm",(void*)f_11673},
{"f_11724:support_scm",(void*)f_11724},
{"f_11703:support_scm",(void*)f_11703},
{"f_11715:support_scm",(void*)f_11715},
{"f_11718:support_scm",(void*)f_11718},
{"f_11691:support_scm",(void*)f_11691},
{"f_11627:support_scm",(void*)f_11627},
{"f_11637:support_scm",(void*)f_11637},
{"f_11640:support_scm",(void*)f_11640},
{"f_11525:support_scm",(void*)f_11525},
{"f_11534:support_scm",(void*)f_11534},
{"f_11621:support_scm",(void*)f_11621},
{"f_11538:support_scm",(void*)f_11538},
{"f_11616:support_scm",(void*)f_11616},
{"f_11541:support_scm",(void*)f_11541},
{"f_11611:support_scm",(void*)f_11611},
{"f_11544:support_scm",(void*)f_11544},
{"f_11547:support_scm",(void*)f_11547},
{"f_11553:support_scm",(void*)f_11553},
{"f_11606:support_scm",(void*)f_11606},
{"f_11556:support_scm",(void*)f_11556},
{"f_11571:support_scm",(void*)f_11571},
{"f_11579:support_scm",(void*)f_11579},
{"f_11589:support_scm",(void*)f_11589},
{"f_11574:support_scm",(void*)f_11574},
{"f_11562:support_scm",(void*)f_11562},
{"f_11529:support_scm",(void*)f_11529},
{"f_11519:support_scm",(void*)f_11519},
{"f_11473:support_scm",(void*)f_11473},
{"f_11492:support_scm",(void*)f_11492},
{"f_11503:support_scm",(void*)f_11503},
{"f_11499:support_scm",(void*)f_11499},
{"f_11461:support_scm",(void*)f_11461},
{"f_11467:support_scm",(void*)f_11467},
{"f_11449:support_scm",(void*)f_11449},
{"f_11453:support_scm",(void*)f_11453},
{"f_11370:support_scm",(void*)f_11370},
{"f_11389:support_scm",(void*)f_11389},
{"f_11414:support_scm",(void*)f_11414},
{"f_11418:support_scm",(void*)f_11418},
{"f_11420:support_scm",(void*)f_11420},
{"f_11427:support_scm",(void*)f_11427},
{"f_11440:support_scm",(void*)f_11440},
{"f_11444:support_scm",(void*)f_11444},
{"f_11373:support_scm",(void*)f_11373},
{"f_11377:support_scm",(void*)f_11377},
{"f_11383:support_scm",(void*)f_11383},
{"f_11364:support_scm",(void*)f_11364},
{"f_11320:support_scm",(void*)f_11320},
{"f_11332:support_scm",(void*)f_11332},
{"f_11336:support_scm",(void*)f_11336},
{"f_11340:support_scm",(void*)f_11340},
{"f_11328:support_scm",(void*)f_11328},
{"f_11311:support_scm",(void*)f_11311},
{"f_11305:support_scm",(void*)f_11305},
{"f_11299:support_scm",(void*)f_11299},
{"f_11287:support_scm",(void*)f_11287},
{"f_11291:support_scm",(void*)f_11291},
{"f_11294:support_scm",(void*)f_11294},
{"f_11249:support_scm",(void*)f_11249},
{"f_11253:support_scm",(void*)f_11253},
{"f_11256:support_scm",(void*)f_11256},
{"f_11263:support_scm",(void*)f_11263},
{"f_11207:support_scm",(void*)f_11207},
{"f_11216:support_scm",(void*)f_11216},
{"f_11178:support_scm",(void*)f_11178},
{"f_11188:support_scm",(void*)f_11188},
{"f_10981:support_scm",(void*)f_10981},
{"f_11160:support_scm",(void*)f_11160},
{"f_11109:support_scm",(void*)f_11109},
{"f_11154:support_scm",(void*)f_11154},
{"f_11158:support_scm",(void*)f_11158},
{"f_11112:support_scm",(void*)f_11112},
{"f_11117:support_scm",(void*)f_11117},
{"f_11121:support_scm",(void*)f_11121},
{"f_11115:support_scm",(void*)f_11115},
{"f_11072:support_scm",(void*)f_11072},
{"f_11076:support_scm",(void*)f_11076},
{"f_11085:support_scm",(void*)f_11085},
{"f_11089:support_scm",(void*)f_11089},
{"f_11079:support_scm",(void*)f_11079},
{"f_11037:support_scm",(void*)f_11037},
{"f_11043:support_scm",(void*)f_11043},
{"f_11070:support_scm",(void*)f_11070},
{"f_11056:support_scm",(void*)f_11056},
{"f_10990:support_scm",(void*)f_10990},
{"f_10996:support_scm",(void*)f_10996},
{"f_11035:support_scm",(void*)f_11035},
{"f_11017:support_scm",(void*)f_11017},
{"f_10794:support_scm",(void*)f_10794},
{"f_10976:support_scm",(void*)f_10976},
{"f_10963:support_scm",(void*)f_10963},
{"f_10969:support_scm",(void*)f_10969},
{"f_10797:support_scm",(void*)f_10797},
{"f_10957:support_scm",(void*)f_10957},
{"f_10801:support_scm",(void*)f_10801},
{"f_10952:support_scm",(void*)f_10952},
{"f_10804:support_scm",(void*)f_10804},
{"f_10947:support_scm",(void*)f_10947},
{"f_10807:support_scm",(void*)f_10807},
{"f_10816:support_scm",(void*)f_10816},
{"f_10910:support_scm",(void*)f_10910},
{"f_10922:support_scm",(void*)f_10922},
{"f_10880:support_scm",(void*)f_10880},
{"f_10891:support_scm",(void*)f_10891},
{"f_10871:support_scm",(void*)f_10871},
{"f_10857:support_scm",(void*)f_10857},
{"f_10835:support_scm",(void*)f_10835},
{"f_10841:support_scm",(void*)f_10841},
{"f_10845:support_scm",(void*)f_10845},
{"f_10701:support_scm",(void*)f_10701},
{"f_10707:support_scm",(void*)f_10707},
{"f_10788:support_scm",(void*)f_10788},
{"f_10711:support_scm",(void*)f_10711},
{"f_10783:support_scm",(void*)f_10783},
{"f_10714:support_scm",(void*)f_10714},
{"f_10767:support_scm",(void*)f_10767},
{"f_10754:support_scm",(void*)f_10754},
{"f_10753:support_scm",(void*)f_10753},
{"f_10735:support_scm",(void*)f_10735},
{"f_10729:support_scm",(void*)f_10729},
{"f_10705:support_scm",(void*)f_10705},
{"f_10409:support_scm",(void*)f_10409},
{"f_10605:support_scm",(void*)f_10605},
{"f_10626:support_scm",(void*)f_10626},
{"f_10099:support_scm",(void*)f_10099},
{"f_10403:support_scm",(void*)f_10403},
{"f_10111:support_scm",(void*)f_10111},
{"f_10121:support_scm",(void*)f_10121},
{"f_10139:support_scm",(void*)f_10139},
{"f_10173:support_scm",(void*)f_10173},
{"f_10102:support_scm",(void*)f_10102},
{"f_9780:support_scm",(void*)f_9780},
{"f_10093:support_scm",(void*)f_10093},
{"f_9786:support_scm",(void*)f_9786},
{"f_9796:support_scm",(void*)f_9796},
{"f_9805:support_scm",(void*)f_9805},
{"f_9817:support_scm",(void*)f_9817},
{"f_9829:support_scm",(void*)f_9829},
{"f_9835:support_scm",(void*)f_9835},
{"f_9869:support_scm",(void*)f_9869},
{"f_9740:support_scm",(void*)f_9740},
{"f_9774:support_scm",(void*)f_9774},
{"f_9746:support_scm",(void*)f_9746},
{"f_9750:support_scm",(void*)f_9750},
{"f_9709:support_scm",(void*)f_9709},
{"f_9722:support_scm",(void*)f_9722},
{"f_9713:support_scm",(void*)f_9713},
{"f_9678:support_scm",(void*)f_9678},
{"f_9691:support_scm",(void*)f_9691},
{"f_9682:support_scm",(void*)f_9682},
{"f_8631:support_scm",(void*)f_8631},
{"f_9672:support_scm",(void*)f_9672},
{"f_8637:support_scm",(void*)f_8637},
{"f_8643:support_scm",(void*)f_8643},
{"f_8672:support_scm",(void*)f_8672},
{"f_8691:support_scm",(void*)f_8691},
{"f_8710:support_scm",(void*)f_8710},
{"f_8780:support_scm",(void*)f_8780},
{"f_8799:support_scm",(void*)f_8799},
{"f_8881:support_scm",(void*)f_8881},
{"f_8920:support_scm",(void*)f_8920},
{"f_8939:support_scm",(void*)f_8939},
{"f_8958:support_scm",(void*)f_8958},
{"f_9038:support_scm",(void*)f_9038},
{"f_9123:support_scm",(void*)f_9123},
{"f_9198:support_scm",(void*)f_9198},
{"f_9232:support_scm",(void*)f_9232},
{"f_9302:support_scm",(void*)f_9302},
{"f_9235:support_scm",(void*)f_9235},
{"f_9041:support_scm",(void*)f_9041},
{"f_9072:support_scm",(void*)f_9072},
{"f_8961:support_scm",(void*)f_8961},
{"f_8802:support_scm",(void*)f_8802},
{"f_8833:support_scm",(void*)f_8833},
{"f_8713:support_scm",(void*)f_8713},
{"f_8744:support_scm",(void*)f_8744},
{"f_8595:support_scm",(void*)f_8595},
{"f_8599:support_scm",(void*)f_8599},
{"f_8610:support_scm",(void*)f_8610},
{"f_8616:support_scm",(void*)f_8616},
{"f_8620:support_scm",(void*)f_8620},
{"f_8602:support_scm",(void*)f_8602},
{"f_8556:support_scm",(void*)f_8556},
{"f_8568:support_scm",(void*)f_8568},
{"f_8575:support_scm",(void*)f_8575},
{"f_8578:support_scm",(void*)f_8578},
{"f_8581:support_scm",(void*)f_8581},
{"f_8584:support_scm",(void*)f_8584},
{"f_8587:support_scm",(void*)f_8587},
{"f_8590:support_scm",(void*)f_8590},
{"f_8562:support_scm",(void*)f_8562},
{"f_8470:support_scm",(void*)f_8470},
{"f_8479:support_scm",(void*)f_8479},
{"f_8485:support_scm",(void*)f_8485},
{"f_8532:support_scm",(void*)f_8532},
{"f_8527:support_scm",(void*)f_8527},
{"f_8474:support_scm",(void*)f_8474},
{"f_8449:support_scm",(void*)f_8449},
{"f_8459:support_scm",(void*)f_8459},
{"f_8418:support_scm",(void*)f_8418},
{"f_8424:support_scm",(void*)f_8424},
{"f_8431:support_scm",(void*)f_8431},
{"f_8434:support_scm",(void*)f_8434},
{"f_8296:support_scm",(void*)f_8296},
{"f_8412:support_scm",(void*)f_8412},
{"f_8300:support_scm",(void*)f_8300},
{"f_8320:support_scm",(void*)f_8320},
{"f_8401:support_scm",(void*)f_8401},
{"f_8324:support_scm",(void*)f_8324},
{"f_8396:support_scm",(void*)f_8396},
{"f_8395:support_scm",(void*)f_8395},
{"f_8378:support_scm",(void*)f_8378},
{"f_8333:support_scm",(void*)f_8333},
{"f_8373:support_scm",(void*)f_8373},
{"f_8372:support_scm",(void*)f_8372},
{"f_8364:support_scm",(void*)f_8364},
{"f_8363:support_scm",(void*)f_8363},
{"f_8195:support_scm",(void*)f_8195},
{"f_8201:support_scm",(void*)f_8201},
{"f_8290:support_scm",(void*)f_8290},
{"f_8205:support_scm",(void*)f_8205},
{"f_8285:support_scm",(void*)f_8285},
{"f_8208:support_scm",(void*)f_8208},
{"f_8217:support_scm",(void*)f_8217},
{"f_8244:support_scm",(void*)f_8244},
{"f_8243:support_scm",(void*)f_8243},
{"f_8231:support_scm",(void*)f_8231},
{"f_8239:support_scm",(void*)f_8239},
{"f_7975:support_scm",(void*)f_7975},
{"f_8169:support_scm",(void*)f_8169},
{"f_8189:support_scm",(void*)f_8189},
{"f_8179:support_scm",(void*)f_8179},
{"f_8184:support_scm",(void*)f_8184},
{"f_8183:support_scm",(void*)f_8183},
{"f_8175:support_scm",(void*)f_8175},
{"f_8050:support_scm",(void*)f_8050},
{"f_8162:support_scm",(void*)f_8162},
{"f_8157:support_scm",(void*)f_8157},
{"f_8149:support_scm",(void*)f_8149},
{"f_8144:support_scm",(void*)f_8144},
{"f_8072:support_scm",(void*)f_8072},
{"f_8136:support_scm",(void*)f_8136},
{"f_8079:support_scm",(void*)f_8079},
{"f_8085:support_scm",(void*)f_8085},
{"f_8116:support_scm",(void*)f_8116},
{"f_8007:support_scm",(void*)f_8007},
{"f_8029:support_scm",(void*)f_8029},
{"f_7978:support_scm",(void*)f_7978},
{"f_8002:support_scm",(void*)f_8002},
{"f_7906:support_scm",(void*)f_7906},
{"f_7912:support_scm",(void*)f_7912},
{"f_7918:support_scm",(void*)f_7918},
{"f_7922:support_scm",(void*)f_7922},
{"f_7942:support_scm",(void*)f_7942},
{"f_7943:support_scm",(void*)f_7943},
{"f_7947:support_scm",(void*)f_7947},
{"f_7931:support_scm",(void*)f_7931},
{"f_7704:support_scm",(void*)f_7704},
{"f_7735:support_scm",(void*)f_7735},
{"f_7904:support_scm",(void*)f_7904},
{"f_7739:support_scm",(void*)f_7739},
{"f_7747:support_scm",(void*)f_7747},
{"f_7754:support_scm",(void*)f_7754},
{"f_7896:support_scm",(void*)f_7896},
{"f_7890:support_scm",(void*)f_7890},
{"f_7891:support_scm",(void*)f_7891},
{"f_7886:support_scm",(void*)f_7886},
{"f_7778:support_scm",(void*)f_7778},
{"f_7867:support_scm",(void*)f_7867},
{"f_7787:support_scm",(void*)f_7787},
{"f_7796:support_scm",(void*)f_7796},
{"f_7858:support_scm",(void*)f_7858},
{"f_7850:support_scm",(void*)f_7850},
{"f_7808:support_scm",(void*)f_7808},
{"f_7811:support_scm",(void*)f_7811},
{"f_7829:support_scm",(void*)f_7829},
{"f_7818:support_scm",(void*)f_7818},
{"f_7742:support_scm",(void*)f_7742},
{"f_7708:support_scm",(void*)f_7708},
{"f_7714:support_scm",(void*)f_7714},
{"f_7727:support_scm",(void*)f_7727},
{"f_7719:support_scm",(void*)f_7719},
{"f_7671:support_scm",(void*)f_7671},
{"f_7677:support_scm",(void*)f_7677},
{"f_7693:support_scm",(void*)f_7693},
{"f_7694:support_scm",(void*)f_7694},
{"f_7620:support_scm",(void*)f_7620},
{"f_7626:support_scm",(void*)f_7626},
{"f_7665:support_scm",(void*)f_7665},
{"f_7634:support_scm",(void*)f_7634},
{"f_7660:support_scm",(void*)f_7660},
{"f_7642:support_scm",(void*)f_7642},
{"f_7655:support_scm",(void*)f_7655},
{"f_7654:support_scm",(void*)f_7654},
{"f_7650:support_scm",(void*)f_7650},
{"f_7646:support_scm",(void*)f_7646},
{"f_7543:support_scm",(void*)f_7543},
{"f_7614:support_scm",(void*)f_7614},
{"f_7613:support_scm",(void*)f_7613},
{"f_7547:support_scm",(void*)f_7547},
{"f_7605:support_scm",(void*)f_7605},
{"f_7604:support_scm",(void*)f_7604},
{"f_7550:support_scm",(void*)f_7550},
{"f_7596:support_scm",(void*)f_7596},
{"f_7595:support_scm",(void*)f_7595},
{"f_7553:support_scm",(void*)f_7553},
{"f_7564:support_scm",(void*)f_7564},
{"f_7509:support_scm",(void*)f_7509},
{"f_7515:support_scm",(void*)f_7515},
{"f_7529:support_scm",(void*)f_7529},
{"f_7533:support_scm",(void*)f_7533},
{"f_7288:support_scm",(void*)f_7288},
{"f_7292:support_scm",(void*)f_7292},
{"f_7300:support_scm",(void*)f_7300},
{"f_7500:support_scm",(void*)f_7500},
{"f_7304:support_scm",(void*)f_7304},
{"f_7495:support_scm",(void*)f_7495},
{"f_7307:support_scm",(void*)f_7307},
{"f_7490:support_scm",(void*)f_7490},
{"f_7310:support_scm",(void*)f_7310},
{"f_7474:support_scm",(void*)f_7474},
{"f_7485:support_scm",(void*)f_7485},
{"f_7478:support_scm",(void*)f_7478},
{"f_7479:support_scm",(void*)f_7479},
{"f_7415:support_scm",(void*)f_7415},
{"f_7419:support_scm",(void*)f_7419},
{"f_7422:support_scm",(void*)f_7422},
{"f_7448:support_scm",(void*)f_7448},
{"f_7464:support_scm",(void*)f_7464},
{"f_7456:support_scm",(void*)f_7456},
{"f_7440:support_scm",(void*)f_7440},
{"f_7433:support_scm",(void*)f_7433},
{"f_7434:support_scm",(void*)f_7434},
{"f_7375:support_scm",(void*)f_7375},
{"f_7378:support_scm",(void*)f_7378},
{"f_7396:support_scm",(void*)f_7396},
{"f_7389:support_scm",(void*)f_7389},
{"f_7390:support_scm",(void*)f_7390},
{"f_7359:support_scm",(void*)f_7359},
{"f_7351:support_scm",(void*)f_7351},
{"f_7344:support_scm",(void*)f_7344},
{"f_7345:support_scm",(void*)f_7345},
{"f_7323:support_scm",(void*)f_7323},
{"f_7294:support_scm",(void*)f_7294},
{"f_7175:support_scm",(void*)f_7175},
{"f_7181:support_scm",(void*)f_7181},
{"f_7193:support_scm",(void*)f_7193},
{"f_7197:support_scm",(void*)f_7197},
{"f_7200:support_scm",(void*)f_7200},
{"f_7280:support_scm",(void*)f_7280},
{"f_7264:support_scm",(void*)f_7264},
{"f_7250:support_scm",(void*)f_7250},
{"f_7242:support_scm",(void*)f_7242},
{"f_7226:support_scm",(void*)f_7226},
{"f_7230:support_scm",(void*)f_7230},
{"f_7205:support_scm",(void*)f_7205},
{"f_7218:support_scm",(void*)f_7218},
{"f_7187:support_scm",(void*)f_7187},
{"f_7121:support_scm",(void*)f_7121},
{"f_7127:support_scm",(void*)f_7127},
{"f_7153:support_scm",(void*)f_7153},
{"f_7157:support_scm",(void*)f_7157},
{"f_7145:support_scm",(void*)f_7145},
{"f_6788:support_scm",(void*)f_6788},
{"f_6794:support_scm",(void*)f_6794},
{"f_7115:support_scm",(void*)f_7115},
{"f_6798:support_scm",(void*)f_6798},
{"f_7110:support_scm",(void*)f_7110},
{"f_6801:support_scm",(void*)f_6801},
{"f_7105:support_scm",(void*)f_7105},
{"f_6804:support_scm",(void*)f_6804},
{"f_6813:support_scm",(void*)f_6813},
{"f_7047:support_scm",(void*)f_7047},
{"f_7077:support_scm",(void*)f_7077},
{"f_7073:support_scm",(void*)f_7073},
{"f_7054:support_scm",(void*)f_7054},
{"f_7058:support_scm",(void*)f_7058},
{"f_6985:support_scm",(void*)f_6985},
{"f_7034:support_scm",(void*)f_7034},
{"f_7003:support_scm",(void*)f_7003},
{"f_7011:support_scm",(void*)f_7011},
{"f_6961:support_scm",(void*)f_6961},
{"f_6928:support_scm",(void*)f_6928},
{"f_6907:support_scm",(void*)f_6907},
{"f_6903:support_scm",(void*)f_6903},
{"f_6887:support_scm",(void*)f_6887},
{"f_6899:support_scm",(void*)f_6899},
{"f_6895:support_scm",(void*)f_6895},
{"f_6841:support_scm",(void*)f_6841},
{"f_6837:support_scm",(void*)f_6837},
{"f_6820:support_scm",(void*)f_6820},
{"f_6179:support_scm",(void*)f_6179},
{"f_6783:support_scm",(void*)f_6783},
{"f_6786:support_scm",(void*)f_6786},
{"f_6182:support_scm",(void*)f_6182},
{"f_6771:support_scm",(void*)f_6771},
{"f_6772:support_scm",(void*)f_6772},
{"f_6621:support_scm",(void*)f_6621},
{"f_6678:support_scm",(void*)f_6678},
{"f_6727:support_scm",(void*)f_6727},
{"f_6722:support_scm",(void*)f_6722},
{"f_6699:support_scm",(void*)f_6699},
{"f_6706:support_scm",(void*)f_6706},
{"f_6713:support_scm",(void*)f_6713},
{"f_6703:support_scm",(void*)f_6703},
{"f_6690:support_scm",(void*)f_6690},
{"f_6691:support_scm",(void*)f_6691},
{"f_6672:support_scm",(void*)f_6672},
{"f_6658:support_scm",(void*)f_6658},
{"f_6659:support_scm",(void*)f_6659},
{"f_6636:support_scm",(void*)f_6636},
{"f_6637:support_scm",(void*)f_6637},
{"f_6600:support_scm",(void*)f_6600},
{"f_6584:support_scm",(void*)f_6584},
{"f_6580:support_scm",(void*)f_6580},
{"f_6572:support_scm",(void*)f_6572},
{"f_6538:support_scm",(void*)f_6538},
{"f_6539:support_scm",(void*)f_6539},
{"f_6510:support_scm",(void*)f_6510},
{"f_6483:support_scm",(void*)f_6483},
{"f_6484:support_scm",(void*)f_6484},
{"f_6446:support_scm",(void*)f_6446},
{"f_6430:support_scm",(void*)f_6430},
{"f_6431:support_scm",(void*)f_6431},
{"f_6398:support_scm",(void*)f_6398},
{"f_6390:support_scm",(void*)f_6390},
{"f_6334:support_scm",(void*)f_6334},
{"f_6357:support_scm",(void*)f_6357},
{"f_6347:support_scm",(void*)f_6347},
{"f_6355:support_scm",(void*)f_6355},
{"f_6338:support_scm",(void*)f_6338},
{"f_6339:support_scm",(void*)f_6339},
{"f_6280:support_scm",(void*)f_6280},
{"f_6283:support_scm",(void*)f_6283},
{"f_6290:support_scm",(void*)f_6290},
{"f_6277:support_scm",(void*)f_6277},
{"f_6252:support_scm",(void*)f_6252},
{"f_6253:support_scm",(void*)f_6253},
{"f_6224:support_scm",(void*)f_6224},
{"f_6164:support_scm",(void*)f_6164},
{"f_6173:support_scm",(void*)f_6173},
{"f_6149:support_scm",(void*)f_6149},
{"f_6158:support_scm",(void*)f_6158},
{"f_6143:support_scm",(void*)f_6143},
{"f_6134:support_scm",(void*)f_6134},
{"f_6125:support_scm",(void*)f_6125},
{"f_6116:support_scm",(void*)f_6116},
{"f_6107:support_scm",(void*)f_6107},
{"f_6098:support_scm",(void*)f_6098},
{"f_6089:support_scm",(void*)f_6089},
{"f_6083:support_scm",(void*)f_6083},
{"f_6077:support_scm",(void*)f_6077},
{"f_5599:support_scm",(void*)f_5599},
{"f_6075:support_scm",(void*)f_6075},
{"f_5603:support_scm",(void*)f_5603},
{"f_5608:support_scm",(void*)f_5608},
{"f_5618:support_scm",(void*)f_5618},
{"f_5766:support_scm",(void*)f_5766},
{"f_5776:support_scm",(void*)f_5776},
{"f_5792:support_scm",(void*)f_5792},
{"f_5865:support_scm",(void*)f_5865},
{"f_5896:support_scm",(void*)f_5896},
{"f_5886:support_scm",(void*)f_5886},
{"f_5872:support_scm",(void*)f_5872},
{"f_5876:support_scm",(void*)f_5876},
{"f_5856:support_scm",(void*)f_5856},
{"f_5846:support_scm",(void*)f_5846},
{"f_5830:support_scm",(void*)f_5830},
{"f_5807:support_scm",(void*)f_5807},
{"f_5779:support_scm",(void*)f_5779},
{"f_5621:support_scm",(void*)f_5621},
{"f_5656:support_scm",(void*)f_5656},
{"f_5687:support_scm",(void*)f_5687},
{"f_5718:support_scm",(void*)f_5718},
{"f_5739:support_scm",(void*)f_5739},
{"f_5729:support_scm",(void*)f_5729},
{"f_5734:support_scm",(void*)f_5734},
{"f_5733:support_scm",(void*)f_5733},
{"f_5708:support_scm",(void*)f_5708},
{"f_5698:support_scm",(void*)f_5698},
{"f_5703:support_scm",(void*)f_5703},
{"f_5702:support_scm",(void*)f_5702},
{"f_5677:support_scm",(void*)f_5677},
{"f_5667:support_scm",(void*)f_5667},
{"f_5672:support_scm",(void*)f_5672},
{"f_5671:support_scm",(void*)f_5671},
{"f_5624:support_scm",(void*)f_5624},
{"f_5627:support_scm",(void*)f_5627},
{"f_5630:support_scm",(void*)f_5630},
{"f_5580:support_scm",(void*)f_5580},
{"f_5586:support_scm",(void*)f_5586},
{"f_5597:support_scm",(void*)f_5597},
{"f_5556:support_scm",(void*)f_5556},
{"f_5562:support_scm",(void*)f_5562},
{"f_5572:support_scm",(void*)f_5572},
{"f_5520:support_scm",(void*)f_5520},
{"f_5527:support_scm",(void*)f_5527},
{"f_5530:support_scm",(void*)f_5530},
{"f_5510:support_scm",(void*)f_5510},
{"f_5453:support_scm",(void*)f_5453},
{"f_5457:support_scm",(void*)f_5457},
{"f_5487:support_scm",(void*)f_5487},
{"f_5401:support_scm",(void*)f_5401},
{"f_5405:support_scm",(void*)f_5405},
{"f_5432:support_scm",(void*)f_5432},
{"f_5355:support_scm",(void*)f_5355},
{"f_5359:support_scm",(void*)f_5359},
{"f_5381:support_scm",(void*)f_5381},
{"f_5337:support_scm",(void*)f_5337},
{"f_5341:support_scm",(void*)f_5341},
{"f_5349:support_scm",(void*)f_5349},
{"f_5319:support_scm",(void*)f_5319},
{"f_5323:support_scm",(void*)f_5323},
{"f_5168:support_scm",(void*)f_5168},
{"f_5250:support_scm",(void*)f_5250},
{"f_5291:support_scm",(void*)f_5291},
{"f_5295:support_scm",(void*)f_5295},
{"f_5254:support_scm",(void*)f_5254},
{"f_5264:support_scm",(void*)f_5264},
{"f_5268:support_scm",(void*)f_5268},
{"f_5176:support_scm",(void*)f_5176},
{"f_5217:support_scm",(void*)f_5217},
{"f_5222:support_scm",(void*)f_5222},
{"f_5226:support_scm",(void*)f_5226},
{"f_5179:support_scm",(void*)f_5179},
{"f_5184:support_scm",(void*)f_5184},
{"f_5189:support_scm",(void*)f_5189},
{"f_5193:support_scm",(void*)f_5193},
{"f_5172:support_scm",(void*)f_5172},
{"f_5027:support_scm",(void*)f_5027},
{"f_5031:support_scm",(void*)f_5031},
{"f_5035:support_scm",(void*)f_5035},
{"f_5024:support_scm",(void*)f_5024},
{"f_5021:support_scm",(void*)f_5021},
{"f_4914:support_scm",(void*)f_4914},
{"f_4923:support_scm",(void*)f_4923},
{"f_4954:support_scm",(void*)f_4954},
{"f_5008:support_scm",(void*)f_5008},
{"f_5014:support_scm",(void*)f_5014},
{"f_4960:support_scm",(void*)f_4960},
{"f_4992:support_scm",(void*)f_4992},
{"f_5006:support_scm",(void*)f_5006},
{"f_4998:support_scm",(void*)f_4998},
{"f_4964:support_scm",(void*)f_4964},
{"f_4986:support_scm",(void*)f_4986},
{"f_4929:support_scm",(void*)f_4929},
{"f_4935:support_scm",(void*)f_4935},
{"f_4946:support_scm",(void*)f_4946},
{"f_4943:support_scm",(void*)f_4943},
{"f_4921:support_scm",(void*)f_4921},
{"f_4813:support_scm",(void*)f_4813},
{"f_4819:support_scm",(void*)f_4819},
{"f_4896:support_scm",(void*)f_4896},
{"f_4847:support_scm",(void*)f_4847},
{"f_4885:support_scm",(void*)f_4885},
{"f_4873:support_scm",(void*)f_4873},
{"f_4753:support_scm",(void*)f_4753},
{"f_4769:support_scm",(void*)f_4769},
{"f_4811:support_scm",(void*)f_4811},
{"f_4775:support_scm",(void*)f_4775},
{"f_4790:support_scm",(void*)f_4790},
{"f_4707:support_scm",(void*)f_4707},
{"f_4751:support_scm",(void*)f_4751},
{"f_4711:support_scm",(void*)f_4711},
{"f_4677:support_scm",(void*)f_4677},
{"f_4631:support_scm",(void*)f_4631},
{"f_4611:support_scm",(void*)f_4611},
{"f_4617:support_scm",(void*)f_4617},
{"f_4625:support_scm",(void*)f_4625},
{"f_4629:support_scm",(void*)f_4629},
{"f_4580:support_scm",(void*)f_4580},
{"f_4586:support_scm",(void*)f_4586},
{"f_4601:support_scm",(void*)f_4601},
{"f_4517:support_scm",(void*)f_4517},
{"f_4531:support_scm",(void*)f_4531},
{"f_4533:support_scm",(void*)f_4533},
{"f_4562:support_scm",(void*)f_4562},
{"f_4541:support_scm",(void*)f_4541},
{"f_4505:support_scm",(void*)f_4505},
{"f_4458:support_scm",(void*)f_4458},
{"f_4474:support_scm",(void*)f_4474},
{"f_4486:support_scm",(void*)f_4486},
{"f_4451:support_scm",(void*)f_4451},
{"f_4444:support_scm",(void*)f_4444},
{"f_4388:support_scm",(void*)f_4388},
{"f_4442:support_scm",(void*)f_4442},
{"f_4392:support_scm",(void*)f_4392},
{"f_4415:support_scm",(void*)f_4415},
{"f_4294:support_scm",(void*)f_4294},
{"f_4310:support_scm",(void*)f_4310},
{"f_4312:support_scm",(void*)f_4312},
{"f_4334:support_scm",(void*)f_4334},
{"f_4373:support_scm",(void*)f_4373},
{"f_4341:support_scm",(void*)f_4341},
{"f_4357:support_scm",(void*)f_4357},
{"f_4345:support_scm",(void*)f_4345},
{"f_4349:support_scm",(void*)f_4349},
{"f_4306:support_scm",(void*)f_4306},
{"f_4250:support_scm",(void*)f_4250},
{"f_4256:support_scm",(void*)f_4256},
{"f_4280:support_scm",(void*)f_4280},
{"f_4225:support_scm",(void*)f_4225},
{"f_4248:support_scm",(void*)f_4248},
{"f_4204:support_scm",(void*)f_4204},
{"f_4168:support_scm",(void*)f_4168},
{"f_4174:support_scm",(void*)f_4174},
{"f_4100:support_scm",(void*)f_4100},
{"f_4124:support_scm",(void*)f_4124},
{"f_4103:support_scm",(void*)f_4103},
{"f_4111:support_scm",(void*)f_4111},
{"f_4115:support_scm",(void*)f_4115},
{"f_4057:support_scm",(void*)f_4057},
{"f_4063:support_scm",(void*)f_4063},
{"f_4086:support_scm",(void*)f_4086},
{"f_4090:support_scm",(void*)f_4090},
{"f_4054:support_scm",(void*)f_4054},
{"f_4009:support_scm",(void*)f_4009},
{"f_4013:support_scm",(void*)f_4013},
{"f_4016:support_scm",(void*)f_4016},
{"f_4019:support_scm",(void*)f_4019},
{"f_4030:support_scm",(void*)f_4030},
{"f_4022:support_scm",(void*)f_4022},
{"f_4025:support_scm",(void*)f_4025},
{"f_3990:support_scm",(void*)f_3990},
{"f_3994:support_scm",(void*)f_3994},
{"f_4007:support_scm",(void*)f_4007},
{"f_3997:support_scm",(void*)f_3997},
{"f_4000:support_scm",(void*)f_4000},
{"f_3961:support_scm",(void*)f_3961},
{"f_3968:support_scm",(void*)f_3968},
{"f_3971:support_scm",(void*)f_3971},
{"f_3981:support_scm",(void*)f_3981},
{"f_3974:support_scm",(void*)f_3974},
{"f_3921:support_scm",(void*)f_3921},
{"f_3931:support_scm",(void*)f_3931},
{"f_3946:support_scm",(void*)f_3946},
{"f_3951:support_scm",(void*)f_3951},
{"f_3959:support_scm",(void*)f_3959},
{"f_3934:support_scm",(void*)f_3934},
{"f_3937:support_scm",(void*)f_3937},
{"f_3940:support_scm",(void*)f_3940},
{"f_3894:support_scm",(void*)f_3894},
{"f_3908:support_scm",(void*)f_3908},
{"f_3889:support_scm",(void*)f_3889},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
