/* Generated from data-structures.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:45
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: data-structures.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file data-structures.c -extend ./private-namespace.scm
   unit: data_structures
*/

#include "chicken.h"

#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[114];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,105,100,101,110,116,105,116,121,32,120,53,51,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,17),40,102,95,49,54,51,54,32,46,32,97,114,103,115,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,13),40,112,114,111,106,101,99,116,32,110,53,55,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,54,57,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,102,95,49,54,52,52,32,120,54,53,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,19),40,99,111,110,106,111,105,110,32,46,32,112,114,101,100,115,54,51,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,56,57,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,12),40,102,95,49,54,55,55,32,120,56,53,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,19),40,100,105,115,106,111,105,110,32,46,32,112,114,101,100,115,56,51,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,15),40,102,95,49,55,50,51,32,46,32,95,49,48,55,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,15),40,102,95,49,55,50,53,32,46,32,95,49,48,57,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,20),40,99,111,110,115,116,97,110,116,108,121,32,46,32,120,115,49,48,51,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,51,55,32,120,49,49,53,32,121,49,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,14),40,102,108,105,112,32,112,114,111,99,49,49,51,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,52,53,32,46,32,97,114,103,115,49,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,17),40,99,111,109,112,108,101,109,101,110,116,32,112,49,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,49,55,55,49,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,54,54,32,46,32,97,114,103,115,49,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,20),40,114,101,99,32,102,48,49,50,56,32,46,32,102,110,115,49,50,57,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,18),40,99,111,109,112,111,115,101,32,46,32,102,110,115,49,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,13),40,102,95,49,56,49,55,32,120,49,52,54,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,49,52,49,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,12),40,111,32,46,32,102,110,115,49,51,55,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,53,56,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,15),40,102,95,49,56,51,50,32,108,115,116,49,53,52,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,18),40,108,105,115,116,45,111,102,63,32,112,114,101,100,49,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,13),40,110,111,111,112,32,46,32,95,49,55,50,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,15),40,102,95,49,56,56,53,32,46,32,95,49,56,53,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,112,114,111,99,115,49,57,49,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,18),40,102,95,49,56,57,57,32,46,32,97,114,103,115,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,17),40,101,97,99,104,32,46,32,112,114,111,99,115,49,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,11),40,97,110,121,63,32,120,50,48,49,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,12),40,110,111,110,101,63,32,120,50,48,53,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,16),40,97,108,119,97,121,115,63,32,46,32,95,50,48,57,41};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,15),40,110,101,118,101,114,63,32,46,32,95,50,49,51,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,102,95,49,57,53,48,32,46,32,120,115,50,50,48,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,32),40,108,101,102,116,45,115,101,99,116,105,111,110,32,112,114,111,99,50,49,55,32,46,32,97,114,103,115,50,49,56,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,16),40,102,95,49,57,54,56,32,46,32,120,115,50,51,49,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,33),40,114,105,103,104,116,45,115,101,99,116,105,111,110,32,112,114,111,99,50,50,54,32,46,32,97,114,103,115,50,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,12),40,97,116,111,109,63,32,120,50,51,54,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,17),40,116,97,105,108,63,32,120,50,52,48,32,121,50,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,110,115,50,54,57,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,25),40,105,110,116,101,114,115,112,101,114,115,101,32,108,115,116,50,54,52,32,120,50,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,50,56,49,41,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,16),40,98,117,116,108,97,115,116,32,108,115,116,50,55,55,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,105,115,116,115,50,57,54,32,114,101,115,116,50,57,55,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,21),40,102,108,97,116,116,101,110,32,46,32,108,105,115,116,115,48,50,57,50,41,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,28),40,100,111,108,111,111,112,51,51,56,32,104,100,51,52,52,32,116,108,51,52,53,32,99,51,52,54,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,115,116,51,50,56,32,105,51,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,18),40,99,104,111,112,32,108,115,116,51,49,52,32,110,51,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,115,51,54,51,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,106,111,105,110,32,108,115,116,115,51,53,54,32,46,32,108,115,116,51,53,55,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,98,108,115,116,51,57,49,32,108,115,116,51,57,50,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,99,111,109,112,114,101,115,115,32,98,108,115,116,51,56,52,32,108,115,116,51,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,17),40,97,50,51,54,51,32,120,52,50,50,32,121,52,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,50,51,55,55,32,120,52,50,48,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,24),40,115,104,117,102,102,108,101,32,108,52,49,53,32,114,97,110,100,111,109,52,49,54,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,52,52,56,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,102,95,50,52,50,55,32,120,52,52,51,32,108,115,116,52,52,52,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,41),40,97,108,105,115,116,45,117,112,100,97,116,101,33,32,120,52,50,55,32,121,52,50,56,32,108,115,116,52,50,57,32,46,32,99,109,112,52,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,53,48,57,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,102,95,50,53,48,53,32,120,53,48,52,32,108,115,116,53,48,53,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,52,56,50,32,99,109,112,52,57,50,32,100,101,102,97,117,108,116,52,57,51,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,100,101,102,97,117,108,116,52,56,53,32,37,99,109,112,52,56,48,53,50,53,41,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,99,109,112,52,56,52,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,35),40,97,108,105,115,116,45,114,101,102,32,120,52,55,49,32,108,115,116,52,55,50,32,46,32,116,109,112,52,55,48,52,55,51,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,53,53,52,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,114,97,115,115,111,99,32,120,53,52,49,32,108,115,116,53,52,50,32,46,32,116,115,116,53,52,51,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,106,53,56,55,32,107,53,56,56,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,29),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,53,55,52,32,105,53,55,53,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,46),40,35,35,100,97,116,97,45,115,116,114,117,99,116,117,114,101,115,35,114,101,118,101,114,115,101,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,53,55,49,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,15),40,45,62,115,116,114,105,110,103,32,120,54,48,48,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,99,111,110,99,32,46,32,97,114,103,115,54,49,53,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,115,116,97,114,116,54,51,49,32,105,101,110,100,54,51,50,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,52),40,116,114,97,118,101,114,115,101,32,119,104,105,99,104,54,50,48,32,119,104,101,114,101,54,50,49,32,115,116,97,114,116,54,50,50,32,116,101,115,116,54,50,51,32,108,111,99,54,50,52,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,17),40,97,50,56,51,50,32,105,54,53,48,32,108,54,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,54,52,54,32,119,104,101,114,101,54,52,55,32,115,116,97,114,116,54,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,97,50,56,52,49,32,105,54,53,55,32,108,54,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,53),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,54,53,51,32,119,104,101,114,101,54,53,52,32,115,116,97,114,116,54,53,53,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,47),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,54,55,48,32,119,104,101,114,101,54,55,49,32,46,32,116,109,112,54,54,57,54,55,50,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,50),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,54,57,50,32,119,104,101,114,101,54,57,51,32,46,32,116,109,112,54,57,49,54,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,29),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,32,115,49,55,48,56,32,115,50,55,48,57,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,45,99,105,32,115,49,55,50,52,32,115,50,55,50,53,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,61,63,32,115,49,55,52,48,32,115,50,55,52,49,32,115,116,97,114,116,49,55,52,50,32,115,116,97,114,116,50,55,52,51,32,110,55,52,52,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,55,55,56,32,115,116,97,114,116,49,55,56,57,32,115,116,97,114,116,50,55,57,48,32,108,101,110,55,57,49,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,108,101,110,55,56,50,32,37,115,116,97,114,116,49,55,55,53,55,57,53,32,37,115,116,97,114,116,50,55,55,54,55,57,54,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,50,55,56,49,32,37,115,116,97,114,116,49,55,55,53,56,48,48,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,115,116,97,114,116,49,55,56,48,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,37),40,115,117,98,115,116,114,105,110,103,61,63,32,115,49,55,54,54,32,115,50,55,54,55,32,46,32,116,109,112,55,54,53,55,54,56,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,59),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,56,49,56,32,115,50,56,49,57,32,115,116,97,114,116,49,56,50,48,32,115,116,97,114,116,50,56,50,49,32,110,56,50,50,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,56,53,54,32,115,116,97,114,116,49,56,54,55,32,115,116,97,114,116,50,56,54,56,32,108,101,110,56,54,57,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,108,101,110,56,54,48,32,37,115,116,97,114,116,49,56,53,51,56,55,51,32,37,115,116,97,114,116,50,56,53,52,56,55,52,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,50,56,53,57,32,37,115,116,97,114,116,49,56,53,51,56,55,56,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,115,116,97,114,116,49,56,53,56,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,40),40,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,56,52,52,32,115,50,56,52,53,32,46,32,116,109,112,56,52,51,56,52,54,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,27),40,97,100,100,32,102,114,111,109,57,49,48,32,116,111,57,49,49,32,108,97,115,116,57,49,50,41,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,57,52,57,41,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,105,57,49,57,32,108,97,115,116,57,50,48,32,102,114,111,109,57,50,49,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,42),40,115,116,114,105,110,103,45,115,112,108,105,116,32,115,116,114,56,57,53,32,46,32,100,101,108,115,116,114,45,97,110,100,45,102,108,97,103,56,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,50,32,110,50,49,48,49,51,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,49,32,115,115,57,57,56,32,110,57,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,40),40,115,116,114,105,110,103,45,105,110,116,101,114,115,112,101,114,115,101,32,115,116,114,115,57,56,49,32,46,32,116,109,112,57,56,48,57,56,50,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,14),40,102,95,51,52,53,53,32,99,49,48,53,50,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,16),40,105,110,115,116,114,105,110,103,32,115,49,48,52,56,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,105,49,49,48,54,32,106,49,49,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,14),40,102,95,51,54,50,52,32,99,49,48,55,53,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,44),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,32,115,116,114,49,48,52,50,32,102,114,111,109,49,48,52,51,32,46,32,116,111,49,48,52,52,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,115,109,97,112,49,49,52,57,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,41),40,99,111,108,108,101,99,116,32,105,49,49,52,50,32,102,114,111,109,49,49,52,51,32,116,111,116,97,108,49,49,52,52,32,102,115,49,49,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,42,32,115,116,114,49,49,51,54,32,115,109,97,112,49,49,51,55,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,116,111,116,97,108,49,49,56,48,32,112,111,115,49,49,56,49,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,29),40,115,116,114,105,110,103,45,99,104,111,112,32,115,116,114,49,49,55,51,32,108,101,110,49,49,55,52,41,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,99,104,111,109,112,32,115,116,114,49,50,48,50,32,46,32,116,109,112,49,50,48,49,49,50,48,51,41,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,52,49,32,105,49,50,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,108,97,115,116,49,50,53,57,32,110,101,120,116,49,50,54,48,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,27),40,115,111,114,116,101,100,63,32,115,101,113,49,50,50,57,32,108,101,115,115,63,49,50,51,48,41,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,120,49,50,56,55,32,97,49,50,56,56,32,121,49,50,56,57,32,98,49,50,57,48,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,29),40,109,101,114,103,101,32,97,49,50,55,52,32,98,49,50,55,53,32,108,101,115,115,63,49,50,55,54,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,114,49,51,48,56,32,97,49,51,48,57,32,98,49,51,49,48,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,30),40,109,101,114,103,101,33,32,97,49,50,57,54,32,98,49,50,57,55,32,108,101,115,115,63,49,50,57,56,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,12),40,115,116,101,112,32,110,49,51,50,51,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,51,53,55,32,112,49,51,54,51,32,105,49,51,54,52,41};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,25),40,115,111,114,116,33,32,115,101,113,49,51,49,57,32,108,101,115,115,63,49,51,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,24),40,115,111,114,116,32,115,101,113,49,51,55,52,32,108,101,115,115,63,49,51,55,53,41};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,115,49,51,56,57,32,112,101,49,51,57,48,41,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,32),40,98,105,110,97,114,121,45,115,101,97,114,99,104,32,118,101,99,49,51,56,48,32,112,114,111,99,49,51,56,49,41};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,12),40,109,97,107,101,45,113,117,101,117,101,41,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,14),40,113,117,101,117,101,63,32,120,49,52,49,57,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,20),40,113,117,101,117,101,45,101,109,112,116,121,63,32,113,49,52,50,51,41,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,102,105,114,115,116,32,113,49,52,50,55,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,108,97,115,116,32,113,49,52,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,28),40,113,117,101,117,101,45,97,100,100,33,32,113,49,52,53,54,32,100,97,116,117,109,49,52,53,55,41,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,21),40,113,117,101,117,101,45,114,101,109,111,118,101,33,32,113,49,52,55,50,41,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,62,108,105,115,116,32,113,49,52,57,49,41,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,52,57,56,32,108,115,116,49,53,48,52,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,22),40,108,105,115,116,45,62,113,117,101,117,101,32,108,115,116,48,49,52,57,54,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,33),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,33,32,113,49,53,49,57,32,105,116,101,109,49,53,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,12),40,100,111,108,111,111,112,49,53,51,57,41,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,42),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,45,108,105,115,116,33,32,113,49,53,51,48,32,105,116,101,109,108,105,115,116,49,53,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_data_structures_toplevel)
C_externexport void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static C_word C_fcall f_4724(C_word t0);
C_noret_decl(f_4710)
static void C_fcall f_4710(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4614)
static void C_ccall f_4614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4633)
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4547)
static void C_fcall f_4547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_fcall f_4391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_fcall f_4405(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_fcall f_4326(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4230)
static void C_fcall f_4230(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_fcall f_4271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4030)
static void C_fcall f_4030(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3962)
static void C_fcall f_3962(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_fcall f_3914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3786)
static void C_fcall f_3786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3661)
static void C_fcall f_3661(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3694)
static void C_fcall f_3694(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_fcall f_3733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_fcall f_3679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_fcall f_3504(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_fcall f_3450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3461)
static C_word C_fcall f_3461(C_word t0,C_word t1);
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_fcall f_3350(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static C_word C_fcall f_3365(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3238)
static void C_fcall f_3238(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3265)
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_fcall f_3225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3134)
static void C_fcall f_3134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_fcall f_3129(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3124)
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3119)
static void C_fcall f_3119(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3090)
static void C_fcall f_3090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3017)
static void C_fcall f_3017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_fcall f_3012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3007)
static void C_fcall f_3007(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3002)
static void C_fcall f_3002(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2973)
static void C_fcall f_2973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2780)
static void C_fcall f_2780(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2801)
static void C_fcall f_2801(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2651)
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_fcall f_2676(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2610)
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2550)
static void C_fcall f_2550(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_fcall f_2545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2476)
static void C_fcall f_2476(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2511)
static void C_fcall f_2511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_fcall f_2480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2433)
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_fcall f_2395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2220)
static void C_fcall f_2220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_fcall f_2138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2159)
static void C_fcall f_2159(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2088)
static void C_fcall f_2088(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2059)
static void C_fcall f_2059(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2001)
static C_word C_fcall f_2001(C_word t0,C_word t1);
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1905)
static void C_fcall f_1905(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1838)
static void C_fcall f_1838(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1803)
static void C_fcall f_1803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1683)
static void C_fcall f_1683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1650)
static void C_fcall f_1650(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_4710)
static void C_fcall trf_4710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4710(t0,t1);}

C_noret_decl(trf_4633)
static void C_fcall trf_4633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4633(t0,t1,t2);}

C_noret_decl(trf_4547)
static void C_fcall trf_4547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4547(t0,t1);}

C_noret_decl(trf_4391)
static void C_fcall trf_4391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4391(t0,t1);}

C_noret_decl(trf_4405)
static void C_fcall trf_4405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4405(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4405(t0,t1,t2,t3);}

C_noret_decl(trf_4326)
static void C_fcall trf_4326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4326(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4326(t0,t1,t2,t3);}

C_noret_decl(trf_4230)
static void C_fcall trf_4230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4230(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4230(t0,t1,t2);}

C_noret_decl(trf_4271)
static void C_fcall trf_4271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4271(t0,t1);}

C_noret_decl(trf_4098)
static void C_fcall trf_4098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4098(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4098(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4030)
static void C_fcall trf_4030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4030(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4030(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3962)
static void C_fcall trf_3962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3962(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3962(t0,t1,t2,t3);}

C_noret_decl(trf_3914)
static void C_fcall trf_3914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3914(t0,t1,t2);}

C_noret_decl(trf_3786)
static void C_fcall trf_3786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3786(t0,t1,t2,t3);}

C_noret_decl(trf_3661)
static void C_fcall trf_3661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3661(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3661(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3694)
static void C_fcall trf_3694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3694(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3694(t0,t1,t2);}

C_noret_decl(trf_3733)
static void C_fcall trf_3733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3733(t0,t1);}

C_noret_decl(trf_3679)
static void C_fcall trf_3679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3679(t0,t1);}

C_noret_decl(trf_3504)
static void C_fcall trf_3504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3504(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3504(t0,t1,t2,t3);}

C_noret_decl(trf_3450)
static void C_fcall trf_3450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3450(t0,t1);}

C_noret_decl(trf_3350)
static void C_fcall trf_3350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3350(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3350(t0,t1,t2,t3);}

C_noret_decl(trf_3238)
static void C_fcall trf_3238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3238(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3238(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3265)
static void C_fcall trf_3265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3265(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3265(t0,t1,t2);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3218(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3225)
static void C_fcall trf_3225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3225(t0,t1);}

C_noret_decl(trf_3134)
static void C_fcall trf_3134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3134(t0,t1);}

C_noret_decl(trf_3129)
static void C_fcall trf_3129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3129(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3129(t0,t1,t2);}

C_noret_decl(trf_3124)
static void C_fcall trf_3124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3124(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3124(t0,t1,t2,t3);}

C_noret_decl(trf_3119)
static void C_fcall trf_3119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3119(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3119(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3090)
static void C_fcall trf_3090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3090(t0,t1);}

C_noret_decl(trf_3017)
static void C_fcall trf_3017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3017(t0,t1);}

C_noret_decl(trf_3012)
static void C_fcall trf_3012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3012(t0,t1,t2);}

C_noret_decl(trf_3007)
static void C_fcall trf_3007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3007(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3007(t0,t1,t2,t3);}

C_noret_decl(trf_3002)
static void C_fcall trf_3002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3002(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3002(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2973)
static void C_fcall trf_2973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2973(t0,t1);}

C_noret_decl(trf_2780)
static void C_fcall trf_2780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2780(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2780(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2801)
static void C_fcall trf_2801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2801(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2801(t0,t1,t2,t3);}

C_noret_decl(trf_2651)
static void C_fcall trf_2651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2651(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2651(t0,t1,t2,t3);}

C_noret_decl(trf_2676)
static void C_fcall trf_2676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2676(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2676(t0,t1,t2,t3);}

C_noret_decl(trf_2610)
static void C_fcall trf_2610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2610(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2610(t0,t1,t2);}

C_noret_decl(trf_2550)
static void C_fcall trf_2550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2550(t0,t1);}

C_noret_decl(trf_2545)
static void C_fcall trf_2545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2545(t0,t1,t2);}

C_noret_decl(trf_2476)
static void C_fcall trf_2476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2476(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2476(t0,t1,t2,t3);}

C_noret_decl(trf_2511)
static void C_fcall trf_2511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2511(t0,t1,t2);}

C_noret_decl(trf_2480)
static void C_fcall trf_2480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2480(t0,t1);}

C_noret_decl(trf_2433)
static void C_fcall trf_2433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2433(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2433(t0,t1,t2);}

C_noret_decl(trf_2395)
static void C_fcall trf_2395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2395(t0,t1);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2276(t0,t1,t2,t3);}

C_noret_decl(trf_2220)
static void C_fcall trf_2220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2220(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2220(t0,t1,t2);}

C_noret_decl(trf_2138)
static void C_fcall trf_2138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2138(t0,t1,t2,t3);}

C_noret_decl(trf_2159)
static void C_fcall trf_2159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2159(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2159(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2088)
static void C_fcall trf_2088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2088(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2088(t0,t1,t2,t3);}

C_noret_decl(trf_2059)
static void C_fcall trf_2059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2059(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2059(t0,t1,t2);}

C_noret_decl(trf_2023)
static void C_fcall trf_2023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2023(t0,t1,t2);}

C_noret_decl(trf_1905)
static void C_fcall trf_1905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1905(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1905(t0,t1,t2);}

C_noret_decl(trf_1838)
static void C_fcall trf_1838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1838(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1838(t0,t1,t2);}

C_noret_decl(trf_1803)
static void C_fcall trf_1803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1803(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1803(t0,t1,t2);}

C_noret_decl(trf_1683)
static void C_fcall trf_1683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1683(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1683(t0,t1,t2);}

C_noret_decl(trf_1650)
static void C_fcall trf_1650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1650(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1650(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("data_structures_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1020)){
C_save(t1);
C_rereclaim2(1020*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,114);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],8,"identity");
lf[3]=C_h_intern(&lf[3],7,"project");
lf[4]=C_h_intern(&lf[4],7,"conjoin");
lf[5]=C_h_intern(&lf[5],7,"disjoin");
lf[6]=C_h_intern(&lf[6],10,"constantly");
lf[7]=C_h_intern(&lf[7],4,"flip");
lf[8]=C_h_intern(&lf[8],10,"complement");
lf[9]=C_h_intern(&lf[9],7,"compose");
lf[10]=C_h_intern(&lf[10],6,"values");
lf[11]=C_h_intern(&lf[11],1,"o");
lf[12]=C_h_intern(&lf[12],8,"list-of\077");
lf[13]=C_h_intern(&lf[13],7,"list-of");
lf[14]=C_h_intern(&lf[14],4,"noop");
lf[15]=C_h_intern(&lf[15],19,"\003sysundefined-value");
lf[16]=C_h_intern(&lf[16],4,"each");
lf[17]=C_h_intern(&lf[17],4,"any\077");
lf[18]=C_h_intern(&lf[18],5,"none\077");
lf[19]=C_h_intern(&lf[19],7,"always\077");
lf[20]=C_h_intern(&lf[20],6,"never\077");
lf[21]=C_h_intern(&lf[21],12,"left-section");
lf[22]=C_h_intern(&lf[22],10,"\003sysappend");
lf[23]=C_h_intern(&lf[23],17,"\003syscheck-closure");
lf[24]=C_h_intern(&lf[24],7,"reverse");
lf[25]=C_h_intern(&lf[25],13,"right-section");
lf[26]=C_h_intern(&lf[26],5,"atom\077");
lf[27]=C_h_intern(&lf[27],5,"tail\077");
lf[28]=C_h_intern(&lf[28],11,"intersperse");
lf[29]=C_h_intern(&lf[29],7,"butlast");
lf[30]=C_h_intern(&lf[30],7,"flatten");
lf[31]=C_h_intern(&lf[31],4,"chop");
lf[32]=C_h_intern(&lf[32],9,"\003syserror");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid numeric argument");
lf[34]=C_h_intern(&lf[34],4,"join");
lf[35]=C_h_intern(&lf[35],27,"\003syserror-not-a-proper-list");
lf[36]=C_h_intern(&lf[36],8,"compress");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000%bad argument type - not a proper list");
lf[38]=C_h_intern(&lf[38],15,"\003syssignal-hook");
lf[39]=C_h_intern(&lf[39],11,"\000type-error");
lf[40]=C_h_intern(&lf[40],7,"shuffle");
lf[41]=C_h_intern(&lf[41],7,"\003sysmap");
lf[42]=C_h_intern(&lf[42],3,"cdr");
lf[43]=C_h_intern(&lf[43],5,"sort!");
lf[44]=C_h_intern(&lf[44],13,"alist-update!");
lf[45]=C_h_intern(&lf[45],4,"eqv\077");
lf[46]=C_h_intern(&lf[46],3,"eq\077");
lf[47]=C_h_intern(&lf[47],4,"assq");
lf[48]=C_h_intern(&lf[48],4,"assv");
lf[49]=C_h_intern(&lf[49],6,"equal\077");
lf[50]=C_h_intern(&lf[50],5,"assoc");
lf[51]=C_h_intern(&lf[51],9,"alist-ref");
lf[52]=C_h_intern(&lf[52],6,"rassoc");
lf[53]=C_h_intern(&lf[53],37,"\017data-structuresreverse-string-append");
lf[54]=C_h_intern(&lf[54],11,"make-string");
lf[55]=C_h_intern(&lf[55],18,"open-output-string");
lf[56]=C_h_intern(&lf[56],7,"display");
lf[57]=C_h_intern(&lf[57],6,"string");
lf[58]=C_h_intern(&lf[58],17,"get-output-string");
lf[59]=C_h_intern(&lf[59],8,"->string");
lf[60]=C_h_intern(&lf[60],14,"symbol->string");
lf[61]=C_h_intern(&lf[61],18,"\003sysnumber->string");
lf[62]=C_h_intern(&lf[62],13,"string-append");
lf[63]=C_h_intern(&lf[63],4,"conc");
lf[64]=C_h_intern(&lf[64],19,"\003syssubstring-index");
lf[65]=C_h_intern(&lf[65],15,"substring-index");
lf[66]=C_h_intern(&lf[66],22,"\003syssubstring-index-ci");
lf[67]=C_h_intern(&lf[67],18,"substring-index-ci");
lf[68]=C_h_intern(&lf[68],15,"string-compare3");
lf[69]=C_h_intern(&lf[69],18,"string-compare3-ci");
lf[70]=C_h_intern(&lf[70],15,"\003syssubstring=\077");
lf[71]=C_h_intern(&lf[71],11,"substring=\077");
lf[72]=C_h_intern(&lf[72],18,"\003syssubstring-ci=\077");
lf[73]=C_h_intern(&lf[73],14,"substring-ci=\077");
lf[74]=C_h_intern(&lf[74],12,"string-split");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\003\011\012 ");
lf[76]=C_h_intern(&lf[76],13,"\003syssubstring");
lf[77]=C_h_intern(&lf[77],18,"string-intersperse");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[79]=C_h_intern(&lf[79],19,"\003sysallocate-vector");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[81]=C_h_intern(&lf[81],12,"list->string");
lf[82]=C_h_intern(&lf[82],16,"string-translate");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid translation destination");
lf[84]=C_h_intern(&lf[84],17,"string-translate*");
lf[85]=C_h_intern(&lf[85],21,"\003sysfragments->string");
lf[86]=C_h_intern(&lf[86],11,"string-chop");
lf[87]=C_h_intern(&lf[87],12,"string-chomp");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[89]=C_h_intern(&lf[89],7,"sorted\077");
lf[90]=C_h_intern(&lf[90],5,"merge");
lf[91]=C_h_intern(&lf[91],6,"merge!");
lf[92]=C_h_intern(&lf[92],12,"vector->list");
lf[93]=C_h_intern(&lf[93],4,"sort");
lf[94]=C_h_intern(&lf[94],12,"list->vector");
lf[95]=C_h_intern(&lf[95],6,"append");
lf[96]=C_h_intern(&lf[96],13,"binary-search");
lf[97]=C_h_intern(&lf[97],10,"make-queue");
lf[98]=C_h_intern(&lf[98],5,"queue");
lf[99]=C_h_intern(&lf[99],6,"queue\077");
lf[100]=C_h_intern(&lf[100],12,"queue-empty\077");
lf[101]=C_h_intern(&lf[101],11,"queue-first");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[103]=C_h_intern(&lf[103],10,"queue-last");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[105]=C_h_intern(&lf[105],10,"queue-add!");
lf[106]=C_h_intern(&lf[106],13,"queue-remove!");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[108]=C_h_intern(&lf[108],11,"queue->list");
lf[109]=C_h_intern(&lf[109],11,"list->queue");
lf[110]=C_h_intern(&lf[110],16,"queue-push-back!");
lf[111]=C_h_intern(&lf[111],21,"queue-push-back-list!");
lf[112]=C_h_intern(&lf[112],17,"register-feature!");
lf[113]=C_h_intern(&lf[113],15,"data-structures");
C_register_lf2(lf,114,create_ptable());
t2=C_mutate(&lf[0] /* (set! c538 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm: 73   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t3,lf[113]);}

/* k1627 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[213],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! identity ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! project ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! conjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! disjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[6]+1 /* (set! constantly ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1712,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[7]+1 /* (set! flip ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[8]+1 /* (set! complement ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1743,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[9]+1 /* (set! compose ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[11]+1 /* (set! o ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[12]+1 /* (set! list-of? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[13]+1 /* (set! list-of ...) */,*((C_word*)lf[12]+1));
t13=C_mutate((C_word*)lf[14]+1 /* (set! noop ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1871,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[16]+1 /* (set! each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[17]+1 /* (set! any? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[18]+1 /* (set! none? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[19]+1 /* (set! always? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[20]+1 /* (set! never? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[21]+1 /* (set! left-section ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[24]+1);
t21=C_mutate((C_word*)lf[25]+1 /* (set! right-section ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1960,a[2]=t20,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[26]+1 /* (set! atom? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1986,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[27]+1 /* (set! tail? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1989,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[28]+1 /* (set! intersperse ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[29]+1 /* (set! butlast ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2050,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[30]+1 /* (set! flatten ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t27=*((C_word*)lf[24]+1);
t28=C_mutate((C_word*)lf[31]+1 /* (set! chop ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2123,a[2]=t27,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t29=C_mutate((C_word*)lf[34]+1 /* (set! join ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2208,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[36]+1 /* (set! compress ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[40]+1 /* (set! shuffle ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[44]+1 /* (set! alist-update! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[51]+1 /* (set! alist-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2474,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[52]+1 /* (set! rassoc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2598,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[53]+1 /* (set! reverse-string-append ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2648,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t36=*((C_word*)lf[55]+1);
t37=*((C_word*)lf[56]+1);
t38=*((C_word*)lf[57]+1);
t39=*((C_word*)lf[58]+1);
t40=C_mutate((C_word*)lf[59]+1 /* (set! ->string ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2725,a[2]=t36,a[3]=t37,a[4]=t39,a[5]=t38,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t41=*((C_word*)lf[62]+1);
t42=C_mutate((C_word*)lf[63]+1 /* (set! conc ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t41,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t43=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
t44=C_mutate((C_word*)lf[64]+1 /* (set! substring-index ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2827,a[2]=t43,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp));
t45=C_mutate((C_word*)lf[66]+1 /* (set! substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2836,a[2]=t43,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[65]+1 /* (set! substring-index ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[67]+1 /* (set! substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[68]+1 /* (set! string-compare3 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2901,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[69]+1 /* (set! string-compare3-ci ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[70]+1 /* (set! substring=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1 /* (set! substring=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[72]+1 /* (set! substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[73]+1 /* (set! substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3117,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[74]+1 /* (set! string-split ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3197,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[77]+1 /* (set! string-intersperse ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3332,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t56=*((C_word*)lf[54]+1);
t57=*((C_word*)lf[81]+1);
t58=C_mutate((C_word*)lf[82]+1 /* (set! string-translate ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3447,a[2]=t57,a[3]=t56,a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp));
t59=C_mutate((C_word*)lf[84]+1 /* (set! string-translate* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[86]+1 /* (set! string-chop ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3771,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[87]+1 /* (set! string-chomp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3835,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[89]+1 /* (set! sorted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3887,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[90]+1 /* (set! merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3996,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[91]+1 /* (set! merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4095,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[43]+1 /* (set! sort! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4227,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[93]+1 /* (set! sort ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4360,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t67=*((C_word*)lf[94]+1);
t68=C_mutate((C_word*)lf[96]+1 /* (set! binary-search ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4387,a[2]=t67,a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp));
t69=C_mutate((C_word*)lf[97]+1 /* (set! make-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4470,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[99]+1 /* (set! queue? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4476,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[100]+1 /* (set! queue-empty? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4482,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[101]+1 /* (set! queue-first ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4495,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[103]+1 /* (set! queue-last ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4516,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[105]+1 /* (set! queue-add! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4537,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[106]+1 /* (set! queue-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4569,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[108]+1 /* (set! queue->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4605,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[109]+1 /* (set! list->queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4614,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[110]+1 /* (set! queue-push-back! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4668,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[111]+1 /* (set! queue-push-back-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t80=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t80+1)))(2,t80,C_SCHEME_UNDEFINED);}

/* queue-push-back-list! in k1627 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4697,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[98],lf[111]);
t5=(C_word)C_i_check_list_2(t3,lf[111]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4707,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* data-structures.scm: 908  append */
t8=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t3,t7);}

/* k4705 in queue-push-back-list! in k1627 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_4710(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4724,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
t5=t2;
f_4710(t5,f_4724(t1));}}

/* doloop1539 in k4705 in queue-push-back-list! in k1627 */
static C_word C_fcall f_4724(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* k4708 in k4705 in queue-push-back-list! in k1627 */
static void C_fcall f_4710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1));}

/* queue-push-back! in k1627 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4668,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[98],lf[110]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_i_setslot(t2,C_fix(1),t6);
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?(C_word)C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED));}

/* list->queue in k1627 */
static void C_ccall f_4614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4614,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[109]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4625,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_4625(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4633,a[2]=t2,a[3]=t7,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4633(t9,t4,t2);}}

/* doloop1498 in list->queue in k1627 */
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4633,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4643,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* data-structures.scm: 884  ##sys#error-not-a-proper-list */
t8=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[109]);}
else{
t8=t5;
f_4643(2,t8,C_SCHEME_UNDEFINED);}}}

/* k4641 in doloop1498 in list->queue in k1627 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4633(t3,((C_word*)t0)[2],t2);}

/* k4623 in list->queue in k1627 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[98],((C_word*)t0)[2],t1));}

/* queue->list in k1627 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4605,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[108]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k1627 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4569,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[106]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4579,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 862  ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[106],lf[107],t2);}
else{
t7=t5;
f_4579(2,t7,C_SCHEME_UNDEFINED);}}

/* k4577 in queue-remove! in k1627 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(((C_word*)t0)[4],C_fix(0)));}

/* queue-add! in k1627 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4537,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[98],lf[105]);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4547,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t7);
if(C_truep(t8)){
t9=t6;
f_4547(t9,(C_word)C_i_setslot(t2,C_fix(1),t5));}
else{
t9=(C_word)C_slot(t2,C_fix(2));
t10=t6;
f_4547(t10,(C_word)C_i_setslot(t9,C_fix(1),t5));}}

/* k4545 in queue-add! in k1627 */
static void C_fcall f_4547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k1627 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4516,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[103]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4526,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 843  ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[103],lf[104],t2);}
else{
t7=t5;
f_4526(2,t7,C_SCHEME_UNDEFINED);}}

/* k4524 in queue-last in k1627 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-first in k1627 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4495,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[101]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 832  ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[101],lf[102],t2);}
else{
t7=t5;
f_4505(2,t7,C_SCHEME_UNDEFINED);}}

/* k4503 in queue-first in k1627 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-empty? in k1627 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4482,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[100]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* queue? in k1627 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4476,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[98]));}

/* make-queue in k1627 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[98],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* binary-search in k1627 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4387,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4391,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4465,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 789  list->vector */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_4391(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[96]));}}

/* k4463 in binary-search in k1627 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4391(t3,t2);}

/* k4389 in binary-search in k1627 */
static void C_fcall f_4391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4391,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li126),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4405(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k4389 in binary-search in k1627 */
static void C_fcall f_4405(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4405,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_divide(t4,C_fix(2));
t6=(C_word)C_fixnum_plus(t2,t5);
t7=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4415,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 797  proc */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t7);}

/* k4413 in loop in k4389 in binary-search in k1627 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 799  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4405(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 800  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4405(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k1627 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4360,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4374,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4378,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 779  vector->list */
t6=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4385,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 780  append */
t5=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k4383 in sort in k1627 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 780  sort! */
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4376 in sort in k1627 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 779  sort! */
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4372 in sort in k1627 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 779  list->vector */
t2=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k1627 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4227,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4230,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=((C_word)li122),tmp=(C_word)a,a+=6,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_i_vector_length(((C_word*)t4)[1]);
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4317,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 762  vector->list */
t11=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* data-structures.scm: 768  step */
t9=((C_word*)t6)[1];
f_4230(t9,t1,t8);}}

/* k4315 in sort! in k1627 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 763  step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4230(t4,t3,((C_word*)t0)[2]);}

/* k4322 in k4315 in sort! in k1627 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4326,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4326(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* doloop1357 in k4322 in k4315 in sort! in k1627 */
static void C_fcall f_4326(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4326,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_vector_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k1627 */
static void C_fcall f_4230(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4230,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4281,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 747  less? */
t10=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k4279 in step in sort! in k1627 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_car(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
f_4271(t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_4271(t2,C_SCHEME_UNDEFINED);}}

/* k4269 in step in sort! in k1627 */
static void C_fcall f_4271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k4238 in step in sort! in k1627 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 738  step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4230(t3,t2,t1);}

/* k4241 in k4238 in step in sort! in k1627 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 740  step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4230(t4,t3,t2);}

/* k4247 in k4241 in k4238 in step in sort! in k1627 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 741  merge! */
t2=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k1627 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4095,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4098,a[2]=t4,a[3]=t6,a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4177,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* data-structures.scm: 715  less? */
t11=t4;
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}}}

/* k4175 in merge! in k1627 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_4180(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* data-structures.scm: 718  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4098(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_4200(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[4]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 723  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4098(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k4198 in k4175 in merge! in k1627 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4178 in k4175 in merge! in k1627 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k1627 */
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4098,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_car(t3);
/* data-structures.scm: 700  less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k4103 in loop in merge! in k1627 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[5],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* data-structures.scm: 705  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4098(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[5]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 711  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4098(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k1627 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3996,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4030,a[2]=t4,a[3]=t10,a[4]=((C_word)li118),tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_4030(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k1627 */
static void C_fcall f_4030(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4030,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 683  less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t4,t2);}

/* k4035 in loop in merge in k1627 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* data-structures.scm: 686  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4030(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* data-structures.scm: 690  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4030(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k4083 in k4035 in loop in merge in k1627 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4055 in k4035 in loop in merge in k1627 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k1627 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3887,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3914,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=((C_word)li115),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3914(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3962,a[2]=t3,a[3]=t7,a[4]=((C_word)li116),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3962(t9,t1,t4,t5);}}}

/* loop in sorted? in k1627 */
static void C_fcall f_3962(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3962,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t3);
/* data-structures.scm: 666  less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}}

/* k3988 in loop in sorted? in k1627 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 667  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3962(t4,((C_word*)t0)[4],t2,t3);}}

/* doloop1241 in sorted? in k1627 */
static void C_fcall f_3914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3914,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_3924(2,t5,t3);}
else{
t5=(C_word)C_i_vector_ref(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[3],t6);
/* data-structures.scm: 660  less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t4,t5,t7);}}

/* k3922 in doloop1241 in sorted? in k1627 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_3914(t3,((C_word*)t0)[5],t2);}}

/* string-chomp in k1627 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3835r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3835r(t0,t1,t2,t3);}}

static void C_ccall f_3835r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3839,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3839(2,t5,lf[88]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3839(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3837 in string-chomp in k1627 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[87]);
t3=(C_word)C_i_check_string_2(t1,lf[87]);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
t5=(C_word)C_block_size(t1);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_fixnum_greater_or_equal_p(t4,t5);
t8=(C_truep(t7)?(C_word)C_substring_compare(((C_word*)t0)[3],t1,t6,C_fix(0),t5):C_SCHEME_FALSE);
if(C_truep(t8)){
/* data-structures.scm: 627  ##sys#substring */
t9=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t6);}
else{
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}}

/* string-chop in k1627 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3771,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[86]);
t5=(C_word)C_i_check_exact_2(t3,lf[86]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3786,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=((C_word)li112),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3786(t10,t1,t6,C_fix(0));}

/* loop in string-chop in k1627 */
static void C_fcall f_3786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3786,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(t3,t2);
/* data-structures.scm: 613  ##sys#substring */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
/* data-structures.scm: 614  ##sys#substring */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k3815 in loop in string-chop in k1627 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3821,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* data-structures.scm: 614  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3786(t5,t2,t3,t4);}

/* k3819 in k3815 in loop in string-chop in k1627 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3804 in loop in string-chop in k1627 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k1627 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3649,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[84]);
t5=(C_word)C_i_check_list_2(t3,lf[84]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3661,a[2]=t3,a[3]=t8,a[4]=t2,a[5]=t6,a[6]=((C_word)li110),tmp=(C_word)a,a+=7,tmp));
/* data-structures.scm: 602  collect */
t10=((C_word*)t8)[1];
f_3661(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k1627 */
static void C_fcall f_3661(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3661,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3675,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3689,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 584  ##sys#substring */
t10=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_3679(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3694,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,a[9]=((C_word)li109),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3694(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k1627 */
static void C_fcall f_3694(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3694,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 588  collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3661(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3733,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3759,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 596  ##sys#substring */
t10=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_3733(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_i_cdr(t2);
/* data-structures.scm: 601  loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k3757 in loop in collect in string-translate* in k1627 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3733(t4,t3);}

/* k3731 in loop in collect in string-translate* in k1627 */
static void C_fcall f_3733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3733,NULL,2,t0,t1);}
t2=(C_word)C_i_string_length(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* data-structures.scm: 597  collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3661(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k3687 in collect in string-translate* in k1627 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3679(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k3677 in collect in string-translate* in k1627 */
static void C_fcall f_3679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 582  reverse */
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3673 in collect in string-translate* in k1627 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 580  ##sys#fragments->string */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k1627 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr4r,(void*)f_3447r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3447r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3447r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(14);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_3484(2,t7,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3624,a[2]=t3,a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3641,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 538  list->string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_check_string_2(t3,lf[82]);
/* data-structures.scm: 541  instring */
f_3450(t6,t3);}}}

/* k3639 in string-translate in k1627 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 538  instring */
f_3450(((C_word*)t0)[2],t1);}

/* f_3624 in string-translate in k1627 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3624,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k3482 in string-translate in k1627 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_3487(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* data-structures.scm: 546  list->string */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t4=(C_word)C_i_check_string_2(t3,lf[82]);
t5=t2;
f_3487(2,t5,t3);}}}
else{
t3=t2;
f_3487(2,t3,C_SCHEME_FALSE);}}

/* k3485 in k3482 in string-translate in k1627 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[82]);
t5=(C_word)C_block_size(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 553  make-string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3497 in k3485 in k3482 in string-translate in k1627 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word)li106),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_3504(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k3497 in k3485 in k3482 in string-translate in k1627 */
static void C_fcall f_3504(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3504,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* data-structures.scm: 557  ##sys#substring */
t4=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[7],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[6],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3523,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* data-structures.scm: 560  from */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}

/* k3521 in loop in k3497 in k3485 in k3482 in string-translate in k1627 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[9];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 567  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3504(t7,((C_word*)t0)[4],t5,t6);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
/* data-structures.scm: 569  ##sys#error */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[82],lf[83],((C_word*)t0)[6],((C_word*)t0)[9]);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],(C_word)C_subchar(((C_word*)t0)[9],t1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 572  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3504(t7,((C_word*)t0)[4],t5,t6);}}}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* data-structures.scm: 564  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3504(t5,((C_word*)t0)[4],t4,((C_word*)t0)[7]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 563  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3504(t6,((C_word*)t0)[4],t4,t5);}}

/* instring in string-translate in k1627 */
static void C_fcall f_3450(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3450,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3455,a[2]=t2,a[3]=t3,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp));}

/* f_3455 in instring in string-translate in k1627 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3455,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3461(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_3461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k1627 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3332r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3332r(t0,t1,t2,t3);}}

static void C_ccall f_3332r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3336,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3336(2,t5,lf[80]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3336(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3334 in string-intersperse in k1627 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3336,2,t0,t1);}
t2=(C_word)C_i_check_list_2(((C_word*)t0)[3],lf[77]);
t3=(C_word)C_i_check_string_2(t1,lf[77]);
t4=(C_word)C_block_size(t1);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3350,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3350(t8,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* loop1 in k3334 in string-intersperse in k1627 */
static void C_fcall f_3350(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3350,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[78]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_fixnum_difference(t3,((C_word*)t0)[3]);
/* data-structures.scm: 501  ##sys#allocate-vector */
t6=*((C_word*)lf[79]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_i_check_string_2(t5,lf[77]);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t5);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],t3);
t10=(C_word)C_fixnum_plus(t8,t9);
/* data-structures.scm: 516  loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* data-structures.scm: 518  ##sys#error-not-a-proper-list */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k3358 in loop1 in k3334 in string-intersperse in k1627 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_3365(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k3358 in loop1 in k3334 in string-intersperse in k1627 */
static C_word C_fcall f_3365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
C_stack_check;
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k1627 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3197r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3197r(t0,t1,t2,t3);}}

static void C_ccall f_3197r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(20);
t4=(C_word)C_i_check_string_2(t2,lf[74]);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?lf[75]:(C_word)C_i_vector_ref(t3,C_fix(0)));
t7=(C_word)C_block_size(t3);
t8=(C_word)C_eqp(t7,C_fix(2));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_string_2(t6,lf[74]);
t12=(C_word)C_block_size(t6);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3218,a[2]=t2,a[3]=t14,a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3238,a[2]=t6,a[3]=t17,a[4]=t12,a[5]=t2,a[6]=t15,a[7]=t9,a[8]=t14,a[9]=t10,a[10]=((C_word)li98),tmp=(C_word)a,a+=11,tmp));
t19=((C_word*)t17)[1];
f_3238(t19,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k1627 */
static void C_fcall f_3238(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3238,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3248,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* data-structures.scm: 477  add */
t8=((C_word*)t0)[6];
f_3218(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_3248(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3265,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],a[12]=((C_word)li97),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_3265(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k1627 */
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3265,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* data-structures.scm: 482  loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_3238(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3304,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 486  add */
t8=((C_word*)t0)[3];
f_3218(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* data-structures.scm: 487  loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_3238(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* data-structures.scm: 488  scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k3302 in scan in loop in string-split in k1627 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 486  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3238(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k3246 in loop in string-split in k1627 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k1627 */
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3233,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 470  ##sys#substring */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k3231 in add in string-split in k1627 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3233,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3225,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_3225(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_3225(t5,t4);}}

/* k3223 in k3231 in add in string-split in k1627 */
static void C_fcall f_3225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k1627 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3117r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3117r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3117r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3119,a[2]=t3,a[3]=t2,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3124,a[2]=t5,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3129,a[2]=t6,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3134,a[2]=t7,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1858881 */
t9=t8;
f_3134(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2859877 */
t11=t7;
f_3129(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len860872 */
t13=t6;
f_3124(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body856866 */
t15=t5;
f_3119(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1858 in substring-ci=? in k1627 */
static void C_fcall f_3134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3134,NULL,2,t0,t1);}
/* def-start2859877 */
t2=((C_word*)t0)[2];
f_3129(t2,t1,C_fix(0));}

/* def-start2859 in substring-ci=? in k1627 */
static void C_fcall f_3129(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3129,NULL,3,t0,t1,t2);}
/* def-len860872 */
t3=((C_word*)t0)[2];
f_3124(t3,t1,t2,C_fix(0));}

/* def-len860 in substring-ci=? in k1627 */
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3124,NULL,4,t0,t1,t2,t3);}
/* body856866 */
t4=((C_word*)t0)[2];
f_3119(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body856 in substring-ci=? in k1627 */
static void C_fcall f_3119(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3119,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 455  ##sys#substring-ci=? */
((C_proc7)C_retrieve_proc(*((C_word*)lf[72]+1)))(7,*((C_word*)lf[72]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring-ci=? in k1627 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_3080,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[73]);
t8=(C_word)C_i_check_string_2(t3,lf[73]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3090,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_3090(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_3090(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k3088 in ##sys#substring-ci=? in k1627 */
static void C_fcall f_3090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[73]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[73]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* substring=? in k1627 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3000r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3000r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3000r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3002,a[2]=t3,a[3]=t2,a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3007,a[2]=t5,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3012,a[2]=t6,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3017,a[2]=t7,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1780803 */
t9=t8;
f_3017(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2781799 */
t11=t7;
f_3012(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len782794 */
t13=t6;
f_3007(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body778788 */
t15=t5;
f_3002(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1780 in substring=? in k1627 */
static void C_fcall f_3017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3017,NULL,2,t0,t1);}
/* def-start2781799 */
t2=((C_word*)t0)[2];
f_3012(t2,t1,C_fix(0));}

/* def-start2781 in substring=? in k1627 */
static void C_fcall f_3012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3012,NULL,3,t0,t1,t2);}
/* def-len782794 */
t3=((C_word*)t0)[2];
f_3007(t3,t1,t2,C_fix(0));}

/* def-len782 in substring=? in k1627 */
static void C_fcall f_3007(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3007,NULL,4,t0,t1,t2,t3);}
/* body778788 */
t4=((C_word*)t0)[2];
f_3002(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body778 in substring=? in k1627 */
static void C_fcall f_3002(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3002,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 441  ##sys#substring=? */
((C_proc7)C_retrieve_proc(*((C_word*)lf[70]+1)))(7,*((C_word*)lf[70]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring=? in k1627 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2963,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[71]);
t8=(C_word)C_i_check_string_2(t3,lf[71]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2973,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2973(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_2973(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k2971 in ##sys#substring=? in k1627 */
static void C_fcall f_2973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[71]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[71]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* string-compare3-ci in k1627 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2932,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[69]);
t5=(C_word)C_i_check_string_2(t3,lf[69]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_string_compare_case_insensitive(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* string-compare3 in k1627 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2901,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[68]);
t5=(C_word)C_i_check_string_2(t3,lf[68]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_mem_compare(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* substring-index-ci in k1627 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2873r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2873r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2873r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2877,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2877(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2877(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2875 in substring-index-ci in k1627 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 400  ##sys#substring-index-ci */
((C_proc5)C_retrieve_proc(*((C_word*)lf[66]+1)))(5,*((C_word*)lf[66]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* substring-index in k1627 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2845r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2845r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2845r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2849,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2849(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2849(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2847 in substring-index in k1627 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 397  ##sys#substring-index */
((C_proc5)C_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#substring-index-ci in k1627 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2836,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=t3,a[3]=t2,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 391  traverse */
f_2780(t1,t2,t3,t4,t5,lf[67]);}

/* a2841 in ##sys#substring-index-ci in k1627 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2842,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* ##sys#substring-index in k1627 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2827,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2833,a[2]=t3,a[3]=t2,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 385  traverse */
f_2780(t1,t2,t3,t4,t5,lf[65]);}

/* a2832 in ##sys#substring-index in k1627 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2833,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k1627 */
static void C_fcall f_2780(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2780,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,t6);
t8=(C_word)C_i_check_string_2(t3,t6);
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_exact_2(t4,t6);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2801,a[2]=t10,a[3]=t5,a[4]=t13,a[5]=t9,a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_2801(t15,t1,t4,t10);}

/* loop in traverse in k1627 */
static void C_fcall f_2801(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2801,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 379  test */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k2812 in loop in traverse in k1627 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 381  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2801(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k1627 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2770r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2770r(t0,t1,t2);}}

static void C_ccall f_2770r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[59]+1),t2);}

/* k2776 in conc in k1627 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k1627 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2725,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* data-structures.scm: 354  symbol->string */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
/* data-structures.scm: 355  string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* data-structures.scm: 356  ##sys#number->string */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2762,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 358  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}}}}

/* k2760 in ->string in k1627 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2765,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 359  display */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2763 in k2760 in ->string in k1627 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 360  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##data-structures#reverse-string-append in k1627 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2648,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2651,a[2]=t4,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
/* data-structures.scm: 343  rev-string-append */
t6=((C_word*)t4)[1];
f_2651(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##data-structures#reverse-string-append in k1627 */
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2651,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2667,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* data-structures.scm: 334  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* data-structures.scm: 341  make-string */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k2665 in rev-string-append in ##data-structures#reverse-string-append in k1627 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2676,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2676(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k2665 in rev-string-append in ##data-structures#reverse-string-append in k1627 */
static void C_fcall f_2676(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2676,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* data-structures.scm: 339  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* rassoc in k1627 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2598r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2598r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2598r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_list_2(t3,lf[52]);
t6=(C_word)C_notvemptyp(t4);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t4,C_fix(0)):*((C_word*)lf[45]+1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2610,a[2]=t2,a[3]=t7,a[4]=t9,a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2610(t11,t1,t3);}

/* loop in rassoc in k1627 */
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2610,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[52]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 320  tst */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2627 in loop in rassoc in k1627 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 322  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2610(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k1627 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_2474r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2474r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2476,a[2]=t3,a[3]=t2,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2545,a[2]=t5,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=t6,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp484528 */
t8=t7;
f_2550(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default485524 */
t10=t6;
f_2545(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body482491 */
t12=t5;
f_2476(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-cmp484 in alist-ref in k1627 */
static void C_fcall f_2550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2550,NULL,2,t0,t1);}
/* def-default485524 */
t2=((C_word*)t0)[2];
f_2545(t2,t1,*((C_word*)lf[45]+1));}

/* def-default485 in alist-ref in k1627 */
static void C_fcall f_2545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2545,NULL,3,t0,t1,t2);}
/* body482491 */
t3=((C_word*)t0)[2];
f_2476(t3,t1,t2,C_SCHEME_FALSE);}

/* body482 in alist-ref in k1627 */
static void C_fcall f_2476(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2476,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[46]+1),t2);
if(C_truep(t5)){
t6=t4;
f_2480(t6,*((C_word*)lf[47]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[45]+1),t2);
if(C_truep(t6)){
t7=t4;
f_2480(t7,*((C_word*)lf[48]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[49]+1),t2);
t8=t4;
f_2480(t8,(C_truep(t7)?*((C_word*)lf[50]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=t2,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp)));}}}

/* f_2505 in body482 in alist-ref in k1627 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2505,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2511,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2511(t7,t1,t3);}

/* loop */
static void C_fcall f_2511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2511,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 305  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2527(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2525 in loop */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 307  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2511(t3,((C_word*)t0)[5],t2);}}

/* k2478 in body482 in alist-ref in k1627 */
static void C_fcall f_2480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2480,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 308  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2481 in k2478 in body482 in alist-ref in k1627 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k1627 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2388r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2388r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2388r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t5,C_fix(0)):*((C_word*)lf[45]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2395,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[46]+1),t7);
if(C_truep(t9)){
t10=t8;
f_2395(t10,*((C_word*)lf[47]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[45]+1),t7);
if(C_truep(t10)){
t11=t8;
f_2395(t11,*((C_word*)lf[48]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[49]+1),t7);
t12=t8;
f_2395(t12,(C_truep(t11)?*((C_word*)lf[50]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2427,a[2]=t7,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp)));}}}

/* f_2427 in alist-update! in k1627 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2427,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2433,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2433(t7,t1,t3);}

/* loop */
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2433,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 286  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2449(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2447 in loop */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 288  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2433(t3,((C_word*)t0)[5],t2);}}

/* k2393 in alist-update! in k1627 */
static void C_fcall f_2395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2395,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 289  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2396 in k2393 in alist-update! in k1627 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k1627 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2347,4,t0,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2362,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2378,a[2]=t4,a[3]=t3,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
/* map */
t8=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}

/* a2377 in shuffle in k1627 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2378,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 270  random */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2384 in a2377 in shuffle in k1627 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2360 in shuffle in k1627 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm: 270  sort! */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2363 in k2360 in shuffle in k1627 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2364,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k2356 in shuffle in k1627 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[42]+1),t1);}

/* compress in k1627 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2267,4,t0,t1,t2,t3);}
t4=lf[37];
t5=(C_word)C_i_check_list_2(t3,lf[36]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2276,a[2]=t4,a[3]=t7,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2276(t9,t1,t2,t3);}

/* loop in compress in k1627 */
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2276,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 262  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 263  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
/* data-structures.scm: 261  ##sys#signal-hook */
t4=*((C_word*)lf[38]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[39],lf[36],((C_word*)t0)[2],t3);}}
else{
/* data-structures.scm: 259  ##sys#signal-hook */
t4=*((C_word*)lf[38]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[39],lf[36],((C_word*)t0)[2],t2);}}}

/* k2316 in loop in compress in k1627 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k1627 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2208r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2208r(t0,t1,t2,t3);}}

static void C_ccall f_2208r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[34]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2220,a[2]=t8,a[3]=t5,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2220(t10,t1,t2);}

/* loop in join in k1627 */
static void C_fcall f_2220(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2220,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 250  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}
else{
/* data-structures.scm: 244  ##sys#error-not-a-proper-list */
t3=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}}

/* k2253 in loop in join in k1627 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 250  ##sys#append */
t2=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k1627 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2123,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[31]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2130,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* data-structures.scm: 225  ##sys#error */
t6=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[31],lf[33],t3);}
else{
t6=t5;
f_2130(2,t6,C_SCHEME_UNDEFINED);}}

/* k2128 in chop in k1627 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2138(t6,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* loop in k2128 in chop in k1627 */
static void C_fcall f_2138(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2138,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2159,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word)li48),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_2159(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* doloop338 in loop in k2128 in chop in k1627 */
static void C_fcall f_2159(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2159,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2173,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 236  reverse */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k2171 in doloop338 in loop in k2128 in chop in k1627 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* data-structures.scm: 236  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2138(t4,t2,((C_word*)t0)[2],t3);}

/* k2175 in k2171 in doloop338 in loop in k2128 in chop in k1627 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k1627 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2082r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2082r(t0,t1,t2);}}

static void C_ccall f_2082r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=t4,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2088(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k1627 */
static void C_fcall f_2088(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2088,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2114,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 217  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 218  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k2119 in loop in flatten in k1627 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2112 in loop in flatten in k1627 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 217  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2088(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k1627 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2050,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[29]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2059,a[2]=t5,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2059(t7,t1,t2);}

/* loop in butlast in k1627 */
static void C_fcall f_2059(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2059,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 207  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2078 in loop in butlast in k1627 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k1627 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2017,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2023,a[2]=t5,a[3]=t3,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2023(t7,t1,t2);}

/* loop in intersperse in k1627 */
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2023,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2048,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 200  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k2046 in loop in intersperse in k1627 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k1627 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1989,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[27]);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2001,a[2]=t2,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_2001(t6,t3));}}

/* loop in tail? in k1627 */
static C_word C_fcall f_2001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k1627 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1986,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* right-section in k1627 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1960r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1960r(t0,t1,t2,t3);}}

static void C_ccall f_1960r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1964,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 174  ##sys#check-closure */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[25]);}

/* k1962 in right-section in k1627 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 175  ##sys#reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1965 in k1962 in right-section in k1627 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1968,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li37),tmp=(C_word)a,a+=6,tmp));}

/* f_1968 in k1965 in k1962 in right-section in k1627 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_1968r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1968r(t0,t1,t2);}}

static void C_ccall f_1968r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 177  ##sys#reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1982 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 177  ##sys#append */
t2=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1978 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 177  ##sys#reverse */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1974 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* left-section in k1627 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1945r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1945r(t0,t1,t2,t3);}}

static void C_ccall f_1945r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1949,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 167  ##sys#check-closure */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[21]);}

/* k1947 in left-section in k1627 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));}

/* f_1950 in k1947 in left-section in k1627 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1950r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1950r(t0,t1,t2);}}

static void C_ccall f_1950r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 169  ##sys#append */
t4=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k1956 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* never? in k1627 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* always? in k1627 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* none? in k1627 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1936,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* any? in k1627 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1933,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* each in k1627 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1877r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1877r(t0,t1,t2);}}

static void C_ccall f_1877r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1899,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp)));}}

/* f_1899 in each in k1627 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_1899r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1899r(t0,t1,t2);}}

static void C_ccall f_1899r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1905,a[2]=t4,a[3]=t2,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1905(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1905(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1905,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
C_apply(4,0,t1,t3,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1924,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,t3,((C_word*)t0)[3]);}}

/* k1922 in loop */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 156  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1905(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_1885 in each in k1627 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[15]+1));}

/* noop in k1627 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[15]+1));}

/* list-of? in k1627 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1830,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1832,a[2]=t2,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));}

/* f_1832 in list-of? in k1627 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1832,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1838(t6,t1,t2);}

/* loop */
static void C_fcall f_1838(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1838,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1857,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* data-structures.scm: 137  pred */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k1855 in loop */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 137  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1838(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* o in k1627 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1791r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1791r(t0,t1,t2);}}

static void C_ccall f_1791r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[2]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1803,a[2]=t4,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1803(t6,t1,t2);}}

/* loop in o in k1627 */
static void C_fcall f_1803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1803,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1817,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp)));}

/* f_1817 in loop in o in k1627 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1817,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1825,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 130  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1803(t5,t4,((C_word*)t0)[2]);}

/* k1826 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1823 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 130  h */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* compose in k1627 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1755r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1755r(t0,t1,t2);}}

static void C_ccall f_1755r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1758,a[2]=t4,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[10]+1));}
else{
C_apply(4,0,t1,((C_word*)t4)[1],t2);}}

/* rec in compose in k1627 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1758r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1758r(t0,t1,t2,t3);}}

static void C_ccall f_1758r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1766,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp)));}

/* f_1766 in rec in compose in k1627 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1766r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1766r(t0,t1,t2);}}

static void C_ccall f_1766r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 115  call-with-values */
C_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a1771 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1778 in a1771 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k1627 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1743,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1745,a[2]=t2,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));}

/* f_1745 in complement in k1627 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1745r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1745r(t0,t1,t2);}}

static void C_ccall f_1745r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1753,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k1751 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k1627 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1735,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1737,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));}

/* f_1737 in flip in k1627 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1737,4,t0,t1,t2,t3);}
/* data-structures.scm: 104  proc */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* constantly in k1627 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1712r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1712r(t0,t1,t2);}}

static void C_ccall f_1712r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1723,a[2]=t5,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1725,a[2]=t2,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));}}

/* f_1725 in constantly in k1627 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_1723 in constantly in k1627 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k1627 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1675r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1675r(t0,t1,t2);}}

static void C_ccall f_1675r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1677,a[2]=t2,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp));}

/* f_1677 in disjoin in k1627 */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1677,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1683,a[2]=t2,a[3]=t4,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1683(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1683,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[2]);}}

/* k1691 in loop */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 96   loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1683(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k1627 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1642r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1642r(t0,t1,t2);}}

static void C_ccall f_1642r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=t2,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));}

/* f_1644 in conjoin in k1627 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1644,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1650,a[2]=t2,a[3]=t4,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1650(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1650(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1650,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1663,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[2]);}}

/* k1661 in loop */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 89   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1650(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k1627 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1634,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1636,a[2]=t2,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));}

/* f_1636 in project in k1627 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1636r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1636r(t0,t1,t2);}}

static void C_ccall f_1636r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,((C_word*)t0)[2]));}

/* identity in k1627 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1631,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[237] = {
{"toplevel:data_structures_scm",(void*)C_data_structures_toplevel},
{"f_1629:data_structures_scm",(void*)f_1629},
{"f_4697:data_structures_scm",(void*)f_4697},
{"f_4707:data_structures_scm",(void*)f_4707},
{"f_4724:data_structures_scm",(void*)f_4724},
{"f_4710:data_structures_scm",(void*)f_4710},
{"f_4668:data_structures_scm",(void*)f_4668},
{"f_4614:data_structures_scm",(void*)f_4614},
{"f_4633:data_structures_scm",(void*)f_4633},
{"f_4643:data_structures_scm",(void*)f_4643},
{"f_4625:data_structures_scm",(void*)f_4625},
{"f_4605:data_structures_scm",(void*)f_4605},
{"f_4569:data_structures_scm",(void*)f_4569},
{"f_4579:data_structures_scm",(void*)f_4579},
{"f_4537:data_structures_scm",(void*)f_4537},
{"f_4547:data_structures_scm",(void*)f_4547},
{"f_4516:data_structures_scm",(void*)f_4516},
{"f_4526:data_structures_scm",(void*)f_4526},
{"f_4495:data_structures_scm",(void*)f_4495},
{"f_4505:data_structures_scm",(void*)f_4505},
{"f_4482:data_structures_scm",(void*)f_4482},
{"f_4476:data_structures_scm",(void*)f_4476},
{"f_4470:data_structures_scm",(void*)f_4470},
{"f_4387:data_structures_scm",(void*)f_4387},
{"f_4465:data_structures_scm",(void*)f_4465},
{"f_4391:data_structures_scm",(void*)f_4391},
{"f_4405:data_structures_scm",(void*)f_4405},
{"f_4415:data_structures_scm",(void*)f_4415},
{"f_4360:data_structures_scm",(void*)f_4360},
{"f_4385:data_structures_scm",(void*)f_4385},
{"f_4378:data_structures_scm",(void*)f_4378},
{"f_4374:data_structures_scm",(void*)f_4374},
{"f_4227:data_structures_scm",(void*)f_4227},
{"f_4317:data_structures_scm",(void*)f_4317},
{"f_4324:data_structures_scm",(void*)f_4324},
{"f_4326:data_structures_scm",(void*)f_4326},
{"f_4230:data_structures_scm",(void*)f_4230},
{"f_4281:data_structures_scm",(void*)f_4281},
{"f_4271:data_structures_scm",(void*)f_4271},
{"f_4240:data_structures_scm",(void*)f_4240},
{"f_4243:data_structures_scm",(void*)f_4243},
{"f_4249:data_structures_scm",(void*)f_4249},
{"f_4095:data_structures_scm",(void*)f_4095},
{"f_4177:data_structures_scm",(void*)f_4177},
{"f_4200:data_structures_scm",(void*)f_4200},
{"f_4180:data_structures_scm",(void*)f_4180},
{"f_4098:data_structures_scm",(void*)f_4098},
{"f_4105:data_structures_scm",(void*)f_4105},
{"f_3996:data_structures_scm",(void*)f_3996},
{"f_4030:data_structures_scm",(void*)f_4030},
{"f_4037:data_structures_scm",(void*)f_4037},
{"f_4085:data_structures_scm",(void*)f_4085},
{"f_4057:data_structures_scm",(void*)f_4057},
{"f_3887:data_structures_scm",(void*)f_3887},
{"f_3962:data_structures_scm",(void*)f_3962},
{"f_3990:data_structures_scm",(void*)f_3990},
{"f_3914:data_structures_scm",(void*)f_3914},
{"f_3924:data_structures_scm",(void*)f_3924},
{"f_3835:data_structures_scm",(void*)f_3835},
{"f_3839:data_structures_scm",(void*)f_3839},
{"f_3771:data_structures_scm",(void*)f_3771},
{"f_3786:data_structures_scm",(void*)f_3786},
{"f_3817:data_structures_scm",(void*)f_3817},
{"f_3821:data_structures_scm",(void*)f_3821},
{"f_3806:data_structures_scm",(void*)f_3806},
{"f_3649:data_structures_scm",(void*)f_3649},
{"f_3661:data_structures_scm",(void*)f_3661},
{"f_3694:data_structures_scm",(void*)f_3694},
{"f_3759:data_structures_scm",(void*)f_3759},
{"f_3733:data_structures_scm",(void*)f_3733},
{"f_3689:data_structures_scm",(void*)f_3689},
{"f_3679:data_structures_scm",(void*)f_3679},
{"f_3675:data_structures_scm",(void*)f_3675},
{"f_3447:data_structures_scm",(void*)f_3447},
{"f_3641:data_structures_scm",(void*)f_3641},
{"f_3624:data_structures_scm",(void*)f_3624},
{"f_3484:data_structures_scm",(void*)f_3484},
{"f_3487:data_structures_scm",(void*)f_3487},
{"f_3499:data_structures_scm",(void*)f_3499},
{"f_3504:data_structures_scm",(void*)f_3504},
{"f_3523:data_structures_scm",(void*)f_3523},
{"f_3450:data_structures_scm",(void*)f_3450},
{"f_3455:data_structures_scm",(void*)f_3455},
{"f_3461:data_structures_scm",(void*)f_3461},
{"f_3332:data_structures_scm",(void*)f_3332},
{"f_3336:data_structures_scm",(void*)f_3336},
{"f_3350:data_structures_scm",(void*)f_3350},
{"f_3360:data_structures_scm",(void*)f_3360},
{"f_3365:data_structures_scm",(void*)f_3365},
{"f_3197:data_structures_scm",(void*)f_3197},
{"f_3238:data_structures_scm",(void*)f_3238},
{"f_3265:data_structures_scm",(void*)f_3265},
{"f_3304:data_structures_scm",(void*)f_3304},
{"f_3248:data_structures_scm",(void*)f_3248},
{"f_3218:data_structures_scm",(void*)f_3218},
{"f_3233:data_structures_scm",(void*)f_3233},
{"f_3225:data_structures_scm",(void*)f_3225},
{"f_3117:data_structures_scm",(void*)f_3117},
{"f_3134:data_structures_scm",(void*)f_3134},
{"f_3129:data_structures_scm",(void*)f_3129},
{"f_3124:data_structures_scm",(void*)f_3124},
{"f_3119:data_structures_scm",(void*)f_3119},
{"f_3080:data_structures_scm",(void*)f_3080},
{"f_3090:data_structures_scm",(void*)f_3090},
{"f_3000:data_structures_scm",(void*)f_3000},
{"f_3017:data_structures_scm",(void*)f_3017},
{"f_3012:data_structures_scm",(void*)f_3012},
{"f_3007:data_structures_scm",(void*)f_3007},
{"f_3002:data_structures_scm",(void*)f_3002},
{"f_2963:data_structures_scm",(void*)f_2963},
{"f_2973:data_structures_scm",(void*)f_2973},
{"f_2932:data_structures_scm",(void*)f_2932},
{"f_2901:data_structures_scm",(void*)f_2901},
{"f_2873:data_structures_scm",(void*)f_2873},
{"f_2877:data_structures_scm",(void*)f_2877},
{"f_2845:data_structures_scm",(void*)f_2845},
{"f_2849:data_structures_scm",(void*)f_2849},
{"f_2836:data_structures_scm",(void*)f_2836},
{"f_2842:data_structures_scm",(void*)f_2842},
{"f_2827:data_structures_scm",(void*)f_2827},
{"f_2833:data_structures_scm",(void*)f_2833},
{"f_2780:data_structures_scm",(void*)f_2780},
{"f_2801:data_structures_scm",(void*)f_2801},
{"f_2814:data_structures_scm",(void*)f_2814},
{"f_2770:data_structures_scm",(void*)f_2770},
{"f_2778:data_structures_scm",(void*)f_2778},
{"f_2725:data_structures_scm",(void*)f_2725},
{"f_2762:data_structures_scm",(void*)f_2762},
{"f_2765:data_structures_scm",(void*)f_2765},
{"f_2648:data_structures_scm",(void*)f_2648},
{"f_2651:data_structures_scm",(void*)f_2651},
{"f_2667:data_structures_scm",(void*)f_2667},
{"f_2676:data_structures_scm",(void*)f_2676},
{"f_2598:data_structures_scm",(void*)f_2598},
{"f_2610:data_structures_scm",(void*)f_2610},
{"f_2629:data_structures_scm",(void*)f_2629},
{"f_2474:data_structures_scm",(void*)f_2474},
{"f_2550:data_structures_scm",(void*)f_2550},
{"f_2545:data_structures_scm",(void*)f_2545},
{"f_2476:data_structures_scm",(void*)f_2476},
{"f_2505:data_structures_scm",(void*)f_2505},
{"f_2511:data_structures_scm",(void*)f_2511},
{"f_2527:data_structures_scm",(void*)f_2527},
{"f_2480:data_structures_scm",(void*)f_2480},
{"f_2483:data_structures_scm",(void*)f_2483},
{"f_2388:data_structures_scm",(void*)f_2388},
{"f_2427:data_structures_scm",(void*)f_2427},
{"f_2433:data_structures_scm",(void*)f_2433},
{"f_2449:data_structures_scm",(void*)f_2449},
{"f_2395:data_structures_scm",(void*)f_2395},
{"f_2398:data_structures_scm",(void*)f_2398},
{"f_2347:data_structures_scm",(void*)f_2347},
{"f_2378:data_structures_scm",(void*)f_2378},
{"f_2386:data_structures_scm",(void*)f_2386},
{"f_2362:data_structures_scm",(void*)f_2362},
{"f_2364:data_structures_scm",(void*)f_2364},
{"f_2358:data_structures_scm",(void*)f_2358},
{"f_2267:data_structures_scm",(void*)f_2267},
{"f_2276:data_structures_scm",(void*)f_2276},
{"f_2318:data_structures_scm",(void*)f_2318},
{"f_2208:data_structures_scm",(void*)f_2208},
{"f_2220:data_structures_scm",(void*)f_2220},
{"f_2255:data_structures_scm",(void*)f_2255},
{"f_2123:data_structures_scm",(void*)f_2123},
{"f_2130:data_structures_scm",(void*)f_2130},
{"f_2138:data_structures_scm",(void*)f_2138},
{"f_2159:data_structures_scm",(void*)f_2159},
{"f_2173:data_structures_scm",(void*)f_2173},
{"f_2177:data_structures_scm",(void*)f_2177},
{"f_2082:data_structures_scm",(void*)f_2082},
{"f_2088:data_structures_scm",(void*)f_2088},
{"f_2121:data_structures_scm",(void*)f_2121},
{"f_2114:data_structures_scm",(void*)f_2114},
{"f_2050:data_structures_scm",(void*)f_2050},
{"f_2059:data_structures_scm",(void*)f_2059},
{"f_2080:data_structures_scm",(void*)f_2080},
{"f_2017:data_structures_scm",(void*)f_2017},
{"f_2023:data_structures_scm",(void*)f_2023},
{"f_2048:data_structures_scm",(void*)f_2048},
{"f_1989:data_structures_scm",(void*)f_1989},
{"f_2001:data_structures_scm",(void*)f_2001},
{"f_1986:data_structures_scm",(void*)f_1986},
{"f_1960:data_structures_scm",(void*)f_1960},
{"f_1964:data_structures_scm",(void*)f_1964},
{"f_1967:data_structures_scm",(void*)f_1967},
{"f_1968:data_structures_scm",(void*)f_1968},
{"f_1984:data_structures_scm",(void*)f_1984},
{"f_1980:data_structures_scm",(void*)f_1980},
{"f_1976:data_structures_scm",(void*)f_1976},
{"f_1945:data_structures_scm",(void*)f_1945},
{"f_1949:data_structures_scm",(void*)f_1949},
{"f_1950:data_structures_scm",(void*)f_1950},
{"f_1958:data_structures_scm",(void*)f_1958},
{"f_1942:data_structures_scm",(void*)f_1942},
{"f_1939:data_structures_scm",(void*)f_1939},
{"f_1936:data_structures_scm",(void*)f_1936},
{"f_1933:data_structures_scm",(void*)f_1933},
{"f_1877:data_structures_scm",(void*)f_1877},
{"f_1899:data_structures_scm",(void*)f_1899},
{"f_1905:data_structures_scm",(void*)f_1905},
{"f_1924:data_structures_scm",(void*)f_1924},
{"f_1885:data_structures_scm",(void*)f_1885},
{"f_1871:data_structures_scm",(void*)f_1871},
{"f_1830:data_structures_scm",(void*)f_1830},
{"f_1832:data_structures_scm",(void*)f_1832},
{"f_1838:data_structures_scm",(void*)f_1838},
{"f_1857:data_structures_scm",(void*)f_1857},
{"f_1791:data_structures_scm",(void*)f_1791},
{"f_1803:data_structures_scm",(void*)f_1803},
{"f_1817:data_structures_scm",(void*)f_1817},
{"f_1828:data_structures_scm",(void*)f_1828},
{"f_1825:data_structures_scm",(void*)f_1825},
{"f_1755:data_structures_scm",(void*)f_1755},
{"f_1758:data_structures_scm",(void*)f_1758},
{"f_1766:data_structures_scm",(void*)f_1766},
{"f_1772:data_structures_scm",(void*)f_1772},
{"f_1780:data_structures_scm",(void*)f_1780},
{"f_1743:data_structures_scm",(void*)f_1743},
{"f_1745:data_structures_scm",(void*)f_1745},
{"f_1753:data_structures_scm",(void*)f_1753},
{"f_1735:data_structures_scm",(void*)f_1735},
{"f_1737:data_structures_scm",(void*)f_1737},
{"f_1712:data_structures_scm",(void*)f_1712},
{"f_1725:data_structures_scm",(void*)f_1725},
{"f_1723:data_structures_scm",(void*)f_1723},
{"f_1675:data_structures_scm",(void*)f_1675},
{"f_1677:data_structures_scm",(void*)f_1677},
{"f_1683:data_structures_scm",(void*)f_1683},
{"f_1693:data_structures_scm",(void*)f_1693},
{"f_1642:data_structures_scm",(void*)f_1642},
{"f_1644:data_structures_scm",(void*)f_1644},
{"f_1650:data_structures_scm",(void*)f_1650},
{"f_1663:data_structures_scm",(void*)f_1663},
{"f_1634:data_structures_scm",(void*)f_1634},
{"f_1636:data_structures_scm",(void*)f_1636},
{"f_1631:data_structures_scm",(void*)f_1631},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
