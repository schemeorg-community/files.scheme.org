/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:47
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: posixwin.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file uposixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[392];
static double C_possibly_force_alignment;


/* from k5446 */
static C_word C_fcall stub1538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub1538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from current-process-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static C_word C_fcall stub1498(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1498(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k5091 */
static C_word C_fcall stub1323(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1323(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k5085 */
static C_word C_fcall stub1311(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1311(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from ex0 */
static C_word C_fcall stub1149(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1149(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1141(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1141(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (_daylight ? _tzname[1] : _tzname[0]);
return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub1098(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1098(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1090(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1090(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub1075(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1075(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from get */
static C_word C_fcall stub1031(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1031(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from strerror */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6063)
static void C_fcall f_6063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6058)
static void C_fcall f_6058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6053)
static void C_fcall f_6053(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5914)
static void C_fcall f_5914(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5921)
static void C_fcall f_5921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_fcall f_5933(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5722)
static void C_fcall f_5722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5717)
static void C_fcall f_5717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5712)
static void C_fcall f_5712(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5707)
static void C_fcall f_5707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5645)
static void C_fcall f_5645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_fcall f_5640(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5635)
static void C_fcall f_5635(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5630)
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5566)
static void C_fcall f_5566(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5300)
static void C_fcall f_5300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5295)
static void C_fcall f_5295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5290)
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5278)
static void C_fcall f_5278(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5216)
static void C_fcall f_5216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_fcall f_5211(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5206)
static void C_fcall f_5206(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5194)
static void C_fcall f_5194(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_fcall f_5177(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_fcall f_5144(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_fcall f_5094(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5106)
static void C_fcall f_5106(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5003)
static void C_fcall f_5003(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5046)
static void C_fcall f_5046(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_fcall f_5017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4897)
static void C_fcall f_4897(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_fcall f_4934(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4652)
static void C_fcall f_4652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_fcall f_4592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_fcall f_4604(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4531)
static void C_fcall f_4531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_fcall f_4443(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_fcall f_4406(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4361)
static void C_fcall f_4361(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_fcall f_3987(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_fcall f_3981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static C_word C_fcall f_3969(C_word t0);
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_fcall f_3758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_fcall f_3830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3635)
static void C_ccall f_3635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_fcall f_3707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_fcall f_3556(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static C_word C_fcall f_3545(C_word t0);
C_noret_decl(f_3540)
static void C_fcall f_3540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3420)
static void C_fcall f_3420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_fcall f_3415(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3314)
static void C_fcall f_3314(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_fcall f_3348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_fcall f_3370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_fcall f_3187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_fcall f_3018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_fcall f_2892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6063)
static void C_fcall trf_6063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6063(t0,t1);}

C_noret_decl(trf_6058)
static void C_fcall trf_6058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6058(t0,t1,t2);}

C_noret_decl(trf_6053)
static void C_fcall trf_6053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6053(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6053(t0,t1,t2,t3);}

C_noret_decl(trf_5914)
static void C_fcall trf_5914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5914(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5914(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5921)
static void C_fcall trf_5921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5921(t0,t1);}

C_noret_decl(trf_5933)
static void C_fcall trf_5933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5933(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5933(t0,t1,t2,t3);}

C_noret_decl(trf_5722)
static void C_fcall trf_5722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5722(t0,t1);}

C_noret_decl(trf_5717)
static void C_fcall trf_5717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5717(t0,t1,t2);}

C_noret_decl(trf_5712)
static void C_fcall trf_5712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5712(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5712(t0,t1,t2,t3);}

C_noret_decl(trf_5707)
static void C_fcall trf_5707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5707(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5707(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5645)
static void C_fcall trf_5645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5645(t0,t1);}

C_noret_decl(trf_5640)
static void C_fcall trf_5640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5640(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5640(t0,t1,t2);}

C_noret_decl(trf_5635)
static void C_fcall trf_5635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5635(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5635(t0,t1,t2,t3);}

C_noret_decl(trf_5630)
static void C_fcall trf_5630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5630(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5630(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5566)
static void C_fcall trf_5566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5566(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5566(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5568)
static void C_fcall trf_5568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5568(t0,t1,t2);}

C_noret_decl(trf_5300)
static void C_fcall trf_5300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5300(t0,t1);}

C_noret_decl(trf_5295)
static void C_fcall trf_5295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5295(t0,t1,t2);}

C_noret_decl(trf_5290)
static void C_fcall trf_5290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5290(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5290(t0,t1,t2,t3);}

C_noret_decl(trf_5278)
static void C_fcall trf_5278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5278(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5278(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5216)
static void C_fcall trf_5216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5216(t0,t1);}

C_noret_decl(trf_5211)
static void C_fcall trf_5211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5211(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5211(t0,t1,t2);}

C_noret_decl(trf_5206)
static void C_fcall trf_5206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5206(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5206(t0,t1,t2,t3);}

C_noret_decl(trf_5194)
static void C_fcall trf_5194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5194(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5194(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5177)
static void C_fcall trf_5177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5177(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5177(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5144)
static void C_fcall trf_5144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5144(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5144(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5094)
static void C_fcall trf_5094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5094(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5094(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5106)
static void C_fcall trf_5106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5106(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5106(t0,t1,t2,t3);}

C_noret_decl(trf_5003)
static void C_fcall trf_5003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5003(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5003(t0,t1,t2,t3);}

C_noret_decl(trf_5046)
static void C_fcall trf_5046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5046(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5046(t0,t1,t2,t3);}

C_noret_decl(trf_5008)
static void C_fcall trf_5008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5008(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5008(t0,t1,t2);}

C_noret_decl(trf_5017)
static void C_fcall trf_5017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5017(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5017(t0,t1,t2);}

C_noret_decl(trf_4897)
static void C_fcall trf_4897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4897(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4897(t0,t1,t2);}

C_noret_decl(trf_4934)
static void C_fcall trf_4934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4934(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4934(t0,t1,t2);}

C_noret_decl(trf_4652)
static void C_fcall trf_4652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4652(t0,t1,t2);}

C_noret_decl(trf_4592)
static void C_fcall trf_4592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4592(t0,t1,t2);}

C_noret_decl(trf_4604)
static void C_fcall trf_4604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4604(t0,t1,t2);}

C_noret_decl(trf_4531)
static void C_fcall trf_4531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4531(t0,t1);}

C_noret_decl(trf_4443)
static void C_fcall trf_4443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4443(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4443(t0,t1,t2,t3);}

C_noret_decl(trf_4406)
static void C_fcall trf_4406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4406(t0,t1,t2);}

C_noret_decl(trf_4361)
static void C_fcall trf_4361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4361(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4361(t0,t1,t2,t3);}

C_noret_decl(trf_3987)
static void C_fcall trf_3987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3987(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3987(t0,t1,t2,t3);}

C_noret_decl(trf_3981)
static void C_fcall trf_3981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3981(t0,t1);}

C_noret_decl(trf_3758)
static void C_fcall trf_3758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3758(t0,t1);}

C_noret_decl(trf_3788)
static void C_fcall trf_3788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3788(t0,t1);}

C_noret_decl(trf_3830)
static void C_fcall trf_3830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3830(t0,t1);}

C_noret_decl(trf_3628)
static void C_fcall trf_3628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3628(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3628(t0,t1,t2,t3);}

C_noret_decl(trf_3707)
static void C_fcall trf_3707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3707(t0,t1);}

C_noret_decl(trf_3556)
static void C_fcall trf_3556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3556(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3556(t0,t1);}

C_noret_decl(trf_3540)
static void C_fcall trf_3540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3540(t0,t1);}

C_noret_decl(trf_3420)
static void C_fcall trf_3420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3420(t0,t1);}

C_noret_decl(trf_3415)
static void C_fcall trf_3415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3415(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3415(t0,t1,t2);}

C_noret_decl(trf_3314)
static void C_fcall trf_3314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3314(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3314(t0,t1,t2,t3);}

C_noret_decl(trf_3348)
static void C_fcall trf_3348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3348(t0,t1);}

C_noret_decl(trf_3370)
static void C_fcall trf_3370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3370(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3370(t0,t1);}

C_noret_decl(trf_3187)
static void C_fcall trf_3187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3187(t0,t1);}

C_noret_decl(trf_3018)
static void C_fcall trf_3018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3018(t0,t1);}

C_noret_decl(trf_2892)
static void C_fcall trf_2892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2892(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr9rv)
static void C_fcall tr9rv(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9rv(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n+1);
t9=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3080)){
C_save(t1);
C_rereclaim2(3080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,392);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"open/rdonly");
lf[11]=C_h_intern(&lf[11],11,"open/wronly");
lf[12]=C_h_intern(&lf[12],9,"open/rdwr");
lf[13]=C_h_intern(&lf[13],9,"open/read");
lf[14]=C_h_intern(&lf[14],10,"open/write");
lf[15]=C_h_intern(&lf[15],10,"open/creat");
lf[16]=C_h_intern(&lf[16],11,"open/append");
lf[17]=C_h_intern(&lf[17],9,"open/excl");
lf[18]=C_h_intern(&lf[18],10,"open/trunc");
lf[19]=C_h_intern(&lf[19],11,"open/binary");
lf[20]=C_h_intern(&lf[20],9,"open/text");
lf[21]=C_h_intern(&lf[21],14,"open/noinherit");
lf[22]=C_h_intern(&lf[22],10,"perm/irusr");
lf[23]=C_h_intern(&lf[23],10,"perm/iwusr");
lf[24]=C_h_intern(&lf[24],10,"perm/ixusr");
lf[25]=C_h_intern(&lf[25],10,"perm/irgrp");
lf[26]=C_h_intern(&lf[26],10,"perm/iwgrp");
lf[27]=C_h_intern(&lf[27],10,"perm/ixgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iroth");
lf[29]=C_h_intern(&lf[29],10,"perm/iwoth");
lf[30]=C_h_intern(&lf[30],10,"perm/ixoth");
lf[31]=C_h_intern(&lf[31],10,"perm/irwxu");
lf[32]=C_h_intern(&lf[32],10,"perm/irwxg");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxo");
lf[34]=C_h_intern(&lf[34],9,"file-open");
lf[35]=C_h_intern(&lf[35],11,"\000file-error");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[37]=C_h_intern(&lf[37],17,"\003sysmake-c-string");
lf[38]=C_h_intern(&lf[38],20,"\003sysexpand-home-path");
lf[39]=C_h_intern(&lf[39],10,"file-close");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[41]=C_h_intern(&lf[41],11,"make-string");
lf[42]=C_h_intern(&lf[42],9,"file-read");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[44]=C_h_intern(&lf[44],11,"\000type-error");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[46]=C_h_intern(&lf[46],10,"file-write");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[49]=C_h_intern(&lf[49],13,"string-length");
lf[50]=C_h_intern(&lf[50],12,"file-mkstemp");
lf[51]=C_h_intern(&lf[51],13,"\003syssubstring");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[53]=C_h_intern(&lf[53],8,"seek/set");
lf[54]=C_h_intern(&lf[54],8,"seek/end");
lf[55]=C_h_intern(&lf[55],8,"seek/cur");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[59]=C_h_intern(&lf[59],9,"file-stat");
lf[60]=C_h_intern(&lf[60],9,"file-size");
lf[61]=C_h_intern(&lf[61],22,"file-modification-time");
lf[62]=C_h_intern(&lf[62],16,"file-access-time");
lf[63]=C_h_intern(&lf[63],16,"file-change-time");
lf[64]=C_h_intern(&lf[64],10,"file-owner");
lf[65]=C_h_intern(&lf[65],16,"file-permissions");
lf[66]=C_h_intern(&lf[66],13,"regular-file\077");
lf[67]=C_h_intern(&lf[67],13,"\003sysfile-info");
lf[68]=C_h_intern(&lf[68],14,"symbolic-link\077");
lf[69]=C_h_intern(&lf[69],13,"stat-regular\077");
lf[70]=C_h_intern(&lf[70],15,"stat-directory\077");
lf[71]=C_h_intern(&lf[71],17,"stat-char-device\077");
lf[72]=C_h_intern(&lf[72],18,"stat-block-device\077");
lf[73]=C_h_intern(&lf[73],10,"stat-fifo\077");
lf[74]=C_h_intern(&lf[74],13,"stat-symlink\077");
lf[75]=C_h_intern(&lf[75],12,"stat-socket\077");
lf[76]=C_h_intern(&lf[76],13,"file-position");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[78]=C_h_intern(&lf[78],6,"stream");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[80]=C_h_intern(&lf[80],5,"port\077");
lf[81]=C_h_intern(&lf[81],18,"set-file-position!");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[84]=C_h_intern(&lf[84],13,"\000bounds-error");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[86]=C_h_intern(&lf[86],16,"create-directory");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[88]=C_h_intern(&lf[88],12,"file-exists\077");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[90]=C_h_intern(&lf[90],12,"\003sysfor-each");
lf[91]=C_h_intern(&lf[91],12,"string-split");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[93]=C_h_intern(&lf[93],14,"canonical-path");
lf[94]=C_h_intern(&lf[94],16,"change-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[96]=C_h_intern(&lf[96],16,"delete-directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[98]=C_h_intern(&lf[98],6,"string");
lf[99]=C_h_intern(&lf[99],9,"directory");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[101]=C_h_intern(&lf[101],16,"\003sysmake-pointer");
lf[102]=C_h_intern(&lf[102],17,"current-directory");
lf[103]=C_h_intern(&lf[103],10,"directory\077");
lf[104]=C_h_intern(&lf[104],27,"\003sysplatform-fixup-pathname");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[106]=C_h_intern(&lf[106],5,"null\077");
lf[107]=C_h_intern(&lf[107],6,"char=\077");
lf[108]=C_h_intern(&lf[108],8,"string=\077");
lf[109]=C_h_intern(&lf[109],16,"char-alphabetic\077");
lf[110]=C_h_intern(&lf[110],10,"string-ref");
lf[111]=C_h_intern(&lf[111],18,"string-intersperse");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[113]=C_h_intern(&lf[113],17,"current-user-name");
lf[114]=C_h_intern(&lf[114],9,"condition");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[116]=C_h_intern(&lf[116],22,"with-exception-handler");
lf[117]=C_h_intern(&lf[117],30,"call-with-current-continuation");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[119]=C_h_intern(&lf[119],7,"reverse");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[129]=C_h_intern(&lf[129],5,"\000text");
lf[130]=C_h_intern(&lf[130],9,"\003syserror");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[133]=C_h_intern(&lf[133],13,"\003sysmake-port");
lf[134]=C_h_intern(&lf[134],21,"\003sysstream-port-class");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[136]=C_h_intern(&lf[136],15,"open-input-pipe");
lf[137]=C_h_intern(&lf[137],7,"\000binary");
lf[138]=C_h_intern(&lf[138],16,"open-output-pipe");
lf[139]=C_h_intern(&lf[139],16,"close-input-pipe");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[141]=C_h_intern(&lf[141],14,"\003syscheck-port");
lf[142]=C_h_intern(&lf[142],17,"close-output-pipe");
lf[143]=C_h_intern(&lf[143],20,"call-with-input-pipe");
lf[144]=C_h_intern(&lf[144],21,"call-with-output-pipe");
lf[145]=C_h_intern(&lf[145],20,"with-input-from-pipe");
lf[146]=C_h_intern(&lf[146],18,"\003sysstandard-input");
lf[147]=C_h_intern(&lf[147],19,"with-output-to-pipe");
lf[148]=C_h_intern(&lf[148],19,"\003sysstandard-output");
lf[149]=C_h_intern(&lf[149],11,"create-pipe");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[151]=C_h_intern(&lf[151],11,"signal/term");
lf[152]=C_h_intern(&lf[152],10,"signal/int");
lf[153]=C_h_intern(&lf[153],10,"signal/fpe");
lf[154]=C_h_intern(&lf[154],10,"signal/ill");
lf[155]=C_h_intern(&lf[155],11,"signal/segv");
lf[156]=C_h_intern(&lf[156],11,"signal/abrt");
lf[157]=C_h_intern(&lf[157],12,"signal/break");
lf[158]=C_h_intern(&lf[158],11,"signal/alrm");
lf[159]=C_h_intern(&lf[159],11,"signal/chld");
lf[160]=C_h_intern(&lf[160],11,"signal/cont");
lf[161]=C_h_intern(&lf[161],10,"signal/hup");
lf[162]=C_h_intern(&lf[162],9,"signal/io");
lf[163]=C_h_intern(&lf[163],11,"signal/kill");
lf[164]=C_h_intern(&lf[164],11,"signal/pipe");
lf[165]=C_h_intern(&lf[165],11,"signal/prof");
lf[166]=C_h_intern(&lf[166],11,"signal/quit");
lf[167]=C_h_intern(&lf[167],11,"signal/stop");
lf[168]=C_h_intern(&lf[168],11,"signal/trap");
lf[169]=C_h_intern(&lf[169],11,"signal/tstp");
lf[170]=C_h_intern(&lf[170],10,"signal/urg");
lf[171]=C_h_intern(&lf[171],11,"signal/usr1");
lf[172]=C_h_intern(&lf[172],11,"signal/usr2");
lf[173]=C_h_intern(&lf[173],13,"signal/vtalrm");
lf[174]=C_h_intern(&lf[174],12,"signal/winch");
lf[175]=C_h_intern(&lf[175],11,"signal/xcpu");
lf[176]=C_h_intern(&lf[176],11,"signal/xfsz");
lf[177]=C_h_intern(&lf[177],12,"signals-list");
lf[178]=C_h_intern(&lf[178],18,"\003sysinterrupt-hook");
lf[179]=C_h_intern(&lf[179],14,"signal-handler");
lf[180]=C_h_intern(&lf[180],19,"set-signal-handler!");
lf[181]=C_h_intern(&lf[181],10,"errno/perm");
lf[182]=C_h_intern(&lf[182],11,"errno/noent");
lf[183]=C_h_intern(&lf[183],10,"errno/srch");
lf[184]=C_h_intern(&lf[184],10,"errno/intr");
lf[185]=C_h_intern(&lf[185],8,"errno/io");
lf[186]=C_h_intern(&lf[186],12,"errno/noexec");
lf[187]=C_h_intern(&lf[187],10,"errno/badf");
lf[188]=C_h_intern(&lf[188],11,"errno/child");
lf[189]=C_h_intern(&lf[189],11,"errno/nomem");
lf[190]=C_h_intern(&lf[190],11,"errno/acces");
lf[191]=C_h_intern(&lf[191],11,"errno/fault");
lf[192]=C_h_intern(&lf[192],10,"errno/busy");
lf[193]=C_h_intern(&lf[193],11,"errno/exist");
lf[194]=C_h_intern(&lf[194],12,"errno/notdir");
lf[195]=C_h_intern(&lf[195],11,"errno/isdir");
lf[196]=C_h_intern(&lf[196],11,"errno/inval");
lf[197]=C_h_intern(&lf[197],11,"errno/mfile");
lf[198]=C_h_intern(&lf[198],11,"errno/nospc");
lf[199]=C_h_intern(&lf[199],11,"errno/spipe");
lf[200]=C_h_intern(&lf[200],10,"errno/pipe");
lf[201]=C_h_intern(&lf[201],11,"errno/again");
lf[202]=C_h_intern(&lf[202],10,"errno/rofs");
lf[203]=C_h_intern(&lf[203],10,"errno/nxio");
lf[204]=C_h_intern(&lf[204],10,"errno/2big");
lf[205]=C_h_intern(&lf[205],10,"errno/xdev");
lf[206]=C_h_intern(&lf[206],11,"errno/nodev");
lf[207]=C_h_intern(&lf[207],11,"errno/nfile");
lf[208]=C_h_intern(&lf[208],11,"errno/notty");
lf[209]=C_h_intern(&lf[209],10,"errno/fbig");
lf[210]=C_h_intern(&lf[210],11,"errno/mlink");
lf[211]=C_h_intern(&lf[211],9,"errno/dom");
lf[212]=C_h_intern(&lf[212],11,"errno/range");
lf[213]=C_h_intern(&lf[213],12,"errno/deadlk");
lf[214]=C_h_intern(&lf[214],17,"errno/nametoolong");
lf[215]=C_h_intern(&lf[215],11,"errno/nolck");
lf[216]=C_h_intern(&lf[216],11,"errno/nosys");
lf[217]=C_h_intern(&lf[217],14,"errno/notempty");
lf[218]=C_h_intern(&lf[218],11,"errno/ilseq");
lf[219]=C_h_intern(&lf[219],16,"change-file-mode");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[221]=C_h_intern(&lf[221],17,"file-read-access\077");
lf[222]=C_h_intern(&lf[222],18,"file-write-access\077");
lf[223]=C_h_intern(&lf[223],20,"file-execute-access\077");
lf[224]=C_h_intern(&lf[224],12,"fileno/stdin");
lf[225]=C_h_intern(&lf[225],13,"fileno/stdout");
lf[226]=C_h_intern(&lf[226],13,"fileno/stderr");
lf[227]=C_h_intern(&lf[227],7,"\000append");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[235]=C_h_intern(&lf[235],16,"open-input-file*");
lf[236]=C_h_intern(&lf[236],17,"open-output-file*");
lf[237]=C_h_intern(&lf[237],12,"port->fileno");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[240]=C_h_intern(&lf[240],25,"\003syspeek-unsigned-integer");
lf[241]=C_h_intern(&lf[241],16,"duplicate-fileno");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[243]=C_h_intern(&lf[243],6,"setenv");
lf[244]=C_h_intern(&lf[244],8,"unsetenv");
lf[245]=C_h_intern(&lf[245],9,"substring");
lf[246]=C_h_intern(&lf[246],25,"get-environment-variables");
lf[247]=C_h_intern(&lf[247],19,"current-environment");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[250]=C_h_intern(&lf[250],19,"seconds->local-time");
lf[251]=C_h_intern(&lf[251],18,"\003sysdecode-seconds");
lf[252]=C_h_intern(&lf[252],17,"seconds->utc-time");
lf[253]=C_h_intern(&lf[253],15,"seconds->string");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[255]=C_h_intern(&lf[255],12,"time->string");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[258]=C_h_intern(&lf[258],19,"local-time->seconds");
lf[259]=C_h_intern(&lf[259],15,"\003syscons-flonum");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[261]=C_h_intern(&lf[261],27,"local-timezone-abbreviation");
lf[262]=C_h_intern(&lf[262],5,"_exit");
lf[263]=C_h_intern(&lf[263],14,"terminal-port\077");
lf[264]=C_h_intern(&lf[264],19,"set-buffering-mode!");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[266]=C_h_intern(&lf[266],5,"\000full");
lf[267]=C_h_intern(&lf[267],5,"\000line");
lf[268]=C_h_intern(&lf[268],5,"\000none");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[270]=C_h_intern(&lf[270],6,"regexp");
lf[271]=C_h_intern(&lf[271],12,"string-match");
lf[272]=C_h_intern(&lf[272],12,"glob->regexp");
lf[273]=C_h_intern(&lf[273],13,"make-pathname");
lf[274]=C_h_intern(&lf[274],18,"decompose-pathname");
lf[275]=C_h_intern(&lf[275],4,"glob");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[278]=C_h_intern(&lf[278],13,"spawn/overlay");
lf[279]=C_h_intern(&lf[279],10,"spawn/wait");
lf[280]=C_h_intern(&lf[280],12,"spawn/nowait");
lf[281]=C_h_intern(&lf[281],13,"spawn/nowaito");
lf[282]=C_h_intern(&lf[282],12,"spawn/detach");
lf[283]=C_h_intern(&lf[283],16,"char-whitespace\077");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[287]=C_h_intern(&lf[287],24,"pathname-strip-directory");
lf[290]=C_h_intern(&lf[290],15,"process-execute");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[292]=C_h_intern(&lf[292],13,"process-spawn");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[294]=C_h_intern(&lf[294],18,"current-process-id");
lf[295]=C_h_intern(&lf[295],17,"\003sysshell-command");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[297]=C_h_intern(&lf[297],6,"getenv");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[299]=C_h_intern(&lf[299],27,"\003sysshell-command-arguments");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[301]=C_h_intern(&lf[301],11,"process-run");
lf[302]=C_h_intern(&lf[302],11,"\003sysprocess");
lf[303]=C_h_intern(&lf[303],14,"\000process-error");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[305]=C_h_intern(&lf[305],17,"\003sysmake-locative");
lf[306]=C_h_intern(&lf[306],8,"location");
lf[307]=C_h_intern(&lf[307],7,"process");
lf[308]=C_h_intern(&lf[308],8,"process*");
lf[309]=C_h_intern(&lf[309],16,"\003sysprocess-wait");
lf[310]=C_h_intern(&lf[310],12,"process-wait");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[312]=C_h_intern(&lf[312],5,"sleep");
lf[313]=C_h_intern(&lf[313],13,"get-host-name");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[315]=C_h_intern(&lf[315],18,"system-information");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[319]=C_h_intern(&lf[319],10,"find-files");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[323]=C_h_intern(&lf[323],16,"\003sysdynamic-wind");
lf[324]=C_h_intern(&lf[324],13,"pathname-file");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[326]=C_h_intern(&lf[326],17,"change-file-owner");
lf[327]=C_h_intern(&lf[327],5,"error");
lf[328]=C_h_intern(&lf[328],11,"create-fifo");
lf[329]=C_h_intern(&lf[329],14,"create-session");
lf[330]=C_h_intern(&lf[330],20,"create-symbolic-link");
lf[331]=C_h_intern(&lf[331],26,"current-effective-group-id");
lf[332]=C_h_intern(&lf[332],25,"current-effective-user-id");
lf[333]=C_h_intern(&lf[333],27,"current-effective-user-name");
lf[334]=C_h_intern(&lf[334],16,"current-group-id");
lf[335]=C_h_intern(&lf[335],15,"current-user-id");
lf[336]=C_h_intern(&lf[336],18,"map-file-to-memory");
lf[337]=C_h_intern(&lf[337],9,"file-link");
lf[338]=C_h_intern(&lf[338],9,"file-lock");
lf[339]=C_h_intern(&lf[339],18,"file-lock/blocking");
lf[340]=C_h_intern(&lf[340],11,"file-select");
lf[341]=C_h_intern(&lf[341],14,"file-test-lock");
lf[342]=C_h_intern(&lf[342],13,"file-truncate");
lf[343]=C_h_intern(&lf[343],11,"file-unlock");
lf[344]=C_h_intern(&lf[344],10,"get-groups");
lf[345]=C_h_intern(&lf[345],17,"group-information");
lf[346]=C_h_intern(&lf[346],17,"initialize-groups");
lf[347]=C_h_intern(&lf[347],26,"memory-mapped-file-pointer");
lf[348]=C_h_intern(&lf[348],17,"parent-process-id");
lf[349]=C_h_intern(&lf[349],12,"process-fork");
lf[350]=C_h_intern(&lf[350],16,"process-group-id");
lf[351]=C_h_intern(&lf[351],14,"process-signal");
lf[352]=C_h_intern(&lf[352],18,"read-symbolic-link");
lf[353]=C_h_intern(&lf[353],10,"set-alarm!");
lf[354]=C_h_intern(&lf[354],13,"set-group-id!");
lf[355]=C_h_intern(&lf[355],11,"set-groups!");
lf[356]=C_h_intern(&lf[356],21,"set-process-group-id!");
lf[357]=C_h_intern(&lf[357],19,"set-root-directory!");
lf[358]=C_h_intern(&lf[358],16,"set-signal-mask!");
lf[359]=C_h_intern(&lf[359],12,"set-user-id!");
lf[360]=C_h_intern(&lf[360],11,"signal-mask");
lf[361]=C_h_intern(&lf[361],12,"signal-mask!");
lf[362]=C_h_intern(&lf[362],14,"signal-masked\077");
lf[363]=C_h_intern(&lf[363],14,"signal-unmask!");
lf[364]=C_h_intern(&lf[364],13,"terminal-name");
lf[365]=C_h_intern(&lf[365],13,"terminal-size");
lf[366]=C_h_intern(&lf[366],22,"unmap-file-from-memory");
lf[367]=C_h_intern(&lf[367],16,"user-information");
lf[368]=C_h_intern(&lf[368],17,"utc-time->seconds");
lf[369]=C_h_intern(&lf[369],12,"string->time");
lf[370]=C_h_intern(&lf[370],16,"errno/wouldblock");
lf[371]=C_h_intern(&lf[371],5,"fifo\077");
lf[372]=C_h_intern(&lf[372],19,"memory-mapped-file\077");
lf[373]=C_h_intern(&lf[373],13,"map/anonymous");
lf[374]=C_h_intern(&lf[374],8,"map/file");
lf[375]=C_h_intern(&lf[375],9,"map/fixed");
lf[376]=C_h_intern(&lf[376],11,"map/private");
lf[377]=C_h_intern(&lf[377],10,"map/shared");
lf[378]=C_h_intern(&lf[378],10,"open/fsync");
lf[379]=C_h_intern(&lf[379],11,"open/noctty");
lf[380]=C_h_intern(&lf[380],13,"open/nonblock");
lf[381]=C_h_intern(&lf[381],9,"open/sync");
lf[382]=C_h_intern(&lf[382],10,"perm/isgid");
lf[383]=C_h_intern(&lf[383],10,"perm/isuid");
lf[384]=C_h_intern(&lf[384],10,"perm/isvtx");
lf[385]=C_h_intern(&lf[385],9,"prot/exec");
lf[386]=C_h_intern(&lf[386],9,"prot/none");
lf[387]=C_h_intern(&lf[387],9,"prot/read");
lf[388]=C_h_intern(&lf[388],10,"prot/write");
lf[389]=C_h_intern(&lf[389],11,"make-vector");
lf[390]=C_h_intern(&lf[390],17,"register-feature!");
lf[391]=C_h_intern(&lf[391],5,"posix");
C_register_lf2(lf,392,create_ptable());
t2=C_mutate(&lf[0] /* (set! c2027 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k2635 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2638 in k2635 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2641 in k2638 in k2635 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 930  register-feature! */
t3=*((C_word*)lf[390]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[391]);}

/* k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[10]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[11]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[12]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[13]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[14]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[15]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[16]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[22]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[23]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[24]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[25]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[26]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[27]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[29]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[30]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[31]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_u_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[34]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2708,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[39]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2749,tmp=(C_word)a,a+=2,tmp));
t34=*((C_word*)lf[41]+1);
t35=C_mutate((C_word*)lf[42]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[46]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2812,tmp=(C_word)a,a+=2,tmp));
t37=*((C_word*)lf[49]+1);
t38=C_mutate((C_word*)lf[50]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=t37,tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[53]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[54]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[55]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[56] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2892,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[59]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2930,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[60]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2954,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[61]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2960,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[62]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2966,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[63]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2972,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[64]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2978,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[65]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2984,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[66]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2990,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[68]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3013,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3018,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[69]+1 /* (set! stat-regular? ...) */,*((C_word*)lf[66]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3029,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1115 stat-type */
f_3018(t54,lf[70]);}

/* k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! stat-directory? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1116 stat-type */
f_3018(t3,lf[71]);}

/* k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! stat-char-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1117 stat-type */
f_3018(t3,lf[72]);}

/* k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! stat-block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1118 stat-type */
f_3018(t3,lf[73]);}

/* k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3041,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! stat-fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1119 stat-type */
f_3018(t3,lf[74]);}

/* k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! stat-symlink? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1120 stat-type */
f_3018(t3,lf[75]);}

/* k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word ab[98],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! stat-socket? ...) */,t1);
t3=C_mutate((C_word*)lf[76]+1 /* (set! file-position ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3051,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[81]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3091,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[86]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3152,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[94]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3258,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[96]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3285,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[2]+1);
t9=*((C_word*)lf[41]+1);
t10=*((C_word*)lf[98]+1);
t11=C_mutate((C_word*)lf[99]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3312,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[103]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3469,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[41]+1);
t14=C_mutate((C_word*)lf[102]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3496,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[106]+1);
t16=*((C_word*)lf[107]+1);
t17=*((C_word*)lf[108]+1);
t18=*((C_word*)lf[109]+1);
t19=*((C_word*)lf[110]+1);
t20=*((C_word*)lf[2]+1);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3540,tmp=(C_word)a,a+=2,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3545,tmp=(C_word)a,a+=2,tmp);
t23=*((C_word*)lf[113]+1);
t24=*((C_word*)lf[102]+1);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=C_mutate((C_word*)lf[93]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3612,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t25,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,tmp=(C_word)a,a+=12,tmp));
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3969,tmp=(C_word)a,a+=2,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3981,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3987,tmp=(C_word)a,a+=2,tmp);
t30=C_mutate((C_word*)lf[136]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=t28,a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp));
t31=C_mutate((C_word*)lf[138]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4041,a[2]=t28,a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp));
t32=C_mutate((C_word*)lf[139]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4077,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[142]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[139]+1));
t34=*((C_word*)lf[136]+1);
t35=*((C_word*)lf[138]+1);
t36=*((C_word*)lf[139]+1);
t37=*((C_word*)lf[142]+1);
t38=C_mutate((C_word*)lf[143]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4096,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[144]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4120,a[2]=t35,a[3]=t37,tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[145]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[147]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4164,a[2]=t35,a[3]=t37,tmp=(C_word)a,a+=4,tmp));
t42=C_mutate((C_word*)lf[149]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4184,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[151]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t44=C_mutate((C_word*)lf[152]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[153]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[154]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[155]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[156]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[157]+1 /* (set! signal/break ...) */,C_fix((C_word)SIGBREAK));
t50=C_set_block_item(lf[158] /* signal/alrm */,0,C_fix(0));
t51=C_set_block_item(lf[159] /* signal/chld */,0,C_fix(0));
t52=C_set_block_item(lf[160] /* signal/cont */,0,C_fix(0));
t53=C_set_block_item(lf[161] /* signal/hup */,0,C_fix(0));
t54=C_set_block_item(lf[162] /* signal/io */,0,C_fix(0));
t55=C_set_block_item(lf[163] /* signal/kill */,0,C_fix(0));
t56=C_set_block_item(lf[164] /* signal/pipe */,0,C_fix(0));
t57=C_set_block_item(lf[165] /* signal/prof */,0,C_fix(0));
t58=C_set_block_item(lf[166] /* signal/quit */,0,C_fix(0));
t59=C_set_block_item(lf[167] /* signal/stop */,0,C_fix(0));
t60=C_set_block_item(lf[168] /* signal/trap */,0,C_fix(0));
t61=C_set_block_item(lf[169] /* signal/tstp */,0,C_fix(0));
t62=C_set_block_item(lf[170] /* signal/urg */,0,C_fix(0));
t63=C_set_block_item(lf[171] /* signal/usr1 */,0,C_fix(0));
t64=C_set_block_item(lf[172] /* signal/usr2 */,0,C_fix(0));
t65=C_set_block_item(lf[173] /* signal/vtalrm */,0,C_fix(0));
t66=C_set_block_item(lf[174] /* signal/winch */,0,C_fix(0));
t67=C_set_block_item(lf[175] /* signal/xcpu */,0,C_fix(0));
t68=C_set_block_item(lf[176] /* signal/xfsz */,0,C_fix(0));
t69=(C_word)C_a_i_list(&a,7,*((C_word*)lf[151]+1),*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1),*((C_word*)lf[156]+1),*((C_word*)lf[157]+1));
t70=C_mutate((C_word*)lf[177]+1 /* (set! signals-list ...) */,t69);
t71=*((C_word*)lf[178]+1);
t72=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[2],a[3]=t71,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1468 make-vector */
t73=*((C_word*)lf[389]+1);
((C_proc4)(void*)(*((C_word*)t73+1)))(4,t73,t72,C_fix(256),C_SCHEME_FALSE);}

/* k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word ab[225],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=C_mutate((C_word*)lf[179]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4253,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[180]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4262,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[178]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4275,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[181]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[182]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[183]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[184]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[185]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[186]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[187]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[188]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[189]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[190]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[191]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[192]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[193]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[194]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[195]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[196]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[197]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[198]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[199]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[200]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[201]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[202]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[203]+1 /* (set! errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[204]+1 /* (set! errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[205]+1 /* (set! errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[206]+1 /* (set! errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[207]+1 /* (set! errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[208]+1 /* (set! errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[209]+1 /* (set! errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[210]+1 /* (set! errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[211]+1 /* (set! errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[212]+1 /* (set! errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[213]+1 /* (set! errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[214]+1 /* (set! errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[215]+1 /* (set! errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[216]+1 /* (set! errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[217]+1 /* (set! errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[218]+1 /* (set! errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[219]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4331,tmp=(C_word)a,a+=2,tmp));
t44=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4361,tmp=(C_word)a,a+=2,tmp);
t45=C_mutate((C_word*)lf[221]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4385,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[222]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4391,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[223]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4397,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[224]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[225]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[226]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4406,tmp=(C_word)a,a+=2,tmp);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4443,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[235]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4461,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[236]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[237]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4489,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[241]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4524,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[243]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4554,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[244]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4571,tmp=(C_word)a,a+=2,tmp));
t59=*((C_word*)lf[245]+1);
t60=C_mutate((C_word*)lf[246]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=t59,tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[247]+1 /* (set! current-environment ...) */,*((C_word*)lf[246]+1));
t62=C_mutate(&lf[248] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4652,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[250]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4671,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[252]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4680,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[253]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4694,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[255]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4727,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[258]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4787,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[261]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4802,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[262]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4810,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[263]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4826,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[264]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4832,tmp=(C_word)a,a+=2,tmp));
t72=*((C_word*)lf[270]+1);
t73=*((C_word*)lf[271]+1);
t74=*((C_word*)lf[272]+1);
t75=*((C_word*)lf[99]+1);
t76=*((C_word*)lf[273]+1);
t77=*((C_word*)lf[274]+1);
t78=C_mutate((C_word*)lf[275]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4891,a[2]=t74,a[3]=t72,a[4]=t75,a[5]=t73,a[6]=t76,a[7]=t77,tmp=(C_word)a,a+=8,tmp));
t79=C_mutate((C_word*)lf[278]+1 /* (set! spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t80=C_mutate((C_word*)lf[279]+1 /* (set! spawn/wait ...) */,C_fix((C_word)P_WAIT));
t81=C_mutate((C_word*)lf[280]+1 /* (set! spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t82=C_mutate((C_word*)lf[281]+1 /* (set! spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t83=C_mutate((C_word*)lf[282]+1 /* (set! spawn/detach ...) */,C_fix((C_word)P_DETACH));
t84=*((C_word*)lf[283]+1);
t85=*((C_word*)lf[49]+1);
t86=*((C_word*)lf[110]+1);
t87=*((C_word*)lf[2]+1);
t88=C_mutate(&lf[284] /* (set! $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5003,a[2]=t87,a[3]=t85,a[4]=t86,a[5]=t84,tmp=(C_word)a,a+=6,tmp));
t89=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5082,tmp=(C_word)a,a+=2,tmp);
t90=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5088,tmp=(C_word)a,a+=2,tmp);
t91=*((C_word*)lf[287]+1);
t92=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5094,tmp=(C_word)a,a+=2,tmp);
t93=C_mutate(&lf[288] /* (set! $exec-setup ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5144,a[2]=t91,a[3]=t89,a[4]=t90,a[5]=t92,tmp=(C_word)a,a+=6,tmp));
t94=C_mutate(&lf[289] /* (set! $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5177,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[290]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5192,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[292]+1 /* (set! process-spawn ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5276,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[294]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5360,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[295]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5363,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[299]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5384,tmp=(C_word)a,a+=2,tmp));
t100=*((C_word*)lf[292]+1);
t101=*((C_word*)lf[297]+1);
t102=C_mutate((C_word*)lf[301]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5390,a[2]=t100,tmp=(C_word)a,a+=3,tmp));
t103=C_mutate((C_word*)lf[302]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5470,tmp=(C_word)a,a+=2,tmp));
t104=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5566,tmp=(C_word)a,a+=2,tmp);
t105=C_mutate((C_word*)lf[307]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5628,a[2]=t104,tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[308]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5705,a[2]=t104,tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[309]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5782,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[310]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5794,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[312]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5851,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[313]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5854,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[315]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5866,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[113]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5897,tmp=(C_word)a,a+=2,tmp));
t113=*((C_word*)lf[275]+1);
t114=*((C_word*)lf[271]+1);
t115=*((C_word*)lf[273]+1);
t116=*((C_word*)lf[103]+1);
t117=C_mutate((C_word*)lf[319]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5912,a[2]=t116,a[3]=t115,a[4]=t113,a[5]=t114,tmp=(C_word)a,a+=6,tmp));
t118=C_mutate((C_word*)lf[326]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6129,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[328]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6135,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[329]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6141,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[330]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6147,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[331]+1 /* (set! current-effective-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6153,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[332]+1 /* (set! current-effective-user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6159,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[333]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6165,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[334]+1 /* (set! current-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6171,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[335]+1 /* (set! current-user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6177,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[336]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6183,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[337]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6189,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[338]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6195,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[339]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6201,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[340]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6207,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[341]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6213,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[342]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6219,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[343]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6225,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[344]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6231,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[345]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6237,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[346]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6243,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[347]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6249,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[348]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6255,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[349]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6261,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[350]+1 /* (set! process-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6267,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[351]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6273,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[352]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6279,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[353]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6285,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[354]+1 /* (set! set-group-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6291,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[355]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6297,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[356]+1 /* (set! set-process-group-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6303,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[357]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6309,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[358]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6315,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[359]+1 /* (set! set-user-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6321,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[360]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6327,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[361]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6333,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[362]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6339,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[363]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6345,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[364]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6351,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[365]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6357,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[366]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6363,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[367]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6369,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[368]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6375,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[369]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6381,tmp=(C_word)a,a+=2,tmp));
t161=C_set_block_item(lf[370] /* errno/wouldblock */,0,C_fix(0));
t162=C_mutate((C_word*)lf[371]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6388,tmp=(C_word)a,a+=2,tmp));
t163=C_mutate((C_word*)lf[372]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6391,tmp=(C_word)a,a+=2,tmp));
t164=C_set_block_item(lf[373] /* map/anonymous */,0,C_fix(0));
t165=C_set_block_item(lf[374] /* map/file */,0,C_fix(0));
t166=C_set_block_item(lf[375] /* map/fixed */,0,C_fix(0));
t167=C_set_block_item(lf[376] /* map/private */,0,C_fix(0));
t168=C_set_block_item(lf[377] /* map/shared */,0,C_fix(0));
t169=C_set_block_item(lf[378] /* open/fsync */,0,C_fix(0));
t170=C_set_block_item(lf[379] /* open/noctty */,0,C_fix(0));
t171=C_set_block_item(lf[380] /* open/nonblock */,0,C_fix(0));
t172=C_set_block_item(lf[381] /* open/sync */,0,C_fix(0));
t173=C_set_block_item(lf[382] /* perm/isgid */,0,C_fix(0));
t174=C_set_block_item(lf[383] /* perm/isuid */,0,C_fix(0));
t175=C_set_block_item(lf[384] /* perm/isvtx */,0,C_fix(0));
t176=C_set_block_item(lf[385] /* prot/exec */,0,C_fix(0));
t177=C_set_block_item(lf[386] /* prot/none */,0,C_fix(0));
t178=C_set_block_item(lf[387] /* prot/read */,0,C_fix(0));
t179=C_set_block_item(lf[388] /* prot/write */,0,C_fix(0));
t180=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t180+1)))(2,t180,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6391,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6388,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* string->time in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[369],lf[0]);}

/* utc-time->seconds in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[368],lf[0]);}

/* user-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6369,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[367],lf[0]);}

/* unmap-file-from-memory in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[366],lf[0]);}

/* terminal-size in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[365],lf[0]);}

/* terminal-name in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[364],lf[0]);}

/* signal-unmask! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[363],lf[0]);}

/* signal-masked? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[362],lf[0]);}

/* signal-mask! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[361],lf[0]);}

/* signal-mask in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[360],lf[0]);}

/* set-user-id! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[359],lf[0]);}

/* set-signal-mask! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[358],lf[0]);}

/* set-root-directory! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[357],lf[0]);}

/* set-process-group-id! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[356],lf[0]);}

/* set-groups! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[355],lf[0]);}

/* set-group-id! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[354],lf[0]);}

/* set-alarm! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[353],lf[0]);}

/* read-symbolic-link in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6279,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[352],lf[0]);}

/* process-signal in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6273,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[351],lf[0]);}

/* process-group-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6267,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[350],lf[0]);}

/* process-fork in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6261,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[349],lf[0]);}

/* parent-process-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6255,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[348],lf[0]);}

/* memory-mapped-file-pointer in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6249,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[347],lf[0]);}

/* initialize-groups in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6243,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[346],lf[0]);}

/* group-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6237,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[345],lf[0]);}

/* get-groups in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6231,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[344],lf[0]);}

/* file-unlock in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[343],lf[0]);}

/* file-truncate in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6219,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[342],lf[0]);}

/* file-test-lock in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6213,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[341],lf[0]);}

/* file-select in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* file-lock/blocking in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6201,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* file-lock in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6195,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* file-link in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6189,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* map-file-to-memory in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6183,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* current-user-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6177,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* current-group-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6171,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* current-effective-user-name in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6165,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* current-effective-user-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6159(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6159,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* current-effective-group-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6153,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* create-symbolic-link in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6147,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* create-session in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[329],lf[0]);}

/* create-fifo in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6135,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* change-file-owner in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6129,2,t0,t1);}
/* error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[326],lf[0]);}

/* find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5912r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5912r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5912r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6053,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6058,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6063,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action18781963 */
t9=t8;
f_6063(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id18791959 */
t11=t7;
f_6058(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit18801954 */
t13=t6;
f_6053(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body18761886 */
t15=t5;
f_5914(t15,t1,t9,t11,t13);}}}}

/* def-action1878 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6063,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6069,tmp=(C_word)a,a+=2,tmp);
/* def-id18791959 */
t3=((C_word*)t0)[2];
f_6058(t3,t1,t2);}

/* a6068 in def-action1878 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6069,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1879 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6058,NULL,3,t0,t1,t2);}
/* def-limit18801954 */
t3=((C_word*)t0)[2];
f_6053(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1880 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6053(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6053,NULL,4,t0,t1,t2,t3);}
/* body18761886 */
t4=((C_word*)t0)[2];
f_5914(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5914(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5914,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[319]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_5921(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6048,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_5921(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6040,tmp=(C_word)a,a+=2,tmp));}}

/* f_6040 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6040,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6048 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6048,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5921,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6028,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2050 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],lf[325]);}

/* k6026 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2050 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5933(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5933(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5933,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2056 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5952,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6008,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2057 pathname-file */
t3=*((C_word*)lf[324]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6014,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2063 pproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k6012 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6021,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2063 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2064 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5933(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6019 in k6012 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2063 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5933(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6008,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[320]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[321]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2057 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_5933(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2058 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k5965 in k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5967,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5979,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5998,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[323]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2062 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5933(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a5997 in k5965 in k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5998,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a5983 in k5965 in k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5996,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2061 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[322]);}

/* k5994 in a5983 in k5965 in k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2061 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5990 in a5983 in k5965 in k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2061 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5933(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5978 in k5965 in k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5979,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k5975 in k5965 in k6006 in k5950 in loop in k5929 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2059 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5933(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6032 in k5919 in body1876 in find-files in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6032,3,t0,t1,t2);}
/* posixwin.scm: 2048 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5897,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5907,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2024 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5905 in current-user-name in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2025 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[113],lf[318]);}

/* system-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5877,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5892,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2015 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5890 in system-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2016 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[315],lf[317]);}

/* k5875 in system-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5881,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k5879 in k5875 in system-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5885,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k5883 in k5879 in k5875 in system-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5889,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k5887 in k5883 in k5879 in k5875 in system-information in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5889,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[316],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 2005 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[313],lf[314]);}}

/* sleep in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5851,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5794r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5794r(t0,t1,t2,t3);}}

static void C_ccall f_5794r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_exact_2(t2,lf[310]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5812,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a5817 in process-wait in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5818,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1987 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1989 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k5826 in a5817 in process-wait in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1988 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[303],lf[310],lf[311],((C_word*)t0)[2]);}

/* a5811 in process-wait in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5812,2,t0,t1);}
/* posixwin.scm: 1984 ##sys#process-wait */
t2=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5782,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1977 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1978 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_5705r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5705r(t0,t1,t2,t3);}}

static void C_ccall f_5705r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5707,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5712,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5717,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5722,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17711794 */
t8=t7;
f_5722(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17721790 */
t10=t6;
f_5717(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17731785 */
t12=t5;
f_5712(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body17691779 */
t14=t4;
f_5707(t14,t1,t8,t10,t12);}}}}

/* def-args1771 in process* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5722,NULL,2,t0,t1);}
/* def-env17721790 */
t2=((C_word*)t0)[2];
f_5717(t2,t1,C_SCHEME_FALSE);}

/* def-env1772 in process* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5717,NULL,3,t0,t1,t2);}
/* def-exactf17731785 */
t3=((C_word*)t0)[2];
f_5712(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1773 in process* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5712(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5712,NULL,4,t0,t1,t2,t3);}
/* body17691779 */
t4=((C_word*)t0)[2];
f_5707(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1769 in process* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5707,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1971 %process */
f_5566(t1,lf[308],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_5628r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5628r(t0,t1,t2,t3);}}

static void C_ccall f_5628r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5630,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5635,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5640,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5645,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17161739 */
t8=t7;
f_5645(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17171735 */
t10=t6;
f_5640(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17181730 */
t12=t5;
f_5635(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body17141724 */
t14=t4;
f_5630(t14,t1,t8,t10,t12);}}}}

/* def-args1716 in process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5645,NULL,2,t0,t1);}
/* def-env17171735 */
t2=((C_word*)t0)[2];
f_5640(t2,t1,C_SCHEME_FALSE);}

/* def-env1717 in process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5640(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5640,NULL,3,t0,t1,t2);}
/* def-exactf17181730 */
t3=((C_word*)t0)[2];
f_5635(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1718 in process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5635(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5635,NULL,4,t0,t1,t2,t3);}
/* body17141724 */
t4=((C_word*)t0)[2];
f_5630(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1714 in process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5630,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1968 %process */
f_5566(t1,lf[307],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5566(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5566,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5587,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1956 chkstrlst */
t14=t11;
f_5568(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5622,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1959 ##sys#shell-command-arguments */
t16=*((C_word*)lf[299]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,((C_word*)t8)[1]);}}

/* k5620 in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5622,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1960 ##sys#shell-command */
t4=*((C_word*)lf[295]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5624 in k5620 in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5587(2,t3,t2);}

/* k5585 in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1961 chkstrlst */
t3=((C_word*)t0)[2];
f_5568(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_5590(2,t3,C_SCHEME_UNDEFINED);}}

/* k5588 in k5585 in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5600 in k5588 in k5585 in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5601,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1964 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1965 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5594 in k5588 in k5585 in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
/* posixwin.scm: 1962 ##sys#process */
t2=*((C_word*)lf[302]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5568,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5576 in chkstrlst in %process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5577,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr9rv,(void*)f_5470r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest_vector(a,C_rest_count(0));
f_5470r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_5470r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(14);
t10=(C_word)C_vemptyp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:(C_word)C_slot(t9,C_fix(0)));
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5477,a[2]=t2,a[3]=t6,a[4]=t7,a[5]=t8,a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5549,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_cons(&a,2,t3,t4);
/* posixwin.scm: 1928 $quote-args-list */
t15=lf[284];
f_5003(t15,t13,t14,t11);}

/* k5547 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1928 string-intersperse */
t2=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=((*(int *)C_data_pointer(t2))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t5=((*(int *)C_data_pointer(t4))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t7=((*(int *)C_data_pointer(t6))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=((*(int *)C_data_pointer(t8))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t11=*((C_word*)lf[305]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,t2,C_fix(0),C_SCHEME_FALSE,lf[306]);}

/* k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[305]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[306]);}

/* k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[305]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[306]);}

/* k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[305]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[306]);}

/* k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1935 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k5531 in k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5424,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t9=t8;
f_5424(2,t9,C_SCHEME_FALSE);}}

/* k5422 in k5531 in k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_5428(2,t3,C_SCHEME_FALSE);}}

/* k5426 in k5422 in k5531 in k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5428,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
if(C_truep((C_word)stub1538(C_SCHEME_UNDEFINED,((C_word*)t0)[13],t1,C_SCHEME_FALSE,t2,t3,t4,t5,((C_word*)t0)[12]))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5490,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1938 open-input-file* */
t7=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t7=t6;
f_5490(2,t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1943 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5508 in k5426 in k5422 in k5531 in k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1944 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[303],((C_word*)t0)[3],lf[304],((C_word*)t0)[2]);}

/* k5488 in k5426 in k5422 in k5531 in k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1939 open-output-file* */
t3=*((C_word*)lf[236]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5494(2,t3,C_SCHEME_FALSE);}}

/* k5492 in k5488 in k5426 in k5422 in k5531 in k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5498,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1941 open-input-file* */
t3=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5498(2,t3,C_SCHEME_FALSE);}}

/* k5496 in k5492 in k5488 in k5426 in k5422 in k5531 in k5527 in k5523 in k5519 in k5515 in k5475 in ##sys#process in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1937 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* process-run in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5390r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5390r(t0,t1,t2,t3);}}

static void C_ccall f_5390r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1899 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,*((C_word*)lf[280]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5407,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1900 ##sys#shell-command */
t7=*((C_word*)lf[295]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5405 in process-run in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5411,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1900 ##sys#shell-command-arguments */
t3=*((C_word*)lf[299]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5409 in k5405 in process-run in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1900 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[280]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5384,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[300],t2));}

/* ##sys#shell-command in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5367,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1883 getenv */
t3=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[298]);}

/* k5365 in ##sys#shell-command in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5367,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1887 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k5377 in k5365 in ##sys#shell-command in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1888 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[295],lf[296]);}

/* current-process-id in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5360,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1498(C_SCHEME_UNDEFINED));}

/* process-spawn in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_5276r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5276r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5276r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5278,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5290,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5295,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5300,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst14591484 */
t9=t8;
f_5300(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst14601480 */
t11=t7;
f_5295(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf14611475 */
t13=t6;
f_5290(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body14571467 */
t15=t5;
f_5278(t15,t1,t9,t11,t13);}}}}

/* def-arglst1459 in process-spawn in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5300,NULL,2,t0,t1);}
/* def-envlst14601480 */
t2=((C_word*)t0)[2];
f_5295(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1460 in process-spawn in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5295,NULL,3,t0,t1,t2);}
/* def-exactf14611475 */
t3=((C_word*)t0)[2];
f_5290(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1461 in process-spawn in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5290,NULL,4,t0,t1,t2,t3);}
/* body14571467 */
t4=((C_word*)t0)[2];
f_5278(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1457 in process-spawn in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5278(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5278,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1874 $exec-setup */
t6=lf[288];
f_5144(t6,t5,lf[292],((C_word*)t0)[2],t2,t3,t4);}

/* k5280 in body1457 in process-spawn in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1875 $exec-teardown */
f_5177(((C_word*)t0)[3],lf[292],lf[293],((C_word*)t0)[2],t2);}

/* process-execute in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_5192r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5192r(t0,t1,t2,t3);}}

static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5206,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5211,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5216,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst13991424 */
t8=t7;
f_5216(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst14001420 */
t10=t6;
f_5211(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf14011415 */
t12=t5;
f_5206(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body13971407 */
t14=t4;
f_5194(t14,t1,t8,t10,t12);}}}}

/* def-arglst1399 in process-execute in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5216,NULL,2,t0,t1);}
/* def-envlst14001420 */
t2=((C_word*)t0)[2];
f_5211(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1400 in process-execute in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5211,NULL,3,t0,t1,t2);}
/* def-exactf14011415 */
t3=((C_word*)t0)[2];
f_5206(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1401 in process-execute in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5206(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5206,NULL,4,t0,t1,t2,t3);}
/* body13971407 */
t4=((C_word*)t0)[2];
f_5194(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1397 in process-execute in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5194(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5194,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1869 $exec-setup */
t6=lf[288];
f_5144(t6,t5,lf[290],((C_word*)t0)[2],t2,t3,t4);}

/* k5196 in body1397 in process-execute in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1870 $exec-teardown */
f_5177(((C_word*)t0)[3],lf[290],lf[291],((C_word*)t0)[2],t2);}

/* $exec-teardown in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5177(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5177,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5181,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1861 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k5179 in $exec-teardown in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1865 ##sys#error */
t5=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5144(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5144,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5151,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1853 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k5149 in $exec-setup in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1854 setarg */
t4=((C_word*)t0)[4];
f_5082(5,t4,t2,C_fix(0),t1,t3);}

/* k5152 in k5149 in $exec-setup in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5157,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1855 $quote-args-list */
t4=lf[284];
f_5003(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5169 in k5152 in k5149 in $exec-setup in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1855 build-exec-argvec */
f_5094(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k5155 in k5152 in k5149 in $exec-setup in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1856 build-exec-argvec */
f_5094(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k5158 in k5155 in k5152 in k5149 in $exec-setup in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1858 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5165 in k5158 in k5155 in k5152 in k5149 in $exec-setup in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1858 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5094(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5094,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5106,a[2]=t8,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_5106(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1850 argvec-setter */
t6=t4;
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop1337 in build-exec-argvec in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5106(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5106,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1846 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5125,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1849 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t3,t4,t7);}}

/* k5123 in doloop1337 in build-exec-argvec in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5106(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5088,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1323(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* setarg in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5082,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1311(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5003(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5003,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5046,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5046(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5046(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5046,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1827 reverse */
t4=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5074,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5077,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1832 needs-quoting? */
t8=((C_word*)t0)[2];
f_5008(t8,t7,t4);}}

/* k5075 in loop in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1832 string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[285],((C_word*)t0)[2],lf[286]);}
else{
t2=((C_word*)t0)[3];
f_5074(2,t2,((C_word*)t0)[2]);}}

/* k5072 in loop in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5074,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1829 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5046(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5008,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5012,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1819 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5010 in needs-quoting? in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5017(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5010 in needs-quoting? in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5017,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5041,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1823 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k5039 in loop in k5010 in needs-quoting? in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1823 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5028 in loop in k5010 in needs-quoting? in $quote-args-list in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1824 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5017(t3,((C_word*)t0)[4],t2);}}

/* glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_4891r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4891r(t0,t1,t2);}}

static void C_ccall f_4891r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4897(t6,t1,t2);}

/* conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4897(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4897,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4912,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4918,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4992,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[277]);
/* posixwin.scm: 1781 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k4990 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1781 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4920 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1782 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4923 in k4920 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[276]);
/* posixwin.scm: 1783 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k4930 in k4923 in k4920 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4932,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_4934(t5,((C_word*)t0)[2],t1);}

/* loop in k4930 in k4923 in k4920 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4934(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4934,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixwin.scm: 1784 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4897(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4951,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixwin.scm: 1785 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k4949 in loop in k4930 in k4923 in k4920 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4951,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixwin.scm: 1786 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixwin.scm: 1787 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4934(t3,((C_word*)t0)[6],t2);}}

/* k4959 in k4949 in loop in k4930 in k4923 in k4920 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4965,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1786 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4934(t4,t2,t3);}

/* k4963 in k4959 in k4949 in loop in k4930 in k4923 in k4920 in a4917 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4911 in conc-loop in glob in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4912,2,t0,t1);}
/* posixwin.scm: 1780 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4832r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4832r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4836,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1752 ##sys#check-port */
t6=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[264]);}

/* k4834 in set-buffering-mode! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[266]);
if(C_truep(t6)){
t7=t5;
f_4842(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[267]);
if(C_truep(t7)){
t8=t5;
f_4842(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[268]);
if(C_truep(t8)){
t9=t5;
f_4842(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1758 ##sys#error */
t9=*((C_word*)lf[130]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[264],lf[269],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k4840 in k4834 in set-buffering-mode! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[264]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[78],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1764 ##sys#error */
t6=*((C_word*)lf[130]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[264],lf[265],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* terminal-port? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4826,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4830,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1742 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[263]);}

/* k4828 in terminal-port? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4810r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4810r(t0,t1,t2);}}

static void C_ccall f_4810r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1149(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4802,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1141(t2),C_fix(0));}

/* local-time->seconds in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4787,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1724 check-time-vector */
f_4652(t3,lf[258],t2);}

/* k4789 in local-time->seconds in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1726 ##sys#cons-flonum */
t2=*((C_word*)lf[259]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1727 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[258],lf[260],((C_word*)t0)[3]);}}

/* time->string in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4727r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4727r(t0,t1,t2,t3);}}

static void C_ccall f_4727r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4734,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1712 check-time-vector */
f_4652(t6,lf[255],t2);}

/* k4732 in time->string in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[255]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4753,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1716 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1090(t4,t3),C_fix(0));}}

/* k4754 in k4732 in time->string in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1720 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1721 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[257],((C_word*)t0)[2]);}}

/* k4751 in k4732 in time->string in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4753,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1098(t3,t2,t1),C_fix(0));}

/* k4741 in k4732 in time->string in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1717 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[256],((C_word*)t0)[2]);}}

/* seconds->string in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4694,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1075(t5,t4),C_fix(0));}

/* k4696 in seconds->string in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1705 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1706 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[253],lf[254],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4680,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[252]);
/* posixwin.scm: 1698 ##sys#decode-seconds */
t4=*((C_word*)lf[251]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4671,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[250]);
/* posixwin.scm: 1694 ##sys#decode-seconds */
t4=*((C_word*)lf[251]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4652(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4652,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1690 ##sys#error */
t6=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[249],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* get-environment-variables in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4592(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4592,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4596,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1031(t5,t4),C_fix(0));}

/* k4594 in loop in get-environment-variables in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4604,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4604(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4594 in loop in get-environment-variables in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4604(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4604,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1679 substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1680 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4628 in scan in k4594 in loop in get-environment-variables in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1679 substring */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k4632 in k4628 in scan in k4594 in loop in get-environment-variables in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4622,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1679 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4592(t5,t3,t4);}

/* k4620 in k4632 in k4628 in scan in k4594 in loop in get-environment-variables in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4571,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[244]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4579,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1667 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4577 in unsetenv in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4554,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[243]);
t5=(C_word)C_i_check_string_2(t3,lf[243]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4565,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1662 ##sys#make-c-string */
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4563 in setenv in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1662 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4567 in k4563 in setenv in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4524r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4524r(t0,t1,t2,t3);}}

static void C_ccall f_4524r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[241]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4531(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[241]);
t8=t5;
f_4531(t8,(C_word)C_dup2(t2,t6));}}

/* k4529 in duplicate-fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4531,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4534,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1651 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4534(2,t3,C_SCHEME_UNDEFINED);}}

/* k4538 in k4529 in duplicate-fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1652 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[241],lf[242],((C_word*)t0)[2]);}

/* k4532 in k4529 in duplicate-fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4489,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1633 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[237]);}

/* k4491 in port->fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1634 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4520 in k4491 in port->fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4522,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1640 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[44],lf[237],lf[238],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4502,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1637 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4502(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4506 in k4520 in k4491 in port->fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1638 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[237],lf[239],((C_word*)t0)[2]);}

/* k4500 in k4520 in k4491 in port->fileno in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4475r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4475r(t0,t1,t2,t3);}}

static void C_ccall f_4475r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[236]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4487,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1629 mode */
f_4406(t5,C_SCHEME_FALSE,t3);}

/* k4485 in open-output-file* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1629 check */
f_4443(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4461r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4461r(t0,t1,t2,t3);}}

static void C_ccall f_4461r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[235]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4473,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1625 mode */
f_4406(t5,C_SCHEME_TRUE,t3);}

/* k4471 in open-input-file* in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1625 check */
f_4443(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4443(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4443,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4447,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1616 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4445 in check in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1618 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[233],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1619 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[234],lf[78]);}}

/* k4457 in k4445 in check in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4406(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4406,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4414,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[227]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1611 ##sys#error */
t8=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[228],t5);}
else{
t8=t4;
f_4414(2,t8,lf[229]);}}
else{
/* posixwin.scm: 1612 ##sys#error */
t7=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[230],t5);}}
else{
t5=t4;
f_4414(2,t5,(C_truep(t2)?lf[231]:lf[232]));}}

/* k4412 in mode in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1607 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4397,3,t0,t1,t2);}
/* posixwin.scm: 1591 check */
f_4361(t1,t2,C_fix((C_word)2),lf[223]);}

/* file-write-access? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4391,3,t0,t1,t2);}
/* posixwin.scm: 1590 check */
f_4361(t1,t2,C_fix((C_word)4),lf[222]);}

/* file-read-access? in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4385,3,t0,t1,t2);}
/* posixwin.scm: 1589 check */
f_4361(t1,t2,C_fix((C_word)2),lf[221]);}

/* check in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4361(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4361,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4379,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4383,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1586 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4381 in check in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1586 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4377 in check in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4371(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1587 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4369 in k4377 in check in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4331,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[219]);
t5=(C_word)C_i_check_exact_2(t3,lf[219]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4355,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4359,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1575 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4357 in change-file-mode in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1575 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4353 in change-file-mode in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4355,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1576 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4345 in k4353 in change-file-mode in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1577 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[219],lf[220],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4275,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4285,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1483 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1485 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k4283 in ##sys#interrupt-hook in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1484 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4262,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[180]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k4249 in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4253,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[179]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4184r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4184r(t0,t1,t2);}}

static void C_ccall f_4184r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?(C_word)C_u_fixnum_or(*((C_word*)lf[19]+1),*((C_word*)lf[21]+1)):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4191,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t4),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4200,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1420 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_4191(2,t6,C_SCHEME_UNDEFINED);}}

/* k4198 in create-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1421 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[35],lf[149],lf[150]);}

/* k4189 in create-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1422 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4164r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4164r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4164r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[148]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4168,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4166 in with-output-to-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4174,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1405 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4173 in k4166 in with-output-to-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4174r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4174r(t0,t1,t2);}}

static void C_ccall f_4174r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4178,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1407 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4176 in a4173 in k4166 in with-output-to-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4144r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4144r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4144r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[146]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4148,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4146 in with-input-from-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=C_mutate((C_word*)lf[146]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4154,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1395 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4153 in k4146 in with-input-from-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4154r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4154r(t0,t1,t2);}}

static void C_ccall f_4154r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4158,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1397 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4156 in a4153 in k4146 in with-input-from-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[146]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4120r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4120r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4120r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4124,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4122 in call-with-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1385 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4134 in k4122 in call-with-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4135r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4135r(t0,t1,t2);}}

static void C_ccall f_4135r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4139,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1388 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4137 in a4134 in k4122 in call-with-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4128 in k4122 in call-with-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
/* posixwin.scm: 1386 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4096r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4096r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4096r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4100,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4098 in call-with-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4105,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1377 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4110 in k4098 in call-with-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4111r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4111r(t0,t1,t2);}}

static void C_ccall f_4111r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1380 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4113 in a4110 in k4098 in call-with-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4104 in k4098 in call-with-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
/* posixwin.scm: 1378 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4077,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4081,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1364 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[139]);}

/* k4079 in close-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4081,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1366 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4082 in k4079 in close-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1367 ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[35],lf[139],lf[140],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4041r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4041r(t0,t1,t2,t3);}}

static void C_ccall f_4041r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[138]);
t5=f_3969(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4055,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[129]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1359 ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4072,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1360 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1361 badmode */
f_3981(t6,t5);}}}

/* k4070 in open-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4055(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4060 in open-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4062,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4055(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4053 in open-output-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1356 check */
f_3987(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4005r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4005r(t0,t1,t2,t3);}}

static void C_ccall f_4005r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[136]);
t5=f_3969(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4019,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[129]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4026,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1349 ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1350 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1351 badmode */
f_3981(t6,t5);}}}

/* k4034 in open-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4036,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4019(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4024 in open-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4019(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4017 in open-input-pipe in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1346 check */
f_3987(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3987(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3987,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3991,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1336 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3989 in check in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1338 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[132],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1339 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[135],lf[78]);}}

/* k4001 in k3989 in check in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3981(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3981,NULL,2,t1,t2);}
/* posixwin.scm: 1334 ##sys#error */
t3=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[131],t2);}

/* mode in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static C_word C_fcall f_3969(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[129]));}

/* canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3612,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[93]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3619,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3752,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1273 cwd */
t8=((C_word*)t0)[5];
f_3556(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1275 sref */
t10=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3758(t9,C_SCHEME_FALSE);}}}

/* k3957 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1275 sep? */
t2=((C_word*)t0)[3];
f_3758(t2,f_3545(t1));}

/* k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3758,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1277 cwd */
t4=((C_word*)t0)[7];
f_3556(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1280 cwd */
t5=((C_word*)t0)[7];
f_3556(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3945,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1281 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3943 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1281 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3932 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1282 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3788(t2,C_SCHEME_FALSE);}}

/* k3939 in k3932 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1282 sep? */
t2=((C_word*)t0)[3];
f_3788(t2,f_3545(t1));}

/* k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3788,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3795,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1284 cwd */
t4=((C_word*)t0)[6];
f_3556(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1290 cwd */
t5=((C_word*)t0)[6];
f_3556(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3927,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1291 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3925 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1291 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3904 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3923,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1292 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_3830(t2,C_SCHEME_FALSE);}}

/* k3921 in k3904 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1292 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3910 in k3904 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1293 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_3830(t2,C_SCHEME_FALSE);}}

/* k3917 in k3910 in k3904 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1293 sep? */
t2=((C_word*)t0)[3];
f_3830(t2,f_3545(t1));}

/* k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_3619(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3903,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1295 sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3901 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1295 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3880 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3899,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1296 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3836(2,t2,C_SCHEME_FALSE);}}

/* k3897 in k3880 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1296 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3886 in k3880 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1297 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3836(2,t2,C_SCHEME_FALSE);}}

/* k3893 in k3886 in k3880 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3834 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3836,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1299 ##sys#substring */
t3=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1303 sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k3877 in k3834 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=f_3545(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1305 cwd */
t5=((C_word*)t0)[2];
f_3556(t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1308 cwd */
t4=((C_word*)t0)[2];
f_3556(t4,t3);}}

/* k3873 in k3877 in k3834 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1308 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[128],((C_word*)t0)[2]);}

/* k3866 in k3877 in k3834 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1305 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3862 in k3877 in k3834 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1304 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3841 in k3834 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3847,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1301 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3845 in k3841 in k3834 in k3828 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1298 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[127],t1);}

/* k3822 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1290 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[126],((C_word*)t0)[2]);}

/* k3809 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1284 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k3793 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3799,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1286 user */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3797 in k3793 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3803,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1287 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3801 in k3797 in k3793 in k3786 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1283 sappend */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[125],((C_word*)t0)[2],t1);}

/* k3780 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1280 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[124],((C_word*)t0)[2]);}

/* k3767 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1277 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3763 in k3756 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1276 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3750 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1273 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[123]);}

/* k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3738,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1309 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t1,C_fix(3),t4);}

/* k3736 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[122]);}

/* k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3626,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_3628(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3628,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1311 null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3635,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1312 null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3707,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1323 string=? */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[121],t5);}}

/* k3708 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3710,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3707(t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1325 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[120],t3);}}

/* k3717 in k3708 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3707(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_3707(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k3705 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1321 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3628(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1313 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1314 sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k3686 in k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=f_3545(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1316 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1319 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k3674 in k3686 in k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3680,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3684,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1320 reverse */
t4=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3682 in k3674 in k3686 in k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1320 isperse */
f_3540(((C_word*)t0)[2],t1);}

/* k3678 in k3674 in k3686 in k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1318 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3655 in k3686 in k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3661,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3665,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[118],((C_word*)t0)[2]);
/* posixwin.scm: 1317 reverse */
t5=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3663 in k3655 in k3686 in k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1317 isperse */
f_3540(((C_word*)t0)[2],t1);}

/* k3659 in k3655 in k3686 in k3639 in k3633 in loop in k3624 in k3617 in canonical-path in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1315 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3556(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3556,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3563,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3564 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3565,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3589,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[116]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a3588 in a3564 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a3600 in a3588 in a3564 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3601r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3601r(t0,t1,t2);}}

static void C_ccall f_3601r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3607,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k577583 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3606 in a3600 in a3588 in a3564 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3594 in a3588 in a3564 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
/* posixwin.scm: 1268 cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a3570 in a3564 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3571,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k577583 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3576 in a3570 in a3564 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3577,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[114]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[115]);}

/* k3561 in cwd in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* sep? in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static C_word C_fcall f_3545(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3540(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3540,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[112]);}

/* current-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3496r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3496r(t0,t1,t2);}}

static void C_ccall f_3496r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixwin.scm: 1246 change-directory */
t5=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1247 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k3507 in current-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3512,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1249 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3510 in k3507 in current-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1251 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1252 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[102],lf[105]);}}

/* directory? in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3469,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1239 ##sys#expand-home-path */
t7=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k3492 in directory? in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1239 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3488 in directory? in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1238 ##sys#file-info */
t2=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3474 in directory? in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_3312r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3312r(t0,t1,t2);}}

static void C_ccall f_3312r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3420,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec424482 */
t6=t5;
f_3420(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?425478 */
t8=t4;
f_3415(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body422431 */
t10=t3;
f_3314(t10,t1,t6,t8);}}}

/* def-spec424 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3420,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3428,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1209 current-directory */
t3=*((C_word*)lf[102]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3426 in def-spec424 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?425478 */
t2=((C_word*)t0)[3];
f_3415(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?425 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3415(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3415,NULL,3,t0,t1,t2);}
/* body422431 */
t3=((C_word*)t0)[2];
f_3314(t3,t1,t2,C_SCHEME_FALSE);}

/* body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3314(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3314,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[99]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3321,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1211 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1212 ##sys#make-pointer */
t3=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1213 ##sys#make-pointer */
t3=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3414,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1214 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k3412 in k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1214 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3329 in k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1217 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3348,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3348(t6,((C_word*)t0)[6]);}}

/* loop in k3329 in k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3348,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1226 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k3356 in loop in k3329 in k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=(C_word)C_subchar(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_subchar(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3370,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_3370(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_3370(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_3370(t7,C_SCHEME_FALSE);}}

/* k3368 in k3356 in loop in k3329 in k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3370,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1233 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3348(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1234 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3348(t3,t2);}}

/* k3378 in k3368 in k3356 in loop in k3329 in k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3338 in k3329 in k3325 in k3322 in k3319 in body422 in directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1218 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[99],lf[100],((C_word*)t0)[2]);}

/* delete-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3285,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3306,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1201 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3308 in delete-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1201 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3304 in delete-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1202 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3296 in k3304 in delete-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1203 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[96],lf[97],((C_word*)t0)[2]);}

/* change-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3258,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[94]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3279,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3283,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1194 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3281 in change-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1194 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3277 in change-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3279,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1195 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3269 in k3277 in change-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1196 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[94],lf[95],((C_word*)t0)[2]);}

/* create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3152r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3152r(t0,t1,t2,t3);}}

static void C_ccall f_3152r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[86]);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1182 canonical-path */
t8=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1183 canonical-path */
t8=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k3225 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3244,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3242 in k3225 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1154 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3234 in k3242 in k3225 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1155 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[86],lf[87],((C_word*)t0)[2]);}

/* k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1170 string-split */
t3=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[92]);}

/* k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* for-each */
t7=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a3175 in k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3181,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1174 string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[89],t2);}

/* k3179 in a3175 in k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3187,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3207,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1159 file-exists? */
t6=*((C_word*)lf[88]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k3205 in k3179 in a3175 in k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1160 ##sys#file-info */
t3=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3187(t2,C_SCHEME_FALSE);}}

/* k3208 in k3205 in k3179 in a3175 in k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
f_3187(t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
f_3187(t2,C_SCHEME_FALSE);}}

/* k3185 in k3179 in a3175 in k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3187,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3202 in k3185 in k3179 in a3175 in k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1154 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3194 in k3202 in k3185 in k3179 in a3175 in k3166 in k3163 in create-directory in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1155 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[86],lf[87],((C_word*)t0)[2]);}

/* set-file-position! in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3091r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3091r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3091r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[81]);
t8=(C_word)C_i_check_exact_2(t6,lf[81]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3104,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1140 ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[84],lf[81],lf[85],t3,t2);}
else{
t10=t9;
f_3104(2,t10,C_SCHEME_UNDEFINED);}}

/* k3102 in set-file-position! in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1141 port? */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k3117 in k3102 in set-file-position! in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[78]);
t4=((C_word*)t0)[4];
f_3110(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_3110(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1145 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[44],lf[81],lf[83],((C_word*)t0)[5]);}}}

/* k3108 in k3102 in set-file-position! in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1146 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3111 in k3108 in k3102 in set-file-position! in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1147 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[81],lf[82],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3051,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3055,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1124 port? */
t5=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3068 in file-position in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[78]);
t4=((C_word*)t0)[2];
f_3055(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_3055(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1129 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[44],lf[76],lf[79],((C_word*)t0)[3]);}}}

/* k3053 in file-position in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3058,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1131 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3058(2,t3,C_SCHEME_UNDEFINED);}}

/* k3062 in k3053 in file-position in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1132 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[76],lf[77],((C_word*)t0)[2]);}

/* k3056 in k3053 in file-position in k3047 in k3043 in k3039 in k3035 in k3031 in k3027 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3018(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3018,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3020,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_3020 in stat-type in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3020,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3013,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[68]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2990,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[66]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3011,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1102 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3009 in regular-file? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1102 ##sys#file-info */
t2=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2995 in regular-file? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2984,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1098 ##sys#stat */
f_2892(t3,t2);}

/* k2986 in file-permissions in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2978,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_2892(t3,t2);}

/* k2980 in file-owner in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2972,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_2892(t3,t2);}

/* k2974 in file-change-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2966,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_2892(t3,t2);}

/* k2968 in file-access-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2960,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2964,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#stat */
f_2892(t3,t2);}

/* k2962 in file-modification-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2954,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1093 ##sys#stat */
f_2892(t3,t2);}

/* k2956 in file-size in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2930r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2930r(t0,t1,t2,t3);}}

static void C_ccall f_2930r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2937,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1087 ##sys#stat */
f_2892(t6,t2);}

/* k2935 in file-stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_2892(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2892,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2896(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2921,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1080 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1081 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[44],lf[58],t2);}}}

/* k2923 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1080 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2919 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2896(2,t2,(C_word)C_stat(t1));}

/* k2894 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1083 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2903 in k2894 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1084 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[57],((C_word*)t0)[2]);}

/* file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2854,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[50]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1049 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2859 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1051 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k2862 in k2859 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1053 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2867(2,t4,C_SCHEME_UNDEFINED);}}

/* k2882 in k2862 in k2859 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1054 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[50],lf[52],((C_word*)t0)[2]);}

/* k2865 in k2862 in k2859 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1055 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2872 in k2865 in k2862 in k2859 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1055 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2812r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2812r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[46]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2819,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2819(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1036 ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[44],lf[46],lf[48],t3);}}

/* k2817 in file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[46]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2828,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2834,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1041 ##sys#update-errno */
t9=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2828(2,t8,C_SCHEME_UNDEFINED);}}

/* k2832 in k2817 in file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1042 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[46],lf[47],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2826 in k2817 in file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2767r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2767r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2767r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[42]);
t6=(C_word)C_i_check_exact_2(t3,lf[42]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2777,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2777(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixwin.scm: 1023 make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k2775 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2780(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1025 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[44],lf[42],lf[45],t1);}}

/* k2778 in k2775 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2783,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1028 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2783(2,t5,C_SCHEME_UNDEFINED);}}

/* k2790 in k2778 in k2775 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1029 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[42],lf[43],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2781 in k2778 in k2775 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2749,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[39]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2762,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1015 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2760 in file-close in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1016 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[39],lf[40],((C_word*)t0)[2]);}

/* file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2708r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2708r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[34]);
t8=(C_word)C_i_check_exact_2(t3,lf[34]);
t9=(C_word)C_i_check_exact_2(t6,lf[34]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2725,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2741,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1005 ##sys#expand-home-path */
t12=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k2739 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1005 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2723 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2728,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1007 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2728(2,t5,C_SCHEME_UNDEFINED);}}

/* k2732 in k2723 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1008 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[35],lf[34],lf[36],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2726 in k2723 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2662r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2662r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2662r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2666,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 936  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2664 in posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub23(t4,t1),C_fix(0));}

/* k2675 in k2664 in posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 937  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k2671 in k2664 in posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[454] = {
{"toplevel:posixwin_scm",(void*)C_posix_toplevel},
{"f_2637:posixwin_scm",(void*)f_2637},
{"f_2640:posixwin_scm",(void*)f_2640},
{"f_2643:posixwin_scm",(void*)f_2643},
{"f_2646:posixwin_scm",(void*)f_2646},
{"f_2649:posixwin_scm",(void*)f_2649},
{"f_2652:posixwin_scm",(void*)f_2652},
{"f_2655:posixwin_scm",(void*)f_2655},
{"f_3029:posixwin_scm",(void*)f_3029},
{"f_3033:posixwin_scm",(void*)f_3033},
{"f_3037:posixwin_scm",(void*)f_3037},
{"f_3041:posixwin_scm",(void*)f_3041},
{"f_3045:posixwin_scm",(void*)f_3045},
{"f_3049:posixwin_scm",(void*)f_3049},
{"f_4251:posixwin_scm",(void*)f_4251},
{"f_6391:posixwin_scm",(void*)f_6391},
{"f_6388:posixwin_scm",(void*)f_6388},
{"f_6381:posixwin_scm",(void*)f_6381},
{"f_6375:posixwin_scm",(void*)f_6375},
{"f_6369:posixwin_scm",(void*)f_6369},
{"f_6363:posixwin_scm",(void*)f_6363},
{"f_6357:posixwin_scm",(void*)f_6357},
{"f_6351:posixwin_scm",(void*)f_6351},
{"f_6345:posixwin_scm",(void*)f_6345},
{"f_6339:posixwin_scm",(void*)f_6339},
{"f_6333:posixwin_scm",(void*)f_6333},
{"f_6327:posixwin_scm",(void*)f_6327},
{"f_6321:posixwin_scm",(void*)f_6321},
{"f_6315:posixwin_scm",(void*)f_6315},
{"f_6309:posixwin_scm",(void*)f_6309},
{"f_6303:posixwin_scm",(void*)f_6303},
{"f_6297:posixwin_scm",(void*)f_6297},
{"f_6291:posixwin_scm",(void*)f_6291},
{"f_6285:posixwin_scm",(void*)f_6285},
{"f_6279:posixwin_scm",(void*)f_6279},
{"f_6273:posixwin_scm",(void*)f_6273},
{"f_6267:posixwin_scm",(void*)f_6267},
{"f_6261:posixwin_scm",(void*)f_6261},
{"f_6255:posixwin_scm",(void*)f_6255},
{"f_6249:posixwin_scm",(void*)f_6249},
{"f_6243:posixwin_scm",(void*)f_6243},
{"f_6237:posixwin_scm",(void*)f_6237},
{"f_6231:posixwin_scm",(void*)f_6231},
{"f_6225:posixwin_scm",(void*)f_6225},
{"f_6219:posixwin_scm",(void*)f_6219},
{"f_6213:posixwin_scm",(void*)f_6213},
{"f_6207:posixwin_scm",(void*)f_6207},
{"f_6201:posixwin_scm",(void*)f_6201},
{"f_6195:posixwin_scm",(void*)f_6195},
{"f_6189:posixwin_scm",(void*)f_6189},
{"f_6183:posixwin_scm",(void*)f_6183},
{"f_6177:posixwin_scm",(void*)f_6177},
{"f_6171:posixwin_scm",(void*)f_6171},
{"f_6165:posixwin_scm",(void*)f_6165},
{"f_6159:posixwin_scm",(void*)f_6159},
{"f_6153:posixwin_scm",(void*)f_6153},
{"f_6147:posixwin_scm",(void*)f_6147},
{"f_6141:posixwin_scm",(void*)f_6141},
{"f_6135:posixwin_scm",(void*)f_6135},
{"f_6129:posixwin_scm",(void*)f_6129},
{"f_5912:posixwin_scm",(void*)f_5912},
{"f_6063:posixwin_scm",(void*)f_6063},
{"f_6069:posixwin_scm",(void*)f_6069},
{"f_6058:posixwin_scm",(void*)f_6058},
{"f_6053:posixwin_scm",(void*)f_6053},
{"f_5914:posixwin_scm",(void*)f_5914},
{"f_6040:posixwin_scm",(void*)f_6040},
{"f_6048:posixwin_scm",(void*)f_6048},
{"f_5921:posixwin_scm",(void*)f_5921},
{"f_6028:posixwin_scm",(void*)f_6028},
{"f_5931:posixwin_scm",(void*)f_5931},
{"f_5933:posixwin_scm",(void*)f_5933},
{"f_5952:posixwin_scm",(void*)f_5952},
{"f_6014:posixwin_scm",(void*)f_6014},
{"f_6021:posixwin_scm",(void*)f_6021},
{"f_6008:posixwin_scm",(void*)f_6008},
{"f_5967:posixwin_scm",(void*)f_5967},
{"f_5998:posixwin_scm",(void*)f_5998},
{"f_5984:posixwin_scm",(void*)f_5984},
{"f_5996:posixwin_scm",(void*)f_5996},
{"f_5992:posixwin_scm",(void*)f_5992},
{"f_5979:posixwin_scm",(void*)f_5979},
{"f_5977:posixwin_scm",(void*)f_5977},
{"f_6032:posixwin_scm",(void*)f_6032},
{"f_5897:posixwin_scm",(void*)f_5897},
{"f_5907:posixwin_scm",(void*)f_5907},
{"f_5866:posixwin_scm",(void*)f_5866},
{"f_5892:posixwin_scm",(void*)f_5892},
{"f_5877:posixwin_scm",(void*)f_5877},
{"f_5881:posixwin_scm",(void*)f_5881},
{"f_5885:posixwin_scm",(void*)f_5885},
{"f_5889:posixwin_scm",(void*)f_5889},
{"f_5854:posixwin_scm",(void*)f_5854},
{"f_5851:posixwin_scm",(void*)f_5851},
{"f_5794:posixwin_scm",(void*)f_5794},
{"f_5818:posixwin_scm",(void*)f_5818},
{"f_5828:posixwin_scm",(void*)f_5828},
{"f_5812:posixwin_scm",(void*)f_5812},
{"f_5782:posixwin_scm",(void*)f_5782},
{"f_5705:posixwin_scm",(void*)f_5705},
{"f_5722:posixwin_scm",(void*)f_5722},
{"f_5717:posixwin_scm",(void*)f_5717},
{"f_5712:posixwin_scm",(void*)f_5712},
{"f_5707:posixwin_scm",(void*)f_5707},
{"f_5628:posixwin_scm",(void*)f_5628},
{"f_5645:posixwin_scm",(void*)f_5645},
{"f_5640:posixwin_scm",(void*)f_5640},
{"f_5635:posixwin_scm",(void*)f_5635},
{"f_5630:posixwin_scm",(void*)f_5630},
{"f_5566:posixwin_scm",(void*)f_5566},
{"f_5622:posixwin_scm",(void*)f_5622},
{"f_5626:posixwin_scm",(void*)f_5626},
{"f_5587:posixwin_scm",(void*)f_5587},
{"f_5590:posixwin_scm",(void*)f_5590},
{"f_5601:posixwin_scm",(void*)f_5601},
{"f_5595:posixwin_scm",(void*)f_5595},
{"f_5568:posixwin_scm",(void*)f_5568},
{"f_5577:posixwin_scm",(void*)f_5577},
{"f_5470:posixwin_scm",(void*)f_5470},
{"f_5549:posixwin_scm",(void*)f_5549},
{"f_5477:posixwin_scm",(void*)f_5477},
{"f_5517:posixwin_scm",(void*)f_5517},
{"f_5521:posixwin_scm",(void*)f_5521},
{"f_5525:posixwin_scm",(void*)f_5525},
{"f_5529:posixwin_scm",(void*)f_5529},
{"f_5533:posixwin_scm",(void*)f_5533},
{"f_5424:posixwin_scm",(void*)f_5424},
{"f_5428:posixwin_scm",(void*)f_5428},
{"f_5510:posixwin_scm",(void*)f_5510},
{"f_5490:posixwin_scm",(void*)f_5490},
{"f_5494:posixwin_scm",(void*)f_5494},
{"f_5498:posixwin_scm",(void*)f_5498},
{"f_5390:posixwin_scm",(void*)f_5390},
{"f_5407:posixwin_scm",(void*)f_5407},
{"f_5411:posixwin_scm",(void*)f_5411},
{"f_5384:posixwin_scm",(void*)f_5384},
{"f_5363:posixwin_scm",(void*)f_5363},
{"f_5367:posixwin_scm",(void*)f_5367},
{"f_5379:posixwin_scm",(void*)f_5379},
{"f_5360:posixwin_scm",(void*)f_5360},
{"f_5276:posixwin_scm",(void*)f_5276},
{"f_5300:posixwin_scm",(void*)f_5300},
{"f_5295:posixwin_scm",(void*)f_5295},
{"f_5290:posixwin_scm",(void*)f_5290},
{"f_5278:posixwin_scm",(void*)f_5278},
{"f_5282:posixwin_scm",(void*)f_5282},
{"f_5192:posixwin_scm",(void*)f_5192},
{"f_5216:posixwin_scm",(void*)f_5216},
{"f_5211:posixwin_scm",(void*)f_5211},
{"f_5206:posixwin_scm",(void*)f_5206},
{"f_5194:posixwin_scm",(void*)f_5194},
{"f_5198:posixwin_scm",(void*)f_5198},
{"f_5177:posixwin_scm",(void*)f_5177},
{"f_5181:posixwin_scm",(void*)f_5181},
{"f_5144:posixwin_scm",(void*)f_5144},
{"f_5151:posixwin_scm",(void*)f_5151},
{"f_5154:posixwin_scm",(void*)f_5154},
{"f_5171:posixwin_scm",(void*)f_5171},
{"f_5157:posixwin_scm",(void*)f_5157},
{"f_5160:posixwin_scm",(void*)f_5160},
{"f_5167:posixwin_scm",(void*)f_5167},
{"f_5094:posixwin_scm",(void*)f_5094},
{"f_5106:posixwin_scm",(void*)f_5106},
{"f_5125:posixwin_scm",(void*)f_5125},
{"f_5088:posixwin_scm",(void*)f_5088},
{"f_5082:posixwin_scm",(void*)f_5082},
{"f_5003:posixwin_scm",(void*)f_5003},
{"f_5046:posixwin_scm",(void*)f_5046},
{"f_5077:posixwin_scm",(void*)f_5077},
{"f_5074:posixwin_scm",(void*)f_5074},
{"f_5008:posixwin_scm",(void*)f_5008},
{"f_5012:posixwin_scm",(void*)f_5012},
{"f_5017:posixwin_scm",(void*)f_5017},
{"f_5041:posixwin_scm",(void*)f_5041},
{"f_5030:posixwin_scm",(void*)f_5030},
{"f_4891:posixwin_scm",(void*)f_4891},
{"f_4897:posixwin_scm",(void*)f_4897},
{"f_4918:posixwin_scm",(void*)f_4918},
{"f_4992:posixwin_scm",(void*)f_4992},
{"f_4922:posixwin_scm",(void*)f_4922},
{"f_4925:posixwin_scm",(void*)f_4925},
{"f_4932:posixwin_scm",(void*)f_4932},
{"f_4934:posixwin_scm",(void*)f_4934},
{"f_4951:posixwin_scm",(void*)f_4951},
{"f_4961:posixwin_scm",(void*)f_4961},
{"f_4965:posixwin_scm",(void*)f_4965},
{"f_4912:posixwin_scm",(void*)f_4912},
{"f_4832:posixwin_scm",(void*)f_4832},
{"f_4836:posixwin_scm",(void*)f_4836},
{"f_4842:posixwin_scm",(void*)f_4842},
{"f_4826:posixwin_scm",(void*)f_4826},
{"f_4830:posixwin_scm",(void*)f_4830},
{"f_4810:posixwin_scm",(void*)f_4810},
{"f_4802:posixwin_scm",(void*)f_4802},
{"f_4787:posixwin_scm",(void*)f_4787},
{"f_4791:posixwin_scm",(void*)f_4791},
{"f_4727:posixwin_scm",(void*)f_4727},
{"f_4734:posixwin_scm",(void*)f_4734},
{"f_4756:posixwin_scm",(void*)f_4756},
{"f_4753:posixwin_scm",(void*)f_4753},
{"f_4743:posixwin_scm",(void*)f_4743},
{"f_4694:posixwin_scm",(void*)f_4694},
{"f_4698:posixwin_scm",(void*)f_4698},
{"f_4680:posixwin_scm",(void*)f_4680},
{"f_4671:posixwin_scm",(void*)f_4671},
{"f_4652:posixwin_scm",(void*)f_4652},
{"f_4586:posixwin_scm",(void*)f_4586},
{"f_4592:posixwin_scm",(void*)f_4592},
{"f_4596:posixwin_scm",(void*)f_4596},
{"f_4604:posixwin_scm",(void*)f_4604},
{"f_4630:posixwin_scm",(void*)f_4630},
{"f_4634:posixwin_scm",(void*)f_4634},
{"f_4622:posixwin_scm",(void*)f_4622},
{"f_4571:posixwin_scm",(void*)f_4571},
{"f_4579:posixwin_scm",(void*)f_4579},
{"f_4554:posixwin_scm",(void*)f_4554},
{"f_4565:posixwin_scm",(void*)f_4565},
{"f_4569:posixwin_scm",(void*)f_4569},
{"f_4524:posixwin_scm",(void*)f_4524},
{"f_4531:posixwin_scm",(void*)f_4531},
{"f_4540:posixwin_scm",(void*)f_4540},
{"f_4534:posixwin_scm",(void*)f_4534},
{"f_4489:posixwin_scm",(void*)f_4489},
{"f_4493:posixwin_scm",(void*)f_4493},
{"f_4522:posixwin_scm",(void*)f_4522},
{"f_4508:posixwin_scm",(void*)f_4508},
{"f_4502:posixwin_scm",(void*)f_4502},
{"f_4475:posixwin_scm",(void*)f_4475},
{"f_4487:posixwin_scm",(void*)f_4487},
{"f_4461:posixwin_scm",(void*)f_4461},
{"f_4473:posixwin_scm",(void*)f_4473},
{"f_4443:posixwin_scm",(void*)f_4443},
{"f_4447:posixwin_scm",(void*)f_4447},
{"f_4459:posixwin_scm",(void*)f_4459},
{"f_4406:posixwin_scm",(void*)f_4406},
{"f_4414:posixwin_scm",(void*)f_4414},
{"f_4397:posixwin_scm",(void*)f_4397},
{"f_4391:posixwin_scm",(void*)f_4391},
{"f_4385:posixwin_scm",(void*)f_4385},
{"f_4361:posixwin_scm",(void*)f_4361},
{"f_4383:posixwin_scm",(void*)f_4383},
{"f_4379:posixwin_scm",(void*)f_4379},
{"f_4371:posixwin_scm",(void*)f_4371},
{"f_4331:posixwin_scm",(void*)f_4331},
{"f_4359:posixwin_scm",(void*)f_4359},
{"f_4355:posixwin_scm",(void*)f_4355},
{"f_4347:posixwin_scm",(void*)f_4347},
{"f_4275:posixwin_scm",(void*)f_4275},
{"f_4285:posixwin_scm",(void*)f_4285},
{"f_4262:posixwin_scm",(void*)f_4262},
{"f_4253:posixwin_scm",(void*)f_4253},
{"f_4184:posixwin_scm",(void*)f_4184},
{"f_4200:posixwin_scm",(void*)f_4200},
{"f_4191:posixwin_scm",(void*)f_4191},
{"f_4164:posixwin_scm",(void*)f_4164},
{"f_4168:posixwin_scm",(void*)f_4168},
{"f_4174:posixwin_scm",(void*)f_4174},
{"f_4178:posixwin_scm",(void*)f_4178},
{"f_4144:posixwin_scm",(void*)f_4144},
{"f_4148:posixwin_scm",(void*)f_4148},
{"f_4154:posixwin_scm",(void*)f_4154},
{"f_4158:posixwin_scm",(void*)f_4158},
{"f_4120:posixwin_scm",(void*)f_4120},
{"f_4124:posixwin_scm",(void*)f_4124},
{"f_4135:posixwin_scm",(void*)f_4135},
{"f_4139:posixwin_scm",(void*)f_4139},
{"f_4129:posixwin_scm",(void*)f_4129},
{"f_4096:posixwin_scm",(void*)f_4096},
{"f_4100:posixwin_scm",(void*)f_4100},
{"f_4111:posixwin_scm",(void*)f_4111},
{"f_4115:posixwin_scm",(void*)f_4115},
{"f_4105:posixwin_scm",(void*)f_4105},
{"f_4077:posixwin_scm",(void*)f_4077},
{"f_4081:posixwin_scm",(void*)f_4081},
{"f_4084:posixwin_scm",(void*)f_4084},
{"f_4041:posixwin_scm",(void*)f_4041},
{"f_4072:posixwin_scm",(void*)f_4072},
{"f_4062:posixwin_scm",(void*)f_4062},
{"f_4055:posixwin_scm",(void*)f_4055},
{"f_4005:posixwin_scm",(void*)f_4005},
{"f_4036:posixwin_scm",(void*)f_4036},
{"f_4026:posixwin_scm",(void*)f_4026},
{"f_4019:posixwin_scm",(void*)f_4019},
{"f_3987:posixwin_scm",(void*)f_3987},
{"f_3991:posixwin_scm",(void*)f_3991},
{"f_4003:posixwin_scm",(void*)f_4003},
{"f_3981:posixwin_scm",(void*)f_3981},
{"f_3969:posixwin_scm",(void*)f_3969},
{"f_3612:posixwin_scm",(void*)f_3612},
{"f_3959:posixwin_scm",(void*)f_3959},
{"f_3758:posixwin_scm",(void*)f_3758},
{"f_3945:posixwin_scm",(void*)f_3945},
{"f_3934:posixwin_scm",(void*)f_3934},
{"f_3941:posixwin_scm",(void*)f_3941},
{"f_3788:posixwin_scm",(void*)f_3788},
{"f_3927:posixwin_scm",(void*)f_3927},
{"f_3906:posixwin_scm",(void*)f_3906},
{"f_3923:posixwin_scm",(void*)f_3923},
{"f_3912:posixwin_scm",(void*)f_3912},
{"f_3919:posixwin_scm",(void*)f_3919},
{"f_3830:posixwin_scm",(void*)f_3830},
{"f_3903:posixwin_scm",(void*)f_3903},
{"f_3882:posixwin_scm",(void*)f_3882},
{"f_3899:posixwin_scm",(void*)f_3899},
{"f_3888:posixwin_scm",(void*)f_3888},
{"f_3895:posixwin_scm",(void*)f_3895},
{"f_3836:posixwin_scm",(void*)f_3836},
{"f_3879:posixwin_scm",(void*)f_3879},
{"f_3875:posixwin_scm",(void*)f_3875},
{"f_3868:posixwin_scm",(void*)f_3868},
{"f_3864:posixwin_scm",(void*)f_3864},
{"f_3843:posixwin_scm",(void*)f_3843},
{"f_3847:posixwin_scm",(void*)f_3847},
{"f_3824:posixwin_scm",(void*)f_3824},
{"f_3811:posixwin_scm",(void*)f_3811},
{"f_3795:posixwin_scm",(void*)f_3795},
{"f_3799:posixwin_scm",(void*)f_3799},
{"f_3803:posixwin_scm",(void*)f_3803},
{"f_3782:posixwin_scm",(void*)f_3782},
{"f_3769:posixwin_scm",(void*)f_3769},
{"f_3765:posixwin_scm",(void*)f_3765},
{"f_3752:posixwin_scm",(void*)f_3752},
{"f_3619:posixwin_scm",(void*)f_3619},
{"f_3738:posixwin_scm",(void*)f_3738},
{"f_3626:posixwin_scm",(void*)f_3626},
{"f_3628:posixwin_scm",(void*)f_3628},
{"f_3635:posixwin_scm",(void*)f_3635},
{"f_3710:posixwin_scm",(void*)f_3710},
{"f_3719:posixwin_scm",(void*)f_3719},
{"f_3707:posixwin_scm",(void*)f_3707},
{"f_3641:posixwin_scm",(void*)f_3641},
{"f_3688:posixwin_scm",(void*)f_3688},
{"f_3676:posixwin_scm",(void*)f_3676},
{"f_3684:posixwin_scm",(void*)f_3684},
{"f_3680:posixwin_scm",(void*)f_3680},
{"f_3657:posixwin_scm",(void*)f_3657},
{"f_3665:posixwin_scm",(void*)f_3665},
{"f_3661:posixwin_scm",(void*)f_3661},
{"f_3556:posixwin_scm",(void*)f_3556},
{"f_3565:posixwin_scm",(void*)f_3565},
{"f_3589:posixwin_scm",(void*)f_3589},
{"f_3601:posixwin_scm",(void*)f_3601},
{"f_3607:posixwin_scm",(void*)f_3607},
{"f_3595:posixwin_scm",(void*)f_3595},
{"f_3571:posixwin_scm",(void*)f_3571},
{"f_3577:posixwin_scm",(void*)f_3577},
{"f_3563:posixwin_scm",(void*)f_3563},
{"f_3545:posixwin_scm",(void*)f_3545},
{"f_3540:posixwin_scm",(void*)f_3540},
{"f_3496:posixwin_scm",(void*)f_3496},
{"f_3509:posixwin_scm",(void*)f_3509},
{"f_3512:posixwin_scm",(void*)f_3512},
{"f_3469:posixwin_scm",(void*)f_3469},
{"f_3494:posixwin_scm",(void*)f_3494},
{"f_3490:posixwin_scm",(void*)f_3490},
{"f_3476:posixwin_scm",(void*)f_3476},
{"f_3312:posixwin_scm",(void*)f_3312},
{"f_3420:posixwin_scm",(void*)f_3420},
{"f_3428:posixwin_scm",(void*)f_3428},
{"f_3415:posixwin_scm",(void*)f_3415},
{"f_3314:posixwin_scm",(void*)f_3314},
{"f_3321:posixwin_scm",(void*)f_3321},
{"f_3324:posixwin_scm",(void*)f_3324},
{"f_3327:posixwin_scm",(void*)f_3327},
{"f_3414:posixwin_scm",(void*)f_3414},
{"f_3331:posixwin_scm",(void*)f_3331},
{"f_3348:posixwin_scm",(void*)f_3348},
{"f_3358:posixwin_scm",(void*)f_3358},
{"f_3370:posixwin_scm",(void*)f_3370},
{"f_3380:posixwin_scm",(void*)f_3380},
{"f_3340:posixwin_scm",(void*)f_3340},
{"f_3285:posixwin_scm",(void*)f_3285},
{"f_3310:posixwin_scm",(void*)f_3310},
{"f_3306:posixwin_scm",(void*)f_3306},
{"f_3298:posixwin_scm",(void*)f_3298},
{"f_3258:posixwin_scm",(void*)f_3258},
{"f_3283:posixwin_scm",(void*)f_3283},
{"f_3279:posixwin_scm",(void*)f_3279},
{"f_3271:posixwin_scm",(void*)f_3271},
{"f_3152:posixwin_scm",(void*)f_3152},
{"f_3227:posixwin_scm",(void*)f_3227},
{"f_3244:posixwin_scm",(void*)f_3244},
{"f_3236:posixwin_scm",(void*)f_3236},
{"f_3165:posixwin_scm",(void*)f_3165},
{"f_3168:posixwin_scm",(void*)f_3168},
{"f_3176:posixwin_scm",(void*)f_3176},
{"f_3181:posixwin_scm",(void*)f_3181},
{"f_3207:posixwin_scm",(void*)f_3207},
{"f_3210:posixwin_scm",(void*)f_3210},
{"f_3187:posixwin_scm",(void*)f_3187},
{"f_3204:posixwin_scm",(void*)f_3204},
{"f_3196:posixwin_scm",(void*)f_3196},
{"f_3091:posixwin_scm",(void*)f_3091},
{"f_3104:posixwin_scm",(void*)f_3104},
{"f_3119:posixwin_scm",(void*)f_3119},
{"f_3110:posixwin_scm",(void*)f_3110},
{"f_3113:posixwin_scm",(void*)f_3113},
{"f_3051:posixwin_scm",(void*)f_3051},
{"f_3070:posixwin_scm",(void*)f_3070},
{"f_3055:posixwin_scm",(void*)f_3055},
{"f_3064:posixwin_scm",(void*)f_3064},
{"f_3058:posixwin_scm",(void*)f_3058},
{"f_3018:posixwin_scm",(void*)f_3018},
{"f_3020:posixwin_scm",(void*)f_3020},
{"f_3013:posixwin_scm",(void*)f_3013},
{"f_2990:posixwin_scm",(void*)f_2990},
{"f_3011:posixwin_scm",(void*)f_3011},
{"f_2997:posixwin_scm",(void*)f_2997},
{"f_2984:posixwin_scm",(void*)f_2984},
{"f_2988:posixwin_scm",(void*)f_2988},
{"f_2978:posixwin_scm",(void*)f_2978},
{"f_2982:posixwin_scm",(void*)f_2982},
{"f_2972:posixwin_scm",(void*)f_2972},
{"f_2976:posixwin_scm",(void*)f_2976},
{"f_2966:posixwin_scm",(void*)f_2966},
{"f_2970:posixwin_scm",(void*)f_2970},
{"f_2960:posixwin_scm",(void*)f_2960},
{"f_2964:posixwin_scm",(void*)f_2964},
{"f_2954:posixwin_scm",(void*)f_2954},
{"f_2958:posixwin_scm",(void*)f_2958},
{"f_2930:posixwin_scm",(void*)f_2930},
{"f_2937:posixwin_scm",(void*)f_2937},
{"f_2892:posixwin_scm",(void*)f_2892},
{"f_2925:posixwin_scm",(void*)f_2925},
{"f_2921:posixwin_scm",(void*)f_2921},
{"f_2896:posixwin_scm",(void*)f_2896},
{"f_2905:posixwin_scm",(void*)f_2905},
{"f_2854:posixwin_scm",(void*)f_2854},
{"f_2861:posixwin_scm",(void*)f_2861},
{"f_2864:posixwin_scm",(void*)f_2864},
{"f_2884:posixwin_scm",(void*)f_2884},
{"f_2867:posixwin_scm",(void*)f_2867},
{"f_2874:posixwin_scm",(void*)f_2874},
{"f_2812:posixwin_scm",(void*)f_2812},
{"f_2819:posixwin_scm",(void*)f_2819},
{"f_2834:posixwin_scm",(void*)f_2834},
{"f_2828:posixwin_scm",(void*)f_2828},
{"f_2767:posixwin_scm",(void*)f_2767},
{"f_2777:posixwin_scm",(void*)f_2777},
{"f_2780:posixwin_scm",(void*)f_2780},
{"f_2792:posixwin_scm",(void*)f_2792},
{"f_2783:posixwin_scm",(void*)f_2783},
{"f_2749:posixwin_scm",(void*)f_2749},
{"f_2762:posixwin_scm",(void*)f_2762},
{"f_2708:posixwin_scm",(void*)f_2708},
{"f_2741:posixwin_scm",(void*)f_2741},
{"f_2725:posixwin_scm",(void*)f_2725},
{"f_2734:posixwin_scm",(void*)f_2734},
{"f_2728:posixwin_scm",(void*)f_2728},
{"f_2662:posixwin_scm",(void*)f_2662},
{"f_2666:posixwin_scm",(void*)f_2666},
{"f_2677:posixwin_scm",(void*)f_2677},
{"f_2673:posixwin_scm",(void*)f_2673},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
