/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:52
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: posixunix.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[464];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,51,57,52,50,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,52,53,52,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,49,51,55,32,99,109,100,49,51,56,32,46,32,116,109,112,49,51,54,49,51,57,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,53,57,32,102,108,97,103,115,49,54,48,32,46,32,109,111,100,101,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,56,50,32,115,105,122,101,49,56,51,32,46,32,98,117,102,102,101,114,49,56,52,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,50,48,49,32,98,117,102,102,101,114,50,48,50,32,46,32,115,105,122,101,50,48,51,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,50,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,102,100,95,115,101,116,32,97,50,52,51,50,52,56,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,17),40,102,100,95,116,101,115,116,32,97,50,53,48,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,51,56,54,52,32,102,100,51,51,51,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,51,56,56,57,32,102,100,51,50,52,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,51,57,50,57,32,102,100,50,57,56,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,51,57,53,53,32,102,100,50,55,57,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,50,53,56,32,102,100,115,119,50,53,57,32,46,32,116,105,109,101,111,117,116,50,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,51,54,51,32,108,105,110,107,51,54,52,32,108,111,99,51,54,53,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,51,56,50,32,46,32,108,105,110,107,51,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,51,57,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,52,48,49,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,52,48,54,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,52,49,49,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,52,50,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,52,50,54,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,52,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,52,52,52,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,115,116,97,116,45,99,104,97,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,54,50,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,29),40,115,116,97,116,45,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,55,49,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,21),40,115,116,97,116,45,102,105,102,111,63,32,102,110,97,109,101,52,56,48,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,115,121,109,108,105,110,107,63,32,102,110,97,109,101,52,56,57,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,115,116,97,116,45,115,111,99,107,101,116,63,32,102,110,97,109,101,52,57,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,97,52,49,56,50,32,120,53,55,53,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,53,53,55,32,46,32,116,109,112,53,53,54,53,53,56,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,54,51,56,32,115,112,101,99,54,52,56,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,52,57,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,52,49,32,37,115,112,101,99,54,51,54,54,57,52,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,54,52,48,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,54,50,56,54,50,57,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,55,48,57,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,55,50,52,55,50,53,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,55,55,48,55,55,49,55,55,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,52,53,56,53,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,19),40,97,52,53,55,57,32,101,120,118,97,114,55,56,52,56,48,48,41,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,52,54,48,51,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,52,54,49,53,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,20),40,97,52,54,48,57,32,46,32,97,114,103,115,55,57,51,56,49,56,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,52,53,57,55,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,15),40,97,52,53,55,51,32,107,55,57,50,55,57,56,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,56,53,51,32,114,56,53,52,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,56,50,50,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,56,54,54,41,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,56,54,56,32,99,109,100,56,54,57,32,105,110,112,56,55,48,32,114,56,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,56,55,54,32,46,32,109,56,55,55,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,56,56,57,32,46,32,109,56,57,48,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,57,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,7),40,97,53,48,54,55,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,97,53,48,55,51,32,46,32,114,101,115,117,108,116,115,57,50,57,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,57,50,50,32,112,114,111,99,57,50,51,32,46,32,109,111,100,101,57,50,52,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,53,48,57,49,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,20),40,97,53,48,57,55,32,46,32,114,101,115,117,108,116,115,57,51,57,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,57,51,50,32,112,114,111,99,57,51,51,32,46,32,109,111,100,101,57,51,52,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,53,49,49,54,32,46,32,114,101,115,117,108,116,115,57,52,57,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,57,52,50,32,116,104,117,110,107,57,52,51,32,46,32,109,111,100,101,57,52,52,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,20),40,97,53,49,51,54,32,46,32,114,101,115,117,108,116,115,57,54,49,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,57,53,52,32,116,104,117,110,107,57,53,53,32,46,32,109,111,100,101,57,53,54,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,49,48,51,50,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,49,48,51,53,32,112,114,111,99,49,48,51,54,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,49,48,52,50,32,115,116,97,116,101,49,48,52,51,41,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,13),40,97,53,50,53,49,32,115,49,48,53,51,41,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,27),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,49,48,53,49,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,105,103,115,49,48,54,54,32,109,97,115,107,49,48,54,55,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,49,48,55,53,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,22),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,49,48,56,48,41,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,49,48,56,56,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,41),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,49,49,54,48,32,46,32,116,109,112,49,49,53,57,49,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,50,51,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,43),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,49,50,48,51,32,46,32,116,109,112,49,50,48,50,49,50,48,52,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,53,57,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,49,50,55,50,32,108,115,116,49,50,55,56,32,105,49,50,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,49,50,54,56,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,35),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,49,51,48,53,32,105,100,49,51,48,54,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,34),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,49,51,55,55,32,109,49,51,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,42),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,49,51,56,53,32,117,105,100,49,51,56,54,32,103,105,100,49,51,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,49,52,48,48,32,97,99,99,49,52,48,49,32,108,111,99,49,52,48,50,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,49,48,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,49,52,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,49,52,52,55,32,110,101,119,49,52,52,56,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,49,52,53,57,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,105,110,107,32,111,108,100,49,52,56,51,32,110,101,119,49,52,56,52,41,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,20),40,109,111,100,101,32,105,110,112,49,53,48,48,32,109,49,53,48,49,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,108,111,99,49,53,49,57,32,102,100,49,53,50,48,32,105,110,112,49,53,50,49,32,114,49,53,50,50,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,33),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,49,53,50,55,32,46,32,109,49,53,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,34),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,49,53,51,49,32,46,32,109,49,53,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,23),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,49,53,51,57,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,53,53,53,32,46,32,110,101,119,49,53,53,54,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,7),40,97,54,50,57,54,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,7),40,97,54,51,48,57,41,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,7),40,97,54,51,50,49,41,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,7),40,97,54,51,52,50,41,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,54,56,49,32,109,49,54,56,50,32,115,116,97,114,116,49,54,56,51,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,41),40,97,54,51,53,49,32,112,111,114,116,49,54,55,52,32,110,49,54,55,53,32,100,101,115,116,49,54,55,54,32,115,116,97,114,116,49,54,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,24),40,98,117,109,112,101,114,32,99,117,114,49,55,49,55,32,112,116,114,49,55,49,56,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,7),40,97,54,53,49,51,41,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,42),40,97,54,53,49,57,32,100,101,115,116,49,55,53,55,49,55,53,56,49,55,54,50,32,99,111,110,116,63,49,55,53,57,49,55,54,48,49,55,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,55,49,52,41,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,26),40,97,54,52,50,55,32,112,111,114,116,49,55,48,57,32,108,105,109,105,116,49,55,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,49,53,57,49,32,110,111,110,98,108,111,99,107,105,110,103,63,49,54,48,51,32,98,117,102,105,49,54,48,52,32,111,110,45,99,108,111,115,101,49,54,48,53,32,109,111,114,101,63,49,54,48,54,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,69),40,100,101,102,45,109,111,114,101,63,49,53,57,54,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,55,49,55,55,55,32,37,98,117,102,105,49,53,56,56,49,55,55,56,32,37,111,110,45,99,108,111,115,101,49,53,56,57,49,55,55,57,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,53,57,53,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,55,49,55,56,51,32,37,98,117,102,105,49,53,56,56,49,55,56,52,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,53,57,52,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,55,49,55,56,56,41,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,53,57,51,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,53,55,55,32,110,97,109,49,53,55,56,32,102,100,49,53,55,57,32,46,32,116,109,112,49,53,55,54,49,53,56,48,41,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,56,53,48,32,108,101,110,49,56,53,49,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,15),40,97,54,55,49,48,32,115,116,114,49,56,57,56,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,7),40,97,54,55,49,54,41,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,7),40,97,54,55,51,55,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,52,54,32,115,116,114,49,56,54,53,41};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,56,55,54,32,115,116,97,114,116,49,56,55,55,32,108,101,110,49,56,55,56,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,54,49,32,115,116,114,49,56,55,50,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,49),40,98,111,100,121,49,56,51,48,32,110,111,110,98,108,111,99,107,105,110,103,63,49,56,52,49,32,98,117,102,105,49,56,52,50,32,111,110,45,99,108,111,115,101,49,56,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,56,51,52,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,55,49,57,49,53,32,37,98,117,102,105,49,56,50,56,49,57,49,54,41,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,56,51,51,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,55,49,57,50,48,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,56,51,50,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,56,49,55,32,110,97,109,49,56,49,56,32,102,100,49,56,49,57,32,46,32,116,109,112,49,56,49,54,49,56,50,48,41,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,57,51,55,32,111,102,102,49,57,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,57,53,55,32,97,114,103,115,49,57,53,56,32,108,111,99,49,57,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,49,57,56,49,32,108,111,99,107,49,57,56,50,32,108,111,99,49,57,56,51,41,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,49,57,56,53,32,46,32,97,114,103,115,49,57,56,54,41,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,49,57,57,48,32,46,32,97,114,103,115,49,57,57,49,41};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,49,57,57,53,32,46,32,97,114,103,115,49,57,57,54,41,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,50,48,50,48,41,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,50,48,50,55,32,46,32,109,111,100,101,50,48,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,50,48,51,55,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,50,48,52,51,32,118,97,108,50,48,52,52,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,50,48,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,50,48,55,52,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,50,48,54,56,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,50,49,50,50,32,108,101,110,50,49,50,51,32,112,114,111,116,50,49,50,52,32,102,108,97,103,50,49,50,53,32,102,100,50,49,50,54,32,46,32,111,102,102,50,49,50,55,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,50,49,53,53,32,46,32,108,101,110,50,49,53,54,41,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,50,49,54,53,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,50,49,55,48,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,34),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,50,49,55,52,32,116,109,50,49,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,50,49,56,50,41,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,50,49,56,55,41,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,50,50,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,50,50,51,49,32,46,32,116,109,112,50,50,51,48,50,50,51,50,41,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,50,50,55,50,32,46,32,116,109,112,50,50,55,49,50,50,55,51,41,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,56,57,41,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,50,51,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,50,51,49,52,50,51,49,55,41,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,50,51,50,52,32,109,111,100,101,50,51,50,53,32,46,32,115,105,122,101,50,51,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,50,51,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,50,51,53,51,32,112,111,114,116,50,51,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,50,51,55,49,41};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,50,51,56,54,41};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,7),40,97,55,57,48,51,41,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,50,52,54,55,41,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,55),40,97,55,57,48,57,32,100,105,114,50,52,51,55,50,52,51,56,50,52,52,53,32,102,105,108,50,52,51,57,50,52,52,48,50,52,52,54,32,101,120,116,50,52,52,49,50,52,52,50,50,52,52,55,41,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,50,52,51,50,41,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,50,52,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,49,56,32,97,50,53,49,49,50,53,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,50,52,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,50,53,50,52,50,53,51,48,32,97,50,53,50,51,50,53,51,49,41,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,50,53,51,57,50,53,52,53,32,97,50,53,51,56,50,53,52,54,41,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,50,53,57,54,32,105,50,54,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,50,53,56,53,32,97,108,50,53,57,49,32,105,50,53,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,50,53,55,48,32,97,114,103,108,105,115,116,50,53,56,48,32,101,110,118,108,105,115,116,50,53,56,49,41,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,50,53,55,51,32,37,97,114,103,108,105,115,116,50,53,54,56,50,54,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,50,53,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,50,53,54,48,32,46,32,116,109,112,50,53,53,57,50,53,54,49,41,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,50,54,53,52,32,110,111,104,97,110,103,50,54,53,53,41,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,7),40,97,56,51,48,48,41,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,36),40,97,56,51,48,54,32,101,112,105,100,50,55,48,48,32,101,110,111,114,109,50,55,48,49,32,101,99,111,100,101,50,55,48,50,41,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,50,54,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,50,55,49,52,50,55,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,50,55,50,48,32,46,32,115,105,103,50,55,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,50,55,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,50,55,52,57,32,46,32,97,114,103,115,50,55,53,48,41,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,7),40,97,56,52,55,54,41,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,29),40,97,56,52,56,50,32,95,50,55,57,57,32,102,108,103,50,56,48,48,32,99,111,100,50,56,48,49,41,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,8),40,102,95,56,52,54,50,41};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,50,55,56,52,32,112,105,100,50,55,56,53,32,99,108,115,118,101,99,50,55,56,54,32,105,100,120,50,55,56,55,32,105,100,120,97,50,55,56,56,32,105,100,120,98,50,55,56,57,41,0,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,7),40,97,56,53,48,53,41,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,19),40,97,56,53,49,49,32,105,50,56,49,52,32,111,50,56,49,53,41,0,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,50,56,48,55,41,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,50,56,49,56,32,112,111,114,116,50,56,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,50,56,50,57,32,112,111,114,116,50,56,51,48,32,115,116,100,102,100,50,56,51,49,41,0,0,0,0,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,7),40,97,56,53,56,54,41,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,50,56,53,48,32,97,114,103,115,50,56,53,49,32,101,110,118,50,56,53,50,32,115,116,100,111,117,116,102,50,56,53,51,32,115,116,100,105,110,102,50,56,53,52,32,115,116,100,101,114,114,102,50,56,53,53,41,0,0,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,50,56,54,53,32,99,109,100,50,56,54,55,32,112,105,112,101,50,56,54,56,32,115,116,100,102,50,56,54,57,32,111,110,45,99,108,111,115,101,50,56,55,49,41,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,50,56,55,56,32,99,109,100,50,56,56,48,32,112,105,112,101,50,56,56,49,32,115,116,100,102,50,56,56,50,32,111,110,45,99,108,111,115,101,50,56,56,52,41,0,0,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,7),40,97,56,54,51,54,41,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,50),40,97,56,54,52,50,32,105,110,112,105,112,101,50,57,48,51,32,111,117,116,112,105,112,101,50,57,48,52,32,101,114,114,112,105,112,101,50,57,48,53,32,112,105,100,50,57,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,50,56,57,50,32,99,109,100,50,56,57,51,32,97,114,103,115,50,56,57,52,32,101,110,118,50,56,57,53,32,115,116,100,111,117,116,102,50,56,57,54,32,115,116,100,105,110,102,50,56,57,55,32,115,116,100,101,114,114,102,50,56,57,56,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,21),40,97,56,54,57,57,32,103,50,57,50,56,50,57,50,57,50,57,51,48,41,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,50,57,50,49,41,0,0,0,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,7),40,97,56,55,49,55,41,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,38),40,97,56,55,50,51,32,105,110,50,57,52,48,32,111,117,116,50,57,52,49,32,112,105,100,50,57,52,50,32,101,114,114,50,57,52,51,41,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,50,57,49,52,32,101,114,114,63,50,57,49,53,32,99,109,100,50,57,49,54,32,97,114,103,115,50,57,49,55,32,101,110,118,50,57,49,56,41,0,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,50,57,54,53,32,97,114,103,115,50,57,55,53,32,101,110,118,50,57,55,54,41,0,0,0,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,50,57,54,56,32,37,97,114,103,115,50,57,54,51,50,57,56,48,41,0,0,0,0,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,50,57,54,55,41,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,50,57,53,53,32,46,32,116,109,112,50,57,53,52,50,57,53,54,41,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,51,48,48,57,32,97,114,103,115,51,48,49,57,32,101,110,118,51,48,50,48,41,0,0,0,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,51,48,49,50,32,37,97,114,103,115,51,48,48,55,51,48,50,52,41,0,0,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,51,48,49,49,41,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,50,57,57,57,32,46,32,116,109,112,50,57,57,56,51,48,48,48,41};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,14),40,102,95,57,48,49,51,32,120,51,48,57,52,41,0,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,7),40,97,56,57,51,54,41,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,7),40,97,56,57,52,49,41,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,7),40,97,56,57,54,53,41,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,51,49,48,48,32,114,51,49,48,49,41,0,0,0,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,51,50,32,46,32,95,51,48,56,52,41};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,50,52,32,46,32,95,51,48,56,50,41};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,51,48,53,54,32,97,99,116,105,111,110,51,48,54,55,32,105,100,51,48,54,56,32,108,105,109,105,116,51,48,54,57,41,0,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,51,48,54,48,32,37,97,99,116,105,111,110,51,48,53,51,51,49,52,49,32,37,105,100,51,48,53,52,51,49,52,50,41,0,0,0,0,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,51,48,53,57,32,37,97,99,116,105,111,110,51,48,53,51,51,49,52,54,41,0,0,0,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,19),40,97,57,48,53,50,32,120,51,49,53,49,32,121,51,49,53,50,41,0,0,0,0,0};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,51,48,53,56,41};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,51,48,52,52,32,112,114,101,100,51,48,52,53,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,51,48,52,54,41,0,0,0,0,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,51,49,55,54,41,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,15),40,97,57,49,53,49,32,112,105,100,49,52,50,57,41,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,24),40,97,57,49,54,57,32,112,105,100,49,52,51,56,32,112,103,105,100,49,52,51,57,41};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,7),40,97,57,49,57,48,41,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,14),40,97,57,49,57,51,32,105,100,49,49,52,48,41,0,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,7),40,97,57,50,48,56,41,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,14),40,97,57,50,49,49,32,105,100,49,49,51,49,41,0,0};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,7),40,97,57,50,50,54,41,0};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,14),40,97,57,50,50,57,32,105,100,49,49,50,50,41,0,0};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,7),40,97,57,50,52,52,41,0};
static C_char C_TLS li258[] C_aligned={C_lihdr(0,0,14),40,97,57,50,52,55,32,105,100,49,49,49,51,41,0,0};
static C_char C_TLS li259[] C_aligned={C_lihdr(0,0,13),40,97,57,50,54,50,32,110,49,48,57,53,41,0,0,0};
static C_char C_TLS li260[] C_aligned={C_lihdr(0,0,15),40,97,57,50,54,56,32,112,111,114,116,53,48,54,41,0};
static C_char C_TLS li261[] C_aligned={C_lihdr(0,0,34),40,97,57,51,48,53,32,112,111,114,116,53,50,48,32,112,111,115,53,50,49,32,46,32,119,104,101,110,99,101,53,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li262[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k9119 in set-root-directory! in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub3168(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3168(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k8358 */
static C_word C_fcall stub2715(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2715(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub2710(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2710(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub2706(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2706(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub2550(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2550(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k8064 */
static C_word C_fcall stub2541(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2541(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub2535(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2535(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k8045 */
static C_word C_fcall stub2526(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2526(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k8021 */
static C_word C_fcall stub2512(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2512(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub2494(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2494(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2408(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2408(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7833 */
static C_word C_fcall stub2379(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2379(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k7810 */
static C_word C_fcall stub2364(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2364(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k7699 */
static C_word C_fcall stub2315(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2315(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k7677 */
static C_word C_fcall stub2306(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2306(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2298(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2298(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub2259(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2259(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub2217(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2217(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub2209(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2209(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k7484 */
static C_word C_fcall stub2193(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2193(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7384 */
static C_word C_fcall stub2146(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2146(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k7322 */
static C_word C_fcall stub2107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub2107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k7221 */
static C_word C_fcall stub2058(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2058(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5972 in k5968 in file-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1471(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1471(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5709 */
static C_word C_fcall stub1296(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1296(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k5578 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1237(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1237(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k5571 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1231(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1231(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k5485 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1189(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1189(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a9190 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1137(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1137(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a9208 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1128(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1128(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a9226 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1119(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1119(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a9244 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall stub1110(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1110(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k3780 */
static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k3770 */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k3760 */
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k3542 */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k3491 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub46(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k3484 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub40(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub40(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k3460 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9306)
static void C_ccall f_9306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9306)
static void C_ccall f_9306r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9319)
static void C_ccall f_9319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9331)
static void C_ccall f_9331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9269)
static void C_ccall f_9269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9285)
static void C_ccall f_9285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9273)
static void C_ccall f_9273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9276)
static void C_ccall f_9276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9263)
static void C_ccall f_9263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9258)
static void C_ccall f_9258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9227)
static void C_ccall f_9227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9222)
static void C_ccall f_9222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9209)
static void C_ccall f_9209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9204)
static void C_ccall f_9204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9191)
static void C_ccall f_9191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9152)
static void C_ccall f_9152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9165)
static void C_ccall f_9165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9159)
static void C_ccall f_9159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_ccall f_9129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9121)
static void C_ccall f_9121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9047)
static void C_fcall f_9047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9053)
static void C_ccall f_9053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9042)
static void C_fcall f_9042(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9037)
static void C_fcall f_9037(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8872)
static void C_fcall f_8872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9032)
static void C_ccall f_9032(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8879)
static void C_fcall f_8879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9012)
static void C_ccall f_9012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8889)
static void C_ccall f_8889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8891)
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8992)
static void C_ccall f_8992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8925)
static void C_ccall f_8925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8976)
static void C_ccall f_8976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8964)
static void C_ccall f_8964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8950)
static void C_ccall f_8950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8937)
static void C_ccall f_8937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8935)
static void C_ccall f_8935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8810)
static void C_ccall f_8810(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8810)
static void C_ccall f_8810r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8822)
static void C_fcall f_8822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_fcall f_8817(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8812)
static void C_fcall f_8812(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8762)
static void C_fcall f_8762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_fcall f_8757(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8752)
static void C_fcall f_8752(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8689)
static void C_fcall f_8689(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8710)
static void C_ccall f_8710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8713)
static void C_ccall f_8713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8718)
static void C_ccall f_8718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8691)
static void C_fcall f_8691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8700)
static void C_ccall f_8700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8631)
static void C_ccall f_8631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8674)
static void C_ccall f_8674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8670)
static void C_ccall f_8670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8658)
static void C_ccall f_8658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_ccall f_8666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8662)
static void C_ccall f_8662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8637)
static void C_ccall f_8637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8620)
static void C_fcall f_8620(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8624)
static void C_ccall f_8624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_fcall f_8609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8613)
static void C_ccall f_8613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8564)
static void C_fcall f_8564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8571)
static void C_ccall f_8571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8587)
static void C_ccall f_8587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8597)
static void C_ccall f_8597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8585)
static void C_ccall f_8585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static C_word C_fcall f_8548(C_word *a,C_word t0);
C_noret_decl(f_8531)
static void C_fcall f_8531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8456)
static void C_ccall f_8456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8517)
static void C_fcall f_8517(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8530)
static void C_ccall f_8530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8497)
static void C_fcall f_8497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8506)
static void C_ccall f_8506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8460)
static void C_fcall f_8460(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8483)
static void C_ccall f_8483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8404)
static void C_ccall f_8404(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8404)
static void C_ccall f_8404r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8434)
static void C_ccall f_8434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_ccall f_8393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8355)
static void C_ccall f_8355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8271)
static void C_ccall f_8271(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8271)
static void C_ccall f_8271r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8301)
static void C_ccall f_8301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8072)
static void C_ccall f_8072(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8072)
static void C_ccall f_8072r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8206)
static void C_fcall f_8206(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_fcall f_8201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8074)
static void C_fcall f_8074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8092)
static void C_fcall f_8092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8138)
static C_word C_fcall f_8138(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8105)
static void C_fcall f_8105(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8053)
static C_word C_fcall f_8053(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8034)
static C_word C_fcall f_8034(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8018)
static void C_ccall f_8018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7889)
static void C_fcall f_7889(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7924)
static void C_ccall f_7924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7926)
static void C_fcall f_7926(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7957)
static void C_ccall f_7957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_fcall f_7781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7766)
static void C_ccall f_7766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_ccall f_7769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7680)
static void C_ccall f_7680(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7680)
static void C_ccall f_7680r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7657)
static void C_ccall f_7657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7642)
static void C_ccall f_7642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7609)
static void C_ccall f_7609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7459)
static void C_ccall f_7459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7440)
static void C_fcall f_7440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7338)
static void C_ccall f_7338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_fcall f_7230(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_fcall f_7242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7212)
static void C_ccall f_7212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7125)
static void C_fcall f_7125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7072)
static void C_ccall f_7072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_fcall f_7020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6946)
static void C_fcall f_6946(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_fcall f_6974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6844)
static void C_fcall f_6844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6839)
static void C_fcall f_6839(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6834)
static void C_fcall f_6834(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6650)
static void C_fcall f_6650(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6778)
static void C_fcall f_6778(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6702)
static void C_fcall f_6702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6709)
static void C_ccall f_6709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6656)
static void C_fcall f_6656(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6672)
static void C_ccall f_6672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6570)
static void C_fcall f_6570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_fcall f_6565(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6560)
static void C_fcall f_6560(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6555)
static void C_fcall f_6555(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6168)
static void C_fcall f_6168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6434)
static void C_fcall f_6434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6352)
static void C_ccall f_6352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6360)
static void C_fcall f_6360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_fcall f_6362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_fcall f_6210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_fcall f_6222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6238)
static void C_ccall f_6238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static C_word C_fcall f_6202(C_word t0);
C_noret_decl(f_6179)
static void C_fcall f_6179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6146)
static void C_fcall f_6146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_fcall f_6051(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_fcall f_6014(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5840)
static void C_fcall f_5840(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5735)
static void C_ccall f_5735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5654)
static void C_fcall f_5654(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_fcall f_5597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static C_word C_fcall f_5575(C_word t0);
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_fcall f_5496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5472)
static void C_ccall f_5472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_fcall f_5390(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5408)
static void C_ccall f_5408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_fcall f_5264(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_fcall f_4956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_fcall f_4950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static C_word C_fcall f_4938(C_word t0);
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_fcall f_4748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_fcall f_4767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_fcall f_4811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_fcall f_4637(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_fcall f_4565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static C_word C_fcall f_4554(C_word t0);
C_noret_decl(f_4549)
static void C_fcall f_4549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4426)
static void C_fcall f_4426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4323)
static void C_fcall f_4323(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_fcall f_4354(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_fcall f_4376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_fcall f_3975(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_fcall f_3808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_fcall f_3847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_fcall f_3851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static C_word C_fcall f_3773(C_word t0,C_word t1);
C_noret_decl(f_3763)
static C_word C_fcall f_3763(C_word t0,C_word t1);
C_noret_decl(f_3757)
static C_word C_fcall f_3757(C_word t0);
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9047)
static void C_fcall trf_9047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9047(t0,t1);}

C_noret_decl(trf_9042)
static void C_fcall trf_9042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9042(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9042(t0,t1,t2);}

C_noret_decl(trf_9037)
static void C_fcall trf_9037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9037(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9037(t0,t1,t2,t3);}

C_noret_decl(trf_8872)
static void C_fcall trf_8872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8872(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8872(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8879)
static void C_fcall trf_8879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8879(t0,t1);}

C_noret_decl(trf_8891)
static void C_fcall trf_8891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8891(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8891(t0,t1,t2,t3);}

C_noret_decl(trf_8822)
static void C_fcall trf_8822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8822(t0,t1);}

C_noret_decl(trf_8817)
static void C_fcall trf_8817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8817(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8817(t0,t1,t2);}

C_noret_decl(trf_8812)
static void C_fcall trf_8812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8812(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8812(t0,t1,t2,t3);}

C_noret_decl(trf_8762)
static void C_fcall trf_8762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8762(t0,t1);}

C_noret_decl(trf_8757)
static void C_fcall trf_8757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8757(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8757(t0,t1,t2);}

C_noret_decl(trf_8752)
static void C_fcall trf_8752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8752(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8752(t0,t1,t2,t3);}

C_noret_decl(trf_8689)
static void C_fcall trf_8689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8689(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8689(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8691)
static void C_fcall trf_8691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8691(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8691(t0,t1,t2);}

C_noret_decl(trf_8620)
static void C_fcall trf_8620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8620(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8620(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8609)
static void C_fcall trf_8609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8609(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8609(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8564)
static void C_fcall trf_8564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8564(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8564(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8531)
static void C_fcall trf_8531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8531(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8531(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8517)
static void C_fcall trf_8517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8517(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8517(t0,t1,t2,t3);}

C_noret_decl(trf_8497)
static void C_fcall trf_8497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8497(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8497(t0,t1,t2);}

C_noret_decl(trf_8460)
static void C_fcall trf_8460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8460(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8460(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8206)
static void C_fcall trf_8206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8206(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8206(t0,t1);}

C_noret_decl(trf_8201)
static void C_fcall trf_8201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8201(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8201(t0,t1,t2);}

C_noret_decl(trf_8074)
static void C_fcall trf_8074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8074(t0,t1,t2,t3);}

C_noret_decl(trf_8092)
static void C_fcall trf_8092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8092(t0,t1,t2,t3);}

C_noret_decl(trf_8105)
static void C_fcall trf_8105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8105(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8105(t0,t1);}

C_noret_decl(trf_7889)
static void C_fcall trf_7889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7889(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7889(t0,t1,t2);}

C_noret_decl(trf_7926)
static void C_fcall trf_7926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7926(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7926(t0,t1,t2);}

C_noret_decl(trf_7781)
static void C_fcall trf_7781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7781(t0,t1,t2);}

C_noret_decl(trf_7440)
static void C_fcall trf_7440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7440(t0,t1,t2);}

C_noret_decl(trf_7230)
static void C_fcall trf_7230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7230(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7230(t0,t1,t2);}

C_noret_decl(trf_7242)
static void C_fcall trf_7242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7242(t0,t1,t2);}

C_noret_decl(trf_7125)
static void C_fcall trf_7125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7125(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7125(t0,t1);}

C_noret_decl(trf_7020)
static void C_fcall trf_7020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7020(t0,t1,t2,t3);}

C_noret_decl(trf_6946)
static void C_fcall trf_6946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6946(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6946(t0,t1,t2,t3);}

C_noret_decl(trf_6974)
static void C_fcall trf_6974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6974(t0,t1);}

C_noret_decl(trf_6844)
static void C_fcall trf_6844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6844(t0,t1);}

C_noret_decl(trf_6839)
static void C_fcall trf_6839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6839(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6839(t0,t1,t2);}

C_noret_decl(trf_6834)
static void C_fcall trf_6834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6834(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6834(t0,t1,t2,t3);}

C_noret_decl(trf_6650)
static void C_fcall trf_6650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6650(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6650(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6778)
static void C_fcall trf_6778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6778(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6778(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6702)
static void C_fcall trf_6702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6702(t0,t1);}

C_noret_decl(trf_6656)
static void C_fcall trf_6656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6656(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6656(t0,t1,t2,t3);}

C_noret_decl(trf_6570)
static void C_fcall trf_6570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6570(t0,t1);}

C_noret_decl(trf_6565)
static void C_fcall trf_6565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6565(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6565(t0,t1,t2);}

C_noret_decl(trf_6560)
static void C_fcall trf_6560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6560(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6560(t0,t1,t2,t3);}

C_noret_decl(trf_6555)
static void C_fcall trf_6555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6555(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6555(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6168)
static void C_fcall trf_6168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6168(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6168(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6434)
static void C_fcall trf_6434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6434(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6434(t0,t1,t2);}

C_noret_decl(trf_6360)
static void C_fcall trf_6360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6360(t0,t1);}

C_noret_decl(trf_6362)
static void C_fcall trf_6362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6362(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6362(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6210)
static void C_fcall trf_6210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6210(t0,t1);}

C_noret_decl(trf_6222)
static void C_fcall trf_6222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6222(t0,t1);}

C_noret_decl(trf_6179)
static void C_fcall trf_6179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6179(t0,t1);}

C_noret_decl(trf_6146)
static void C_fcall trf_6146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6146(t0,t1);}

C_noret_decl(trf_6051)
static void C_fcall trf_6051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6051(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6051(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6014)
static void C_fcall trf_6014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6014(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6014(t0,t1,t2);}

C_noret_decl(trf_5840)
static void C_fcall trf_5840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5840(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5840(t0,t1,t2,t3);}

C_noret_decl(trf_5654)
static void C_fcall trf_5654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5654(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5654(t0,t1,t2,t3);}

C_noret_decl(trf_5597)
static void C_fcall trf_5597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5597(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5597(t0,t1,t2);}

C_noret_decl(trf_5496)
static void C_fcall trf_5496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5496(t0,t1);}

C_noret_decl(trf_5519)
static void C_fcall trf_5519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5519(t0,t1,t2);}

C_noret_decl(trf_5390)
static void C_fcall trf_5390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5390(t0,t1);}

C_noret_decl(trf_5264)
static void C_fcall trf_5264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5264(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5264(t0,t1,t2,t3);}

C_noret_decl(trf_4956)
static void C_fcall trf_4956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4956(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4956(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4950)
static void C_fcall trf_4950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4950(t0,t1);}

C_noret_decl(trf_4748)
static void C_fcall trf_4748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4748(t0,t1);}

C_noret_decl(trf_4767)
static void C_fcall trf_4767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4767(t0,t1);}

C_noret_decl(trf_4811)
static void C_fcall trf_4811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4811(t0,t1);}

C_noret_decl(trf_4637)
static void C_fcall trf_4637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4637(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4637(t0,t1,t2,t3);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4705(t0,t1);}

C_noret_decl(trf_4565)
static void C_fcall trf_4565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4565(t0,t1);}

C_noret_decl(trf_4549)
static void C_fcall trf_4549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4549(t0,t1);}

C_noret_decl(trf_4426)
static void C_fcall trf_4426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4426(t0,t1);}

C_noret_decl(trf_4421)
static void C_fcall trf_4421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4421(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4421(t0,t1,t2);}

C_noret_decl(trf_4323)
static void C_fcall trf_4323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4323(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4323(t0,t1,t2,t3);}

C_noret_decl(trf_4354)
static void C_fcall trf_4354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4354(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4354(t0,t1);}

C_noret_decl(trf_4376)
static void C_fcall trf_4376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4376(t0,t1);}

C_noret_decl(trf_3975)
static void C_fcall trf_3975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3975(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3975(t0,t1,t2,t3);}

C_noret_decl(trf_3808)
static void C_fcall trf_3808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3808(t0,t1);}

C_noret_decl(trf_3847)
static void C_fcall trf_3847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3847(t0,t1);}

C_noret_decl(trf_3851)
static void C_fcall trf_3851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3851(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3330)){
C_save(t1);
C_rereclaim2(3330*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,464);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],13,"stat-regular\077");
lf[87]=C_h_intern(&lf[87],15,"stat-directory\077");
lf[88]=C_h_intern(&lf[88],17,"stat-char-device\077");
lf[89]=C_h_intern(&lf[89],18,"stat-block-device\077");
lf[90]=C_h_intern(&lf[90],10,"stat-fifo\077");
lf[91]=C_h_intern(&lf[91],13,"stat-symlink\077");
lf[92]=C_h_intern(&lf[92],12,"stat-socket\077");
lf[93]=C_h_intern(&lf[93],13,"file-position");
lf[94]=C_h_intern(&lf[94],16,"create-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[99]=C_h_intern(&lf[99],12,"file-exists\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[101]=C_h_intern(&lf[101],12,"string-split");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[103]=C_h_intern(&lf[103],14,"canonical-path");
lf[104]=C_h_intern(&lf[104],16,"change-directory");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[106]=C_h_intern(&lf[106],16,"delete-directory");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[108]=C_h_intern(&lf[108],10,"string-ref");
lf[109]=C_h_intern(&lf[109],6,"string");
lf[110]=C_h_intern(&lf[110],9,"directory");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[112]=C_h_intern(&lf[112],16,"\003sysmake-pointer");
lf[113]=C_h_intern(&lf[113],17,"current-directory");
lf[114]=C_h_intern(&lf[114],10,"directory\077");
lf[115]=C_h_intern(&lf[115],13,"\003sysfile-info");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[117]=C_h_intern(&lf[117],5,"null\077");
lf[118]=C_h_intern(&lf[118],6,"char=\077");
lf[119]=C_h_intern(&lf[119],8,"string=\077");
lf[120]=C_h_intern(&lf[120],16,"char-alphabetic\077");
lf[121]=C_h_intern(&lf[121],18,"string-intersperse");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[123]=C_h_intern(&lf[123],6,"getenv");
lf[124]=C_h_intern(&lf[124],17,"current-user-name");
lf[125]=C_h_intern(&lf[125],9,"condition");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_h_intern(&lf[127],22,"with-exception-handler");
lf[128]=C_h_intern(&lf[128],30,"call-with-current-continuation");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[132]=C_h_intern(&lf[132],7,"reverse");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_h_intern(&lf[143],5,"\000text");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[146]=C_h_intern(&lf[146],13,"\003sysmake-port");
lf[147]=C_h_intern(&lf[147],21,"\003sysstream-port-class");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[149]=C_h_intern(&lf[149],6,"stream");
lf[150]=C_h_intern(&lf[150],15,"open-input-pipe");
lf[151]=C_h_intern(&lf[151],7,"\000binary");
lf[152]=C_h_intern(&lf[152],16,"open-output-pipe");
lf[153]=C_h_intern(&lf[153],16,"close-input-pipe");
lf[154]=C_h_intern(&lf[154],23,"close-input/output-pipe");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[156]=C_h_intern(&lf[156],14,"\003syscheck-port");
lf[157]=C_h_intern(&lf[157],17,"close-output-pipe");
lf[158]=C_h_intern(&lf[158],20,"call-with-input-pipe");
lf[159]=C_h_intern(&lf[159],21,"call-with-output-pipe");
lf[160]=C_h_intern(&lf[160],20,"with-input-from-pipe");
lf[161]=C_h_intern(&lf[161],18,"\003sysstandard-input");
lf[162]=C_h_intern(&lf[162],19,"with-output-to-pipe");
lf[163]=C_h_intern(&lf[163],19,"\003sysstandard-output");
lf[164]=C_h_intern(&lf[164],11,"create-pipe");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[166]=C_h_intern(&lf[166],11,"signal/term");
lf[167]=C_h_intern(&lf[167],11,"signal/kill");
lf[168]=C_h_intern(&lf[168],10,"signal/int");
lf[169]=C_h_intern(&lf[169],10,"signal/hup");
lf[170]=C_h_intern(&lf[170],10,"signal/fpe");
lf[171]=C_h_intern(&lf[171],10,"signal/ill");
lf[172]=C_h_intern(&lf[172],11,"signal/segv");
lf[173]=C_h_intern(&lf[173],11,"signal/abrt");
lf[174]=C_h_intern(&lf[174],11,"signal/trap");
lf[175]=C_h_intern(&lf[175],11,"signal/quit");
lf[176]=C_h_intern(&lf[176],11,"signal/alrm");
lf[177]=C_h_intern(&lf[177],13,"signal/vtalrm");
lf[178]=C_h_intern(&lf[178],11,"signal/prof");
lf[179]=C_h_intern(&lf[179],9,"signal/io");
lf[180]=C_h_intern(&lf[180],10,"signal/urg");
lf[181]=C_h_intern(&lf[181],11,"signal/chld");
lf[182]=C_h_intern(&lf[182],11,"signal/cont");
lf[183]=C_h_intern(&lf[183],11,"signal/stop");
lf[184]=C_h_intern(&lf[184],11,"signal/tstp");
lf[185]=C_h_intern(&lf[185],11,"signal/pipe");
lf[186]=C_h_intern(&lf[186],11,"signal/xcpu");
lf[187]=C_h_intern(&lf[187],11,"signal/xfsz");
lf[188]=C_h_intern(&lf[188],11,"signal/usr1");
lf[189]=C_h_intern(&lf[189],11,"signal/usr2");
lf[190]=C_h_intern(&lf[190],12,"signal/winch");
lf[191]=C_h_intern(&lf[191],12,"signals-list");
lf[192]=C_h_intern(&lf[192],18,"\003sysinterrupt-hook");
lf[193]=C_h_intern(&lf[193],14,"signal-handler");
lf[194]=C_h_intern(&lf[194],19,"set-signal-handler!");
lf[195]=C_h_intern(&lf[195],16,"set-signal-mask!");
lf[196]=C_h_intern(&lf[196],14,"\000process-error");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[198]=C_h_intern(&lf[198],11,"signal-mask");
lf[199]=C_h_intern(&lf[199],14,"signal-masked\077");
lf[200]=C_h_intern(&lf[200],12,"signal-mask!");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[202]=C_h_intern(&lf[202],14,"signal-unmask!");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[204]=C_h_intern(&lf[204],18,"system-information");
lf[205]=C_h_intern(&lf[205],25,"\003syspeek-nonnull-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[207]=C_h_intern(&lf[207],15,"current-user-id");
lf[208]=C_h_intern(&lf[208],25,"current-effective-user-id");
lf[209]=C_h_intern(&lf[209],16,"current-group-id");
lf[210]=C_h_intern(&lf[210],26,"current-effective-group-id");
lf[211]=C_h_intern(&lf[211],16,"user-information");
lf[212]=C_h_intern(&lf[212],6,"vector");
lf[213]=C_h_intern(&lf[213],4,"list");
lf[214]=C_h_intern(&lf[214],27,"current-effective-user-name");
lf[215]=C_h_intern(&lf[215],17,"group-information");
lf[217]=C_h_intern(&lf[217],10,"get-groups");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[221]=C_h_intern(&lf[221],11,"set-groups!");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[224]=C_h_intern(&lf[224],17,"initialize-groups");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[226]=C_h_intern(&lf[226],10,"errno/perm");
lf[227]=C_h_intern(&lf[227],11,"errno/noent");
lf[228]=C_h_intern(&lf[228],10,"errno/srch");
lf[229]=C_h_intern(&lf[229],10,"errno/intr");
lf[230]=C_h_intern(&lf[230],8,"errno/io");
lf[231]=C_h_intern(&lf[231],12,"errno/noexec");
lf[232]=C_h_intern(&lf[232],10,"errno/badf");
lf[233]=C_h_intern(&lf[233],11,"errno/child");
lf[234]=C_h_intern(&lf[234],11,"errno/nomem");
lf[235]=C_h_intern(&lf[235],11,"errno/acces");
lf[236]=C_h_intern(&lf[236],11,"errno/fault");
lf[237]=C_h_intern(&lf[237],10,"errno/busy");
lf[238]=C_h_intern(&lf[238],12,"errno/notdir");
lf[239]=C_h_intern(&lf[239],11,"errno/isdir");
lf[240]=C_h_intern(&lf[240],11,"errno/inval");
lf[241]=C_h_intern(&lf[241],11,"errno/mfile");
lf[242]=C_h_intern(&lf[242],11,"errno/nospc");
lf[243]=C_h_intern(&lf[243],11,"errno/spipe");
lf[244]=C_h_intern(&lf[244],10,"errno/pipe");
lf[245]=C_h_intern(&lf[245],11,"errno/again");
lf[246]=C_h_intern(&lf[246],10,"errno/rofs");
lf[247]=C_h_intern(&lf[247],11,"errno/exist");
lf[248]=C_h_intern(&lf[248],16,"errno/wouldblock");
lf[249]=C_h_intern(&lf[249],10,"errno/2big");
lf[250]=C_h_intern(&lf[250],12,"errno/deadlk");
lf[251]=C_h_intern(&lf[251],9,"errno/dom");
lf[252]=C_h_intern(&lf[252],10,"errno/fbig");
lf[253]=C_h_intern(&lf[253],11,"errno/ilseq");
lf[254]=C_h_intern(&lf[254],11,"errno/mlink");
lf[255]=C_h_intern(&lf[255],17,"errno/nametoolong");
lf[256]=C_h_intern(&lf[256],11,"errno/nfile");
lf[257]=C_h_intern(&lf[257],11,"errno/nodev");
lf[258]=C_h_intern(&lf[258],11,"errno/nolck");
lf[259]=C_h_intern(&lf[259],11,"errno/nosys");
lf[260]=C_h_intern(&lf[260],14,"errno/notempty");
lf[261]=C_h_intern(&lf[261],11,"errno/notty");
lf[262]=C_h_intern(&lf[262],10,"errno/nxio");
lf[263]=C_h_intern(&lf[263],11,"errno/range");
lf[264]=C_h_intern(&lf[264],10,"errno/xdev");
lf[265]=C_h_intern(&lf[265],16,"change-file-mode");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[267]=C_h_intern(&lf[267],17,"change-file-owner");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[269]=C_h_intern(&lf[269],17,"file-read-access\077");
lf[270]=C_h_intern(&lf[270],18,"file-write-access\077");
lf[271]=C_h_intern(&lf[271],20,"file-execute-access\077");
lf[272]=C_h_intern(&lf[272],14,"create-session");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[274]=C_h_intern(&lf[274],16,"process-group-id");
lf[275]=C_h_intern(&lf[275],20,"create-symbolic-link");
lf[276]=C_h_intern(&lf[276],18,"create-symbol-link");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[278]=C_h_intern(&lf[278],9,"substring");
lf[279]=C_h_intern(&lf[279],18,"read-symbolic-link");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[281]=C_h_intern(&lf[281],9,"file-link");
lf[282]=C_h_intern(&lf[282],9,"hard-link");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[284]=C_h_intern(&lf[284],12,"fileno/stdin");
lf[285]=C_h_intern(&lf[285],13,"fileno/stdout");
lf[286]=C_h_intern(&lf[286],13,"fileno/stderr");
lf[287]=C_h_intern(&lf[287],7,"\000append");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[295]=C_h_intern(&lf[295],16,"open-input-file*");
lf[296]=C_h_intern(&lf[296],17,"open-output-file*");
lf[297]=C_h_intern(&lf[297],12,"port->fileno");
lf[298]=C_h_intern(&lf[298],6,"socket");
lf[299]=C_h_intern(&lf[299],20,"\003systcp-port->fileno");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[302]=C_h_intern(&lf[302],25,"\003syspeek-unsigned-integer");
lf[303]=C_h_intern(&lf[303],16,"duplicate-fileno");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[305]=C_h_intern(&lf[305],15,"make-input-port");
lf[306]=C_h_intern(&lf[306],14,"set-port-name!");
lf[307]=C_h_intern(&lf[307],21,"\003syscustom-input-port");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[309]=C_h_intern(&lf[309],17,"\003systhread-yield!");
lf[310]=C_h_intern(&lf[310],25,"\003systhread-block-for-i/o!");
lf[311]=C_h_intern(&lf[311],18,"\003syscurrent-thread");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[316]=C_h_intern(&lf[316],17,"\003sysstring-append");
lf[317]=C_h_intern(&lf[317],15,"\003sysmake-string");
lf[318]=C_h_intern(&lf[318],20,"\003sysscan-buffer-line");
lf[319]=C_h_intern(&lf[319],4,"noop");
lf[320]=C_h_intern(&lf[320],16,"make-output-port");
lf[321]=C_h_intern(&lf[321],22,"\003syscustom-output-port");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[324]=C_h_intern(&lf[324],13,"file-truncate");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[327]=C_h_intern(&lf[327],4,"lock");
lf[328]=C_h_intern(&lf[328],9,"file-lock");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[330]=C_h_intern(&lf[330],18,"file-lock/blocking");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[332]=C_h_intern(&lf[332],14,"file-test-lock");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[334]=C_h_intern(&lf[334],11,"file-unlock");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[336]=C_h_intern(&lf[336],11,"create-fifo");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[338]=C_h_intern(&lf[338],5,"fifo\077");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[340]=C_h_intern(&lf[340],6,"setenv");
lf[341]=C_h_intern(&lf[341],8,"unsetenv");
lf[342]=C_h_intern(&lf[342],25,"get-environment-variables");
lf[343]=C_h_intern(&lf[343],19,"current-environment");
lf[344]=C_h_intern(&lf[344],9,"prot/read");
lf[345]=C_h_intern(&lf[345],10,"prot/write");
lf[346]=C_h_intern(&lf[346],9,"prot/exec");
lf[347]=C_h_intern(&lf[347],9,"prot/none");
lf[348]=C_h_intern(&lf[348],9,"map/fixed");
lf[349]=C_h_intern(&lf[349],10,"map/shared");
lf[350]=C_h_intern(&lf[350],11,"map/private");
lf[351]=C_h_intern(&lf[351],13,"map/anonymous");
lf[352]=C_h_intern(&lf[352],8,"map/file");
lf[353]=C_h_intern(&lf[353],18,"map-file-to-memory");
lf[354]=C_h_intern(&lf[354],4,"mmap");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[356]=C_h_intern(&lf[356],20,"\003syspointer->address");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[358]=C_h_intern(&lf[358],16,"\003sysnull-pointer");
lf[359]=C_h_intern(&lf[359],22,"unmap-file-from-memory");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[361]=C_h_intern(&lf[361],26,"memory-mapped-file-pointer");
lf[362]=C_h_intern(&lf[362],19,"memory-mapped-file\077");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[365]=C_h_intern(&lf[365],19,"seconds->local-time");
lf[366]=C_h_intern(&lf[366],18,"\003sysdecode-seconds");
lf[367]=C_h_intern(&lf[367],17,"seconds->utc-time");
lf[368]=C_h_intern(&lf[368],15,"seconds->string");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[370]=C_h_intern(&lf[370],12,"time->string");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[373]=C_h_intern(&lf[373],12,"string->time");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[375]=C_h_intern(&lf[375],19,"local-time->seconds");
lf[376]=C_h_intern(&lf[376],15,"\003syscons-flonum");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[378]=C_h_intern(&lf[378],17,"utc-time->seconds");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[380]=C_h_intern(&lf[380],27,"local-timezone-abbreviation");
lf[381]=C_h_intern(&lf[381],5,"_exit");
lf[382]=C_h_intern(&lf[382],10,"set-alarm!");
lf[383]=C_h_intern(&lf[383],19,"set-buffering-mode!");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[385]=C_h_intern(&lf[385],5,"\000full");
lf[386]=C_h_intern(&lf[386],5,"\000line");
lf[387]=C_h_intern(&lf[387],5,"\000none");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[389]=C_h_intern(&lf[389],14,"terminal-port\077");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[392]=C_h_intern(&lf[392],13,"terminal-name");
lf[393]=C_h_intern(&lf[393],13,"terminal-size");
lf[394]=C_h_intern(&lf[394],6,"\000error");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[396]=C_h_intern(&lf[396],17,"\003sysmake-locative");
lf[397]=C_h_intern(&lf[397],8,"location");
lf[398]=C_h_intern(&lf[398],13,"get-host-name");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[400]=C_h_intern(&lf[400],6,"regexp");
lf[401]=C_h_intern(&lf[401],12,"string-match");
lf[402]=C_h_intern(&lf[402],12,"glob->regexp");
lf[403]=C_h_intern(&lf[403],13,"make-pathname");
lf[404]=C_h_intern(&lf[404],18,"decompose-pathname");
lf[405]=C_h_intern(&lf[405],4,"glob");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[408]=C_h_intern(&lf[408],12,"process-fork");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[410]=C_h_intern(&lf[410],24,"pathname-strip-directory");
lf[411]=C_h_intern(&lf[411],15,"process-execute");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[413]=C_h_intern(&lf[413],16,"\003sysprocess-wait");
lf[414]=C_h_intern(&lf[414],12,"process-wait");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[416]=C_h_intern(&lf[416],18,"current-process-id");
lf[417]=C_h_intern(&lf[417],17,"parent-process-id");
lf[418]=C_h_intern(&lf[418],5,"sleep");
lf[419]=C_h_intern(&lf[419],14,"process-signal");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[421]=C_h_intern(&lf[421],17,"\003sysshell-command");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[424]=C_h_intern(&lf[424],27,"\003sysshell-command-arguments");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[426]=C_h_intern(&lf[426],11,"process-run");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[428]=C_h_intern(&lf[428],11,"\003sysprocess");
lf[429]=C_h_intern(&lf[429],7,"process");
lf[430]=C_h_intern(&lf[430],8,"process*");
lf[431]=C_h_intern(&lf[431],10,"find-files");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[435]=C_h_intern(&lf[435],16,"\003sysdynamic-wind");
lf[436]=C_h_intern(&lf[436],13,"pathname-file");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[438]=C_h_intern(&lf[438],7,"regexp\077");
lf[439]=C_h_intern(&lf[439],19,"set-root-directory!");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[442]=C_h_intern(&lf[442],21,"set-process-group-id!");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[444]=C_h_intern(&lf[444],18,"getter-with-setter");
lf[445]=C_h_intern(&lf[445],26,"effective-group-id!-setter");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[447]=C_h_intern(&lf[447],12,"set-user-id!");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[449]=C_h_intern(&lf[449],25,"effective-user-id!-setter");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[452]=C_h_intern(&lf[452],23,"\003sysuser-interrupt-hook");
lf[453]=C_h_intern(&lf[453],11,"make-vector");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[456]=C_h_intern(&lf[456],5,"port\077");
lf[457]=C_h_intern(&lf[457],18,"set-file-position!");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[460]=C_h_intern(&lf[460],13,"\000bounds-error");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[462]=C_h_intern(&lf[462],17,"register-feature!");
lf[463]=C_h_intern(&lf[463],5,"posix");
C_register_lf2(lf,464,create_ptable());
t2=C_mutate(&lf[0] /* (set! c150 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3431 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3434 in k3431 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3437 in k3434 in k3431 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 501  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[462]+1)))(3,*((C_word*)lf[462]+1),t2,lf[463]);}

/* k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[113],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3545,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3591,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3629,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3644,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3686,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3725,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3773,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3783,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3975,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4012,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4044,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4050,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4056,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4068,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4074,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4098,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[87]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4107,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[88]+1 /* (set! stat-char-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[89]+1 /* (set! stat-block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4125,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[90]+1 /* (set! stat-fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4134,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[91]+1 /* (set! stat-symlink? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4143,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[92]+1 /* (set! stat-socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t76=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9269,a[2]=((C_word)li260),tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9306,a[2]=((C_word)li261),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 828  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[444]+1)))(4,*((C_word*)lf[444]+1),t76,t77,t78);}

/* a9305 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_9306r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_9306r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9306r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[457]);
t8=(C_word)C_i_check_exact_2(t6,lf[457]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9319,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 843  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[460],lf[457],lf[461],t3,t2);}
else{
t10=t9;
f_9319(2,t10,C_SCHEME_UNDEFINED);}}

/* k9317 in a9305 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 844  port? */
t4=*((C_word*)lf[456]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k9329 in k9317 in a9305 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[4];
f_9325(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_9325(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 848  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[457],lf[459],((C_word*)t0)[5]);}}}

/* k9323 in k9317 in a9305 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 849  posix-error */
t2=lf[3];
f_3463(7,t2,((C_word*)t0)[4],lf[48],lf[457],lf[458],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a9268 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9269,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9273,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9285,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 830  port? */
t5=*((C_word*)lf[456]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9283 in a9268 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[2];
f_9273(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_9273(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 835  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[93],lf[455],((C_word*)t0)[3]);}}}

/* k9271 in a9268 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9276,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 837  posix-error */
t3=lf[3];
f_3463(6,t3,t2,lf[48],lf[93],lf[454],((C_word*)t0)[2]);}
else{
t3=t2;
f_9276(2,t3,C_SCHEME_UNDEFINED);}}

/* k9274 in k9271 in a9268 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[171],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[94]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4165,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[104]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4273,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[106]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4297,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[108]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[109]+1);
t9=C_mutate((C_word*)lf[110]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4321,a[2]=t7,a[3]=t6,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[114]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4478,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[113]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=t11,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[117]+1);
t14=*((C_word*)lf[118]+1);
t15=*((C_word*)lf[119]+1);
t16=*((C_word*)lf[120]+1);
t17=*((C_word*)lf[108]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4549,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4554,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
t21=*((C_word*)lf[123]+1);
t22=*((C_word*)lf[124]+1);
t23=*((C_word*)lf[113]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4565,a[2]=t23,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[103]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4621,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,a[13]=((C_word)li56),tmp=(C_word)a,a+=14,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4938,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4950,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4956,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[150]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4971,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[152]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5007,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[153]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5043,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[157]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[153]+1));
t33=*((C_word*)lf[150]+1);
t34=*((C_word*)lf[152]+1);
t35=*((C_word*)lf[153]+1);
t36=*((C_word*)lf[157]+1);
t37=C_mutate((C_word*)lf[158]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5059,a[2]=t33,a[3]=t35,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[159]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5083,a[2]=t34,a[3]=t36,a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[160]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5107,a[2]=t33,a[3]=t35,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[162]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=t34,a[3]=t36,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[164]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5147,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[166]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[167]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[168]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[169]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[170]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[171]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[172]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[173]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[174]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[175]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[176]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[177]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[178]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[179]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[180]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[181]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[182]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[183]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[184]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[185]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[186]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[187]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[188]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[189]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[190]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1));
t68=C_mutate((C_word*)lf[191]+1 /* (set! signals-list ...) */,t67);
t69=*((C_word*)lf[192]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1171 make-vector */
t71=*((C_word*)lf[453]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5192,2,t0,t1);}
t2=C_mutate((C_word*)lf[193]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5194,a[2]=t1,a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[194]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5203,a[2]=t1,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[192]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[195]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5234,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[198]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5258,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[199]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5290,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[200]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5296,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[202]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5311,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9263,a[2]=((C_word)li259),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1227 set-signal-handler! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[194]+1)))(4,*((C_word*)lf[194]+1),t10,*((C_word*)lf[168]+1),t11);}

/* a9262 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9263,3,t0,t1,t2);}
/* posixunix.scm: 1229 ##sys#user-interrupt-hook */
((C_proc2)C_retrieve_proc(*((C_word*)lf[452]+1)))(2,*((C_word*)lf[452]+1),t1);}

/* k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5329,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9245,a[2]=((C_word)li257),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9248,a[2]=((C_word)li258),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1253 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[444]+1)))(4,*((C_word*)lf[444]+1),t3,t4,t5);}

/* a9247 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9248,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9258,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1257 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9256 in a9247 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1258 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[447],lf[451],((C_word*)t0)[2]);}

/* a9244 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9245,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1110(C_SCHEME_UNDEFINED));}

/* k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5369,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9227,a[2]=((C_word)li255),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9230,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1261 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[444]+1)))(4,*((C_word*)lf[444]+1),t3,t4,t5);}

/* a9229 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9230,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1265 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9238 in a9229 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1266 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[449],lf[450],((C_word*)t0)[2]);}

/* a9226 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9227,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1119(C_SCHEME_UNDEFINED));}

/* k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9209,a[2]=((C_word)li253),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9212,a[2]=((C_word)li254),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1270 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[444]+1)))(4,*((C_word*)lf[444]+1),t3,t4,t5);}

/* a9211 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9212,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9222,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1274 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9220 in a9211 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1275 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[447],lf[448],((C_word*)t0)[2]);}

/* a9208 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9209,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1128(C_SCHEME_UNDEFINED));}

/* k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9191,a[2]=((C_word)li251),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9194,a[2]=((C_word)li252),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1278 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[444]+1)))(4,*((C_word*)lf[444]+1),t3,t4,t5);}

/* a9193 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9194,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9204,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1282 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9202 in a9193 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1283 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[445],lf[446],((C_word*)t0)[2]);}

/* a9190 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9191,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1137(C_SCHEME_UNDEFINED));}

/* k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5381,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[211]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5383,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[124]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5450,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[214]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5464,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[215]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5489,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[216] /* (set! _ensure-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5575,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[217]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5582,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[221]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5645,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[224]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5719,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[226]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[227]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[228]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[229]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[230]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[231]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[232]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[233]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[234]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[235]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[236]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[237]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[238]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[239]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[240]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[241]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[242]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[243]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[244]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[245]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[246]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[247]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[248]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[249] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[250] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[251] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[252] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[253] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[254] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[255] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[256] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[257] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[258] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[259] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[260] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[261] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[262] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[263] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[264] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[265]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5783,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[267]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5810,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5840,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[269]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5864,a[2]=t52,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[270]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5870,a[2]=t52,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[271]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=t52,a[3]=((C_word)li101),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[272]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5882,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9152,a[2]=((C_word)li249),tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9170,a[2]=((C_word)li250),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1498 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[444]+1)))(4,*((C_word*)lf[444]+1),t57,t58,t59);}

/* a9169 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9170,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[442]);
t5=(C_word)C_i_check_exact_2(t3,lf[442]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9186,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1510 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k9184 in a9169 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1511 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[442],lf[443],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9151 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9152,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[274]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9159,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9165,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1503 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_9159(2,t6,C_SCHEME_UNDEFINED);}}

/* k9163 in a9151 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1504 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[274],lf[441],((C_word*)t0)[2]);}

/* k9157 in a9151 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=C_mutate((C_word*)lf[274]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[275]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5901,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[278]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5938,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1531 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word ab[261],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=C_mutate((C_word*)lf[279]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[281]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5989,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[284]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[285]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[286]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6014,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6051,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[295]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6066,a[2]=t7,a[3]=t8,a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[296]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6080,a[2]=t7,a[3]=t8,a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[297]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6094,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[303]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6139,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[305]+1);
t14=*((C_word*)lf[306]+1);
t15=C_mutate((C_word*)lf[307]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6166,a[2]=t13,a[3]=t14,a[4]=((C_word)li131),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[320]+1);
t17=*((C_word*)lf[306]+1);
t18=C_mutate((C_word*)lf[321]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6648,a[2]=t16,a[3]=t17,a[4]=((C_word)li143),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[324]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6907,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6946,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7020,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[328]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7038,a[2]=t20,a[3]=t21,a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[330]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7053,a[2]=t20,a[3]=t21,a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[332]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7068,a[2]=t20,a[3]=t21,a[4]=((C_word)li149),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[334]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7090,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[336]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7118,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[338]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7161,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[340]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7187,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[341]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7204,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[342]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7224,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[343]+1 /* (set! current-environment ...) */,*((C_word*)lf[342]+1));
t32=C_mutate((C_word*)lf[344]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[345]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[346]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[347]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[348]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[349]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[350]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[351]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[352]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[353]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7328,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[359]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7390,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[361]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7425,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[362]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7434,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[363] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7440,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[365]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7459,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[367]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7468,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[368]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7487,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[370]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7523,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[373]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7592,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[375]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7638,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[378]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7653,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[380]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7668,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[381]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7680,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[382]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7696,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[383]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7703,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[389]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7762,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate(&lf[390] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7781,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[392]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7813,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[393]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7836,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[398]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7871,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t62=*((C_word*)lf[400]+1);
t63=*((C_word*)lf[401]+1);
t64=*((C_word*)lf[402]+1);
t65=*((C_word*)lf[110]+1);
t66=*((C_word*)lf[403]+1);
t67=*((C_word*)lf[404]+1);
t68=C_mutate((C_word*)lf[405]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7883,a[2]=t64,a[3]=t62,a[4]=t65,a[5]=t63,a[6]=t66,a[7]=t67,a[8]=((C_word)li183),tmp=(C_word)a,a+=9,tmp));
t69=C_mutate((C_word*)lf[408]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7992,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8034,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8053,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
t72=*((C_word*)lf[410]+1);
t73=C_mutate((C_word*)lf[411]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8072,a[2]=t72,a[3]=t71,a[4]=t70,a[5]=((C_word)li193),tmp=(C_word)a,a+=6,tmp));
t74=C_mutate((C_word*)lf[413]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8254,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[414]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8271,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[416]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8349,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[417]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8352,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[418]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8355,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[419]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8362,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[421]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8389,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[424]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8398,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp));
t82=*((C_word*)lf[408]+1);
t83=*((C_word*)lf[411]+1);
t84=*((C_word*)lf[123]+1);
t85=C_mutate((C_word*)lf[426]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8404,a[2]=t82,a[3]=t83,a[4]=((C_word)li204),tmp=(C_word)a,a+=5,tmp));
t86=*((C_word*)lf[164]+1);
t87=*((C_word*)lf[414]+1);
t88=*((C_word*)lf[408]+1);
t89=*((C_word*)lf[411]+1);
t90=*((C_word*)lf[303]+1);
t91=*((C_word*)lf[55]+1);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8460,a[2]=t87,a[3]=((C_word)li208),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8497,a[2]=t86,a[3]=((C_word)li211),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8517,a[2]=t91,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8531,a[2]=t91,a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp);
t96=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8548,a[2]=((C_word)li214),tmp=(C_word)a,a+=3,tmp);
t97=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8564,a[2]=t93,a[3]=t88,a[4]=t95,a[5]=t89,a[6]=t96,a[7]=((C_word)li216),tmp=(C_word)a,a+=8,tmp);
t98=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8609,a[2]=t94,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp);
t99=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8620,a[2]=t94,a[3]=((C_word)li218),tmp=(C_word)a,a+=4,tmp);
t100=C_mutate((C_word*)lf[428]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8631,a[2]=t99,a[3]=t92,a[4]=t98,a[5]=t97,a[6]=((C_word)li221),tmp=(C_word)a,a+=7,tmp));
t101=C_set_block_item(lf[429] /* process */,0,C_SCHEME_UNDEFINED);
t102=C_set_block_item(lf[430] /* process* */,0,C_SCHEME_UNDEFINED);
t103=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8689,a[2]=((C_word)li226),tmp=(C_word)a,a+=3,tmp);
t104=C_mutate((C_word*)lf[429]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8750,a[2]=t103,a[3]=((C_word)li230),tmp=(C_word)a,a+=4,tmp));
t105=C_mutate((C_word*)lf[430]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8810,a[2]=t103,a[3]=((C_word)li234),tmp=(C_word)a,a+=4,tmp));
t106=*((C_word*)lf[405]+1);
t107=*((C_word*)lf[401]+1);
t108=*((C_word*)lf[403]+1);
t109=*((C_word*)lf[114]+1);
t110=C_mutate((C_word*)lf[431]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8870,a[2]=t109,a[3]=t108,a[4]=t106,a[5]=t107,a[6]=((C_word)li247),tmp=(C_word)a,a+=7,tmp));
t111=C_mutate((C_word*)lf[439]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9129,a[2]=((C_word)li248),tmp=(C_word)a,a+=3,tmp));
t112=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t112+1)))(2,t112,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9129,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[439]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9121,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_9121(2,t6,C_SCHEME_FALSE);}}

/* k9119 in set-root-directory! in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub3168(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2393 posix-error */
t3=lf[3];
f_3463(6,t3,((C_word*)t0)[3],lf[48],lf[439],lf[440],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_8870r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8870r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8870r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li242),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9037,a[2]=t5,a[3]=((C_word)li243),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9042,a[2]=t6,a[3]=((C_word)li244),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9047,a[2]=t7,a[3]=((C_word)li246),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action30583149 */
t9=t8;
f_9047(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id30593145 */
t11=t7;
f_9042(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit30603140 */
t13=t6;
f_9037(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body30563066 */
t15=t5;
f_8872(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action3058 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_9047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9047,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9053,a[2]=((C_word)li245),tmp=(C_word)a,a+=3,tmp);
/* def-id30593145 */
t3=((C_word*)t0)[2];
f_9042(t3,t1,t2);}

/* a9052 in def-action3058 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9053,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id3059 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_9042(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9042,NULL,3,t0,t1,t2);}
/* def-limit30603140 */
t3=((C_word*)t0)[2];
f_9037(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit3060 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_9037(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9037,NULL,4,t0,t1,t2,t3);}
/* body30563066 */
t4=((C_word*)t0)[2];
f_8872(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8872,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[431]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8879,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_8879(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9032,a[2]=t4,a[3]=t7,a[4]=((C_word)li240),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_8879(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9024,a[2]=((C_word)li241),tmp=(C_word)a,a+=3,tmp));}}

/* f_9024 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9024(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9024,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_9032 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9032(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9032,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8879,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_9012(2,t4,t2);}
else{
/* posixunix.scm: 2365 regexp? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[438]+1)))(3,*((C_word*)lf[438]+1),t3,((C_word*)t0)[11]);}}

/* k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9012,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li235),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9006,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2368 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[437]);}

/* k9004 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2368 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8889,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8891,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li239),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_8891(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8891,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2374 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8910,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2375 pathname-file */
t3=*((C_word*)lf[436]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8992,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2382 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8990 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8992,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2382 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2383 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8891(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k8997 in k8990 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2382 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8891(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8986,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[432]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[433]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2375 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8891(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2376 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8925,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8935,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8937,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li236),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li237),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8966,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li238),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[435]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8976,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8979,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2381 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8977 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2381 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8976(2,t2,((C_word*)t0)[2]);}}

/* k8974 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2381 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8891(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8965 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8966,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8941 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8964,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2379 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[434]);}

/* k8962 in a8941 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2379 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8948 in a8941 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8954,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2380 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k8955 in k8948 in a8941 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2380 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8954(2,t2,((C_word*)t0)[2]);}}

/* k8952 in k8948 in a8941 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2379 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8891(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8936 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8937,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8933 in k8923 in k8984 in k8908 in loop in k8887 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2377 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8891(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9013 in k9010 in k8877 in body3056 in find-files in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9013,3,t0,t1,t2);}
/* posixunix.scm: 2366 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8810(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8810r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8810r(t0,t1,t2,t3);}}

static void C_ccall f_8810r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8812,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li231),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8817,a[2]=t4,a[3]=((C_word)li232),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8822,a[2]=t5,a[3]=((C_word)li233),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args30113027 */
t7=t6;
f_8822(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env30123023 */
t9=t5;
f_8817(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body30093018 */
t11=t4;
f_8812(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args3011 in process* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8822,NULL,2,t0,t1);}
/* def-env30123023 */
t2=((C_word*)t0)[2];
f_8817(t2,t1,C_SCHEME_FALSE);}

/* def-env3012 in process* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8817(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8817,NULL,3,t0,t1,t2);}
/* body30093018 */
t3=((C_word*)t0)[2];
f_8812(t3,t1,t2,C_SCHEME_FALSE);}

/* body3009 in process* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8812(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8812,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2343 %process */
f_8689(t1,lf[430],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8750r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8750r(t0,t1,t2,t3);}}

static void C_ccall f_8750r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8752,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li227),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8757,a[2]=t4,a[3]=((C_word)li228),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8762,a[2]=t5,a[3]=((C_word)li229),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args29672983 */
t7=t6;
f_8762(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env29682979 */
t9=t5;
f_8757(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body29652974 */
t11=t4;
f_8752(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args2967 in process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8762,NULL,2,t0,t1);}
/* def-env29682979 */
t2=((C_word*)t0)[2];
f_8757(t2,t1,C_SCHEME_FALSE);}

/* def-env2968 in process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8757(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8757,NULL,3,t0,t1,t2);}
/* body29652974 */
t3=((C_word*)t0)[2];
f_8752(t3,t1,t2,C_SCHEME_FALSE);}

/* body2965 in process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8752(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8752,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2340 %process */
f_8689(t1,lf[429],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8689(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8689,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8691,a[2]=t2,a[3]=((C_word)li223),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8710,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2329 chkstrlst */
t12=t9;
f_8691(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8744,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2331 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[424]+1)))(3,*((C_word*)lf[424]+1),t12,((C_word*)t7)[1]);}}

/* k8742 in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8744,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2332 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[421]+1)))(2,*((C_word*)lf[421]+1),t3);}

/* k8746 in k8742 in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8710(2,t3,t2);}

/* k8708 in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2333 chkstrlst */
t3=((C_word*)t0)[2];
f_8691(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8713(2,t3,C_SCHEME_UNDEFINED);}}

/* k8711 in k8708 in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li224),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[3],a[3]=((C_word)li225),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8723 in k8711 in k8708 in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8724,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2336 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2337 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8717 in k8711 in k8708 in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8718,2,t0,t1);}
/* posixunix.scm: 2334 ##sys#process */
t2=*((C_word*)lf[428]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8691,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8700,a[2]=((C_word*)t0)[2],a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8699 in chkstrlst in %process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8700,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8631,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8637,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li219),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li220),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a8642 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8643,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8674,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2310 make-on-close */
t12=((C_word*)t0)[3];
f_8460(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8672 in a8642 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2309 input-port */
t2=((C_word*)t0)[7];
f_8609(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8652 in a8642 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8658,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2312 make-on-close */
t4=((C_word*)t0)[6];
f_8460(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8668 in k8652 in a8642 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2311 output-port */
t2=((C_word*)t0)[7];
f_8620(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8656 in k8652 in a8642 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8662,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8666,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2315 make-on-close */
t4=((C_word*)t0)[3];
f_8460(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8664 in k8656 in k8652 in a8642 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2314 input-port */
t2=((C_word*)t0)[7];
f_8609(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8660 in k8656 in k8652 in a8642 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2308 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8636 in ##sys#process in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8637,2,t0,t1);}
/* posixunix.scm: 2303 spawn */
t2=((C_word*)t0)[8];
f_8564(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8620(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8620,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8624,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2299 connect-parent */
t8=((C_word*)t0)[2];
f_8517(t8,t7,t4,t5);}

/* k8622 in output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2300 ##sys#custom-output-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[321]+1)))(8,*((C_word*)lf[321]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8609,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8613,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2295 connect-parent */
t8=((C_word*)t0)[2];
f_8517(t8,t7,t4,t5);}

/* k8611 in input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2296 ##sys#custom-input-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[307]+1)))(8,*((C_word*)lf[307]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8564,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2282 needed-pipe */
t9=((C_word*)t0)[2];
f_8497(t9,t8,t6);}

/* k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2283 needed-pipe */
t3=((C_word*)t0)[2];
f_8497(t3,t2,((C_word*)t0)[5]);}

/* k8569 in k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2284 needed-pipe */
t3=((C_word*)t0)[2];
f_8497(t3,t2,((C_word*)t0)[6]);}

/* k8572 in k8569 in k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8574,2,t0,t1);}
t2=f_8548(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8585,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li215),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2287 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8586 in k8572 in k8569 in k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8591,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2289 connect-child */
t3=((C_word*)t0)[7];
f_8531(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[284]+1));}

/* k8589 in a8586 in k8572 in k8569 in k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8594,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_8548(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2290 connect-child */
t4=((C_word*)t0)[5];
f_8531(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[285]+1));}

/* k8592 in k8589 in a8586 in k8572 in k8569 in k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8597,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_8548(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2291 connect-child */
t4=((C_word*)t0)[3];
f_8531(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[286]+1));}

/* k8595 in k8592 in k8589 in a8586 in k8572 in k8569 in k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2292 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8583 in k8572 in k8569 in k8566 in spawn in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2285 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_8548(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8531,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8544,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2273 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k8542 in connect-child in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8544,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8456,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2247 duplicate-fileno */
t6=*((C_word*)lf[303]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k8454 in k8542 in connect-child in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2248 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8517(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8517,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8530,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2267 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8528 in connect-parent in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8497,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8506,a[2]=((C_word*)t0)[2],a[3]=((C_word)li209),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8512,a[2]=((C_word)li210),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a8511 in needed-pipe in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8512,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a8505 in needed-pipe in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8506,2,t0,t1);}
/* posixunix.scm: 2262 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8460(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8460,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8462,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li207),tmp=(C_word)a,a+=10,tmp));}

/* f_8462 in make-on-close in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8462,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li205),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li206),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a8482 */
static void C_ccall f_8483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8483,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2257 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[196],((C_word*)t0)[3],lf[427],((C_word*)t0)[2],t4);}}

/* a8476 */
static void C_ccall f_8477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8477,2,t0,t1);}
/* posixunix.scm: 2255 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8404(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8404r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8404r(t0,t1,t2,t3);}}

static void C_ccall f_8404r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8411,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2211 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k8409 in process-run in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8411,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2213 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2215 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[421]+1)))(2,*((C_word*)lf[421]+1),t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8428 in k8409 in process-run in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8434,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2215 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[424]+1)))(3,*((C_word*)lf[424]+1),t2,((C_word*)t0)[2]);}

/* k8432 in k8428 in k8409 in process-run in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2215 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8398,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[425],t2));}

/* ##sys#shell-command in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8393,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2200 getenv */
t3=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[423]);}

/* k8391 in ##sys#shell-command in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[422]));}

/* process-signal in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8362(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8362r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8362r(t0,t1,t2,t3);}}

static void C_ccall f_8362r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[419]);
t7=(C_word)C_i_check_exact_2(t5,lf[419]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2197 posix-error */
t10=lf[3];
f_3463(7,t10,t1,lf[196],lf[419],lf[420],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8355,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2715(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8352,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2710(C_SCHEME_UNDEFINED));}

/* current-process-id in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2706(C_SCHEME_UNDEFINED));}

/* process-wait in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8271(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_8271r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8271r(t0,t1,t2);}}

static void C_ccall f_8271r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[414]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8301,a[2]=t8,a[3]=t11,a[4]=((C_word)li195),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8307,a[2]=t11,a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a8306 in process-wait in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8307,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2183 posix-error */
t6=lf[3];
f_3463(6,t6,t1,lf[196],lf[414],lf[415],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8300 in process-wait in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8301,2,t0,t1);}
/* posixunix.scm: 2181 ##sys#process-wait */
((C_proc4)C_retrieve_proc(*((C_word*)lf[413]+1)))(4,*((C_word*)lf[413]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8254,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2168 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8072(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_8072r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8072r(t0,t1,t2,t3);}}

static void C_ccall f_8072r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li190),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8201,a[2]=t4,a[3]=((C_word)li191),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8206,a[2]=t5,a[3]=((C_word)li192),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist25722640 */
t7=t6;
f_8206(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist25732636 */
t9=t5;
f_8201(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body25702579 */
t11=t4;
f_8074(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist2572 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8206(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8206,NULL,2,t0,t1);}
/* def-envlist25732636 */
t2=((C_word*)t0)[2];
f_8201(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist2573 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8201,NULL,3,t0,t1,t2);}
/* body25702579 */
t3=((C_word*)t0)[2];
f_8074(t3,t1,t2,C_SCHEME_FALSE);}

/* body2570 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8074,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[411]);
t5=(C_word)C_i_check_list_2(t2,lf[411]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8084,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2136 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k8082 in body2570 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8084,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_8034(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8092,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li189),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_8092(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop2585 in k8082 in body2570 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8092,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_8034(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8105,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[411]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8138,a[2]=((C_word*)t0)[3],a[3]=((C_word)li188),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_8105(t8,f_8138(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_8105(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[411]);
t6=(C_word)C_block_size(t4);
t7=f_8034(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop2596 in doloop2585 in k8082 in body2570 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_8138(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_8053(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[411]);
t5=(C_word)C_block_size(t3);
t6=f_8053(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k8103 in doloop2585 in k8082 in body2570 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_8105(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8105,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2150 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8128 in k8103 in doloop2585 in k8082 in body2570 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2150 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8106 in k8103 in doloop2585 in k8082 in body2570 in process-execute in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub2535(C_SCHEME_UNDEFINED);
t5=(C_word)stub2550(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2157 posix-error */
t6=lf[3];
f_3463(6,t6,((C_word*)t0)[3],lf[196],lf[411],lf[412],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_8053(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2541(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_8034(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2526(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7992r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7992r(t0,t1,t2);}}

static void C_ccall f_7992r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub2494(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2121 posix-error */
t5=lf[3];
f_3463(5,t5,t1,lf[196],lf[408],lf[409]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8014,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k8012 in process-fork in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8018,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_8018 in k8012 in process-fork in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_8018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8018,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2512(C_SCHEME_UNDEFINED,t3));}

/* glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_7883r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7883r(t0,t1,t2);}}

static void C_ccall f_7883r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=((C_word)li182),tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_7889(t6,t1,t2);}

/* conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7889(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7889,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7904,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li179),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li181),tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7910,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7984,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[407]);
/* posixunix.scm: 2106 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k7982 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2106 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7912 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2107 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7915 in k7912 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7924,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[406]);
/* posixunix.scm: 2108 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7922 in k7915 in k7912 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7924,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li180),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7926(t5,((C_word*)t0)[2],t1);}

/* loop in k7922 in k7915 in k7912 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7926(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7926,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2109 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7889(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7943,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2110 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7941 in loop in k7922 in k7915 in k7912 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7943,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7953,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 2111 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 2112 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7926(t3,((C_word*)t0)[6],t2);}}

/* k7951 in k7941 in loop in k7922 in k7915 in k7912 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7957,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2111 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7926(t4,t2,t3);}

/* k7955 in k7951 in k7941 in loop in k7922 in k7915 in k7912 in a7909 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7957,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7903 in conc-loop in glob in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7904,2,t0,t1);}
/* posixunix.scm: 2105 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7875,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub2408(t3),C_fix(0));}

/* k7873 in get-host-name in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7878,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7878(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2087 posix-error */
t3=lf[3];
f_3463(5,t3,t2,lf[394],lf[398],lf[399]);}}

/* k7876 in k7873 in get-host-name in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7836,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7840,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2068 ##sys#terminal-check */
f_7781(t3,lf[393],t2);}

/* k7838 in terminal-size in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7840,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7860,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[396]+1)))(6,*((C_word*)lf[396]+1),t4,t2,C_fix(0),C_SCHEME_FALSE,lf[397]);}

/* k7858 in k7838 in terminal-size in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[396]+1)))(6,*((C_word*)lf[396]+1),t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[397]);}

/* k7862 in k7858 in k7838 in terminal-size in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub2379(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2075 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2076 posix-error */
t9=lf[3];
f_3463(6,t9,((C_word*)t0)[4],lf[394],lf[393],lf[395],((C_word*)t0)[6]);}}

/* terminal-name in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7813,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7817,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2060 ##sys#terminal-check */
f_7781(t3,lf[392],t2);}

/* k7815 in terminal-name in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7817,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub2364(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7781(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7781,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7785,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2052 ##sys#check-port */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7783 in ##sys#terminal-check in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[149],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2055 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[391],((C_word*)t0)[4]);}}

/* terminal-port? in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7762,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7766,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2047 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[389]);}

/* k7764 in terminal-port? in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2048 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7767 in k7764 in terminal-port? in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7703r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7703r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7703r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7707,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2032 ##sys#check-port */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[383]);}

/* k7705 in set-buffering-mode! in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7707,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[385]);
if(C_truep(t6)){
t7=t5;
f_7713(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[386]);
if(C_truep(t7)){
t8=t5;
f_7713(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[387]);
if(C_truep(t8)){
t9=t5;
f_7713(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2038 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[383],lf[388],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k7711 in k7705 in set-buffering-mode! in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[383]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[149],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2044 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[383],lf[384],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7696,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2315(C_SCHEME_UNDEFINED,t3));}

/* _exit in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7680(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7680r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7680r(t0,t1,t2);}}

static void C_ccall f_7680r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub2306(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7668,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub2298(t2),C_fix(0));}

/* utc-time->seconds in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7653,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7657,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2000 check-time-vector */
f_7440(t3,lf[378],t2);}

/* k7655 in utc-time->seconds in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 2002 ##sys#cons-flonum */
t2=*((C_word*)lf[376]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2003 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[378],lf[379],((C_word*)t0)[3]);}}

/* local-time->seconds in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7638,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7642,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1994 check-time-vector */
f_7440(t3,lf[375],t2);}

/* k7640 in local-time->seconds in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1996 ##sys#cons-flonum */
t2=*((C_word*)lf[376]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1997 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[375],lf[377],((C_word*)t0)[3]);}}

/* string->time in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7592r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7592r(t0,t1,t2,t3);}}

static void C_ccall f_7592r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7596,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7596(2,t5,lf[374]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7596(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7594 in string->time in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7596,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[373]);
t3=(C_word)C_i_check_string_2(t1,lf[373]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7609,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1991 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k7607 in k7594 in string->time in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7613,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1991 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7611 in k7607 in k7594 in string->time in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7613,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2259(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7523r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7523r(t0,t1,t2,t3);}}

static void C_ccall f_7523r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7527,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7527(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7527(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7525 in time->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1975 check-time-vector */
f_7440(t2,lf[370],((C_word*)t0)[2]);}

/* k7528 in k7525 in time->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[370]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7549,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1979 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2209(t4,t3),C_fix(0));}}

/* k7550 in k7528 in k7525 in time->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1983 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1984 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[370],lf[372],((C_word*)t0)[2]);}}

/* k7547 in k7528 in k7525 in time->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7549,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub2217(t3,t2,t1),C_fix(0));}

/* k7537 in k7528 in k7525 in time->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1980 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[370],lf[371],((C_word*)t0)[2]);}}

/* seconds->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7487,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[368]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7494,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_integer_argumentp(t5);
t8=(C_word)stub2193(t6,t7);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,t8,C_fix(0));}

/* k7492 in seconds->string in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1968 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1969 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[369],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7468,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[367]);
/* posixunix.scm: 1960 ##sys#decode-seconds */
t4=*((C_word*)lf[366]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7459,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[365]);
/* posixunix.scm: 1956 ##sys#decode-seconds */
t4=*((C_word*)lf[366]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7440(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7440,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1952 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[364],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* memory-mapped-file? in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[354]));}

/* memory-mapped-file-pointer in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7425,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[354],lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7390r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7390r(t0,t1,t2,t3);}}

static void C_ccall f_7390r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[354],lf[359]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub2146(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1938 posix-error */
t12=lf[3];
f_3463(7,t12,t1,lf[48],lf[359],lf[360],t2,t6);}}

/* map-file-to-memory in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_7328r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_7328r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_7328r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7332,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_7332(2,t10,t2);}
else{
/* posixunix.scm: 1923 ##sys#null-pointer */
t10=*((C_word*)lf[358]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k7330 in map-file-to-memory in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7332,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7338,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_7338(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1926 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[353],lf[357],t1);}}

/* k7336 in k7330 in map-file-to-memory in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7338,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub2107(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1928 ##sys#pointer->address */
t17=*((C_word*)lf[356]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k7355 in k7336 in k7330 in map-file-to-memory in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1929 posix-error */
t3=lf[3];
f_3463(11,t3,((C_word*)t0)[8],lf[48],lf[353],lf[355],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_7344(2,t3,C_SCHEME_UNDEFINED);}}

/* k7342 in k7336 in k7330 in map-file-to-memory in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7344,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[354],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7224,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7230,a[2]=t3,a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7230(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7230(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7230,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7234,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub2058(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k7232 in loop in get-environment-variables in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7234,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7242,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li155),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7242(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k7232 in loop in get-environment-variables in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7242,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7268,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1887 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1890 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k7266 in scan in k7232 in loop in get-environment-variables in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7272,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1888 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k7270 in k7266 in scan in k7232 in loop in get-environment-variables in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7272,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7260,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1889 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7230(t5,t3,t4);}

/* k7258 in k7270 in k7266 in scan in k7232 in loop in get-environment-variables in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7260,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7204,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[341]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7212,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1876 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7210 in unsetenv in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7187,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[340]);
t5=(C_word)C_i_check_string_2(t3,lf[340]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7198,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1871 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7196 in setenv in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7202,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1871 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7200 in k7196 in setenv in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7161,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7168,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7185,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1859 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7183 in fifo? in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1859 ##sys#file-info */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7166 in fifo? in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1862 posix-error */
t2=lf[3];
f_3463(6,t2,((C_word*)t0)[3],lf[48],lf[338],lf[339],((C_word*)t0)[2]);}}

/* create-fifo in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7118r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7118r(t0,t1,t2,t3);}}

static void C_ccall f_7118r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[336]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7125,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_7125(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_7125(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k7123 in create-fifo in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7125,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[336]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7146,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1853 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k7144 in k7123 in create-fifo in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1853 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7140 in k7123 in create-fifo in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1854 posix-error */
t3=lf[3];
f_3463(7,t3,((C_word*)t0)[3],lf[48],lf[336],lf[337],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7090,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[327],lf[334]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1843 posix-error */
t9=lf[3];
f_3463(6,t9,t1,lf[48],lf[334],lf[335],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7068r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7068r(t0,t1,t2,t3);}}

static void C_ccall f_7068r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7072,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1834 setup */
f_6946(t4,t2,t3,lf[332]);}

/* k7070 in file-test-lock in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1836 err */
f_7020(((C_word*)t0)[3],lf[333],t1,lf[332]);}}

/* file-lock/blocking in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7053r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7053r(t0,t1,t2,t3);}}

static void C_ccall f_7053r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7057,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1828 setup */
f_6946(t4,t2,t3,lf[330]);}

/* k7055 in file-lock/blocking in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1830 err */
f_7020(((C_word*)t0)[2],lf[331],t1,lf[330]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7038r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7038r(t0,t1,t2,t3);}}

static void C_ccall f_7038r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7042,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1822 setup */
f_6946(t4,t2,t3,lf[328]);}

/* k7040 in file-lock in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1824 err */
f_7020(((C_word*)t0)[2],lf[329],t1,lf[328]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_7020(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7020,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1819 posix-error */
t8=lf[3];
f_3463(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6946(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6946,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6968,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1811 ##sys#check-port */
t16=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k6966 in setup in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6974(t6,t5);}
else{
t5=t3;
f_6974(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6972 in k6966 in setup in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6974,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[327],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6907,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[324]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6924,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6931,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6935,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1794 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6924(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1796 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[324],lf[326],t2);}}}

/* k6933 in file-truncate in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1794 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6929 in file-truncate in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6924(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6922 in file-truncate in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1798 posix-error */
t2=lf[3];
f_3463(7,t2,((C_word*)t0)[4],lf[48],lf[324],lf[325],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_6648r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6648r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6648r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li139),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6834,a[2]=t6,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6839,a[2]=t7,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6844,a[2]=t8,a[3]=((C_word)li142),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?18321923 */
t10=t9;
f_6844(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi18331919 */
t12=t8;
f_6839(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close18341914 */
t14=t7;
f_6834(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body18301840 */
t16=t6;
f_6650(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?1832 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6844,NULL,2,t0,t1);}
/* def-bufi18331919 */
t2=((C_word*)t0)[2];
f_6839(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1833 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6839(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6839,NULL,3,t0,t1,t2);}
/* def-on-close18341914 */
t3=((C_word*)t0)[2];
f_6834(t3,t1,t2,C_fix(0));}

/* def-on-close1834 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6834(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6834,NULL,4,t0,t1,t2,t3);}
/* body18301840 */
t4=((C_word*)t0)[2];
f_6650(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6650(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6650,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6654,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1736 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_6654(2,t6,C_SCHEME_UNDEFINED);}}

/* k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6654,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6656,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li132),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6702(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6746,a[2]=t3,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6760,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1755 ##sys#make-string */
t12=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6760(2,t12,((C_word*)t0)[6]);}}}

/* k6758 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6760,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6702(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6761,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li138),tmp=(C_word)a,a+=7,tmp));}

/* f_6761 in k6758 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6761,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6778,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li137),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6778(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1771 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6656(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6778(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6778,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6788,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1761 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6656(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1766 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6786 in loop */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1763 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6778(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6746 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6746,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1754 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6656(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6700 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6702,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6711,a[2]=((C_word*)t0)[9],a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li134),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6738,a[2]=((C_word*)t0)[9],a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1774 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a6737 in k6700 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6738,2,t0,t1);}
/* posixunix.scm: 1784 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a6716 in k6700 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6717,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6727,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1781 posix-error */
t3=lf[3];
f_3463(7,t3,t2,lf[48],((C_word*)t0)[3],lf[323],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6727(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6725 in a6716 in k6700 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1782 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6710 in k6700 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6711,3,t0,t1,t2);}
/* posixunix.scm: 1776 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k6704 in k6700 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6709,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1785 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6707 in k6704 in k6700 in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6656(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6656,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6672,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1744 ##sys#thread-yield! */
t8=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1746 posix-error */
t7=lf[3];
f_3463(7,t7,t1,((C_word*)t0)[3],lf[48],lf[322],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6691,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1748 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6689 in poke in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1748 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6656(t3,((C_word*)t0)[2],t1,t2);}

/* k6670 in poke in k6652 in body1830 in ##sys#custom-output-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1745 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6656(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6166r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6166r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6166r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li126),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6555,a[2]=t6,a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6560,a[2]=t7,a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6565,a[2]=t8,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6570,a[2]=t9,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?15931791 */
t11=t10;
f_6570(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi15941787 */
t13=t9;
f_6565(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close15951782 */
t15=t8;
f_6560(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?15961776 */
t17=t7;
f_6555(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body15911602 */
t19=t6;
f_6168(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?1593 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6570,NULL,2,t0,t1);}
/* def-bufi15941787 */
t2=((C_word*)t0)[2];
f_6565(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1594 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6565(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6565,NULL,3,t0,t1,t2);}
/* def-on-close15951782 */
t3=((C_word*)t0)[2];
f_6560(t3,t1,t2,C_fix(1));}

/* def-on-close1595 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6560(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6560,NULL,4,t0,t1,t2,t3);}
/* def-more?15961776 */
t4=((C_word*)t0)[2];
f_6555(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* def-more?1596 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6555(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6555,NULL,5,t0,t1,t2,t3,t4);}
/* body15911602 */
t5=((C_word*)t0)[2];
f_6168(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6168,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1610 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_6172(2,t7,C_SCHEME_UNDEFINED);}}

/* k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1612 ##sys#make-string */
t5=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_6178(2,t5,((C_word*)t0)[10]);}}

/* k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6178,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li112),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6202,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li114),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6297,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li115),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6310,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li116),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li117),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6343,a[2]=t8,a[3]=t7,a[4]=((C_word)li118),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6352,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6428,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li125),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1660 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6428,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6434,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li124),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_6434(t7,t1,C_SCHEME_FALSE);}

/* loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6434,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6436,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li121),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6514,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li122),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6520,a[2]=((C_word*)t0)[2],a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6530,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1725 fetch */
t5=((C_word*)t0)[5];
f_6210(t5,t4);}}

/* k6528 in loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1727 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6434(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a6519 in loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6520,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1722 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6434(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a6513 in loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
/* posixunix.scm: 1720 ##sys#scan-buffer-line */
((C_proc6)C_retrieve_proc(*((C_word*)lf[318]+1)))(6,*((C_word*)lf[318]+1),t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6436,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_6443(2,t8,(C_truep(t7)?t7:lf[315]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6486,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1702 ##sys#make-string */
t8=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k6484 in bumper in loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1708 ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[316]+1)))(4,*((C_word*)lf[316]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_6443(2,t6,t1);}}

/* k6441 in bumper in loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6443,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6453,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1712 fetch */
t5=((C_word*)t0)[3];
f_6210(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1717 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k6451 in k6441 in bumper in loop in a6427 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1713 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6351 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6352,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6360,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_6360(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_6360(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k6358 in a6351 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6360,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li119),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6362(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k6358 in a6351 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6362,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1688 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6410,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1690 fetch */
t7=((C_word*)t0)[2];
f_6210(t7,t6);}}}

/* k6408 in loop in k6358 in a6351 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1693 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6362(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a6342 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1678 fetch */
t3=((C_word*)t0)[2];
f_6210(t3,t2);}

/* k6345 in a6342 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1679 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_6202(((C_word*)t0)[2]));}

/* a6321 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6322,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6332,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1675 posix-error */
t3=lf[3];
f_3463(7,t3,t2,lf[48],((C_word*)t0)[3],lf[314],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6332(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6330 in a6321 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1676 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6309 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6310,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1670 ready? */
t3=((C_word*)t0)[2];
f_6179(t3,t1);}}

/* a6296 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6301,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1662 fetch */
t3=((C_word*)t0)[2];
f_6210(t3,t2);}

/* k6299 in a6296 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_6202(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k6290 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6292,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6295,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1729 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6293 in k6290 in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6210,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6222,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li113),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_6222(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6222,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6238,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1637 ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[310]+1)))(5,*((C_word*)lf[310]+1),t5,*((C_word*)lf[311]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1640 posix-error */
t5=lf[3];
f_3463(7,t5,t1,lf[48],((C_word*)t0)[6],lf[312],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1644 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k6257 in loop in fetch in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6259,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6262,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1646 ##sys#thread-yield! */
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6268,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_6268(2,t8,t7);}
else{
/* posixunix.scm: 1652 posix-error */
t7=lf[3];
f_3463(7,t7,t4,lf[48],((C_word*)t0)[3],lf[313],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_6268(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6266 in k6257 in loop in fetch in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6260 in k6257 in loop in fetch in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1647 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6222(t2,((C_word*)t0)[2]);}

/* k6236 in loop in fetch in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1638 ##sys#thread-yield! */
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6239 in k6236 in loop in fetch in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1639 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6222(t2,((C_word*)t0)[2]);}

/* peek in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_6202(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6179,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1618 ##sys#file-select-one */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[3]);}

/* k6181 in ready? in k6176 in k6170 in body1591 in ##sys#custom-input-port in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1622 posix-error */
t4=lf[3];
f_3463(7,t4,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[308],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6139r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6139r(t0,t1,t2,t3);}}

static void C_ccall f_6139r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[303]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6146,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_6146(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[303]);
t8=t5;
f_6146(t8,(C_word)C_dup2(t2,t6));}}

/* k6144 in duplicate-fileno in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6146,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6149,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1603 posix-error */
t3=lf[3];
f_3463(6,t3,t2,lf[48],lf[303],lf[304],((C_word*)t0)[2]);}
else{
t3=t2;
f_6149(2,t3,C_SCHEME_UNDEFINED);}}

/* k6147 in k6144 in duplicate-fileno in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6094,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6098,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1585 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[297]);}

/* k6096 in port->fileno in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6098,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[298],t2);
if(C_truep(t3)){
/* posixunix.scm: 1586 ##sys#tcp-port->fileno */
((C_proc3)C_retrieve_proc(*((C_word*)lf[299]+1)))(3,*((C_word*)lf[299]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1587 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k6131 in k6096 in port->fileno in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6133,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1592 posix-error */
t2=lf[3];
f_3463(6,t2,((C_word*)t0)[3],lf[60],lf[297],lf[300],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6116,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1590 posix-error */
t4=lf[3];
f_3463(6,t4,t3,lf[48],lf[297],lf[301],((C_word*)t0)[2]);}
else{
t4=t3;
f_6116(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6114 in k6131 in k6096 in port->fileno in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6080r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6080r(t0,t1,t2,t3);}}

static void C_ccall f_6080r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6092,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1581 mode */
f_6014(t5,C_SCHEME_FALSE,t3);}

/* k6090 in open-output-file* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6092,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1581 check */
f_6051(((C_word*)t0)[2],lf[296],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6066r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6066r(t0,t1,t2,t3);}}

static void C_ccall f_6066r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[295]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6078,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1577 mode */
f_6014(t5,C_SCHEME_TRUE,t3);}

/* k6076 in open-input-file* in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6078,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1577 check */
f_6051(((C_word*)t0)[2],lf[295],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6051(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6051,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1570 posix-error */
t6=lf[3];
f_3463(6,t6,t1,lf[48],t2,lf[293],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6064,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1571 ##sys#make-port */
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[294],lf[149]);}}

/* k6062 in check in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_6014(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6014,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6022,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[287]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1564 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[288],t5);}
else{
t8=t4;
f_6022(2,t8,lf[289]);}}
else{
/* posixunix.scm: 1565 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[290],t5);}}
else{
t5=t4;
f_6022(2,t5,(C_truep(t2)?lf[291]:lf[292]));}}

/* k6020 in mode in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1560 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5989,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[281]);
t5=(C_word)C_i_check_string_2(t3,lf[281]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5970,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5970(2,t9,C_SCHEME_FALSE);}}

/* k5968 in file-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5974(2,t3,C_SCHEME_FALSE);}}

/* k5972 in k5968 in file-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1471(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1545 posix-error */
t3=lf[3];
f_3463(7,t3,((C_word*)t0)[4],lf[48],lf[282],lf[283],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5939,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[279]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5947,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5963,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1534 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5961 in read-symbolic-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1534 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5945 in read-symbolic-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5950,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1536 posix-error */
t4=lf[3];
f_3463(6,t4,t3,lf[48],lf[279],lf[280],((C_word*)t0)[2]);}
else{
t4=t3;
f_5950(2,t4,C_SCHEME_UNDEFINED);}}

/* k5948 in k5945 in read-symbolic-link in k5936 in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1537 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5901,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[275]);
t5=(C_word)C_i_check_string_2(t3,lf[275]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5922,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5934,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1522 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5932 in create-symbolic-link in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1522 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5920 in create-symbolic-link in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1523 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5928 in k5920 in create-symbolic-link in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1523 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5924 in k5920 in create-symbolic-link in k5897 in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1525 posix-error */
t3=lf[3];
f_3463(7,t3,((C_word*)t0)[4],lf[48],lf[276],lf[277],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5886,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5892,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1493 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5886(2,t4,C_SCHEME_UNDEFINED);}}

/* k5890 in create-session in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1494 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[272],lf[273]);}

/* k5884 in create-session in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5876,3,t0,t1,t2);}
/* posixunix.scm: 1488 check */
f_5840(t1,t2,C_fix((C_word)X_OK),lf[271]);}

/* file-write-access? in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5870,3,t0,t1,t2);}
/* posixunix.scm: 1487 check */
f_5840(t1,t2,C_fix((C_word)W_OK),lf[270]);}

/* file-read-access? in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5864,3,t0,t1,t2);}
/* posixunix.scm: 1486 check */
f_5840(t1,t2,C_fix((C_word)R_OK),lf[269]);}

/* check in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5840(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5840,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5858,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5862,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1483 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5860 in check in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1483 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5856 in check in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5850,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5850(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1484 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5848 in k5856 in check in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5810,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[267]);
t6=(C_word)C_i_check_exact_2(t3,lf[267]);
t7=(C_word)C_i_check_exact_2(t4,lf[267]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5834,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5838,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1473 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5836 in change-file-owner in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1473 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5832 in change-file-owner in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1474 posix-error */
t3=lf[3];
f_3463(8,t3,((C_word*)t0)[3],lf[48],lf[267],lf[268],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5783,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[265]);
t5=(C_word)C_i_check_exact_2(t3,lf[265]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5804,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5808,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1465 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5806 in change-file-mode in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1465 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5802 in change-file-mode in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1466 posix-error */
t3=lf[3];
f_3463(7,t3,((C_word*)t0)[3],lf[48],lf[265],lf[266],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5719,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[224]);
t5=(C_word)C_i_check_exact_2(t3,lf[224]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5707,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5707(2,t9,C_SCHEME_FALSE);}}

/* k5705 in initialize-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub1296(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1386 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5733 in k5705 in initialize-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1387 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[224],lf[225],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5645,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5649,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_5575(t4);
if(C_truep(t5)){
t6=t3;
f_5649(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1369 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[221],lf[223]);}}

/* k5647 in set-groups! in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5649,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5654,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5654(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop1272 in k5647 in set-groups! in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5654(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5654,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5670,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1374 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[221]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5668 in doloop1272 in k5647 in set-groups! in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1375 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[221],lf[222],((C_word*)t0)[2]);}

/* get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5582,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5586,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5640,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1355 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5586(2,t4,C_SCHEME_UNDEFINED);}}

/* k5638 in get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1356 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[220]);}

/* k5584 in get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_5575(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_5589(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1358 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[217],lf[219]);}}

/* k5587 in k5584 in get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub1231(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5621,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1360 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_5592(2,t5,C_SCHEME_UNDEFINED);}}

/* k5619 in k5587 in k5584 in get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1361 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[218]);}

/* k5590 in k5587 in k5584 in get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5592,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5597,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5597(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5590 in k5587 in k5584 in get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5597,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5611,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1365 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k5609 in loop in k5590 in k5587 in k5584 in get-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_5575(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub1237(C_SCHEME_UNDEFINED,t2));}

/* group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5489r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5489r(t0,t1,t2,t3);}}

static void C_ccall f_5489r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5493,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5493(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5493(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5496,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5496(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[215]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5547,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1329 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5545 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5496(t2,(C_word)C_getgrnam(t1));}

/* k5494 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5496,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5504 in k5494 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5510,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k5508 in k5504 in k5494 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5514,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5519,a[2]=t4,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5519(t6,t2,C_fix(0));}

/* loop in k5508 in k5504 in k5494 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5519,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1189(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5521 in loop in k5508 in k5504 in k5494 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1338 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5519(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5531 in k5521 in loop in k5508 in k5504 in k5494 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5512 in k5508 in k5504 in k5494 in k5491 in group-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5472,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1314 current-effective-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[208]+1)))(2,*((C_word*)lf[208]+1),t3);}

/* k5474 in current-effective-user-name in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1314 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[211]+1)))(3,*((C_word*)lf[211]+1),((C_word*)t0)[2],t1);}

/* k5470 in current-effective-user-name in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5458,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5462,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1311 current-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[207]+1)))(2,*((C_word*)lf[207]+1),t3);}

/* k5460 in current-user-name in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1311 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[211]+1)))(3,*((C_word*)lf[211]+1),((C_word*)t0)[2],t1);}

/* k5456 in current-user-name in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5383r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5383r(t0,t1,t2,t3);}}

static void C_ccall f_5383r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5387,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5387(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5387(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5390(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[211]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5429,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1299 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5427 in k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5390(t2,(C_word)C_getpwnam(t1));}

/* k5388 in k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5390,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5398 in k5388 in k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5404,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k5402 in k5398 in k5388 in k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5408,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k5406 in k5402 in k5398 in k5388 in k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5412,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5410 in k5406 in k5402 in k5398 in k5388 in k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5416,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k5414 in k5410 in k5406 in k5402 in k5398 in k5388 in k5385 in user-information in k5379 in k5375 in k5371 in k5367 in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5333,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5362,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1244 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_5333(2,t3,C_SCHEME_UNDEFINED);}}

/* k5360 in system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1245 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[204],lf[206]);}

/* k5331 in system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k5338 in k5331 in system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5344,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k5342 in k5338 in k5331 in system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5348,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k5346 in k5342 in k5338 in k5331 in system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5352,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k5350 in k5346 in k5342 in k5338 in k5331 in system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5356,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k5354 in k5350 in k5346 in k5342 in k5338 in k5331 in system-information in k5325 in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5356,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5311,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1223 posix-error */
t5=lf[3];
f_3463(5,t5,t1,lf[196],lf[202],lf[203]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5296,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[200]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1217 posix-error */
t5=lf[3];
f_3463(5,t5,t1,lf[196],lf[200],lf[201]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5290,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5258,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5264,a[2]=t3,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5264(t5,t1,*((C_word*)lf[191]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_5264(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5264,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1207 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5234,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[195]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5241,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5252,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5251 in set-signal-mask! in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5252,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k5239 in set-signal-mask! in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1200 posix-error */
t2=lf[3];
f_3463(5,t2,((C_word*)t0)[2],lf[196],lf[195],lf[197]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5216,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5226,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1186 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1188 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k5224 in ##sys#interrupt-hook in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1187 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5203,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[194]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k5190 in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5194,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[193]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5151,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1103 posix-error */
t3=lf[3];
f_3463(5,t3,t2,lf[48],lf[164],lf[165]);}
else{
t3=t2;
f_5151(2,t3,C_SCHEME_UNDEFINED);}}

/* k5149 in create-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1104 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5127r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5127r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5127r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[163]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5131,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5129 in with-output-to-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5131,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5137,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li71),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1091 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5136 in k5129 in with-output-to-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5137r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5137r(t0,t1,t2);}}

static void C_ccall f_5137r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5141,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1093 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5139 in a5136 in k5129 in with-output-to-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[163]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5107r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5107r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5107r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[161]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5111,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5109 in with-input-from-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5111,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5117,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1081 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5116 in k5109 in with-input-from-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5117r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5117r(t0,t1,t2);}}

static void C_ccall f_5117r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5121,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1083 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5119 in a5116 in k5109 in with-input-from-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5083r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5083r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5083r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5087,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5085 in call-with-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5092,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5098,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1071 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5097 in k5085 in call-with-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5098r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5098r(t0,t1,t2);}}

static void C_ccall f_5098r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5102,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1074 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5100 in a5097 in k5085 in call-with-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5091 in k5085 in call-with-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5092,2,t0,t1);}
/* posixunix.scm: 1072 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5059r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5059r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5059r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5063,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5061 in call-with-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5068,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5074,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1063 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5073 in k5061 in call-with-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5074r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5074r(t0,t1,t2);}}

static void C_ccall f_5074r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5078,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1066 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5076 in a5073 in k5061 in call-with-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5067 in k5061 in call-with-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5068,2,t0,t1);}
/* posixunix.scm: 1064 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5043,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1050 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[153]);}

/* k5045 in close-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5050,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1052 posix-error */
t5=lf[3];
f_3463(6,t5,t3,lf[48],lf[154],lf[155],((C_word*)t0)[3]);}
else{
t5=t3;
f_5050(2,t5,C_SCHEME_UNDEFINED);}}

/* k5048 in k5045 in close-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5007r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5007r(t0,t1,t2,t3);}}

static void C_ccall f_5007r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=f_4938(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5021,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5028,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1045 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5038,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1046 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1047 badmode */
f_4950(t6,t5);}}}

/* k5036 in open-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5038,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5021(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k5026 in open-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5021(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k5019 in open-output-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1041 check */
f_4956(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4971r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4971r(t0,t1,t2,t3);}}

static void C_ccall f_4971r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[150]);
t5=f_4938(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4985,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4992,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1034 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5002,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1035 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1036 badmode */
f_4950(t6,t5);}}}

/* k5000 in open-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4985(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4990 in open-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4985(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4983 in open-input-pipe in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1030 check */
f_4956(((C_word*)t0)[3],lf[150],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4956(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4956,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1022 posix-error */
t6=lf[3];
f_3463(6,t6,t1,lf[48],t2,lf[145],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4969,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1023 ##sys#make-port */
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[148],lf[149]);}}

/* k4967 in check in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4950(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4950,NULL,2,t1,t2);}
/* posixunix.scm: 1019 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[144],t2);}

/* mode in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_4938(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[143]));}

/* canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4621,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4628,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4742,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 967  cwd */
t8=((C_word*)t0)[6];
f_4565(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 969  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_4748(t9,C_SCHEME_FALSE);}}}

/* k4926 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 969  sep? */
t2=((C_word*)t0)[3];
f_4748(t2,f_4554(t1));}

/* k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4748,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_4628(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 972  cwd */
t5=((C_word*)t0)[8];
f_4565(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4914,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 973  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4912 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 973  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4901 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4903,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 974  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4767(t2,C_SCHEME_FALSE);}}

/* k4908 in k4901 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  sep? */
t2=((C_word*)t0)[3];
f_4767(t2,f_4554(t1));}

/* k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 976  getenv */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[140]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 981  cwd */
t5=((C_word*)t0)[6];
f_4565(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4896,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 982  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4894 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 982  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4873 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4892,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 983  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_4811(t2,C_SCHEME_FALSE);}}

/* k4890 in k4873 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 983  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4879 in k4873 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 984  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_4811(t2,C_SCHEME_FALSE);}}

/* k4886 in k4879 in k4873 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 984  sep? */
t2=((C_word*)t0)[3];
f_4811(t2,f_4554(t1));}

/* k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 985  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4872,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 986  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k4870 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4849 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4851,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4824(2,t2,C_SCHEME_FALSE);}}

/* k4866 in k4849 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 987  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4855 in k4849 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4857,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 988  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4824(2,t2,C_SCHEME_FALSE);}}

/* k4862 in k4855 in k4849 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4822 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4824,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 989  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 990  sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k4846 in k4822 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=f_4554(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_4628(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 993  cwd */
t4=((C_word*)t0)[2];
f_4565(t4,t3);}}

/* k4842 in k4846 in k4822 in k4809 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 993  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[142],((C_word*)t0)[2]);}

/* k4803 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 981  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[141],((C_word*)t0)[2]);}

/* k4772 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4777(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4792,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 977  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4790 in k4772 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k4775 in k4772 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4781,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 978  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4779 in k4775 in k4772 in k4765 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 975  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4759 in k4746 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 972  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k4740 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 967  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[137]);}

/* k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[101]+1)))(4,*((C_word*)lf[101]+1),t2,t3,lf[136]);}

/* k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li55),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4637(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4637(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4637,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 996  null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 997  null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4705,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1008 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[135],t5);}}

/* k4706 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4705(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1010 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[134],t3);}}

/* k4715 in k4706 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4705(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4705(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k4703 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1006 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4637(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4648 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[129]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 999  sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k4684 in k4648 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4686,2,t0,t1);}
t2=f_4554(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4667,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[131],((C_word*)t0)[2]);
/* posixunix.scm: 1002 reverse */
t6=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4682,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1005 reverse */
t5=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4680 in k4684 in k4648 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1005 isperse */
f_4549(((C_word*)t0)[2],t1);}

/* k4676 in k4684 in k4648 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1003 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[133],t1);}

/* k4665 in k4684 in k4648 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1002 isperse */
f_4549(((C_word*)t0)[2],t1);}

/* k4661 in k4684 in k4648 in k4642 in loop in k4633 in k4626 in canonical-path in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1000 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4565,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4572,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a4573 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4574,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4580,a[2]=t2,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4598,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t1,t3,t4);}

/* a4597 in a4573 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[3],a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[2],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4609 in a4597 in a4573 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4610r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4610r(t0,t1,t2);}}

static void C_ccall f_4610r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4616,a[2]=t2,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp);
/* k792798 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4615 in a4609 in a4597 in a4573 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4603 in a4597 in a4573 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
/* posixunix.scm: 962  cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a4579 in a4573 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4580,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4586,a[2]=t2,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
/* k792798 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4585 in a4579 in a4573 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[125]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[126]);}

/* k4570 in cwd in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_4554(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4549(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4549,NULL,2,t1,t2);}
/* string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[121]+1)))(4,*((C_word*)lf[121]+1),t1,t2,lf[122]);}

/* current-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4501r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4501r(t0,t1,t2);}}

static void C_ccall f_4501r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4505(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4505(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4503 in current-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 940  change-directory */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 941  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k4512 in k4503 in current-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 944  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 945  posix-error */
t3=lf[3];
f_3463(5,t3,((C_word*)t0)[2],lf[48],lf[113],lf[116]);}}

/* directory? in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4478,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4485,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4499,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 933  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4497 in directory? in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 933  ##sys#file-info */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4483 in directory? in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4321r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4321r(t0,t1,t2);}}

static void C_ccall f_4321r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4421,a[2]=t3,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4426,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec640697 */
t6=t5;
f_4426(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?641693 */
t8=t4;
f_4421(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body638647 */
t10=t3;
f_4323(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec640 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4426,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4434,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 906  current-directory */
t3=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4432 in def-spec640 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?641693 */
t2=((C_word*)t0)[3];
f_4421(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?641 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4421,NULL,3,t0,t1,t2);}
/* body638647 */
t3=((C_word*)t0)[2];
f_4323(t3,t1,t2,C_SCHEME_FALSE);}

/* body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4323(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4323,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[110]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 908  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 909  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 910  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 911  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4418 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 911  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4338 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4340,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 913  posix-error */
t3=lf[3];
f_3463(6,t3,((C_word*)t0)[7],lf[48],lf[110],lf[111],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li38),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4354(t6,((C_word*)t0)[7]);}}

/* loop in k4338 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4354,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 921  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k4362 in loop in k4338 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 922  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k4365 in k4362 in loop in k4338 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 923  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_4370(2,t3,C_SCHEME_FALSE);}}

/* k4368 in k4365 in k4362 in loop in k4338 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_4376(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_4376(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_4376(t4,C_SCHEME_FALSE);}}

/* k4374 in k4368 in k4365 in k4362 in loop in k4338 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_4376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4376,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 928  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4354(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 929  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4354(t3,t2);}}

/* k4384 in k4374 in k4368 in k4365 in k4362 in loop in k4338 in k4334 in k4331 in k4328 in body638 in directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4297,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4315,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4319,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 899  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4317 in delete-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 899  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4313 in delete-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 900  posix-error */
t3=lf[3];
f_3463(6,t3,((C_word*)t0)[3],lf[48],lf[106],lf[107],((C_word*)t0)[2]);}}

/* change-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4273,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4291,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4295,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 893  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4293 in change-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 893  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4289 in change-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 894  posix-error */
t3=lf[3];
f_3463(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[105],((C_word*)t0)[2]);}}

/* create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4165r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4165r(t0,t1,t2,t3);}}

static void C_ccall f_4165r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4169,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4169(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4169(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[94]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 885  canonical-path */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 886  canonical-path */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k4236 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4252,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 855  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4250 in k4236 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 856  posix-error */
t3=lf[3];
f_3463(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=lf[95];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4183,a[2]=t3,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4235,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 879  string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[101]+1)))(4,*((C_word*)lf[101]+1),t5,t1,lf[102]);}

/* k4233 in k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4182 in k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4183,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4188,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 877  string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[100],t2);}

/* k4186 in a4182 in k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4194,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4211,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 860  file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[99]+1)))(3,*((C_word*)lf[99]+1),t5,t3);}

/* k4209 in k4186 in a4182 in k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4211,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 861  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4194(2,t2,C_SCHEME_FALSE);}}

/* k4229 in k4209 in k4186 in a4182 in k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 862  posix-error */
t3=lf[3];
f_3463(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[97],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4194(2,t4,t3);}
else{
/* posixunix.scm: 865  posix-error */
t4=lf[3];
f_3463(6,t4,((C_word*)t0)[3],lf[48],lf[94],lf[98],((C_word*)t0)[2]);}}}

/* k4192 in k4186 in a4182 in k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 855  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4206 in k4192 in k4186 in a4182 in k4176 in k4167 in create-directory in k4161 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 856  posix-error */
t3=lf[3];
f_3463(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* stat-socket? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4152,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 824  ##sys#stat */
f_3975(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k4157 in stat-socket? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4143,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4150,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 819  ##sys#stat */
f_3975(t4,t2,C_SCHEME_TRUE,lf[91]);}

/* k4148 in stat-symlink? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4134,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 814  ##sys#stat */
f_3975(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k4139 in stat-fifo? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4125,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4132,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 809  ##sys#stat */
f_3975(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k4130 in stat-block-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4116,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4123,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 804  ##sys#stat */
f_3975(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k4121 in stat-char-device? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4107,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 799  ##sys#stat */
f_3975(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k4112 in stat-directory? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4098,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4105,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 794  ##sys#stat */
f_3975(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k4103 in stat-regular? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4089,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4096,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 789  ##sys#stat */
f_3975(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k4094 in symbolic-link? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4080,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4087,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 784  ##sys#stat */
f_3975(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k4085 in regular-file? in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4074,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4078,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_3975(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k4076 in file-permissions in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4068,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4072,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_3975(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k4070 in file-owner in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4062,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_3975(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k4064 in file-change-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4056,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4060,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_3975(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k4058 in file-access-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4050,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_3975(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k4052 in file-modification-time in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4044,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 775  ##sys#stat */
f_3975(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k4046 in file-size in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4012r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4012r(t0,t1,t2,t3);}}

static void C_ccall f_4012r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4023,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_4023(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4023(2,t7,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k4021 in file-stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 768  ##sys#stat */
f_3975(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k4014 in file-stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3975(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3975,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3979,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3979(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4000,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 759  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 763  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k4005 in ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 759  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3998 in ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3979(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3977 in ##sys#stat in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 765  posix-error */
t2=lf[3];
f_3463(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3783r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3783r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3783r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_3757(C_fix(0));
t10=f_3757(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3799,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_3799(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 688  fd_set */
t14=t12;
f_3799(2,t14,f_3763(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a3955 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3956,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 695  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3763(C_fix(0),t2));}

/* k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3805(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 700  fd_set */
t5=t3;
f_3805(2,t5,f_3763(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a3929 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3930,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 707  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3763(C_fix(1),t2));}

/* k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_3808(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_3808(t4,(C_word)C_C_select(t3));}}

/* k3806 in k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3808,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 714  posix-error */
t2=lf[3];
f_3463(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 715  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 720  fd_test */
t4=t3;
f_3847(t4,f_3773(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3890,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_3847(t4,C_SCHEME_FALSE);}}}}

/* a3889 in k3806 in k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3890,3,t0,t1,t2);}
t3=f_3773(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3886 in k3806 in k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3847(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3845 in k3806 in k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3847,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3851,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 726  fd_test */
t3=t2;
f_3851(t3,f_3773(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3863,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3865,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_3851(t3,C_SCHEME_FALSE);}}

/* a3864 in k3845 in k3806 in k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3865,3,t0,t1,t2);}
t3=f_3773(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3861 in k3845 in k3806 in k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3851(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3849 in k3845 in k3806 in k3803 in k3797 in file-select in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_fcall f_3851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 717  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_3773(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub252(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_3763(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub245(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static C_word C_fcall f_3757(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub239(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3725,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3732,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 666  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3730 in file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3738,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 670  posix-error */
t6=lf[3];
f_3463(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_3738(2,t6,C_SCHEME_UNDEFINED);}}

/* k3736 in k3730 in file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3745,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 671  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k3743 in k3736 in k3730 in file-mkstemp in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 671  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3686r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3686r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3686r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3693,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_3693(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 655  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k3691 in file-write in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3702,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 660  posix-error */
t8=lf[3];
f_3463(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_3702(2,t8,C_SCHEME_UNDEFINED);}}

/* k3700 in k3691 in file-write in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3644r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3644r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3644r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3654,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_3654(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 643  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k3652 in file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_3657(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 645  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k3655 in k3652 in file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3660,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 648  posix-error */
t5=lf[3];
f_3463(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_3660(2,t5,C_SCHEME_UNDEFINED);}}

/* k3658 in k3655 in k3652 in file-read in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3629,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 636  posix-error */
t4=lf[3];
f_3463(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3591r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3591r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3591r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3608,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3621,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 627  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k3619 in file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 627  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3606 in file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3608,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3611,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 629  posix-error */
t5=lf[3];
f_3463(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_3611(2,t5,C_SCHEME_UNDEFINED);}}

/* k3609 in k3606 in file-open in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3545r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3545r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3545r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3549,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3549(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3549(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3547 in file-control in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub124(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 617  posix-error */
t11=lf[3];
f_3463(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3488,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub46(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3481,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub40(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_3463r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3463r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3463r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3467,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 507  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3465 in posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k3476 in k3465 in posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 508  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k3472 in k3465 in posix-error in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[618] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_3433:posixunix_scm",(void*)f_3433},
{"f_3436:posixunix_scm",(void*)f_3436},
{"f_3439:posixunix_scm",(void*)f_3439},
{"f_3442:posixunix_scm",(void*)f_3442},
{"f_3445:posixunix_scm",(void*)f_3445},
{"f_3448:posixunix_scm",(void*)f_3448},
{"f_3451:posixunix_scm",(void*)f_3451},
{"f_9306:posixunix_scm",(void*)f_9306},
{"f_9319:posixunix_scm",(void*)f_9319},
{"f_9331:posixunix_scm",(void*)f_9331},
{"f_9325:posixunix_scm",(void*)f_9325},
{"f_9269:posixunix_scm",(void*)f_9269},
{"f_9285:posixunix_scm",(void*)f_9285},
{"f_9273:posixunix_scm",(void*)f_9273},
{"f_9276:posixunix_scm",(void*)f_9276},
{"f_4163:posixunix_scm",(void*)f_4163},
{"f_5192:posixunix_scm",(void*)f_5192},
{"f_9263:posixunix_scm",(void*)f_9263},
{"f_5327:posixunix_scm",(void*)f_5327},
{"f_9248:posixunix_scm",(void*)f_9248},
{"f_9258:posixunix_scm",(void*)f_9258},
{"f_9245:posixunix_scm",(void*)f_9245},
{"f_5369:posixunix_scm",(void*)f_5369},
{"f_9230:posixunix_scm",(void*)f_9230},
{"f_9240:posixunix_scm",(void*)f_9240},
{"f_9227:posixunix_scm",(void*)f_9227},
{"f_5373:posixunix_scm",(void*)f_5373},
{"f_9212:posixunix_scm",(void*)f_9212},
{"f_9222:posixunix_scm",(void*)f_9222},
{"f_9209:posixunix_scm",(void*)f_9209},
{"f_5377:posixunix_scm",(void*)f_5377},
{"f_9194:posixunix_scm",(void*)f_9194},
{"f_9204:posixunix_scm",(void*)f_9204},
{"f_9191:posixunix_scm",(void*)f_9191},
{"f_5381:posixunix_scm",(void*)f_5381},
{"f_9170:posixunix_scm",(void*)f_9170},
{"f_9186:posixunix_scm",(void*)f_9186},
{"f_9152:posixunix_scm",(void*)f_9152},
{"f_9165:posixunix_scm",(void*)f_9165},
{"f_9159:posixunix_scm",(void*)f_9159},
{"f_5899:posixunix_scm",(void*)f_5899},
{"f_5938:posixunix_scm",(void*)f_5938},
{"f_9129:posixunix_scm",(void*)f_9129},
{"f_9121:posixunix_scm",(void*)f_9121},
{"f_8870:posixunix_scm",(void*)f_8870},
{"f_9047:posixunix_scm",(void*)f_9047},
{"f_9053:posixunix_scm",(void*)f_9053},
{"f_9042:posixunix_scm",(void*)f_9042},
{"f_9037:posixunix_scm",(void*)f_9037},
{"f_8872:posixunix_scm",(void*)f_8872},
{"f_9024:posixunix_scm",(void*)f_9024},
{"f_9032:posixunix_scm",(void*)f_9032},
{"f_8879:posixunix_scm",(void*)f_8879},
{"f_9012:posixunix_scm",(void*)f_9012},
{"f_9006:posixunix_scm",(void*)f_9006},
{"f_8889:posixunix_scm",(void*)f_8889},
{"f_8891:posixunix_scm",(void*)f_8891},
{"f_8910:posixunix_scm",(void*)f_8910},
{"f_8992:posixunix_scm",(void*)f_8992},
{"f_8999:posixunix_scm",(void*)f_8999},
{"f_8986:posixunix_scm",(void*)f_8986},
{"f_8925:posixunix_scm",(void*)f_8925},
{"f_8979:posixunix_scm",(void*)f_8979},
{"f_8976:posixunix_scm",(void*)f_8976},
{"f_8966:posixunix_scm",(void*)f_8966},
{"f_8942:posixunix_scm",(void*)f_8942},
{"f_8964:posixunix_scm",(void*)f_8964},
{"f_8950:posixunix_scm",(void*)f_8950},
{"f_8957:posixunix_scm",(void*)f_8957},
{"f_8954:posixunix_scm",(void*)f_8954},
{"f_8937:posixunix_scm",(void*)f_8937},
{"f_8935:posixunix_scm",(void*)f_8935},
{"f_9013:posixunix_scm",(void*)f_9013},
{"f_8810:posixunix_scm",(void*)f_8810},
{"f_8822:posixunix_scm",(void*)f_8822},
{"f_8817:posixunix_scm",(void*)f_8817},
{"f_8812:posixunix_scm",(void*)f_8812},
{"f_8750:posixunix_scm",(void*)f_8750},
{"f_8762:posixunix_scm",(void*)f_8762},
{"f_8757:posixunix_scm",(void*)f_8757},
{"f_8752:posixunix_scm",(void*)f_8752},
{"f_8689:posixunix_scm",(void*)f_8689},
{"f_8744:posixunix_scm",(void*)f_8744},
{"f_8748:posixunix_scm",(void*)f_8748},
{"f_8710:posixunix_scm",(void*)f_8710},
{"f_8713:posixunix_scm",(void*)f_8713},
{"f_8724:posixunix_scm",(void*)f_8724},
{"f_8718:posixunix_scm",(void*)f_8718},
{"f_8691:posixunix_scm",(void*)f_8691},
{"f_8700:posixunix_scm",(void*)f_8700},
{"f_8631:posixunix_scm",(void*)f_8631},
{"f_8643:posixunix_scm",(void*)f_8643},
{"f_8674:posixunix_scm",(void*)f_8674},
{"f_8654:posixunix_scm",(void*)f_8654},
{"f_8670:posixunix_scm",(void*)f_8670},
{"f_8658:posixunix_scm",(void*)f_8658},
{"f_8666:posixunix_scm",(void*)f_8666},
{"f_8662:posixunix_scm",(void*)f_8662},
{"f_8637:posixunix_scm",(void*)f_8637},
{"f_8620:posixunix_scm",(void*)f_8620},
{"f_8624:posixunix_scm",(void*)f_8624},
{"f_8609:posixunix_scm",(void*)f_8609},
{"f_8613:posixunix_scm",(void*)f_8613},
{"f_8564:posixunix_scm",(void*)f_8564},
{"f_8568:posixunix_scm",(void*)f_8568},
{"f_8571:posixunix_scm",(void*)f_8571},
{"f_8574:posixunix_scm",(void*)f_8574},
{"f_8587:posixunix_scm",(void*)f_8587},
{"f_8591:posixunix_scm",(void*)f_8591},
{"f_8594:posixunix_scm",(void*)f_8594},
{"f_8597:posixunix_scm",(void*)f_8597},
{"f_8585:posixunix_scm",(void*)f_8585},
{"f_8548:posixunix_scm",(void*)f_8548},
{"f_8531:posixunix_scm",(void*)f_8531},
{"f_8544:posixunix_scm",(void*)f_8544},
{"f_8456:posixunix_scm",(void*)f_8456},
{"f_8517:posixunix_scm",(void*)f_8517},
{"f_8530:posixunix_scm",(void*)f_8530},
{"f_8497:posixunix_scm",(void*)f_8497},
{"f_8512:posixunix_scm",(void*)f_8512},
{"f_8506:posixunix_scm",(void*)f_8506},
{"f_8460:posixunix_scm",(void*)f_8460},
{"f_8462:posixunix_scm",(void*)f_8462},
{"f_8483:posixunix_scm",(void*)f_8483},
{"f_8477:posixunix_scm",(void*)f_8477},
{"f_8404:posixunix_scm",(void*)f_8404},
{"f_8411:posixunix_scm",(void*)f_8411},
{"f_8430:posixunix_scm",(void*)f_8430},
{"f_8434:posixunix_scm",(void*)f_8434},
{"f_8398:posixunix_scm",(void*)f_8398},
{"f_8389:posixunix_scm",(void*)f_8389},
{"f_8393:posixunix_scm",(void*)f_8393},
{"f_8362:posixunix_scm",(void*)f_8362},
{"f_8355:posixunix_scm",(void*)f_8355},
{"f_8352:posixunix_scm",(void*)f_8352},
{"f_8349:posixunix_scm",(void*)f_8349},
{"f_8271:posixunix_scm",(void*)f_8271},
{"f_8307:posixunix_scm",(void*)f_8307},
{"f_8301:posixunix_scm",(void*)f_8301},
{"f_8254:posixunix_scm",(void*)f_8254},
{"f_8072:posixunix_scm",(void*)f_8072},
{"f_8206:posixunix_scm",(void*)f_8206},
{"f_8201:posixunix_scm",(void*)f_8201},
{"f_8074:posixunix_scm",(void*)f_8074},
{"f_8084:posixunix_scm",(void*)f_8084},
{"f_8092:posixunix_scm",(void*)f_8092},
{"f_8138:posixunix_scm",(void*)f_8138},
{"f_8105:posixunix_scm",(void*)f_8105},
{"f_8130:posixunix_scm",(void*)f_8130},
{"f_8108:posixunix_scm",(void*)f_8108},
{"f_8053:posixunix_scm",(void*)f_8053},
{"f_8034:posixunix_scm",(void*)f_8034},
{"f_7992:posixunix_scm",(void*)f_7992},
{"f_8014:posixunix_scm",(void*)f_8014},
{"f_8018:posixunix_scm",(void*)f_8018},
{"f_7883:posixunix_scm",(void*)f_7883},
{"f_7889:posixunix_scm",(void*)f_7889},
{"f_7910:posixunix_scm",(void*)f_7910},
{"f_7984:posixunix_scm",(void*)f_7984},
{"f_7914:posixunix_scm",(void*)f_7914},
{"f_7917:posixunix_scm",(void*)f_7917},
{"f_7924:posixunix_scm",(void*)f_7924},
{"f_7926:posixunix_scm",(void*)f_7926},
{"f_7943:posixunix_scm",(void*)f_7943},
{"f_7953:posixunix_scm",(void*)f_7953},
{"f_7957:posixunix_scm",(void*)f_7957},
{"f_7904:posixunix_scm",(void*)f_7904},
{"f_7871:posixunix_scm",(void*)f_7871},
{"f_7875:posixunix_scm",(void*)f_7875},
{"f_7878:posixunix_scm",(void*)f_7878},
{"f_7836:posixunix_scm",(void*)f_7836},
{"f_7840:posixunix_scm",(void*)f_7840},
{"f_7860:posixunix_scm",(void*)f_7860},
{"f_7864:posixunix_scm",(void*)f_7864},
{"f_7813:posixunix_scm",(void*)f_7813},
{"f_7817:posixunix_scm",(void*)f_7817},
{"f_7781:posixunix_scm",(void*)f_7781},
{"f_7785:posixunix_scm",(void*)f_7785},
{"f_7762:posixunix_scm",(void*)f_7762},
{"f_7766:posixunix_scm",(void*)f_7766},
{"f_7769:posixunix_scm",(void*)f_7769},
{"f_7703:posixunix_scm",(void*)f_7703},
{"f_7707:posixunix_scm",(void*)f_7707},
{"f_7713:posixunix_scm",(void*)f_7713},
{"f_7696:posixunix_scm",(void*)f_7696},
{"f_7680:posixunix_scm",(void*)f_7680},
{"f_7668:posixunix_scm",(void*)f_7668},
{"f_7653:posixunix_scm",(void*)f_7653},
{"f_7657:posixunix_scm",(void*)f_7657},
{"f_7638:posixunix_scm",(void*)f_7638},
{"f_7642:posixunix_scm",(void*)f_7642},
{"f_7592:posixunix_scm",(void*)f_7592},
{"f_7596:posixunix_scm",(void*)f_7596},
{"f_7609:posixunix_scm",(void*)f_7609},
{"f_7613:posixunix_scm",(void*)f_7613},
{"f_7523:posixunix_scm",(void*)f_7523},
{"f_7527:posixunix_scm",(void*)f_7527},
{"f_7530:posixunix_scm",(void*)f_7530},
{"f_7552:posixunix_scm",(void*)f_7552},
{"f_7549:posixunix_scm",(void*)f_7549},
{"f_7539:posixunix_scm",(void*)f_7539},
{"f_7487:posixunix_scm",(void*)f_7487},
{"f_7494:posixunix_scm",(void*)f_7494},
{"f_7468:posixunix_scm",(void*)f_7468},
{"f_7459:posixunix_scm",(void*)f_7459},
{"f_7440:posixunix_scm",(void*)f_7440},
{"f_7434:posixunix_scm",(void*)f_7434},
{"f_7425:posixunix_scm",(void*)f_7425},
{"f_7390:posixunix_scm",(void*)f_7390},
{"f_7328:posixunix_scm",(void*)f_7328},
{"f_7332:posixunix_scm",(void*)f_7332},
{"f_7338:posixunix_scm",(void*)f_7338},
{"f_7357:posixunix_scm",(void*)f_7357},
{"f_7344:posixunix_scm",(void*)f_7344},
{"f_7224:posixunix_scm",(void*)f_7224},
{"f_7230:posixunix_scm",(void*)f_7230},
{"f_7234:posixunix_scm",(void*)f_7234},
{"f_7242:posixunix_scm",(void*)f_7242},
{"f_7268:posixunix_scm",(void*)f_7268},
{"f_7272:posixunix_scm",(void*)f_7272},
{"f_7260:posixunix_scm",(void*)f_7260},
{"f_7204:posixunix_scm",(void*)f_7204},
{"f_7212:posixunix_scm",(void*)f_7212},
{"f_7187:posixunix_scm",(void*)f_7187},
{"f_7198:posixunix_scm",(void*)f_7198},
{"f_7202:posixunix_scm",(void*)f_7202},
{"f_7161:posixunix_scm",(void*)f_7161},
{"f_7185:posixunix_scm",(void*)f_7185},
{"f_7168:posixunix_scm",(void*)f_7168},
{"f_7118:posixunix_scm",(void*)f_7118},
{"f_7125:posixunix_scm",(void*)f_7125},
{"f_7146:posixunix_scm",(void*)f_7146},
{"f_7142:posixunix_scm",(void*)f_7142},
{"f_7090:posixunix_scm",(void*)f_7090},
{"f_7068:posixunix_scm",(void*)f_7068},
{"f_7072:posixunix_scm",(void*)f_7072},
{"f_7053:posixunix_scm",(void*)f_7053},
{"f_7057:posixunix_scm",(void*)f_7057},
{"f_7038:posixunix_scm",(void*)f_7038},
{"f_7042:posixunix_scm",(void*)f_7042},
{"f_7020:posixunix_scm",(void*)f_7020},
{"f_6946:posixunix_scm",(void*)f_6946},
{"f_6968:posixunix_scm",(void*)f_6968},
{"f_6974:posixunix_scm",(void*)f_6974},
{"f_6907:posixunix_scm",(void*)f_6907},
{"f_6935:posixunix_scm",(void*)f_6935},
{"f_6931:posixunix_scm",(void*)f_6931},
{"f_6924:posixunix_scm",(void*)f_6924},
{"f_6648:posixunix_scm",(void*)f_6648},
{"f_6844:posixunix_scm",(void*)f_6844},
{"f_6839:posixunix_scm",(void*)f_6839},
{"f_6834:posixunix_scm",(void*)f_6834},
{"f_6650:posixunix_scm",(void*)f_6650},
{"f_6654:posixunix_scm",(void*)f_6654},
{"f_6760:posixunix_scm",(void*)f_6760},
{"f_6761:posixunix_scm",(void*)f_6761},
{"f_6778:posixunix_scm",(void*)f_6778},
{"f_6788:posixunix_scm",(void*)f_6788},
{"f_6746:posixunix_scm",(void*)f_6746},
{"f_6702:posixunix_scm",(void*)f_6702},
{"f_6738:posixunix_scm",(void*)f_6738},
{"f_6717:posixunix_scm",(void*)f_6717},
{"f_6727:posixunix_scm",(void*)f_6727},
{"f_6711:posixunix_scm",(void*)f_6711},
{"f_6706:posixunix_scm",(void*)f_6706},
{"f_6709:posixunix_scm",(void*)f_6709},
{"f_6656:posixunix_scm",(void*)f_6656},
{"f_6691:posixunix_scm",(void*)f_6691},
{"f_6672:posixunix_scm",(void*)f_6672},
{"f_6166:posixunix_scm",(void*)f_6166},
{"f_6570:posixunix_scm",(void*)f_6570},
{"f_6565:posixunix_scm",(void*)f_6565},
{"f_6560:posixunix_scm",(void*)f_6560},
{"f_6555:posixunix_scm",(void*)f_6555},
{"f_6168:posixunix_scm",(void*)f_6168},
{"f_6172:posixunix_scm",(void*)f_6172},
{"f_6178:posixunix_scm",(void*)f_6178},
{"f_6428:posixunix_scm",(void*)f_6428},
{"f_6434:posixunix_scm",(void*)f_6434},
{"f_6530:posixunix_scm",(void*)f_6530},
{"f_6520:posixunix_scm",(void*)f_6520},
{"f_6514:posixunix_scm",(void*)f_6514},
{"f_6436:posixunix_scm",(void*)f_6436},
{"f_6486:posixunix_scm",(void*)f_6486},
{"f_6443:posixunix_scm",(void*)f_6443},
{"f_6453:posixunix_scm",(void*)f_6453},
{"f_6352:posixunix_scm",(void*)f_6352},
{"f_6360:posixunix_scm",(void*)f_6360},
{"f_6362:posixunix_scm",(void*)f_6362},
{"f_6410:posixunix_scm",(void*)f_6410},
{"f_6343:posixunix_scm",(void*)f_6343},
{"f_6347:posixunix_scm",(void*)f_6347},
{"f_6322:posixunix_scm",(void*)f_6322},
{"f_6332:posixunix_scm",(void*)f_6332},
{"f_6310:posixunix_scm",(void*)f_6310},
{"f_6297:posixunix_scm",(void*)f_6297},
{"f_6301:posixunix_scm",(void*)f_6301},
{"f_6292:posixunix_scm",(void*)f_6292},
{"f_6295:posixunix_scm",(void*)f_6295},
{"f_6210:posixunix_scm",(void*)f_6210},
{"f_6222:posixunix_scm",(void*)f_6222},
{"f_6259:posixunix_scm",(void*)f_6259},
{"f_6268:posixunix_scm",(void*)f_6268},
{"f_6262:posixunix_scm",(void*)f_6262},
{"f_6238:posixunix_scm",(void*)f_6238},
{"f_6241:posixunix_scm",(void*)f_6241},
{"f_6202:posixunix_scm",(void*)f_6202},
{"f_6179:posixunix_scm",(void*)f_6179},
{"f_6183:posixunix_scm",(void*)f_6183},
{"f_6139:posixunix_scm",(void*)f_6139},
{"f_6146:posixunix_scm",(void*)f_6146},
{"f_6149:posixunix_scm",(void*)f_6149},
{"f_6094:posixunix_scm",(void*)f_6094},
{"f_6098:posixunix_scm",(void*)f_6098},
{"f_6133:posixunix_scm",(void*)f_6133},
{"f_6116:posixunix_scm",(void*)f_6116},
{"f_6080:posixunix_scm",(void*)f_6080},
{"f_6092:posixunix_scm",(void*)f_6092},
{"f_6066:posixunix_scm",(void*)f_6066},
{"f_6078:posixunix_scm",(void*)f_6078},
{"f_6051:posixunix_scm",(void*)f_6051},
{"f_6064:posixunix_scm",(void*)f_6064},
{"f_6014:posixunix_scm",(void*)f_6014},
{"f_6022:posixunix_scm",(void*)f_6022},
{"f_5989:posixunix_scm",(void*)f_5989},
{"f_5970:posixunix_scm",(void*)f_5970},
{"f_5974:posixunix_scm",(void*)f_5974},
{"f_5939:posixunix_scm",(void*)f_5939},
{"f_5963:posixunix_scm",(void*)f_5963},
{"f_5947:posixunix_scm",(void*)f_5947},
{"f_5950:posixunix_scm",(void*)f_5950},
{"f_5901:posixunix_scm",(void*)f_5901},
{"f_5934:posixunix_scm",(void*)f_5934},
{"f_5922:posixunix_scm",(void*)f_5922},
{"f_5930:posixunix_scm",(void*)f_5930},
{"f_5926:posixunix_scm",(void*)f_5926},
{"f_5882:posixunix_scm",(void*)f_5882},
{"f_5892:posixunix_scm",(void*)f_5892},
{"f_5886:posixunix_scm",(void*)f_5886},
{"f_5876:posixunix_scm",(void*)f_5876},
{"f_5870:posixunix_scm",(void*)f_5870},
{"f_5864:posixunix_scm",(void*)f_5864},
{"f_5840:posixunix_scm",(void*)f_5840},
{"f_5862:posixunix_scm",(void*)f_5862},
{"f_5858:posixunix_scm",(void*)f_5858},
{"f_5850:posixunix_scm",(void*)f_5850},
{"f_5810:posixunix_scm",(void*)f_5810},
{"f_5838:posixunix_scm",(void*)f_5838},
{"f_5834:posixunix_scm",(void*)f_5834},
{"f_5783:posixunix_scm",(void*)f_5783},
{"f_5808:posixunix_scm",(void*)f_5808},
{"f_5804:posixunix_scm",(void*)f_5804},
{"f_5719:posixunix_scm",(void*)f_5719},
{"f_5707:posixunix_scm",(void*)f_5707},
{"f_5735:posixunix_scm",(void*)f_5735},
{"f_5645:posixunix_scm",(void*)f_5645},
{"f_5649:posixunix_scm",(void*)f_5649},
{"f_5654:posixunix_scm",(void*)f_5654},
{"f_5670:posixunix_scm",(void*)f_5670},
{"f_5582:posixunix_scm",(void*)f_5582},
{"f_5640:posixunix_scm",(void*)f_5640},
{"f_5586:posixunix_scm",(void*)f_5586},
{"f_5589:posixunix_scm",(void*)f_5589},
{"f_5621:posixunix_scm",(void*)f_5621},
{"f_5592:posixunix_scm",(void*)f_5592},
{"f_5597:posixunix_scm",(void*)f_5597},
{"f_5611:posixunix_scm",(void*)f_5611},
{"f_5575:posixunix_scm",(void*)f_5575},
{"f_5489:posixunix_scm",(void*)f_5489},
{"f_5493:posixunix_scm",(void*)f_5493},
{"f_5547:posixunix_scm",(void*)f_5547},
{"f_5496:posixunix_scm",(void*)f_5496},
{"f_5506:posixunix_scm",(void*)f_5506},
{"f_5510:posixunix_scm",(void*)f_5510},
{"f_5519:posixunix_scm",(void*)f_5519},
{"f_5523:posixunix_scm",(void*)f_5523},
{"f_5533:posixunix_scm",(void*)f_5533},
{"f_5514:posixunix_scm",(void*)f_5514},
{"f_5464:posixunix_scm",(void*)f_5464},
{"f_5476:posixunix_scm",(void*)f_5476},
{"f_5472:posixunix_scm",(void*)f_5472},
{"f_5450:posixunix_scm",(void*)f_5450},
{"f_5462:posixunix_scm",(void*)f_5462},
{"f_5458:posixunix_scm",(void*)f_5458},
{"f_5383:posixunix_scm",(void*)f_5383},
{"f_5387:posixunix_scm",(void*)f_5387},
{"f_5429:posixunix_scm",(void*)f_5429},
{"f_5390:posixunix_scm",(void*)f_5390},
{"f_5400:posixunix_scm",(void*)f_5400},
{"f_5404:posixunix_scm",(void*)f_5404},
{"f_5408:posixunix_scm",(void*)f_5408},
{"f_5412:posixunix_scm",(void*)f_5412},
{"f_5416:posixunix_scm",(void*)f_5416},
{"f_5329:posixunix_scm",(void*)f_5329},
{"f_5362:posixunix_scm",(void*)f_5362},
{"f_5333:posixunix_scm",(void*)f_5333},
{"f_5340:posixunix_scm",(void*)f_5340},
{"f_5344:posixunix_scm",(void*)f_5344},
{"f_5348:posixunix_scm",(void*)f_5348},
{"f_5352:posixunix_scm",(void*)f_5352},
{"f_5356:posixunix_scm",(void*)f_5356},
{"f_5311:posixunix_scm",(void*)f_5311},
{"f_5296:posixunix_scm",(void*)f_5296},
{"f_5290:posixunix_scm",(void*)f_5290},
{"f_5258:posixunix_scm",(void*)f_5258},
{"f_5264:posixunix_scm",(void*)f_5264},
{"f_5234:posixunix_scm",(void*)f_5234},
{"f_5252:posixunix_scm",(void*)f_5252},
{"f_5241:posixunix_scm",(void*)f_5241},
{"f_5216:posixunix_scm",(void*)f_5216},
{"f_5226:posixunix_scm",(void*)f_5226},
{"f_5203:posixunix_scm",(void*)f_5203},
{"f_5194:posixunix_scm",(void*)f_5194},
{"f_5147:posixunix_scm",(void*)f_5147},
{"f_5151:posixunix_scm",(void*)f_5151},
{"f_5127:posixunix_scm",(void*)f_5127},
{"f_5131:posixunix_scm",(void*)f_5131},
{"f_5137:posixunix_scm",(void*)f_5137},
{"f_5141:posixunix_scm",(void*)f_5141},
{"f_5107:posixunix_scm",(void*)f_5107},
{"f_5111:posixunix_scm",(void*)f_5111},
{"f_5117:posixunix_scm",(void*)f_5117},
{"f_5121:posixunix_scm",(void*)f_5121},
{"f_5083:posixunix_scm",(void*)f_5083},
{"f_5087:posixunix_scm",(void*)f_5087},
{"f_5098:posixunix_scm",(void*)f_5098},
{"f_5102:posixunix_scm",(void*)f_5102},
{"f_5092:posixunix_scm",(void*)f_5092},
{"f_5059:posixunix_scm",(void*)f_5059},
{"f_5063:posixunix_scm",(void*)f_5063},
{"f_5074:posixunix_scm",(void*)f_5074},
{"f_5078:posixunix_scm",(void*)f_5078},
{"f_5068:posixunix_scm",(void*)f_5068},
{"f_5043:posixunix_scm",(void*)f_5043},
{"f_5047:posixunix_scm",(void*)f_5047},
{"f_5050:posixunix_scm",(void*)f_5050},
{"f_5007:posixunix_scm",(void*)f_5007},
{"f_5038:posixunix_scm",(void*)f_5038},
{"f_5028:posixunix_scm",(void*)f_5028},
{"f_5021:posixunix_scm",(void*)f_5021},
{"f_4971:posixunix_scm",(void*)f_4971},
{"f_5002:posixunix_scm",(void*)f_5002},
{"f_4992:posixunix_scm",(void*)f_4992},
{"f_4985:posixunix_scm",(void*)f_4985},
{"f_4956:posixunix_scm",(void*)f_4956},
{"f_4969:posixunix_scm",(void*)f_4969},
{"f_4950:posixunix_scm",(void*)f_4950},
{"f_4938:posixunix_scm",(void*)f_4938},
{"f_4621:posixunix_scm",(void*)f_4621},
{"f_4928:posixunix_scm",(void*)f_4928},
{"f_4748:posixunix_scm",(void*)f_4748},
{"f_4914:posixunix_scm",(void*)f_4914},
{"f_4903:posixunix_scm",(void*)f_4903},
{"f_4910:posixunix_scm",(void*)f_4910},
{"f_4767:posixunix_scm",(void*)f_4767},
{"f_4896:posixunix_scm",(void*)f_4896},
{"f_4875:posixunix_scm",(void*)f_4875},
{"f_4892:posixunix_scm",(void*)f_4892},
{"f_4881:posixunix_scm",(void*)f_4881},
{"f_4888:posixunix_scm",(void*)f_4888},
{"f_4811:posixunix_scm",(void*)f_4811},
{"f_4872:posixunix_scm",(void*)f_4872},
{"f_4851:posixunix_scm",(void*)f_4851},
{"f_4868:posixunix_scm",(void*)f_4868},
{"f_4857:posixunix_scm",(void*)f_4857},
{"f_4864:posixunix_scm",(void*)f_4864},
{"f_4824:posixunix_scm",(void*)f_4824},
{"f_4848:posixunix_scm",(void*)f_4848},
{"f_4844:posixunix_scm",(void*)f_4844},
{"f_4805:posixunix_scm",(void*)f_4805},
{"f_4774:posixunix_scm",(void*)f_4774},
{"f_4792:posixunix_scm",(void*)f_4792},
{"f_4777:posixunix_scm",(void*)f_4777},
{"f_4781:posixunix_scm",(void*)f_4781},
{"f_4761:posixunix_scm",(void*)f_4761},
{"f_4742:posixunix_scm",(void*)f_4742},
{"f_4628:posixunix_scm",(void*)f_4628},
{"f_4635:posixunix_scm",(void*)f_4635},
{"f_4637:posixunix_scm",(void*)f_4637},
{"f_4644:posixunix_scm",(void*)f_4644},
{"f_4708:posixunix_scm",(void*)f_4708},
{"f_4717:posixunix_scm",(void*)f_4717},
{"f_4705:posixunix_scm",(void*)f_4705},
{"f_4650:posixunix_scm",(void*)f_4650},
{"f_4686:posixunix_scm",(void*)f_4686},
{"f_4682:posixunix_scm",(void*)f_4682},
{"f_4678:posixunix_scm",(void*)f_4678},
{"f_4667:posixunix_scm",(void*)f_4667},
{"f_4663:posixunix_scm",(void*)f_4663},
{"f_4565:posixunix_scm",(void*)f_4565},
{"f_4574:posixunix_scm",(void*)f_4574},
{"f_4598:posixunix_scm",(void*)f_4598},
{"f_4610:posixunix_scm",(void*)f_4610},
{"f_4616:posixunix_scm",(void*)f_4616},
{"f_4604:posixunix_scm",(void*)f_4604},
{"f_4580:posixunix_scm",(void*)f_4580},
{"f_4586:posixunix_scm",(void*)f_4586},
{"f_4572:posixunix_scm",(void*)f_4572},
{"f_4554:posixunix_scm",(void*)f_4554},
{"f_4549:posixunix_scm",(void*)f_4549},
{"f_4501:posixunix_scm",(void*)f_4501},
{"f_4505:posixunix_scm",(void*)f_4505},
{"f_4514:posixunix_scm",(void*)f_4514},
{"f_4478:posixunix_scm",(void*)f_4478},
{"f_4499:posixunix_scm",(void*)f_4499},
{"f_4485:posixunix_scm",(void*)f_4485},
{"f_4321:posixunix_scm",(void*)f_4321},
{"f_4426:posixunix_scm",(void*)f_4426},
{"f_4434:posixunix_scm",(void*)f_4434},
{"f_4421:posixunix_scm",(void*)f_4421},
{"f_4323:posixunix_scm",(void*)f_4323},
{"f_4330:posixunix_scm",(void*)f_4330},
{"f_4333:posixunix_scm",(void*)f_4333},
{"f_4336:posixunix_scm",(void*)f_4336},
{"f_4420:posixunix_scm",(void*)f_4420},
{"f_4340:posixunix_scm",(void*)f_4340},
{"f_4354:posixunix_scm",(void*)f_4354},
{"f_4364:posixunix_scm",(void*)f_4364},
{"f_4367:posixunix_scm",(void*)f_4367},
{"f_4370:posixunix_scm",(void*)f_4370},
{"f_4376:posixunix_scm",(void*)f_4376},
{"f_4386:posixunix_scm",(void*)f_4386},
{"f_4297:posixunix_scm",(void*)f_4297},
{"f_4319:posixunix_scm",(void*)f_4319},
{"f_4315:posixunix_scm",(void*)f_4315},
{"f_4273:posixunix_scm",(void*)f_4273},
{"f_4295:posixunix_scm",(void*)f_4295},
{"f_4291:posixunix_scm",(void*)f_4291},
{"f_4165:posixunix_scm",(void*)f_4165},
{"f_4169:posixunix_scm",(void*)f_4169},
{"f_4238:posixunix_scm",(void*)f_4238},
{"f_4252:posixunix_scm",(void*)f_4252},
{"f_4178:posixunix_scm",(void*)f_4178},
{"f_4235:posixunix_scm",(void*)f_4235},
{"f_4183:posixunix_scm",(void*)f_4183},
{"f_4188:posixunix_scm",(void*)f_4188},
{"f_4211:posixunix_scm",(void*)f_4211},
{"f_4231:posixunix_scm",(void*)f_4231},
{"f_4194:posixunix_scm",(void*)f_4194},
{"f_4208:posixunix_scm",(void*)f_4208},
{"f_4152:posixunix_scm",(void*)f_4152},
{"f_4159:posixunix_scm",(void*)f_4159},
{"f_4143:posixunix_scm",(void*)f_4143},
{"f_4150:posixunix_scm",(void*)f_4150},
{"f_4134:posixunix_scm",(void*)f_4134},
{"f_4141:posixunix_scm",(void*)f_4141},
{"f_4125:posixunix_scm",(void*)f_4125},
{"f_4132:posixunix_scm",(void*)f_4132},
{"f_4116:posixunix_scm",(void*)f_4116},
{"f_4123:posixunix_scm",(void*)f_4123},
{"f_4107:posixunix_scm",(void*)f_4107},
{"f_4114:posixunix_scm",(void*)f_4114},
{"f_4098:posixunix_scm",(void*)f_4098},
{"f_4105:posixunix_scm",(void*)f_4105},
{"f_4089:posixunix_scm",(void*)f_4089},
{"f_4096:posixunix_scm",(void*)f_4096},
{"f_4080:posixunix_scm",(void*)f_4080},
{"f_4087:posixunix_scm",(void*)f_4087},
{"f_4074:posixunix_scm",(void*)f_4074},
{"f_4078:posixunix_scm",(void*)f_4078},
{"f_4068:posixunix_scm",(void*)f_4068},
{"f_4072:posixunix_scm",(void*)f_4072},
{"f_4062:posixunix_scm",(void*)f_4062},
{"f_4066:posixunix_scm",(void*)f_4066},
{"f_4056:posixunix_scm",(void*)f_4056},
{"f_4060:posixunix_scm",(void*)f_4060},
{"f_4050:posixunix_scm",(void*)f_4050},
{"f_4054:posixunix_scm",(void*)f_4054},
{"f_4044:posixunix_scm",(void*)f_4044},
{"f_4048:posixunix_scm",(void*)f_4048},
{"f_4012:posixunix_scm",(void*)f_4012},
{"f_4023:posixunix_scm",(void*)f_4023},
{"f_4016:posixunix_scm",(void*)f_4016},
{"f_3975:posixunix_scm",(void*)f_3975},
{"f_4007:posixunix_scm",(void*)f_4007},
{"f_4000:posixunix_scm",(void*)f_4000},
{"f_3979:posixunix_scm",(void*)f_3979},
{"f_3783:posixunix_scm",(void*)f_3783},
{"f_3956:posixunix_scm",(void*)f_3956},
{"f_3799:posixunix_scm",(void*)f_3799},
{"f_3930:posixunix_scm",(void*)f_3930},
{"f_3805:posixunix_scm",(void*)f_3805},
{"f_3808:posixunix_scm",(void*)f_3808},
{"f_3890:posixunix_scm",(void*)f_3890},
{"f_3888:posixunix_scm",(void*)f_3888},
{"f_3847:posixunix_scm",(void*)f_3847},
{"f_3865:posixunix_scm",(void*)f_3865},
{"f_3863:posixunix_scm",(void*)f_3863},
{"f_3851:posixunix_scm",(void*)f_3851},
{"f_3773:posixunix_scm",(void*)f_3773},
{"f_3763:posixunix_scm",(void*)f_3763},
{"f_3757:posixunix_scm",(void*)f_3757},
{"f_3725:posixunix_scm",(void*)f_3725},
{"f_3732:posixunix_scm",(void*)f_3732},
{"f_3738:posixunix_scm",(void*)f_3738},
{"f_3745:posixunix_scm",(void*)f_3745},
{"f_3686:posixunix_scm",(void*)f_3686},
{"f_3693:posixunix_scm",(void*)f_3693},
{"f_3702:posixunix_scm",(void*)f_3702},
{"f_3644:posixunix_scm",(void*)f_3644},
{"f_3654:posixunix_scm",(void*)f_3654},
{"f_3657:posixunix_scm",(void*)f_3657},
{"f_3660:posixunix_scm",(void*)f_3660},
{"f_3629:posixunix_scm",(void*)f_3629},
{"f_3591:posixunix_scm",(void*)f_3591},
{"f_3621:posixunix_scm",(void*)f_3621},
{"f_3608:posixunix_scm",(void*)f_3608},
{"f_3611:posixunix_scm",(void*)f_3611},
{"f_3545:posixunix_scm",(void*)f_3545},
{"f_3549:posixunix_scm",(void*)f_3549},
{"f_3488:posixunix_scm",(void*)f_3488},
{"f_3481:posixunix_scm",(void*)f_3481},
{"f_3463:posixunix_scm",(void*)f_3463},
{"f_3467:posixunix_scm",(void*)f_3467},
{"f_3478:posixunix_scm",(void*)f_3478},
{"f_3474:posixunix_scm",(void*)f_3474},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
