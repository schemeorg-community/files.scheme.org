/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:49
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: c-backend.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[839];
static double C_possibly_force_alignment;


/* from getsize */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2383(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2383(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2378(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2378(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9158)
static void C_ccall f_9158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9134)
static void C_ccall f_9134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9120)
static void C_ccall f_9120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9090)
static void C_ccall f_9090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9051)
static void C_ccall f_9051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8867)
static C_word C_fcall f_8867(C_word *a,C_word t0);
C_noret_decl(f_8460)
static void C_ccall f_8460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8547)
static void C_fcall f_8547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8628)
static void C_ccall f_8628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8650)
static void C_fcall f_8650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8462)
static void C_fcall f_8462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8005)
static void C_fcall f_8005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8032)
static void C_fcall f_8032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_fcall f_8227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8236)
static void C_fcall f_8236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_ccall f_8245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8267)
static void C_fcall f_8267(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8344)
static void C_ccall f_8344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_fcall f_7977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7216)
static void C_fcall f_7216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7318)
static void C_fcall f_7318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_fcall f_7351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_fcall f_7447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_fcall f_7502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_fcall f_7519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_fcall f_7536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_fcall f_7575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7592)
static void C_fcall f_7592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7609)
static void C_fcall f_7609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7626)
static void C_fcall f_7626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7643)
static void C_fcall f_7643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7660)
static void C_fcall f_7660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7677)
static void C_fcall f_7677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7706)
static void C_ccall f_7706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_fcall f_7146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7141)
static void C_fcall f_7141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7137)
static void C_ccall f_7137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6653)
static void C_ccall f_6653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6659)
static void C_ccall f_6659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7072)
static void C_ccall f_7072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6680)
static void C_fcall f_6680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_fcall f_6689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6701)
static void C_fcall f_6701(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6713)
static void C_fcall f_6713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6753)
static void C_fcall f_6753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6432)
static void C_ccall f_6432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6456)
static void C_ccall f_6456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6462)
static void C_ccall f_6462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6522)
static void C_ccall f_6522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6528)
static void C_ccall f_6528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_ccall f_6328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6248)
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6277)
static void C_fcall f_6277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_fcall f_6280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_fcall f_6264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_fcall f_6180(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6136)
static void C_ccall f_6136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6142)
static void C_ccall f_6142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6145)
static void C_ccall f_6145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_fcall f_5382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_fcall f_5410(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_fcall f_6028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_fcall f_5476(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_fcall f_5933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_ccall f_5948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5954)
static void C_fcall f_5954(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_fcall f_5897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_fcall f_5864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_fcall f_5873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_fcall f_5818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5735)
static void C_ccall f_5735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5508)
static void C_fcall f_5508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_fcall f_4949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_fcall f_4955(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_fcall f_5151(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_fcall f_5158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_fcall f_5247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_fcall f_4986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_fcall f_5293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_fcall f_5308(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_fcall f_5324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_fcall f_5370(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_fcall f_4663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_fcall f_4849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_fcall f_4852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_fcall f_4898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_fcall f_4702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_fcall f_4666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_fcall f_4412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_fcall f_4450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_fcall f_4471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_fcall f_4536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_fcall f_4263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_fcall f_4353(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_fcall f_4326(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_fcall f_4116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_fcall f_4119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_fcall f_2543(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4084)
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_fcall f_2546(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_fcall f_3223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_fcall f_3229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_fcall f_3362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_fcall f_3467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_fcall f_2533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8547)
static void C_fcall trf_8547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8547(t0,t1);}

C_noret_decl(trf_8650)
static void C_fcall trf_8650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8650(t0,t1);}

C_noret_decl(trf_8462)
static void C_fcall trf_8462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8462(t0,t1);}

C_noret_decl(trf_8005)
static void C_fcall trf_8005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8005(t0,t1);}

C_noret_decl(trf_8032)
static void C_fcall trf_8032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8032(t0,t1);}

C_noret_decl(trf_8227)
static void C_fcall trf_8227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8227(t0,t1);}

C_noret_decl(trf_8236)
static void C_fcall trf_8236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8236(t0,t1);}

C_noret_decl(trf_8267)
static void C_fcall trf_8267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8267(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8267(t0,t1);}

C_noret_decl(trf_7977)
static void C_fcall trf_7977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7977(t0,t1);}

C_noret_decl(trf_7216)
static void C_fcall trf_7216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7216(t0,t1);}

C_noret_decl(trf_7318)
static void C_fcall trf_7318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7318(t0,t1);}

C_noret_decl(trf_7351)
static void C_fcall trf_7351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7351(t0,t1);}

C_noret_decl(trf_7447)
static void C_fcall trf_7447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7447(t0,t1);}

C_noret_decl(trf_7502)
static void C_fcall trf_7502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7502(t0,t1);}

C_noret_decl(trf_7519)
static void C_fcall trf_7519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7519(t0,t1);}

C_noret_decl(trf_7536)
static void C_fcall trf_7536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7536(t0,t1);}

C_noret_decl(trf_7575)
static void C_fcall trf_7575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7575(t0,t1);}

C_noret_decl(trf_7592)
static void C_fcall trf_7592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7592(t0,t1);}

C_noret_decl(trf_7609)
static void C_fcall trf_7609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7609(t0,t1);}

C_noret_decl(trf_7626)
static void C_fcall trf_7626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7626(t0,t1);}

C_noret_decl(trf_7643)
static void C_fcall trf_7643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7643(t0,t1);}

C_noret_decl(trf_7660)
static void C_fcall trf_7660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7660(t0,t1);}

C_noret_decl(trf_7677)
static void C_fcall trf_7677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7677(t0,t1);}

C_noret_decl(trf_7146)
static void C_fcall trf_7146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7146(t0,t1,t2);}

C_noret_decl(trf_7141)
static void C_fcall trf_7141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7141(t0,t1);}

C_noret_decl(trf_6680)
static void C_fcall trf_6680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6680(t0,t1);}

C_noret_decl(trf_6689)
static void C_fcall trf_6689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6689(t0,t1);}

C_noret_decl(trf_6701)
static void C_fcall trf_6701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6701(t0,t1);}

C_noret_decl(trf_6713)
static void C_fcall trf_6713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6713(t0,t1);}

C_noret_decl(trf_6753)
static void C_fcall trf_6753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6753(t0,t1);}

C_noret_decl(trf_6248)
static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6248(t0,t1,t2);}

C_noret_decl(trf_6277)
static void C_fcall trf_6277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6277(t0,t1);}

C_noret_decl(trf_6280)
static void C_fcall trf_6280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6280(t0,t1);}

C_noret_decl(trf_6264)
static void C_fcall trf_6264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6264(t0,t1);}

C_noret_decl(trf_6180)
static void C_fcall trf_6180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6180(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6180(t0,t1,t2);}

C_noret_decl(trf_5382)
static void C_fcall trf_5382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5382(t0,t1);}

C_noret_decl(trf_5410)
static void C_fcall trf_5410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5410(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5410(t0,t1);}

C_noret_decl(trf_6028)
static void C_fcall trf_6028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6028(t0,t1);}

C_noret_decl(trf_5476)
static void C_fcall trf_5476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5476(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5476(t0,t1);}

C_noret_decl(trf_5990)
static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5990(t0,t1,t2,t3);}

C_noret_decl(trf_5933)
static void C_fcall trf_5933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5933(t0,t1);}

C_noret_decl(trf_5954)
static void C_fcall trf_5954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5954(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5954(t0,t1);}

C_noret_decl(trf_5897)
static void C_fcall trf_5897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5897(t0,t1);}

C_noret_decl(trf_5864)
static void C_fcall trf_5864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5864(t0,t1);}

C_noret_decl(trf_5873)
static void C_fcall trf_5873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5873(t0,t1);}

C_noret_decl(trf_5818)
static void C_fcall trf_5818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5818(t0,t1);}

C_noret_decl(trf_5508)
static void C_fcall trf_5508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5508(t0,t1);}

C_noret_decl(trf_5568)
static void C_fcall trf_5568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5568(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5568(t0,t1,t2,t3);}

C_noret_decl(trf_5120)
static void C_fcall trf_5120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5120(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5120(t0,t1,t2,t3);}

C_noret_decl(trf_4949)
static void C_fcall trf_4949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4949(t0,t1);}

C_noret_decl(trf_4955)
static void C_fcall trf_4955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4955(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4955(t0,t1,t2,t3);}

C_noret_decl(trf_5151)
static void C_fcall trf_5151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5151(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5151(t0,t1,t2,t3);}

C_noret_decl(trf_5158)
static void C_fcall trf_5158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5158(t0,t1);}

C_noret_decl(trf_5247)
static void C_fcall trf_5247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5247(t0,t1);}

C_noret_decl(trf_4986)
static void C_fcall trf_4986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4986(t0,t1);}

C_noret_decl(trf_5293)
static void C_fcall trf_5293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5293(t0,t1,t2);}

C_noret_decl(trf_5308)
static void C_fcall trf_5308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5308(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5308(t0,t1,t2,t3);}

C_noret_decl(trf_5324)
static void C_fcall trf_5324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5324(t0,t1);}

C_noret_decl(trf_5370)
static void C_fcall trf_5370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5370(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5370(t0,t1,t2,t3);}

C_noret_decl(trf_4663)
static void C_fcall trf_4663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4663(t0,t1);}

C_noret_decl(trf_4849)
static void C_fcall trf_4849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4849(t0,t1);}

C_noret_decl(trf_4852)
static void C_fcall trf_4852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4852(t0,t1);}

C_noret_decl(trf_4898)
static void C_fcall trf_4898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4898(t0,t1);}

C_noret_decl(trf_4702)
static void C_fcall trf_4702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4702(t0,t1,t2);}

C_noret_decl(trf_4666)
static void C_fcall trf_4666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4666(t0,t1);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4679(t0,t1,t2,t3);}

C_noret_decl(trf_4412)
static void C_fcall trf_4412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4412(t0,t1);}

C_noret_decl(trf_4450)
static void C_fcall trf_4450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4450(t0,t1);}

C_noret_decl(trf_4471)
static void C_fcall trf_4471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4471(t0,t1);}

C_noret_decl(trf_4536)
static void C_fcall trf_4536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4536(t0,t1);}

C_noret_decl(trf_4263)
static void C_fcall trf_4263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4263(t0,t1);}

C_noret_decl(trf_4284)
static void C_fcall trf_4284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4284(t0,t1,t2,t3);}

C_noret_decl(trf_4353)
static void C_fcall trf_4353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4353(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4353(t0,t1,t2);}

C_noret_decl(trf_4326)
static void C_fcall trf_4326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4326(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4326(t0,t1,t2);}

C_noret_decl(trf_4116)
static void C_fcall trf_4116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4116(t0,t1);}

C_noret_decl(trf_4119)
static void C_fcall trf_4119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4119(t0,t1);}

C_noret_decl(trf_2543)
static void C_fcall trf_2543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2543(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2543(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4084)
static void C_fcall trf_4084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4084(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4084(t0,t1,t2,t3);}

C_noret_decl(trf_2546)
static void C_fcall trf_2546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2546(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2546(t0,t1,t2,t3);}

C_noret_decl(trf_3985)
static void C_fcall trf_3985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3985(t0,t1,t2,t3);}

C_noret_decl(trf_3223)
static void C_fcall trf_3223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3223(t0,t1);}

C_noret_decl(trf_3229)
static void C_fcall trf_3229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3229(t0,t1);}

C_noret_decl(trf_3362)
static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3362(t0,t1);}

C_noret_decl(trf_3467)
static void C_fcall trf_3467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3467(t0,t1);}

C_noret_decl(trf_2728)
static void C_fcall trf_2728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2728(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2728(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2533)
static void C_fcall trf_2533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2533(t0,t1);}

C_noret_decl(trf_2501)
static void C_fcall trf_2501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2501(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2414)){
C_save(t1);
C_rereclaim2(2414*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,839);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],12,"\003sysfor-each");
lf[5]=C_h_intern(&lf[5],17,"\010compilergen-list");
lf[6]=C_h_intern(&lf[6],11,"intersperse");
lf[7]=C_h_intern(&lf[7],18,"\010compilerunique-id");
lf[8]=C_h_intern(&lf[8],22,"\010compilergenerate-code");
lf[9]=C_h_intern(&lf[9],13,"\010compilerbomb");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[11]=C_h_intern(&lf[11],17,"lambda-literal-id");
lf[12]=C_h_intern(&lf[12],4,"find");
lf[13]=C_h_intern(&lf[13],17,"string-translate*");
lf[14]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[15]=C_h_intern(&lf[15],8,"->string");
lf[16]=C_h_intern(&lf[16],14,"\004coreimmediate");
lf[17]=C_h_intern(&lf[17],4,"bool");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[20]=C_h_intern(&lf[20],4,"char");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[22]=C_h_intern(&lf[22],3,"nil");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[24]=C_h_intern(&lf[24],3,"fix");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[26]=C_h_intern(&lf[26],3,"eof");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[29]=C_h_intern(&lf[29],12,"\004coreliteral");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[33]=C_h_intern(&lf[33],2,"if");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[37]=C_h_intern(&lf[37],9,"\004coreproc");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[39]=C_h_intern(&lf[39],9,"\004corebind");
lf[40]=C_h_intern(&lf[40],8,"\004coreref");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[43]=C_h_intern(&lf[43],10,"\004coreunbox");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[46]=C_h_intern(&lf[46],13,"\004coreupdate_i");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[48]=C_h_intern(&lf[48],11,"\004coreupdate");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[52]=C_h_intern(&lf[52],16,"\004coreupdatebox_i");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[55]=C_h_intern(&lf[55],14,"\004coreupdatebox");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[58]=C_h_intern(&lf[58],12,"\004coreclosure");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[63]=C_h_intern(&lf[63],8,"for-each");
lf[64]=C_h_intern(&lf[64],4,"iota");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[66]=C_h_intern(&lf[66],8,"\004corebox");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[69]=C_h_intern(&lf[69],10,"\004corelocal");
lf[70]=C_h_intern(&lf[70],13,"\004coresetlocal");
lf[71]=C_h_intern(&lf[71],11,"\004coreglobal");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[76]=C_h_intern(&lf[76],21,"\010compilerc-ify-string");
lf[77]=C_h_intern(&lf[77],14,"symbol->string");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[82]=C_h_intern(&lf[82],14,"\004coresetglobal");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[89]=C_h_intern(&lf[89],16,"\004coresetglobal_i");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[96]=C_h_intern(&lf[96],14,"\004coreundefined");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[98]=C_h_intern(&lf[98],9,"\004corecall");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[104]=C_h_intern(&lf[104],26,"lambda-literal-temporaries");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[106]=C_h_intern(&lf[106],22,"lambda-literal-looping");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[113]=C_h_intern(&lf[113],13,"string-append");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\032C_retrieve_symbol_proc(lf[");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[129]=C_h_intern(&lf[129],6,"unsafe");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[134]=C_h_intern(&lf[134],19,"no-procedure-checks");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[137]=C_h_intern(&lf[137],24,"\010compileremit-trace-info");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[140]=C_h_intern(&lf[140],16,"string-translate");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[145]=C_h_intern(&lf[145],27,"lambda-literal-closure-size");
lf[146]=C_h_intern(&lf[146],28,"\010compilersource-info->string");
lf[147]=C_h_intern(&lf[147],12,"\004corerecurse");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[151]=C_h_intern(&lf[151],16,"\004coredirect_call");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[153]=C_h_intern(&lf[153],13,"\004corecallunit");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[158]=C_h_intern(&lf[158],11,"\004corereturn");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[161]=C_h_intern(&lf[161],11,"\004coreinline");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[163]=C_h_intern(&lf[163],20,"\004coreinline_allocate");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[166]=C_h_intern(&lf[166],15,"\004coreinline_ref");
lf[167]=C_h_intern(&lf[167],34,"\010compilerforeign-result-conversion");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[169]=C_h_intern(&lf[169],18,"\004coreinline_update");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[172]=C_h_intern(&lf[172],36,"\010compilerforeign-argument-conversion");
lf[173]=C_h_intern(&lf[173],33,"\010compilerforeign-type-declaration");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[175]=C_h_intern(&lf[175],19,"\004coreinline_loc_ref");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[181]=C_h_intern(&lf[181],22,"\004coreinline_loc_update");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_h_intern(&lf[187],11,"\004coreswitch");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[192]=C_h_intern(&lf[192],9,"\004corecond");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[196]=C_h_intern(&lf[196],13,"pair-for-each");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[198]=C_h_intern(&lf[198],30,"\010compilerexternal-protos-first");
lf[199]=C_h_intern(&lf[199],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[200]=C_h_intern(&lf[200],22,"foreign-callback-stubs");
lf[201]=C_h_intern(&lf[201],29,"\010compilerforeign-declarations");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[204]=C_h_intern(&lf[204],28,"\010compilertarget-include-file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[206]=C_h_intern(&lf[206],18,"\010compilerunit-name");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[208]=C_h_intern(&lf[208],19,"\010compilerused-units");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[210]=C_h_intern(&lf[210],27,"\010compilercompiler-arguments");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[216]=C_h_intern(&lf[216],18,"string-intersperse");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[220]=C_h_intern(&lf[220],7,"\003sysmap");
lf[221]=C_h_intern(&lf[221],12,"string-split");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[223]=C_h_intern(&lf[223],15,"chicken-version");
lf[224]=C_h_intern(&lf[224],18,"\003sysdecode-seconds");
lf[225]=C_h_intern(&lf[225],15,"current-seconds");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[230]=C_h_intern(&lf[230],23,"\003syslambda-info->string");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[240]=C_h_intern(&lf[240],9,"make-list");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[244]=C_h_intern(&lf[244],4,"none");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[255]=C_h_intern(&lf[255],8,"toplevel");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[258]=C_h_intern(&lf[258],27,"\010compileremit-unsafe-marker");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[271]=C_h_intern(&lf[271],21,"small-parameter-limit");
lf[272]=C_h_intern(&lf[272],11,"lset-adjoin");
lf[273]=C_h_intern(&lf[273],1,"=");
lf[274]=C_h_intern(&lf[274],32,"lambda-literal-callee-signatures");
lf[275]=C_h_intern(&lf[275],24,"lambda-literal-allocated");
lf[276]=C_h_intern(&lf[276],21,"lambda-literal-direct");
lf[277]=C_h_intern(&lf[277],33,"lambda-literal-rest-argument-mode");
lf[278]=C_h_intern(&lf[278],28,"lambda-literal-rest-argument");
lf[279]=C_h_intern(&lf[279],27,"\010compilermake-variable-list");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[281]=C_h_intern(&lf[281],27,"lambda-literal-customizable");
lf[282]=C_h_intern(&lf[282],29,"lambda-literal-argument-count");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[289]=C_h_intern(&lf[289],27,"\010compilermake-argument-list");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[329]=C_h_intern(&lf[329],6,"vector");
lf[330]=C_h_intern(&lf[330],23,"lambda-literal-external");
lf[331]=C_h_intern(&lf[331],14,"\003syscopy-bytes");
lf[332]=C_h_intern(&lf[332],11,"make-string");
lf[333]=C_h_intern(&lf[333],6,"modulo");
lf[334]=C_h_intern(&lf[334],3,"fx/");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[338]=C_h_intern(&lf[338],19,"\003sysundefined-value");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[349]=C_h_intern(&lf[349],23,"\010compilerencode-literal");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[351]=C_h_intern(&lf[351],32,"\010compilerblock-variable-literal\077");
lf[352]=C_h_intern(&lf[352],20,"\010compilerbig-fixnum\077");
lf[353]=C_h_intern(&lf[353],7,"sprintf");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[355]=C_h_intern(&lf[355],25,"\010compilerwords-per-flonum");
lf[356]=C_h_intern(&lf[356],6,"reduce");
lf[357]=C_h_intern(&lf[357],1,"+");
lf[358]=C_h_intern(&lf[358],12,"vector->list");
lf[359]=C_h_intern(&lf[359],14,"\010compilerwords");
lf[360]=C_h_intern(&lf[360],15,"\003sysbytevector\077");
lf[361]=C_h_intern(&lf[361],19,"\010compilerimmediate\077");
lf[362]=C_h_intern(&lf[362],19,"lambda-literal-body");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[375]=C_h_intern(&lf[375],4,"list");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[414]=C_h_intern(&lf[414],26,"\010compilertarget-stack-size");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[417]=C_h_intern(&lf[417],30,"\010compilertarget-heap-shrinkage");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[419]=C_h_intern(&lf[419],27,"\010compilertarget-heap-growth");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[421]=C_h_intern(&lf[421],33,"\010compilertarget-initial-heap-size");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[424]=C_h_intern(&lf[424],25,"\010compilertarget-heap-size");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[428]=C_h_intern(&lf[428],40,"\010compilerdisable-stack-overflow-checking");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[434]=C_h_intern(&lf[434],4,"fold");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[437]=C_h_intern(&lf[437],28,"\010compilerinsert-timer-checks");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[442]=C_h_intern(&lf[442],14,"no-argc-checks");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[489]=C_h_intern(&lf[489],16,"\010compilercleanup");
lf[490]=C_h_intern(&lf[490],18,"\010compilerdebugging");
lf[491]=C_h_intern(&lf[491],1,"o");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[497]=C_h_intern(&lf[497],18,"\010compilerreal-name");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[499]=C_h_intern(&lf[499],25,"emit-procedure-table-info");
lf[500]=C_h_intern(&lf[500],31,"generate-foreign-callback-stubs");
lf[501]=C_h_intern(&lf[501],31,"\010compilergenerate-foreign-stubs");
lf[502]=C_h_intern(&lf[502],29,"\010compilerforeign-lambda-stubs");
lf[503]=C_h_intern(&lf[503],36,"\010compilergenerate-external-variables");
lf[504]=C_h_intern(&lf[504],27,"\010compilerexternal-variables");
lf[505]=C_h_intern(&lf[505],1,"p");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[523]=C_h_intern(&lf[523],29,"\010compilerstring->c-identifier");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[527]=C_h_intern(&lf[527],11,"string-copy");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[529]=C_h_intern(&lf[529],13,"list-tabulate");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[532]=C_h_intern(&lf[532],41,"\010compilergenerate-foreign-callback-header");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[545]=C_h_intern(&lf[545],4,"void");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[570]=C_h_intern(&lf[570],21,"foreign-stub-callback");
lf[571]=C_h_intern(&lf[571],16,"foreign-stub-cps");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[573]=C_h_intern(&lf[573],27,"foreign-stub-argument-names");
lf[574]=C_h_intern(&lf[574],17,"foreign-stub-body");
lf[575]=C_h_intern(&lf[575],17,"foreign-stub-name");
lf[576]=C_h_intern(&lf[576],24,"foreign-stub-return-type");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[579]=C_h_intern(&lf[579],27,"foreign-stub-argument-types");
lf[580]=C_h_intern(&lf[580],19,"\010compilerreal-name2");
lf[581]=C_h_intern(&lf[581],15,"foreign-stub-id");
lf[582]=C_h_intern(&lf[582],5,"float");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[584]=C_h_intern(&lf[584],8,"c-string");
lf[585]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[586]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[588]=C_h_intern(&lf[588],16,"nonnull-c-string");
lf[589]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[590]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[591]=C_h_intern(&lf[591],3,"ref");
lf[592]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[593]=C_h_intern(&lf[593],5,"const");
lf[594]=C_h_intern(&lf[594],7,"pointer");
lf[595]=C_h_intern(&lf[595],9,"c-pointer");
lf[596]=C_h_intern(&lf[596],15,"nonnull-pointer");
lf[597]=C_h_intern(&lf[597],17,"nonnull-c-pointer");
lf[598]=C_h_intern(&lf[598],8,"function");
lf[599]=C_h_intern(&lf[599],8,"instance");
lf[600]=C_h_intern(&lf[600],16,"nonnull-instance");
lf[601]=C_h_intern(&lf[601],12,"instance-ref");
lf[602]=C_h_intern(&lf[602],18,"\003syshash-table-ref");
lf[603]=C_h_intern(&lf[603],27,"\010compilerforeign-type-table");
lf[604]=C_h_intern(&lf[604],17,"nonnull-c-string*");
lf[605]=C_h_intern(&lf[605],25,"nonnull-unsigned-c-string");
lf[606]=C_h_intern(&lf[606],26,"nonnull-unsigned-c-string*");
lf[607]=C_h_intern(&lf[607],6,"symbol");
lf[608]=C_h_intern(&lf[608],9,"c-string*");
lf[609]=C_h_intern(&lf[609],17,"unsigned-c-string");
lf[610]=C_h_intern(&lf[610],18,"unsigned-c-string*");
lf[611]=C_h_intern(&lf[611],6,"double");
lf[612]=C_h_intern(&lf[612],16,"unsigned-integer");
lf[613]=C_h_intern(&lf[613],18,"unsigned-integer32");
lf[614]=C_h_intern(&lf[614],4,"long");
lf[615]=C_h_intern(&lf[615],7,"integer");
lf[616]=C_h_intern(&lf[616],9,"integer32");
lf[617]=C_h_intern(&lf[617],13,"unsigned-long");
lf[618]=C_h_intern(&lf[618],6,"number");
lf[619]=C_h_intern(&lf[619],9,"integer64");
lf[620]=C_h_intern(&lf[620],13,"c-string-list");
lf[621]=C_h_intern(&lf[621],14,"c-string-list*");
lf[622]=C_h_intern(&lf[622],3,"int");
lf[623]=C_h_intern(&lf[623],5,"int32");
lf[624]=C_h_intern(&lf[624],5,"short");
lf[625]=C_h_intern(&lf[625],14,"unsigned-short");
lf[626]=C_h_intern(&lf[626],13,"scheme-object");
lf[627]=C_h_intern(&lf[627],13,"unsigned-char");
lf[628]=C_h_intern(&lf[628],12,"unsigned-int");
lf[629]=C_h_intern(&lf[629],14,"unsigned-int32");
lf[630]=C_h_intern(&lf[630],4,"byte");
lf[631]=C_h_intern(&lf[631],13,"unsigned-byte");
lf[632]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[647]=C_h_intern(&lf[647],36,"foreign-callback-stub-argument-types");
lf[648]=C_h_intern(&lf[648],33,"foreign-callback-stub-return-type");
lf[649]=C_h_intern(&lf[649],24,"foreign-callback-stub-id");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[652]=C_h_intern(&lf[652],32,"foreign-callback-stub-qualifiers");
lf[653]=C_h_intern(&lf[653],26,"foreign-callback-stub-name");
lf[654]=C_h_intern(&lf[654],4,"quit");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[666]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[674]=C_h_intern(&lf[674],11,"byte-vector");
lf[675]=C_h_intern(&lf[675],19,"nonnull-byte-vector");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[677]=C_h_intern(&lf[677],4,"blob");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[679]=C_h_intern(&lf[679],9,"u16vector");
lf[680]=C_h_intern(&lf[680],17,"nonnull-u16vector");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[682]=C_h_intern(&lf[682],8,"s8vector");
lf[683]=C_h_intern(&lf[683],16,"nonnull-s8vector");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[685]=C_h_intern(&lf[685],9,"u32vector");
lf[686]=C_h_intern(&lf[686],17,"nonnull-u32vector");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[688]=C_h_intern(&lf[688],9,"s16vector");
lf[689]=C_h_intern(&lf[689],17,"nonnull-s16vector");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[691]=C_h_intern(&lf[691],9,"s32vector");
lf[692]=C_h_intern(&lf[692],17,"nonnull-s32vector");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[694]=C_h_intern(&lf[694],9,"f32vector");
lf[695]=C_h_intern(&lf[695],17,"nonnull-f32vector");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[697]=C_h_intern(&lf[697],9,"f64vector");
lf[698]=C_h_intern(&lf[698],17,"nonnull-f64vector");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[711]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[722]=C_h_intern(&lf[722],3,"...");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[727]=C_h_intern(&lf[727],9,"\003syserror");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[729]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[730]=C_h_intern(&lf[730],4,"enum");
lf[731]=C_h_intern(&lf[731],5,"union");
lf[732]=C_h_intern(&lf[732],6,"struct");
lf[733]=C_h_intern(&lf[733],8,"template");
lf[734]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[735]=C_h_intern(&lf[735],12,"nonnull-blob");
lf[736]=C_h_intern(&lf[736],8,"u8vector");
lf[737]=C_h_intern(&lf[737],16,"nonnull-u8vector");
lf[738]=C_h_intern(&lf[738],14,"scheme-pointer");
lf[739]=C_h_intern(&lf[739],22,"nonnull-scheme-pointer");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[834]=C_h_intern(&lf[834],17,"\003sysstring-append");
lf[835]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[836]=C_h_intern(&lf[836],5,"cons*");
lf[837]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[838]=C_h_intern(&lf[838],6,"random");
C_register_lf2(lf,839,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2437 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2440 in k2437 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2443 in k2440 in k2437 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2457,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2478,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9158,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9162,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 98   random */
((C_proc3)C_retrieve_symbol_proc(lf[838]))(3,*((C_word*)lf[838]+1),t7,C_fix(16777216));}

/* k9160 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9166,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 98   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t2);}

/* k9164 in k9160 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 98   sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[353]))(5,*((C_word*)lf[353]+1),((C_word*)t0)[3],lf[837],((C_word*)t0)[2],t1);}

/* k9156 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 97   string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),((C_word*)t0)[2],t1);}

/* k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1 /* (set! unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[8]+1 /* (set! generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2498,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[499]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6162,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[489]+1 /* (set! cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6239,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[279]+1 /* (set! make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6328,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[289]+1 /* (set! make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6344,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[503]+1 /* (set! generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6360,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[199]+1 /* (set! generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6392,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[501]+1 /* (set! generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6410,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[500]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6643,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[532]+1 /* (set! generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7074,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[173]+1 /* (set! foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7139,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[172]+1 /* (set! foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7975,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[167]+1 /* (set! foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8460,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[349]+1 /* (set! encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8858,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8867,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8920,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t4;
f_8920(2,t6,lf[821]);}
else{
t6=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t4;
f_8920(2,t7,lf[822]);}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(C_word)C_fix((C_word)C_character_code(t2));
t8=f_8867(C_a_i(&a,4),t7);
/* c-backend.scm: 1406 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,lf[823],t8);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t7=t4;
f_8920(2,t7,lf[824]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t7=t4;
f_8920(2,t7,lf[825]);}
else{
t7=C_retrieve(lf[338]);
t8=(C_word)C_eqp(t7,t2);
if(C_truep(t8)){
t9=t4;
f_8920(2,t9,lf[826]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9038,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1411 big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t9,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9051,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1420 number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_i_string_length(t9);
t11=f_8867(C_a_i(&a,4),t10);
/* c-backend.scm: 1423 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t4,lf[832],t11,t9);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1428 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t4,lf[833],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9090,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=(C_word)stub2378(C_SCHEME_UNDEFINED,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,1,t12);
t14=t2;
t15=(C_word)stub2383(C_SCHEME_UNDEFINED,t14);
t16=f_8867(C_a_i(&a,4),t15);
/* c-backend.scm: 1431 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t9,t13,t16);}
else{
t9=t2;
t10=(C_word)stub2383(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9120,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=(C_word)stub2378(C_SCHEME_UNDEFINED,t12);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8867(C_a_i(&a,4),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9132,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9134,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1441 list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t17,t10,t18);}}}}}}}}}}}}

/* a9133 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9134,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1441 encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t1,t3);}

/* k9130 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1438 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[836]))(5,*((C_word*)lf[836]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9118 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1437 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[835]);}

/* k9088 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1430 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[834]))(4,*((C_word*)lf[834]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9049 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1420 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[830],t1,lf[831]);}

/* k9036 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1418 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1412 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[829],t13);}}

/* k9032 in k9036 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1418 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[827],t1,lf[828]);}

/* k8918 in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8920,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1402 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static C_word C_fcall f_8867(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_8460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8460,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8462,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[795]);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[623]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[796]);}
else{
t10=(C_word)C_eqp(t5,lf[628]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[629]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[797]);}
else{
t12=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[798]);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[799]);}
else{
t14=(C_word)C_eqp(t5,lf[630]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[800]);}
else{
t15=(C_word)C_eqp(t5,lf[631]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[801]);}
else{
t16=(C_word)C_eqp(t5,lf[582]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[611]));
if(C_truep(t17)){
/* c-backend.scm: 1340 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[802],t3);}
else{
t18=(C_word)C_eqp(t5,lf[618]);
if(C_truep(t18)){
/* c-backend.scm: 1341 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[803],t3);}
else{
t19=(C_word)C_eqp(t5,lf[588]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8547,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8547(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t21)){
t22=t20;
f_8547(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[597]);
if(C_truep(t22)){
t23=t20;
f_8547(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t23)){
t24=t20;
f_8547(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t24)){
t25=t20;
f_8547(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t25)){
t26=t20;
f_8547(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t26)){
t27=t20;
f_8547(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t27)){
t28=t20;
f_8547(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t28)){
t29=t20;
f_8547(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t29)){
t30=t20;
f_8547(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[620]);
t31=t20;
f_8547(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[621])));}}}}}}}}}}}}}}}}}}}}

/* k8545 in ##compiler#foreign-result-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8547,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1345 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[804],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t2)){
/* c-backend.scm: 1346 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[805],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t4)){
/* c-backend.scm: 1347 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[806],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t5)){
/* c-backend.scm: 1348 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[807],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
/* c-backend.scm: 1349 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[808],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t8)){
/* c-backend.scm: 1350 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[809],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t9)){
/* c-backend.scm: 1351 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[810],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[811]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[545]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[626]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[812]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1355 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t13,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8628(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8626 in k8545 in ##compiler#foreign-result-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_8628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8628,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1357 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8650(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8650(t3,C_SCHEME_FALSE);}}}

/* k8648 in k8626 in k8545 in ##compiler#foreign-result-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[596]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[597]));
if(C_truep(t4)){
/* c-backend.scm: 1361 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[813],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t5)){
/* c-backend.scm: 1363 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[814],((C_word*)t0)[3]);}
else{
t6=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t6)){
/* c-backend.scm: 1365 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[815],((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t7)){
/* c-backend.scm: 1367 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[816],((C_word*)t0)[3]);}
else{
t8=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t8)){
/* c-backend.scm: 1369 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[817],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1370 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[594]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[595]));
if(C_truep(t11)){
/* c-backend.scm: 1372 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[818],((C_word*)t0)[3]);}
else{
t12=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t12)){
/* c-backend.scm: 1373 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[819],((C_word*)t0)[3]);}
else{
t13=(C_word)C_eqp(t2,lf[730]);
if(C_truep(t13)){
/* c-backend.scm: 1374 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[820],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1375 err */
t14=((C_word*)t0)[2];
f_8462(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm: 1376 err */
t2=((C_word*)t0)[2];
f_8462(t2,((C_word*)t0)[4]);}}

/* err in ##compiler#foreign-result-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8462,NULL,2,t0,t1);}
/* c-backend.scm: 1331 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[794],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7977,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[626]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[741]);}
else{
t6=(C_word)C_eqp(t4,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[742]);}
else{
t8=(C_word)C_eqp(t4,lf[630]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8005,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_8005(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[622]);
if(C_truep(t10)){
t11=t9;
f_8005(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[628]);
if(C_truep(t11)){
t12=t9;
f_8005(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[629]);
t13=t9;
f_8005(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[631])));}}}}}}

/* k8003 in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8005,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[743]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[624]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[744]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[625]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[745]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[746]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[611]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_8032(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[618]);
t8=t6;
f_8032(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[582])));}}}}}}

/* k8030 in k8003 in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8032,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[747]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[748]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[749]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[750]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[751]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[594]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[752]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[753]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[738]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[754]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[739]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[755]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[756]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[757]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[677]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[758]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[735]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[759]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[674]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[760]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[761]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[736]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[762]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[737]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[763]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[764]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[680]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[765]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[685]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[766]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[686]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[767]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[682]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[768]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[683]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[769]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[688]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[770]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[689]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[771]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[691]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[772]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[773]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[694]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[774]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[695]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[775]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[697]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[776]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[698]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[777]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8227(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t36)){
t37=t35;
f_8227(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[609]);
t38=t35;
f_8227(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[610])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8225 in k8030 in k8003 in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8227,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[778]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8236(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_8236(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_8236(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_8236(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k8234 in k8225 in k8030 in k8003 in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8236,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[779]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[780]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1304 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8245(2,t4,C_SCHEME_FALSE);}}}}

/* k8243 in k8234 in k8225 in k8030 in k8003 in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_8245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8245,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1306 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8267(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8267(t3,C_SCHEME_FALSE);}}}

/* k8265 in k8243 in k8234 in k8225 in k8030 in k8003 in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_8267(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8267,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[781]);}
else{
t4=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[782]);}
else{
t5=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[783]);}
else{
t6=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[784]);}
else{
t7=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[785]);}
else{
t8=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[786]);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[787]);}
else{
t10=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1317 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[730]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[788]);}
else{
t12=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8344,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 1320 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t13,t14,lf[791]);}
else{
t13=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1323 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[792],t14,lf[793]);}
else{
/* c-backend.scm: 1324 err */
t14=((C_word*)t0)[2];
f_7977(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm: 1325 err */
t2=((C_word*)t0)[2];
f_7977(t2,((C_word*)t0)[3]);}}

/* k8342 in k8265 in k8243 in k8234 in k8225 in k8030 in k8003 in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_8344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1320 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[789],t1,lf[790]);}

/* err in ##compiler#foreign-argument-conversion in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7977,NULL,2,t0,t1);}
/* c-backend.scm: 1258 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[740],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7139,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7141,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7146,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[626]);
if(C_truep(t7)){
/* c-backend.scm: 1166 str */
t8=t5;
f_7146(t8,t1,lf[657]);}
else{
t8=(C_word)C_eqp(t6,lf[20]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[630]));
if(C_truep(t9)){
/* c-backend.scm: 1167 str */
t10=t5;
f_7146(t10,t1,lf[658]);}
else{
t10=(C_word)C_eqp(t6,lf[627]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[631]));
if(C_truep(t11)){
/* c-backend.scm: 1168 str */
t12=t5;
f_7146(t12,t1,lf[659]);}
else{
t12=(C_word)C_eqp(t6,lf[628]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[612]));
if(C_truep(t13)){
/* c-backend.scm: 1169 str */
t14=t5;
f_7146(t14,t1,lf[660]);}
else{
t14=(C_word)C_eqp(t6,lf[629]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[613]));
if(C_truep(t15)){
/* c-backend.scm: 1170 str */
t16=t5;
f_7146(t16,t1,lf[661]);}
else{
t16=(C_word)C_eqp(t6,lf[622]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7216,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7216(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[615]);
t19=t17;
f_7216(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[17])));}}}}}}}

/* k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7216,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1171 str */
t2=((C_word*)t0)[7];
f_7146(t2,((C_word*)t0)[6],lf[662]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[623]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[616]));
if(C_truep(t3)){
/* c-backend.scm: 1172 str */
t4=((C_word*)t0)[7];
f_7146(t4,((C_word*)t0)[6],lf[663]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t4)){
/* c-backend.scm: 1173 str */
t5=((C_word*)t0)[7];
f_7146(t5,((C_word*)t0)[6],lf[664]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[624]);
if(C_truep(t5)){
/* c-backend.scm: 1174 str */
t6=((C_word*)t0)[7];
f_7146(t6,((C_word*)t0)[6],lf[665]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t6)){
/* c-backend.scm: 1175 str */
t7=((C_word*)t0)[7];
f_7146(t7,((C_word*)t0)[6],lf[666]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[625]);
if(C_truep(t7)){
/* c-backend.scm: 1176 str */
t8=((C_word*)t0)[7];
f_7146(t8,((C_word*)t0)[6],lf[667]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t8)){
/* c-backend.scm: 1177 str */
t9=((C_word*)t0)[7];
f_7146(t9,((C_word*)t0)[6],lf[668]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t9)){
/* c-backend.scm: 1178 str */
t10=((C_word*)t0)[7];
f_7146(t10,((C_word*)t0)[6],lf[669]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[618]));
if(C_truep(t11)){
/* c-backend.scm: 1179 str */
t12=((C_word*)t0)[7];
f_7146(t12,((C_word*)t0)[6],lf[670]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t13)){
/* c-backend.scm: 1181 str */
t14=((C_word*)t0)[7];
f_7146(t14,((C_word*)t0)[6],lf[671]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7318(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t16)){
t17=t15;
f_7318(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[738]);
t18=t15;
f_7318(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[739])));}}}}}}}}}}}}}

/* k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7318,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1182 str */
t2=((C_word*)t0)[7];
f_7146(t2,((C_word*)t0)[6],lf[672]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[621]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[673]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[674]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[675]));
if(C_truep(t5)){
/* c-backend.scm: 1185 str */
t6=((C_word*)t0)[7];
f_7146(t6,((C_word*)t0)[6],lf[676]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[677]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7351(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[735]);
if(C_truep(t8)){
t9=t7;
f_7351(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[736]);
t10=t7;
f_7351(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[737])));}}}}}}

/* k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7351,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1186 str */
t2=((C_word*)t0)[7];
f_7146(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[679]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[680]));
if(C_truep(t3)){
/* c-backend.scm: 1187 str */
t4=((C_word*)t0)[7];
f_7146(t4,((C_word*)t0)[6],lf[681]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[682]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[683]));
if(C_truep(t5)){
/* c-backend.scm: 1188 str */
t6=((C_word*)t0)[7];
f_7146(t6,((C_word*)t0)[6],lf[684]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[685]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[686]));
if(C_truep(t7)){
/* c-backend.scm: 1189 str */
t8=((C_word*)t0)[7];
f_7146(t8,((C_word*)t0)[6],lf[687]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[688]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[689]));
if(C_truep(t9)){
/* c-backend.scm: 1190 str */
t10=((C_word*)t0)[7];
f_7146(t10,((C_word*)t0)[6],lf[690]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[691]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[692]));
if(C_truep(t11)){
/* c-backend.scm: 1191 str */
t12=((C_word*)t0)[7];
f_7146(t12,((C_word*)t0)[6],lf[693]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[694]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[695]));
if(C_truep(t13)){
/* c-backend.scm: 1192 str */
t14=((C_word*)t0)[7];
f_7146(t14,((C_word*)t0)[6],lf[696]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[697]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[698]));
if(C_truep(t15)){
/* c-backend.scm: 1193 str */
t16=((C_word*)t0)[7];
f_7146(t16,((C_word*)t0)[6],lf[699]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7447(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t18)){
t19=t17;
f_7447(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[604]);
if(C_truep(t19)){
t20=t17;
f_7447(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t20)){
t21=t17;
f_7447(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[605]);
if(C_truep(t21)){
t22=t17;
f_7447(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[606]);
if(C_truep(t22)){
t23=t17;
f_7447(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[610]);
t24=t17;
f_7447(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[607])));}}}}}}}}}}}}}}}

/* k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7447,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1196 str */
t2=((C_word*)t0)[7];
f_7146(t2,((C_word*)t0)[6],lf[700]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t2)){
/* c-backend.scm: 1197 str */
t3=((C_word*)t0)[7];
f_7146(t3,((C_word*)t0)[6],lf[701]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1199 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7462(2,t4,C_SCHEME_FALSE);}}}}

/* k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7462,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1201 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1202 str */
t2=((C_word*)t0)[3];
f_7146(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7502,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7502(t6,(C_word)C_i_memq(t5,lf[734]));}
else{
t5=t3;
f_7502(t5,C_SCHEME_FALSE);}}
else{
/* c-backend.scm: 1252 err */
t2=((C_word*)t0)[2];
f_7141(t2,((C_word*)t0)[6]);}}}}

/* k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7502,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7513,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1209 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[702],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7519(t5,(C_word)C_eqp(lf[591],t4));}
else{
t4=t2;
f_7519(t4,C_SCHEME_FALSE);}}}

/* k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7519,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7530,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1212 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[703],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7536(t4,(C_word)C_eqp(lf[733],t3));}
else{
t3=t2;
f_7536(t3,C_SCHEME_FALSE);}}}

/* k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7536,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7543,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7547,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1217 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,t4,lf[708]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7575(t5,(C_word)C_eqp(lf[593],t4));}
else{
t4=t2;
f_7575(t4,C_SCHEME_FALSE);}}}

/* k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7575,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1224 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7592(t5,(C_word)C_eqp(lf[732],t4));}
else{
t4=t2;
f_7592(t4,C_SCHEME_FALSE);}}}

/* k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7592,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1226 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7609(t5,(C_word)C_eqp(lf[731],t4));}
else{
t4=t2;
f_7609(t4,C_SCHEME_FALSE);}}}

/* k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7609,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7616,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1228 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7626(t5,(C_word)C_eqp(lf[730],t4));}
else{
t4=t2;
f_7626(t4,C_SCHEME_FALSE);}}}

/* k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7626,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7633,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1230 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7643(t5,(C_word)C_i_memq(t4,lf[729]));}
else{
t4=t2;
f_7643(t4,C_SCHEME_FALSE);}}}

/* k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7643,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1232 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7660(t5,(C_word)C_eqp(lf[601],t4));}
else{
t4=t2;
f_7660(t4,C_SCHEME_FALSE);}}}

/* k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7660,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7667,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1234 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7677(t4,(C_word)C_eqp(lf[598],t3));}
else{
t3=t2;
f_7677(t3,C_SCHEME_FALSE);}}}

/* k7675 in k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7677,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7689,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7689(2,t6,lf[726]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7689(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[727]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[728],t4);}}}
else{
/* c-backend.scm: 1251 err */
t2=((C_word*)t0)[2];
f_7141(t2,((C_word*)t0)[4]);}}

/* k7687 in k7675 in k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1240 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[725]);}

/* k7694 in k7687 in k7675 in k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7704,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7706,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7705 in k7694 in k7687 in k7675 in k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7706,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[722],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[723]);}
else{
/* c-backend.scm: 1247 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[724]);}}

/* k7702 in k7694 in k7687 in k7675 in k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1243 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[721]);}

/* k7698 in k7694 in k7687 in k7675 in k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1239 string-append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[113]+1)))(9,*((C_word*)lf[113]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[718],((C_word*)t0)[2],lf[719],t1,lf[720]);}

/* k7665 in k7658 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1234 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[717],((C_word*)t0)[2]);}

/* k7648 in k7641 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1232 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[716],((C_word*)t0)[2]);}

/* k7631 in k7624 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1230 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[714],t1,lf[715],((C_word*)t0)[2]);}

/* k7614 in k7607 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1228 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[712],t1,lf[713],((C_word*)t0)[2]);}

/* k7597 in k7590 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1226 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[710],t1,lf[711],((C_word*)t0)[2]);}

/* k7580 in k7573 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1224 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[709],t1);}

/* k7545 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7551,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7555,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7557,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7556 in k7545 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7557,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[707]);}

/* k7553 in k7545 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1219 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[706]);}

/* k7549 in k7545 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1216 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[704],t1,lf[705]);}

/* k7541 in k7534 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1215 str */
t2=((C_word*)t0)[3];
f_7146(t2,((C_word*)t0)[2],t1);}

/* k7528 in k7517 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1212 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7511 in k7500 in k7460 in k7445 in k7349 in k7316 in k7214 in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1209 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7146,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1164 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,t2,lf[656],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_7141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7141,NULL,2,t0,t1);}
/* c-backend.scm: 1163 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[655],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7074,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7078,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1145 foreign-callback-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[653]))(3,*((C_word*)lf[653]+1),t4,t3);}

/* k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7081,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1146 foreign-callback-stub-qualifiers */
((C_proc3)C_retrieve_symbol_proc(lf[652]))(3,*((C_word*)lf[652]+1),t2,((C_word*)t0)[2]);}

/* k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1147 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7087,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1148 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[2]);}

/* k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7087,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1150 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[651]);}

/* k7091 in k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7096,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7137,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1151 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,((C_word*)t0)[2],lf[650]);}

/* k7135 in k7091 in k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1151 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k7094 in k7091 in k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7099,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7104,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1152 pair-for-each */
((C_proc5)C_retrieve_symbol_proc(lf[196]))(5,*((C_word*)lf[196]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7103 in k7094 in k7091 in k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7104,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7108,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7125,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1154 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t5,t6,t7);}

/* k7123 in a7103 in k7094 in k7091 in k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1154 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k7106 in a7103 in k7094 in k7091 in k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1155 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7097 in k7094 in k7091 in k7085 in k7082 in k7079 in k7076 in ##compiler#generate-foreign-callback-header in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1157 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6643,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6649,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6649,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6653,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1092 foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[649]))(3,*((C_word*)lf[649]+1),t3,t2);}

/* k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6656,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1093 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6659,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1094 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1095 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[3]);}

/* k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6662,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1097 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[646]);}

/* k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6668,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6670,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1124 fold */
((C_proc6)C_retrieve_symbol_proc(lf[434]))(6,*((C_word*)lf[434]+1),t5,((C_word*)t3)[1],lf[645],((C_word*)t0)[4],t1);}

/* k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1125 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7072,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1127 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7015(2,t3,C_SCHEME_UNDEFINED);}}

/* k7070 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1127 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[643],t1,lf[644]);}

/* k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1128 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[642],((C_word*)t0)[2]);}

/* k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1129 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(123),C_SCHEME_TRUE,lf[640],((C_word*)t0)[2],lf[641]);}

/* k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1130 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[639]);}

/* k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7027,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7057,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1131 for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7056 in k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7057,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7065,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1133 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t4,t3,lf[638]);}

/* k7063 in a7056 in k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1133 gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[635],t1,((C_word*)t0)[2],lf[636],C_SCHEME_TRUE,lf[637]);}

/* k7025 in k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_7030(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7055,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1138 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,((C_word*)t0)[4]);}}

/* k7053 in k7025 in k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1138 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[634],t1);}

/* k7028 in k7025 in k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1139 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[633],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k7031 in k7028 in k7025 in k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7036,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_7036(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1140 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k7034 in k7031 in k7028 in k7025 in k7022 in k7019 in k7016 in k7013 in k7010 in k7007 in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1141 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[632]);}

/* compute-size in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6670,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6680,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6680(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
if(C_truep(t8)){
t9=t7;
f_6680(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[623]);
if(C_truep(t9)){
t10=t7;
f_6680(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t10)){
t11=t7;
f_6680(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t11)){
t12=t7;
f_6680(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[545]);
if(C_truep(t12)){
t13=t7;
f_6680(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t7;
f_6680(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[626]);
if(C_truep(t14)){
t15=t7;
f_6680(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[627]);
if(C_truep(t15)){
t16=t7;
f_6680(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[628]);
if(C_truep(t16)){
t17=t7;
f_6680(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[629]);
if(C_truep(t17)){
t18=t7;
f_6680(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[630]);
t19=t7;
f_6680(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[631])));}}}}}}}}}}}}

/* k6678 in compute-size in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6680,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6689(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
if(C_truep(t4)){
t5=t3;
f_6689(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t5)){
t6=t3;
f_6689(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[612]);
if(C_truep(t6)){
t7=t3;
f_6689(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[613]);
if(C_truep(t7)){
t8=t3;
f_6689(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t8)){
t9=t3;
f_6689(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[615]);
if(C_truep(t9)){
t10=t3;
f_6689(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[616]);
if(C_truep(t10)){
t11=t3;
f_6689(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t11)){
t12=t3;
f_6689(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t12)){
t13=t3;
f_6689(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[618]);
if(C_truep(t13)){
t14=t3;
f_6689(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t14)){
t15=t3;
f_6689(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t16=t3;
f_6689(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[621])));}}}}}}}}}}}}}}

/* k6687 in k6678 in compute-size in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6689,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1106 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[583]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6701(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t4)){
t5=t3;
f_6701(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
if(C_truep(t5)){
t6=t3;
f_6701(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
t7=t3;
f_6701(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[610])));}}}}}

/* k6699 in k6687 in k6678 in compute-size in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6701,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1108 string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[113]+1)))(8,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[585],((C_word*)t0)[5],lf[586],((C_word*)t0)[5],lf[587]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6713(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_6713(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_6713(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_6713(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k6711 in k6699 in k6687 in k6678 in compute-size in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6713,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1110 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[589],((C_word*)t0)[4],lf[590]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1112 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t2,C_retrieve(lf[603]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6719(2,t3,C_SCHEME_FALSE);}}}

/* k6717 in k6711 in k6699 in k6687 in k6678 in compute-size in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6719,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1114 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6670(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[591]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6753,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6753(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t5)){
t6=t4;
f_6753(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t6)){
t7=t4;
f_6753(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t7)){
t8=t4;
f_6753(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t8)){
t9=t4;
f_6753(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=t4;
f_6753(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t10)){
t11=t4;
f_6753(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[600]);
t12=t4;
f_6753(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[601])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6751 in k6717 in k6711 in k6699 in k6687 in k6678 in compute-size in k6666 in k6660 in k6657 in k6654 in k6651 in a6648 in generate-foreign-callback-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1119 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[592]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1120 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6670(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6410,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6416,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6416,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1025 foreign-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[581]))(3,*((C_word*)lf[581]+1),t3,t2);}

/* k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1026 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6426,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1027 foreign-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[579]))(3,*((C_word*)lf[579]+1),t2,((C_word*)t0)[2]);}

/* k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6641,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1029 make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,t2,lf[578]);}

/* k6639 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[577],t1);
/* c-backend.scm: 1029 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t2,C_make_character(44));}

/* k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1030 foreign-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[576]))(3,*((C_word*)lf[576]+1),t2,((C_word*)t0)[2]);}

/* k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1031 foreign-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[575]))(3,*((C_word*)lf[575]+1),t2,((C_word*)t0)[2]);}

/* k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1032 foreign-stub-body */
((C_proc3)C_retrieve_symbol_proc(lf[574]))(3,*((C_word*)lf[574]+1),t2,((C_word*)t0)[2]);}

/* k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1033 foreign-stub-argument-names */
((C_proc3)C_retrieve_symbol_proc(lf[573]))(3,*((C_word*)lf[573]+1),t2,((C_word*)t0)[2]);}

/* k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6447(2,t3,t1);}
else{
/* c-backend.scm: 1033 make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1034 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t2,((C_word*)t0)[9],lf[572]);}

/* k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1035 foreign-stub-cps */
((C_proc3)C_retrieve_symbol_proc(lf[571]))(3,*((C_word*)lf[571]+1),t2,((C_word*)t0)[2]);}

/* k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1036 foreign-stub-callback */
((C_proc3)C_retrieve_symbol_proc(lf[570]))(3,*((C_word*)lf[570]+1),t2,((C_word*)t0)[2]);}

/* k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1037 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1039 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6462(2,t3,C_SCHEME_UNDEFINED);}}

/* k6628 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1039 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[568],t1,lf[569]);}

/* k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1041 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[566],((C_word*)t0)[6],lf[567]);}
else{
t3=t2;
f_6465(2,t3,C_SCHEME_UNDEFINED);}}

/* k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1044 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[561],((C_word*)t0)[2],lf[562],C_SCHEME_TRUE,lf[563],((C_word*)t0)[2],lf[564]);}
else{
/* c-backend.scm: 1046 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[565],((C_word*)t0)[2],C_make_character(40));}}

/* k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[3]);}

/* k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1049 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[556],C_SCHEME_TRUE,lf[557],((C_word*)t0)[2],lf[558]);}
else{
/* c-backend.scm: 1050 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[559],C_SCHEME_TRUE,lf[560],((C_word*)t0)[2],C_make_character(40));}}

/* k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1052 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[555]);}

/* k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1053 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[554]);}

/* k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6486,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6578,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1062 iota */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6]);}

/* k6606 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1054 for-each */
((C_proc6)C_retrieve_proc(*((C_word*)lf[63]+1)))(6,*((C_word*)lf[63]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6577 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6578,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6586,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6598,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1059 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t6,t4);}
else{
/* c-backend.scm: 1059 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[553],t3);}}

/* k6596 in a6577 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1057 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6584 in a6577 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1060 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[552]);}

/* k6588 in k6584 in a6577 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6594,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1061 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k6592 in k6588 in k6584 in a6577 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1056 gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[549],((C_word*)t0)[3],C_make_character(41),t1,lf[550],((C_word*)t0)[2],lf[551]);}

/* k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1063 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[548]);}
else{
t3=t2;
f_6489(2,t3,C_SCHEME_UNDEFINED);}}

/* k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6498,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1065 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[539]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t4)){
/* c-backend.scm: 1076 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1075 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[547],((C_word*)t0)[2]);}}}

/* k6517 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1077 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(40));}

/* k6520 in k6517 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6556,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6560,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1078 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[546]);}

/* k6558 in k6520 in k6517 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1078 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k6554 in k6520 in k6517 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k6523 in k6520 in k6517 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6528,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[545]);
if(C_truep(t3)){
t4=t2;
f_6528(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1079 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k6526 in k6523 in k6520 in k6517 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1080 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[544]);}

/* k6529 in k6526 in k6523 in k6520 in k6517 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1082 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[540],C_SCHEME_TRUE,lf[541]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1084 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[542]);}
else{
/* c-backend.scm: 1085 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[543]);}}}

/* k6496 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1067 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[538],C_SCHEME_TRUE);}

/* k6499 in k6496 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1069 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[534],C_SCHEME_TRUE,lf[535]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1071 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[536]);}
else{
/* c-backend.scm: 1072 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[537]);}}}

/* k6490 in k6487 in k6484 in k6481 in k6478 in k6475 in k6472 in k6469 in k6466 in k6463 in k6460 in k6457 in k6454 in k6451 in k6448 in k6445 in k6442 in k6439 in k6436 in k6433 in k6430 in k6424 in k6421 in k6418 in a6415 in ##compiler#generate-foreign-stubs in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1086 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6392,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6398,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6397 in ##compiler#generate-foreign-callback-stub-prototypes in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6398,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1017 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6400 in a6397 in ##compiler#generate-foreign-callback-stub-prototypes in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1018 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[533],((C_word*)t0)[2]);}

/* k6403 in k6400 in a6397 in ##compiler#generate-foreign-callback-stub-prototypes in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1019 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6360,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6364,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1002 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6362 in ##compiler#generate-external-variables in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6369,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6368 in k6362 in ##compiler#generate-external-variables in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6369,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(t2,C_fix(2));
t6=(C_truep(t5)?lf[530]:lf[531]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6390,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1008 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t7,t4,t3);}

/* k6388 in a6368 in k6362 in ##compiler#generate-external-variables in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1008 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6344,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6350,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 994  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6349 in ##compiler#make-argument-list in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6350,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6358,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 996  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6356 in a6349 in ##compiler#make-argument-list in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 996  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6328,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6334,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 989  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6333 in ##compiler#make-variable-list in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 991  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6340 in a6333 in ##compiler#make-variable-list in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 991  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[528],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6239,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6248,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6248(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6264,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6277,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_6277(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_6277(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_6277(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_6277(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_6277(t10,C_SCHEME_FALSE);}}}}}

/* k6275 in loop in ##compiler#cleanup in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6277,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_6280(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6287,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 980  string-copy */
((C_proc3)C_retrieve_symbol_proc(lf[527]))(3,*((C_word*)lf[527]+1),t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_6264(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k6285 in k6275 in loop in ##compiler#cleanup in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6280(t3,t2);}

/* k6278 in k6275 in loop in ##compiler#cleanup in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_6264(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k6262 in loop in ##compiler#cleanup in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 983  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6248(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6162,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6166,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 945  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[524],C_SCHEME_TRUE,lf[525],t6,lf[526]);}

/* k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6169,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6180(t6,t2,((C_word*)t0)[2]);}

/* doloop1269 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6180(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6180,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 949  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[516]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 950  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t4);}}

/* k6191 in doloop1269 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6196,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6225,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 951  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),t3,((C_word*)t0)[2]);}

/* k6223 in k6191 in doloop1269 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 951  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[521],((C_word*)t0)[2],C_make_character(58),t1,lf[522]);}

/* k6194 in k6191 in doloop1269 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 954  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[517],C_retrieve(lf[206]),lf[518]);}
else{
/* c-backend.scm: 955  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[519]);}}
else{
/* c-backend.scm: 956  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[520]);}}

/* k6197 in k6194 in k6191 in doloop1269 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6180(t3,((C_word*)t0)[2],t2);}

/* k6167 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 957  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[515]);}

/* k6170 in k6167 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 958  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[514]);}

/* k6173 in k6170 in k6167 in k6164 in emit-procedure-table-info in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 959  gen */
((C_proc15)C_retrieve_symbol_proc(lf[1]))(15,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[507],C_SCHEME_TRUE,lf[508],C_SCHEME_TRUE,lf[509],C_SCHEME_TRUE,lf[510],C_SCHEME_TRUE,lf[511],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}

/* ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2498,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2501,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2533,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4263,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4412,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4663,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5370,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5293,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4986,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5151,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4949,a[2]=t2,a[3]=t19,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4992,a[2]=t18,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5382,a[2]=t4,a[3]=t8,a[4]=t22,a[5]=t20,a[6]=t2,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t25=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6129,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t8,a[6]=t15,a[7]=t24,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 928  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[490]))(4,*((C_word*)lf[490]+1),t25,lf[505],lf[506]);}

/* k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6129,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 930  header */
t4=((C_word*)t0)[2];
f_4116(t4,t3);}

/* k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 931  declarations */
t3=((C_word*)t0)[2];
f_4263(t3,t2);}

/* k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 932  generate-external-variables */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t2,C_retrieve(lf[504]));}

/* k6137 in k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 933  generate-foreign-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[501]))(4,*((C_word*)lf[501]+1),t2,C_retrieve(lf[502]),((C_word*)t0)[3]);}

/* k6140 in k6137 in k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 934  prototypes */
t3=((C_word*)t0)[2];
f_4412(t3,t2);}

/* k6143 in k6140 in k6137 in k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 935  generate-foreign-callback-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[500]))(4,*((C_word*)lf[500]+1),t2,C_retrieve(lf[200]),((C_word*)t0)[2]);}

/* k6146 in k6143 in k6140 in k6137 in k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 936  trampolines */
t3=((C_word*)t0)[2];
f_4663(t3,t2);}

/* k6149 in k6146 in k6143 in k6140 in k6137 in k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 937  procedures */
t3=((C_word*)t0)[2];
f_5382(t3,t2);}

/* k6152 in k6149 in k6146 in k6143 in k6140 in k6137 in k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6157,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 938  emit-procedure-table-info */
((C_proc4)C_retrieve_symbol_proc(lf[499]))(4,*((C_word*)lf[499]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6155 in k6152 in k6149 in k6146 in k6143 in k6140 in k6137 in k6134 in k6131 in k6127 in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 509  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[498],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5382,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5388,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 752  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 753  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[6]);}

/* k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 754  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[497]))(4,*((C_word*)lf[497]+1),t2,t1,((C_word*)t0)[2]);}

/* k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5401,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 755  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[6]);}

/* k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 756  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[7]);}

/* k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5404,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 757  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t4,((C_word*)t0)[8]);}

/* k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 758  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5410(t3,C_SCHEME_FALSE);}}

/* k6124 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5410(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5410,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5416,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 760  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,((C_word*)t0)[13],lf[496]);}

/* k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5419,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 761  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)t0)[13],lf[495]);}

/* k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5422,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 762  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 763  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 764  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t2,((C_word*)t0)[12]);}

/* k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 765  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,((C_word*)t0)[13]);}

/* k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5434,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 766  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[14]);}

/* k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 767  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[15]);}

/* k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 768  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[16]);}

/* k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 770  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,C_retrieve(lf[206]),lf[493]);}
else{
t3=t2;
f_5443(2,t3,lf[494]);}}

/* k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 772  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[490]))(5,*((C_word*)lf[490]+1),t2,lf[491],lf[492],((C_word*)t0)[14]);}
else{
t3=t2;
f_5446(2,t3,C_SCHEME_UNDEFINED);}}

/* k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 773  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6095,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 774  cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}

/* k6093 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 774  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[487],t1,lf[488],C_SCHEME_TRUE);}

/* k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6078,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 783  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[481]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 776  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[486]);}}

/* k6054 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[484]:lf[485]);
/* c-backend.scm: 777  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k6057 in k6054 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 779  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[482]);}
else{
/* c-backend.scm: 780  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[483]);}}

/* k6060 in k6057 in k6054 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 781  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6076 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_6081(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 785  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[480]);}}

/* k6079 in k6076 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 786  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[474],C_SCHEME_TRUE,lf[475],C_SCHEME_TRUE,lf[476],C_SCHEME_TRUE,lf[477],((C_word*)t0)[2],lf[478],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[479],((C_word*)t0)[2]);}

/* k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 791  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5461(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 792  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[473]);}}

/* k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6028,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_6028(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6028(t4,C_SCHEME_FALSE);}}

/* k6026 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_6028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6028,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 794  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[472]);}
else{
t2=((C_word*)t0)[2];
f_5464(2,t2,C_SCHEME_UNDEFINED);}}

/* k6029 in k6026 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 795  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_5464(2,t2,C_SCHEME_UNDEFINED);}}

/* k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[15]);}

/* k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 797  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[471]);}
else{
t3=t2;
f_5470(2,t3,C_SCHEME_UNDEFINED);}}

/* k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 798  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[470]);}

/* k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[244]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5476(t5,t4);}
else{
t4=t2;
f_5476(t4,C_SCHEME_UNDEFINED);}}

/* k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5476(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5476,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 800  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[469]);}

/* k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 802  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[467],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5990,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5990(t8,t2,((C_word*)t0)[20],t4);}}

/* doloop1022 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6000,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 806  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[468],t2,C_make_character(59));}}

/* k5998 in doloop1022 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5990(t4,((C_word*)t0)[2],t2,t3);}

/* k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5485,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5777,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 808  fold */
((C_proc5)C_retrieve_symbol_proc(lf[434]))(5,*((C_word*)lf[434]+1),t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 842  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5933(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5933(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5931 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5933,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 856  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],C_SCHEME_TRUE,lf[460],((C_word*)t0)[3],lf[461]);}
else{
/* c-backend.scm: 859  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[462],((C_word*)t0)[3],lf[463]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5945(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 861  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[466]);}}}

/* k5943 in k5931 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 862  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[465]);}
else{
t3=t2;
f_5948(2,t3,C_SCHEME_UNDEFINED);}}

/* k5946 in k5943 in k5931 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5954,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[129]);
t4=t2;
f_5954(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[428]))));}
else{
t3=t2;
f_5954(t3,C_SCHEME_FALSE);}}

/* k5952 in k5946 in k5943 in k5931 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5954(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 864  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[464]);}
else{
t2=((C_word*)t0)[2];
f_5855(2,t2,C_SCHEME_UNDEFINED);}}

/* k5853 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5858,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5897,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5897(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
t6=t3;
f_5897(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5897(t4,C_SCHEME_FALSE);}}

/* k5895 in k5853 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 868  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[452],((C_word*)t0)[3],lf[453],((C_word*)t0)[3],lf[454]);}
else{
t4=((C_word*)t0)[2];
f_5858(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 869  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455],((C_word*)t0)[3],lf[456],((C_word*)t0)[3],lf[457]);}}
else{
t2=((C_word*)t0)[2];
f_5858(2,t2,C_SCHEME_UNDEFINED);}}

/* k5856 in k5853 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5864(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_5864(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_5864(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5862 in k5856 in k5853 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5864,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 871  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[451]);}
else{
t3=t2;
f_5867(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_5485(2,t2,C_SCHEME_UNDEFINED);}}

/* k5865 in k5862 in k5856 in k5853 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5873,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_5873(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_5873(t3,C_SCHEME_FALSE);}}

/* k5871 in k5865 in k5862 in k5856 in k5853 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 873  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[449]);}
else{
/* c-backend.scm: 874  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[450]);}}

/* k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 843  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[447]);}

/* k5792 in k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 844  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[446]);}

/* k5795 in k5792 in k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 846  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 847  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[445]);}}

/* k5798 in k5795 in k5792 in k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 848  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[443],((C_word*)t0)[3],lf[444]);}

/* k5801 in k5798 in k5795 in k5792 in k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5806,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5818(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
if(C_truep(t5)){
t6=t3;
f_5818(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5818(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5816 in k5801 in k5798 in k5795 in k5792 in k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 850  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[439],((C_word*)t0)[2],lf[440],((C_word*)t0)[2],lf[441]);}
else{
t2=((C_word*)t0)[3];
f_5806(2,t2,C_SCHEME_UNDEFINED);}}

/* k5804 in k5801 in k5798 in k5795 in k5792 in k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 851  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[438]);}
else{
t3=t2;
f_5809(2,t3,C_SCHEME_UNDEFINED);}}

/* k5807 in k5804 in k5801 in k5798 in k5795 in k5792 in k5789 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 852  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[435],((C_word*)t0)[2],lf[436]);}

/* a5776 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5777,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5785,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 808  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4992(3,t5,t4,t2);}

/* k5783 in a5776 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5708,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 810  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[430],C_SCHEME_TRUE,lf[431],C_SCHEME_TRUE,lf[432],((C_word*)t0)[2],lf[433]);}

/* k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[428]))){
/* c-backend.scm: 814  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[429]);}
else{
t3=t2;
f_5711(2,t3,C_SCHEME_UNDEFINED);}}

/* k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_5714(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5745,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[421]))){
/* c-backend.scm: 817  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[422],C_retrieve(lf[421]),lf[423]);}
else{
if(C_truep(C_retrieve(lf[424]))){
/* c-backend.scm: 819  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[425],C_retrieve(lf[424]),lf[426],C_SCHEME_TRUE,lf[427]);}
else{
t4=t3;
f_5745(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k5743 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[419]))){
/* c-backend.scm: 822  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[420],C_retrieve(lf[419]),C_make_character(59));}
else{
t3=t2;
f_5748(2,t3,C_SCHEME_UNDEFINED);}}

/* k5746 in k5743 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[417]))){
/* c-backend.scm: 824  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[418],C_retrieve(lf[417]),C_make_character(59));}
else{
t3=t2;
f_5751(2,t3,C_SCHEME_UNDEFINED);}}

/* k5749 in k5746 in k5743 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[414]))){
/* c-backend.scm: 826  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[415],C_retrieve(lf[414]),lf[416]);}
else{
t2=((C_word*)t0)[2];
f_5714(2,t2,C_SCHEME_UNDEFINED);}}

/* k5712 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 827  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[407],((C_word*)t0)[3],lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[3],lf[410],C_SCHEME_TRUE,lf[411],C_SCHEME_TRUE,lf[412],C_SCHEME_TRUE,lf[413]);}

/* k5715 in k5712 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 832  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[401],((C_word*)t0)[2],lf[402],C_SCHEME_TRUE,lf[403],C_SCHEME_TRUE,lf[404],((C_word*)t0)[2],lf[405],C_SCHEME_TRUE,lf[406]);}

/* k5718 in k5715 in k5712 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 836  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[399],((C_word*)t0)[2],lf[400]);}

/* k5721 in k5718 in k5715 in k5712 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5723,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5485(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 838  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[397],((C_word*)t0)[4],lf[398]);}}

/* k5730 in k5721 in k5718 in k5715 in k5712 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5735,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 839  literal-frame */
t3=((C_word*)t0)[2];
f_4949(t3,t2);}

/* k5733 in k5730 in k5721 in k5718 in k5715 in k5712 in k5709 in k5706 in k5700 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 840  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[395],((C_word*)t0)[2],lf[396]);}

/* k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5488,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[255],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5508(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5508(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5508(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_5508(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5508(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5508,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[386]:lf[387]);
/* c-backend.scm: 885  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[388],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[392]:lf[393]);
/* c-backend.scm: 911  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[394]);}}
else{
t2=((C_word*)t0)[10];
f_5488(2,t2,C_SCHEME_UNDEFINED);}}

/* k5641 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 913  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[3],lf[390]);}
else{
/* c-backend.scm: 914  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[391],((C_word*)t0)[3]);}}

/* k5644 in k5641 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5649,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5658,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 916  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5649(2,t3,C_SCHEME_UNDEFINED);}}

/* k5656 in k5644 in k5641 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5647 in k5644 in k5641 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 918  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[389]);}

/* k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[329]);
if(C_truep(t3)){
/* c-backend.scm: 886  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t4=t2;
f_5517(2,t4,C_SCHEME_UNDEFINED);}}

/* k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 887  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[384],((C_word*)t0)[5],lf[385]);}

/* k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 889  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5523(2,t3,C_SCHEME_UNDEFINED);}}

/* k5622 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 891  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,lf[380],C_SCHEME_TRUE,lf[381],C_SCHEME_TRUE,lf[382],((C_word*)t0)[6],lf[383]);}

/* k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[375]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 895  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[376],((C_word*)t0)[6],lf[377]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[329]);
if(C_truep(t5)){
/* c-backend.scm: 896  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[6],lf[379]);}
else{
t6=t2;
f_5529(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 897  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[374]);}

/* k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5597,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 898  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[5],lf[373]);}

/* k5595 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 898  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k5591 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 899  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[371],((C_word*)t0)[5],lf[372]);}

/* k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 901  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[369],((C_word*)t0)[2],lf[370]);}

/* k5539 in k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5542 in k5539 in k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 903  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[367],((C_word*)t0)[3],lf[368]);}

/* k5545 in k5542 in k5539 in k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 904  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[366]);}

/* k5548 in k5545 in k5542 in k5539 in k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5568,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5568(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1186 in k5548 in k5545 in k5542 in k5539 in k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5568,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5578,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 908  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[365],t2,C_make_character(59));}}

/* k5576 in doloop1186 in k5548 in k5545 in k5542 in k5539 in k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5568(t4,((C_word*)t0)[2],t2,t3);}

/* k5551 in k5548 in k5545 in k5542 in k5539 in k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5506 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 909  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[363],((C_word*)t0)[3],lf[364]);}
else{
t3=((C_word*)t0)[2];
f_5488(2,t3,C_SCHEME_UNDEFINED);}}

/* k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5491,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5498,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 920  lambda-literal-body */
((C_proc3)C_retrieve_symbol_proc(lf[362]))(3,*((C_word*)lf[362]+1),t3,((C_word*)t0)[2]);}

/* k5496 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 919  expression */
t3=((C_word*)t0)[4];
f_2543(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5489 in k5486 in k5483 in k5480 in k5477 in k5474 in k5471 in k5468 in k5465 in k5462 in k5459 in k5456 in k5453 in k5450 in k5447 in k5444 in k5441 in k5438 in k5435 in k5432 in k5429 in k5426 in k5423 in k5420 in k5417 in k5414 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in a5387 in procedures in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 925  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4992,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 687  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[361]))(3,*((C_word*)lf[361]+1),t3,t2);}

/* k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[355]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 691  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4992(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5059,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5063,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 692  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[358]+1)))(3,*((C_word*)lf[358]+1),t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 693  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}}}}}}

/* k5071 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5073,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 694  bad-literal */
f_4986(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 696  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[360]+1)))(3,*((C_word*)lf[360]+1),t2,((C_word*)t0)[4]);}}}}

/* k5089 in k5071 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5091,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 696  words */
((C_proc3)C_retrieve_symbol_proc(lf[359]))(3,*((C_word*)lf[359]+1),t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5120(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 703  bad-literal */
f_4986(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k5089 in k5071 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5120,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5142,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 702  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4992(3,t8,t6,t7);}}

/* k5140 in loop in k5089 in k5071 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 702  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5120(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5096 in k5089 in k5071 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k5065 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k5061 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 692  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[356]))(5,*((C_word*)lf[356]+1),((C_word*)t0)[2],*((C_word*)lf[357]+1),C_fix(0),t1);}

/* k5057 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k5028 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5034,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 691  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4992(3,t4,t2,t3);}

/* k5032 in k5028 in k4997 in literal-size in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4949,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4955(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop831 in literal-frame in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4955(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4955,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4965,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4984,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 681  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[354],t2);}}

/* k4982 in doloop831 in literal-frame in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 681  gen-lit */
t2=((C_word*)t0)[4];
f_5151(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4963 in doloop831 in literal-frame in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4955(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5151(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5151,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5291,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 707  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t5,t2);}
else{
t5=t4;
f_5158(t5,C_SCHEME_FALSE);}}

/* k5289 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5158(t2,(C_word)C_i_not(t1));}

/* k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5158,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 708  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[336],((C_word*)t0)[4],lf[337]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 709  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}

/* k5162 in k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[338]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 711  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[339]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[340]:lf[341]);
/* c-backend.scm: 713  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 715  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[342],t4,lf[343]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 718  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 723  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[347]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5247(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_5247(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5245 in k5162 in k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5247,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 727  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[350]);}
else{
/* c-backend.scm: 730  bad-literal */
f_4986(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k5248 in k5245 in k5162 in k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5253,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5260,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 728  encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t3,((C_word*)t0)[2]);}

/* k5258 in k5248 in k5245 in k5162 in k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 728  gen-string-constant */
t2=((C_word*)t0)[3];
f_5293(t2,((C_word*)t0)[2],t1);}

/* k5251 in k5248 in k5245 in k5162 in k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 729  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[348]);}

/* k5212 in k5162 in k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5220,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 720  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[346]);}

/* k5218 in k5212 in k5162 in k5156 in gen-lit in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 721  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[5],lf[344],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[345]);}

/* bad-literal in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4986(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4986,NULL,2,t1,t2);}
/* c-backend.scm: 684  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t1,lf[335],t2);}

/* gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5293,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5300,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 734  fx/ */
((C_proc4)C_retrieve_proc(*((C_word*)lf[334]+1)))(4,*((C_word*)lf[334]+1),t4,t3,C_fix(80));}

/* k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5303,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 735  modulo */
((C_proc4)C_retrieve_proc(*((C_word*)lf[333]+1)))(4,*((C_word*)lf[333]+1),t2,((C_word*)t0)[5],C_fix(80));}

/* k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5303,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5308,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5308(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop917 in k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5308(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5308,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5324(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5324(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5345,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5364,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 741  string-like-substring */
f_5370(t7,((C_word*)t0)[4],t3,t8);}}

/* k5362 in doloop917 in k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 741  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5358 in doloop917 in k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 741  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5343 in doloop917 in k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5308(t4,((C_word*)t0)[2],t2,t3);}

/* k5322 in doloop917 in k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5324,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5331,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 740  string-like-substring */
f_5370(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5333 in k5322 in doloop917 in k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5329 in k5322 in doloop917 in k5301 in k5298 in gen-string-constant in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_5370(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5370,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5377,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 745  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[332]+1)))(3,*((C_word*)lf[332]+1),t6,t5);}

/* k5375 in string-like-substring in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5380,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 746  ##sys#copy-bytes */
((C_proc7)C_retrieve_symbol_proc(lf[331]))(7,*((C_word*)lf[331]+1),t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5378 in k5375 in string-like-substring in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4663,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4666,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4702,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4782,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4830,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4834,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 640  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 641  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t4,((C_word*)t0)[2]);}

/* k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 642  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 643  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 644  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4947,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 645  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4849(t3,C_SCHEME_FALSE);}}

/* k4945 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4849(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4849,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4852(t5,t4);}
else{
t3=t2;
f_4852(t3,C_SCHEME_UNDEFINED);}}

/* k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4852,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 647  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 649  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[325],((C_word*)t0)[9],lf[326],C_SCHEME_TRUE,lf[327],((C_word*)t0)[9],lf[328]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4892(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 657  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t3,((C_word*)t0)[2]);}}}}

/* k4934 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4892(2,t3,t2);}
else{
/* c-backend.scm: 657  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4890 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[244]);
t4=t2;
f_4898(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4898(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4896 in k4890 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4898,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[329]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 660  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4912,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 661  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 662  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t2,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4914 in k4896 in k4890 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4910 in k4896 in k4890 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4906 in k4896 in k4890 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4862 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 651  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[323],((C_word*)t0)[3],lf[324]);}

/* k4865 in k4862 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 652  restore */
f_4666(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4868 in k4865 in k4862 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 653  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4871 in k4868 in k4865 in k4862 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 654  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)((C_word*)t0)[2])[1],lf[322]);}

/* k4874 in k4871 in k4868 in k4865 in k4862 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4886,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 655  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,t1,C_make_character(44));}

/* k4884 in k4874 in k4871 in k4868 in k4865 in k4862 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in a4829 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 656  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[321]);}

/* k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4801,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 666  gen */
((C_proc13)C_retrieve_symbol_proc(lf[1]))(13,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[316],t2,lf[317],C_SCHEME_TRUE,lf[318],t2,lf[319],t2,lf[320]);}

/* k4803 in a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 668  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[313],((C_word*)t0)[3],lf[314],((C_word*)t0)[3],lf[315]);}

/* k4806 in k4803 in a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 669  restore */
f_4666(t2,((C_word*)t0)[3]);}

/* k4809 in k4806 in k4803 in a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 670  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[312],((C_word*)t0)[2],C_make_character(44));}

/* k4812 in k4809 in k4806 in k4803 in a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4824,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4828,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 671  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[311]);}

/* k4826 in k4812 in k4809 in k4806 in k4803 in a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 671  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4822 in k4812 in k4809 in k4806 in k4803 in a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4815 in k4812 in k4809 in k4806 in k4803 in a4800 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 672  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[310]);}

/* k4783 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 674  emitter */
t4=((C_word*)t0)[3];
f_4702(t4,t3,C_SCHEME_FALSE);}

/* k4797 in k4783 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4786 in k4783 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 675  emitter */
t3=((C_word*)t0)[2];
f_4702(t3,t2,C_SCHEME_TRUE);}

/* k4793 in k4786 in k4783 in k4780 in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4702,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4704 in emitter in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4704,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[305]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[306]);
/* c-backend.scm: 618  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[307],t2,C_make_character(114),t4,lf[308],C_SCHEME_TRUE,lf[309],t2,C_make_character(114),t5);}

/* k4706 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 620  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[303],((C_word*)t0)[4],lf[304]);}

/* k4709 in k4706 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 621  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[302],((C_word*)t0)[4],C_make_character(114));}

/* k4712 in k4709 in k4706 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 622  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t3=t2;
f_4717(2,t3,C_SCHEME_UNDEFINED);}}

/* k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 623  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,lf[298],((C_word*)t0)[4],lf[299],C_SCHEME_TRUE,lf[300],C_SCHEME_TRUE,lf[301],((C_word*)t0)[4],C_make_character(59));}

/* k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 626  restore */
f_4666(t2,((C_word*)t0)[4]);}

/* k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 627  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[297]);}

/* k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 629  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[295]);}
else{
/* c-backend.scm: 630  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[296]);}}

/* k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 631  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[294]);}

/* k4730 in k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 632  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[293]);}
else{
t3=t2;
f_4735(2,t3,C_SCHEME_UNDEFINED);}}

/* k4733 in k4730 in k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 633  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[292]);}

/* k4736 in k4733 in k4730 in k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 634  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[291]);}

/* k4739 in k4736 in k4733 in k4730 in k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 635  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,t5,lf[290]);}

/* k4753 in k4739 in k4736 in k4733 in k4730 in k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 635  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4749 in k4739 in k4736 in k4733 in k4730 in k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4742 in k4739 in k4736 in k4733 in k4730 in k4727 in k4724 in k4721 in k4718 in k4715 in k4712 in k4709 in k4706 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 636  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[288]);}

/* restore in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4666(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4666,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4670,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4679,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4679(t8,t3,t4,C_fix(0));}

/* doloop732 in restore in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4679,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4689,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 613  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[285],t2,lf[286],t3,lf[287]);}}

/* k4687 in doloop732 in restore in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4679(t4,((C_word*)t0)[2],t2,t3);}

/* k4668 in restore in trampolines in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 614  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[283],((C_word*)t0)[2],lf[284]);}

/* prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4412,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 542  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE);}

/* k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4444,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 545  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 546  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4661,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 547  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4450(t3,C_SCHEME_FALSE);}}

/* k4659 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4450(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4450,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4647,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 548  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t3,t4,lf[280]);}

/* k4645 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 548  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 549  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 550  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[2]);}

/* k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 551  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 552  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 553  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[2]);}

/* k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4639,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 555  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4471(t5,C_SCHEME_UNDEFINED);}}

/* k4637 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4471(t3,t2);}

/* k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4471,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 556  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4477,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4632,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 561  lambda-literal-callee-signatures */
((C_proc3)C_retrieve_symbol_proc(lf[274]))(3,*((C_word*)lf[274]+1),t4,((C_word*)t0)[2]);}

/* k4630 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4612 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4613,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4624,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 560  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4622 in a4612 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 571  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,C_retrieve(lf[206]),lf[262]);}
else{
t5=t4;
f_4589(2,t5,lf[263]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 563  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,lf[269],((C_word*)t0)[5],lf[270],C_SCHEME_TRUE);}}

/* k4562 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 564  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[268]);}

/* k4565 in k4562 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[266]:lf[267]);
/* c-backend.scm: 565  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k4568 in k4565 in k4562 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 567  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[264]);}
else{
/* c-backend.scm: 568  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[265]);}}

/* k4571 in k4568 in k4565 in k4562 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 569  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4587 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4592,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 572  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,lf[260],t1,lf[261],C_SCHEME_TRUE);}

/* k4590 in k4587 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[258]))){
/* c-backend.scm: 574  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[259],C_SCHEME_TRUE);}
else{
t3=t2;
f_4595(2,t3,C_SCHEME_UNDEFINED);}}

/* k4593 in k4590 in k4587 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 575  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[257]);}

/* k4596 in k4593 in k4590 in k4587 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 576  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[256],((C_word*)t0)[2]);}

/* k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 577  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4486(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 578  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[254]);}}

/* k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4536,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4536(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4536(t4,C_SCHEME_FALSE);}}

/* k4534 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4536,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 580  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[253]);}
else{
t2=((C_word*)t0)[2];
f_4489(2,t2,C_SCHEME_UNDEFINED);}}

/* k4537 in k4534 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 581  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4489(2,t2,C_SCHEME_UNDEFINED);}}

/* k4487 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[4]);}

/* k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4492,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 584  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[251]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 592  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k4522 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4527(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 594  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[252]);}}

/* k4525 in k4522 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 595  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k4496 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4498,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 587  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[247],((C_word*)t0)[2],lf[248],C_SCHEME_TRUE,lf[249],((C_word*)t0)[2],lf[250]);}}

/* k4505 in k4496 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k4508 in k4505 in k4496 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4472 in k4469 in k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in a4439 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 590  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[245],t2,lf[246]);}

/* k4417 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4424,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4423 in k4417 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4424,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4428,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 599  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[242],t2,lf[243]);}

/* k4426 in a4423 in k4417 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4438,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 600  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t3,((C_word*)t0)[2],lf[241]);}

/* k4436 in k4426 in a4423 in k4417 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4429 in k4426 in a4423 in k4417 in k4414 in prototypes in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 601  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[239]);}

/* declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4263,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4270,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 513  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[238]);}

/* k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4406,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[208]));}

/* a4405 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4406,3,t0,t1,t2);}
/* c-backend.scm: 516  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[234],t2,lf[235],C_SCHEME_TRUE,lf[236],t2,lf[237]);}

/* k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4276(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 520  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[232],((C_word*)t0)[2],lf[233]);}}

/* k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 521  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[231]);}

/* k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4284,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4284(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4284,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4294,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 525  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t4,t5);}}

/* k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4294,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4300,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 527  gen */
((C_proc12)C_retrieve_symbol_proc(lf[1]))(12,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[228],((C_word*)t0)[5],lf[229],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4353(t6,t2,C_fix(0));}

/* doloop602 in k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4353(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4353,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4363,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 534  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_make_character(44),t6);}}

/* k4361 in doloop602 in k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4353(t3,((C_word*)t0)[2],t2);}

/* k4301 in k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4326,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4326(t9,t2,t5);}

/* doloop614 in k4301 in k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4326(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4326,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4336,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 537  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[227]);}}

/* k4334 in doloop614 in k4301 in k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4326(t3,((C_word*)t0)[2],t2);}

/* k4304 in k4301 in k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 538  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[226]);}

/* k4307 in k4304 in k4301 in k4298 in k4292 in doloop586 in k4277 in k4274 in k4271 in k4268 in declarations in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4284(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4116,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4119,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4136,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4255,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 479  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t4);}

/* k4253 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 479  ##sys#decode-seconds */
((C_proc4)C_retrieve_symbol_proc(lf[224]))(4,*((C_word*)lf[224]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4136,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4213,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 487  pad0 */
f_4119(t9,t10);}

/* k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 487  pad0 */
f_4119(t2,((C_word*)t0)[2]);}

/* k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 487  pad0 */
f_4119(t2,((C_word*)t0)[2]);}

/* k4219 in k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4225,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 487  pad0 */
f_4119(t2,((C_word*)t0)[2]);}

/* k4223 in k4219 in k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4229,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4233,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4235,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4243,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4247,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 490  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t6,C_SCHEME_TRUE);}

/* k4245 in k4223 in k4219 in k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 490  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),((C_word*)t0)[2],t1,lf[222]);}

/* k4241 in k4223 in k4219 in k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4234 in k4223 in k4219 in k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4235,3,t0,t1,t2);}
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,lf[218],t2,lf[219]);}

/* k4231 in k4223 in k4219 in k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 488  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[217]);}

/* k4227 in k4223 in k4219 in k4215 in k4211 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 485  gen */
((C_proc21)C_retrieve_symbol_proc(lf[1]))(21,*((C_word*)lf[1]+1),((C_word*)t0)[8],lf[211],((C_word*)t0)[7],lf[212],C_SCHEME_TRUE,lf[213],C_SCHEME_TRUE,lf[214],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[215]);}

/* k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 493  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),t2,C_retrieve(lf[210]));}

/* k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 494  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 495  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[207],C_retrieve(lf[206]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4202,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 497  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,lf[209]);}}

/* k4200 in k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 498  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),((C_word*)t0)[2],C_retrieve(lf[208]));}

/* k4161 in k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 499  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[202],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[203],C_retrieve(lf[204]),lf[205]);}

/* k4164 in k4161 in k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[198]))){
/* c-backend.scm: 501  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t2,C_retrieve(lf[200]));}
else{
t3=t2;
f_4169(2,t3,C_SCHEME_UNDEFINED);}}

/* k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[201])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 503  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_4172(2,t3,C_SCHEME_UNDEFINED);}}

/* k4182 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4189,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[201]));}

/* a4188 in k4182 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4189,3,t0,t1,t2);}
/* c-backend.scm: 504  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,t2);}

/* k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4134 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[198]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 506  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),((C_word*)t0)[2],C_retrieve(lf[200]));}}

/* pad0 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4119(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4119,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4133,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 477  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4131 in pad0 in header in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 477  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[197],t1);}

/* expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_2543(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2543,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4084,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 472  expr */
t11=((C_word*)t6)[1];
f_2546(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4084,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4090,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 466  pair-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[196]))(4,*((C_word*)lf[196]+1),t1,t4,t2);}

/* a4089 in expr-args in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4090,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_4094(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 468  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}}

/* k4092 in a4089 in expr-args in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 469  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2546(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_2546(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2546,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[16]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[17]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[18]:lf[19]);
/* c-backend.scm: 125  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 126  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[21],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t14)){
/* c-backend.scm: 127  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[23]);}
else{
t15=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 128  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[25],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[26]);
if(C_truep(t16)){
/* c-backend.scm: 129  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[27]);}
else{
/* c-backend.scm: 130  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t1,lf[28]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[29]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 135  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[30],t13,lf[31]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 136  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[32],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[33]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2670,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 139  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t13,C_SCHEME_TRUE,lf[36]);}
else{
t13=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 148  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,lf[38],t14);}
else{
t14=(C_word)C_eqp(t9,lf[39]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[6],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_2728(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[40]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2779,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 160  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t16,lf[42]);}
else{
t16=(C_word)C_eqp(t9,lf[43]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2806,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 165  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t17,lf[45]);}
else{
t17=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2825,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 170  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t18,lf[47]);}
else{
t18=(C_word)C_eqp(t9,lf[48]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2858,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 177  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t19,lf[51]);}
else{
t19=(C_word)C_eqp(t9,lf[52]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2895,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 184  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t20,lf[54]);}
else{
t20=(C_word)C_eqp(t9,lf[55]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2924,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 191  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t21,lf[57]);}
else{
t21=(C_word)C_eqp(t9,lf[58]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2956,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 199  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t23,lf[65],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[66]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 209  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t23,lf[68]);}
else{
t23=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 213  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[70]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3023,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 216  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[71]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 225  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[72],t26,lf[73]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3065,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3069,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 226  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 227  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[78],t26,lf[79]);}
else{
/* c-backend.scm: 228  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[80],t26,lf[81]);}}}
else{
t26=(C_word)C_eqp(t9,lf[82]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(C_word)C_i_caddr(t7);
t30=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3100,a[2]=t29,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t28)){
/* c-backend.scm: 235  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t30,lf[85],t27,lf[86]);}
else{
/* c-backend.scm: 236  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t30,lf[87],t27,lf[88]);}}
else{
t27=(C_word)C_eqp(t9,lf[89]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
t29=(C_word)C_i_cadr(t7);
t30=(C_word)C_i_caddr(t7);
if(C_truep(t29)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3148,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3162,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3166,a[2]=t32,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 247  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t33,t30);}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3169,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3183,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3187,a[2]=t32,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 252  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t33,t30);}}
else{
t28=(C_word)C_eqp(t9,lf[96]);
if(C_truep(t28)){
/* c-backend.scm: 256  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[97]);}
else{
t29=(C_word)C_eqp(t9,lf[98]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3220,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t36,a[6]=t32,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],a[9]=t31,a[10]=t33,a[11]=t3,a[12]=t30,a[13]=((C_word*)t0)[4],a[14]=t1,a[15]=t5,a[16]=t7,tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 265  source-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3644,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 349  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[151]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3729,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3733,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 377  find-lambda */
t41=((C_word*)t0)[2];
f_2501(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3752,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 394  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t35,C_SCHEME_TRUE,lf[155],t36,lf[156],t34,lf[157]);}
else{
t33=(C_word)C_eqp(t9,lf[158]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3771,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 399  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t34,C_SCHEME_TRUE,lf[160]);}
else{
t34=(C_word)C_eqp(t9,lf[161]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3790,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 404  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t35,lf[162],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[163]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3809,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 409  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t36,lf[164],t37,lf[165],t38);}
else{
t36=(C_word)C_eqp(t9,lf[166]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3845,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 417  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t37,t38,lf[168]);}
else{
t37=(C_word)C_eqp(t9,lf[169]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3865,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 421  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t41,t38,lf[174]);}
else{
t38=(C_word)C_eqp(t9,lf[175]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3899,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3913,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 427  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t41,t39,lf[180]);}
else{
t39=(C_word)C_eqp(t9,lf[181]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3929,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3957,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 433  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t42,t40,lf[186]);}
else{
t40=(C_word)C_eqp(t9,lf[187]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3966,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 440  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t41,C_SCHEME_TRUE,lf[191]);}
else{
t41=(C_word)C_eqp(t9,lf[192]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4049,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 455  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t42,lf[194]);}
else{
/* c-backend.scm: 463  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t1,lf[195]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4047 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 456  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k4050 in k4047 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 457  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[193]);}

/* k4053 in k4050 in k4047 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 458  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k4056 in k4053 in k4050 in k4047 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 459  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4059 in k4056 in k4053 in k4050 in k4047 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 460  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 461  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 441  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2546(t4,t2,t3,((C_word*)t0)[3]);}

/* k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 442  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[190]);}

/* k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3985,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3985(t7,((C_word*)t0)[2],t2,t3);}

/* doloop491 in k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3985,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 446  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[188]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 449  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[189]);}}

/* k4006 in doloop491 in k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 450  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k4009 in k4006 in doloop491 in k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 451  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4012 in k4009 in k4006 in doloop491 in k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 452  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k4015 in k4012 in k4009 in k4006 in doloop491 in k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3985(t4,((C_word*)t0)[2],t2,t3);}

/* k3993 in doloop491 in k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 447  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3996 in k3993 in doloop491 in k3970 in k3967 in k3964 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 448  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* k3955 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 433  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[184],t1,lf[185]);}

/* k3927 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 434  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2546(t4,t2,t3,((C_word*)t0)[3]);}

/* k3930 in k3927 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3949,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 435  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t3,((C_word*)t0)[2]);}

/* k3947 in k3930 in k3927 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 435  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[183],t1);}

/* k3933 in k3930 in k3927 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 436  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3936 in k3933 in k3930 in k3927 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 437  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[182]);}

/* k3911 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3917,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 427  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[179]);}

/* k3915 in k3911 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 427  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[177],t1,lf[178]);}

/* k3897 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3900 in k3897 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 429  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[176]);}

/* k3881 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3887,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 421  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k3885 in k3881 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 421  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[171],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3863 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3866 in k3863 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 423  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[170]);}

/* k3843 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 417  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3807 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3812,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 412  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}
else{
t3=t2;
f_3812(2,t3,C_SCHEME_UNDEFINED);}}

/* k3819 in k3807 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 413  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4084(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3810 in k3807 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 414  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3788 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 405  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4084(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3791 in k3788 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 406  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3769 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 400  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3772 in k3769 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 401  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[159]);}

/* k3750 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 395  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4084(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3753 in k3750 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 396  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[154]);}

/* k3731 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 377  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3727 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 379  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],C_make_character(40));}

/* k3675 in k3727 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3680,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3710,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 381  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,lf[152],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3680(2,t3,C_SCHEME_UNDEFINED);}}

/* k3708 in k3675 in k3727 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 382  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_3680(2,t4,C_SCHEME_UNDEFINED);}}

/* k3678 in k3675 in k3727 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3683(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3698,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 384  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3696 in k3678 in k3675 in k3727 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 385  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3683(2,t2,C_SCHEME_UNDEFINED);}}

/* k3681 in k3678 in k3675 in k3727 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 386  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4084(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3686(2,t3,C_SCHEME_UNDEFINED);}}

/* k3684 in k3681 in k3678 in k3675 in k3727 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 387  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3587,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 351  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3628,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 364  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3626 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3631(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 365  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[150]);}}

/* k3629 in k3626 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 366  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4084(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3632 in k3629 in k3626 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 367  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 352  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 353  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3610 in k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3611,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 355  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3613 in a3610 in k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 356  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2546(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3616 in k3613 in a3610 in k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 357  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3591 in k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3596,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3601,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 361  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3607 in k3591 in k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 359  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3600 in k3591 in k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3601,4,t0,t1,t2,t3);}
/* c-backend.scm: 360  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[149],t2,C_make_character(59));}

/* k3594 in k3591 in k3588 in k3585 in k3642 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 362  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[148]);}

/* k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[16]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3223(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[16]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3223(t3,C_SCHEME_FALSE);}}

/* k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_3223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3223,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[16]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3533,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 268  find-lambda */
t6=((C_word*)t0)[2];
f_2501(t6,t5,t1);}
else{
t4=t3;
f_3229(t4,C_SCHEME_FALSE);}}

/* k3535 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 268  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3531 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3229(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_3229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3229,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_retrieve(lf[137]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3519,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 112  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3526,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 273  uncommentify */
f_2533(t4,((C_word*)t0)[3]);}}
else{
t4=t3;
f_3235(2,t4,C_SCHEME_UNDEFINED);}}

/* k3524 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 273  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[143],t1,lf[144]);}

/* k2529 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 112  string-translate */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[2],t1,lf[141],lf[142]);}

/* k3517 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 272  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[138],t1,lf[139]);}

/* k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[37],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 276  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[100]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 280  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t6=(C_word)C_eqp(lf[71],t5);
if(C_truep(t6)){
t7=C_retrieve(lf[129]);
if(C_truep(t7)){
t8=t4;
f_3362(t8,C_SCHEME_FALSE);}
else{
t8=C_retrieve(lf[134]);
if(C_truep(t8)){
t9=t4;
f_3362(t9,C_SCHEME_FALSE);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=t4;
f_3362(t10,(C_word)C_i_not(t9));}}}
else{
t7=t4;
f_3362(t7,C_SCHEME_FALSE);}}}}

/* k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_3362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3377,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 314  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t8,C_SCHEME_TRUE,lf[124],((C_word*)t0)[5],lf[125]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 333  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}

/* k3444 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 334  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2546(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3447 in k3444 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 335  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(59),C_SCHEME_TRUE,lf[135],((C_word*)t0)[4],lf[136]);}

/* k3450 in k3447 in k3444 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[129]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3467(t5,t3);}
else{
t5=C_retrieve(lf[134]);
t6=t4;
f_3467(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3465 in k3450 in k3447 in k3444 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_3467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 338  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[130],((C_word*)t0)[2],lf[131]);}
else{
/* c-backend.scm: 339  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[132],((C_word*)t0)[2],lf[133]);}}

/* k3453 in k3450 in k3447 in k3444 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 340  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[127],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],C_make_character(44));}

/* k3456 in k3453 in k3450 in k3447 in k3444 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 341  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4084(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3459 in k3456 in k3453 in k3450 in k3447 in k3444 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 342  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[126]);}

/* k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 316  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3432,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 323  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3443,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 327  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}}}

/* k3441 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 327  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* k3434 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* c-backend.scm: 328  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[120],((C_word*)t0)[2],lf[121]);}

/* k3430 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 323  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[118],t1,lf[119]);}

/* k3423 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
/* c-backend.scm: 324  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[116],((C_word*)((C_word*)t0)[3])[1],lf[117]);}

/* k3416 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 316  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[114],t1,lf[115]);}

/* k3391 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3393,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 318  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[109],((C_word*)((C_word*)t0)[5])[1],lf[110]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3410,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
/* c-backend.scm: 320  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,t5);}}

/* k3408 in k3391 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 320  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3404 in k3391 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 319  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[111],((C_word*)((C_word*)t0)[2])[1],lf[112],t1,C_make_character(41));}

/* k3378 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 329  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[108],((C_word*)t0)[3],C_make_character(44),((C_word*)((C_word*)t0)[2])[1],C_make_character(44));}

/* k3381 in k3378 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 330  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4084(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3384 in k3381 in k3378 in k3375 in k3360 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 331  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[107]);}

/* k3354 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 281  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3266(2,t3,C_SCHEME_FALSE);}}

/* k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 282  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3316(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 297  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3338 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 298  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2546(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3341 in k3338 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 299  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3314 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 300  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3317 in k3314 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3322(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 301  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3320 in k3317 in k3314 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3325(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 302  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k3323 in k3320 in k3317 in k3314 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 303  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4084(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3326 in k3323 in k3320 in k3317 in k3314 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 304  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[105]);}

/* k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 283  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 284  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3298 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3299,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3303,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 286  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3301 in a3298 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3306,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 287  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2546(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3304 in k3301 in a3298 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 288  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3273 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3289,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 292  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3295 in k3273 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 290  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3288 in k3273 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3289,4,t0,t1,t2,t3);}
/* c-backend.scm: 291  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[103],t2,C_make_character(59));}

/* k3276 in k3273 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3281(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 293  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[102],((C_word*)t0)[2],C_make_character(59));}}

/* k3279 in k3276 in k3273 in k3270 in k3267 in k3264 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 294  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[101]);}

/* k3245 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 277  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4084(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3248 in k3245 in k3233 in k3227 in k3221 in k3218 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 278  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[99]);}

/* k3185 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 252  uncommentify */
f_2533(((C_word*)t0)[2],t1);}

/* k3181 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95]);}

/* k3167 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 253  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3170 in k3167 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 254  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3164 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  uncommentify */
f_2533(((C_word*)t0)[2],t1);}

/* k3160 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 246  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92]);}

/* k3146 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 248  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3149 in k3146 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 249  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3098 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3117,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3121,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 237  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,((C_word*)t0)[2]);}

/* k3119 in k3098 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 237  uncommentify */
f_2533(((C_word*)t0)[2],t1);}

/* k3115 in k3098 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 237  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[83],t1,lf[84]);}

/* k3101 in k3098 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 238  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k3104 in k3101 in k3098 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3067 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 226  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3063 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 226  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[74],((C_word*)t0)[2],lf[75],t1,C_make_character(41));}

/* k3021 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 217  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2546(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2989 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 210  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2992 in k2989 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 211  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[67]);}

/* k2954 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 205  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2980 in k2954 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 200  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2967 in k2954 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2968,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 202  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t4,lf[61],t3,lf[62]);}

/* k2970 in a2967 in k2954 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 203  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2546(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2973 in k2970 in a2967 in k2954 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 204  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}

/* k2957 in k2954 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 206  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[59],t2,lf[60]);}

/* k2922 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 192  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2925 in k2922 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[56]);}

/* k2928 in k2925 in k2922 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2931 in k2928 in k2925 in k2922 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 195  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2893 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 185  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2896 in k2893 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[53]);}

/* k2899 in k2896 in k2893 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2902 in k2899 in k2896 in k2893 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 188  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2856 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 178  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2546(t4,t2,t3,((C_word*)t0)[3]);}

/* k2859 in k2856 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 179  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[49],t4,lf[50]);}

/* k2862 in k2859 in k2856 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2865 in k2862 in k2859 in k2856 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 181  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2823 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 171  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2546(t4,t2,t3,((C_word*)t0)[3]);}

/* k2826 in k2823 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 172  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(44),t3,C_make_character(44));}

/* k2829 in k2826 in k2823 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2832 in k2829 in k2826 in k2823 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 174  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2804 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 166  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2807 in k2804 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 167  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[44]);}

/* k2777 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 161  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2780 in k2777 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 162  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[41],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2728,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 153  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 157  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2546(t7,t1,t6,t3);}}

/* k2736 in loop in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 154  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2546(t4,t2,t3,((C_word*)t0)[6]);}

/* k2739 in k2736 in loop in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 155  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k2742 in k2739 in k2736 in loop in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 156  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2728(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2668 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 140  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2671 in k2668 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[35]);}

/* k2674 in k2671 in k2668 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2677 in k2674 in k2671 in k2668 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(125),C_SCHEME_TRUE,lf[34]);}

/* k2680 in k2677 in k2674 in k2671 in k2668 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2546(t4,t2,t3,((C_word*)t0)[2]);}

/* k2683 in k2680 in k2677 in k2674 in k2671 in k2668 in expr in expression in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 145  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* uncommentify in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_2533(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2533,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2541,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 113  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k2539 in uncommentify in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 113  string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,lf[14]);}

/* find-lambda in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2501,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 109  find */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t3,t4,((C_word*)t0)[2]);}

/* a2512 in find-lambda in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2513,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 109  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k2519 in a2512 in find-lambda in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2503 in find-lambda in ##compiler#generate-code in k2494 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 110  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2478,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2484,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 91   intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t4,t2,C_make_character(32));}

/* k2490 in ##compiler#gen-list in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2483 in ##compiler#gen-list in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2484,3,t0,t1,t2);}
/* c-backend.scm: 90   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}

/* ##compiler#gen in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_2457r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2457r(t0,t1,t2);}}

static void C_ccall f_2457r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2463,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a2462 in ##compiler#gen in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2463,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 84   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t1,C_retrieve(lf[0]));}
else{
/* c-backend.scm: 85   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[664] = {
{"toplevel:c_backend_scm",(void*)C_backend_toplevel},
{"f_2439:c_backend_scm",(void*)f_2439},
{"f_2442:c_backend_scm",(void*)f_2442},
{"f_2445:c_backend_scm",(void*)f_2445},
{"f_2448:c_backend_scm",(void*)f_2448},
{"f_2451:c_backend_scm",(void*)f_2451},
{"f_2454:c_backend_scm",(void*)f_2454},
{"f_9162:c_backend_scm",(void*)f_9162},
{"f_9166:c_backend_scm",(void*)f_9166},
{"f_9158:c_backend_scm",(void*)f_9158},
{"f_2496:c_backend_scm",(void*)f_2496},
{"f_8858:c_backend_scm",(void*)f_8858},
{"f_9134:c_backend_scm",(void*)f_9134},
{"f_9132:c_backend_scm",(void*)f_9132},
{"f_9120:c_backend_scm",(void*)f_9120},
{"f_9090:c_backend_scm",(void*)f_9090},
{"f_9051:c_backend_scm",(void*)f_9051},
{"f_9038:c_backend_scm",(void*)f_9038},
{"f_9034:c_backend_scm",(void*)f_9034},
{"f_8920:c_backend_scm",(void*)f_8920},
{"f_8867:c_backend_scm",(void*)f_8867},
{"f_8460:c_backend_scm",(void*)f_8460},
{"f_8547:c_backend_scm",(void*)f_8547},
{"f_8628:c_backend_scm",(void*)f_8628},
{"f_8650:c_backend_scm",(void*)f_8650},
{"f_8462:c_backend_scm",(void*)f_8462},
{"f_7975:c_backend_scm",(void*)f_7975},
{"f_8005:c_backend_scm",(void*)f_8005},
{"f_8032:c_backend_scm",(void*)f_8032},
{"f_8227:c_backend_scm",(void*)f_8227},
{"f_8236:c_backend_scm",(void*)f_8236},
{"f_8245:c_backend_scm",(void*)f_8245},
{"f_8267:c_backend_scm",(void*)f_8267},
{"f_8344:c_backend_scm",(void*)f_8344},
{"f_7977:c_backend_scm",(void*)f_7977},
{"f_7139:c_backend_scm",(void*)f_7139},
{"f_7216:c_backend_scm",(void*)f_7216},
{"f_7318:c_backend_scm",(void*)f_7318},
{"f_7351:c_backend_scm",(void*)f_7351},
{"f_7447:c_backend_scm",(void*)f_7447},
{"f_7462:c_backend_scm",(void*)f_7462},
{"f_7502:c_backend_scm",(void*)f_7502},
{"f_7519:c_backend_scm",(void*)f_7519},
{"f_7536:c_backend_scm",(void*)f_7536},
{"f_7575:c_backend_scm",(void*)f_7575},
{"f_7592:c_backend_scm",(void*)f_7592},
{"f_7609:c_backend_scm",(void*)f_7609},
{"f_7626:c_backend_scm",(void*)f_7626},
{"f_7643:c_backend_scm",(void*)f_7643},
{"f_7660:c_backend_scm",(void*)f_7660},
{"f_7677:c_backend_scm",(void*)f_7677},
{"f_7689:c_backend_scm",(void*)f_7689},
{"f_7696:c_backend_scm",(void*)f_7696},
{"f_7706:c_backend_scm",(void*)f_7706},
{"f_7704:c_backend_scm",(void*)f_7704},
{"f_7700:c_backend_scm",(void*)f_7700},
{"f_7667:c_backend_scm",(void*)f_7667},
{"f_7650:c_backend_scm",(void*)f_7650},
{"f_7633:c_backend_scm",(void*)f_7633},
{"f_7616:c_backend_scm",(void*)f_7616},
{"f_7599:c_backend_scm",(void*)f_7599},
{"f_7582:c_backend_scm",(void*)f_7582},
{"f_7547:c_backend_scm",(void*)f_7547},
{"f_7557:c_backend_scm",(void*)f_7557},
{"f_7555:c_backend_scm",(void*)f_7555},
{"f_7551:c_backend_scm",(void*)f_7551},
{"f_7543:c_backend_scm",(void*)f_7543},
{"f_7530:c_backend_scm",(void*)f_7530},
{"f_7513:c_backend_scm",(void*)f_7513},
{"f_7146:c_backend_scm",(void*)f_7146},
{"f_7141:c_backend_scm",(void*)f_7141},
{"f_7074:c_backend_scm",(void*)f_7074},
{"f_7078:c_backend_scm",(void*)f_7078},
{"f_7081:c_backend_scm",(void*)f_7081},
{"f_7084:c_backend_scm",(void*)f_7084},
{"f_7087:c_backend_scm",(void*)f_7087},
{"f_7093:c_backend_scm",(void*)f_7093},
{"f_7137:c_backend_scm",(void*)f_7137},
{"f_7096:c_backend_scm",(void*)f_7096},
{"f_7104:c_backend_scm",(void*)f_7104},
{"f_7125:c_backend_scm",(void*)f_7125},
{"f_7108:c_backend_scm",(void*)f_7108},
{"f_7099:c_backend_scm",(void*)f_7099},
{"f_6643:c_backend_scm",(void*)f_6643},
{"f_6649:c_backend_scm",(void*)f_6649},
{"f_6653:c_backend_scm",(void*)f_6653},
{"f_6656:c_backend_scm",(void*)f_6656},
{"f_6659:c_backend_scm",(void*)f_6659},
{"f_6662:c_backend_scm",(void*)f_6662},
{"f_6668:c_backend_scm",(void*)f_6668},
{"f_7009:c_backend_scm",(void*)f_7009},
{"f_7012:c_backend_scm",(void*)f_7012},
{"f_7072:c_backend_scm",(void*)f_7072},
{"f_7015:c_backend_scm",(void*)f_7015},
{"f_7018:c_backend_scm",(void*)f_7018},
{"f_7021:c_backend_scm",(void*)f_7021},
{"f_7024:c_backend_scm",(void*)f_7024},
{"f_7057:c_backend_scm",(void*)f_7057},
{"f_7065:c_backend_scm",(void*)f_7065},
{"f_7027:c_backend_scm",(void*)f_7027},
{"f_7055:c_backend_scm",(void*)f_7055},
{"f_7030:c_backend_scm",(void*)f_7030},
{"f_7033:c_backend_scm",(void*)f_7033},
{"f_7036:c_backend_scm",(void*)f_7036},
{"f_6670:c_backend_scm",(void*)f_6670},
{"f_6680:c_backend_scm",(void*)f_6680},
{"f_6689:c_backend_scm",(void*)f_6689},
{"f_6701:c_backend_scm",(void*)f_6701},
{"f_6713:c_backend_scm",(void*)f_6713},
{"f_6719:c_backend_scm",(void*)f_6719},
{"f_6753:c_backend_scm",(void*)f_6753},
{"f_6410:c_backend_scm",(void*)f_6410},
{"f_6416:c_backend_scm",(void*)f_6416},
{"f_6420:c_backend_scm",(void*)f_6420},
{"f_6423:c_backend_scm",(void*)f_6423},
{"f_6426:c_backend_scm",(void*)f_6426},
{"f_6641:c_backend_scm",(void*)f_6641},
{"f_6432:c_backend_scm",(void*)f_6432},
{"f_6435:c_backend_scm",(void*)f_6435},
{"f_6438:c_backend_scm",(void*)f_6438},
{"f_6441:c_backend_scm",(void*)f_6441},
{"f_6444:c_backend_scm",(void*)f_6444},
{"f_6447:c_backend_scm",(void*)f_6447},
{"f_6450:c_backend_scm",(void*)f_6450},
{"f_6453:c_backend_scm",(void*)f_6453},
{"f_6456:c_backend_scm",(void*)f_6456},
{"f_6459:c_backend_scm",(void*)f_6459},
{"f_6630:c_backend_scm",(void*)f_6630},
{"f_6462:c_backend_scm",(void*)f_6462},
{"f_6465:c_backend_scm",(void*)f_6465},
{"f_6468:c_backend_scm",(void*)f_6468},
{"f_6471:c_backend_scm",(void*)f_6471},
{"f_6474:c_backend_scm",(void*)f_6474},
{"f_6477:c_backend_scm",(void*)f_6477},
{"f_6480:c_backend_scm",(void*)f_6480},
{"f_6483:c_backend_scm",(void*)f_6483},
{"f_6608:c_backend_scm",(void*)f_6608},
{"f_6578:c_backend_scm",(void*)f_6578},
{"f_6598:c_backend_scm",(void*)f_6598},
{"f_6586:c_backend_scm",(void*)f_6586},
{"f_6590:c_backend_scm",(void*)f_6590},
{"f_6594:c_backend_scm",(void*)f_6594},
{"f_6486:c_backend_scm",(void*)f_6486},
{"f_6489:c_backend_scm",(void*)f_6489},
{"f_6519:c_backend_scm",(void*)f_6519},
{"f_6522:c_backend_scm",(void*)f_6522},
{"f_6560:c_backend_scm",(void*)f_6560},
{"f_6556:c_backend_scm",(void*)f_6556},
{"f_6525:c_backend_scm",(void*)f_6525},
{"f_6528:c_backend_scm",(void*)f_6528},
{"f_6531:c_backend_scm",(void*)f_6531},
{"f_6498:c_backend_scm",(void*)f_6498},
{"f_6501:c_backend_scm",(void*)f_6501},
{"f_6492:c_backend_scm",(void*)f_6492},
{"f_6392:c_backend_scm",(void*)f_6392},
{"f_6398:c_backend_scm",(void*)f_6398},
{"f_6402:c_backend_scm",(void*)f_6402},
{"f_6405:c_backend_scm",(void*)f_6405},
{"f_6360:c_backend_scm",(void*)f_6360},
{"f_6364:c_backend_scm",(void*)f_6364},
{"f_6369:c_backend_scm",(void*)f_6369},
{"f_6390:c_backend_scm",(void*)f_6390},
{"f_6344:c_backend_scm",(void*)f_6344},
{"f_6350:c_backend_scm",(void*)f_6350},
{"f_6358:c_backend_scm",(void*)f_6358},
{"f_6328:c_backend_scm",(void*)f_6328},
{"f_6334:c_backend_scm",(void*)f_6334},
{"f_6342:c_backend_scm",(void*)f_6342},
{"f_6239:c_backend_scm",(void*)f_6239},
{"f_6248:c_backend_scm",(void*)f_6248},
{"f_6277:c_backend_scm",(void*)f_6277},
{"f_6287:c_backend_scm",(void*)f_6287},
{"f_6280:c_backend_scm",(void*)f_6280},
{"f_6264:c_backend_scm",(void*)f_6264},
{"f_6162:c_backend_scm",(void*)f_6162},
{"f_6166:c_backend_scm",(void*)f_6166},
{"f_6180:c_backend_scm",(void*)f_6180},
{"f_6193:c_backend_scm",(void*)f_6193},
{"f_6225:c_backend_scm",(void*)f_6225},
{"f_6196:c_backend_scm",(void*)f_6196},
{"f_6199:c_backend_scm",(void*)f_6199},
{"f_6169:c_backend_scm",(void*)f_6169},
{"f_6172:c_backend_scm",(void*)f_6172},
{"f_6175:c_backend_scm",(void*)f_6175},
{"f_2498:c_backend_scm",(void*)f_2498},
{"f_6129:c_backend_scm",(void*)f_6129},
{"f_6133:c_backend_scm",(void*)f_6133},
{"f_6136:c_backend_scm",(void*)f_6136},
{"f_6139:c_backend_scm",(void*)f_6139},
{"f_6142:c_backend_scm",(void*)f_6142},
{"f_6145:c_backend_scm",(void*)f_6145},
{"f_6148:c_backend_scm",(void*)f_6148},
{"f_6151:c_backend_scm",(void*)f_6151},
{"f_6154:c_backend_scm",(void*)f_6154},
{"f_6157:c_backend_scm",(void*)f_6157},
{"f_5382:c_backend_scm",(void*)f_5382},
{"f_5388:c_backend_scm",(void*)f_5388},
{"f_5392:c_backend_scm",(void*)f_5392},
{"f_5395:c_backend_scm",(void*)f_5395},
{"f_5398:c_backend_scm",(void*)f_5398},
{"f_5401:c_backend_scm",(void*)f_5401},
{"f_5404:c_backend_scm",(void*)f_5404},
{"f_5407:c_backend_scm",(void*)f_5407},
{"f_6126:c_backend_scm",(void*)f_6126},
{"f_5410:c_backend_scm",(void*)f_5410},
{"f_5416:c_backend_scm",(void*)f_5416},
{"f_5419:c_backend_scm",(void*)f_5419},
{"f_5422:c_backend_scm",(void*)f_5422},
{"f_5425:c_backend_scm",(void*)f_5425},
{"f_5428:c_backend_scm",(void*)f_5428},
{"f_5431:c_backend_scm",(void*)f_5431},
{"f_5434:c_backend_scm",(void*)f_5434},
{"f_5437:c_backend_scm",(void*)f_5437},
{"f_5440:c_backend_scm",(void*)f_5440},
{"f_5443:c_backend_scm",(void*)f_5443},
{"f_5446:c_backend_scm",(void*)f_5446},
{"f_5449:c_backend_scm",(void*)f_5449},
{"f_6095:c_backend_scm",(void*)f_6095},
{"f_5452:c_backend_scm",(void*)f_5452},
{"f_6056:c_backend_scm",(void*)f_6056},
{"f_6059:c_backend_scm",(void*)f_6059},
{"f_6062:c_backend_scm",(void*)f_6062},
{"f_6078:c_backend_scm",(void*)f_6078},
{"f_6081:c_backend_scm",(void*)f_6081},
{"f_5455:c_backend_scm",(void*)f_5455},
{"f_5458:c_backend_scm",(void*)f_5458},
{"f_5461:c_backend_scm",(void*)f_5461},
{"f_6028:c_backend_scm",(void*)f_6028},
{"f_6031:c_backend_scm",(void*)f_6031},
{"f_5464:c_backend_scm",(void*)f_5464},
{"f_5467:c_backend_scm",(void*)f_5467},
{"f_5470:c_backend_scm",(void*)f_5470},
{"f_5473:c_backend_scm",(void*)f_5473},
{"f_5476:c_backend_scm",(void*)f_5476},
{"f_5479:c_backend_scm",(void*)f_5479},
{"f_5990:c_backend_scm",(void*)f_5990},
{"f_6000:c_backend_scm",(void*)f_6000},
{"f_5482:c_backend_scm",(void*)f_5482},
{"f_5933:c_backend_scm",(void*)f_5933},
{"f_5945:c_backend_scm",(void*)f_5945},
{"f_5948:c_backend_scm",(void*)f_5948},
{"f_5954:c_backend_scm",(void*)f_5954},
{"f_5855:c_backend_scm",(void*)f_5855},
{"f_5897:c_backend_scm",(void*)f_5897},
{"f_5858:c_backend_scm",(void*)f_5858},
{"f_5864:c_backend_scm",(void*)f_5864},
{"f_5867:c_backend_scm",(void*)f_5867},
{"f_5873:c_backend_scm",(void*)f_5873},
{"f_5791:c_backend_scm",(void*)f_5791},
{"f_5794:c_backend_scm",(void*)f_5794},
{"f_5797:c_backend_scm",(void*)f_5797},
{"f_5800:c_backend_scm",(void*)f_5800},
{"f_5803:c_backend_scm",(void*)f_5803},
{"f_5818:c_backend_scm",(void*)f_5818},
{"f_5806:c_backend_scm",(void*)f_5806},
{"f_5809:c_backend_scm",(void*)f_5809},
{"f_5777:c_backend_scm",(void*)f_5777},
{"f_5785:c_backend_scm",(void*)f_5785},
{"f_5702:c_backend_scm",(void*)f_5702},
{"f_5708:c_backend_scm",(void*)f_5708},
{"f_5711:c_backend_scm",(void*)f_5711},
{"f_5745:c_backend_scm",(void*)f_5745},
{"f_5748:c_backend_scm",(void*)f_5748},
{"f_5751:c_backend_scm",(void*)f_5751},
{"f_5714:c_backend_scm",(void*)f_5714},
{"f_5717:c_backend_scm",(void*)f_5717},
{"f_5720:c_backend_scm",(void*)f_5720},
{"f_5723:c_backend_scm",(void*)f_5723},
{"f_5732:c_backend_scm",(void*)f_5732},
{"f_5735:c_backend_scm",(void*)f_5735},
{"f_5485:c_backend_scm",(void*)f_5485},
{"f_5508:c_backend_scm",(void*)f_5508},
{"f_5643:c_backend_scm",(void*)f_5643},
{"f_5646:c_backend_scm",(void*)f_5646},
{"f_5658:c_backend_scm",(void*)f_5658},
{"f_5649:c_backend_scm",(void*)f_5649},
{"f_5514:c_backend_scm",(void*)f_5514},
{"f_5517:c_backend_scm",(void*)f_5517},
{"f_5520:c_backend_scm",(void*)f_5520},
{"f_5624:c_backend_scm",(void*)f_5624},
{"f_5523:c_backend_scm",(void*)f_5523},
{"f_5526:c_backend_scm",(void*)f_5526},
{"f_5529:c_backend_scm",(void*)f_5529},
{"f_5532:c_backend_scm",(void*)f_5532},
{"f_5597:c_backend_scm",(void*)f_5597},
{"f_5593:c_backend_scm",(void*)f_5593},
{"f_5535:c_backend_scm",(void*)f_5535},
{"f_5538:c_backend_scm",(void*)f_5538},
{"f_5541:c_backend_scm",(void*)f_5541},
{"f_5544:c_backend_scm",(void*)f_5544},
{"f_5547:c_backend_scm",(void*)f_5547},
{"f_5550:c_backend_scm",(void*)f_5550},
{"f_5568:c_backend_scm",(void*)f_5568},
{"f_5578:c_backend_scm",(void*)f_5578},
{"f_5553:c_backend_scm",(void*)f_5553},
{"f_5488:c_backend_scm",(void*)f_5488},
{"f_5498:c_backend_scm",(void*)f_5498},
{"f_5491:c_backend_scm",(void*)f_5491},
{"f_4992:c_backend_scm",(void*)f_4992},
{"f_4999:c_backend_scm",(void*)f_4999},
{"f_5073:c_backend_scm",(void*)f_5073},
{"f_5091:c_backend_scm",(void*)f_5091},
{"f_5120:c_backend_scm",(void*)f_5120},
{"f_5142:c_backend_scm",(void*)f_5142},
{"f_5098:c_backend_scm",(void*)f_5098},
{"f_5067:c_backend_scm",(void*)f_5067},
{"f_5063:c_backend_scm",(void*)f_5063},
{"f_5059:c_backend_scm",(void*)f_5059},
{"f_5030:c_backend_scm",(void*)f_5030},
{"f_5034:c_backend_scm",(void*)f_5034},
{"f_4949:c_backend_scm",(void*)f_4949},
{"f_4955:c_backend_scm",(void*)f_4955},
{"f_4984:c_backend_scm",(void*)f_4984},
{"f_4965:c_backend_scm",(void*)f_4965},
{"f_5151:c_backend_scm",(void*)f_5151},
{"f_5291:c_backend_scm",(void*)f_5291},
{"f_5158:c_backend_scm",(void*)f_5158},
{"f_5164:c_backend_scm",(void*)f_5164},
{"f_5247:c_backend_scm",(void*)f_5247},
{"f_5250:c_backend_scm",(void*)f_5250},
{"f_5260:c_backend_scm",(void*)f_5260},
{"f_5253:c_backend_scm",(void*)f_5253},
{"f_5214:c_backend_scm",(void*)f_5214},
{"f_5220:c_backend_scm",(void*)f_5220},
{"f_4986:c_backend_scm",(void*)f_4986},
{"f_5293:c_backend_scm",(void*)f_5293},
{"f_5300:c_backend_scm",(void*)f_5300},
{"f_5303:c_backend_scm",(void*)f_5303},
{"f_5308:c_backend_scm",(void*)f_5308},
{"f_5364:c_backend_scm",(void*)f_5364},
{"f_5360:c_backend_scm",(void*)f_5360},
{"f_5345:c_backend_scm",(void*)f_5345},
{"f_5324:c_backend_scm",(void*)f_5324},
{"f_5335:c_backend_scm",(void*)f_5335},
{"f_5331:c_backend_scm",(void*)f_5331},
{"f_5370:c_backend_scm",(void*)f_5370},
{"f_5377:c_backend_scm",(void*)f_5377},
{"f_5380:c_backend_scm",(void*)f_5380},
{"f_4663:c_backend_scm",(void*)f_4663},
{"f_4830:c_backend_scm",(void*)f_4830},
{"f_4834:c_backend_scm",(void*)f_4834},
{"f_4837:c_backend_scm",(void*)f_4837},
{"f_4840:c_backend_scm",(void*)f_4840},
{"f_4843:c_backend_scm",(void*)f_4843},
{"f_4846:c_backend_scm",(void*)f_4846},
{"f_4947:c_backend_scm",(void*)f_4947},
{"f_4849:c_backend_scm",(void*)f_4849},
{"f_4852:c_backend_scm",(void*)f_4852},
{"f_4858:c_backend_scm",(void*)f_4858},
{"f_4936:c_backend_scm",(void*)f_4936},
{"f_4892:c_backend_scm",(void*)f_4892},
{"f_4898:c_backend_scm",(void*)f_4898},
{"f_4916:c_backend_scm",(void*)f_4916},
{"f_4912:c_backend_scm",(void*)f_4912},
{"f_4908:c_backend_scm",(void*)f_4908},
{"f_4864:c_backend_scm",(void*)f_4864},
{"f_4867:c_backend_scm",(void*)f_4867},
{"f_4870:c_backend_scm",(void*)f_4870},
{"f_4873:c_backend_scm",(void*)f_4873},
{"f_4876:c_backend_scm",(void*)f_4876},
{"f_4886:c_backend_scm",(void*)f_4886},
{"f_4879:c_backend_scm",(void*)f_4879},
{"f_4782:c_backend_scm",(void*)f_4782},
{"f_4801:c_backend_scm",(void*)f_4801},
{"f_4805:c_backend_scm",(void*)f_4805},
{"f_4808:c_backend_scm",(void*)f_4808},
{"f_4811:c_backend_scm",(void*)f_4811},
{"f_4814:c_backend_scm",(void*)f_4814},
{"f_4828:c_backend_scm",(void*)f_4828},
{"f_4824:c_backend_scm",(void*)f_4824},
{"f_4817:c_backend_scm",(void*)f_4817},
{"f_4785:c_backend_scm",(void*)f_4785},
{"f_4799:c_backend_scm",(void*)f_4799},
{"f_4788:c_backend_scm",(void*)f_4788},
{"f_4795:c_backend_scm",(void*)f_4795},
{"f_4702:c_backend_scm",(void*)f_4702},
{"f_4704:c_backend_scm",(void*)f_4704},
{"f_4708:c_backend_scm",(void*)f_4708},
{"f_4711:c_backend_scm",(void*)f_4711},
{"f_4714:c_backend_scm",(void*)f_4714},
{"f_4717:c_backend_scm",(void*)f_4717},
{"f_4720:c_backend_scm",(void*)f_4720},
{"f_4723:c_backend_scm",(void*)f_4723},
{"f_4726:c_backend_scm",(void*)f_4726},
{"f_4729:c_backend_scm",(void*)f_4729},
{"f_4732:c_backend_scm",(void*)f_4732},
{"f_4735:c_backend_scm",(void*)f_4735},
{"f_4738:c_backend_scm",(void*)f_4738},
{"f_4741:c_backend_scm",(void*)f_4741},
{"f_4755:c_backend_scm",(void*)f_4755},
{"f_4751:c_backend_scm",(void*)f_4751},
{"f_4744:c_backend_scm",(void*)f_4744},
{"f_4666:c_backend_scm",(void*)f_4666},
{"f_4679:c_backend_scm",(void*)f_4679},
{"f_4689:c_backend_scm",(void*)f_4689},
{"f_4670:c_backend_scm",(void*)f_4670},
{"f_4412:c_backend_scm",(void*)f_4412},
{"f_4416:c_backend_scm",(void*)f_4416},
{"f_4440:c_backend_scm",(void*)f_4440},
{"f_4444:c_backend_scm",(void*)f_4444},
{"f_4447:c_backend_scm",(void*)f_4447},
{"f_4661:c_backend_scm",(void*)f_4661},
{"f_4450:c_backend_scm",(void*)f_4450},
{"f_4647:c_backend_scm",(void*)f_4647},
{"f_4453:c_backend_scm",(void*)f_4453},
{"f_4456:c_backend_scm",(void*)f_4456},
{"f_4459:c_backend_scm",(void*)f_4459},
{"f_4462:c_backend_scm",(void*)f_4462},
{"f_4465:c_backend_scm",(void*)f_4465},
{"f_4468:c_backend_scm",(void*)f_4468},
{"f_4639:c_backend_scm",(void*)f_4639},
{"f_4471:c_backend_scm",(void*)f_4471},
{"f_4474:c_backend_scm",(void*)f_4474},
{"f_4632:c_backend_scm",(void*)f_4632},
{"f_4613:c_backend_scm",(void*)f_4613},
{"f_4624:c_backend_scm",(void*)f_4624},
{"f_4477:c_backend_scm",(void*)f_4477},
{"f_4564:c_backend_scm",(void*)f_4564},
{"f_4567:c_backend_scm",(void*)f_4567},
{"f_4570:c_backend_scm",(void*)f_4570},
{"f_4573:c_backend_scm",(void*)f_4573},
{"f_4589:c_backend_scm",(void*)f_4589},
{"f_4592:c_backend_scm",(void*)f_4592},
{"f_4595:c_backend_scm",(void*)f_4595},
{"f_4598:c_backend_scm",(void*)f_4598},
{"f_4480:c_backend_scm",(void*)f_4480},
{"f_4483:c_backend_scm",(void*)f_4483},
{"f_4486:c_backend_scm",(void*)f_4486},
{"f_4536:c_backend_scm",(void*)f_4536},
{"f_4539:c_backend_scm",(void*)f_4539},
{"f_4489:c_backend_scm",(void*)f_4489},
{"f_4492:c_backend_scm",(void*)f_4492},
{"f_4524:c_backend_scm",(void*)f_4524},
{"f_4527:c_backend_scm",(void*)f_4527},
{"f_4498:c_backend_scm",(void*)f_4498},
{"f_4507:c_backend_scm",(void*)f_4507},
{"f_4510:c_backend_scm",(void*)f_4510},
{"f_4419:c_backend_scm",(void*)f_4419},
{"f_4424:c_backend_scm",(void*)f_4424},
{"f_4428:c_backend_scm",(void*)f_4428},
{"f_4438:c_backend_scm",(void*)f_4438},
{"f_4431:c_backend_scm",(void*)f_4431},
{"f_4263:c_backend_scm",(void*)f_4263},
{"f_4270:c_backend_scm",(void*)f_4270},
{"f_4406:c_backend_scm",(void*)f_4406},
{"f_4273:c_backend_scm",(void*)f_4273},
{"f_4276:c_backend_scm",(void*)f_4276},
{"f_4279:c_backend_scm",(void*)f_4279},
{"f_4284:c_backend_scm",(void*)f_4284},
{"f_4294:c_backend_scm",(void*)f_4294},
{"f_4300:c_backend_scm",(void*)f_4300},
{"f_4353:c_backend_scm",(void*)f_4353},
{"f_4363:c_backend_scm",(void*)f_4363},
{"f_4303:c_backend_scm",(void*)f_4303},
{"f_4326:c_backend_scm",(void*)f_4326},
{"f_4336:c_backend_scm",(void*)f_4336},
{"f_4306:c_backend_scm",(void*)f_4306},
{"f_4309:c_backend_scm",(void*)f_4309},
{"f_4116:c_backend_scm",(void*)f_4116},
{"f_4255:c_backend_scm",(void*)f_4255},
{"f_4136:c_backend_scm",(void*)f_4136},
{"f_4213:c_backend_scm",(void*)f_4213},
{"f_4217:c_backend_scm",(void*)f_4217},
{"f_4221:c_backend_scm",(void*)f_4221},
{"f_4225:c_backend_scm",(void*)f_4225},
{"f_4247:c_backend_scm",(void*)f_4247},
{"f_4243:c_backend_scm",(void*)f_4243},
{"f_4235:c_backend_scm",(void*)f_4235},
{"f_4233:c_backend_scm",(void*)f_4233},
{"f_4229:c_backend_scm",(void*)f_4229},
{"f_4154:c_backend_scm",(void*)f_4154},
{"f_4157:c_backend_scm",(void*)f_4157},
{"f_4160:c_backend_scm",(void*)f_4160},
{"f_4202:c_backend_scm",(void*)f_4202},
{"f_4163:c_backend_scm",(void*)f_4163},
{"f_4166:c_backend_scm",(void*)f_4166},
{"f_4169:c_backend_scm",(void*)f_4169},
{"f_4184:c_backend_scm",(void*)f_4184},
{"f_4189:c_backend_scm",(void*)f_4189},
{"f_4172:c_backend_scm",(void*)f_4172},
{"f_4119:c_backend_scm",(void*)f_4119},
{"f_4133:c_backend_scm",(void*)f_4133},
{"f_2543:c_backend_scm",(void*)f_2543},
{"f_4084:c_backend_scm",(void*)f_4084},
{"f_4090:c_backend_scm",(void*)f_4090},
{"f_4094:c_backend_scm",(void*)f_4094},
{"f_2546:c_backend_scm",(void*)f_2546},
{"f_4049:c_backend_scm",(void*)f_4049},
{"f_4052:c_backend_scm",(void*)f_4052},
{"f_4055:c_backend_scm",(void*)f_4055},
{"f_4058:c_backend_scm",(void*)f_4058},
{"f_4061:c_backend_scm",(void*)f_4061},
{"f_4064:c_backend_scm",(void*)f_4064},
{"f_3966:c_backend_scm",(void*)f_3966},
{"f_3969:c_backend_scm",(void*)f_3969},
{"f_3972:c_backend_scm",(void*)f_3972},
{"f_3985:c_backend_scm",(void*)f_3985},
{"f_4008:c_backend_scm",(void*)f_4008},
{"f_4011:c_backend_scm",(void*)f_4011},
{"f_4014:c_backend_scm",(void*)f_4014},
{"f_4017:c_backend_scm",(void*)f_4017},
{"f_3995:c_backend_scm",(void*)f_3995},
{"f_3998:c_backend_scm",(void*)f_3998},
{"f_3957:c_backend_scm",(void*)f_3957},
{"f_3929:c_backend_scm",(void*)f_3929},
{"f_3932:c_backend_scm",(void*)f_3932},
{"f_3949:c_backend_scm",(void*)f_3949},
{"f_3935:c_backend_scm",(void*)f_3935},
{"f_3938:c_backend_scm",(void*)f_3938},
{"f_3913:c_backend_scm",(void*)f_3913},
{"f_3917:c_backend_scm",(void*)f_3917},
{"f_3899:c_backend_scm",(void*)f_3899},
{"f_3902:c_backend_scm",(void*)f_3902},
{"f_3883:c_backend_scm",(void*)f_3883},
{"f_3887:c_backend_scm",(void*)f_3887},
{"f_3865:c_backend_scm",(void*)f_3865},
{"f_3868:c_backend_scm",(void*)f_3868},
{"f_3845:c_backend_scm",(void*)f_3845},
{"f_3809:c_backend_scm",(void*)f_3809},
{"f_3821:c_backend_scm",(void*)f_3821},
{"f_3812:c_backend_scm",(void*)f_3812},
{"f_3790:c_backend_scm",(void*)f_3790},
{"f_3793:c_backend_scm",(void*)f_3793},
{"f_3771:c_backend_scm",(void*)f_3771},
{"f_3774:c_backend_scm",(void*)f_3774},
{"f_3752:c_backend_scm",(void*)f_3752},
{"f_3755:c_backend_scm",(void*)f_3755},
{"f_3733:c_backend_scm",(void*)f_3733},
{"f_3729:c_backend_scm",(void*)f_3729},
{"f_3677:c_backend_scm",(void*)f_3677},
{"f_3710:c_backend_scm",(void*)f_3710},
{"f_3680:c_backend_scm",(void*)f_3680},
{"f_3698:c_backend_scm",(void*)f_3698},
{"f_3683:c_backend_scm",(void*)f_3683},
{"f_3686:c_backend_scm",(void*)f_3686},
{"f_3644:c_backend_scm",(void*)f_3644},
{"f_3628:c_backend_scm",(void*)f_3628},
{"f_3631:c_backend_scm",(void*)f_3631},
{"f_3634:c_backend_scm",(void*)f_3634},
{"f_3587:c_backend_scm",(void*)f_3587},
{"f_3590:c_backend_scm",(void*)f_3590},
{"f_3611:c_backend_scm",(void*)f_3611},
{"f_3615:c_backend_scm",(void*)f_3615},
{"f_3618:c_backend_scm",(void*)f_3618},
{"f_3593:c_backend_scm",(void*)f_3593},
{"f_3609:c_backend_scm",(void*)f_3609},
{"f_3601:c_backend_scm",(void*)f_3601},
{"f_3596:c_backend_scm",(void*)f_3596},
{"f_3220:c_backend_scm",(void*)f_3220},
{"f_3223:c_backend_scm",(void*)f_3223},
{"f_3537:c_backend_scm",(void*)f_3537},
{"f_3533:c_backend_scm",(void*)f_3533},
{"f_3229:c_backend_scm",(void*)f_3229},
{"f_3526:c_backend_scm",(void*)f_3526},
{"f_2531:c_backend_scm",(void*)f_2531},
{"f_3519:c_backend_scm",(void*)f_3519},
{"f_3235:c_backend_scm",(void*)f_3235},
{"f_3362:c_backend_scm",(void*)f_3362},
{"f_3446:c_backend_scm",(void*)f_3446},
{"f_3449:c_backend_scm",(void*)f_3449},
{"f_3452:c_backend_scm",(void*)f_3452},
{"f_3467:c_backend_scm",(void*)f_3467},
{"f_3455:c_backend_scm",(void*)f_3455},
{"f_3458:c_backend_scm",(void*)f_3458},
{"f_3461:c_backend_scm",(void*)f_3461},
{"f_3377:c_backend_scm",(void*)f_3377},
{"f_3443:c_backend_scm",(void*)f_3443},
{"f_3436:c_backend_scm",(void*)f_3436},
{"f_3432:c_backend_scm",(void*)f_3432},
{"f_3425:c_backend_scm",(void*)f_3425},
{"f_3418:c_backend_scm",(void*)f_3418},
{"f_3393:c_backend_scm",(void*)f_3393},
{"f_3410:c_backend_scm",(void*)f_3410},
{"f_3406:c_backend_scm",(void*)f_3406},
{"f_3380:c_backend_scm",(void*)f_3380},
{"f_3383:c_backend_scm",(void*)f_3383},
{"f_3386:c_backend_scm",(void*)f_3386},
{"f_3356:c_backend_scm",(void*)f_3356},
{"f_3266:c_backend_scm",(void*)f_3266},
{"f_3340:c_backend_scm",(void*)f_3340},
{"f_3343:c_backend_scm",(void*)f_3343},
{"f_3316:c_backend_scm",(void*)f_3316},
{"f_3319:c_backend_scm",(void*)f_3319},
{"f_3322:c_backend_scm",(void*)f_3322},
{"f_3325:c_backend_scm",(void*)f_3325},
{"f_3328:c_backend_scm",(void*)f_3328},
{"f_3269:c_backend_scm",(void*)f_3269},
{"f_3272:c_backend_scm",(void*)f_3272},
{"f_3299:c_backend_scm",(void*)f_3299},
{"f_3303:c_backend_scm",(void*)f_3303},
{"f_3306:c_backend_scm",(void*)f_3306},
{"f_3275:c_backend_scm",(void*)f_3275},
{"f_3297:c_backend_scm",(void*)f_3297},
{"f_3289:c_backend_scm",(void*)f_3289},
{"f_3278:c_backend_scm",(void*)f_3278},
{"f_3281:c_backend_scm",(void*)f_3281},
{"f_3247:c_backend_scm",(void*)f_3247},
{"f_3250:c_backend_scm",(void*)f_3250},
{"f_3187:c_backend_scm",(void*)f_3187},
{"f_3183:c_backend_scm",(void*)f_3183},
{"f_3169:c_backend_scm",(void*)f_3169},
{"f_3172:c_backend_scm",(void*)f_3172},
{"f_3166:c_backend_scm",(void*)f_3166},
{"f_3162:c_backend_scm",(void*)f_3162},
{"f_3148:c_backend_scm",(void*)f_3148},
{"f_3151:c_backend_scm",(void*)f_3151},
{"f_3100:c_backend_scm",(void*)f_3100},
{"f_3121:c_backend_scm",(void*)f_3121},
{"f_3117:c_backend_scm",(void*)f_3117},
{"f_3103:c_backend_scm",(void*)f_3103},
{"f_3106:c_backend_scm",(void*)f_3106},
{"f_3069:c_backend_scm",(void*)f_3069},
{"f_3065:c_backend_scm",(void*)f_3065},
{"f_3023:c_backend_scm",(void*)f_3023},
{"f_2991:c_backend_scm",(void*)f_2991},
{"f_2994:c_backend_scm",(void*)f_2994},
{"f_2956:c_backend_scm",(void*)f_2956},
{"f_2982:c_backend_scm",(void*)f_2982},
{"f_2968:c_backend_scm",(void*)f_2968},
{"f_2972:c_backend_scm",(void*)f_2972},
{"f_2975:c_backend_scm",(void*)f_2975},
{"f_2959:c_backend_scm",(void*)f_2959},
{"f_2924:c_backend_scm",(void*)f_2924},
{"f_2927:c_backend_scm",(void*)f_2927},
{"f_2930:c_backend_scm",(void*)f_2930},
{"f_2933:c_backend_scm",(void*)f_2933},
{"f_2895:c_backend_scm",(void*)f_2895},
{"f_2898:c_backend_scm",(void*)f_2898},
{"f_2901:c_backend_scm",(void*)f_2901},
{"f_2904:c_backend_scm",(void*)f_2904},
{"f_2858:c_backend_scm",(void*)f_2858},
{"f_2861:c_backend_scm",(void*)f_2861},
{"f_2864:c_backend_scm",(void*)f_2864},
{"f_2867:c_backend_scm",(void*)f_2867},
{"f_2825:c_backend_scm",(void*)f_2825},
{"f_2828:c_backend_scm",(void*)f_2828},
{"f_2831:c_backend_scm",(void*)f_2831},
{"f_2834:c_backend_scm",(void*)f_2834},
{"f_2806:c_backend_scm",(void*)f_2806},
{"f_2809:c_backend_scm",(void*)f_2809},
{"f_2779:c_backend_scm",(void*)f_2779},
{"f_2782:c_backend_scm",(void*)f_2782},
{"f_2728:c_backend_scm",(void*)f_2728},
{"f_2738:c_backend_scm",(void*)f_2738},
{"f_2741:c_backend_scm",(void*)f_2741},
{"f_2744:c_backend_scm",(void*)f_2744},
{"f_2670:c_backend_scm",(void*)f_2670},
{"f_2673:c_backend_scm",(void*)f_2673},
{"f_2676:c_backend_scm",(void*)f_2676},
{"f_2679:c_backend_scm",(void*)f_2679},
{"f_2682:c_backend_scm",(void*)f_2682},
{"f_2685:c_backend_scm",(void*)f_2685},
{"f_2533:c_backend_scm",(void*)f_2533},
{"f_2541:c_backend_scm",(void*)f_2541},
{"f_2501:c_backend_scm",(void*)f_2501},
{"f_2513:c_backend_scm",(void*)f_2513},
{"f_2521:c_backend_scm",(void*)f_2521},
{"f_2505:c_backend_scm",(void*)f_2505},
{"f_2478:c_backend_scm",(void*)f_2478},
{"f_2492:c_backend_scm",(void*)f_2492},
{"f_2484:c_backend_scm",(void*)f_2484},
{"f_2457:c_backend_scm",(void*)f_2457},
{"f_2463:c_backend_scm",(void*)f_2463},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
