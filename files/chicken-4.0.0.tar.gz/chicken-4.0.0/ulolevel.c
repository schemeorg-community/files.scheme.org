/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:47
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: lolevel.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file ulolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[133];
static double C_possibly_force_alignment;


/* from k3152 */
static C_word C_fcall stub1202(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1202(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from f_2900 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static C_word C_fcall stub1048(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1048(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k3500 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub844(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub844(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3510 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub833(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub833(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3520 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub822(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub822(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3530 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub811(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub811(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3540 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub802(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub802(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3550 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub793(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub793(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3560 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub784(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub784(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_ret:
#undef return

return C_r;}

/* from k3570 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub775(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub775(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k2445 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub765(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub765(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2435 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub754(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub754(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2425 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub743(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub743(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2415 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub732(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub732(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2405 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub721(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub721(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2395 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub710(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub710(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2385 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub699(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub699(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2375 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub688(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub688(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from align in k1506 in k1503 */
static C_word C_fcall stub561(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub561(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k2201 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub548(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub548(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from f_2180 in object->pointer in k1506 in k1503 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub527(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub527(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k2121 */
static C_word C_fcall stub479(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub479(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from allocate in k1506 in k1503 */
static C_word C_fcall stub471(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub471(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1705 */
static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1692 */
static C_word C_fcall stub178(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub178(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1679 */
static C_word C_fcall stub159(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub159(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1663 */
static C_word C_fcall stub140(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub140(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3424)
static void C_fcall f_3424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_fcall f_3326(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_fcall f_3168(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3076)
static void C_fcall f_3076(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3121)
static void C_fcall f_3121(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_fcall f_2910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_fcall f_2924(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_fcall f_2949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_fcall f_2967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_fcall f_2830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_fcall f_2845(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static C_word C_fcall f_2763(C_word t0,C_word t1);
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1612)
static void C_fcall f_1612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static C_word C_fcall f_2208(C_word *a,C_word t0);
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2040)
static void C_fcall f_2040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_fcall f_2085(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1974)
static void C_fcall f_1974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_fcall f_1969(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1964)
static void C_fcall f_1964(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1715)
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_fcall f_1781(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_fcall f_1746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1753)
static void C_fcall f_1753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1724)
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_fcall f_1708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1583)
static void C_fcall f_1583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1510)
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3424)
static void C_fcall trf_3424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3424(t0,t1);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1538(t0,t1,t2);}

C_noret_decl(trf_3255)
static void C_fcall trf_3255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3255(t0,t1,t2);}

C_noret_decl(trf_3326)
static void C_fcall trf_3326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3326(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3326(t0,t1,t2);}

C_noret_decl(trf_3168)
static void C_fcall trf_3168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3168(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3168(t0,t1,t2);}

C_noret_decl(trf_3202)
static void C_fcall trf_3202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3202(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3202(t0,t1,t2);}

C_noret_decl(trf_3076)
static void C_fcall trf_3076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3076(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3076(t0,t1,t2);}

C_noret_decl(trf_3121)
static void C_fcall trf_3121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3121(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3121(t0,t1,t2);}

C_noret_decl(trf_2910)
static void C_fcall trf_2910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2910(t0,t1);}

C_noret_decl(trf_2924)
static void C_fcall trf_2924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2924(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2924(t0,t1,t2);}

C_noret_decl(trf_2949)
static void C_fcall trf_2949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2949(t0,t1);}

C_noret_decl(trf_2967)
static void C_fcall trf_2967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2967(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2967(t0,t1,t2);}

C_noret_decl(trf_2804)
static void C_fcall trf_2804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2804(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2804(t0,t1,t2);}

C_noret_decl(trf_2830)
static void C_fcall trf_2830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2830(t0,t1);}

C_noret_decl(trf_2845)
static void C_fcall trf_2845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2845(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2845(t0,t1,t2);}

C_noret_decl(trf_1612)
static void C_fcall trf_1612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1612(t0,t1);}

C_noret_decl(trf_2040)
static void C_fcall trf_2040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2040(t0,t1,t2);}

C_noret_decl(trf_2085)
static void C_fcall trf_2085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2085(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2085(t0,t1,t2);}

C_noret_decl(trf_1974)
static void C_fcall trf_1974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1974(t0,t1);}

C_noret_decl(trf_1969)
static void C_fcall trf_1969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1969(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1969(t0,t1,t2);}

C_noret_decl(trf_1964)
static void C_fcall trf_1964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1964(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1964(t0,t1,t2,t3);}

C_noret_decl(trf_1715)
static void C_fcall trf_1715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1715(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1715(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1781)
static void C_fcall trf_1781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1781(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1781(t0,t1,t2,t3);}

C_noret_decl(trf_1746)
static void C_fcall trf_1746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1746(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1746(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1753)
static void C_fcall trf_1753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1753(t0,t1);}

C_noret_decl(trf_1730)
static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1730(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1724)
static void C_fcall trf_1724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1724(t0,t1,t2);}

C_noret_decl(trf_1718)
static void C_fcall trf_1718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1718(t0,t1);}

C_noret_decl(trf_1708)
static void C_fcall trf_1708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1708(t0,t1);}

C_noret_decl(trf_1583)
static void C_fcall trf_1583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1583(t0,t1,t2);}

C_noret_decl(trf_1510)
static void C_fcall trf_1510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1510(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1510(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1297)){
C_save(t1);
C_rereclaim2(1297*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,133);
lf[1]=C_h_intern(&lf[1],14,"\003syserror-hook");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[6]=C_h_intern(&lf[6],17,"\003syscheck-pointer");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[8]=C_h_intern(&lf[8],12,"move-memory!");
lf[9]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[13]=C_h_intern(&lf[13],15,"\003sysbytevector\077");
lf[14]=C_h_intern(&lf[14],11,"object-copy");
lf[15]=C_h_intern(&lf[15],15,"\003sysmake-vector");
lf[16]=C_h_intern(&lf[16],8,"allocate");
lf[17]=C_h_intern(&lf[17],4,"free");
lf[18]=C_h_intern(&lf[18],8,"pointer\077");
lf[19]=C_h_intern(&lf[19],13,"pointer-like\077");
lf[20]=C_h_intern(&lf[20],16,"address->pointer");
lf[21]=C_h_intern(&lf[21],20,"\003sysaddress->pointer");
lf[22]=C_h_intern(&lf[22],17,"\003syscheck-integer");
lf[23]=C_h_intern(&lf[23],16,"pointer->address");
lf[24]=C_h_intern(&lf[24],20,"\003syspointer->address");
lf[25]=C_h_intern(&lf[25],17,"\003syscheck-special");
lf[26]=C_h_intern(&lf[26],12,"null-pointer");
lf[27]=C_h_intern(&lf[27],16,"\003sysnull-pointer");
lf[28]=C_h_intern(&lf[28],13,"null-pointer\077");
lf[29]=C_h_intern(&lf[29],15,"object->pointer");
lf[30]=C_h_intern(&lf[30],15,"pointer->object");
lf[31]=C_h_intern(&lf[31],9,"pointer=\077");
lf[32]=C_h_intern(&lf[32],14,"pointer-offset");
lf[33]=C_h_intern(&lf[33],13,"align-to-word");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[35]=C_h_intern(&lf[35],11,"tag-pointer");
lf[36]=C_h_intern(&lf[36],23,"\003sysmake-tagged-pointer");
lf[37]=C_h_intern(&lf[37],15,"tagged-pointer\077");
lf[38]=C_h_intern(&lf[38],11,"pointer-tag");
lf[39]=C_h_intern(&lf[39],13,"make-locative");
lf[40]=C_h_intern(&lf[40],17,"\003sysmake-locative");
lf[41]=C_h_intern(&lf[41],18,"make-weak-locative");
lf[42]=C_h_intern(&lf[42],13,"locative-set!");
lf[43]=C_h_intern(&lf[43],12,"locative-ref");
lf[44]=C_h_intern(&lf[44],16,"locative->object");
lf[45]=C_h_intern(&lf[45],9,"locative\077");
lf[46]=C_h_intern(&lf[46],15,"pointer-u8-set!");
lf[47]=C_h_intern(&lf[47],15,"pointer-s8-set!");
lf[48]=C_h_intern(&lf[48],16,"pointer-u16-set!");
lf[49]=C_h_intern(&lf[49],16,"pointer-s16-set!");
lf[50]=C_h_intern(&lf[50],16,"pointer-u32-set!");
lf[51]=C_h_intern(&lf[51],16,"pointer-s32-set!");
lf[52]=C_h_intern(&lf[52],16,"pointer-f32-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-f64-set!");
lf[54]=C_h_intern(&lf[54],14,"pointer-u8-ref");
lf[55]=C_h_intern(&lf[55],14,"pointer-s8-ref");
lf[56]=C_h_intern(&lf[56],15,"pointer-u16-ref");
lf[57]=C_h_intern(&lf[57],15,"pointer-s16-ref");
lf[58]=C_h_intern(&lf[58],15,"pointer-u32-ref");
lf[59]=C_h_intern(&lf[59],15,"pointer-s32-ref");
lf[60]=C_h_intern(&lf[60],15,"pointer-f32-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-f64-ref");
lf[62]=C_h_intern(&lf[62],8,"extended");
lf[64]=C_h_intern(&lf[64],16,"extend-procedure");
lf[65]=C_h_intern(&lf[65],19,"\003sysdecorate-lambda");
lf[66]=C_h_intern(&lf[66],17,"\003syscheck-closure");
lf[67]=C_h_intern(&lf[67],19,"extended-procedure\077");
lf[68]=C_h_intern(&lf[68],21,"\003syslambda-decoration");
lf[69]=C_h_intern(&lf[69],14,"procedure-data");
lf[70]=C_h_intern(&lf[70],19,"set-procedure-data!");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[72]=C_h_intern(&lf[72],10,"block-set!");
lf[73]=C_h_intern(&lf[73],14,"\003sysblock-set!");
lf[74]=C_h_intern(&lf[74],9,"block-ref");
lf[75]=C_h_intern(&lf[75],12,"vector-like\077");
lf[76]=C_h_intern(&lf[76],15,"number-of-slots");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[78]=C_h_intern(&lf[78],15,"number-of-bytes");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[80]=C_h_intern(&lf[80],20,"make-record-instance");
lf[81]=C_h_intern(&lf[81],18,"\003sysmake-structure");
lf[82]=C_h_intern(&lf[82],16,"record-instance\077");
lf[83]=C_h_intern(&lf[83],20,"record-instance-type");
lf[84]=C_h_intern(&lf[84],22,"record-instance-length");
lf[85]=C_h_intern(&lf[85],25,"record-instance-slot-set!");
lf[86]=C_h_intern(&lf[86],15,"\003syscheck-range");
lf[87]=C_h_intern(&lf[87],20,"record-instance-slot");
lf[88]=C_h_intern(&lf[88],14,"record->vector");
lf[89]=C_h_intern(&lf[89],15,"object-evicted\077");
lf[90]=C_h_intern(&lf[90],12,"object-evict");
lf[91]=C_h_intern(&lf[91],15,"hash-table-set!");
lf[92]=C_h_intern(&lf[92],19,"\003sysundefined-value");
lf[93]=C_h_intern(&lf[93],22,"hash-table-ref/default");
lf[94]=C_h_intern(&lf[94],15,"make-hash-table");
lf[95]=C_h_intern(&lf[95],3,"eq\077");
lf[96]=C_h_intern(&lf[96],24,"object-evict-to-location");
lf[97]=C_h_intern(&lf[97],24,"\003sysset-pointer-address!");
lf[98]=C_h_intern(&lf[98],6,"signal");
lf[99]=C_h_intern(&lf[99],24,"make-composite-condition");
lf[100]=C_h_intern(&lf[100],23,"make-property-condition");
lf[101]=C_h_intern(&lf[101],5,"evict");
lf[102]=C_h_intern(&lf[102],5,"limit");
lf[103]=C_h_intern(&lf[103],3,"exn");
lf[104]=C_h_intern(&lf[104],8,"location");
lf[105]=C_h_intern(&lf[105],7,"message");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[107]=C_h_intern(&lf[107],9,"arguments");
lf[108]=C_h_intern(&lf[108],14,"object-release");
lf[109]=C_h_intern(&lf[109],11,"object-size");
lf[110]=C_h_intern(&lf[110],14,"object-unevict");
lf[111]=C_h_intern(&lf[111],15,"\003sysmake-string");
lf[112]=C_h_intern(&lf[112],14,"object-become!");
lf[113]=C_h_intern(&lf[113],11,"\003sysbecome!");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[115]=C_h_intern(&lf[115],16,"mutate-procedure");
lf[117]=C_h_intern(&lf[117],35,"set-invalid-procedure-call-handler!");
lf[118]=C_h_intern(&lf[118],31,"\003sysinvalid-procedure-call-hook");
lf[119]=C_h_intern(&lf[119],26,"\003syslast-invalid-procedure");
lf[120]=C_h_intern(&lf[120],22,"unbound-variable-value");
lf[121]=C_h_intern(&lf[121],31,"\003sysunbound-variable-value-hook");
lf[122]=C_h_intern(&lf[122],10,"global-ref");
lf[123]=C_h_intern(&lf[123],11,"global-set!");
lf[124]=C_h_intern(&lf[124],13,"global-bound\077");
lf[125]=C_h_intern(&lf[125],32,"\003syssymbol-has-toplevel-binding\077");
lf[126]=C_h_intern(&lf[126],20,"global-make-unbound!");
lf[127]=C_h_intern(&lf[127],28,"\003sysarbitrary-unbound-symbol");
lf[128]=C_h_intern(&lf[128],18,"getter-with-setter");
lf[129]=C_h_intern(&lf[129],13,"\003sysblock-ref");
lf[130]=C_h_intern(&lf[130],15,"pointer-s6-set!");
lf[131]=C_h_intern(&lf[131],17,"register-feature!");
lf[132]=C_h_intern(&lf[132],7,"lolevel");
C_register_lf2(lf,133,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1503 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 74   register-feature! */
t3=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[132]);}

/* k1506 in k1503 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[58],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! check-block ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1510,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[2] /* (set! check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1583,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! check-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1634,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1708,tmp=(C_word)a,a+=2,tmp);
t6=lf[9];
t7=C_mutate((C_word*)lf[8]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1713,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[14]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2034,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[16]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2115,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2118,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[18]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2128,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[19]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2134,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[20]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2140,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[23]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2149,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[26]+1 /* (set! null-pointer ...) */,*((C_word*)lf[27]+1));
t16=C_mutate((C_word*)lf[28]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2159,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[29]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2172,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[30]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2183,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[31]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2189,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[32]+1 /* (set! pointer-offset ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2198,tmp=(C_word)a,a+=2,tmp));
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2208,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[33]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[35]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2242,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[37]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2257,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[38]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2294,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[39]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2312,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[41]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2334,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[42]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2356,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)C_locative_ref,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 344  getter-with-setter */
t31=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t31+1)))(4,t31,t29,t30,*((C_word*)lf[42]+1));}

/* k2359 in k1506 in k1503 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2361,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[44]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2363,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[45]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2366,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[46]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2372,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[47]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2382,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[48]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2392,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[49]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2402,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[50]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2412,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[51]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2422,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[52]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2432,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[53]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2442,tmp=(C_word)a,a+=2,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3567,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 361  getter-with-setter */
t15=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,*((C_word*)lf[46]+1));}

/* a3566 in k2359 in k1506 in k1503 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3567,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub775(C_SCHEME_UNDEFINED,t3));}

/* k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3557,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 366  getter-with-setter */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[47]+1));}

/* a3556 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3557,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub784(C_SCHEME_UNDEFINED,t3));}

/* k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3547,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 371  getter-with-setter */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[48]+1));}

/* a3546 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3547,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub793(C_SCHEME_UNDEFINED,t3));}

/* k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2462,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3537,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 376  getter-with-setter */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[130]+1));}

/* a3536 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3537,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub802(C_SCHEME_UNDEFINED,t3));}

/* k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2466,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3527,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 381  getter-with-setter */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[50]+1));}

/* a3526 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3527,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub811(t3,t4));}

/* k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3517,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 386  getter-with-setter */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[51]+1));}

/* a3516 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3517,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub822(t3,t4));}

/* k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3507,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 391  getter-with-setter */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[52]+1));}

/* a3506 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3507,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub833(t3,t4));}

/* k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2478,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3497,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 396  getter-with-setter */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[53]+1));}

/* a3496 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3497,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub844(t3,t4));}

/* k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2482,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=(C_word)C_a_i_vector(&a,1,lf[62]);
t4=C_mutate(&lf[63] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[64]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2488,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[67]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2523,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[69]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2554,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[64]+1);
t9=C_mutate((C_word*)lf[70]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2588,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[72]+1 /* (set! block-set! ...) */,*((C_word*)lf[73]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 440  getter-with-setter */
t12=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[129]+1),*((C_word*)lf[73]+1));}

/* k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[75]+1 /* (set! vector-like? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2608,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[76]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2621,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[78]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2630,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[80]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2652,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[82]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2661,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[83]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2698,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[84]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2707,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[85]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2720,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3473,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 490  getter-with-setter */
t13=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,*((C_word*)lf[85]+1));}

/* a3472 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3473,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3477,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 492  ##sys#check-generic-structure */
f_1583(t4,t2,(C_word)C_a_i_list(&a,1,lf[87]));}

/* k3475 in a3472 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 493  ##sys#check-range */
t5=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[4],C_fix(0),t4,lf[87]);}

/* k3478 in k3475 in a3472 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2746,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[88]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2748,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[89]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2786,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[90]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2789,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[96]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2903,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[108]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3067,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[109]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3159,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[110]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3243,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[112]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3365,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[115]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3374,tmp=(C_word)a,a+=2,tmp));
t12=lf[116] /* ipc-hook-0 */ =C_SCHEME_FALSE;;
t13=C_mutate((C_word*)lf[117]+1 /* (set! set-invalid-procedure-call-handler! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3406,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[120]+1 /* (set! unbound-variable-value ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3419,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[122]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3436,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[123]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3442,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[124]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3451,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[126]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3460,tmp=(C_word)a,a+=2,tmp));
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3460,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[126]);
t4=(C_word)C_slot(lf[127],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3451,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[124]);
/* lolevel.scm: 678  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* global-set! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3442,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[123]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3436,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[122]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3419r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3419r(t0,t1,t2);}}

static void C_ccall f_3419r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_3424(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_3424(t4,C_SCHEME_FALSE);}}

/* k3422 in unbound-variable-value in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_3424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[121]+1 /* (set! unbound-variable-value-hook ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* set-invalid-procedure-call-handler! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3406,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3410,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 654  ##sys#check-closure */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[117]);}

/* k3408 in set-invalid-procedure-call-handler! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
t2=C_mutate(&lf[116] /* (set! ipc-hook-0 ...) */,((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[118]+1 /* (set! invalid-procedure-call-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3413,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k3408 in set-invalid-procedure-call-handler! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3413r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3413r(t0,t1,t2);}}

static void C_ccall f_3413r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 658  ipc-hook-0 */
t3=lf[116];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,*((C_word*)lf[119]+1),t2);}

/* mutate-procedure in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3374,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3378,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 640  ##sys#check-closure */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[115]);}

/* k3376 in mutate-procedure in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 641  ##sys#check-closure */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[115]);}

/* k3379 in k3376 in mutate-procedure in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 644  ##sys#make-vector */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3386 in k3379 in k3376 in mutate-procedure in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3388,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 645  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3401 in k3386 in k3379 in k3376 in mutate-procedure in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3403,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 645  ##sys#become! */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3389 in k3386 in k3379 in k3376 in mutate-procedure in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3365,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3369,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_i_check_list_2(t4,lf[112]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1538(t9,t3,t4);}

/* loop in object-become! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_pair_2(t4,lf[112]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1560,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t4);
/* lolevel.scm: 115  ##sys#check-block */
f_1510(t6,t7,(C_word)C_a_i_list(&a,1,lf[112]));}
else{
/* lolevel.scm: 119  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[4],lf[112],lf[114],((C_word*)t0)[2]);}}}

/* k1558 in loop in object-become! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* lolevel.scm: 116  ##sys#check-block */
f_1510(t2,t3,(C_word)C_a_i_list(&a,1,lf[112]));}

/* k1561 in k1558 in loop in object-become! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 117  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1538(t3,((C_word*)t0)[2],t2);}

/* k3367 in object-become! in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 637  ##sys#become! */
t2=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3243r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3243r(t0,t1,t2,t3);}}

static void C_ccall f_3243r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3250,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 608  make-hash-table */
t7=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[95]+1));}

/* k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3255,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3255(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3255,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 612  hash-table-ref/default */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 615  ##sys#make-string */
t4=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3300,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 620  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 625  ##sys#make-vector */
t4=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k3312 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 626  hash-table-set! */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k3315 in k3312 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3326(t7,t2,t3);}

/* doloop1340 in k3315 in k3312 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_3326(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3326,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3347,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 629  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3255(t5,t3,t4);}}

/* k3345 in doloop1340 in k3315 in k3312 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3326(t4,((C_word*)t0)[2],t3);}

/* k3318 in k3315 in k3312 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3298 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3303,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 621  hash-table-set! */
t3=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3301 in k3298 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3282 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3287,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 616  hash-table-set! */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k3285 in k3282 in k3269 in copy in k3248 in object-unevict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3159,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3163,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 591  make-hash-table */
t4=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[95]+1));}

/* k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3163,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3168(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_3168(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3168,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 594  hash-table-ref/default */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k3179 in evict in k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 598  align-to-word */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_3238(2,t4,(C_word)C_bytes(t2));}}}

/* k3236 in k3179 in evict in k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 600  hash-table-set! */
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k3188 in k3236 in k3179 in evict in k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_3193(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_3202(t9,t2,t5);}}

/* doloop1266 in k3188 in k3236 in k3179 in evict in k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3202,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3224,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 604  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3168(t5,t3,t4);}}

/* k3222 in doloop1266 in k3188 in k3236 in k3179 in evict in k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_3202(t5,((C_word*)t0)[2],t4);}

/* k3191 in k3188 in k3236 in k3179 in evict in k3161 in object-size in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-release in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3067r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3067r(t0,t1,t2,t3);}}

static void C_ccall f_3067r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3149,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3076,a[2]=t9,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3076(t11,t1,t2);}

/* release in object-release in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_3076(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3076,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_u_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3105,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_3105(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3121(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* doloop1225 in release in object-release in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_3121(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3121,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3131,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 587  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3076(t5,t3,t4);}}

/* k3129 in doloop1225 in release in object-release in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3121(t3,((C_word*)t0)[2],t2);}

/* k3103 in release in object-release in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 588  ##sys#address->pointer */
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k3110 in k3103 in release in object-release in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 588  free */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3149 in object-release in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3149,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1202(C_SCHEME_UNDEFINED,t3));}

/* object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2903r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2903r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2907,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 535  ##sys#check-special */
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[96]);}

/* k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[96]);
t5=t2;
f_2910(t5,t3);}
else{
t3=t2;
f_2910(t3,C_SCHEME_FALSE);}}

/* k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_2910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2910,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 540  ##sys#pointer->address */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k3054 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 540  ##sys#address->pointer */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 541  make-hash-table */
t3=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[95]+1));}

/* k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2924(t6,t2,((C_word*)t0)[2]);}

/* evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_2924(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2924,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 545  hash-table-ref/default */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 549  align-to-word */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_3049(2,t4,(C_word)C_bytes(t2));}}}

/* k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2946,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 556  make-property-condition */
t9=*((C_word*)lf[100]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[103],lf[104],lf[96],lf[105],lf[106],lf[107],t8);}
else{
t6=t3;
f_2946(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2946(2,t4,C_SCHEME_UNDEFINED);}}

/* k3035 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3041,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 560  make-property-condition */
t3=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[101],lf[102],((C_word*)((C_word*)t0)[2])[1]);}

/* k3039 in k3035 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 555  make-composite-condition */
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3031 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 554  signal */
t2=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[92]+1);
t5=t3;
f_2949(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2949(t4,C_SCHEME_UNDEFINED);}}

/* k2947 in k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_2949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2949,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 563  ##sys#pointer->address */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3004 in k2947 in k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 563  ##sys#set-pointer-address! */
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2950 in k2947 in k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 564  hash-table-set! */
t3=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2953 in k2950 in k2947 in k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2958(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2967(t9,t2,t5);}}

/* doloop1166 in k2953 in k2950 in k2947 in k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_2967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2967,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2988,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 568  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2924(t5,t3,t4);}}

/* k2986 in doloop1166 in k2953 in k2950 in k2947 in k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2967(t4,((C_word*)t0)[2],t3);}

/* k2956 in k2953 in k2950 in k2947 in k2944 in k3047 in k2932 in evict in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2917 in k2914 in k2911 in k2908 in k2905 in object-evict-to-location in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 570  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2789r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2789r(t0,t1,t2,t3);}}

static void C_ccall f_2789r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2900,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2796,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 516  make-hash-table */
t7=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[95]+1));}

/* k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 517  ##sys#check-closure */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[90]);}

/* k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2804(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2804,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 520  hash-table-ref/default */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 523  align-to-word */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2823(2,t4,(C_word)C_bytes(t2));}}}

/* k2821 in k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 524  allocator */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k2825 in k2821 in k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[92]+1);
t5=t3;
f_2830(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2830(t4,C_SCHEME_UNDEFINED);}}

/* k2828 in k2825 in k2821 in k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_2830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2830,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 526  hash-table-set! */
t3=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2831 in k2828 in k2825 in k2821 in k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2836(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2845(t9,t2,t5);}}

/* doloop1084 in k2831 in k2828 in k2825 in k2821 in k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_2845(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2845,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2866,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 531  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2804(t5,t3,t4);}}

/* k2864 in doloop1084 in k2831 in k2828 in k2825 in k2821 in k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2845(t4,((C_word*)t0)[2],t3);}

/* k2834 in k2831 in k2828 in k2825 in k2821 in k2812 in evict in k2797 in k2794 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2900 in object-evict in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2900,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1048(t3,t2));}

/* object-evicted? in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2786,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* record->vector in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2748,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2752,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 498  ##sys#check-generic-structure */
f_1583(t3,t2,(C_word)C_a_i_list(&a,1,lf[88]));}

/* k2750 in record->vector in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2752,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 500  ##sys#make-vector */
t4=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2756 in k2750 in record->vector in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2763(t2,C_fix(0)));}

/* doloop1021 in k2756 in k2750 in record->vector in k2744 in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static C_word C_fcall f_2763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance-slot-set! in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2720,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2724,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 485  ##sys#check-generic-structure */
f_1583(t5,t2,(C_word)C_a_i_list(&a,1,lf[85]));}

/* k2722 in record-instance-slot-set! in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 486  ##sys#check-range */
t5=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[5],C_fix(0),t4,lf[85]);}

/* k2725 in k2722 in record-instance-slot-set! in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2707,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2711,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 481  ##sys#check-generic-structure */
f_1583(t3,t2,(C_word)C_a_i_list(&a,1,lf[84]));}

/* k2709 in record-instance-length in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2698,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2702,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 477  ##sys#check-generic-structure */
f_1583(t3,t2,(C_word)C_a_i_list(&a,1,lf[83]));}

/* k2700 in record-instance-type in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2661r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2661r(t0,t1,t2,t3);}}

static void C_ccall f_2661r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=t2;
t7=(C_truep((C_word)C_blockp(t6))?(C_word)C_structurep(t6):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_not(t5);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_eqp(t5,t9));}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* make-record-instance in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2652r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2652r(t0,t1,t2,t3);}}

static void C_ccall f_2652r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[80]);
C_apply(5,0,t1,*((C_word*)lf[81]+1),t2,t3);}

/* number-of-bytes in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2630,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 451  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[4],lf[78],lf[79],t2);}}

/* number-of-slots in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2621,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2625,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[76]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1612,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t4))){
t7=(C_word)C_specialp(t4);
t8=(C_truep(t7)?t7:(C_word)C_byteblockp(t4));
t9=t6;
f_1612(t9,(C_word)C_i_not(t8));}
else{
t7=t6;
f_1612(t7,C_SCHEME_FALSE);}}

/* k1610 in number-of-slots in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_fcall f_1612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2625(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[3]):C_SCHEME_FALSE);
/* lolevel.scm: 133  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[4],t3,lf[77],((C_word*)t0)[2]);}}

/* k2623 in number-of-slots in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* vector-like? in k2604 in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2608,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_specialp(t2);
t4=(C_truep(t3)?t3:(C_word)C_byteblockp(t2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_not(t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* set-procedure-data! in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2588,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 429  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2590 in set-procedure-data! in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 432  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[4],lf[70],lf[71],((C_word*)t0)[3]);}}

/* procedure-data in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2554,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2564,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2572,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 414  ##sys#lambda-decoration */
t6=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2571 in procedure-data in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2572,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[63],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2562 in procedure-data in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2523,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2538,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 414  ##sys#lambda-decoration */
t6=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2537 in extended-procedure? in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2538,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[63],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2534 in extended-procedure? in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2488,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2492,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 407  ##sys#check-closure */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[64]);}

/* k2490 in extend-procedure in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2497,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 408  ##sys#decorate-lambda */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2512 in k2490 in extend-procedure in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2513,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[63],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2496 in k2490 in extend-procedure in k2480 in k2476 in k2472 in k2468 in k2464 in k2460 in k2456 in k2452 in k2359 in k1506 in k1503 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2497,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[63],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2442,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub765(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-f32-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2432,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub754(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s32-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2422,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub743(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u32-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2412,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub732(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s16-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2402,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub721(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u16-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2392,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub710(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s8-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2382,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub699(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u8-set! in k2359 in k1506 in k1503 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2372,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub688(C_SCHEME_UNDEFINED,t4,t3));}

/* locative? in k2359 in k1506 in k1503 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2366,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k2359 in k1506 in k1503 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2363,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1506 in k1503 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2356,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1506 in k1503 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2334r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2334r(t0,t1,t2,t3);}}

static void C_ccall f_2334r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(0):(C_word)C_slot(t3,C_fix(0)));
/* lolevel.scm: 341  ##sys#make-locative */
t6=*((C_word*)lf[40]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t5,C_SCHEME_TRUE,lf[41]);}

/* make-locative in k1506 in k1503 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2312r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2312r(t0,t1,t2,t3);}}

static void C_ccall f_2312r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(0):(C_word)C_slot(t3,C_fix(0)));
/* lolevel.scm: 338  ##sys#make-locative */
t6=*((C_word*)lf[40]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t5,C_SCHEME_FALSE,lf[39]);}

/* pointer-tag in k1506 in k1503 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2294,3,t0,t1,t2);}
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 315  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[38],t2);}}

/* tagged-pointer? in k1506 in k1503 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2257r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2257r(t0,t1,t2,t3);}}

static void C_ccall f_2257r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t5,t7));}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* tag-pointer in k1506 in k1503 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2242,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2246,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 300  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2244 in tag-pointer in k1506 in k1503 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_2249(2,t5,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 303  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[35],((C_word*)t0)[2]);}}

/* k2247 in k2244 in tag-pointer in k1506 in k1503 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k1506 in k1503 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2210,3,t0,t1,t2);}
if(C_truep((C_word)C_i_integerp(t2))){
/* lolevel.scm: 288  align */
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2208(C_a_i(&a,6),t2));}
else{
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 290  ##sys#pointer->address */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* lolevel.scm: 292  ##sys#signal-hook */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[4],lf[33],lf[34],t2);}}}

/* k2235 in align-to-word in k1506 in k1503 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=f_2208(C_a_i(&a,6),t1);
/* lolevel.scm: 290  ##sys#address->pointer */
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k1506 in k1503 */
static C_word C_fcall f_2208(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
return((C_word)stub561(t2,t1));}

/* pointer-offset in k1506 in k1503 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2198,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub548(t4,t5,t3));}

/* pointer=? in k1506 in k1503 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2189,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2193,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 276  ##sys#check-special */
t5=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[31]);}

/* k2191 in pointer=? in k1506 in k1503 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 277  ##sys#check-special */
t3=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[31]);}

/* k2194 in k2191 in pointer=? in k1506 in k1503 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1506 in k1503 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2183,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2187,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 272  ##sys#check-pointer */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[30]);}

/* k2185 in pointer->object in k1506 in k1503 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1506 in k1503 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2172,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2180,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_2180 in object->pointer in k1506 in k1503 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2180,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub527(t3,t2));}

/* null-pointer? in k1506 in k1503 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2159,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 264  ##sys#check-special */
t4=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[28]);}

/* k2161 in null-pointer? in k1506 in k1503 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 265  ##sys#pointer->address */
t3=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2168 in k2161 in null-pointer? in k1506 in k1503 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1506 in k1503 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2149,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2153,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 258  ##sys#check-special */
t4=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[23]);}

/* k2151 in pointer->address in k1506 in k1503 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 259  ##sys#pointer->address */
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1506 in k1503 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2140,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2144,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 254  ##sys#check-integer */
t4=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[20]);}

/* k2142 in address->pointer in k1506 in k1503 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 255  ##sys#address->pointer */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k1506 in k1503 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2134,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE));}

/* pointer? in k1506 in k1503 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2128,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_anypointerp(t2):C_SCHEME_FALSE));}

/* free in k1506 in k1503 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2118,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub479(C_SCHEME_UNDEFINED,t3));}

/* allocate in k1506 in k1503 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2115,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub471(t3,t2));}

/* object-copy in k1506 in k1503 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2034,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2040(t6,t1,t2);}

/* copy in object-copy in k1506 in k1503 */
static void C_fcall f_2040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2040,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 232  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 236  ##sys#make-vector */
t6=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2068 in copy in object-copy in k1506 in k1503 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_2073(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2085(t10,t3,t6);}}

/* doloop454 in k2068 in copy in object-copy in k1506 in k1503 */
static void C_fcall f_2085(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2085,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2106,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 240  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2040(t5,t3,t4);}}

/* k2104 in doloop454 in k2068 in copy in object-copy in k1506 in k1503 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2085(t4,((C_word*)t0)[2],t3);}

/* k2071 in k2068 in copy in object-copy in k1506 in k1503 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k1506 in k1503 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1713r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1713r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1969,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n237409 */
t9=t8;
f_1974(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset238405 */
t11=t7;
f_1969(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset239400 */
t13=t6;
f_1964(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body235245 */
t15=t5;
f_1715(t15,t1,t9,t11,t13);}}}}

/* def-n237 in move-memory! in k1506 in k1503 */
static void C_fcall f_1974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1974,NULL,2,t0,t1);}
/* def-foffset238405 */
t2=((C_word*)t0)[2];
f_1969(t2,t1,C_SCHEME_FALSE);}

/* def-foffset238 in move-memory! in k1506 in k1503 */
static void C_fcall f_1969(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1969,NULL,3,t0,t1,t2);}
/* def-toffset239400 */
t3=((C_word*)t0)[2];
f_1964(t3,t1,t2,C_fix(0));}

/* def-toffset239 in move-memory! in k1506 in k1503 */
static void C_fcall f_1964(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1964,NULL,4,t0,t1,t2,t3);}
/* body235245 */
t4=((C_word*)t0)[2];
f_1715(t4,t1,t2,t3,C_fix(0));}

/* body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1715,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1730,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t8,a[6]=t7,a[7]=t5,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[3],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 196  ##sys#check-block */
f_1510(t9,((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,lf[8]));}

/* k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 197  ##sys#check-block */
f_1510(t2,((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,lf[8]));}

/* k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t3,a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_1781(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1781(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1781,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 201  move */
t19=t1;
t20=t5;
t21=t3;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 202  typerr */
f_1708(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 205  move */
t19=t1;
t20=t2;
t21=t5;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 206  typerr */
f_1708(t1,t3);}}
else{
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=t3;
t8=(C_truep((C_word)C_blockp(t7))?(C_word)C_anypointerp(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:(C_word)C_locativep(t7));
if(C_truep(t9)){
t10=((C_word*)t0)[7];
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_1859(2,t12,t10);}
else{
/* lolevel.scm: 209  nosizerr */
t12=((C_word*)t0)[4];
f_1718(t12,t11);}}
else{
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 210  ##sys#bytevector? */
t11=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 214  ##sys#bytevector? */
t8=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}}}

/* k1899 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=((C_word*)t0)[9];
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[5];
t9=(C_truep(t8)?t8:t3);
/* lolevel.scm: 217  checkn1 */
t10=((C_word*)t0)[4];
f_1730(t10,t7,t9,t3,((C_word*)t0)[6]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 218  ##sys#bytevector? */
t8=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 224  typerr */
f_1708(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k1931 in k1899 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 219  checkn2 */
t7=((C_word*)t0)[3];
f_1746(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 222  typerr */
f_1708(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1941 in k1931 in k1899 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub197(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k1921 in k1899 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub159(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k1866 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1882(2,t6,t4);}
else{
/* lolevel.scm: 211  nosizerr */
t6=((C_word*)t0)[3];
f_1718(t6,t5);}}
else{
/* lolevel.scm: 213  typerr */
f_1708(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1880 in k1866 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 211  checkn1 */
t3=((C_word*)t0)[4];
f_1730(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1876 in k1866 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub178(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k1857 in move in k1774 in k1771 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub140(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* checkn2 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1746,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1753,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_u_fixnum_difference(t4,t6);
t10=t7;
f_1753(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1753(t9,C_SCHEME_FALSE);}}

/* k1751 in checkn2 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1753,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* lolevel.scm: 194  sizerr */
t2=((C_word*)t0)[4];
f_1724(t2,((C_word*)t0)[6],(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 189  sizerr */
t6=((C_word*)t0)[2];
f_1724(t6,t1,(C_word)C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1724,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[10]+1),lf[8],lf[12],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1718,NULL,2,t0,t1);}
/* lolevel.scm: 181  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[8],lf[11],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* typerr in k1506 in k1503 */
static void C_fcall f_1708(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1708,NULL,2,t1,t2);}
/* lolevel.scm: 172  ##sys#error-hook */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[8],t2);}

/* ##sys#check-pointer in k1506 in k1503 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1634r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1634r(t0,t1,t2,t3);}}

static void C_ccall f_1634r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* lolevel.scm: 139  ##sys#error-hook */
t8=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t7,lf[7],t2);}}

/* ##sys#check-generic-structure in k1506 in k1503 */
static void C_fcall f_1583(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1583,NULL,3,t1,t2,t3);}
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_structurep(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_pairp(t3);
t7=(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 125  ##sys#signal-hook */
t8=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,lf[4],t7,lf[5],t2);}}

/* ##sys#check-block in k1506 in k1503 */
static void C_fcall f_1510(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1510,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 104  ##sys#error-hook */
t6=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t5,t2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[211] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_1505:lolevel_scm",(void*)f_1505},
{"f_1508:lolevel_scm",(void*)f_1508},
{"f_2361:lolevel_scm",(void*)f_2361},
{"f_3567:lolevel_scm",(void*)f_3567},
{"f_2454:lolevel_scm",(void*)f_2454},
{"f_3557:lolevel_scm",(void*)f_3557},
{"f_2458:lolevel_scm",(void*)f_2458},
{"f_3547:lolevel_scm",(void*)f_3547},
{"f_2462:lolevel_scm",(void*)f_2462},
{"f_3537:lolevel_scm",(void*)f_3537},
{"f_2466:lolevel_scm",(void*)f_2466},
{"f_3527:lolevel_scm",(void*)f_3527},
{"f_2470:lolevel_scm",(void*)f_2470},
{"f_3517:lolevel_scm",(void*)f_3517},
{"f_2474:lolevel_scm",(void*)f_2474},
{"f_3507:lolevel_scm",(void*)f_3507},
{"f_2478:lolevel_scm",(void*)f_2478},
{"f_3497:lolevel_scm",(void*)f_3497},
{"f_2482:lolevel_scm",(void*)f_2482},
{"f_2606:lolevel_scm",(void*)f_2606},
{"f_3473:lolevel_scm",(void*)f_3473},
{"f_3477:lolevel_scm",(void*)f_3477},
{"f_3480:lolevel_scm",(void*)f_3480},
{"f_2746:lolevel_scm",(void*)f_2746},
{"f_3460:lolevel_scm",(void*)f_3460},
{"f_3451:lolevel_scm",(void*)f_3451},
{"f_3442:lolevel_scm",(void*)f_3442},
{"f_3436:lolevel_scm",(void*)f_3436},
{"f_3419:lolevel_scm",(void*)f_3419},
{"f_3424:lolevel_scm",(void*)f_3424},
{"f_3406:lolevel_scm",(void*)f_3406},
{"f_3410:lolevel_scm",(void*)f_3410},
{"f_3413:lolevel_scm",(void*)f_3413},
{"f_3374:lolevel_scm",(void*)f_3374},
{"f_3378:lolevel_scm",(void*)f_3378},
{"f_3381:lolevel_scm",(void*)f_3381},
{"f_3388:lolevel_scm",(void*)f_3388},
{"f_3403:lolevel_scm",(void*)f_3403},
{"f_3391:lolevel_scm",(void*)f_3391},
{"f_3365:lolevel_scm",(void*)f_3365},
{"f_1538:lolevel_scm",(void*)f_1538},
{"f_1560:lolevel_scm",(void*)f_1560},
{"f_1563:lolevel_scm",(void*)f_1563},
{"f_3369:lolevel_scm",(void*)f_3369},
{"f_3243:lolevel_scm",(void*)f_3243},
{"f_3250:lolevel_scm",(void*)f_3250},
{"f_3255:lolevel_scm",(void*)f_3255},
{"f_3271:lolevel_scm",(void*)f_3271},
{"f_3314:lolevel_scm",(void*)f_3314},
{"f_3317:lolevel_scm",(void*)f_3317},
{"f_3326:lolevel_scm",(void*)f_3326},
{"f_3347:lolevel_scm",(void*)f_3347},
{"f_3320:lolevel_scm",(void*)f_3320},
{"f_3300:lolevel_scm",(void*)f_3300},
{"f_3303:lolevel_scm",(void*)f_3303},
{"f_3284:lolevel_scm",(void*)f_3284},
{"f_3287:lolevel_scm",(void*)f_3287},
{"f_3159:lolevel_scm",(void*)f_3159},
{"f_3163:lolevel_scm",(void*)f_3163},
{"f_3168:lolevel_scm",(void*)f_3168},
{"f_3181:lolevel_scm",(void*)f_3181},
{"f_3238:lolevel_scm",(void*)f_3238},
{"f_3190:lolevel_scm",(void*)f_3190},
{"f_3202:lolevel_scm",(void*)f_3202},
{"f_3224:lolevel_scm",(void*)f_3224},
{"f_3193:lolevel_scm",(void*)f_3193},
{"f_3067:lolevel_scm",(void*)f_3067},
{"f_3076:lolevel_scm",(void*)f_3076},
{"f_3121:lolevel_scm",(void*)f_3121},
{"f_3131:lolevel_scm",(void*)f_3131},
{"f_3105:lolevel_scm",(void*)f_3105},
{"f_3112:lolevel_scm",(void*)f_3112},
{"f_3149:lolevel_scm",(void*)f_3149},
{"f_2903:lolevel_scm",(void*)f_2903},
{"f_2907:lolevel_scm",(void*)f_2907},
{"f_2910:lolevel_scm",(void*)f_2910},
{"f_3056:lolevel_scm",(void*)f_3056},
{"f_2913:lolevel_scm",(void*)f_2913},
{"f_2916:lolevel_scm",(void*)f_2916},
{"f_2924:lolevel_scm",(void*)f_2924},
{"f_2934:lolevel_scm",(void*)f_2934},
{"f_3049:lolevel_scm",(void*)f_3049},
{"f_3037:lolevel_scm",(void*)f_3037},
{"f_3041:lolevel_scm",(void*)f_3041},
{"f_3033:lolevel_scm",(void*)f_3033},
{"f_2946:lolevel_scm",(void*)f_2946},
{"f_2949:lolevel_scm",(void*)f_2949},
{"f_3006:lolevel_scm",(void*)f_3006},
{"f_2952:lolevel_scm",(void*)f_2952},
{"f_2955:lolevel_scm",(void*)f_2955},
{"f_2967:lolevel_scm",(void*)f_2967},
{"f_2988:lolevel_scm",(void*)f_2988},
{"f_2958:lolevel_scm",(void*)f_2958},
{"f_2919:lolevel_scm",(void*)f_2919},
{"f_2789:lolevel_scm",(void*)f_2789},
{"f_2796:lolevel_scm",(void*)f_2796},
{"f_2799:lolevel_scm",(void*)f_2799},
{"f_2804:lolevel_scm",(void*)f_2804},
{"f_2814:lolevel_scm",(void*)f_2814},
{"f_2823:lolevel_scm",(void*)f_2823},
{"f_2827:lolevel_scm",(void*)f_2827},
{"f_2830:lolevel_scm",(void*)f_2830},
{"f_2833:lolevel_scm",(void*)f_2833},
{"f_2845:lolevel_scm",(void*)f_2845},
{"f_2866:lolevel_scm",(void*)f_2866},
{"f_2836:lolevel_scm",(void*)f_2836},
{"f_2900:lolevel_scm",(void*)f_2900},
{"f_2786:lolevel_scm",(void*)f_2786},
{"f_2748:lolevel_scm",(void*)f_2748},
{"f_2752:lolevel_scm",(void*)f_2752},
{"f_2758:lolevel_scm",(void*)f_2758},
{"f_2763:lolevel_scm",(void*)f_2763},
{"f_2720:lolevel_scm",(void*)f_2720},
{"f_2724:lolevel_scm",(void*)f_2724},
{"f_2727:lolevel_scm",(void*)f_2727},
{"f_2707:lolevel_scm",(void*)f_2707},
{"f_2711:lolevel_scm",(void*)f_2711},
{"f_2698:lolevel_scm",(void*)f_2698},
{"f_2702:lolevel_scm",(void*)f_2702},
{"f_2661:lolevel_scm",(void*)f_2661},
{"f_2652:lolevel_scm",(void*)f_2652},
{"f_2630:lolevel_scm",(void*)f_2630},
{"f_2621:lolevel_scm",(void*)f_2621},
{"f_1612:lolevel_scm",(void*)f_1612},
{"f_2625:lolevel_scm",(void*)f_2625},
{"f_2608:lolevel_scm",(void*)f_2608},
{"f_2588:lolevel_scm",(void*)f_2588},
{"f_2592:lolevel_scm",(void*)f_2592},
{"f_2554:lolevel_scm",(void*)f_2554},
{"f_2572:lolevel_scm",(void*)f_2572},
{"f_2564:lolevel_scm",(void*)f_2564},
{"f_2523:lolevel_scm",(void*)f_2523},
{"f_2538:lolevel_scm",(void*)f_2538},
{"f_2536:lolevel_scm",(void*)f_2536},
{"f_2488:lolevel_scm",(void*)f_2488},
{"f_2492:lolevel_scm",(void*)f_2492},
{"f_2513:lolevel_scm",(void*)f_2513},
{"f_2497:lolevel_scm",(void*)f_2497},
{"f_2442:lolevel_scm",(void*)f_2442},
{"f_2432:lolevel_scm",(void*)f_2432},
{"f_2422:lolevel_scm",(void*)f_2422},
{"f_2412:lolevel_scm",(void*)f_2412},
{"f_2402:lolevel_scm",(void*)f_2402},
{"f_2392:lolevel_scm",(void*)f_2392},
{"f_2382:lolevel_scm",(void*)f_2382},
{"f_2372:lolevel_scm",(void*)f_2372},
{"f_2366:lolevel_scm",(void*)f_2366},
{"f_2363:lolevel_scm",(void*)f_2363},
{"f_2356:lolevel_scm",(void*)f_2356},
{"f_2334:lolevel_scm",(void*)f_2334},
{"f_2312:lolevel_scm",(void*)f_2312},
{"f_2294:lolevel_scm",(void*)f_2294},
{"f_2257:lolevel_scm",(void*)f_2257},
{"f_2242:lolevel_scm",(void*)f_2242},
{"f_2246:lolevel_scm",(void*)f_2246},
{"f_2249:lolevel_scm",(void*)f_2249},
{"f_2210:lolevel_scm",(void*)f_2210},
{"f_2237:lolevel_scm",(void*)f_2237},
{"f_2208:lolevel_scm",(void*)f_2208},
{"f_2198:lolevel_scm",(void*)f_2198},
{"f_2189:lolevel_scm",(void*)f_2189},
{"f_2193:lolevel_scm",(void*)f_2193},
{"f_2196:lolevel_scm",(void*)f_2196},
{"f_2183:lolevel_scm",(void*)f_2183},
{"f_2187:lolevel_scm",(void*)f_2187},
{"f_2172:lolevel_scm",(void*)f_2172},
{"f_2180:lolevel_scm",(void*)f_2180},
{"f_2159:lolevel_scm",(void*)f_2159},
{"f_2163:lolevel_scm",(void*)f_2163},
{"f_2170:lolevel_scm",(void*)f_2170},
{"f_2149:lolevel_scm",(void*)f_2149},
{"f_2153:lolevel_scm",(void*)f_2153},
{"f_2140:lolevel_scm",(void*)f_2140},
{"f_2144:lolevel_scm",(void*)f_2144},
{"f_2134:lolevel_scm",(void*)f_2134},
{"f_2128:lolevel_scm",(void*)f_2128},
{"f_2118:lolevel_scm",(void*)f_2118},
{"f_2115:lolevel_scm",(void*)f_2115},
{"f_2034:lolevel_scm",(void*)f_2034},
{"f_2040:lolevel_scm",(void*)f_2040},
{"f_2070:lolevel_scm",(void*)f_2070},
{"f_2085:lolevel_scm",(void*)f_2085},
{"f_2106:lolevel_scm",(void*)f_2106},
{"f_2073:lolevel_scm",(void*)f_2073},
{"f_1713:lolevel_scm",(void*)f_1713},
{"f_1974:lolevel_scm",(void*)f_1974},
{"f_1969:lolevel_scm",(void*)f_1969},
{"f_1964:lolevel_scm",(void*)f_1964},
{"f_1715:lolevel_scm",(void*)f_1715},
{"f_1773:lolevel_scm",(void*)f_1773},
{"f_1776:lolevel_scm",(void*)f_1776},
{"f_1781:lolevel_scm",(void*)f_1781},
{"f_1901:lolevel_scm",(void*)f_1901},
{"f_1933:lolevel_scm",(void*)f_1933},
{"f_1943:lolevel_scm",(void*)f_1943},
{"f_1923:lolevel_scm",(void*)f_1923},
{"f_1868:lolevel_scm",(void*)f_1868},
{"f_1882:lolevel_scm",(void*)f_1882},
{"f_1878:lolevel_scm",(void*)f_1878},
{"f_1859:lolevel_scm",(void*)f_1859},
{"f_1746:lolevel_scm",(void*)f_1746},
{"f_1753:lolevel_scm",(void*)f_1753},
{"f_1730:lolevel_scm",(void*)f_1730},
{"f_1724:lolevel_scm",(void*)f_1724},
{"f_1718:lolevel_scm",(void*)f_1718},
{"f_1708:lolevel_scm",(void*)f_1708},
{"f_1634:lolevel_scm",(void*)f_1634},
{"f_1583:lolevel_scm",(void*)f_1583},
{"f_1510:lolevel_scm",(void*)f_1510},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
