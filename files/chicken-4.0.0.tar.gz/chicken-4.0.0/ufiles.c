/* Generated from files.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:47
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: files.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file ufiles.c
   unit: files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[86];
static double C_possibly_force_alignment;


C_noret_decl(C_files_toplevel)
C_externexport void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static C_word C_fcall f_2501(C_word t0);
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_fcall f_2408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_fcall f_2157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2106)
static void C_fcall f_2106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_fcall f_2101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2079)
static void C_fcall f_2079(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2032)
static void C_fcall f_2032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_fcall f_2027(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2018)
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_fcall f_1935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_fcall f_1971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_fcall f_1904(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1843)
static void C_fcall f_1843(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1852)
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_fcall f_1795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1811)
static void C_fcall f_1811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1728)
static void C_fcall f_1728(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_fcall f_1723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1370)
static void C_fcall f_1370(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1383)
static void C_fcall f_1383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_fcall f_1413(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1323)
static void C_fcall f_1323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1026)
static void C_fcall f_1026(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1039)
static void C_fcall f_1039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1250)
static void C_ccall f_1250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_fcall f_1069(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2408)
static void C_fcall trf_2408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2408(t0,t1);}

C_noret_decl(trf_2157)
static void C_fcall trf_2157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2157(t0,t1);}

C_noret_decl(trf_2106)
static void C_fcall trf_2106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2106(t0,t1);}

C_noret_decl(trf_2101)
static void C_fcall trf_2101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2101(t0,t1,t2);}

C_noret_decl(trf_2079)
static void C_fcall trf_2079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2079(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2079(t0,t1,t2,t3);}

C_noret_decl(trf_2032)
static void C_fcall trf_2032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2032(t0,t1);}

C_noret_decl(trf_2027)
static void C_fcall trf_2027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2027(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2027(t0,t1,t2);}

C_noret_decl(trf_2018)
static void C_fcall trf_2018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2018(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2018(t0,t1,t2,t3);}

C_noret_decl(trf_1935)
static void C_fcall trf_1935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1935(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1935(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1971)
static void C_fcall trf_1971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1971(t0,t1);}

C_noret_decl(trf_1904)
static void C_fcall trf_1904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1904(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1904(t0,t1,t2,t3);}

C_noret_decl(trf_1843)
static void C_fcall trf_1843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1843(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1843(t0,t1,t2,t3);}

C_noret_decl(trf_1852)
static void C_fcall trf_1852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1852(t0,t1,t2);}

C_noret_decl(trf_1795)
static void C_fcall trf_1795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1795(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1795(t0,t1,t2);}

C_noret_decl(trf_1811)
static void C_fcall trf_1811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1811(t0,t1);}

C_noret_decl(trf_1728)
static void C_fcall trf_1728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1728(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1728(t0,t1);}

C_noret_decl(trf_1723)
static void C_fcall trf_1723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1723(t0,t1,t2);}

C_noret_decl(trf_1370)
static void C_fcall trf_1370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1370(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1370(t0,t1,t2,t3);}

C_noret_decl(trf_1383)
static void C_fcall trf_1383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1383(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1383(t0,t1);}

C_noret_decl(trf_1413)
static void C_fcall trf_1413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1413(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1413(t0,t1,t2,t3);}

C_noret_decl(trf_1323)
static void C_fcall trf_1323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1323(t0,t1);}

C_noret_decl(trf_1318)
static void C_fcall trf_1318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1318(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1318(t0,t1,t2);}

C_noret_decl(trf_1026)
static void C_fcall trf_1026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1026(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1026(t0,t1,t2,t3);}

C_noret_decl(trf_1039)
static void C_fcall trf_1039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1039(t0,t1);}

C_noret_decl(trf_1069)
static void C_fcall trf_1069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1069(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1069(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_files_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("files_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(472)){
C_save(t1);
C_rereclaim2(472*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,86);
lf[0]=C_h_intern(&lf[0],12,"file-exists\077");
lf[1]=C_h_intern(&lf[1],11,"delete-file");
lf[2]=C_h_intern(&lf[2],12,"delete-file*");
lf[3]=C_h_intern(&lf[3],9,"file-copy");
lf[4]=C_h_intern(&lf[4],17,"close-output-port");
lf[5]=C_h_intern(&lf[5],16,"close-input-port");
lf[6]=C_h_intern(&lf[6],12,"read-string!");
lf[7]=C_h_intern(&lf[7],9,"condition");
lf[8]=C_h_intern(&lf[8],9,"\003syserror");
lf[9]=C_h_intern(&lf[9],17,"\003sysstring-append");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[11]=C_h_intern(&lf[11],12,"write-string");
lf[12]=C_h_intern(&lf[12],22,"with-exception-handler");
lf[13]=C_h_intern(&lf[13],30,"call-with-current-continuation");
lf[14]=C_h_intern(&lf[14],11,"make-string");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[16]=C_h_intern(&lf[16],16,"open-output-file");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[18]=C_h_intern(&lf[18],15,"open-input-file");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[22]=C_h_intern(&lf[22],9,"file-move");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\034could not remove origfile - ");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[30]=C_h_intern(&lf[30],12,"string-match");
lf[31]=C_h_intern(&lf[31],6,"regexp");
lf[32]=C_h_intern(&lf[32],13,"string-append");
lf[33]=C_h_intern(&lf[33],20,"\003syswindows-platform");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\014([A-Za-z]:)\077");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[36]=C_h_intern(&lf[36],18,"absolute-pathname\077");
lf[38]=C_h_intern(&lf[38],13,"\003syssubstring");
lf[39]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000/\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[40]=C_h_intern(&lf[40],13,"make-pathname");
lf[41]=C_h_intern(&lf[41],22,"make-absolute-pathname");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[52]=C_h_intern(&lf[52],18,"decompose-pathname");
lf[53]=C_h_intern(&lf[53],18,"pathname-directory");
lf[54]=C_h_intern(&lf[54],13,"pathname-file");
lf[55]=C_h_intern(&lf[55],18,"pathname-extension");
lf[56]=C_h_intern(&lf[56],24,"pathname-strip-directory");
lf[57]=C_h_intern(&lf[57],24,"pathname-strip-extension");
lf[58]=C_h_intern(&lf[58],26,"pathname-replace-directory");
lf[59]=C_h_intern(&lf[59],21,"pathname-replace-file");
lf[60]=C_h_intern(&lf[60],26,"pathname-replace-extension");
lf[61]=C_h_intern(&lf[61],6,"getenv");
lf[62]=C_h_intern(&lf[62],21,"call-with-output-file");
lf[63]=C_h_intern(&lf[63],21,"create-temporary-file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[69]=C_h_intern(&lf[69],18,"normalize-pathname");
lf[70]=C_h_intern(&lf[70],7,"mingw32");
lf[71]=C_h_intern(&lf[71],4,"msvc");
lf[72]=C_h_intern(&lf[72],16,"string-translate");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[75]=C_h_intern(&lf[75],14,"build-platform");
lf[76]=C_h_intern(&lf[76],15,"directory-null\077");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[79]=C_h_intern(&lf[79],12,"string-split");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\010[\134/\134\134].*");
lf[84]=C_h_intern(&lf[84],17,"register-feature!");
lf[85]=C_h_intern(&lf[85],5,"files");
C_register_lf2(lf,86,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1001,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k999 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1002 in k999 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 62   register-feature! */
t3=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[85]);}

/* k1005 in k1002 in k999 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=*((C_word*)lf[1]+1);
t4=C_mutate((C_word*)lf[2]+1 /* (set! delete-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1009,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[3]+1 /* (set! file-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1024,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* (set! file-move ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1368,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[30]+1);
t8=*((C_word*)lf[31]+1);
t9=*((C_word*)lf[32]+1);
t10=(C_truep(*((C_word*)lf[33]+1))?lf[34]:lf[35]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1778,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 172  string-append */
t12=t9;
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t10,lf[83]);}

/* k1776 in k1005 in k1002 in k999 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 173  regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* (set! absolute-pathname? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t3=C_mutate(&lf[37] /* (set! chop-pds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1795,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[40] /* make-pathname */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[41] /* make-absolute-pathname */,0,C_SCHEME_UNDEFINED);
t6=*((C_word*)lf[32]+1);
t7=*((C_word*)lf[36]+1);
t8=lf[42];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1843,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1904,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1935,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=C_mutate((C_word*)lf[40]+1 /* (set! make-pathname ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2016,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=C_mutate((C_word*)lf[41]+1 /* (set! make-absolute-pathname ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2077,a[2]=t10,a[3]=t7,a[4]=t8,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t14=*((C_word*)lf[30]+1);
t15=*((C_word*)lf[31]+1);
t16=*((C_word*)lf[32]+1);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2153,a[2]=t15,a[3]=((C_word*)t0)[2],a[4]=t14,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 256  regexp */
t18=t15;
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,t17,lf[82]);}

/* k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 257  regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[81]);}

/* k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2157,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[52]+1 /* (set! decompose-pathname ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t4=C_set_block_item(lf[53] /* pathname-directory */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[54] /* pathname-file */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[55] /* pathname-extension */,0,C_SCHEME_UNDEFINED);
t7=C_set_block_item(lf[56] /* pathname-strip-directory */,0,C_SCHEME_UNDEFINED);
t8=C_set_block_item(lf[57] /* pathname-strip-extension */,0,C_SCHEME_UNDEFINED);
t9=C_set_block_item(lf[58] /* pathname-replace-directory */,0,C_SCHEME_UNDEFINED);
t10=C_set_block_item(lf[59] /* pathname-replace-file */,0,C_SCHEME_UNDEFINED);
t11=C_set_block_item(lf[60] /* pathname-replace-extension */,0,C_SCHEME_UNDEFINED);
t12=*((C_word*)lf[52]+1);
t13=C_mutate((C_word*)lf[53]+1 /* (set! pathname-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[54]+1 /* (set! pathname-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[55]+1 /* (set! pathname-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[56]+1 /* (set! pathname-strip-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2300,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[57]+1 /* (set! pathname-strip-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2318,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[58]+1 /* (set! pathname-replace-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2336,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[59]+1 /* (set! pathname-replace-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[60]+1 /* (set! pathname-replace-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2372,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[61]+1);
t22=*((C_word*)lf[40]+1);
t23=*((C_word*)lf[0]+1);
t24=*((C_word*)lf[62]+1);
t25=C_mutate((C_word*)lf[63]+1 /* (set! create-temporary-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2390,a[2]=t21,a[3]=t22,a[4]=t23,a[5]=t24,tmp=(C_word)a,a+=6,tmp));
t26=C_mutate((C_word*)lf[69]+1 /* (set! normalize-pathname ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2455,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[76]+1 /* (set! directory-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2491,tmp=(C_word)a,a+=2,tmp));
t28=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,C_SCHEME_UNDEFINED);}

/* directory-null? in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2491,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_2499(2,t4,t2);}
else{
t4=(C_word)C_i_check_string_2(t2,lf[76]);
/* files.scm: 361  string-split */
t5=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t2,lf[80],C_SCHEME_TRUE);}}

/* k2497 in directory-null? in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2501,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2501(t1));}

/* loop in k2497 in directory-null? in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static C_word C_fcall f_2501(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_i_car(t1);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[77]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[78]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* normalize-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2455r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2455r(t0,t1,t2,t3);}}

static void C_ccall f_2455r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
/* files.scm: 345  build-platform */
t5=*((C_word*)lf[75]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t4;
f_2459(2,t5,(C_word)C_slot(t3,C_fix(0)));}}

/* k2457 in normalize-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[70]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[71]));
if(C_truep(t3)){
/* files.scm: 348  string-translate */
t4=*((C_word*)lf[72]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[73],lf[74]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}

/* create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2390r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2390r(t0,t1,t2);}}

static void C_ccall f_2390r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* files.scm: 332  getenv */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[68]);}

/* k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_2397(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm: 332  getenv */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[67]);}}

/* k2445 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2397(2,t2,t1);}
else{
/* files.scm: 332  getenv */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[66]);}}

/* k2395 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[6],C_fix(0)):lf[64]);
t4=(C_word)C_i_check_string_2(t3,lf[63]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2408,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_2408(t8,((C_word*)t0)[2]);}

/* loop in k2395 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2408,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 337  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k2436 in loop in k2395 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 337  ##sys#string-append */
t2=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[65],t1);}

/* k2432 in loop in k2395 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 337  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2413 in loop in k2395 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 338  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2419 in k2413 in loop in k2395 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
if(C_truep(t1)){
/* files.scm: 339  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2408(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 340  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a2428 in k2419 in k2413 in loop in k2395 in k2392 in create-temporary-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2429,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2372,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2378,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2384,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a2383 in pathname-replace-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2384,5,t0,t1,t2,t3,t4);}
/* files.scm: 324  make-pathname */
t5=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a2377 in pathname-replace-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
/* files.scm: 323  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2354,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2366,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a2365 in pathname-replace-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2366,5,t0,t1,t2,t3,t4);}
/* files.scm: 319  make-pathname */
t5=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a2359 in pathname-replace-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
/* files.scm: 318  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2336,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2342,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2348,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a2347 in pathname-replace-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2348,5,t0,t1,t2,t3,t4);}
/* files.scm: 314  make-pathname */
t5=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a2341 in pathname-replace-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2342,2,t0,t1);}
/* files.scm: 313  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2318,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2330,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2329 in pathname-strip-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2330,5,t0,t1,t2,t3,t4);}
/* files.scm: 309  make-pathname */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a2323 in pathname-strip-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
/* files.scm: 308  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2300,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2312,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2311 in pathname-strip-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2312,5,t0,t1,t2,t3,t4);}
/* files.scm: 304  make-pathname */
t5=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a2305 in pathname-strip-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
/* files.scm: 303  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2285,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2297,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2296 in pathname-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2297,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2290 in pathname-extension in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
/* files.scm: 298  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2270,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2276,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2282,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2281 in pathname-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2282,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a2275 in pathname-file in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
/* files.scm: 293  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2255,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2261,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2267,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2266 in pathname-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2267,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2260 in pathname-directory in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
/* files.scm: 288  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2171,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* files.scm: 267  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* files.scm: 268  string-match */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k2185 in decompose-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(t1);
/* files.scm: 270  strip-pds */
f_2157(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 271  string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k2214 in k2185 in decompose-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(t1);
/* files.scm: 273  strip-pds */
f_2157(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 274  strip-pds */
f_2157(t2,((C_word*)t0)[2]);}}

/* k2239 in k2214 in k2185 in decompose-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 274  values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2224 in k2214 in k2185 in decompose-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* files.scm: 273  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k2195 in k2185 in decompose-pathname in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t3=(C_word)C_u_i_cddddr(((C_word*)t0)[3]);
t4=(C_word)C_u_i_car(t3);
/* files.scm: 270  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k2154 in k2151 in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2157(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2157,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[50]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[51]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* files.scm: 263  chop-pds */
f_1795(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr4r,(void*)f_2077r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2077r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(14);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2079,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2101,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2106,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext641665 */
t8=t7;
f_2106(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds642661 */
t10=t6;
f_2101(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body639648 */
t12=t5;
f_2079(t12,t1,t8,t10);}}}

/* def-ext641 in make-absolute-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2106,NULL,2,t0,t1);}
/* def-pds642661 */
t2=((C_word*)t0)[2];
f_2101(t2,t1,C_SCHEME_FALSE);}

/* def-pds642 in make-absolute-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2101,NULL,3,t0,t1,t2);}
/* body639648 */
t3=((C_word*)t0)[2];
f_2079(t3,t1,t2,C_SCHEME_FALSE);}

/* body639 in make-absolute-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2079(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2079,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* files.scm: 244  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1904(t5,t4,((C_word*)t0)[2],t3);}

/* k2085 in body639 in make-absolute-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 245  absolute-pathname? */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k2091 in k2085 in body639 in make-absolute-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2090(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
/* files.scm: 247  ##sys#string-append */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}}

/* k2088 in k2085 in body639 in make-absolute-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 242  _make-pathname */
t2=((C_word*)t0)[6];
f_1935(t2,((C_word*)t0)[5],lf[41],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2016r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2016r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2027,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext596612 */
t8=t7;
f_2032(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds597608 */
t10=t6;
f_2027(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body594603 */
t12=t5;
f_2018(t12,t1,t8,t10);}}}

/* def-ext596 in make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2032,NULL,2,t0,t1);}
/* def-pds597608 */
t2=((C_word*)t0)[2];
f_2027(t2,t1,C_SCHEME_FALSE);}

/* def-pds597 in make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2027(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2027,NULL,3,t0,t1,t2);}
/* body594603 */
t3=((C_word*)t0)[2];
f_2018(t3,t1,t2,C_SCHEME_FALSE);}

/* body594 in make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2018,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2026,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 238  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1904(t5,t4,((C_word*)t0)[2],t3);}

/* k2024 in body594 in make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 238  _make-pathname */
t2=((C_word*)t0)[6];
f_1935(t2,((C_word*)t0)[5],lf[40],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_1935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1935,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[45]);
t8=(C_truep(t4)?t4:lf[46]);
t9=(C_truep(t6)?(C_word)C_block_size(t6):C_fix(1));
t10=(C_word)C_i_check_string_2(t3,t2);
t11=(C_word)C_i_check_string_2(t8,t2);
t12=(C_word)C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?(C_word)C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1964,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_block_size(t8);
t16=(C_word)C_fixnum_greater_or_equal_p(t15,t9);
t17=(C_truep(t16)?(C_truep(t6)?(C_word)C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9):(C_word)C_u_i_memq((C_word)C_subchar(t8,C_fix(0)),lf[49])):C_SCHEME_FALSE);
if(C_truep(t17)){
t18=(C_word)C_block_size(t8);
/* files.scm: 228  ##sys#substring */
t19=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t14,t8,t9,t18);}
else{
t18=t14;
f_1964(2,t18,t8);}}

/* k1962 in _make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1971(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_1971(t4,C_SCHEME_FALSE);}}

/* k1969 in k1962 in _make-pathname in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_1971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[47]:lf[48]);
/* files.scm: 222  string-append */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* canonicalize-dirs in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_1904(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1904,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[44]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
/* files.scm: 211  conc-dirs */
t7=((C_word*)t0)[2];
f_1843(t7,t1,t6,t3);}
else{
/* files.scm: 212  conc-dirs */
t6=((C_word*)t0)[2];
f_1843(t6,t1,t2,t3);}}}

/* conc-dirs in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_1843(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1843,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t2,lf[40]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1852(t8,t1,t2);}

/* loop in conc-dirs in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1852,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[43]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
/* files.scm: 203  loop */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_u_i_car(t2);
/* files.scm: 205  chop-pds */
f_1795(t6,t7,((C_word*)t0)[4]);}}}

/* k1880 in loop in conc-dirs in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1890,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* files.scm: 207  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1852(t6,t4,t5);}

/* k1888 in k1880 in loop in conc-dirs in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 204  string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_1795(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1795,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_block_size(t2);
t5=(C_truep(t3)?(C_word)C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1811,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=(C_word)C_u_fixnum_difference(t4,t5);
t8=t6;
f_1811(t8,(C_word)C_substring_compare(t2,t3,t7,C_fix(0),t5));}
else{
t7=(C_word)C_u_fixnum_difference(t4,t5);
t8=(C_word)C_subchar(t2,t7);
t9=t6;
f_1811(t9,(C_word)C_u_i_memq(t8,lf[39]));}}
else{
t7=t6;
f_1811(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1809 in chop-pds in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_fcall f_1811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 187  ##sys#substring */
t3=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1782,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[36]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1793,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 176  string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k1791 in absolute-pathname? in k1779 in k1776 in k1005 in k1002 in k999 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* file-move in k1005 in k1002 in k999 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_1368r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1368r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1368r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber254463 */
t8=t7;
f_1728(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize255459 */
t10=t6;
f_1723(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body252261 */
t12=t5;
f_1370(t12,t1,t8,t10);}}}

/* def-clobber254 in file-move in k1005 in k1002 in k999 */
static void C_fcall f_1728(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1728,NULL,2,t0,t1);}
/* def-blocksize255459 */
t2=((C_word*)t0)[2];
f_1723(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize255 in file-move in k1005 in k1002 in k999 */
static void C_fcall f_1723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1723,NULL,3,t0,t1,t2);}
/* body252261 */
t3=((C_word*)t0)[2];
f_1370(t3,t1,t2,C_fix(1024));}

/* body252 in file-move in k1005 in k1002 in k999 */
static void C_fcall f_1370(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1370,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[22]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[22]);
t6=(C_word)C_i_check_number_2(t3,lf[22]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1383,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_1383(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_1383(t8,C_SCHEME_FALSE);}}

/* k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_fcall f_1383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1383,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1386(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1712,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 124  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[5]);}}

/* k1714 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[29],t1);}

/* k1710 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 122  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 125  file-exists? */
t3=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1392(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1705,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[28],((C_word*)t0)[6]);}}

/* k1703 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 126  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 127  file-exists? */
t4=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1686 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1688,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1395(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[27],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_1395(2,t2,C_SCHEME_FALSE);}}

/* k1696 in k1686 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 129  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1632,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1663,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1662 in a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1674 in a1662 in a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1675r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1675r(t0,t1,t2);}}

static void C_ccall f_1675r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k297302 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1680 in a1674 in a1662 in a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1668 in a1662 in a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
/* files.scm: 132  open-input-file */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1637 in a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1638,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k297302 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1643 in a1637 in a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1655,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t5=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[26],((C_word*)t0)[2]);}

/* k1653 in a1643 in a1637 in a1631 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 134  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1628 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1572,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1574,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1580,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1605,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1604 in a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1616 in a1604 in a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1617r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1617r(t0,t1,t2);}}

static void C_ccall f_1617r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k335340 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1622 in a1616 in a1604 in a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1610 in a1604 in a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
/* files.scm: 137  open-output-file */
t2=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1579 in a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1580,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k335340 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1585 in a1579 in a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t5=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[25],((C_word*)t0)[2]);}

/* k1595 in a1585 in a1579 in a1573 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 139  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1570 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 142  make-string */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* files.scm: 143  read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1413(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_fcall f_1413(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1413,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 147  close-input-port */
t7=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1506,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* call-with-current-continuation */
t9=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1506,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1512,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1547,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1546 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1558 in a1546 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1559r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1559r(t0,t1,t2);}}

static void C_ccall f_1559r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k419424 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1564 in a1558 in a1546 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1552 in a1546 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
/* files.scm: 156  write-string */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1511 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1512,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* k419424 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1517 in a1511 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1518,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 158  close-input-port */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1523 in a1517 in a1511 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 159  close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1526 in k1523 in a1517 in a1511 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1539,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 162  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1537 in k1526 in k1523 in a1517 in a1511 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[24],t1);}

/* k1533 in k1526 in k1523 in a1517 in a1511 in a1505 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 160  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1502 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1488 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 163  read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1495 in k1488 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 163  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1413(t3,((C_word*)t0)[2],t1,t2);}

/* k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 148  close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1432,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1434,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1440,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1464 in a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1476 in a1464 in a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1477r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1477r(t0,t1,t2);}}

static void C_ccall f_1477r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k380385 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1482 in a1476 in a1464 in a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1470 in a1464 in a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
/* files.scm: 149  delete-file */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1439 in a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k380385 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1445 in a1439 in a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1446,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t5=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[23],((C_word*)t0)[2]);}

/* k1455 in a1445 in a1439 in a1433 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 151  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1430 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1427 in k1424 in k1421 in loop in k1409 in k1402 in k1399 in k1396 in k1393 in k1390 in k1387 in k1384 in k1381 in body252 in file-move in k1005 in k1002 in k999 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_1024r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1024r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1024r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1026,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1323,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber50222 */
t8=t7;
f_1323(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize51218 */
t10=t6;
f_1318(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body4857 */
t12=t5;
f_1026(t12,t1,t8,t10);}}}

/* def-clobber50 in file-copy in k1005 in k1002 in k999 */
static void C_fcall f_1323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1323,NULL,2,t0,t1);}
/* def-blocksize51218 */
t2=((C_word*)t0)[2];
f_1318(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize51 in file-copy in k1005 in k1002 in k999 */
static void C_fcall f_1318(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1318,NULL,3,t0,t1,t2);}
/* body4857 */
t3=((C_word*)t0)[2];
f_1026(t3,t1,t2,C_fix(1024));}

/* body48 in file-copy in k1005 in k1002 in k999 */
static void C_fcall f_1026(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1026,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[3]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[3]);
t6=(C_word)C_i_check_number_2(t3,lf[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1039,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_1039(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_1039(t8,C_SCHEME_FALSE);}}

/* k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_fcall f_1039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1039,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1042(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 81   number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[6]);}}

/* k1309 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[21],t1);}

/* k1305 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 79   ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 82   file-exists? */
t3=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1048(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[20],((C_word*)t0)[3]);}}

/* k1298 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 83   ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 84   file-exists? */
t4=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1281 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1283,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1051(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* string-append */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[19],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_1051(2,t2,C_SCHEME_FALSE);}}

/* k1291 in k1281 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 86   ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1225,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1227,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1257 in a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1264,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1269 in a1257 in a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1270r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1270r(t0,t1,t2);}}

static void C_ccall f_1270r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k9398 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1275 in a1269 in a1257 in a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1263 in a1257 in a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1264,2,t0,t1);}
/* files.scm: 89   open-input-file */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1232 in a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1233,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k9398 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1238 in a1232 in a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1250,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t5=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[17],((C_word*)t0)[2]);}

/* k1248 in a1238 in a1232 in a1226 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 91   ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1223 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1167,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1169,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1200,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1199 in a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1211 in a1199 in a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1212r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1212r(t0,t1,t2);}}

static void C_ccall f_1212r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k131136 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1217 in a1211 in a1199 in a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1205 in a1199 in a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1206,2,t0,t1);}
/* files.scm: 94   open-output-file */
t2=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1174 in a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1175,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k131136 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1180 in a1174 in a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1192,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* string-append */
t5=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[15],((C_word*)t0)[2]);}

/* k1190 in a1180 in a1174 in a1168 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 96   ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1165 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 99   make-string */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 100  read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1069(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_fcall f_1069(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1069,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1079,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 104  close-input-port */
t7=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1101,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* call-with-current-continuation */
t9=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1101,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1107,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1142,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1141 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1153 in a1141 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1154r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1154r(t0,t1,t2);}}

static void C_ccall f_1154r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1160,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k178183 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1159 in a1153 in a1141 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1147 in a1141 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1148,2,t0,t1);}
/* files.scm: 108  write-string */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1106 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1107,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* k178183 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1112 in a1106 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1113,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 110  close-input-port */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1118 in a1112 in a1106 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 111  close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1121 in k1118 in a1112 in a1106 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1134,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 114  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1132 in k1121 in k1118 in a1112 in a1106 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[10],t1);}

/* k1128 in k1121 in k1118 in a1112 in a1106 in a1100 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 112  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1097 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1083 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 115  read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1090 in k1083 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 115  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1069(t3,((C_word*)t0)[2],t1,t2);}

/* k1077 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 105  close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1080 in k1077 in loop in k1065 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in body48 in file-copy in k1005 in k1002 in k999 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* delete-file* in k1005 in k1002 in k999 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1009,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1016,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 71   file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1014 in delete-file* in k1005 in k1002 in k999 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 71   delete-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1020 in k1014 in delete-file* in k1005 in k1002 in k999 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[198] = {
{"toplevel:files_scm",(void*)C_files_toplevel},
{"f_1001:files_scm",(void*)f_1001},
{"f_1004:files_scm",(void*)f_1004},
{"f_1007:files_scm",(void*)f_1007},
{"f_1778:files_scm",(void*)f_1778},
{"f_1781:files_scm",(void*)f_1781},
{"f_2153:files_scm",(void*)f_2153},
{"f_2156:files_scm",(void*)f_2156},
{"f_2491:files_scm",(void*)f_2491},
{"f_2499:files_scm",(void*)f_2499},
{"f_2501:files_scm",(void*)f_2501},
{"f_2455:files_scm",(void*)f_2455},
{"f_2459:files_scm",(void*)f_2459},
{"f_2390:files_scm",(void*)f_2390},
{"f_2394:files_scm",(void*)f_2394},
{"f_2447:files_scm",(void*)f_2447},
{"f_2397:files_scm",(void*)f_2397},
{"f_2408:files_scm",(void*)f_2408},
{"f_2438:files_scm",(void*)f_2438},
{"f_2434:files_scm",(void*)f_2434},
{"f_2415:files_scm",(void*)f_2415},
{"f_2421:files_scm",(void*)f_2421},
{"f_2429:files_scm",(void*)f_2429},
{"f_2372:files_scm",(void*)f_2372},
{"f_2384:files_scm",(void*)f_2384},
{"f_2378:files_scm",(void*)f_2378},
{"f_2354:files_scm",(void*)f_2354},
{"f_2366:files_scm",(void*)f_2366},
{"f_2360:files_scm",(void*)f_2360},
{"f_2336:files_scm",(void*)f_2336},
{"f_2348:files_scm",(void*)f_2348},
{"f_2342:files_scm",(void*)f_2342},
{"f_2318:files_scm",(void*)f_2318},
{"f_2330:files_scm",(void*)f_2330},
{"f_2324:files_scm",(void*)f_2324},
{"f_2300:files_scm",(void*)f_2300},
{"f_2312:files_scm",(void*)f_2312},
{"f_2306:files_scm",(void*)f_2306},
{"f_2285:files_scm",(void*)f_2285},
{"f_2297:files_scm",(void*)f_2297},
{"f_2291:files_scm",(void*)f_2291},
{"f_2270:files_scm",(void*)f_2270},
{"f_2282:files_scm",(void*)f_2282},
{"f_2276:files_scm",(void*)f_2276},
{"f_2255:files_scm",(void*)f_2255},
{"f_2267:files_scm",(void*)f_2267},
{"f_2261:files_scm",(void*)f_2261},
{"f_2171:files_scm",(void*)f_2171},
{"f_2187:files_scm",(void*)f_2187},
{"f_2216:files_scm",(void*)f_2216},
{"f_2241:files_scm",(void*)f_2241},
{"f_2226:files_scm",(void*)f_2226},
{"f_2197:files_scm",(void*)f_2197},
{"f_2157:files_scm",(void*)f_2157},
{"f_2077:files_scm",(void*)f_2077},
{"f_2106:files_scm",(void*)f_2106},
{"f_2101:files_scm",(void*)f_2101},
{"f_2079:files_scm",(void*)f_2079},
{"f_2087:files_scm",(void*)f_2087},
{"f_2093:files_scm",(void*)f_2093},
{"f_2090:files_scm",(void*)f_2090},
{"f_2016:files_scm",(void*)f_2016},
{"f_2032:files_scm",(void*)f_2032},
{"f_2027:files_scm",(void*)f_2027},
{"f_2018:files_scm",(void*)f_2018},
{"f_2026:files_scm",(void*)f_2026},
{"f_1935:files_scm",(void*)f_1935},
{"f_1964:files_scm",(void*)f_1964},
{"f_1971:files_scm",(void*)f_1971},
{"f_1904:files_scm",(void*)f_1904},
{"f_1843:files_scm",(void*)f_1843},
{"f_1852:files_scm",(void*)f_1852},
{"f_1882:files_scm",(void*)f_1882},
{"f_1890:files_scm",(void*)f_1890},
{"f_1795:files_scm",(void*)f_1795},
{"f_1811:files_scm",(void*)f_1811},
{"f_1782:files_scm",(void*)f_1782},
{"f_1793:files_scm",(void*)f_1793},
{"f_1368:files_scm",(void*)f_1368},
{"f_1728:files_scm",(void*)f_1728},
{"f_1723:files_scm",(void*)f_1723},
{"f_1370:files_scm",(void*)f_1370},
{"f_1383:files_scm",(void*)f_1383},
{"f_1716:files_scm",(void*)f_1716},
{"f_1712:files_scm",(void*)f_1712},
{"f_1386:files_scm",(void*)f_1386},
{"f_1389:files_scm",(void*)f_1389},
{"f_1705:files_scm",(void*)f_1705},
{"f_1392:files_scm",(void*)f_1392},
{"f_1688:files_scm",(void*)f_1688},
{"f_1698:files_scm",(void*)f_1698},
{"f_1395:files_scm",(void*)f_1395},
{"f_1632:files_scm",(void*)f_1632},
{"f_1663:files_scm",(void*)f_1663},
{"f_1675:files_scm",(void*)f_1675},
{"f_1681:files_scm",(void*)f_1681},
{"f_1669:files_scm",(void*)f_1669},
{"f_1638:files_scm",(void*)f_1638},
{"f_1644:files_scm",(void*)f_1644},
{"f_1655:files_scm",(void*)f_1655},
{"f_1630:files_scm",(void*)f_1630},
{"f_1398:files_scm",(void*)f_1398},
{"f_1574:files_scm",(void*)f_1574},
{"f_1605:files_scm",(void*)f_1605},
{"f_1617:files_scm",(void*)f_1617},
{"f_1623:files_scm",(void*)f_1623},
{"f_1611:files_scm",(void*)f_1611},
{"f_1580:files_scm",(void*)f_1580},
{"f_1586:files_scm",(void*)f_1586},
{"f_1597:files_scm",(void*)f_1597},
{"f_1572:files_scm",(void*)f_1572},
{"f_1401:files_scm",(void*)f_1401},
{"f_1404:files_scm",(void*)f_1404},
{"f_1411:files_scm",(void*)f_1411},
{"f_1413:files_scm",(void*)f_1413},
{"f_1506:files_scm",(void*)f_1506},
{"f_1547:files_scm",(void*)f_1547},
{"f_1559:files_scm",(void*)f_1559},
{"f_1565:files_scm",(void*)f_1565},
{"f_1553:files_scm",(void*)f_1553},
{"f_1512:files_scm",(void*)f_1512},
{"f_1518:files_scm",(void*)f_1518},
{"f_1525:files_scm",(void*)f_1525},
{"f_1528:files_scm",(void*)f_1528},
{"f_1539:files_scm",(void*)f_1539},
{"f_1535:files_scm",(void*)f_1535},
{"f_1504:files_scm",(void*)f_1504},
{"f_1490:files_scm",(void*)f_1490},
{"f_1497:files_scm",(void*)f_1497},
{"f_1423:files_scm",(void*)f_1423},
{"f_1426:files_scm",(void*)f_1426},
{"f_1434:files_scm",(void*)f_1434},
{"f_1465:files_scm",(void*)f_1465},
{"f_1477:files_scm",(void*)f_1477},
{"f_1483:files_scm",(void*)f_1483},
{"f_1471:files_scm",(void*)f_1471},
{"f_1440:files_scm",(void*)f_1440},
{"f_1446:files_scm",(void*)f_1446},
{"f_1457:files_scm",(void*)f_1457},
{"f_1432:files_scm",(void*)f_1432},
{"f_1429:files_scm",(void*)f_1429},
{"f_1024:files_scm",(void*)f_1024},
{"f_1323:files_scm",(void*)f_1323},
{"f_1318:files_scm",(void*)f_1318},
{"f_1026:files_scm",(void*)f_1026},
{"f_1039:files_scm",(void*)f_1039},
{"f_1311:files_scm",(void*)f_1311},
{"f_1307:files_scm",(void*)f_1307},
{"f_1042:files_scm",(void*)f_1042},
{"f_1045:files_scm",(void*)f_1045},
{"f_1300:files_scm",(void*)f_1300},
{"f_1048:files_scm",(void*)f_1048},
{"f_1283:files_scm",(void*)f_1283},
{"f_1293:files_scm",(void*)f_1293},
{"f_1051:files_scm",(void*)f_1051},
{"f_1227:files_scm",(void*)f_1227},
{"f_1258:files_scm",(void*)f_1258},
{"f_1270:files_scm",(void*)f_1270},
{"f_1276:files_scm",(void*)f_1276},
{"f_1264:files_scm",(void*)f_1264},
{"f_1233:files_scm",(void*)f_1233},
{"f_1239:files_scm",(void*)f_1239},
{"f_1250:files_scm",(void*)f_1250},
{"f_1225:files_scm",(void*)f_1225},
{"f_1054:files_scm",(void*)f_1054},
{"f_1169:files_scm",(void*)f_1169},
{"f_1200:files_scm",(void*)f_1200},
{"f_1212:files_scm",(void*)f_1212},
{"f_1218:files_scm",(void*)f_1218},
{"f_1206:files_scm",(void*)f_1206},
{"f_1175:files_scm",(void*)f_1175},
{"f_1181:files_scm",(void*)f_1181},
{"f_1192:files_scm",(void*)f_1192},
{"f_1167:files_scm",(void*)f_1167},
{"f_1057:files_scm",(void*)f_1057},
{"f_1060:files_scm",(void*)f_1060},
{"f_1067:files_scm",(void*)f_1067},
{"f_1069:files_scm",(void*)f_1069},
{"f_1101:files_scm",(void*)f_1101},
{"f_1142:files_scm",(void*)f_1142},
{"f_1154:files_scm",(void*)f_1154},
{"f_1160:files_scm",(void*)f_1160},
{"f_1148:files_scm",(void*)f_1148},
{"f_1107:files_scm",(void*)f_1107},
{"f_1113:files_scm",(void*)f_1113},
{"f_1120:files_scm",(void*)f_1120},
{"f_1123:files_scm",(void*)f_1123},
{"f_1134:files_scm",(void*)f_1134},
{"f_1130:files_scm",(void*)f_1130},
{"f_1099:files_scm",(void*)f_1099},
{"f_1085:files_scm",(void*)f_1085},
{"f_1092:files_scm",(void*)f_1092},
{"f_1079:files_scm",(void*)f_1079},
{"f_1082:files_scm",(void*)f_1082},
{"f_1009:files_scm",(void*)f_1009},
{"f_1016:files_scm",(void*)f_1016},
{"f_1022:files_scm",(void*)f_1022},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
