/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:49
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: chicken-bug.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -output-file chicken-bug.c
   used units: library eval data_structures ports extras srfi_69 srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[143];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_335)
static void C_ccall f_335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_338)
static void C_ccall f_338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_341)
static void C_ccall f_341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_359)
static void C_ccall f_359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_362)
static void C_ccall f_362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_783)
static void C_fcall f_783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_fcall f_794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_802)
static void C_ccall f_802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_607)
static void C_ccall f_607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_729)
static void C_ccall f_729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_686)
static void C_ccall f_686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_614)
static void C_fcall f_614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_617)
static void C_ccall f_617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_620)
static void C_ccall f_620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_674)
static void C_ccall f_674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_653)
static void C_ccall f_653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_588)
static void C_ccall f_588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_579)
static void C_ccall f_579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_573)
static void C_ccall f_573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_560)
static void C_ccall f_560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_564)
static void C_ccall f_564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_378)
static void C_ccall f_378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_381)
static void C_ccall f_381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_554)
static void C_ccall f_554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_384)
static void C_ccall f_384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_ccall f_387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_390)
static void C_ccall f_390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_393)
static void C_ccall f_393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_538)
static void C_ccall f_538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_399)
static void C_ccall f_399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_405)
static void C_ccall f_405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_526)
static void C_ccall f_526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_408)
static void C_ccall f_408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_411)
static void C_ccall f_411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_518)
static void C_ccall f_518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_514)
static void C_ccall f_514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_481)
static void C_ccall f_481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_420)
static void C_ccall f_420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_475)
static void C_ccall f_475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_426)
static void C_ccall f_426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_451)
static void C_ccall f_451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_429)
static void C_ccall f_429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_371)
static void C_ccall f_371(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_783)
static void C_fcall trf_783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_783(t0,t1);}

C_noret_decl(trf_794)
static void C_fcall trf_794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_794(t0,t1);}

C_noret_decl(trf_614)
static void C_fcall trf_614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_614(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(616)){
C_save(t1);
C_rereclaim2(616*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,143);
lf[0]=C_h_intern(&lf[0],7,"user-id");
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\017<not available>");
lf[2]=C_h_intern(&lf[2],12,"collect-info");
lf[3]=C_h_intern(&lf[3],7,"newline");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_h_intern(&lf[5],8,"read-all");
lf[6]=C_h_intern(&lf[6],20,"with-input-from-pipe");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[8]=C_h_intern(&lf[8],5,"print");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[11]=C_h_intern(&lf[11],8,"feature\077");
lf[12]=C_h_intern(&lf[12],4,"unix");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_h_intern(&lf[14],20,"with-input-from-file");
lf[15]=C_h_intern(&lf[15],13,"make-pathname");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[18]=C_h_intern(&lf[18],6,"printf");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[20]=C_h_intern(&lf[20],11,"make-string");
lf[21]=C_h_intern(&lf[21],12,"\003sysfor-each");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[23]=C_h_intern(&lf[23],4,"chop");
lf[24]=C_h_intern(&lf[24],4,"sort");
lf[25]=C_h_intern(&lf[25],8,"string<\077");
lf[26]=C_h_intern(&lf[26],7,"\003sysmap");
lf[27]=C_h_intern(&lf[27],15,"keyword->string");
lf[28]=C_h_intern(&lf[28],12,"\003sysfeatures");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\024Include path:\011~s~%~%");
lf[31]=C_h_intern(&lf[31],21,"\003sysinclude-pathnames");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[34]=C_h_intern(&lf[34],12,"chicken-home");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[37]=C_h_intern(&lf[37],15,"chicken-version");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[40]=C_h_intern(&lf[40],14,"build-platform");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[42]=C_h_intern(&lf[42],16,"software-version");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[44]=C_h_intern(&lf[44],13,"software-type");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[46]=C_h_intern(&lf[46],12,"machine-type");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\030User information:\011~s~%~%");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[51]=C_h_intern(&lf[51],15,"seconds->string");
lf[52]=C_h_intern(&lf[52],15,"current-seconds");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[55]=C_h_intern(&lf[55],5,"usage");
lf[56]=C_h_intern(&lf[56],4,"exit");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[58]=C_h_intern(&lf[58],10,"user-input");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\001VThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012once you have fini"
"shed. Press CTRL-C to abort the program. You can\012also pass the description from "
"a file (just abort now and re-invoke\012\042chicken-bug\042 with one or more input files "
"given on the command-line)\012");
lf[60]=C_h_intern(&lf[60],13,"\003systty-port\077");
lf[61]=C_h_intern(&lf[61],18,"current-input-port");
lf[62]=C_h_intern(&lf[62],7,"justify");
lf[63]=C_h_intern(&lf[63],13,"string-append");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[65]=C_h_intern(&lf[65],4,"main");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[67]=C_h_intern(&lf[67],8,"try-mail");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014mx10.gnu.org\376\003\000\000\002\376B\000\000\014mx20.gnu.org\376\377\016");
lf[69]=C_h_intern(&lf[69],21,"with-output-to-string");
lf[70]=C_h_intern(&lf[70],12,"mail-headers");
lf[71]=C_h_intern(&lf[71],7,"sprintf");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[73]=C_h_intern(&lf[73],19,"seconds->local-time");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000G\012Could not send mail automatically!\012\012A bug report has been written to `");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[87]=C_h_intern(&lf[87],19,"with-output-to-file");
lf[88]=C_h_intern(&lf[88],9,"send-mail");
lf[89]=C_h_intern(&lf[89],13,"mail-date-str");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[94]=C_h_intern(&lf[94],10,"string-pad");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[119]=C_h_intern(&lf[119],17,"seconds->utc-time");
lf[120]=C_h_intern(&lf[120],9,"mail-read");
lf[121]=C_h_intern(&lf[121],9,"substring");
lf[122]=C_h_intern(&lf[122],9,"condition");
lf[123]=C_h_intern(&lf[123],17,"close-output-port");
lf[124]=C_h_intern(&lf[124],16,"close-input-port");
lf[125]=C_h_intern(&lf[125],9,"read-line");
lf[126]=C_h_intern(&lf[126],22,"with-exception-handler");
lf[127]=C_h_intern(&lf[127],30,"call-with-current-continuation");
lf[128]=C_h_intern(&lf[128],10,"mail-write");
lf[129]=C_h_intern(&lf[129],10,"mail-check");
lf[130]=C_h_intern(&lf[130],11,"tcp-connect");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000QBug report successfully mailed to the Chicken maintainers.\012Thank you very m"
"uch!\012\012");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[141]=C_h_intern(&lf[141],25,"\003sysimplicit-exit-handler");
lf[142]=C_h_intern(&lf[142],22,"command-line-arguments");
C_register_lf2(lf,143,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_332,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k330 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k333 in k330 */
static void C_ccall f_335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k336 in k333 in k330 */
static void C_ccall f_338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k339 in k336 in k333 in k330 */
static void C_ccall f_341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_365,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_371,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! collect-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_374,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[55]+1 /* (set! usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_560,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[58]+1 /* (set! user-input ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_569,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[62]+1 /* (set! justify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_588,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[65]+1 /* (set! main ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_607,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[67]+1 /* (set! try-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_731,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[89]+1 /* (set! mail-date-str ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_772,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[70]+1 /* (set! mail-headers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_960,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[120]+1 /* (set! mail-read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_978,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[128]+1 /* (set! mail-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1064,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[129]+1 /* (set! mail-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1133,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[88]+1 /* (set! send-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1154,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 258  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[142]))(2,*((C_word*)lf[142]+1),t16);}

/* k1245 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 258  main */
((C_proc3)C_retrieve_symbol_proc(lf[65]))(3,*((C_word*)lf[65]+1),((C_word*)t0)[2],t1);}

/* k1235 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1243,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[141]))(2,*((C_word*)lf[141]+1),t3);}

/* k1241 in k1235 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1238 in k1235 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1154,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1158,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 241  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t6,lf[139],t2,lf[140]);}

/* k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1169,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 244  call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t1,t4);}

/* a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1175,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1234,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 246  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1232 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 246  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[129]))(7,*((C_word*)lf[129]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 247  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[138]);}

/* k1228 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 247  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[129]))(7,*((C_word*)lf[129]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 248  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[137]);}

/* k1224 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 248  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[129]))(7,*((C_word*)lf[129]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1222,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 249  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[136]);}

/* k1220 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 249  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[129]))(7,*((C_word*)lf[129]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 250  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[135]);}

/* k1216 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 250  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[129]))(7,*((C_word*)lf[129]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1194,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 251  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[63]+1)))(7,*((C_word*)lf[63]+1),t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[133],((C_word*)t0)[2],lf[134]);}

/* k1212 in k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 251  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1208 in k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 251  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[129]))(7,*((C_word*)lf[129]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 252  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[132],((C_word*)t0)[3]);}

/* k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 253  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,((C_word*)t0)[2]);}

/* k1198 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 254  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2]);}

/* k1201 in k1198 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 255  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[131]);}

/* k1204 in k1201 in k1198 in k1195 in k1192 in k1189 in k1186 in k1183 in k1180 in k1177 in a1174 in a1168 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* a1162 in k1156 in send-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
/* chicken-bug.scm: 243  tcp-connect */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t1,((C_word*)t0)[2],C_fix(25));}

/* mail-check in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1133,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?(C_word)C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1143,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 236  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t8,t2);}}

/* k1141 in mail-check in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 237  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2]);}

/* k1144 in k1141 in mail-check in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 238  k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1064,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1068,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1079,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t6,t7);}

/* a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1079,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1085,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1109,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t1,t3,t4);}

/* a1108 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1120 in a1108 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1121r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1121r(t0,t1,t2);}}

static void C_ccall f_1121r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k226231 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1126 in a1120 in a1108 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1114 in a1108 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
/* chicken-bug.scm: 226  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1084 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1085,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k226231 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1090 in a1084 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[122]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1098,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 227  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t4,((C_word*)t0)[2]);}

/* k1096 in a1090 in a1084 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 227  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2]);}

/* k1099 in k1096 in a1090 in a1084 in a1078 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1075 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1066 in mail-write in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 229  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_978,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_982,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1010,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t5,t6);}

/* a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1010,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1016,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1040,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t1,t3,t4);}

/* a1039 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1051 in a1039 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1052r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1052r(t0,t1,t2);}}

static void C_ccall f_1052r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k180185 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1057 in a1051 in a1039 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1045 in a1039 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
/* chicken-bug.scm: 217  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[125]))(3,*((C_word*)lf[125]+1),t1,((C_word*)t0)[2]);}

/* a1015 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k180185 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1021 in a1015 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[122]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 218  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t4,((C_word*)t0)[2]);}

/* k1027 in a1021 in a1015 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 218  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2]);}

/* k1030 in k1027 in a1021 in a1015 in a1009 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1006 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k980 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 221  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[121]+1)))(5,*((C_word*)lf[121]+1),t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm: 222  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k996 in k980 in mail-read in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 221  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_976,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 211  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t4);}

/* k974 in mail-headers in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 211  seconds->utc-time */
((C_proc3)C_retrieve_symbol_proc(lf[119]))(3,*((C_word*)lf[119]+1),((C_word*)t0)[2],t1);}

/* k970 in mail-headers in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 211  mail-date-str */
((C_proc3)C_retrieve_symbol_proc(lf[89]))(3,*((C_word*)lf[89]+1),((C_word*)t0)[2],t1);}

/* k966 in mail-headers in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 210  string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[63]+1)))(8,*((C_word*)lf[63]+1),((C_word*)t0)[2],lf[114],t1,lf[115],lf[116],lf[117],lf[118]);}

/* mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_772,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_783,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_783(t5,lf[107]);
case C_fix(1):
t5=t4;
f_783(t5,lf[108]);
case C_fix(2):
t5=t4;
f_783(t5,lf[109]);
case C_fix(3):
t5=t4;
f_783(t5,lf[110]);
case C_fix(4):
t5=t4;
f_783(t5,lf[111]);
case C_fix(5):
t5=t4;
f_783(t5,lf[112]);
default:
t5=(C_word)C_eqp(t3,C_fix(6));
t6=t4;
f_783(t6,(C_truep(t5)?lf[113]:C_SCHEME_UNDEFINED));}}

/* k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_783,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_787,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_915,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm: 186  number->string */
C_number_to_string(3,0,t3,t4);}

/* k913 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 186  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[94]))(5,*((C_word*)lf[94]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_787,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_794(t4,lf[95]);
case C_fix(1):
t4=t3;
f_794(t4,lf[96]);
case C_fix(2):
t4=t3;
f_794(t4,lf[97]);
case C_fix(3):
t4=t3;
f_794(t4,lf[98]);
case C_fix(4):
t4=t3;
f_794(t4,lf[99]);
case C_fix(5):
t4=t3;
f_794(t4,lf[100]);
case C_fix(6):
t4=t3;
f_794(t4,lf[101]);
case C_fix(7):
t4=t3;
f_794(t4,lf[102]);
case C_fix(8):
t4=t3;
f_794(t4,lf[103]);
case C_fix(9):
t4=t3;
f_794(t4,lf[104]);
case C_fix(10):
t4=t3;
f_794(t4,lf[105]);
default:
t4=(C_word)C_eqp(t2,C_fix(11));
t5=t3;
f_794(t5,(C_truep(t4)?lf[106]:C_SCHEME_UNDEFINED));}}

/* k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_794,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_798,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=(C_word)C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm: 200  number->string */
C_number_to_string(3,0,t2,t4);}

/* k796 in k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_802,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_830,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm: 202  number->string */
C_number_to_string(3,0,t3,t4);}

/* k828 in k796 in k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 202  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[94]))(5,*((C_word*)lf[94]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k800 in k796 in k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_822,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm: 204  number->string */
C_number_to_string(3,0,t3,t4);}

/* k820 in k800 in k796 in k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 204  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[94]))(5,*((C_word*)lf[94]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k804 in k800 in k796 in k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_810,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_814,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm: 206  number->string */
C_number_to_string(3,0,t3,t4);}

/* k812 in k804 in k800 in k796 in k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 206  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[94]))(5,*((C_word*)lf[94]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k808 in k804 in k800 in k796 in k792 in k785 in k781 in mail-date-str in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 177  string-append */
((C_proc13)C_retrieve_proc(*((C_word*)lf[63]+1)))(13,*((C_word*)lf[63]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[90],((C_word*)t0)[3],lf[91],((C_word*)t0)[2],lf[92],t1,lf[93]);}

/* try-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_731,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_741,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_749,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 169  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_756,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-bug.scm: 173  send-mail */
((C_proc6)C_retrieve_symbol_proc(lf[88]))(6,*((C_word*)lf[88]+1),t6,t7,t5,t4,t3);}}

/* k754 in try-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm: 174  try-mail */
((C_proc6)C_retrieve_symbol_proc(lf[67]))(6,*((C_word*)lf[67]+1),((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a748 in try-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_749,2,t0,t1);}
/* chicken-bug.scm: 170  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t1,((C_word*)t0)[2]);}

/* k739 in try-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 171  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,lf[85],((C_word*)t0)[2],lf[86]);}

/* k742 in k739 in try-mail in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 172  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[83],lf[84]);}

/* main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_607,3,t0,t1,t2);}
t3=lf[66];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_611,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_688,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* for-each */
t11=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t2);}

/* a687 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_688,3,t0,t1,t2);}
if(C_truep((C_word)C_i_string_equal_p(lf[75],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_700,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_704,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 123  user-input */
((C_proc2)C_retrieve_symbol_proc(lf[58]))(2,*((C_word*)lf[58]+1),t5);}
else{
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[77]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[78]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[79]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-bug.scm: 125  usage */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),t1,C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[80],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_725,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_729,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 134  read-all */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),t6,t2);}}}}

/* k727 in a687 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 131  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[63]+1)))(7,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[81],((C_word*)t0)[2],lf[82],t1);}

/* k723 in a687 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k702 in a687 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 123  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[76],t1);}

/* k698 in a687 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_614(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_682,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_686,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 137  user-input */
((C_proc2)C_retrieve_symbol_proc(lf[58]))(2,*((C_word*)lf[58]+1),t4);}}

/* k684 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 137  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[74],t1);}

/* k680 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_614(t3,t2);}

/* k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 138  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[3]+1)))(2,*((C_word*)lf[3]+1),t2);}

/* k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 139  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t3);}

/* k676 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 139  seconds->local-time */
((C_proc3)C_retrieve_symbol_proc(lf[73]))(3,*((C_word*)lf[73]+1),((C_word*)t0)[2],t1);}

/* k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_620,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(3));
t3=(C_word)C_i_vector_ref(t1,C_fix(4));
t4=(C_word)C_i_vector_ref(t1,C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_635,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 145  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_670,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 149  justify */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t7,t3);}}

/* k668 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_674,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 149  justify */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2]);}

/* k672 in k668 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 149  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[71]))(6,*((C_word*)lf[71]+1),((C_word*)t0)[4],lf[72],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k643 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_649,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 150  mail-headers */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t2);}

/* k647 in k643 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_653,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 151  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),t2,t3);}

/* a654 in k647 in k643 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 153  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k657 in a654 in k647 in k643 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 154  collect-info */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),((C_word*)t0)[2]);}

/* k651 in k647 in k643 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 147  try-mail */
((C_proc6)C_retrieve_symbol_proc(lf[67]))(6,*((C_word*)lf[67]+1),((C_word*)t0)[4],lf[68],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k633 in k618 in k615 in k612 in k609 in main in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 146  collect-info */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),((C_word*)t0)[2]);}

/* justify in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_592,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 110  number->string */
C_number_to_string(3,0,t3,t2);}

/* k590 in justify in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(1)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-bug.scm: 113  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[2],lf[64],t1);}}

/* user-input in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_573,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_586,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 97   current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[61]+1)))(2,*((C_word*)lf[61]+1),t4);}

/* k584 in user-input in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 97   ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),((C_word*)t0)[2],t1);}

/* k577 in user-input in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 98   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[59]);}
else{
t2=((C_word*)t0)[2];
f_573(2,t2,C_SCHEME_UNDEFINED);}}

/* k571 in user-input in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 107  read-all */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),((C_word*)t0)[2]);}

/* usage in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_564,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 82   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t3,lf[57]);}

/* k562 in usage in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 94   exit */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_378,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 48   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[54]);}

/* k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 49   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[53]);}

/* k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_554,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_558,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 50   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t4);}

/* k556 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 50   seconds->string */
((C_proc3)C_retrieve_symbol_proc(lf[51]))(3,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1);}

/* k552 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 50   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[49],t1,lf[50]);}

/* k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 51   printf */
((C_proc4)C_retrieve_symbol_proc(lf[18]))(4,*((C_word*)lf[18]+1),t2,lf[48],lf[1]);}

/* k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 52   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[47]);}

/* k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_546,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 53   machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[46]))(2,*((C_word*)lf[46]+1),t3);}

/* k544 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 53   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[45],t1);}

/* k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 54   software-type */
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}

/* k540 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 54   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[43],t1);}

/* k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 55   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[42]))(2,*((C_word*)lf[42]+1),t3);}

/* k536 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 55   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[41],t1);}

/* k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_534,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 56   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[40]))(2,*((C_word*)lf[40]+1),t3);}

/* k532 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 56   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[38],t1,lf[39]);}

/* k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 57   chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t3,C_SCHEME_TRUE);}

/* k528 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[35],t1,lf[36]);}

/* k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_526,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 58   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[34]))(2,*((C_word*)lf[34]+1),t3);}

/* k524 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[32],t1,lf[33]);}

/* k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 59   printf */
((C_proc4)C_retrieve_symbol_proc(lf[18]))(4,*((C_word*)lf[18]+1),t2,lf[30],C_retrieve(lf[31]));}

/* k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 60   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[29]);}

/* k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_481,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_514,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_518,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_522,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[27]),C_retrieve(lf[28]));}

/* k520 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 68   sort */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[2],t1,*((C_word*)lf[25]+1));}

/* k516 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 68   chop */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1,C_fix(5));}

/* k512 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a480 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_485,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 63   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t3,lf[22]);}

/* k483 in a480 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_490,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a489 in k483 in a480 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_490,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_498,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* chicken-bug.scm: 66   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),t3,t6,C_make_character(32));}

/* k496 in a489 in k483 in a480 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 66   printf */
((C_proc5)C_retrieve_symbol_proc(lf[18]))(5,*((C_word*)lf[18]+1),((C_word*)t0)[3],lf[19],((C_word*)t0)[2],t1);}

/* k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_420,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 69   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[17]);}

/* k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_479,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k477 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 70   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1,lf[16]);}

/* k463 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_467,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 70   with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),((C_word*)t0)[2],t1,t2);}

/* a466 in k463 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_475,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 72   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t2);}

/* k473 in a466 in k463 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 72   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 73   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[3]+1)))(2,*((C_word*)lf[3]+1),t2);}

/* k424 in k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_429,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_461,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k459 in k424 in k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(t1,lf[10]))){
/* chicken-bug.scm: 74   feature? */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[12]);}
else{
t2=((C_word*)t0)[2];
f_435(2,t2,C_SCHEME_FALSE);}}

/* k433 in k424 in k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_435,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 75   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[9]);}
else{
t2=((C_word*)t0)[2];
f_429(2,t2,C_SCHEME_UNDEFINED);}}

/* k436 in k433 in k424 in k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_443,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 76   with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],lf[7],t2);}

/* a442 in k436 in k433 in k424 in k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_451,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 78   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t2);}

/* k449 in a442 in k436 in k433 in k424 in k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 78   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k427 in k424 in k421 in k418 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in collect-info in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 79   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[3]+1)))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* user-id in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_371,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[162] = {
{"toplevel:chicken_bug_scm",(void*)C_toplevel},
{"f_332:chicken_bug_scm",(void*)f_332},
{"f_335:chicken_bug_scm",(void*)f_335},
{"f_338:chicken_bug_scm",(void*)f_338},
{"f_341:chicken_bug_scm",(void*)f_341},
{"f_344:chicken_bug_scm",(void*)f_344},
{"f_347:chicken_bug_scm",(void*)f_347},
{"f_350:chicken_bug_scm",(void*)f_350},
{"f_353:chicken_bug_scm",(void*)f_353},
{"f_356:chicken_bug_scm",(void*)f_356},
{"f_359:chicken_bug_scm",(void*)f_359},
{"f_362:chicken_bug_scm",(void*)f_362},
{"f_365:chicken_bug_scm",(void*)f_365},
{"f_1247:chicken_bug_scm",(void*)f_1247},
{"f_1237:chicken_bug_scm",(void*)f_1237},
{"f_1243:chicken_bug_scm",(void*)f_1243},
{"f_1240:chicken_bug_scm",(void*)f_1240},
{"f_1154:chicken_bug_scm",(void*)f_1154},
{"f_1158:chicken_bug_scm",(void*)f_1158},
{"f_1169:chicken_bug_scm",(void*)f_1169},
{"f_1175:chicken_bug_scm",(void*)f_1175},
{"f_1234:chicken_bug_scm",(void*)f_1234},
{"f_1179:chicken_bug_scm",(void*)f_1179},
{"f_1230:chicken_bug_scm",(void*)f_1230},
{"f_1182:chicken_bug_scm",(void*)f_1182},
{"f_1226:chicken_bug_scm",(void*)f_1226},
{"f_1185:chicken_bug_scm",(void*)f_1185},
{"f_1222:chicken_bug_scm",(void*)f_1222},
{"f_1188:chicken_bug_scm",(void*)f_1188},
{"f_1218:chicken_bug_scm",(void*)f_1218},
{"f_1191:chicken_bug_scm",(void*)f_1191},
{"f_1214:chicken_bug_scm",(void*)f_1214},
{"f_1210:chicken_bug_scm",(void*)f_1210},
{"f_1194:chicken_bug_scm",(void*)f_1194},
{"f_1197:chicken_bug_scm",(void*)f_1197},
{"f_1200:chicken_bug_scm",(void*)f_1200},
{"f_1203:chicken_bug_scm",(void*)f_1203},
{"f_1206:chicken_bug_scm",(void*)f_1206},
{"f_1163:chicken_bug_scm",(void*)f_1163},
{"f_1133:chicken_bug_scm",(void*)f_1133},
{"f_1143:chicken_bug_scm",(void*)f_1143},
{"f_1146:chicken_bug_scm",(void*)f_1146},
{"f_1064:chicken_bug_scm",(void*)f_1064},
{"f_1079:chicken_bug_scm",(void*)f_1079},
{"f_1109:chicken_bug_scm",(void*)f_1109},
{"f_1121:chicken_bug_scm",(void*)f_1121},
{"f_1127:chicken_bug_scm",(void*)f_1127},
{"f_1115:chicken_bug_scm",(void*)f_1115},
{"f_1085:chicken_bug_scm",(void*)f_1085},
{"f_1091:chicken_bug_scm",(void*)f_1091},
{"f_1098:chicken_bug_scm",(void*)f_1098},
{"f_1101:chicken_bug_scm",(void*)f_1101},
{"f_1077:chicken_bug_scm",(void*)f_1077},
{"f_1068:chicken_bug_scm",(void*)f_1068},
{"f_978:chicken_bug_scm",(void*)f_978},
{"f_1010:chicken_bug_scm",(void*)f_1010},
{"f_1040:chicken_bug_scm",(void*)f_1040},
{"f_1052:chicken_bug_scm",(void*)f_1052},
{"f_1058:chicken_bug_scm",(void*)f_1058},
{"f_1046:chicken_bug_scm",(void*)f_1046},
{"f_1016:chicken_bug_scm",(void*)f_1016},
{"f_1022:chicken_bug_scm",(void*)f_1022},
{"f_1029:chicken_bug_scm",(void*)f_1029},
{"f_1032:chicken_bug_scm",(void*)f_1032},
{"f_1008:chicken_bug_scm",(void*)f_1008},
{"f_982:chicken_bug_scm",(void*)f_982},
{"f_998:chicken_bug_scm",(void*)f_998},
{"f_960:chicken_bug_scm",(void*)f_960},
{"f_976:chicken_bug_scm",(void*)f_976},
{"f_972:chicken_bug_scm",(void*)f_972},
{"f_968:chicken_bug_scm",(void*)f_968},
{"f_772:chicken_bug_scm",(void*)f_772},
{"f_783:chicken_bug_scm",(void*)f_783},
{"f_915:chicken_bug_scm",(void*)f_915},
{"f_787:chicken_bug_scm",(void*)f_787},
{"f_794:chicken_bug_scm",(void*)f_794},
{"f_798:chicken_bug_scm",(void*)f_798},
{"f_830:chicken_bug_scm",(void*)f_830},
{"f_802:chicken_bug_scm",(void*)f_802},
{"f_822:chicken_bug_scm",(void*)f_822},
{"f_806:chicken_bug_scm",(void*)f_806},
{"f_814:chicken_bug_scm",(void*)f_814},
{"f_810:chicken_bug_scm",(void*)f_810},
{"f_731:chicken_bug_scm",(void*)f_731},
{"f_756:chicken_bug_scm",(void*)f_756},
{"f_749:chicken_bug_scm",(void*)f_749},
{"f_741:chicken_bug_scm",(void*)f_741},
{"f_744:chicken_bug_scm",(void*)f_744},
{"f_607:chicken_bug_scm",(void*)f_607},
{"f_688:chicken_bug_scm",(void*)f_688},
{"f_729:chicken_bug_scm",(void*)f_729},
{"f_725:chicken_bug_scm",(void*)f_725},
{"f_704:chicken_bug_scm",(void*)f_704},
{"f_700:chicken_bug_scm",(void*)f_700},
{"f_611:chicken_bug_scm",(void*)f_611},
{"f_686:chicken_bug_scm",(void*)f_686},
{"f_682:chicken_bug_scm",(void*)f_682},
{"f_614:chicken_bug_scm",(void*)f_614},
{"f_617:chicken_bug_scm",(void*)f_617},
{"f_678:chicken_bug_scm",(void*)f_678},
{"f_620:chicken_bug_scm",(void*)f_620},
{"f_670:chicken_bug_scm",(void*)f_670},
{"f_674:chicken_bug_scm",(void*)f_674},
{"f_645:chicken_bug_scm",(void*)f_645},
{"f_649:chicken_bug_scm",(void*)f_649},
{"f_655:chicken_bug_scm",(void*)f_655},
{"f_659:chicken_bug_scm",(void*)f_659},
{"f_653:chicken_bug_scm",(void*)f_653},
{"f_635:chicken_bug_scm",(void*)f_635},
{"f_588:chicken_bug_scm",(void*)f_588},
{"f_592:chicken_bug_scm",(void*)f_592},
{"f_569:chicken_bug_scm",(void*)f_569},
{"f_586:chicken_bug_scm",(void*)f_586},
{"f_579:chicken_bug_scm",(void*)f_579},
{"f_573:chicken_bug_scm",(void*)f_573},
{"f_560:chicken_bug_scm",(void*)f_560},
{"f_564:chicken_bug_scm",(void*)f_564},
{"f_374:chicken_bug_scm",(void*)f_374},
{"f_378:chicken_bug_scm",(void*)f_378},
{"f_381:chicken_bug_scm",(void*)f_381},
{"f_558:chicken_bug_scm",(void*)f_558},
{"f_554:chicken_bug_scm",(void*)f_554},
{"f_384:chicken_bug_scm",(void*)f_384},
{"f_387:chicken_bug_scm",(void*)f_387},
{"f_390:chicken_bug_scm",(void*)f_390},
{"f_546:chicken_bug_scm",(void*)f_546},
{"f_393:chicken_bug_scm",(void*)f_393},
{"f_542:chicken_bug_scm",(void*)f_542},
{"f_396:chicken_bug_scm",(void*)f_396},
{"f_538:chicken_bug_scm",(void*)f_538},
{"f_399:chicken_bug_scm",(void*)f_399},
{"f_534:chicken_bug_scm",(void*)f_534},
{"f_402:chicken_bug_scm",(void*)f_402},
{"f_530:chicken_bug_scm",(void*)f_530},
{"f_405:chicken_bug_scm",(void*)f_405},
{"f_526:chicken_bug_scm",(void*)f_526},
{"f_408:chicken_bug_scm",(void*)f_408},
{"f_411:chicken_bug_scm",(void*)f_411},
{"f_414:chicken_bug_scm",(void*)f_414},
{"f_522:chicken_bug_scm",(void*)f_522},
{"f_518:chicken_bug_scm",(void*)f_518},
{"f_514:chicken_bug_scm",(void*)f_514},
{"f_481:chicken_bug_scm",(void*)f_481},
{"f_485:chicken_bug_scm",(void*)f_485},
{"f_490:chicken_bug_scm",(void*)f_490},
{"f_498:chicken_bug_scm",(void*)f_498},
{"f_417:chicken_bug_scm",(void*)f_417},
{"f_420:chicken_bug_scm",(void*)f_420},
{"f_479:chicken_bug_scm",(void*)f_479},
{"f_465:chicken_bug_scm",(void*)f_465},
{"f_467:chicken_bug_scm",(void*)f_467},
{"f_475:chicken_bug_scm",(void*)f_475},
{"f_423:chicken_bug_scm",(void*)f_423},
{"f_426:chicken_bug_scm",(void*)f_426},
{"f_461:chicken_bug_scm",(void*)f_461},
{"f_435:chicken_bug_scm",(void*)f_435},
{"f_438:chicken_bug_scm",(void*)f_438},
{"f_443:chicken_bug_scm",(void*)f_443},
{"f_451:chicken_bug_scm",(void*)f_451},
{"f_429:chicken_bug_scm",(void*)f_429},
{"f_371:chicken_bug_scm",(void*)f_371},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
