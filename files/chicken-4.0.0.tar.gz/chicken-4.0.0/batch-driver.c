/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:48
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: batch-driver.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[368];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_fcall f_3199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_fcall f_1097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_fcall f_1488(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_fcall f_1509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_fcall f_1515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_fcall f_1527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_fcall f_1530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_fcall f_1537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_fcall f_1540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_fcall f_1546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_fcall f_1549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_fcall f_1552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_fcall f_1558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_fcall f_1567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_fcall f_1607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_fcall f_1656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_fcall f_1690(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_fcall f_1723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_fcall f_2515(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_fcall f_2570(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_fcall f_1799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_fcall f_1808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_fcall f_2319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_fcall f_1870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_fcall f_1873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_fcall f_1896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_fcall f_2102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_fcall f_1409(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1439)
static void C_fcall f_1439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_fcall f_1434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1411)
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1386)
static void C_fcall f_1386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1376)
static C_word C_fcall f_1376(C_word t0);
C_noret_decl(f_1346)
static void C_fcall f_1346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_fcall f_1266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_fcall f_1227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_fcall f_1144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1039)
static void C_fcall f_1039(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3199)
static void C_fcall trf_3199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3199(t0,t1);}

C_noret_decl(trf_1097)
static void C_fcall trf_1097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1097(t0,t1);}

C_noret_decl(trf_1488)
static void C_fcall trf_1488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1488(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1488(t0,t1);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1491(t0,t1);}

C_noret_decl(trf_1509)
static void C_fcall trf_1509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1509(t0,t1);}

C_noret_decl(trf_1515)
static void C_fcall trf_1515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1515(t0,t1);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1521(t0,t1);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1524(t0,t1);}

C_noret_decl(trf_1527)
static void C_fcall trf_1527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1527(t0,t1);}

C_noret_decl(trf_1530)
static void C_fcall trf_1530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1530(t0,t1);}

C_noret_decl(trf_1537)
static void C_fcall trf_1537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1537(t0,t1);}

C_noret_decl(trf_1540)
static void C_fcall trf_1540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1540(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1546)
static void C_fcall trf_1546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1546(t0,t1);}

C_noret_decl(trf_1549)
static void C_fcall trf_1549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1549(t0,t1);}

C_noret_decl(trf_1552)
static void C_fcall trf_1552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1552(t0,t1);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1555(t0,t1);}

C_noret_decl(trf_1558)
static void C_fcall trf_1558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1558(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1567)
static void C_fcall trf_1567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1567(t0,t1);}

C_noret_decl(trf_1573)
static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1573(t0,t1);}

C_noret_decl(trf_1607)
static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1607(t0,t1);}

C_noret_decl(trf_1656)
static void C_fcall trf_1656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1656(t0,t1);}

C_noret_decl(trf_1690)
static void C_fcall trf_1690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1690(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1690(t0,t1);}

C_noret_decl(trf_1723)
static void C_fcall trf_1723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1723(t0,t1);}

C_noret_decl(trf_2515)
static void C_fcall trf_2515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2515(t0,t1,t2);}

C_noret_decl(trf_2570)
static void C_fcall trf_2570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2570(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2570(t0,t1,t2);}

C_noret_decl(trf_1799)
static void C_fcall trf_1799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1799(t0,t1);}

C_noret_decl(trf_1808)
static void C_fcall trf_1808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1808(t0,t1);}

C_noret_decl(trf_2319)
static void C_fcall trf_2319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2319(t0,t1);}

C_noret_decl(trf_1870)
static void C_fcall trf_1870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1870(t0,t1);}

C_noret_decl(trf_1873)
static void C_fcall trf_1873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1873(t0,t1);}

C_noret_decl(trf_1896)
static void C_fcall trf_1896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1896(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1896(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2102)
static void C_fcall trf_2102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2102(t0,t1);}

C_noret_decl(trf_1409)
static void C_fcall trf_1409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1409(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1409(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1439)
static void C_fcall trf_1439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1439(t0,t1);}

C_noret_decl(trf_1434)
static void C_fcall trf_1434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1434(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1434(t0,t1,t2);}

C_noret_decl(trf_1411)
static void C_fcall trf_1411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1411(t0,t1,t2,t3);}

C_noret_decl(trf_1403)
static void C_fcall trf_1403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1403(t0,t1,t2);}

C_noret_decl(trf_1386)
static void C_fcall trf_1386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1386(t0,t1,t2);}

C_noret_decl(trf_1346)
static void C_fcall trf_1346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1346(t0,t1,t2);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1352(t0,t1,t2);}

C_noret_decl(trf_1266)
static void C_fcall trf_1266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1266(t0,t1);}

C_noret_decl(trf_1227)
static void C_fcall trf_1227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1227(t0,t1);}

C_noret_decl(trf_1205)
static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1205(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1190)
static void C_fcall trf_1190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1190(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1190(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1168)
static void C_fcall trf_1168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1168(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1168(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1153)
static void C_fcall trf_1153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1153(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1153(t0,t1,t2,t3);}

C_noret_decl(trf_1144)
static void C_fcall trf_1144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1144(t0,t1,t2,t3);}

C_noret_decl(trf_1039)
static void C_fcall trf_1039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1039(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2823)){
C_save(t1);
C_rereclaim2(2823*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,368);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],11,"user-pass-2");
lf[5]=C_h_intern(&lf[5],23,"user-post-analysis-pass");
lf[6]=C_h_intern(&lf[6],19,"compile-source-file");
lf[7]=C_h_intern(&lf[7],4,"quit");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],26,"\010compilerexplicit-use-flag");
lf[12]=C_h_intern(&lf[12],12,"\004coredeclare");
lf[13]=C_h_intern(&lf[13],7,"verbose");
lf[14]=C_h_intern(&lf[14],11,"output-file");
lf[15]=C_h_intern(&lf[15],36,"\010compilerdefault-optimization-passes");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[17]=C_h_intern(&lf[17],7,"profile");
lf[18]=C_h_intern(&lf[18],12,"profile-name");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[20]=C_h_intern(&lf[20],9,"heap-size");
lf[21]=C_h_intern(&lf[21],17,"heap-initial-size");
lf[22]=C_h_intern(&lf[22],11,"heap-growth");
lf[23]=C_h_intern(&lf[23],14,"heap-shrinkage");
lf[24]=C_h_intern(&lf[24],13,"keyword-style");
lf[25]=C_h_intern(&lf[25],4,"unit");
lf[26]=C_h_intern(&lf[26],12,"analyze-only");
lf[27]=C_h_intern(&lf[27],7,"dynamic");
lf[28]=C_h_intern(&lf[28],7,"nursery");
lf[29]=C_h_intern(&lf[29],10,"stack-size");
lf[30]=C_h_intern(&lf[30],6,"printf");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006~\077~%~!");
lf[32]=C_h_intern(&lf[32],26,"\010compilerdebugging-chicken");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[35]=C_h_intern(&lf[35],19,"\010compilerdump-nodes");
lf[36]=C_h_intern(&lf[36],12,"pretty-print");
lf[37]=C_h_intern(&lf[37],30,"\010compilerbuild-expression-tree");
lf[38]=C_h_intern(&lf[38],34,"\010compilerdisplay-analysis-database");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[40]=C_h_intern(&lf[40],12,"\003sysfor-each");
lf[41]=C_h_intern(&lf[41],19,"\003syshash-table-set!");
lf[42]=C_h_intern(&lf[42],24,"\003sysline-number-database");
lf[43]=C_h_intern(&lf[43],10,"alist-cons");
lf[44]=C_h_intern(&lf[44],18,"\003syshash-table-ref");
lf[45]=C_h_intern(&lf[45],9,"list-info");
lf[46]=C_h_intern(&lf[46],26,"\003sysdefault-read-info-hook");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[50]=C_h_intern(&lf[50],8,"\003sysread");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],9,"\003syserror");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],25,"\010compilerimport-libraries");
lf[58]=C_h_intern(&lf[58],26,"\010compilerdisabled-warnings");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],10,"\000compiling");
lf[67]=C_h_intern(&lf[67],28,"\003sysexplicit-library-modules");
lf[68]=C_h_intern(&lf[68],25,"\010compilertarget-heap-size");
lf[69]=C_h_intern(&lf[69],33,"\010compilertarget-initial-heap-size");
lf[70]=C_h_intern(&lf[70],27,"\010compilertarget-heap-growth");
lf[71]=C_h_intern(&lf[71],30,"\010compilertarget-heap-shrinkage");
lf[72]=C_h_intern(&lf[72],26,"\010compilertarget-stack-size");
lf[73]=C_h_intern(&lf[73],8,"no-trace");
lf[74]=C_h_intern(&lf[74],24,"\010compileremit-trace-info");
lf[75]=C_h_intern(&lf[75],29,"disable-stack-overflow-checks");
lf[76]=C_h_intern(&lf[76],40,"\010compilerdisable-stack-overflow-checking");
lf[77]=C_h_intern(&lf[77],7,"version");
lf[78]=C_h_intern(&lf[78],7,"newline");
lf[79]=C_h_intern(&lf[79],22,"\010compilerprint-version");
lf[80]=C_h_intern(&lf[80],4,"help");
lf[81]=C_h_intern(&lf[81],20,"\010compilerprint-usage");
lf[82]=C_h_intern(&lf[82],7,"release");
lf[83]=C_h_intern(&lf[83],7,"display");
lf[84]=C_h_intern(&lf[84],15,"chicken-version");
lf[85]=C_h_intern(&lf[85],24,"\010compilersource-filename");
lf[86]=C_h_intern(&lf[86],28,"\010compilerprofile-lambda-list");
lf[87]=C_h_intern(&lf[87],31,"\010compilerline-number-database-2");
lf[88]=C_h_intern(&lf[88],4,"node");
lf[89]=C_h_intern(&lf[89],6,"lambda");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[91]=C_h_intern(&lf[91],23,"\010compilerconstant-table");
lf[92]=C_h_intern(&lf[92],21,"\010compilerinline-table");
lf[93]=C_h_intern(&lf[93],23,"\010compilerfirst-analysis");
lf[94]=C_h_intern(&lf[94],41,"\010compilerperform-high-level-optimizations");
lf[95]=C_h_intern(&lf[95],37,"\010compilerinline-substitutions-enabled");
lf[96]=C_h_intern(&lf[96],22,"optimize-leaf-routines");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[98]=C_h_intern(&lf[98],34,"\010compilertransform-direct-lambdas!");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[100]=C_h_intern(&lf[100],4,"leaf");
lf[101]=C_h_intern(&lf[101],18,"\010compilerdebugging");
lf[102]=C_h_intern(&lf[102],1,"p");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[105]=C_h_intern(&lf[105],1,"5");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[108]=C_h_intern(&lf[108],36,"\010compilerprepare-for-code-generation");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[110]=C_h_intern(&lf[110],30,"\010compilercompiler-cleanup-hook");
lf[111]=C_h_intern(&lf[111],1,"t");
lf[112]=C_h_intern(&lf[112],17,"\003sysdisplay-times");
lf[113]=C_h_intern(&lf[113],14,"\003sysstop-timer");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[115]=C_h_intern(&lf[115],17,"close-output-port");
lf[116]=C_h_intern(&lf[116],22,"\010compilergenerate-code");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[118]=C_h_intern(&lf[118],16,"open-output-file");
lf[119]=C_h_intern(&lf[119],19,"current-output-port");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[122]=C_h_intern(&lf[122],1,"9");
lf[123]=C_h_intern(&lf[123],4,"exit");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[125]=C_h_intern(&lf[125],20,"\003syswarnings-enabled");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[127]=C_h_intern(&lf[127],1,"8");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[129]=C_h_intern(&lf[129],35,"\010compilerperform-closure-conversion");
lf[130]=C_h_intern(&lf[130],27,"\010compilerinline-output-file");
lf[131]=C_h_intern(&lf[131],32,"\010compileremit-global-inline-file");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[134]=C_h_intern(&lf[134],1,"7");
lf[135]=C_h_intern(&lf[135],1,"s");
lf[136]=C_h_intern(&lf[136],33,"\010compilerprint-program-statistics");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[138]=C_h_intern(&lf[138],1,"4");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[140]=C_h_intern(&lf[140],1,"u");
lf[141]=C_h_intern(&lf[141],31,"\010compilerdump-undefined-globals");
lf[142]=C_h_intern(&lf[142],3,"opt");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[144]=C_h_intern(&lf[144],1,"3");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[146]=C_h_intern(&lf[146],31,"\010compilerperform-cps-conversion");
lf[147]=C_h_intern(&lf[147],6,"unsafe");
lf[148]=C_h_intern(&lf[148],34,"\010compilerscan-toplevel-assignments");
lf[149]=C_h_intern(&lf[149],26,"\010compilerdo-lambda-lifting");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[151]=C_h_intern(&lf[151],1,"L");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[153]=C_h_intern(&lf[153],32,"\010compilerperform-lambda-lifting!");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[156]=C_h_intern(&lf[156],1,"0");
lf[157]=C_h_intern(&lf[157],4,"lift");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[159]=C_h_intern(&lf[159],1,"U");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[163]=C_h_intern(&lf[163],4,"user");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\026Secondary user pass...");
lf[165]=C_h_intern(&lf[165],25,"\010compilerbuild-node-graph");
lf[166]=C_h_intern(&lf[166],32,"\010compilercanonicalize-begin-body");
lf[167]=C_h_intern(&lf[167],24,"\010compilerinline-globally");
lf[168]=C_h_intern(&lf[168],25,"\010compilerload-inline-file");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[170]=C_h_intern(&lf[170],12,"file-exists\077");
lf[171]=C_h_intern(&lf[171],28,"\003sysresolve-include-filename");
lf[172]=C_h_intern(&lf[172],13,"make-pathname");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[174]=C_h_intern(&lf[174],14,"symbol->string");
lf[175]=C_h_intern(&lf[175],11,"concatenate");
lf[176]=C_h_intern(&lf[176],7,"\003sysmap");
lf[177]=C_h_intern(&lf[177],3,"cdr");
lf[178]=C_h_intern(&lf[178],2,"pp");
lf[179]=C_h_intern(&lf[179],1,"M");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[181]=C_h_intern(&lf[181],12,"vector->list");
lf[182]=C_h_intern(&lf[182],26,"\010compilerfile-requirements");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[185]=C_h_intern(&lf[185],12,"check-syntax");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[187]=C_h_intern(&lf[187],1,"2");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[189]=C_h_intern(&lf[189],25,"\010compilercompiler-warning");
lf[190]=C_h_intern(&lf[190],5,"style");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[192]=C_h_intern(&lf[192],8,"feature\077");
lf[193]=C_h_intern(&lf[193],19,"compiling-extension");
lf[194]=C_h_intern(&lf[194],18,"\010compilerunit-name");
lf[195]=C_h_intern(&lf[195],5,"usage");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[197]=C_h_intern(&lf[197],37,"\010compilerdisplay-line-number-database");
lf[198]=C_h_intern(&lf[198],1,"n");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[200]=C_h_intern(&lf[200],32,"\010compilerdisplay-real-name-table");
lf[201]=C_h_intern(&lf[201],1,"N");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[203]=C_h_intern(&lf[203],6,"append");
lf[204]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[205]=C_h_intern(&lf[205],5,"quote");
lf[206]=C_h_intern(&lf[206],33,"\010compilerprofile-info-vector-name");
lf[207]=C_h_intern(&lf[207],28,"\003sysset-profile-info-vector!");
lf[208]=C_h_intern(&lf[208],21,"\010compileremit-profile");
lf[209]=C_h_intern(&lf[209],25,"\003sysregister-profile-info");
lf[210]=C_h_intern(&lf[210],4,"set!");
lf[211]=C_h_intern(&lf[211],13,"\004corecallunit");
lf[212]=C_h_intern(&lf[212],19,"\010compilerused-units");
lf[213]=C_h_intern(&lf[213],28,"\010compilerimmutable-constants");
lf[214]=C_h_intern(&lf[214],6,"gensym");
lf[215]=C_h_intern(&lf[215],32,"\010compilercanonicalize-expression");
lf[216]=C_h_intern(&lf[216],4,"uses");
lf[217]=C_h_intern(&lf[217],7,"declare");
lf[218]=C_h_intern(&lf[218],10,"\003sysappend");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[220]=C_h_intern(&lf[220],1,"1");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[223]=C_h_intern(&lf[223],21,"\010compilerstring->expr");
lf[224]=C_h_intern(&lf[224],7,"reverse");
lf[225]=C_h_intern(&lf[225],27,"\003syscurrent-source-filename");
lf[226]=C_h_intern(&lf[226],33,"\010compilerclose-checked-input-file");
lf[227]=C_h_intern(&lf[227],16,"\003sysdynamic-wind");
lf[228]=C_h_intern(&lf[228],34,"\010compilercheck-and-open-input-file");
lf[229]=C_h_intern(&lf[229],8,"epilogue");
lf[230]=C_h_intern(&lf[230],8,"prologue");
lf[231]=C_h_intern(&lf[231],8,"postlude");
lf[232]=C_h_intern(&lf[232],7,"prelude");
lf[233]=C_h_intern(&lf[233],11,"make-vector");
lf[234]=C_h_intern(&lf[234],34,"\010compilerline-number-database-size");
lf[235]=C_h_intern(&lf[235],1,"r");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[242]=C_h_intern(&lf[242],5,"-help");
lf[243]=C_h_intern(&lf[243],1,"h");
lf[244]=C_h_intern(&lf[244],2,"-h");
lf[245]=C_h_intern(&lf[245],8,"\003sysput!");
lf[246]=C_h_intern(&lf[246],7,"\004coredb");
lf[247]=C_h_intern(&lf[247],7,"\003sysget");
lf[248]=C_h_intern(&lf[248],9,"read-file");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\027loading database ~a ...");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[251]=C_h_intern(&lf[251],15,"repository-path");
lf[252]=C_h_intern(&lf[252],18,"accumulate-profile");
lf[253]=C_h_intern(&lf[253],28,"\010compilerprofiled-procedures");
lf[254]=C_h_intern(&lf[254],3,"all");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[258]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[259]=C_h_intern(&lf[259],39,"\010compilerdefault-profiling-declarations");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[263]=C_h_intern(&lf[263],21,"no-usual-integrations");
lf[264]=C_h_intern(&lf[264],17,"standard-bindings");
lf[265]=C_h_intern(&lf[265],34,"\010compilerdefault-standard-bindings");
lf[266]=C_h_intern(&lf[266],17,"extended-bindings");
lf[267]=C_h_intern(&lf[267],34,"\010compilerdefault-extended-bindings");
lf[268]=C_h_intern(&lf[268],1,"m");
lf[269]=C_h_intern(&lf[269],14,"set-gc-report!");
lf[270]=C_h_intern(&lf[270],42,"\010compilerdefault-default-target-stack-size");
lf[271]=C_h_intern(&lf[271],41,"\010compilerdefault-default-target-heap-size");
lf[272]=C_h_intern(&lf[272],14,"compile-syntax");
lf[273]=C_h_intern(&lf[273],25,"\003sysenable-runtime-macros");
lf[274]=C_h_intern(&lf[274],22,"\004corerequire-extension");
lf[275]=C_h_intern(&lf[275],17,"require-extension");
lf[276]=C_h_intern(&lf[276],14,"string->symbol");
lf[277]=C_h_intern(&lf[277],16,"static-extension");
lf[278]=C_h_intern(&lf[278],28,"\010compilerpostponed-initforms");
lf[279]=C_h_intern(&lf[279],6,"delete");
lf[280]=C_h_intern(&lf[280],3,"eq\077");
lf[281]=C_h_intern(&lf[281],4,"load");
lf[282]=C_h_intern(&lf[282],12,"load-verbose");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[284]=C_h_intern(&lf[284],6,"extend");
lf[285]=C_h_intern(&lf[285],17,"register-feature!");
lf[286]=C_h_intern(&lf[286],12,"string-split");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[288]=C_h_intern(&lf[288],10,"append-map");
lf[289]=C_h_intern(&lf[289],7,"feature");
lf[290]=C_h_intern(&lf[290],20,"keep-shadowed-macros");
lf[291]=C_h_intern(&lf[291],33,"\010compilerundefine-shadowed-macros");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[293]=C_h_intern(&lf[293],23,"\010compilerchop-separator");
lf[294]=C_h_intern(&lf[294],12,"include-path");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[296]=C_h_intern(&lf[296],13,"symbol-escape");
lf[297]=C_h_intern(&lf[297],20,"parentheses-synonyms");
lf[298]=C_h_intern(&lf[298],5,"\000none");
lf[299]=C_h_intern(&lf[299],14,"case-sensitive");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the Chicken extensions to R5RS syntax");
lf[301]=C_h_intern(&lf[301],16,"no-symbol-escape");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[303]=C_h_intern(&lf[303],23,"no-parenthesis-synonyms");
lf[304]=C_h_intern(&lf[304],20,"parenthesis-synonyms");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[307]=C_h_intern(&lf[307],7,"\000prefix");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[310]=C_h_intern(&lf[310],7,"\000suffix");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[312]=C_h_intern(&lf[312],17,"compress-literals");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[314]=C_h_intern(&lf[314],16,"case-insensitive");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[316]=C_h_intern(&lf[316],24,"\010compilerinline-max-size");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[318]=C_h_intern(&lf[318],23,"\010compilerinline-locally");
lf[319]=C_h_intern(&lf[319],26,"\010compilerlocal-definitions");
lf[320]=C_h_intern(&lf[320],6,"inline");
lf[321]=C_h_intern(&lf[321],30,"emit-external-prototypes-first");
lf[322]=C_h_intern(&lf[322],30,"\010compilerexternal-protos-first");
lf[323]=C_h_intern(&lf[323],5,"block");
lf[324]=C_h_intern(&lf[324],26,"\010compilerblock-compilation");
lf[325]=C_h_intern(&lf[325],17,"fixnum-arithmetic");
lf[326]=C_h_intern(&lf[326],11,"number-type");
lf[327]=C_h_intern(&lf[327],6,"fixnum");
lf[328]=C_h_intern(&lf[328],18,"disable-interrupts");
lf[329]=C_h_intern(&lf[329],28,"\010compilerinsert-timer-checks");
lf[330]=C_h_intern(&lf[330],16,"unsafe-libraries");
lf[331]=C_h_intern(&lf[331],27,"\010compileremit-unsafe-marker");
lf[332]=C_h_intern(&lf[332],11,"no-warnings");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[334]=C_h_intern(&lf[334],15,"disable-warning");
lf[335]=C_h_intern(&lf[335],13,"inline-global");
lf[336]=C_h_intern(&lf[336],5,"local");
lf[337]=C_h_intern(&lf[337],14,"no-lambda-info");
lf[338]=C_h_intern(&lf[338],26,"\010compileremit-closure-info");
lf[339]=C_h_intern(&lf[339],3,"raw");
lf[340]=C_h_intern(&lf[340],12,"emit-exports");
lf[341]=C_h_intern(&lf[341],7,"warning");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[343]=C_h_intern(&lf[343],1,"b");
lf[344]=C_h_intern(&lf[344],15,"\003sysstart-timer");
lf[345]=C_h_intern(&lf[345],11,"lambda-lift");
lf[346]=C_h_intern(&lf[346],13,"string-append");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[348]=C_h_intern(&lf[348],19,"emit-import-library");
lf[349]=C_h_intern(&lf[349],16,"\003sysstring->list");
lf[350]=C_h_intern(&lf[350],5,"debug");
lf[351]=C_h_intern(&lf[351],17,"ignore-repository");
lf[352]=C_h_intern(&lf[352],18,"\003sysdload-disabled");
lf[353]=C_h_intern(&lf[353],30,"\010compilerstandalone-executable");
lf[354]=C_h_intern(&lf[354],29,"\010compilerstring->c-identifier");
lf[355]=C_h_intern(&lf[355],18,"\010compilerstringify");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[358]=C_h_intern(&lf[358],6,"getenv");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[360]=C_h_intern(&lf[360],9,"to-stdout");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[362]=C_h_intern(&lf[362],13,"pathname-file");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[364]=C_h_intern(&lf[364],29,"\010compilerdefault-declarations");
lf[365]=C_h_intern(&lf[365],30,"\010compilerunits-used-by-default");
lf[366]=C_h_intern(&lf[366],28,"\010compilerinitialize-compiler");
lf[367]=C_h_intern(&lf[367],14,"make-parameter");
C_register_lf2(lf,368,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k992 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k995 in k992 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k998 in k995 in k992 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1001 in k998 in k995 in k992 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 80   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[367]))(3,*((C_word*)lf[367]+1),t2,C_SCHEME_FALSE);}

/* k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 81   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[367]))(3,*((C_word*)lf[367]+1),t3,C_SCHEME_FALSE);}

/* k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[367]))(3,*((C_word*)lf[367]+1),t3,C_SCHEME_FALSE);}

/* k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[367]))(3,*((C_word*)lf[367]+1),t3,C_SCHEME_FALSE);}

/* k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[367]))(3,*((C_word*)lf[367]+1),t3,C_SCHEME_FALSE);}

/* k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-pass-2 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[367]))(3,*((C_word*)lf[367]+1),t3,C_SCHEME_FALSE);}

/* k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[6]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1036,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1036r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1036r(t0,t1,t2,t3);}}

static void C_ccall f_1036r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1039,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1072,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 98   initialize-compiler */
((C_proc2)C_retrieve_symbol_proc(lf[366]))(2,*((C_word*)lf[366]+1),t5);}

/* k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1072,2,t0,t1);}
t2=(C_word)C_i_memq(lf[10],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[11]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3195,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[11]))){
t7=t6;
f_3199(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[365]),C_SCHEME_END_OF_LIST);}}

/* k3208 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[216],t1);
t3=((C_word*)t0)[2];
f_3199(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3197 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_3199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 101  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[2],C_retrieve(lf[364]),t1);}

/* k3193 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[12],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3158,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 109  option-arg */
f_1039(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[360],((C_word*)t0)[5]))){
t9=t8;
f_1088(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 114  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[362]))(3,*((C_word*)lf[362]+1),t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3180(2,t10,lf[363]);}}}}

/* k3178 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 114  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[172]))(5,*((C_word*)lf[172]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[361]);}

/* k3156 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 111  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[174]+1)))(3,*((C_word*)lf[174]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1088(2,t2,t1);}}

/* k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1091,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3152,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 115  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t4,lf[359]);}

/* k3150 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[356]);
/* batch-driver.scm: 115  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[286]))(4,*((C_word*)lf[286]+1),((C_word*)t0)[2],t2,lf[357]);}

/* k3146 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[293]),t1);}

/* k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=C_retrieve(lf[15]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[16];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[17],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1097,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1097(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[252],((C_word*)t0)[8]);
t14=t12;
f_1097(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[18],((C_word*)t0)[8])));}}

/* k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1097,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[19]);
t5=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t22=(C_truep(t21)?t21:(C_word)C_i_memq(lf[29],((C_word*)t0)[13]));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1168,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1190,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1205,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1217,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1266,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1488,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t22,a[12]=t1,a[13]=t30,a[14]=t33,a[15]=((C_word*)t0)[3],a[16]=t4,a[17]=((C_word*)t0)[4],a[18]=t27,a[19]=t26,a[20]=t13,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t23,a[24]=t25,a[25]=t34,a[26]=t32,a[27]=t31,a[28]=t18,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=((C_word*)t0)[8],a[32]=t20,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3125,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 212  option-arg */
f_1039(t38,t12);}
else{
t36=t35;
f_1488(t36,C_SCHEME_UNDEFINED);}}

/* k3127 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 212  stringify */
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[2],t1);}

/* k3123 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 212  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[354]))(3,*((C_word*)lf[354]+1),((C_word*)t0)[2],t1);}

/* k3119 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[194]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1488(t3,t2);}

/* k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1488(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1488,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[194]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[353] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1491(t6,t5);}
else{
t5=t2;
f_1491(t5,C_SCHEME_UNDEFINED);}}

/* k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1491,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[351],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[352] /* dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm: 217  repository-path */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1494(2,t3,C_SCHEME_UNDEFINED);}}

/* k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3084,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3106,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 223  collect-options */
t5=((C_word*)t0)[13];
f_1346(t5,t4,lf[350]);}

/* k3104 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 219  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[288]))(4,*((C_word*)lf[288]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3083 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3084,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3090,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3102,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[349]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3100 in a3083 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3089 in a3083 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3090,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 221  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[276]+1)))(3,*((C_word*)lf[276]+1),t1,t3);}

/* k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[56],C_retrieve(lf[32]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3066,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3082,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 229  collect-options */
t8=((C_word*)t0)[13];
f_1346(t8,t7,lf[348]);}

/* k3080 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3065 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3066,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 227  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[276]+1)))(3,*((C_word*)lf[276]+1),t3,t2);}

/* k3072 in a3065 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3078,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 228  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[346]+1)))(4,*((C_word*)lf[346]+1),t2,((C_word*)t0)[2],lf[347]);}

/* k3076 in k3072 in a3065 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3078,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1506,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[345],((C_word*)t0)[35]))){
t4=C_set_block_item(lf[149] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1509(t5,t4);}
else{
t4=t3;
f_1509(t4,C_SCHEME_UNDEFINED);}}

/* k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1509,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[111],C_retrieve(lf[32])))){
/* batch-driver.scm: 231  ##sys#start-timer */
t3=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1512(2,t3,C_SCHEME_UNDEFINED);}}

/* k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[343],C_retrieve(lf[32])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1515(t4,t3);}
else{
t3=t2;
f_1515(t3,C_SCHEME_UNDEFINED);}}

/* k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1515,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[340],((C_word*)t0)[34]))){
/* batch-driver.scm: 234  warning */
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t2,lf[342]);}
else{
t3=t2;
f_1518(2,t3,C_SCHEME_UNDEFINED);}}

/* k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[339],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[11] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[16],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1521(t6,t5);}
else{
t3=t2;
f_1521(t3,C_SCHEME_UNDEFINED);}}

/* k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1521,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[337],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[338] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1524(t4,t3);}
else{
t3=t2;
f_1524(t3,C_SCHEME_UNDEFINED);}}

/* k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[336],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[319] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1527(t4,t3);}
else{
t3=t2;
f_1527(t3,C_SCHEME_UNDEFINED);}}

/* k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1527,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[335],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[318] /* inline-locally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[167] /* inline-globally */,0,C_SCHEME_TRUE);
t5=t2;
f_1530(t5,t4);}
else{
t3=t2;
f_1530(t3,C_SCHEME_UNDEFINED);}}

/* k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1530,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 246  collect-options */
t4=((C_word*)t0)[12];
f_1346(t4,t3,lf[334]);}

/* k3023 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[276]+1),t1);}

/* k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[332],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3020,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 248  dribble */
t5=((C_word*)t0)[22];
f_1144(t5,t4,lf[333],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1537(t4,C_SCHEME_UNDEFINED);}}

/* k3018 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[125] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1537(t3,t2);}

/* k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1537,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[96],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[96] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1540(t4,t3);}
else{
t3=t2;
f_1540(t3,C_SCHEME_UNDEFINED);}}

/* k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1540,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[147],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[147] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1543(t4,t3);}
else{
t3=t2;
f_1543(t3,C_SCHEME_UNDEFINED);}}

/* k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[330],((C_word*)t0)[34]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[331] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1546(t5,t4);}
else{
t4=t2;
f_1546(t4,C_SCHEME_UNDEFINED);}}

/* k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1546,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[329] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1549(t4,t3);}
else{
t3=t2;
f_1549(t3,C_SCHEME_UNDEFINED);}}

/* k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1549,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[325],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[326]+1 /* (set! number-type ...) */,lf[327]);
t4=t2;
f_1552(t4,t3);}
else{
t3=t2;
f_1552(t3,C_SCHEME_UNDEFINED);}}

/* k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1552,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[323],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[324] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1555(t4,t3);}
else{
t3=t2;
f_1555(t3,C_SCHEME_UNDEFINED);}}

/* k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[321],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[322] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1558(t4,t3);}
else{
t3=t2;
f_1558(t3,C_SCHEME_UNDEFINED);}}

/* k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[320],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[318] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1561(t4,t3);}
else{
t3=t2;
f_1561(t3,C_SCHEME_UNDEFINED);}}

/* k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[59],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[318] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[319] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 264  option-arg */
f_1039(t6,t2);}
else{
t4=t3;
f_1567(t4,C_SCHEME_FALSE);}}

/* k2977 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[130]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1567(t3,t2);}

/* k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1567,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[34],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2964,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 267  option-arg */
f_1039(t4,t2);}
else{
t4=t3;
f_1573(t4,C_SCHEME_FALSE);}}

/* k2962 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2967,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 268  string->number */
C_string_to_number(3,0,t2,t1);}

/* k2965 in k2962 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2970(2,t3,t1);}
else{
/* batch-driver.scm: 269  quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[317],((C_word*)t0)[2]);}}

/* k2968 in k2965 in k2962 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[316]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1573(t3,t2);}

/* k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1573,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[314],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2954,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 271  dribble */
t4=((C_word*)t0)[22];
f_1144(t4,t3,lf[315],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1576(2,t3,C_SCHEME_UNDEFINED);}}

/* k2952 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 272  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[285]))(3,*((C_word*)lf[285]+1),t2,lf[314]);}

/* k2955 in k2952 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 273  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[30]))){
/* batch-driver.scm: 275  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[189]))(4,*((C_word*)lf[189]+1),t2,lf[195],lf[313]);}
else{
t3=t2;
f_1579(2,t3,C_SCHEME_UNDEFINED);}}

/* k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2912,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 277  option-arg */
f_1039(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1582(2,t3,C_SCHEME_UNDEFINED);}}

/* k2910 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[306],t1))){
/* batch-driver.scm: 278  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[307]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[308],t1))){
/* batch-driver.scm: 279  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[298]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[309],t1))){
/* batch-driver.scm: 280  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[310]);}
else{
/* batch-driver.scm: 281  quit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[311]);}}}}

/* k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[303],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2906,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 283  dribble */
t4=((C_word*)t0)[21];
f_1144(t4,t3,lf[305],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1585(2,t3,C_SCHEME_UNDEFINED);}}

/* k2904 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 284  parenthesis-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[301],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2897,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 286  dribble */
t4=((C_word*)t0)[21];
f_1144(t4,t3,lf[302],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1588(2,t3,C_SCHEME_UNDEFINED);}}

/* k2895 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 287  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[296]))(3,*((C_word*)lf[296]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[295],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2879,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 289  dribble */
t4=((C_word*)t0)[21];
f_1144(t4,t3,lf[300],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1591(2,t3,C_SCHEME_UNDEFINED);}}

/* k2877 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 290  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),t2,C_SCHEME_FALSE);}

/* k2880 in k2877 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 291  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,lf[298]);}

/* k2883 in k2880 in k2877 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 292  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t2,C_SCHEME_FALSE);}

/* k2886 in k2883 in k2880 in k2877 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 293  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[296]))(3,*((C_word*)lf[296]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 297  collect-options */
t7=((C_word*)t0)[11];
f_1346(t7,t6,lf[294]);}

/* k2871 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[293]),t1);}

/* k2867 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 297  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),((C_word*)t0)[3],t1,C_retrieve(lf[63]),((C_word*)t0)[2]);}

/* k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=(C_truep(((C_word*)t0)[20])?(C_truep(((C_word*)t0)[27])?(C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[27]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 301  quit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t3,lf[292]);}
else{
t5=t3;
f_1600(2,t5,C_SCHEME_UNDEFINED);}}

/* k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2853,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 302  collect-options */
t4=((C_word*)t0)[11];
f_1346(t4,t3,lf[216]);}

/* k2851 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[276]+1),t1);}

/* k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[32],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[290],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[291] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1607(t5,t4);}
else{
t4=t3;
f_1607(t4,C_SCHEME_UNDEFINED);}}

/* k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2835,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2837,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2845,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 309  collect-options */
t6=((C_word*)t0)[11];
f_1346(t6,t5,lf[289]);}

/* k2843 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 309  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[288]))(4,*((C_word*)lf[288]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2836 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2837,3,t0,t1,t2);}
/* string-split */
((C_proc4)C_retrieve_symbol_proc(lf[286]))(4,*((C_word*)lf[286]+1),t1,t2,lf[287]);}

/* k2833 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[285]),t1);}

/* k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[65]));
t3=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 313  collect-options */
t5=((C_word*)t0)[11];
f_1346(t5,t4,lf[284]);}

/* k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 314  dribble */
t3=((C_word*)t0)[22];
f_1144(t3,t2,lf[283],C_SCHEME_END_OF_LIST);}

/* k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 315  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_1623(2,t3,C_SCHEME_UNDEFINED);}}

/* k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2820,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2819 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2820,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 317  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[171]))(5,*((C_word*)lf[171]+1),t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2826 in a2819 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 317  load */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),((C_word*)t0)[2],t1);}

/* k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 319  delete */
((C_proc5)C_retrieve_symbol_proc(lf[279]))(5,*((C_word*)lf[279]+1),t2,lf[64],C_retrieve(lf[65]),*((C_word*)lf[280]+1));}

/* k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[66],C_retrieve(lf[65]));
t4=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 322  user-post-analysis-pass */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t5);}

/* k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 325  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t3,((C_word*)((C_word*)t0)[30])[1],C_retrieve(lf[278]));}

/* k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 327  collect-options */
t5=((C_word*)t0)[10];
f_1346(t5,t4,lf[277]);}

/* k2816 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[276]+1),t1);}

/* k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1649,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2790,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2814,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 333  collect-options */
t7=((C_word*)t0)[10];
f_1346(t7,t6,lf[275]);}

/* k2812 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 333  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2808 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2789 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2790,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[274],t5));}

/* k2786 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 330  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1649,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[31],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 337  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t3,C_retrieve(lf[67]),((C_word*)t0)[2]);}

/* k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[272],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[273] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1656(t5,t4);}
else{
t4=t3;
f_1656(t4,C_SCHEME_UNDEFINED);}}

/* k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1656,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 343  option-arg */
f_1039(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[271]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1660(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1660(2,t4,C_SCHEME_FALSE);}}}

/* k2765 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 343  arg-val */
f_1266(((C_word*)t0)[2],t1);}

/* k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2760,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 347  option-arg */
f_1039(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1664(2,t4,C_SCHEME_FALSE);}}

/* k2758 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 347  arg-val */
f_1266(((C_word*)t0)[2],t1);}

/* k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 348  option-arg */
f_1039(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1668(2,t4,C_SCHEME_FALSE);}}

/* k2751 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 348  arg-val */
f_1266(((C_word*)t0)[2],t1);}

/* k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1668,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2746,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 349  option-arg */
f_1039(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1672(2,t4,C_SCHEME_FALSE);}}

/* k2744 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 349  arg-val */
f_1266(((C_word*)t0)[2],t1);}

/* k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2726,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 352  option-arg */
f_1039(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[270]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1676(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1676(2,t5,C_SCHEME_FALSE);}}}

/* k2724 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 352  arg-val */
f_1266(((C_word*)t0)[2],t1);}

/* k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[73],((C_word*)t0)[23]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[74]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[75],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[76]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[268],C_retrieve(lf[32])))){
/* batch-driver.scm: 358  set-gc-report! */
((C_proc3)C_retrieve_symbol_proc(lf[269]))(3,*((C_word*)lf[269]+1),t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1687(2,t9,C_SCHEME_UNDEFINED);}}

/* k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[263],((C_word*)t0)[23]))){
t3=t2;
f_1690(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[264]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[265]));
t4=C_mutate((C_word*)lf[266]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[267]));
t5=t2;
f_1690(t5,t4);}}

/* k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1690,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(C_truep(C_retrieve(lf[74]))?lf[260]:lf[261]);
/* batch-driver.scm: 362  dribble */
t4=((C_word*)t0)[15];
f_1144(t4,t2,lf[262],(C_word)C_a_i_list(&a,1,t3));}

/* k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[252],t3);
t5=C_set_block_item(lf[208] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[253]+1 /* (set! profiled-procedures ...) */,lf[254]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2685,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[258]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 371  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),t7,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[259]),t8);}
else{
t3=t2;
f_1696(2,t3,C_SCHEME_UNDEFINED);}}

/* k2683 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2685,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_truep(((C_word*)t0)[4])?lf[255]:lf[256]);
/* batch-driver.scm: 377  dribble */
t4=((C_word*)t0)[3];
f_1144(t4,((C_word*)t0)[2],lf[257],(C_word)C_a_i_list(&a,1,t3));}

/* k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 380  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[251]))(2,*((C_word*)lf[251]+1),t2);}

/* k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[14],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2676,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 381  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[172]))(4,*((C_word*)lf[172]+1),t4,t1,lf[250]);}
else{
t3=t2;
f_1702(2,t3,C_SCHEME_FALSE);}}

/* k2674 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 381  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),((C_word*)t0)[2],t1);}

/* k2624 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2632,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 382  dribble */
t3=((C_word*)t0)[2];
f_1144(t3,t2,lf[249],(C_word)C_a_i_list(&a,1,t1));}
else{
t2=((C_word*)t0)[3];
f_1702(2,t2,C_SCHEME_FALSE);}}

/* k2630 in k2624 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2637,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2672,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 388  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[248]))(3,*((C_word*)lf[248]+1),t3,((C_word*)t0)[2]);}

/* k2670 in k2630 in k2624 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2636 in k2630 in k2624 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2637,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2649,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2653,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* batch-driver.scm: 387  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[247]))(4,*((C_word*)lf[247]+1),t5,t6,lf[246]);}

/* k2651 in a2636 in k2630 in k2624 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* batch-driver.scm: 387  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[2],t2,t4);}

/* k2647 in a2636 in k2630 in k2624 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 385  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[245]))(5,*((C_word*)lf[245]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[246],t1);}

/* k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[77],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 391  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[80],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1723(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[242],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1723(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[243],((C_word*)t0)[22]);
t6=t3;
f_1723(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[244],((C_word*)t0)[22])));}}}}

/* k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1723,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 394  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),((C_word*)t0)[22]);}
else{
if(C_truep((C_word)C_i_memq(lf[82],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 396  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[84]))(2,*((C_word*)lf[84]+1),t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[21],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 404  dribble */
t4=((C_word*)t0)[14];
f_1144(t4,t3,lf[240],(C_word)C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 399  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,C_SCHEME_TRUE);}}}}

/* k1749 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 400  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],lf[241]);}

/* k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1757,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 406  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t3,lf[235],lf[239],((C_word*)t0)[10]);}

/* k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 407  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[235],lf[238],C_retrieve(lf[32]));}

/* k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 408  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[235],lf[237],C_retrieve(lf[68]));}

/* k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 409  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[235],lf[236],C_retrieve(lf[72]));}

/* k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[22])+1,t2);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[22],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 413  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[233]+1)))(4,*((C_word*)lf[233]+1),t4,C_retrieve(lf[234]),C_SCHEME_END_OF_LIST);}

/* k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 414  collect-options */
t4=((C_word*)t0)[2];
f_1346(t4,t3,lf[232]);}

/* k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 415  collect-options */
t3=((C_word*)t0)[2];
f_1346(t3,t2,lf[231]);}

/* k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 417  collect-options */
t4=((C_word*)t0)[2];
f_1346(t4,t3,lf[230]);}

/* k2598 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2608,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 419  collect-options */
t4=((C_word*)t0)[2];
f_1346(t4,t3,lf[229]);}

/* k2606 in k2598 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 416  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 421  user-read-pass */
((C_proc2)C_retrieve_symbol_proc(lf[1]))(2,*((C_word*)lf[1]+1),t2);}

/* k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 423  dribble */
t4=((C_word*)t0)[20];
f_1144(t4,t3,lf[222],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2515(t6,t2,((C_word*)t0)[4]);}}

/* doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_2515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2515,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2526,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[223]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 433  check-and-open-input-file */
((C_proc3)C_retrieve_symbol_proc(lf[228]))(3,*((C_word*)lf[228]+1),t4,t3);}}

/* k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2556,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2593,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[227]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2592 in k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[225]));
t3=C_mutate((C_word*)lf[225]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2560 in k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2565,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 435  read-form */
t3=((C_word*)t0)[2];
f_1403(t3,t2,((C_word*)t0)[5]);}

/* k2563 in a2560 in k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2570(t5,((C_word*)t0)[2],t1);}

/* doloop621 in k2563 in a2560 in k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_2570(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2570,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 438  close-checked-input-file */
((C_proc4)C_retrieve_symbol_proc(lf[226]))(4,*((C_word*)lf[226]+1),t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 436  read-form */
t6=((C_word*)t0)[2];
f_1403(t6,t5,((C_word*)t0)[6]);}}

/* k2589 in doloop621 in k2563 in a2560 in k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2570(t2,((C_word*)t0)[2],t1);}

/* a2555 in k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[225]));
t3=C_mutate((C_word*)lf[225]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2545 in k2542 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2515(t3,((C_word*)t0)[2],t2);}

/* k2528 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 430  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[224]+1)))(3,*((C_word*)lf[224]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2532 in k2528 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2538,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[223]),((C_word*)t0)[2]);}

/* k2536 in k2532 in k2528 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 429  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2524 in doloop592 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2504 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 424  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2508 in k2504 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1793(2,t3,t2);}

/* k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 442  user-preprocessor-pass */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t2);}

/* k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2499,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 444  dribble */
t4=((C_word*)t0)[16];
f_1144(t4,t3,lf[221],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1799(t3,C_SCHEME_UNDEFINED);}}

/* k2497 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2501 in k2497 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1799(t3,t2);}

/* k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1799,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 447  print-expr */
t3=((C_word*)t0)[7];
f_1205(t3,t2,lf[219],lf[220],((C_word*)((C_word*)t0)[3])[1]);}

/* k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=f_1376(((C_word*)t0)[20]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1808(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 450  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t4,C_retrieve(lf[67]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2474 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2494 in k2474 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[216],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[217],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1808(t7,t6);}

/* k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1808,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2469,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 452  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2467 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[215]),t1);}

/* k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 453  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[214]))(2,*((C_word*)lf[214]+1),t2);}

/* k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[86]));
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],tmp=(C_word)a,a+=16,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2437,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[213]));}

/* a2436 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2437,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[205],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[210],t8));}

/* k2309 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2427,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[212]));}

/* a2426 in k2309 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2427,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[211],t3));}

/* k2313 in k2309 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[208]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[205],t3);
t5=(C_truep(C_retrieve(lf[194]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[205],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[209],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[206]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[210],t12);
t14=t2;
f_2319(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2319(t3,C_SCHEME_END_OF_LIST);}}

/* k2317 in k2313 in k2309 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_2319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2319,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2338,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[86]));}

/* a2337 in k2317 in k2313 in k2309 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2338,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[205],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[205],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[206]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[207],t11));}

/* k2321 in k2317 in k2313 in k2309 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[194]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 455  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[203]+1)))(9,*((C_word*)lf[203]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[204]);}

/* k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2304,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 476  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t5,lf[201],lf[202]);}

/* k2302 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 477  display-real-name-table */
((C_proc2)C_retrieve_symbol_proc(lf[200]))(2,*((C_word*)lf[200]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1823(2,t2,C_SCHEME_UNDEFINED);}}

/* k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 478  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[198],lf[199]);}

/* k2296 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 479  display-line-number-database */
((C_proc2)C_retrieve_symbol_proc(lf[197]))(2,*((C_word*)lf[197]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1826(2,t2,C_SCHEME_UNDEFINED);}}

/* k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(C_retrieve(lf[194]))?((C_word*)t0)[9]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 482  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[189]))(5,*((C_word*)lf[189]+1),t2,lf[195],lf[196],C_retrieve(lf[194]));}
else{
t4=t2;
f_1829(2,t4,C_SCHEME_UNDEFINED);}}

/* k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2283,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[147]))){
/* batch-driver.scm: 484  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),t3,lf[193]);}
else{
t4=t3;
f_2283(2,t4,C_SCHEME_FALSE);}}

/* k2281 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 485  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[189]))(4,*((C_word*)lf[189]+1),((C_word*)t0)[2],lf[190],lf[191]);}
else{
t2=((C_word*)t0)[2];
f_1832(2,t2,C_SCHEME_UNDEFINED);}}

/* k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,C_retrieve(lf[87]));
t3=C_set_block_item(lf[87] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 492  end-time */
t5=((C_word*)t0)[15];
f_1386(t5,t4,lf[188]);}

/* k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 493  print-expr */
t3=((C_word*)t0)[2];
f_1205(t3,t2,lf[186],lf[187],((C_word*)((C_word*)t0)[4])[1]);}

/* k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_memq(lf[185],((C_word*)t0)[2]))){
/* batch-driver.scm: 495  exit */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}
else{
t3=t2;
f_1843(2,t3,C_SCHEME_UNDEFINED);}}

/* k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 497  user-pass */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2264,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 499  dribble */
t4=((C_word*)t0)[10];
f_1144(t4,t3,lf[184],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1849(2,t3,C_SCHEME_UNDEFINED);}}

/* k2262 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=f_1376(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2269 in k2262 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 502  end-time */
t3=((C_word*)t0)[3];
f_1386(t3,((C_word*)t0)[2],lf[183]);}

/* k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 504  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[181]+1)))(3,*((C_word*)lf[181]+1),t3,C_retrieve(lf[182]));}

/* k2259 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 504  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1);}

/* k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1855,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 505  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[179],lf[180]);}

/* k2252 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 506  pp */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1855(2,t2,C_SCHEME_UNDEFINED);}}

/* k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[167]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[177]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1858(2,t3,C_SCHEME_UNDEFINED);}}

/* k2249 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 516  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1);}

/* k2245 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2215 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2216,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2243,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 511  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[174]+1)))(3,*((C_word*)lf[174]+1),t5,t2);}

/* k2241 in a2215 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 511  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[172]))(5,*((C_word*)lf[172]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[173]);}

/* k2237 in a2215 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 510  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[171]))(5,*((C_word*)lf[171]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2218 in a2215 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 513  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2227 in k2218 in a2215 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 514  dribble */
t3=((C_word*)t0)[2];
f_1144(t3,t2,lf[169],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2230 in k2227 in k2218 in a2215 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 515  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 521  canonicalize-begin-body */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2209 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 520  build-node-graph */
((C_proc3)C_retrieve_symbol_proc(lf[165]))(3,*((C_word*)lf[165]+1),((C_word*)t0)[2],t1);}

/* k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[88],lf[89],lf[90],t2);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1867,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 522  user-pass-2 */
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t4);}

/* k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[11],a[8]=t2,a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 524  dribble */
t4=((C_word*)t0)[10];
f_1144(t4,t3,lf[164],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1870(t3,C_SCHEME_UNDEFINED);}}

/* k2175 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=f_1376(((C_word*)t0)[9]);
t3=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 527  analyze */
t5=((C_word*)t0)[2];
f_1409(t5,t4,lf[163],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2182 in k2175 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 528  print-db */
t3=((C_word*)t0)[2];
f_1190(t3,t2,lf[162],lf[156],t1,C_fix(0));}

/* k2185 in k2182 in k2175 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 529  end-time */
t3=((C_word*)t0)[3];
f_1386(t3,t2,lf[161]);}

/* k2188 in k2185 in k2182 in k2175 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=f_1376(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 531  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2194 in k2188 in k2185 in k2182 in k2175 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 532  end-time */
t3=((C_word*)t0)[2];
f_1386(t3,t2,lf[160]);}

/* k2197 in k2194 in k2188 in k2185 in k2182 in k2175 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 533  print-node */
t3=((C_word*)t0)[3];
f_1168(t3,t2,lf[158],lf[159],((C_word*)t0)[2]);}

/* k2200 in k2197 in k2194 in k2188 in k2185 in k2182 in k2175 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1870(t3,t2);}

/* k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1870,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[149]))){
t3=f_1376(((C_word*)t0)[14]);
t4=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 539  analyze */
t6=((C_word*)t0)[12];
f_1409(t6,t5,lf[157],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1873(t3,C_SCHEME_UNDEFINED);}}

/* k2153 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2158,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 540  print-db */
t3=((C_word*)t0)[2];
f_1190(t3,t2,lf[155],lf[156],t1,C_fix(0));}

/* k2156 in k2153 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 541  end-time */
t3=((C_word*)t0)[3];
f_1386(t3,t2,lf[154]);}

/* k2159 in k2156 in k2153 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=f_1376(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 543  perform-lambda-lifting! */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2165 in k2159 in k2156 in k2153 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 544  end-time */
t3=((C_word*)t0)[2];
f_1386(t3,t2,lf[152]);}

/* k2168 in k2165 in k2159 in k2156 in k2153 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 545  print-node */
t3=((C_word*)t0)[3];
f_1168(t3,t2,lf[150],lf[151],((C_word*)t0)[2]);}

/* k2171 in k2168 in k2165 in k2159 in k2156 in k2153 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1873(t3,t2);}

/* k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1873,NULL,2,t0,t1);}
t2=C_set_block_item(lf[42] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[91] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[92] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[147]))){
t6=t5;
f_1879(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t7=(C_word)C_i_car(t6);
/* batch-driver.scm: 552  scan-toplevel-assignments */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t5,t7);}}

/* k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=f_1376(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 555  perform-cps-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t3,((C_word*)t0)[2]);}

/* k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1888,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 556  end-time */
t3=((C_word*)t0)[12];
f_1386(t3,t2,lf[145]);}

/* k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 557  print-node */
t3=((C_word*)t0)[11];
f_1168(t3,t2,lf[143],lf[144],((C_word*)t0)[2]);}

/* k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t3,a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp));
t5=((C_word*)t3)[1];
f_1896(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1896,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1376(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=t3,a[16]=((C_word*)t0)[13],a[17]=t4,tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 563  analyze */
t7=((C_word*)t0)[10];
f_1409(t7,t6,lf[142],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
if(C_truep(C_retrieve(lf[93]))){
if(C_truep((C_word)C_i_memq(lf[140],C_retrieve(lf[32])))){
/* batch-driver.scm: 566  dump-undefined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[141]))(3,*((C_word*)lf[141]+1),t2,t1);}
else{
t3=t2;
f_1906(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1906(2,t3,C_SCHEME_UNDEFINED);}}

/* k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 568  end-time */
t4=((C_word*)t0)[12];
f_1386(t4,t3,lf[139]);}

/* k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 569  print-db */
t3=((C_word*)t0)[2];
f_1190(t3,t2,lf[137],lf[138],((C_word*)t0)[15],((C_word*)t0)[14]);}

/* k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_memq(lf[135],C_retrieve(lf[32])))){
/* batch-driver.scm: 571  print-program-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t2,((C_word*)t0)[15]);}
else{
t3=t2;
f_1916(2,t3,C_SCHEME_UNDEFINED);}}

/* k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
if(C_truep(((C_word*)t0)[18])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 574  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[102],lf[107],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 598  print-node */
t3=((C_word*)t0)[10];
f_1168(t3,t2,lf[133],lf[134],((C_word*)t0)[16]);}}

/* k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[130]))){
t3=C_retrieve(lf[130]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[14],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 602  dribble */
t5=((C_word*)t0)[13];
f_1144(t5,t4,lf[132],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=t2;
f_2011(2,t3,C_SCHEME_UNDEFINED);}}

/* k2117 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 603  emit-global-inline-file */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=f_1376(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 606  perform-closure-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,((C_word*)t0)[2],((C_word*)t0)[14]);}

/* k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 607  end-time */
t3=((C_word*)t0)[11];
f_1386(t3,t2,lf[128]);}

/* k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 608  print-db */
t3=((C_word*)t0)[3];
f_1190(t3,t2,lf[126],lf[127],((C_word*)t0)[13],((C_word*)t0)[2]);}

/* k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[125]))){
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2102(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2102(t4,C_SCHEME_FALSE);}}

/* k2100 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_2102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 610  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],lf[124]);}
else{
t2=((C_word*)t0)[2];
f_2026(2,t2,C_SCHEME_UNDEFINED);}}

/* k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 611  exit */
((C_proc3)C_retrieve_symbol_proc(lf[123]))(3,*((C_word*)lf[123]+1),t2,C_fix(0));}
else{
t3=t2;
f_2029(2,t3,C_SCHEME_UNDEFINED);}}

/* k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 612  print-node */
t3=((C_word*)t0)[2];
f_1168(t3,t2,lf[121],lf[122],((C_word*)t0)[10]);}

/* k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=f_1376(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2046,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2046,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 617  end-time */
t7=((C_word*)t0)[6];
f_1386(t7,t6,lf[120]);}

/* k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=f_1376(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
/* batch-driver.scm: 620  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t3,((C_word*)t0)[8]);}
else{
/* batch-driver.scm: 620  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[119]+1)))(2,*((C_word*)lf[119]+1),t3);}}

/* k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 621  dribble */
t3=((C_word*)t0)[11];
f_1144(t3,t2,lf[117],(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2057 in k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 622  generate-code */
((C_proc9)C_retrieve_symbol_proc(lf[116]))(9,*((C_word*)lf[116]+1),t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2060 in k2057 in k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2065,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 623  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2065(2,t3,C_SCHEME_UNDEFINED);}}

/* k2063 in k2060 in k2057 in k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 624  end-time */
t3=((C_word*)t0)[2];
f_1386(t3,t2,lf[114]);}

/* k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[111],C_retrieve(lf[32])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2087,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 625  ##sys#stop-timer */
t4=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2071(2,t3,C_SCHEME_UNDEFINED);}}

/* k2085 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 625  ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 626  compiler-cleanup-hook */
((C_proc2)C_retrieve_symbol_proc(lf[110]))(2,*((C_word*)lf[110]+1),t2);}

/* k2072 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in a2045 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 627  dribble */
t2=((C_word*)t0)[3];
f_1144(t2,((C_word*)t0)[2],lf[109],C_SCHEME_END_OF_LIST);}

/* a2039 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2009 in k2006 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
/* batch-driver.scm: 616  prepare-for-code-generation */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=f_1376(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1936,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 579  end-time */
t5=((C_word*)t0)[4];
f_1386(t5,t4,lf[106]);}

/* k1938 in a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 580  print-node */
t3=((C_word*)t0)[2];
f_1168(t3,t2,lf[104],lf[105],((C_word*)t0)[6]);}

/* k1941 in k1938 in a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1943,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 582  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1896(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[95]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[96]))){
t3=f_1376(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 589  analyze */
t5=((C_word*)t0)[2];
f_1409(t5,t4,lf[100],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 595  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1896(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 584  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[102],lf[103]);}}}

/* k1960 in k1941 in k1938 in a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[95] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 586  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1896(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1977 in k1941 in k1938 in a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1982,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 590  end-time */
t3=((C_word*)t0)[2];
f_1386(t3,t2,lf[99]);}

/* k1980 in k1977 in k1941 in k1938 in a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=f_1376(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 592  transform-direct-lambdas! */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1986 in k1980 in k1977 in k1941 in k1938 in a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1991,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 593  end-time */
t3=((C_word*)t0)[2];
f_1386(t3,t2,lf[97]);}

/* k1989 in k1986 in k1980 in k1977 in k1941 in k1938 in a1935 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 594  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1896(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1929 in k1920 in k1914 in k1911 in k1908 in k1904 in k1901 in loop in k1889 in k1886 in k1883 in k1877 in k1871 in k1868 in k1865 in k2205 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1838 in k1835 in k1830 in k1827 in k1824 in k1821 in k1818 in k1812 in k1809 in k1806 in k1800 in k1797 in k1794 in k1791 in k1788 in k1785 in k1782 in k1779 in k1776 in k1768 in k1765 in k1762 in k1759 in k1755 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
/* batch-driver.scm: 578  perform-high-level-optimizations */
((C_proc4)C_retrieve_symbol_proc(lf[94]))(4,*((C_word*)lf[94]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1740 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 396  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],t1);}

/* k1733 in k1721 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 397  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[2]);}

/* k1709 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1651 in k1647 in k1643 in k1640 in k1636 in k1628 in k1624 in k1621 in k1618 in k1615 in k1608 in k1605 in k1602 in k1598 in k1595 in k1589 in k1586 in k1583 in k1580 in k1577 in k1574 in k1571 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1486 in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 392  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[2]);}

/* analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1409(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1409,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1411,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no305353 */
t8=t7;
f_1439(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf306349 */
t10=t6;
f_1434(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body303312 */
t12=t5;
f_1411(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[55],t11);}}}}

/* def-no305 in analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1439,NULL,2,t0,t1);}
/* def-contf306349 */
t2=((C_word*)t0)[2];
f_1434(t2,t1,C_fix(0));}

/* def-contf306 in analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1434,NULL,3,t0,t1,t2);}
/* body303312 */
t3=((C_word*)t0)[2];
f_1411(t3,t1,t2,C_SCHEME_TRUE);}

/* body303 in analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1411,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1415,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 203  analyze-expression */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t4,((C_word*)t0)[2]);}

/* k1413 in body303 in analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1418,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 205  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1418(2,t3,C_SCHEME_UNDEFINED);}}

/* a1428 in k1413 in body303 in analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1429,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
((C_proc6)C_retrieve_symbol_proc(lf[52]))(6,*((C_word*)lf[52]+1),t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1422 in k1413 in body303 in analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1423,4,t0,t1,t2,t3);}
/* ##compiler#get */
((C_proc5)C_retrieve_symbol_proc(lf[51]))(5,*((C_word*)lf[51]+1),t1,((C_word*)t0)[2],t2,t3);}

/* k1416 in k1413 in body303 in analyze in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1403,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 199  ##sys#read */
((C_proc4)C_retrieve_symbol_proc(lf[50]))(4,*((C_word*)lf[50]+1),t1,t2,((C_word*)t0)[2]);}

/* end-time in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1386,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 196  printf */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t1,lf[49],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static C_word C_fcall f_1376(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1346,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1352,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1352(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 188  option-arg */
f_1039(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1364 in loop in collect-options in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 188  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1352(t4,t2,t3);}

/* k1368 in k1364 in loop in collect-options in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1266(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1266,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1276,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 179  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 181  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 182  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 183  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1333 in arg-val in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1329 in arg-val in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1276(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1313 in arg-val in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 181  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1305 in arg-val in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1276(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1274 in arg-val in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 184  quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),((C_word*)t0)[3],lf[47],((C_word*)t0)[2]);}}

/* infohook in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1217,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1221,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[46]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1263,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1263 in infohook in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1263,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1219 in infohook in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1224,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[45],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1227(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1227(t5,C_SCHEME_FALSE);}}

/* k1225 in k1219 in infohook in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1227,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1238,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 171  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t4,C_retrieve(lf[42]),t5);}
else{
t2=((C_word*)t0)[3];
f_1224(2,t2,C_SCHEME_UNDEFINED);}}

/* k1240 in k1225 in k1219 in infohook in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 170  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1236 in k1225 in k1219 in infohook in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 167  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[3],C_retrieve(lf[42]),((C_word*)t0)[2],t1);}

/* k1222 in k1219 in infohook in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1205,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 161  print-header */
t6=((C_word*)t0)[2];
f_1153(t6,t5,t2,t3);}

/* k1210 in print-expr in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[36]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1190,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1197,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 156  print-header */
t7=((C_word*)t0)[2];
f_1153(t7,t6,t2,t3);}

/* k1195 in print-db in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1197,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 157  printf */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[39],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1198 in k1195 in print-db in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 158  display-analysis-database */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1168,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1175,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 150  print-header */
t6=((C_word*)t0)[2];
f_1153(t6,t5,t2,t3);}

/* k1173 in print-node in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 152  dump-nodes */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1188,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 153  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1186 in k1173 in print-node in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 153  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* print-header in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1153,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1157,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 143  dribble */
t5=((C_word*)t0)[2];
f_1144(t5,t4,lf[34],(C_word)C_a_i_list(&a,1,t2));}

/* k1155 in print-header in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1157,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[32])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 146  printf */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[33],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1164 in k1155 in print-header in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1095 in k1089 in k1086 in k3189 in k1070 in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1144,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 140  printf */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t1,lf[31],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* option-arg in compile-source-file in k1032 in k1028 in k1024 in k1020 in k1016 in k1012 in k1007 in k1004 in k1001 in k998 in k995 in k992 */
static void C_fcall f_1039(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1039,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 93   quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t1,lf[8],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 96   quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t1,lf[9],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[316] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_994:batch_driver_scm",(void*)f_994},
{"f_997:batch_driver_scm",(void*)f_997},
{"f_1000:batch_driver_scm",(void*)f_1000},
{"f_1003:batch_driver_scm",(void*)f_1003},
{"f_1006:batch_driver_scm",(void*)f_1006},
{"f_1009:batch_driver_scm",(void*)f_1009},
{"f_1014:batch_driver_scm",(void*)f_1014},
{"f_1018:batch_driver_scm",(void*)f_1018},
{"f_1022:batch_driver_scm",(void*)f_1022},
{"f_1026:batch_driver_scm",(void*)f_1026},
{"f_1030:batch_driver_scm",(void*)f_1030},
{"f_1034:batch_driver_scm",(void*)f_1034},
{"f_1036:batch_driver_scm",(void*)f_1036},
{"f_1072:batch_driver_scm",(void*)f_1072},
{"f_3210:batch_driver_scm",(void*)f_3210},
{"f_3199:batch_driver_scm",(void*)f_3199},
{"f_3195:batch_driver_scm",(void*)f_3195},
{"f_3191:batch_driver_scm",(void*)f_3191},
{"f_3180:batch_driver_scm",(void*)f_3180},
{"f_3158:batch_driver_scm",(void*)f_3158},
{"f_1088:batch_driver_scm",(void*)f_1088},
{"f_3152:batch_driver_scm",(void*)f_3152},
{"f_3148:batch_driver_scm",(void*)f_3148},
{"f_1091:batch_driver_scm",(void*)f_1091},
{"f_1097:batch_driver_scm",(void*)f_1097},
{"f_3129:batch_driver_scm",(void*)f_3129},
{"f_3125:batch_driver_scm",(void*)f_3125},
{"f_3121:batch_driver_scm",(void*)f_3121},
{"f_1488:batch_driver_scm",(void*)f_1488},
{"f_1491:batch_driver_scm",(void*)f_1491},
{"f_1494:batch_driver_scm",(void*)f_1494},
{"f_3106:batch_driver_scm",(void*)f_3106},
{"f_3084:batch_driver_scm",(void*)f_3084},
{"f_3102:batch_driver_scm",(void*)f_3102},
{"f_3090:batch_driver_scm",(void*)f_3090},
{"f_1498:batch_driver_scm",(void*)f_1498},
{"f_3082:batch_driver_scm",(void*)f_3082},
{"f_3066:batch_driver_scm",(void*)f_3066},
{"f_3074:batch_driver_scm",(void*)f_3074},
{"f_3078:batch_driver_scm",(void*)f_3078},
{"f_1506:batch_driver_scm",(void*)f_1506},
{"f_1509:batch_driver_scm",(void*)f_1509},
{"f_1512:batch_driver_scm",(void*)f_1512},
{"f_1515:batch_driver_scm",(void*)f_1515},
{"f_1518:batch_driver_scm",(void*)f_1518},
{"f_1521:batch_driver_scm",(void*)f_1521},
{"f_1524:batch_driver_scm",(void*)f_1524},
{"f_1527:batch_driver_scm",(void*)f_1527},
{"f_1530:batch_driver_scm",(void*)f_1530},
{"f_3025:batch_driver_scm",(void*)f_3025},
{"f_1534:batch_driver_scm",(void*)f_1534},
{"f_3020:batch_driver_scm",(void*)f_3020},
{"f_1537:batch_driver_scm",(void*)f_1537},
{"f_1540:batch_driver_scm",(void*)f_1540},
{"f_1543:batch_driver_scm",(void*)f_1543},
{"f_1546:batch_driver_scm",(void*)f_1546},
{"f_1549:batch_driver_scm",(void*)f_1549},
{"f_1552:batch_driver_scm",(void*)f_1552},
{"f_1555:batch_driver_scm",(void*)f_1555},
{"f_1558:batch_driver_scm",(void*)f_1558},
{"f_1561:batch_driver_scm",(void*)f_1561},
{"f_2979:batch_driver_scm",(void*)f_2979},
{"f_1567:batch_driver_scm",(void*)f_1567},
{"f_2964:batch_driver_scm",(void*)f_2964},
{"f_2967:batch_driver_scm",(void*)f_2967},
{"f_2970:batch_driver_scm",(void*)f_2970},
{"f_1573:batch_driver_scm",(void*)f_1573},
{"f_2954:batch_driver_scm",(void*)f_2954},
{"f_2957:batch_driver_scm",(void*)f_2957},
{"f_1576:batch_driver_scm",(void*)f_1576},
{"f_1579:batch_driver_scm",(void*)f_1579},
{"f_2912:batch_driver_scm",(void*)f_2912},
{"f_1582:batch_driver_scm",(void*)f_1582},
{"f_2906:batch_driver_scm",(void*)f_2906},
{"f_1585:batch_driver_scm",(void*)f_1585},
{"f_2897:batch_driver_scm",(void*)f_2897},
{"f_1588:batch_driver_scm",(void*)f_1588},
{"f_2879:batch_driver_scm",(void*)f_2879},
{"f_2882:batch_driver_scm",(void*)f_2882},
{"f_2885:batch_driver_scm",(void*)f_2885},
{"f_2888:batch_driver_scm",(void*)f_2888},
{"f_1591:batch_driver_scm",(void*)f_1591},
{"f_2873:batch_driver_scm",(void*)f_2873},
{"f_2869:batch_driver_scm",(void*)f_2869},
{"f_1597:batch_driver_scm",(void*)f_1597},
{"f_1600:batch_driver_scm",(void*)f_1600},
{"f_2853:batch_driver_scm",(void*)f_2853},
{"f_1604:batch_driver_scm",(void*)f_1604},
{"f_1607:batch_driver_scm",(void*)f_1607},
{"f_2845:batch_driver_scm",(void*)f_2845},
{"f_2837:batch_driver_scm",(void*)f_2837},
{"f_2835:batch_driver_scm",(void*)f_2835},
{"f_1610:batch_driver_scm",(void*)f_1610},
{"f_1617:batch_driver_scm",(void*)f_1617},
{"f_1620:batch_driver_scm",(void*)f_1620},
{"f_1623:batch_driver_scm",(void*)f_1623},
{"f_2820:batch_driver_scm",(void*)f_2820},
{"f_2828:batch_driver_scm",(void*)f_2828},
{"f_1626:batch_driver_scm",(void*)f_1626},
{"f_1630:batch_driver_scm",(void*)f_1630},
{"f_1638:batch_driver_scm",(void*)f_1638},
{"f_1642:batch_driver_scm",(void*)f_1642},
{"f_2818:batch_driver_scm",(void*)f_2818},
{"f_1645:batch_driver_scm",(void*)f_1645},
{"f_2814:batch_driver_scm",(void*)f_2814},
{"f_2810:batch_driver_scm",(void*)f_2810},
{"f_2790:batch_driver_scm",(void*)f_2790},
{"f_2788:batch_driver_scm",(void*)f_2788},
{"f_1649:batch_driver_scm",(void*)f_1649},
{"f_1653:batch_driver_scm",(void*)f_1653},
{"f_1656:batch_driver_scm",(void*)f_1656},
{"f_2767:batch_driver_scm",(void*)f_2767},
{"f_1660:batch_driver_scm",(void*)f_1660},
{"f_2760:batch_driver_scm",(void*)f_2760},
{"f_1664:batch_driver_scm",(void*)f_1664},
{"f_2753:batch_driver_scm",(void*)f_2753},
{"f_1668:batch_driver_scm",(void*)f_1668},
{"f_2746:batch_driver_scm",(void*)f_2746},
{"f_1672:batch_driver_scm",(void*)f_1672},
{"f_2726:batch_driver_scm",(void*)f_2726},
{"f_1676:batch_driver_scm",(void*)f_1676},
{"f_1687:batch_driver_scm",(void*)f_1687},
{"f_1690:batch_driver_scm",(void*)f_1690},
{"f_1693:batch_driver_scm",(void*)f_1693},
{"f_2685:batch_driver_scm",(void*)f_2685},
{"f_1696:batch_driver_scm",(void*)f_1696},
{"f_1699:batch_driver_scm",(void*)f_1699},
{"f_2676:batch_driver_scm",(void*)f_2676},
{"f_2626:batch_driver_scm",(void*)f_2626},
{"f_2632:batch_driver_scm",(void*)f_2632},
{"f_2672:batch_driver_scm",(void*)f_2672},
{"f_2637:batch_driver_scm",(void*)f_2637},
{"f_2653:batch_driver_scm",(void*)f_2653},
{"f_2649:batch_driver_scm",(void*)f_2649},
{"f_1702:batch_driver_scm",(void*)f_1702},
{"f_1723:batch_driver_scm",(void*)f_1723},
{"f_1751:batch_driver_scm",(void*)f_1751},
{"f_1757:batch_driver_scm",(void*)f_1757},
{"f_1761:batch_driver_scm",(void*)f_1761},
{"f_1764:batch_driver_scm",(void*)f_1764},
{"f_1767:batch_driver_scm",(void*)f_1767},
{"f_1770:batch_driver_scm",(void*)f_1770},
{"f_1778:batch_driver_scm",(void*)f_1778},
{"f_1781:batch_driver_scm",(void*)f_1781},
{"f_1784:batch_driver_scm",(void*)f_1784},
{"f_2600:batch_driver_scm",(void*)f_2600},
{"f_2608:batch_driver_scm",(void*)f_2608},
{"f_1787:batch_driver_scm",(void*)f_1787},
{"f_1790:batch_driver_scm",(void*)f_1790},
{"f_2515:batch_driver_scm",(void*)f_2515},
{"f_2544:batch_driver_scm",(void*)f_2544},
{"f_2593:batch_driver_scm",(void*)f_2593},
{"f_2561:batch_driver_scm",(void*)f_2561},
{"f_2565:batch_driver_scm",(void*)f_2565},
{"f_2570:batch_driver_scm",(void*)f_2570},
{"f_2591:batch_driver_scm",(void*)f_2591},
{"f_2556:batch_driver_scm",(void*)f_2556},
{"f_2547:batch_driver_scm",(void*)f_2547},
{"f_2530:batch_driver_scm",(void*)f_2530},
{"f_2534:batch_driver_scm",(void*)f_2534},
{"f_2538:batch_driver_scm",(void*)f_2538},
{"f_2526:batch_driver_scm",(void*)f_2526},
{"f_2506:batch_driver_scm",(void*)f_2506},
{"f_2510:batch_driver_scm",(void*)f_2510},
{"f_1793:batch_driver_scm",(void*)f_1793},
{"f_1796:batch_driver_scm",(void*)f_1796},
{"f_2499:batch_driver_scm",(void*)f_2499},
{"f_2503:batch_driver_scm",(void*)f_2503},
{"f_1799:batch_driver_scm",(void*)f_1799},
{"f_1802:batch_driver_scm",(void*)f_1802},
{"f_2476:batch_driver_scm",(void*)f_2476},
{"f_2496:batch_driver_scm",(void*)f_2496},
{"f_1808:batch_driver_scm",(void*)f_1808},
{"f_2469:batch_driver_scm",(void*)f_2469},
{"f_1811:batch_driver_scm",(void*)f_1811},
{"f_1814:batch_driver_scm",(void*)f_1814},
{"f_2437:batch_driver_scm",(void*)f_2437},
{"f_2311:batch_driver_scm",(void*)f_2311},
{"f_2427:batch_driver_scm",(void*)f_2427},
{"f_2315:batch_driver_scm",(void*)f_2315},
{"f_2319:batch_driver_scm",(void*)f_2319},
{"f_2338:batch_driver_scm",(void*)f_2338},
{"f_2323:batch_driver_scm",(void*)f_2323},
{"f_1820:batch_driver_scm",(void*)f_1820},
{"f_2304:batch_driver_scm",(void*)f_2304},
{"f_1823:batch_driver_scm",(void*)f_1823},
{"f_2298:batch_driver_scm",(void*)f_2298},
{"f_1826:batch_driver_scm",(void*)f_1826},
{"f_1829:batch_driver_scm",(void*)f_1829},
{"f_2283:batch_driver_scm",(void*)f_2283},
{"f_1832:batch_driver_scm",(void*)f_1832},
{"f_1837:batch_driver_scm",(void*)f_1837},
{"f_1840:batch_driver_scm",(void*)f_1840},
{"f_1843:batch_driver_scm",(void*)f_1843},
{"f_1846:batch_driver_scm",(void*)f_1846},
{"f_2264:batch_driver_scm",(void*)f_2264},
{"f_2271:batch_driver_scm",(void*)f_2271},
{"f_1849:batch_driver_scm",(void*)f_1849},
{"f_2261:batch_driver_scm",(void*)f_2261},
{"f_1852:batch_driver_scm",(void*)f_1852},
{"f_2254:batch_driver_scm",(void*)f_2254},
{"f_1855:batch_driver_scm",(void*)f_1855},
{"f_2251:batch_driver_scm",(void*)f_2251},
{"f_2247:batch_driver_scm",(void*)f_2247},
{"f_2216:batch_driver_scm",(void*)f_2216},
{"f_2243:batch_driver_scm",(void*)f_2243},
{"f_2239:batch_driver_scm",(void*)f_2239},
{"f_2220:batch_driver_scm",(void*)f_2220},
{"f_2229:batch_driver_scm",(void*)f_2229},
{"f_2232:batch_driver_scm",(void*)f_2232},
{"f_1858:batch_driver_scm",(void*)f_1858},
{"f_2211:batch_driver_scm",(void*)f_2211},
{"f_2207:batch_driver_scm",(void*)f_2207},
{"f_1867:batch_driver_scm",(void*)f_1867},
{"f_2177:batch_driver_scm",(void*)f_2177},
{"f_2184:batch_driver_scm",(void*)f_2184},
{"f_2187:batch_driver_scm",(void*)f_2187},
{"f_2190:batch_driver_scm",(void*)f_2190},
{"f_2196:batch_driver_scm",(void*)f_2196},
{"f_2199:batch_driver_scm",(void*)f_2199},
{"f_2202:batch_driver_scm",(void*)f_2202},
{"f_1870:batch_driver_scm",(void*)f_1870},
{"f_2155:batch_driver_scm",(void*)f_2155},
{"f_2158:batch_driver_scm",(void*)f_2158},
{"f_2161:batch_driver_scm",(void*)f_2161},
{"f_2167:batch_driver_scm",(void*)f_2167},
{"f_2170:batch_driver_scm",(void*)f_2170},
{"f_2173:batch_driver_scm",(void*)f_2173},
{"f_1873:batch_driver_scm",(void*)f_1873},
{"f_1879:batch_driver_scm",(void*)f_1879},
{"f_1885:batch_driver_scm",(void*)f_1885},
{"f_1888:batch_driver_scm",(void*)f_1888},
{"f_1891:batch_driver_scm",(void*)f_1891},
{"f_1896:batch_driver_scm",(void*)f_1896},
{"f_1903:batch_driver_scm",(void*)f_1903},
{"f_1906:batch_driver_scm",(void*)f_1906},
{"f_1910:batch_driver_scm",(void*)f_1910},
{"f_1913:batch_driver_scm",(void*)f_1913},
{"f_1916:batch_driver_scm",(void*)f_1916},
{"f_2008:batch_driver_scm",(void*)f_2008},
{"f_2119:batch_driver_scm",(void*)f_2119},
{"f_2011:batch_driver_scm",(void*)f_2011},
{"f_2017:batch_driver_scm",(void*)f_2017},
{"f_2020:batch_driver_scm",(void*)f_2020},
{"f_2023:batch_driver_scm",(void*)f_2023},
{"f_2102:batch_driver_scm",(void*)f_2102},
{"f_2026:batch_driver_scm",(void*)f_2026},
{"f_2029:batch_driver_scm",(void*)f_2029},
{"f_2032:batch_driver_scm",(void*)f_2032},
{"f_2046:batch_driver_scm",(void*)f_2046},
{"f_2050:batch_driver_scm",(void*)f_2050},
{"f_2056:batch_driver_scm",(void*)f_2056},
{"f_2059:batch_driver_scm",(void*)f_2059},
{"f_2062:batch_driver_scm",(void*)f_2062},
{"f_2065:batch_driver_scm",(void*)f_2065},
{"f_2068:batch_driver_scm",(void*)f_2068},
{"f_2087:batch_driver_scm",(void*)f_2087},
{"f_2071:batch_driver_scm",(void*)f_2071},
{"f_2074:batch_driver_scm",(void*)f_2074},
{"f_2040:batch_driver_scm",(void*)f_2040},
{"f_1922:batch_driver_scm",(void*)f_1922},
{"f_1936:batch_driver_scm",(void*)f_1936},
{"f_1940:batch_driver_scm",(void*)f_1940},
{"f_1943:batch_driver_scm",(void*)f_1943},
{"f_1962:batch_driver_scm",(void*)f_1962},
{"f_1979:batch_driver_scm",(void*)f_1979},
{"f_1982:batch_driver_scm",(void*)f_1982},
{"f_1988:batch_driver_scm",(void*)f_1988},
{"f_1991:batch_driver_scm",(void*)f_1991},
{"f_1930:batch_driver_scm",(void*)f_1930},
{"f_1742:batch_driver_scm",(void*)f_1742},
{"f_1735:batch_driver_scm",(void*)f_1735},
{"f_1711:batch_driver_scm",(void*)f_1711},
{"f_1409:batch_driver_scm",(void*)f_1409},
{"f_1439:batch_driver_scm",(void*)f_1439},
{"f_1434:batch_driver_scm",(void*)f_1434},
{"f_1411:batch_driver_scm",(void*)f_1411},
{"f_1415:batch_driver_scm",(void*)f_1415},
{"f_1429:batch_driver_scm",(void*)f_1429},
{"f_1423:batch_driver_scm",(void*)f_1423},
{"f_1418:batch_driver_scm",(void*)f_1418},
{"f_1403:batch_driver_scm",(void*)f_1403},
{"f_1386:batch_driver_scm",(void*)f_1386},
{"f_1376:batch_driver_scm",(void*)f_1376},
{"f_1346:batch_driver_scm",(void*)f_1346},
{"f_1352:batch_driver_scm",(void*)f_1352},
{"f_1366:batch_driver_scm",(void*)f_1366},
{"f_1370:batch_driver_scm",(void*)f_1370},
{"f_1266:batch_driver_scm",(void*)f_1266},
{"f_1335:batch_driver_scm",(void*)f_1335},
{"f_1331:batch_driver_scm",(void*)f_1331},
{"f_1315:batch_driver_scm",(void*)f_1315},
{"f_1307:batch_driver_scm",(void*)f_1307},
{"f_1276:batch_driver_scm",(void*)f_1276},
{"f_1217:batch_driver_scm",(void*)f_1217},
{"f_1263:batch_driver_scm",(void*)f_1263},
{"f_1221:batch_driver_scm",(void*)f_1221},
{"f_1227:batch_driver_scm",(void*)f_1227},
{"f_1242:batch_driver_scm",(void*)f_1242},
{"f_1238:batch_driver_scm",(void*)f_1238},
{"f_1224:batch_driver_scm",(void*)f_1224},
{"f_1205:batch_driver_scm",(void*)f_1205},
{"f_1212:batch_driver_scm",(void*)f_1212},
{"f_1190:batch_driver_scm",(void*)f_1190},
{"f_1197:batch_driver_scm",(void*)f_1197},
{"f_1200:batch_driver_scm",(void*)f_1200},
{"f_1168:batch_driver_scm",(void*)f_1168},
{"f_1175:batch_driver_scm",(void*)f_1175},
{"f_1188:batch_driver_scm",(void*)f_1188},
{"f_1153:batch_driver_scm",(void*)f_1153},
{"f_1157:batch_driver_scm",(void*)f_1157},
{"f_1166:batch_driver_scm",(void*)f_1166},
{"f_1144:batch_driver_scm",(void*)f_1144},
{"f_1039:batch_driver_scm",(void*)f_1039},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
