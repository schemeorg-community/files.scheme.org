/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:49
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: csi.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -output-file csi.c -extend ./private-namespace.scm
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_69 ports
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[386];
static double C_possibly_force_alignment;


/* from k1801 */
static C_word C_fcall stub128(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub128(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_fcall f_3137(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5570)
static void C_fcall f_5570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_fcall f_4843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_fcall f_4849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_fcall f_5010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_fcall f_5022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_fcall f_5058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5250)
static void C_fcall f_5250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_fcall f_4940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_fcall f_4956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_fcall f_4860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4866)
static void C_fcall f_4866(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_fcall f_4682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_fcall f_4688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4710)
static void C_fcall f_4710(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static C_word C_fcall f_4799(C_word t0);
C_noret_decl(f_4625)
static void C_fcall f_4625(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4631)
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4643)
static void C_fcall f_4643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4389)
static void C_fcall f_4389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_fcall f_4474(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_fcall f_4511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_fcall f_4423(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_fcall f_4360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4309)
static void C_fcall f_4309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_fcall f_4304(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4198)
static void C_fcall f_4198(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_fcall f_4266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_fcall f_4201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_fcall f_4023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_fcall f_3862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_fcall f_3767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_fcall f_3703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3635)
static void C_ccall f_3635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_fcall f_3652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_fcall f_3386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_fcall f_3194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2735)
static void C_ccall f_2735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_fcall f_2703(C_word t0) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2668)
static void C_fcall f_2668(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2115)
static void C_fcall f_2115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_fcall f_2958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_fcall f_1972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_fcall f_1916(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static C_word C_fcall f_1835(C_word t0,C_word t1);
C_noret_decl(f_1808)
static void C_fcall f_1808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_fcall f_1771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3137)
static void C_fcall trf_3137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3137(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3137(t0,t1,t2,t3);}

C_noret_decl(trf_5570)
static void C_fcall trf_5570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5570(t0,t1);}

C_noret_decl(trf_4843)
static void C_fcall trf_4843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4843(t0,t1);}

C_noret_decl(trf_4849)
static void C_fcall trf_4849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4849(t0,t1);}

C_noret_decl(trf_5010)
static void C_fcall trf_5010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5010(t0,t1);}

C_noret_decl(trf_5022)
static void C_fcall trf_5022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5022(t0,t1);}

C_noret_decl(trf_5058)
static void C_fcall trf_5058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5058(t0,t1,t2);}

C_noret_decl(trf_5250)
static void C_fcall trf_5250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5250(t0,t1);}

C_noret_decl(trf_4940)
static void C_fcall trf_4940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4940(t0,t1,t2);}

C_noret_decl(trf_4956)
static void C_fcall trf_4956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4956(t0,t1,t2);}

C_noret_decl(trf_4860)
static void C_fcall trf_4860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4860(t0,t1,t2);}

C_noret_decl(trf_4866)
static void C_fcall trf_4866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4866(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4866(t0,t1,t2);}

C_noret_decl(trf_4682)
static void C_fcall trf_4682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4682(t0,t1);}

C_noret_decl(trf_4688)
static void C_fcall trf_4688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4688(t0,t1,t2);}

C_noret_decl(trf_4710)
static void C_fcall trf_4710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4710(t0,t1);}

C_noret_decl(trf_4625)
static void C_fcall trf_4625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4625(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4625(t0,t1,t2);}

C_noret_decl(trf_4631)
static void C_fcall trf_4631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4631(t0,t1,t2);}

C_noret_decl(trf_4643)
static void C_fcall trf_4643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4643(t0,t1,t2);}

C_noret_decl(trf_4575)
static void C_fcall trf_4575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4575(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4575(t0,t1,t2);}

C_noret_decl(trf_4389)
static void C_fcall trf_4389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4389(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4389(t0,t1,t2);}

C_noret_decl(trf_4474)
static void C_fcall trf_4474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4474(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4474(t0,t1,t2,t3);}

C_noret_decl(trf_4511)
static void C_fcall trf_4511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4511(t0,t1,t2);}

C_noret_decl(trf_4423)
static void C_fcall trf_4423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4423(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4423(t0,t1,t2,t3);}

C_noret_decl(trf_4360)
static void C_fcall trf_4360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4360(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4360(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4309)
static void C_fcall trf_4309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4309(t0,t1);}

C_noret_decl(trf_4304)
static void C_fcall trf_4304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4304(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4304(t0,t1,t2);}

C_noret_decl(trf_4198)
static void C_fcall trf_4198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4198(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4198(t0,t1,t2,t3);}

C_noret_decl(trf_4266)
static void C_fcall trf_4266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4266(t0,t1);}

C_noret_decl(trf_4201)
static void C_fcall trf_4201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4201(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4201(t0,t1,t2);}

C_noret_decl(trf_4023)
static void C_fcall trf_4023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4023(t0,t1,t2);}

C_noret_decl(trf_3862)
static void C_fcall trf_3862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3862(t0,t1);}

C_noret_decl(trf_3767)
static void C_fcall trf_3767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3767(t0,t1);}

C_noret_decl(trf_3703)
static void C_fcall trf_3703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3703(t0,t1);}

C_noret_decl(trf_3652)
static void C_fcall trf_3652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3652(t0,t1,t2);}

C_noret_decl(trf_3386)
static void C_fcall trf_3386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3386(t0,t1,t2);}

C_noret_decl(trf_3418)
static void C_fcall trf_3418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3418(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3418(t0,t1,t2,t3);}

C_noret_decl(trf_3194)
static void C_fcall trf_3194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3194(t0,t1);}

C_noret_decl(trf_2703)
static void C_fcall trf_2703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2703(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2703(t0);}

C_noret_decl(trf_2712)
static void C_fcall trf_2712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2712(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2712(t0,t1,t2);}

C_noret_decl(trf_2668)
static void C_fcall trf_2668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2668(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2668(t0,t1,t2);}

C_noret_decl(trf_2115)
static void C_fcall trf_2115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2115(t0,t1);}

C_noret_decl(trf_2958)
static void C_fcall trf_2958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2958(t0,t1);}

C_noret_decl(trf_1972)
static void C_fcall trf_1972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1972(t0,t1);}

C_noret_decl(trf_1916)
static void C_fcall trf_1916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1916(t0,t1,t2);}

C_noret_decl(trf_1808)
static void C_fcall trf_1808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1808(t0,t1);}

C_noret_decl(trf_1771)
static void C_fcall trf_1771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1771(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2663)){
C_save(t1);
C_rereclaim2(2663*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,386);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[4]=C_h_intern(&lf[4],27,"\003sysrepl-print-length-limit");
lf[5]=C_h_intern(&lf[5],4,"\000csi");
lf[6]=C_h_intern(&lf[6],12,"\003sysfeatures");
lf[7]=C_h_intern(&lf[7],15,"\003csiprint-usage");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\003\376    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -k  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012    -R  -require-ex"
"tension NAME   require extension and import before\012                             "
"      executing code\012    -I  -include-path PATHNAME    add PATHNAME to include p"
"ath\012    --                            ignore all following options\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[12]=C_h_intern(&lf[12],19,"\003sysprint-to-string");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\002\344usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012    -v  -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012    -q  -quiet               "
"     do not print banner\012");
lf[14]=C_h_intern(&lf[14],16,"\003csiprint-banner");
lf[15]=C_h_intern(&lf[15],5,"print");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[18]=C_h_intern(&lf[18],15,"chicken-version");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[20]=C_h_intern(&lf[20],7,"newline");
lf[21]=C_h_intern(&lf[21],9,"read-char");
lf[22]=C_h_intern(&lf[22],4,"read");
lf[23]=C_h_intern(&lf[23],18,"\003sysuser-read-hook");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],17,"\003csihistory-count");
lf[26]=C_h_intern(&lf[26],15,"\003csihistory-ref");
lf[27]=C_h_intern(&lf[27],21,"\003syssharp-number-hook");
lf[28]=C_h_intern(&lf[28],9,"substring");
lf[29]=C_h_intern(&lf[29],18,"\003csichop-separator");
lf[30]=C_h_intern(&lf[30],4,"sub1");
lf[31]=C_h_intern(&lf[31],1,"@");
lf[32]=C_h_intern(&lf[32],12,"file-exists\077");
lf[33]=C_h_intern(&lf[33],13,"string-append");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[35]=C_h_intern(&lf[35],22,"\003csilookup-script-file");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[37]=C_h_intern(&lf[37],25,"\003syspeek-nonnull-c-string");
lf[38]=C_h_intern(&lf[38],12,"string-split");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[41]=C_h_intern(&lf[41],6,"getenv");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[43]=C_h_intern(&lf[43],16,"\003csihistory-list");
lf[44]=C_h_intern(&lf[44],13,"vector-resize");
lf[45]=C_h_intern(&lf[45],15,"\003csihistory-add");
lf[46]=C_h_intern(&lf[46],19,"\003sysundefined-value");
lf[47]=C_h_intern(&lf[47],9,"\003syserror");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[49]=C_h_intern(&lf[49],14,"\003csitty-input\077");
lf[50]=C_h_intern(&lf[50],13,"\003systty-port\077");
lf[51]=C_h_intern(&lf[51],18,"\003sysstandard-input");
lf[52]=C_h_intern(&lf[52],18,"\003sysbreak-on-error");
lf[53]=C_h_intern(&lf[53],20,"\003sysread-prompt-hook");
lf[55]=C_h_intern(&lf[55],16,"toplevel-command");
lf[56]=C_h_intern(&lf[56],19,"\003syshash-table-set!");
lf[57]=C_h_intern(&lf[57],4,"eval");
lf[58]=C_h_intern(&lf[58],12,"load-noisily");
lf[59]=C_h_intern(&lf[59],10,"singlestep");
lf[60]=C_h_intern(&lf[60],9,"read-line");
lf[61]=C_h_intern(&lf[61],6,"length");
lf[62]=C_h_intern(&lf[62],5,"write");
lf[63]=C_h_intern(&lf[63],6,"printf");
lf[64]=C_h_intern(&lf[64],6,"expand");
lf[65]=C_h_intern(&lf[65],12,"pretty-print");
lf[66]=C_h_intern(&lf[66],8,"integer\077");
lf[67]=C_h_intern(&lf[67],6,"values");
lf[68]=C_h_intern(&lf[68],18,"\003sysrepl-eval-hook");
lf[69]=C_h_intern(&lf[69],22,"\003csitrace-indent-level");
lf[70]=C_h_intern(&lf[70],4,"exit");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_h_intern(&lf[72],16,"\003sysstrip-syntax");
lf[73]=C_h_intern(&lf[73],1,"p");
lf[74]=C_h_intern(&lf[74],1,"d");
lf[75]=C_h_intern(&lf[75],12,"\003csidescribe");
lf[76]=C_h_intern(&lf[76],2,"du");
lf[77]=C_h_intern(&lf[77],8,"\003csidump");
lf[78]=C_h_intern(&lf[78],3,"dur");
lf[79]=C_h_intern(&lf[79],1,"r");
lf[80]=C_h_intern(&lf[80],10,"\003csireport");
lf[81]=C_h_intern(&lf[81],1,"q");
lf[82]=C_h_intern(&lf[82],1,"l");
lf[83]=C_h_intern(&lf[83],12,"\003sysfor-each");
lf[84]=C_h_intern(&lf[84],4,"load");
lf[85]=C_h_intern(&lf[85],2,"ln");
lf[86]=C_h_intern(&lf[86],6,"print*");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[88]=C_h_intern(&lf[88],8,"\000printer");
lf[89]=C_h_intern(&lf[89],1,"t");
lf[90]=C_h_intern(&lf[90],17,"\003sysdisplay-times");
lf[91]=C_h_intern(&lf[91],14,"\003sysstop-timer");
lf[92]=C_h_intern(&lf[92],15,"\003sysstart-timer");
lf[93]=C_h_intern(&lf[93],2,"tr");
lf[95]=C_h_intern(&lf[95],8,"\003syswarn");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[99]=C_h_intern(&lf[99],25,"\003csitraced-procedure-exit");
lf[100]=C_h_intern(&lf[100],26,"\003csitraced-procedure-entry");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot trace non-procedure");
lf[102]=C_h_intern(&lf[102],7,"\003sysmap");
lf[104]=C_h_intern(&lf[104],3,"utr");
lf[105]=C_h_intern(&lf[105],7,"\003csidel");
lf[106]=C_h_intern(&lf[106],3,"eq\077");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[108]=C_h_intern(&lf[108],2,"br");
lf[109]=C_h_intern(&lf[109],1,"a");
lf[110]=C_h_intern(&lf[110],15,"\003sysbreak-entry");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000&cannot set breakpoint on non-procedure");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[113]=C_h_intern(&lf[113],3,"ubr");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[115]=C_h_intern(&lf[115],3,"uba");
lf[116]=C_h_intern(&lf[116],14,"do-unbreak-all");
lf[117]=C_h_intern(&lf[117],8,"breakall");
lf[118]=C_h_intern(&lf[118],19,"\003sysbreak-in-thread");
lf[119]=C_h_intern(&lf[119],9,"breakonly");
lf[120]=C_h_intern(&lf[120],4,"info");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[122]=C_h_intern(&lf[122],3,"car");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[124]=C_h_intern(&lf[124],1,"c");
lf[125]=C_h_intern(&lf[125],19,"\003syslast-breakpoint");
lf[126]=C_h_intern(&lf[126],16,"\003sysbreak-resume");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[128]=C_h_intern(&lf[128],3,"exn");
lf[129]=C_h_intern(&lf[129],18,"\003syslast-exception");
lf[130]=C_h_intern(&lf[130],4,"step");
lf[131]=C_h_intern(&lf[131],6,"lambda");
lf[132]=C_h_intern(&lf[132],1,"s");
lf[133]=C_h_intern(&lf[133],6,"system");
lf[134]=C_h_intern(&lf[134],1,"\077");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[136]=C_h_intern(&lf[136],23,"\003syshash-table-for-each");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\004OToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print expanded expression EXP\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[139]=C_h_intern(&lf[139],18,"\003syshash-table-ref");
lf[140]=C_h_intern(&lf[140],7,"unquote");
lf[141]=C_h_intern(&lf[141],23,"\003syscurrent-environment");
lf[142]=C_h_intern(&lf[142],14,"string->symbol");
lf[144]=C_h_intern(&lf[144],19,"\003syswrite-char/port");
lf[145]=C_h_intern(&lf[145],19,"\003sysstandard-output");
lf[146]=C_h_intern(&lf[146],12,"flush-output");
lf[147]=C_h_intern(&lf[147],16,"\003syswrite-char-0");
lf[148]=C_h_intern(&lf[148],4,"add1");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[150]=C_h_intern(&lf[150],4,"chop");
lf[151]=C_h_intern(&lf[151],4,"sort");
lf[152]=C_h_intern(&lf[152],19,"with-output-to-port");
lf[153]=C_h_intern(&lf[153],19,"current-output-port");
lf[154]=C_h_intern(&lf[154],8,"truncate");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\002\001~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbol count:\011~S~%~\012                   Memory:\011heap "
"size is ~S bytes~A with ~S bytes currently in use~%~  \012                     nurs"
"ery size is ~S bytes, stack grows ~A~%");
lf[164]=C_h_intern(&lf[164],21,"\003sysinclude-pathnames");
lf[165]=C_h_intern(&lf[165],14,"build-platform");
lf[166]=C_h_intern(&lf[166],16,"software-version");
lf[167]=C_h_intern(&lf[167],13,"software-type");
lf[168]=C_h_intern(&lf[168],12,"machine-type");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[170]=C_h_intern(&lf[170],11,"make-string");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[172]=C_h_intern(&lf[172],8,"string<\077");
lf[173]=C_h_intern(&lf[173],15,"keyword->string");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[175]=C_h_intern(&lf[175],17,"memory-statistics");
lf[176]=C_h_intern(&lf[176],21,"\003syssymbol-table-info");
lf[177]=C_h_intern(&lf[177],2,"gc");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[181]=C_h_intern(&lf[181],7,"sprintf");
lf[182]=C_h_intern(&lf[182],7,"fprintf");
lf[183]=C_h_intern(&lf[183],8,"list-ref");
lf[184]=C_h_intern(&lf[184],10,"string-ref");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[199]=C_h_intern(&lf[199],28,"\003sysarbitrary-unbound-symbol");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[203]=C_h_intern(&lf[203],8,"\003syssize");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[205]=C_h_intern(&lf[205],8,"\003sysslot");
lf[206]=C_h_intern(&lf[206],27,"\003syswith-print-length-limit");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\027~asymbol with name ~S~%");
lf[212]=C_h_intern(&lf[212],18,"\003syssymbol->string");
lf[213]=C_h_intern(&lf[213],20,"\003sysinterned-symbol\077");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[216]=C_h_intern(&lf[216],32,"\003syssymbol-has-toplevel-binding\077");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[219]=C_h_intern(&lf[219],15,"describe-object");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[221]=C_h_intern(&lf[221],25,"\003syspeek-unsigned-integer");
lf[222]=C_h_intern(&lf[222],9,"\000tinyclos");
lf[223]=C_h_intern(&lf[223],19,"\010tinyclosentity-tag");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[239]=C_h_intern(&lf[239],11,"\003csihexdump");
lf[240]=C_h_intern(&lf[240],8,"\003sysbyte");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[243]=C_h_intern(&lf[243],23,"\003syslambda-info->string");
lf[244]=C_h_intern(&lf[244],10,"hash-table");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[246]=C_h_intern(&lf[246],15,"hash-table-walk");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[251]=C_h_intern(&lf[251],9,"condition");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[253]=C_h_intern(&lf[253],4,"cdar");
lf[254]=C_h_intern(&lf[254],4,"caar");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[257]=C_h_intern(&lf[257],6,"unveil");
lf[258]=C_h_intern(&lf[258],6,"append");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[261]=C_h_intern(&lf[261],15,"meroon-instance");
lf[262]=C_h_intern(&lf[262],9,"provided\077");
lf[263]=C_h_intern(&lf[263],6,"meroon");
lf[264]=C_h_intern(&lf[264],15,"\003sysbytevector\077");
lf[265]=C_h_intern(&lf[265],13,"\003syslocative\077");
lf[266]=C_h_intern(&lf[266],9,"instance\077");
lf[267]=C_h_intern(&lf[267],5,"port\077");
lf[268]=C_h_intern(&lf[268],11,"\003sysnumber\077");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[270]=C_h_intern(&lf[270],17,"\003sysblock-address");
lf[271]=C_h_intern(&lf[271],14,"set-describer!");
lf[272]=C_h_intern(&lf[272],16,"\003syscheck-symbol");
lf[273]=C_h_intern(&lf[273],6,"symbol");
lf[274]=C_h_intern(&lf[274],3,"min");
lf[275]=C_h_intern(&lf[275],4,"dump");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[277]=C_h_intern(&lf[277],13,"\003syspeek-byte");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[279]=C_h_intern(&lf[279],10,"write-char");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[281]=C_h_intern(&lf[281],5,"fxmod");
lf[282]=C_h_intern(&lf[282],11,"\003csideldups");
lf[283]=C_h_intern(&lf[283],6,"equal\077");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[291]=C_h_intern(&lf[291],16,"\003sysstring->list");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000"
"\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000"
"\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376"
"\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release"
"\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[293]=C_h_intern(&lf[293],7,"\003csirun");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[295]=C_h_intern(&lf[295],8,"\003syslist");
lf[296]=C_h_intern(&lf[296],17,"open-input-string");
lf[297]=C_h_intern(&lf[297],4,"repl");
lf[298]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[307]=C_h_intern(&lf[307],22,"\004corerequire-extension");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[312]=C_h_intern(&lf[312],8,"for-each");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[316]=C_h_intern(&lf[316],4,"main");
lf[317]=C_h_intern(&lf[317],22,"command-line-arguments");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[319]=C_h_intern(&lf[319],18,"\003sysstandard-error");
lf[320]=C_h_intern(&lf[320],8,"\003sysload");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[324]=C_h_intern(&lf[324],17,"\003sysstring-append");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[327]=C_h_intern(&lf[327],13,"symbol-escape");
lf[328]=C_h_intern(&lf[328],20,"parentheses-synonyms");
lf[329]=C_h_intern(&lf[329],13,"keyword-style");
lf[330]=C_h_intern(&lf[330],5,"\000none");
lf[331]=C_h_intern(&lf[331],14,"case-sensitive");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[335]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000*Disabled support for parentheses synonyms\012");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[339]=C_h_intern(&lf[339],7,"\000prefix");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[342]=C_h_intern(&lf[342],7,"\000suffix");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[344]=C_h_intern(&lf[344],8,"string=\077");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[347]=C_h_intern(&lf[347],17,"register-feature!");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[350]=C_h_intern(&lf[350],16,"case-insensitive");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[352]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[353]=C_h_intern(&lf[353],12,"load-verbose");
lf[354]=C_h_intern(&lf[354],20,"\003syswarnings-enabled");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[358]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[359]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[360]=C_h_intern(&lf[360],20,"\003syseval-debug-level");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[367]=C_h_intern(&lf[367],20,"\003syswindows-platform");
lf[368]=C_h_intern(&lf[368],6,"script");
lf[369]=C_h_intern(&lf[369],12,"program-name");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[372]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[375]=C_h_intern(&lf[375],17,"get-output-string");
lf[376]=C_h_intern(&lf[376],18,"open-output-string");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[378]=C_h_intern(&lf[378],7,"reverse");
lf[379]=C_h_intern(&lf[379],22,"with-exception-handler");
lf[380]=C_h_intern(&lf[380],30,"call-with-current-continuation");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[382]=C_h_intern(&lf[382],25,"\003sysimplicit-exit-handler");
lf[383]=C_h_intern(&lf[383],11,"make-vector");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[385]=C_h_intern(&lf[385],11,"repl-prompt");
C_register_lf2(lf,386,create_ptable());
t2=C_mutate(&lf[0] /* (set! c275 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1619 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1622 in k1619 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1625 in k1622 in k1619 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant51 ...) */,lf[3]);
t3=C_set_block_item(lf[4] /* repl-print-length-limit */,0,C_fix(2048));
t4=(C_word)C_a_i_cons(&a,2,lf[5],C_retrieve(lf[6]));
t5=C_mutate((C_word*)lf[6]+1 /* (set! features ...) */,t4);
t6=C_mutate((C_word*)lf[7]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1655,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[14]+1 /* (set! print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1683,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[21]+1);
t9=*((C_word*)lf[22]+1);
t10=C_retrieve(lf[23]);
t11=C_mutate((C_word*)lf[23]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1732,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[28]+1);
t14=C_mutate((C_word*)lf[29]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1758,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[31] /* @ */,0,C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 178  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[170]+1)))(3,*((C_word*)lf[170]+1),t16,C_fix(256));}

/* k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1808,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[35]+1 /* (set! lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1856,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t5);
t7=C_set_block_item(lf[25] /* history-count */,0,C_fix(1));
t8=C_retrieve(lf[44]);
t9=C_mutate((C_word*)lf[45]+1 /* (set! history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[26]+1 /* (set! history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2001,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[181]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5645,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 230  repl-prompt */
((C_proc3)C_retrieve_symbol_proc(lf[385]))(3,*((C_word*)lf[385]+1),t11,t13);}

/* a5644 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5645,2,t0,t1);}
/* csi.scm: 233  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[384],C_retrieve(lf[25]));}

/* k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2028,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[52] /* break-on-error */,0,C_SCHEME_FALSE);
t4=C_retrieve(lf[53]);
t5=C_mutate((C_word*)lf[53]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2041,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 245  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[383]+1)))(4,*((C_word*)lf[383]+1),t6,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! command-table ...) */,t1);
t3=C_mutate((C_word*)lf[55]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2057,tmp=(C_word)a,a+=2,tmp));
t4=C_retrieve(lf[57]);
t5=C_retrieve(lf[58]);
t6=*((C_word*)lf[22]+1);
t7=C_retrieve(lf[59]);
t8=C_retrieve(lf[60]);
t9=*((C_word*)lf[61]+1);
t10=*((C_word*)lf[8]+1);
t11=*((C_word*)lf[62]+1);
t12=C_retrieve(lf[38]);
t13=C_retrieve(lf[63]);
t14=C_retrieve(lf[64]);
t15=C_retrieve(lf[65]);
t16=*((C_word*)lf[66]+1);
t17=*((C_word*)lf[67]+1);
t18=C_mutate((C_word*)lf[68]+1 /* (set! repl-eval-hook ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2098,a[2]=t7,a[3]=t10,a[4]=t13,a[5]=t17,a[6]=t5,a[7]=t8,a[8]=t12,a[9]=t4,a[10]=t6,a[11]=t14,a[12]=t15,tmp=(C_word)a,a+=13,tmp));
t19=C_mutate(&lf[103] /* (set! resolve-var ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2648,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[105]+1 /* (set! del ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2662,tmp=(C_word)a,a+=2,tmp));
t21=C_set_block_item(lf[69] /* trace-indent-level */,0,C_fix(0));
t22=lf[94] /* traced-procedures */ =C_SCHEME_END_OF_LIST;;
t23=lf[97] /* broken-procedures */ =C_SCHEME_END_OF_LIST;;
t24=C_mutate(&lf[143] /* (set! trace-indent ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2703,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[100]+1 /* (set! traced-procedure-entry ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2731,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[99]+1 /* (set! traced-procedure-exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2754,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[116]+1 /* (set! do-unbreak-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3045,tmp=(C_word)a,a+=2,tmp));
t28=C_retrieve(lf[63]);
t29=C_retrieve(lf[150]);
t30=C_retrieve(lf[151]);
t31=C_retrieve(lf[152]);
t32=*((C_word*)lf[153]+1);
t33=C_mutate((C_word*)lf[80]+1 /* (set! report ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3172,a[2]=t32,a[3]=t31,a[4]=t30,a[5]=t29,a[6]=t28,tmp=(C_word)a,a+=7,tmp));
t34=C_mutate(&lf[178] /* (set! bytevector-data ...) */,lf[179]);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 607  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[383]+1)))(4,*((C_word*)lf[383]+1),t35,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=C_mutate(&lf[180] /* (set! describer-table ...) */,t1);
t3=C_retrieve(lf[181]);
t4=C_retrieve(lf[63]);
t5=C_retrieve(lf[182]);
t6=*((C_word*)lf[61]+1);
t7=*((C_word*)lf[183]+1);
t8=*((C_word*)lf[184]+1);
t9=C_mutate((C_word*)lf[75]+1 /* (set! describe ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3368,a[2]=t3,a[3]=t7,a[4]=t6,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=C_mutate((C_word*)lf[271]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4187,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[77]+1 /* (set! dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4196,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[8]+1);
t13=*((C_word*)lf[33]+1);
t14=*((C_word*)lf[170]+1);
t15=*((C_word*)lf[279]+1);
t16=C_mutate((C_word*)lf[239]+1 /* (set! hexdump ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4357,a[2]=t12,a[3]=t15,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[282]+1 /* (set! deldups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4566,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[284] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4625,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[285] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4682,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[293]+1 /* (set! run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4827,tmp=(C_word)a,a+=2,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 1013 run */
((C_proc2)C_retrieve_symbol_proc(lf[293]))(2,*((C_word*)lf[293]+1),t21);}

/* k5635 in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5643,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[382]))(2,*((C_word*)lf[382]+1),t3);}

/* k5641 in k5635 in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5638 in k5635 in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4831,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5631,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 875  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[381]);}

/* k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[374]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 525  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[296]))(3,*((C_word*)lf[296]+1),t3,t2);}

/* k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3078,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3103,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[380]+1)))(3,*((C_word*)lf[380]+1),t4,t5);}

/* a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3121,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[379]))(4,*((C_word*)lf[379]+1),t1,t3,t4);}

/* a3120 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3159 in a3120 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3160r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3160r(t0,t1,t2);}}

static void C_ccall f_3160r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3166,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k622627 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3165 in a3159 in a3120 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3126 in a3120 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 533  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k3133 in a3126 in a3120 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3137(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop633 in k3133 in a3126 in a3120 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3137(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3137,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 535  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[378]+1)))(3,*((C_word*)lf[378]+1),t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3154,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 533  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t4,((C_word*)t0)[2]);}}

/* k3152 in doloop633 in k3133 in a3126 in a3120 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3137(t3,((C_word*)t0)[2],t1,t2);}

/* a3108 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3109,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* k622627 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3114 in a3108 in a3102 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
/* csi.scm: 532  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[377],((C_word*)t0)[2]);}

/* k3099 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3096 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3077 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3078,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3088,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 529  open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[376]))(2,*((C_word*)lf[376]+1),t3);}}

/* k3086 in a3077 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3091,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 530  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2],t1);}

/* k3089 in k3086 in a3077 in k3071 in k5629 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 531  get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[375]))(3,*((C_word*)lf[375]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5627,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 876  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[317]))(2,*((C_word*)lf[317]+1),t3);}

/* k5625 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 876  canonicalize-args */
f_4682(((C_word*)t0)[2],t1);}

/* k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 878  member* */
f_4625(t4,lf[373],((C_word*)t3)[1]);}

/* k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 879  member* */
f_4625(t2,lf[372],((C_word*)((C_word*)t0)[4])[1]);}

/* k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5520,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5570,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5570(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5570(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5570(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5610,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 893  canonicalize-args */
f_4682(t4,((C_word*)t0)[2]);}}

/* k5621 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 893  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5608 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[371],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4843(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5568 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_5570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 884  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[370]);}
else{
t2=((C_word*)t0)[2];
f_5520(2,t2,C_SCHEME_UNDEFINED);}}

/* k5518 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 885  program-name */
((C_proc3)C_retrieve_symbol_proc(lf[369]))(3,*((C_word*)lf[369]+1),t2,t3);}

/* k5521 in k5518 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 886  command-line-arguments */
((C_proc3)C_retrieve_symbol_proc(lf[317]))(3,*((C_word*)lf[317]+1),t2,t3);}

/* k5524 in k5521 in k5518 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 887  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[347]))(3,*((C_word*)lf[347]+1),t2,lf[368]);}

/* k5527 in k5524 in k5521 in k5518 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[367]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 890  lookup-script-file */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4843(t4,C_SCHEME_UNDEFINED);}}

/* k5536 in k5527 in k5524 in k5521 in k5518 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4843(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4843(t2,C_SCHEME_FALSE);}}

/* k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4843,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 896  member* */
f_4625(t2,lf[366],((C_word*)((C_word*)t0)[4])[1]);}

/* k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4849(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5514,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 897  member* */
f_4625(t3,lf[365],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5512 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4849(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4849,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 898  member* */
f_4625(t2,lf[364],((C_word*)((C_word*)t0)[4])[1]);}

/* k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4858,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5501,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5505,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 900  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t5,lf[363]);}

/* k5503 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[361]);
/* csi.scm: 900  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2,lf[362]);}

/* k5499 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4940,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5010,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[360] /* eval-debug-level */,0,C_fix(0));
t6=t4;
f_5010(t6,t5);}
else{
t5=t4;
f_5010(t5,C_SCHEME_UNDEFINED);}}

/* k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_5010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5010,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 923  member* */
f_4625(t3,lf[359],((C_word*)((C_word*)t0)[6])[1]);}

/* k5488 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 924  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5013(2,t2,C_SCHEME_UNDEFINED);}}

/* k5491 in k5488 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 925  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5481,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 926  member* */
f_4625(t3,lf[358],((C_word*)((C_word*)t0)[6])[1]);}

/* k5479 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 927  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5016(2,t2,C_SCHEME_UNDEFINED);}}

/* k5482 in k5479 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 928  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[357],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5471,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5478,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 930  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t4);}
else{
t3=t2;
f_5019(2,t3,C_SCHEME_UNDEFINED);}}

/* k5476 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 930  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1);}

/* k5469 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 931  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 932  member* */
f_4625(t3,lf[356],((C_word*)((C_word*)t0)[6])[1]);}

/* k5456 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5461(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 933  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[355]);}}
else{
t2=((C_word*)t0)[3];
f_5022(t2,C_SCHEME_UNDEFINED);}}

/* k5459 in k5456 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[354] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_5022(t3,t2);}

/* k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_5022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5022,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_5025(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 936  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[353]))(3,*((C_word*)lf[353]+1),t3,C_SCHEME_TRUE);}}

/* k5450 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 937  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5437,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 938  member* */
f_4625(t3,lf[352],((C_word*)((C_word*)t0)[6])[1]);}

/* k5435 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5437,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5440(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 939  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[351]);}}
else{
t2=((C_word*)t0)[3];
f_5028(2,t2,C_SCHEME_UNDEFINED);}}

/* k5438 in k5435 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 940  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[347]))(3,*((C_word*)lf[347]+1),t2,lf[350]);}

/* k5441 in k5438 in k5435 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 941  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[331]))(3,*((C_word*)lf[331]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 942  collect-options */
t4=((C_word*)t0)[2];
f_4860(t4,t3,lf[349]);}

/* k5432 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[347]),t1);}

/* k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 943  collect-options */
t4=((C_word*)t0)[2];
f_4860(t4,t3,lf[348]);}

/* k5428 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[347]),t1);}

/* k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5038,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5426,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 946  collect-options */
t6=((C_word*)t0)[2];
f_4860(t6,t5,lf[346]);}

/* k5424 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k5412 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5422,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 947  collect-options */
t4=((C_word*)t0)[2];
f_4860(t4,t3,lf[345]);}

/* k5420 in k5412 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k5416 in k5412 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 946  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[258]+1)))(6,*((C_word*)lf[258]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[164]),((C_word*)t0)[2]);}

/* k5408 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 945  deldups */
((C_proc4)C_retrieve_symbol_proc(lf[282]))(4,*((C_word*)lf[282]+1),((C_word*)t0)[2],t1,*((C_word*)lf[344]+1));}

/* k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5038,2,t0,t1);}
t2=C_mutate((C_word*)lf[164]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[338],t5))){
/* csi.scm: 955  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t3,lf[339]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[340],t6))){
/* csi.scm: 957  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t3,lf[330]);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[341],t7))){
/* csi.scm: 959  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t3,lf[342]);}
else{
t8=t3;
f_5041(2,t8,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 953  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[343]);}}
else{
t4=t3;
f_5041(2,t4,C_SCHEME_UNDEFINED);}}

/* k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 960  member* */
f_4625(t3,lf[337],((C_word*)((C_word*)t0)[3])[1]);}

/* k5339 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5344(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 961  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[336]);}}
else{
t2=((C_word*)t0)[3];
f_5044(2,t2,C_SCHEME_UNDEFINED);}}

/* k5342 in k5339 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 962  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 963  member* */
f_4625(t3,lf[335],((C_word*)((C_word*)t0)[3])[1]);}

/* k5327 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5332(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 964  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[334]);}}
else{
t2=((C_word*)t0)[3];
f_5047(2,t2,C_SCHEME_UNDEFINED);}}

/* k5330 in k5327 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 965  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[327]))(3,*((C_word*)lf[327]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 966  member* */
f_4625(t3,lf[333],((C_word*)((C_word*)t0)[3])[1]);}

/* k5306 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5308,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5311,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5311(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 967  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[332]);}}
else{
t2=((C_word*)t0)[3];
f_5050(2,t2,C_SCHEME_UNDEFINED);}}

/* k5309 in k5306 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 968  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[331]))(3,*((C_word*)lf[331]+1),t2,C_SCHEME_FALSE);}

/* k5312 in k5309 in k5306 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 969  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t2,lf[330]);}

/* k5315 in k5312 in k5309 in k5306 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 970  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),t2,C_SCHEME_FALSE);}

/* k5318 in k5315 in k5312 in k5309 in k5306 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 971  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[327]))(3,*((C_word*)lf[327]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5299,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 972  member* */
f_4625(t3,lf[326],((C_word*)((C_word*)t0)[2])[1]);}

/* k5297 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_5053(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 910  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[324]))(4,*((C_word*)lf[324]+1),t3,lf[325],lf[2]);}}

/* k4905 in k5297 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 911  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4911 in k4905 in k5297 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 912  load */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4935,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 913  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[323]);}}

/* k4933 in k4911 in k4905 in k5297 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[322]);
/* csi.scm: 913  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],t2);}

/* k4917 in k4911 in k4905 in k5297 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 914  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t2,t1,lf[321],lf[2]);}

/* k4920 in k4917 in k4911 in k4905 in k5297 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4928,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 915  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4926 in k4920 in k4917 in k4911 in k4905 in k5297 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 916  load */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5053(2,t2,C_SCHEME_UNDEFINED);}}

/* k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5058(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_5058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5058,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5071,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 976  repl */
((C_proc2)C_retrieve_symbol_proc(lf[297]))(2,*((C_word*)lf[297]+1),t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_member(t4,lf[298]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5083,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_5083(2,t7,t5);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[299]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[300]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[301]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[302]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[303]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[304]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t7=(C_word)C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=t6;
f_5083(2,t9,t8);}
else{
t7=(C_word)C_i_string_equal_p(lf[305],t4);
t8=(C_truep(t7)?t7:(C_word)C_i_string_equal_p(lf[306],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5112,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5136,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 984  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[142]+1)))(3,*((C_word*)lf[142]+1),t10,t11);}
else{
t9=(C_word)C_i_string_equal_p(lf[308],t4);
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(lf[309],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5152,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 987  evalstring */
f_4940(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_i_string_equal_p(lf[310],t4);
t12=(C_truep(t11)?t11:(C_word)C_i_string_equal_p(lf[311],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5172,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5182,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 990  evalstring */
f_4940(t13,t14,(C_word)C_a_i_list(&a,1,t15));}
else{
t13=(C_word)C_i_string_equal_p(lf[313],t4);
t14=(C_truep(t13)?t13:(C_word)C_i_string_equal_p(lf[314],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5208,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 993  evalstring */
f_4940(t15,t16,(C_word)C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[2])?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5218,a[2]=t6,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_equalp(lf[318],t15);
t18=(C_truep(t17)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5271,tmp=(C_word)a,a+=2,tmp):C_SCHEME_FALSE);
/* csi.scm: 997  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[320]))(5,*((C_word*)lf[320]+1),t16,t4,t18,C_SCHEME_FALSE);}}}}}}}}

/* f_5271 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5271,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5275,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 1001 pretty-print */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t3,t2,*((C_word*)lf[319]+1));}

/* k5273 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 1002 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,*((C_word*)lf[319]+1));}

/* k5276 in k5273 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 1003 eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5216 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5218,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[315],((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5229,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5239,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 1006 call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5083(2,t2,C_SCHEME_UNDEFINED);}}

/* a5238 in k5216 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5239r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5239r(t0,t1,t2);}}

static void C_ccall f_5239r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5250,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_5250(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_5250(t4,C_SCHEME_FALSE);}}

/* k5248 in a5238 in k5216 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_5250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 1008 exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],t2);}

/* a5228 in k5216 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5237,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 1006 command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[317]))(2,*((C_word*)lf[317]+1),t2);}

/* k5235 in a5228 in k5216 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
((C_proc3)C_retrieve_symbol_proc(lf[316]))(3,*((C_word*)lf[316]+1),((C_word*)t0)[2],t1);}

/* a5207 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5208r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5208r(t0,t1,t2);}}

static void C_ccall f_5208r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[312]+1),C_retrieve(lf[65]),t2);}

/* k5196 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5083(2,t4,t3);}

/* a5181 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5182r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5182r(t0,t1,t2);}}

static void C_ccall f_5182r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[312]+1),*((C_word*)lf[15]+1),t2);}

/* k5170 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5083(2,t4,t3);}

/* k5150 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5083(2,t4,t3);}

/* k5134 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[307],t4);
/* csi.scm: 984  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[2],t5);}

/* k5110 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5083(2,t4,t3);}

/* k5081 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5058(t3,((C_word*)t0)[2],t2);}

/* k5069 in doloop1425 in k5051 in k5048 in k5045 in k5042 in k5039 in k5036 in k5032 in k5029 in k5026 in k5023 in k5020 in k5017 in k5014 in k5011 in k5008 in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 977  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[145]+1));}

/* evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4940(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4940,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4944,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4944(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4987,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4944(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4987 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4987,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4947,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 918  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[296]))(3,*((C_word*)lf[296]+1),t2,((C_word*)t0)[2]);}

/* k4945 in k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 919  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,t1);}

/* k4952 in k4945 in k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4956(t5,((C_word*)t0)[2],t1);}

/* doloop1351 in k4952 in k4945 in k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4956,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4977,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4979,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[295]+1));}}

/* a4978 in doloop1351 in k4952 in k4945 in k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
/* csi.scm: 921  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t1,((C_word*)t0)[2]);}

/* k4975 in doloop1351 in k4952 in k4945 in k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 921  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4964 in doloop1351 in k4952 in k4945 in k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 919  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k4971 in k4964 in doloop1351 in k4952 in k4945 in k4942 in evalstring in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4956(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4860,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4866,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4866(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4866,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 906  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[294],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4893,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 907  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4891 in loop in collect-options in k4856 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in k4829 in ##csi#run in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4682(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4682,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4688,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4688(t6,t1,t2);}

/* loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4688,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[286]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[287]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[288]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[289]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4710,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[292]);
t8=t4;
f_4710(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4710(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4710(t6,C_SCHEME_FALSE);}}}}

/* k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4710,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 852  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4688(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4726,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4760,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 853  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[28]+1)))(4,*((C_word*)lf[28]+1),t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 857  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4688(t4,t2,t3);}}

/* k4765 in k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4758 in k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[291]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4724 in k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4726,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4799,tmp=(C_word)a,a+=2,tmp);
t4=f_4799(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4749,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 856  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[290],((C_word*)t0)[2]);}}

/* a4748 in k4724 in k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4749,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4737 in k4724 in k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 855  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4688(t4,t2,t3);}

/* k4741 in k4737 in k4724 in k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 855  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4724 in k4708 in loop in canonicalize-args in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static C_word C_fcall f_4799(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4625(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4625,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4631(t7,t1,t3);}

/* loop in member* in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4631,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4643,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4643(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4643,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 828  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4631(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 830  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4566r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4566r(t0,t1,t2,t3);}}

static void C_ccall f_4566r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4570(2,t5,*((C_word*)lf[283]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4570(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4568 in ##csi#deldups in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4575,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4575(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4568 in ##csi#deldups in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4575,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4591,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4604,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 821  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t6,t3,t4,((C_word*)t0)[2]);}}

/* k4602 in recur in k4568 in ##csi#deldups in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 821  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4575(t2,((C_word*)t0)[2],t1);}

/* k4589 in recur in k4568 in ##csi#deldups in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4591,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4357,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4389,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4389(t10,t1,C_fix(0));}

/* doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4389,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 789  justify */
t5=((C_word*)t0)[2];
f_4360(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4562 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 789  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 790  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4474(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4474(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4474,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 795  fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[281]+1)))(4,*((C_word*)lf[281]+1),t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 800  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4533 in doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4557,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 801  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4555 in k4533 in doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 801  justify */
t2=((C_word*)t0)[3];
f_4360(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4551 in k4533 in doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 801  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4536 in k4533 in doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4474(t4,((C_word*)t0)[2],t2,t3);}

/* k4491 in doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4511(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* doloop991 in k4491 in doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4511,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4521,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 799  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[280],((C_word*)t0)[2]);}}

/* k4519 in doloop991 in k4491 in doloop971 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4511(t3,((C_word*)t0)[2],t2);}

/* k4403 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 802  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k4406 in k4403 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4423(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* doloop1008 in k4406 in k4403 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4423(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4423,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 806  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4434 in doloop1008 in k4406 in k4403 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 808  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 809  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4437 in k4434 in doloop1008 in k4406 in k4403 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4423(t4,((C_word*)t0)[2],t2,t3);}

/* k4409 in k4406 in k4403 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 810  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4412 in k4409 in k4406 in k4403 in k4400 in k4397 in doloop949 in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4389(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4360,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4364,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 781  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k4362 in justify in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4380,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 784  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k4378 in k4362 in justify in ##csi#hexdump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 784  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4196r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4196r(t0,t1,t2,t3);}}

static void C_ccall f_4196r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4304,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4309,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len896929 */
t7=t6;
f_4309(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out897925 */
t9=t5;
f_4304(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body894903 */
t11=t4;
f_4198(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len896 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4309,NULL,2,t0,t1);}
/* def-out897925 */
t2=((C_word*)t0)[2];
f_4304(t2,t1,C_SCHEME_FALSE);}

/* def-out897 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4304(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4304,NULL,3,t0,t1,t2);}
/* body894903 */
t3=((C_word*)t0)[2];
f_4198(t3,t1,t2,*((C_word*)lf[145]+1));}

/* body894 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4198(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4198,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4201,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 763  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[275],lf[276],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4223,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 764  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[264]+1)))(3,*((C_word*)lf[264]+1),t5,((C_word*)t0)[2]);}}

/* k4221 in body894 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 764  bestlen */
t4=((C_word*)t0)[2];
f_4201(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 765  bestlen */
t4=((C_word*)t0)[2];
f_4201(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_anypointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 767  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[277]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_4266(t6,(C_word)C_i_assq(t5,C_retrieve2(lf[178],"bytevector-data")));}
else{
t5=t4;
f_4266(t5,C_SCHEME_FALSE);}}}}}

/* k4264 in k4221 in body894 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4266,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 770  bestlen */
t5=((C_word*)t0)[2];
f_4201(t5,t3,t4);}
else{
/* csi.scm: 771  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[275],lf[278],((C_word*)t0)[5]);}}

/* k4274 in k4264 in k4221 in body894 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 770  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k4245 in k4221 in body894 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 765  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k4228 in k4221 in body894 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 764  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* bestlen in body894 in ##csi#dump in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4201,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 762  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[274]+1)))(4,*((C_word*)lf[274]+1),t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4187,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4191,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 751  ##sys#check-symbol */
((C_proc5)C_retrieve_proc(*((C_word*)lf[272]+1)))(5,*((C_word*)lf[272]+1),t4,t2,lf[273],lf[271]);}

/* k4189 in set-describer! in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 752  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],C_retrieve2(lf[180],"describer-table"),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3368r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3368r(t0,t1,t2,t3);}}

static void C_ccall f_3368r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3372(2,t5,*((C_word*)lf[145]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3372(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[7]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4166,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 638  ##sys#block-address */
((C_proc3)C_retrieve_symbol_proc(lf[270]))(3,*((C_word*)lf[270]+1),t4,((C_word*)t0)[7]);}
else{
t4=t3;
f_3500(2,t4,C_SCHEME_UNDEFINED);}}

/* k4164 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 638  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[269],t1);}

/* k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[9]));
/* csi.scm: 641  fprintf */
t4=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[7],lf[191],((C_word*)t0)[9],t3,t3,t3);}
else{
switch(((C_word*)t0)[9]){
case C_SCHEME_TRUE:
/* csi.scm: 642  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[192]);
case C_SCHEME_FALSE:
/* csi.scm: 643  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[193]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[9]))){
/* csi.scm: 644  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[194]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[9]))){
/* csi.scm: 645  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[195]);}
else{
t3=C_retrieve(lf[46]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[9]);
if(C_truep(t4)){
/* csi.scm: 646  fprintf */
t5=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],lf[196]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 648  fprintf */
t6=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[7],lf[198],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9]);}
else{
t5=(C_word)C_slot(lf[199],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
/* csi.scm: 653  fprintf */
t7=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[7],lf[200]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 654  ##sys#number? */
((C_proc3)C_retrieve_symbol_proc(lf[268]))(3,*((C_word*)lf[268]+1),t7,((C_word*)t0)[9]);}}}}}}}}

/* k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3599,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 654  fprintf */
t2=((C_word*)t0)[10];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],lf[201],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[7]))){
/* csi.scm: 655  descseq */
t2=((C_word*)t0)[6];
f_3374(6,t2,((C_word*)t0)[9],lf[202],*((C_word*)lf[203]+1),((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
/* csi.scm: 656  descseq */
t2=((C_word*)t0)[6];
f_3374(6,t2,((C_word*)t0)[9],lf[204],*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 658  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[7]))){
/* csi.scm: 675  descseq */
t2=((C_word*)t0)[6];
f_3374(6,t2,((C_word*)t0)[9],lf[217],((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csi.scm: 676  fprintf */
t4=((C_word*)t0)[10];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[9],((C_word*)t0)[8],lf[218],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[7]))){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[222],C_retrieve(lf[6])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[7],t4);
t6=t3;
f_3767(t6,(C_word)C_eqp(C_retrieve(lf[223]),t5));}
else{
t4=t3;
f_3767(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3767(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3807,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 686  port? */
((C_proc3)C_retrieve_symbol_proc(lf[267]))(3,*((C_word*)lf[267]+1),t2,((C_word*)t0)[7]);}}}}}}}}

/* k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3807,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_truep(t2)?lf[224]:lf[225]);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3826,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 692  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t6,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(lf[222],C_retrieve(lf[6])))){
/* csi.scm: 693  instance? */
((C_proc3)C_retrieve_symbol_proc(lf[266]))(3,*((C_word*)lf[266]+1),t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3835(2,t3,C_SCHEME_FALSE);}}}

/* k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3835,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 694  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[219]))(4,*((C_word*)lf[219]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 695  ##sys#locative? */
((C_proc3)C_retrieve_symbol_proc(lf[265]))(3,*((C_word*)lf[265]+1),t2,((C_word*)t0)[5]);}}

/* k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3844,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 697  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 710  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 711  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[264]+1)))(3,*((C_word*)lf[264]+1),t2,((C_word*)t0)[6]);}}}

/* k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 713  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],lf[241],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 716  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[244]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[248]:lf[249]);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* csi.scm: 719  fprintf */
t7=((C_word*)t0)[3];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[4],lf[250],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[251]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* csi.scm: 726  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[256],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[261]))){
/* csi.scm: 736  provided? */
((C_proc3)C_retrieve_symbol_proc(lf[262]))(3,*((C_word*)lf[262]+1),t2,lf[263]);}
else{
t3=t2;
f_4072(2,t3,C_SCHEME_FALSE);}}}}}}

/* k4070 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 737  unveil */
((C_proc4)C_retrieve_symbol_proc(lf[257]))(4,*((C_word*)lf[257]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 740  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t3,C_retrieve2(lf[180],"describer-table"),t2);}
else{
/* csi.scm: 747  fprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],lf[260]);}}}

/* k4085 in k4070 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve2(lf[178],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[57]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 745  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[259],t4);}}}

/* k4124 in k4085 in k4070 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 746  descseq */
t2=((C_word*)t0)[3];
f_3374(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(1));}

/* k4113 in k4085 in k4070 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 743  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[2],t1,t2);}

/* k4109 in k4085 in k4070 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4094 in k4085 in k4070 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4094,3,t0,t1,t2);}
/* g864865866 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4003 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a4009 in k4003 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4010,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4014,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 729  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[255],t2);}

/* k4012 in a4009 in k4003 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4023(t6,((C_word*)t0)[2],t2);}

/* loop in k4012 in a4009 in k4003 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_4023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4023,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4033,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 732  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[254]+1)))(3,*((C_word*)lf[254]+1),t4,t2);}}

/* k4056 in loop in k4012 in a4009 in k4003 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 733  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[253]+1)))(3,*((C_word*)lf[253]+1),t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_4033(2,t3,C_SCHEME_UNDEFINED);}}

/* k4048 in k4056 in loop in k4012 in a4009 in k4003 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 733  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[252],t1,t2);}

/* k4031 in loop in k4012 in a4009 in k4003 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 734  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4023(t3,((C_word*)t0)[2],t2);}

/* k3967 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 721  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[247],t3);}

/* k3970 in k3967 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 722  hash-table-walk */
((C_proc4)C_retrieve_symbol_proc(lf[246]))(4,*((C_word*)lf[246]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3976 in k3970 in k3967 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3977,4,t0,t1,t2,t3);}
/* csi.scm: 724  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[245],t2,t3);}

/* k3955 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 716  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[242],t1);}

/* k3942 in k3936 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 714  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k3930 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 710  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[238],t1);}

/* k3849 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3851,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3862,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3862(t5,lf[228]);
case C_fix(1):
t5=t4;
f_3862(t5,lf[229]);
case C_fix(2):
t5=t4;
f_3862(t5,lf[230]);
case C_fix(3):
t5=t4;
f_3862(t5,lf[231]);
case C_fix(4):
t5=t4;
f_3862(t5,lf[232]);
case C_fix(5):
t5=t4;
f_3862(t5,lf[233]);
case C_fix(6):
t5=t4;
f_3862(t5,lf[234]);
case C_fix(7):
t5=t4;
f_3862(t5,lf[235]);
case C_fix(8):
t5=t4;
f_3862(t5,lf[236]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3862(t6,(C_truep(t5)?lf[237]:C_SCHEME_UNDEFINED));}}

/* k3860 in k3849 in k3842 in k3833 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 696  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[227],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3824 in k3805 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 687  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[226],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3765 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3767,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 682  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[219]))(4,*((C_word*)lf[219]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3781,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 684  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t3,((C_word*)t0)[5],C_fix(0));}}

/* k3779 in k3765 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 684  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[220],t1);}

/* k3775 in k3765 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 683  descseq */
t2=((C_word*)t0)[3];
f_3374(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(1));}

/* k3721 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3629(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 658  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[215],((C_word*)t0)[2]);}}

/* k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3703(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3703(t4,C_SCHEME_FALSE);}}

/* k3701 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 660  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[214],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3632(2,t2,C_SCHEME_UNDEFINED);}}

/* k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 662  ##sys#interned-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),t3,((C_word*)t0)[5]);}

/* k3698 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(C_truep(t1)?lf[209]:lf[210]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3697,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 663  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t3,((C_word*)t0)[2]);}

/* k3695 in k3698 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 661  fprintf */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[211],((C_word*)t0)[2],t1);}

/* k3633 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3635,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[4];
f_3503(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3647,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 666  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),t3,lf[208],((C_word*)t0)[3]);}}

/* k3645 in k3633 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3647,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3652(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop786 in k3645 in k3633 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3652,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* csi.scm: 669  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[3],lf[207],t4);}}

/* k3660 in doloop786 in k3645 in k3633 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 670  ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),t2,C_fix(1000),t3);}

/* a3676 in k3660 in doloop786 in k3645 in k3633 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 673  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t1,t2,((C_word*)t0)[2]);}

/* k3663 in k3660 in doloop786 in k3645 in k3633 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 674  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}

/* k3666 in k3663 in k3660 in doloop786 in k3645 in k3633 in k3630 in k3627 in k3597 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3652(t3,((C_word*)t0)[2],t2);}

/* k3567 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(65536)))){
/* csi.scm: 650  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[197],t2);}
else{
t4=t3;
f_3575(2,t4,C_SCHEME_UNDEFINED);}}

/* k3573 in k3567 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 651  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[145]+1));}

/* k3501 in k3498 in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3374,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3497,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 618  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 619  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[190],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3381(2,t4,C_SCHEME_UNDEFINED);}}

/* k3379 in k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3386(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3379 in k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3386,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 623  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[185],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3409,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 625  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3407 in loop1 in k3379 in k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3418(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3407 in loop1 in k3379 in k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3418,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 628  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[189],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 635  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3480 in loop2 in k3407 in loop1 in k3379 in k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 635  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3418(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 636  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3418(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3426 in loop2 in k3407 in loop1 in k3379 in k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[186]:lf[187]);
/* csi.scm: 630  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[188],t3,t5);}
else{
/* csi.scm: 633  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}}

/* k3429 in k3426 in loop2 in k3407 in loop1 in k3379 in k3495 in descseq in k3370 in ##csi#describe in k3364 in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 634  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3386(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3172r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3172r(t0,t1,t2);}}

static void C_ccall f_3172r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3180,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_3180(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 547  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3182,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 547  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 549  gc */
((C_proc2)C_retrieve_symbol_proc(lf[177]))(2,*((C_word*)lf[177]+1),t2);}

/* k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 550  ##sys#symbol-table-info */
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t2);}

/* k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 551  memory-statistics */
((C_proc2)C_retrieve_symbol_proc(lf[175]))(2,*((C_word*)lf[175]+1),t2);}

/* k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3194,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 553  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[174]);}

/* k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3344,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3348,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3352,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[173]),C_retrieve(lf[6]));}

/* k3350 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 561  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[172]+1));}

/* k3346 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 561  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k3342 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3310 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3311,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3315,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 556  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t3,lf[171]);}

/* k3313 in a3310 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3319 in k3313 in a3310 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3320,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3328,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 559  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[170]+1)))(4,*((C_word*)lf[170]+1),t3,t6,C_make_character(32));}

/* k3326 in a3319 in k3313 in a3310 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 559  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[169],((C_word*)t0)[2],t1);}

/* k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 573  machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[168]))(2,*((C_word*)lf[168]+1),t3);}

/* k3238 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[157]:lf[158]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 575  software-type */
((C_proc2)C_retrieve_symbol_proc(lf[167]))(2,*((C_word*)lf[167]+1),t4);}

/* k3246 in k3238 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 576  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[166]))(2,*((C_word*)lf[166]+1),t2);}

/* k3250 in k3246 in k3238 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 577  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[165]))(2,*((C_word*)lf[165]+1),t2);}

/* k3254 in k3250 in k3246 in k3238 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 579  shorten */
f_3194(t2,t3);}

/* k3258 in k3254 in k3250 in k3246 in k3238 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3264,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 580  shorten */
f_3194(t2,t3);}

/* k3262 in k3258 in k3254 in k3250 in k3246 in k3238 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[159]:lf[160]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[161]:lf[162]);
/* csi.scm: 562  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[163],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[164]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k3213 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 587  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k3216 in k3213 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 588  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[156]);}
else{
t3=t2;
f_3221(2,t3,C_SCHEME_UNDEFINED);}}

/* k3219 in k3216 in k3213 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 589  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[155]);}
else{
t3=t2;
f_3224(2,t3,C_SCHEME_UNDEFINED);}}

/* k3222 in k3219 in k3216 in k3213 in k3210 in k3207 in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_3194(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3194,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 552  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[154]+1)))(3,*((C_word*)lf[154]+1),t3,t4);}

/* k3200 in shorten in k3190 in k3187 in k3184 in a3181 in k3178 in ##csi#report in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* do-unbreak-all in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3055,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[97],"broken-procedures"));}

/* a3054 in do-unbreak-all in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3055,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k3047 in do-unbreak-all in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[97] /* broken-procedures */ =C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[46]));}

/* ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2754,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2759,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 429  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t4,C_retrieve(lf[69]));}

/* k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! trace-indent-level ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 430  trace-indent */
f_2703(t3);}

/* k2760 in k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 431  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2]);}

/* k2763 in k2760 in k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 432  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[149]);}

/* k2766 in k2763 in k2760 in k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2779,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2778 in k2766 in k2763 in k2760 in k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2779,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2783,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 435  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t3,t2);}

/* k2781 in a2778 in k2766 in k2763 in k2760 in k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[145]+1));}

/* k2769 in k2766 in k2763 in k2760 in k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 438  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in ##csi#traced-procedure-exit in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 439  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[146]+1)))(2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2731,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2735,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 421  trace-indent */
f_2703(t4);}

/* k2733 in ##csi#traced-procedure-entry in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 422  add1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t2,C_retrieve(lf[69]));}

/* k2737 in k2733 in ##csi#traced-procedure-entry in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2739,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! trace-indent-level ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 423  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t3,t4);}

/* k2740 in k2737 in k2733 in ##csi#traced-procedure-entry in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 424  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k2743 in k2740 in k2737 in k2733 in ##csi#traced-procedure-entry in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 425  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[146]+1)))(2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* ##csi#trace-indent in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_2703(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2703,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2707,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[145]+1));}

/* k2705 in ##csi#trace-indent in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2707,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2712(t5,((C_word*)t0)[2],C_retrieve(lf[69]));}

/* doloop469 in k2705 in ##csi#trace-indent in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2712,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[145]+1));}}

/* k2720 in doloop469 in k2705 in ##csi#trace-indent in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 415  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k2727 in k2720 in doloop469 in k2705 in ##csi#trace-indent in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2712(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2662,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2668,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2668(t8,t1,t3);}

/* loop in ##csi#del in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_2668(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2668,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 404  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2682 in loop in ##csi#del in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 406  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2668(t4,t2,t3);}}

/* k2692 in k2682 in loop in ##csi#del in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* resolve-var in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2648,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2656,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 394  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[142]+1)))(3,*((C_word*)lf[142]+1),t3,t2);}

/* k2654 in resolve-var in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2660,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 394  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[141]))(2,*((C_word*)lf[141]+1),t2);}

/* k2658 in k2654 in resolve-var in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 394  ##sys#strip-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2098,3,t0,t1,t2);}
t3=C_set_block_item(lf[69] /* trace-indent-level */,0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 269  exit */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_2115(t6,(C_word)C_eqp(lf[140],t5));}
else{
t5=t4;
f_2115(t5,C_SCHEME_FALSE);}}}

/* k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_2115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2115,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 273  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t3,C_retrieve2(lf[54],"command-table"),t2);}
else{
t4=t3;
f_2121(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2628 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2629r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2629r(t0,t1,t2);}}

static void C_ccall f_2629r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2633,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 390  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2631 in a2628 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2622 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
/* csi.scm: 389  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[71]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 280  read */
t4=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[73]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 284  read */
t5=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[74]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 289  read */
t6=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[76]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 293  read */
t7=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 297  read */
t8=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[79]);
if(C_truep(t7)){
/* csi.scm: 302  report */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[81]);
if(C_truep(t8)){
/* csi.scm: 303  exit */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[82]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2262,a[2]=t10,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 305  read-line */
t12=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=t11,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 309  read-line */
t13=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 313  read */
t13=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[93]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2362,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2366,a[2]=t14,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 317  read-line */
t16=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[104]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2383,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2387,a[2]=t15,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 318  read-line */
t17=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[108]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2408,a[2]=t16,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 319  read-line */
t18=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[113]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2425,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2429,a[2]=t17,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 320  read-line */
t19=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[115]);
if(C_truep(t16)){
/* csi.scm: 321  do-unbreak-all */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[117]);
if(C_truep(t17)){
t18=C_set_block_item(lf[118] /* break-in-thread */,0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[119]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=t19,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 325  read */
t21=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[120]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2468,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[94],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2491,a[2]=t20,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[122]+1),C_retrieve2(lf[94],"traced-procedures"));}
else{
t21=t20;
f_2468(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[125]))){
t21=C_retrieve(lf[125]);
t22=C_set_block_item(lf[125] /* last-breakpoint */,0,C_SCHEME_FALSE);
/* csi.scm: 335  ##sys#break-resume */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),((C_word*)t0)[15],t21);}
else{
/* csi.scm: 336  display */
t21=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[127]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[128]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[129]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[129]));
/* csi.scm: 339  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[130]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 342  read */
t24=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[132]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 346  read-line */
t25=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[134]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 351  display */
t26=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[137]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 386  printf */
t26=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[138],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2607 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2583 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2593,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 377  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,t3,C_retrieve2(lf[54],"command-table"));}

/* a2592 in k2583 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2593,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 381  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,C_make_character(32),t4);}
else{
/* csi.scm: 382  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,lf[135],t2);}}

/* k2586 in k2583 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2564 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 347  system */
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),t2,t1);}

/* k2567 in k2564 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2572,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 348  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t2,t3);}

/* k2570 in k2567 in k2564 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2533 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 343  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2536 in k2533 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[131],t4);
/* csi.scm: 344  eval */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k2543 in k2536 in k2533 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 344  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2517 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 340  describe */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],C_retrieve(lf[129]));}

/* k2489 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 328  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[123],t1);}

/* k2466 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2468,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[97],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[122]+1),C_retrieve2(lf[97],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2479 in k2466 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 330  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[121],t1);}

/* k2457 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 325  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2453 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[118]+1 /* (set! break-in-thread ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2427 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 320  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2423 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2419 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3016,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a3015 in k2419 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3020,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 506  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k3018 in a3015 in k2419 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3020,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[97],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 511  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t5,t2,C_retrieve2(lf[97],"broken-procedures"),*((C_word*)lf[106]+1));}
else{
/* csi.scm: 508  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[114],t1);}}

/* k3037 in k3018 in a3015 in k2419 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[97] /* (set! broken-procedures ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2406 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 319  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2402 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2935,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[97],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2948,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2947 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2948,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2952,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 485  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2950 in a2947 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2997,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 488  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t4,lf[112],t1);}
else{
t4=t3;
f_2958(t4,C_SCHEME_UNDEFINED);}}

/* k2995 in k2950 in a2947 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 490  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t4,((C_word*)t0)[4],C_retrieve2(lf[94],"traced-procedures"),*((C_word*)lf[106]+1));}

/* k3002 in k2995 in k2950 in a2947 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t1);
t3=((C_word*)t0)[2];
f_2958(t3,t2);}

/* k2956 in k2950 in a2947 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_2958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2958,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[97],"broken-procedures"));
t5=C_mutate(&lf[97] /* (set! broken-procedures ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 492  ##sys#error */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[111],((C_word*)t0)[3]);}}

/* a2978 in k2956 in k2950 in a2947 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2979r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2979r(t0,t1,t2);}}

static void C_ccall f_2979r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2983,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 498  ##sys#break-entry */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,((C_word*)t0)[2],t2);}

/* k2981 in a2978 in k2956 in k2950 in a2947 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2934 in k2398 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2935,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[109]));
/* csi.scm: 482  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t1,t3);}

/* k2385 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 318  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2381 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2377 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2894,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2893 in k2377 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2894,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2898,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 471  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2896 in a2893 in k2377 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 476  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t5,t2,C_retrieve2(lf[94],"traced-procedures"),*((C_word*)lf[106]+1));}
else{
/* csi.scm: 473  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[107],t1);}}

/* k2915 in k2896 in a2893 in k2377 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2364 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 317  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2360 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2358,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2800,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[94],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2813,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2812 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2813,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2817,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 447  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2815 in a2812 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures")))){
/* csi.scm: 449  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[96],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[97],"broken-procedures")))){
/* csi.scm: 451  ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[98]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[94],"traced-procedures"));
t5=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2856,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 454  ##sys#error */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[101],t1);}}}}

/* a2855 in k2815 in a2812 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2856r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2856r(t0,t1,t2);}}

static void C_ccall f_2856r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2860,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 460  traced-procedure-entry */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,((C_word*)t0)[2],t2);}

/* k2858 in a2855 in k2815 in a2812 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 461  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2870 in k2858 in a2855 in k2815 in a2812 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2871r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2871r(t0,t1,t2);}}

static void C_ccall f_2871r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2875,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 463  traced-procedure-exit */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t3,((C_word*)t0)[2],t2);}

/* k2873 in a2870 in k2858 in a2855 in k2815 in a2812 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2864 in k2858 in a2855 in k2815 in a2812 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2799 in k2356 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2800,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 444  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t1,t3);}

/* k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2310,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2337 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2338r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2338r(t0,t1,t2);}}

static void C_ccall f_2338r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2342,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 315  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2340 in a2337 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2309 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2314,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[92]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2312 in a2309 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2325,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2324 in k2312 in a2309 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2325r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2325r(t0,t1,t2);}}

static void C_ccall f_2325r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2329,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2336,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[91]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2334 in a2324 in k2312 in a2309 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),((C_word*)t0)[2],t1);}

/* k2327 in a2324 in k2312 in a2309 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2318 in k2312 in a2309 in k2303 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2319,2,t0,t1);}
/* csi.scm: 314  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2294 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 309  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2269 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2278 in k2269 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2279,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily283 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[88],t3);}

/* a2284 in a2278 in k2269 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2285,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 310  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2287 in a2284 in a2278 in k2269 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 310  print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[86]+1)))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],lf[87]);}

/* k2272 in k2269 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2260 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 305  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2250 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[84]),t1);}

/* k2253 in k2250 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2211 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2216,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 298  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2214 in k2211 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2219,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 299  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2217 in k2214 in k2211 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2222,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 300  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2220 in k2217 in k2214 in k2211 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 301  dump */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2196 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 294  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2199 in k2196 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 295  dump */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),((C_word*)t0)[2],t1);}

/* k2181 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 290  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2184 in k2181 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 291  describe */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],t1);}

/* k2163 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 285  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2166 in k2163 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 286  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2169 in k2166 in k2163 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2140 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2152,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 281  expand */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2154 in k2140 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 281  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k2150 in k2140 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 281  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2143 in k2140 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2125 in k2119 in k2113 in ##sys#repl-eval-hook in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* toplevel-command in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2057r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2057r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2061,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2061(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2061(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2059 in toplevel-command in k2053 in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[4],lf[55]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[55]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* csi.scm: 250  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[2],C_retrieve2(lf[54],"command-table"),((C_word*)t0)[4],t4);}

/* ##sys#read-prompt-hook in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2048,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 243  tty-input? */
((C_proc2)C_retrieve_symbol_proc(lf[49]))(2,*((C_word*)lf[49]+1),t2);}

/* k2046 in ##sys#read-prompt-hook in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 243  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k2024 in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 236  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t1,*((C_word*)lf[51]+1));}}

/* ##csi#history-ref in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2001,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[25])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[43]),t3));}
else{
/* csi.scm: 228  ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[48],t2);}}

/* ##csi#history-add in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1962,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[46]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[43]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1972,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[25]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1986,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 219  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[43]),t8);}
else{
t7=t6;
f_1972(t7,C_SCHEME_UNDEFINED);}}

/* k1984 in ##csi#history-add in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1972(t3,t2);}

/* k1970 in ##csi#history-add in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_1972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[43]),C_retrieve(lf[25]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[25]),C_fix(1));
t4=C_mutate((C_word*)lf[25]+1 /* (set! history-count ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1856,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 192  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[42]);}

/* k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=(C_word)C_eqp(t3,C_make_character(92));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,C_make_character(47)));
if(C_truep(t5)){
/* csi.scm: 194  addext */
f_1808(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t6=((C_word*)t0)[5];
t7=(C_word)C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1835,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=f_1835(t8,C_fix(0));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=((C_word*)t0)[2];
t12=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t13=(C_truep(t11)?(C_word)C_i_foreign_block_argumentp(t11):C_SCHEME_FALSE);
t14=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t15=(C_word)stub128(t12,t13,t14);
/* ##sys#peek-nonnull-c-string */
t16=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t10,t15,C_fix(0));}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 198  addext */
f_1808(t10,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1899 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 200  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,lf[40],((C_word*)t0)[2]);}}

/* k1905 in k1899 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 201  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2],lf[39]);}

/* k1912 in k1905 in k1899 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1916(t5,((C_word*)t0)[2],t1);}

/* loop in k1912 in k1905 in k1899 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_1916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1916,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 203  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1941 in loop in k1912 in k1905 in k1899 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 203  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1924 in loop in k1912 in k1905 in k1899 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 204  addext */
f_1808(t2,t1);}

/* k1927 in k1924 in loop in k1912 in k1905 in k1899 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 205  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1916(t3,((C_word*)t0)[4],t2);}}

/* k1882 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 197  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1896 in k1882 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,lf[36],((C_word*)t0)[2]);}

/* k1892 in k1882 in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  addext */
f_1808(((C_word*)t0)[2],t1);}

/* loop in k1858 in ##csi#lookup-script-file in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static C_word C_fcall f_1835(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(47)));
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* addext in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_1808(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1808,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1815,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 181  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t3,t2);}

/* k1813 in addext in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 183  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,((C_word*)t0)[2],lf[34]);}}

/* k1816 in k1813 in addext in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1824,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 184  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k1822 in k1816 in k1813 in addext in k1787 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1758,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1762,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 166  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t3,t4);}

/* k1760 in ##csi#chop-separator in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1771,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))){
t4=(C_word)C_eqp(t2,C_make_character(92));
t5=t3;
f_1771(t5,(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(47))));}
else{
t4=t3;
f_1771(t4,C_SCHEME_FALSE);}}

/* k1769 in k1760 in ##csi#chop-separator in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_fcall f_1771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 169  substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##sys#sharp-number-hook in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1732,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1744,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 155  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* k1742 in ##sys#sharp-number-hook in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##sys#user-read-hook in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1699,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[25]),C_fix(1));
/* csi.scm: 150  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t7);}
else{
/* csi.scm: 151  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1718 in ##sys#user-read-hook in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##csi#print-banner in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 120  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[20]+1)))(2,*((C_word*)lf[20]+1),t2);}

/* k1685 in ##csi#print-banner in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 138  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,lf[19]);}

/* k1688 in k1685 in ##csi#print-banner in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 139  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,C_SCHEME_TRUE);}

/* k1695 in k1688 in k1685 in ##csi#print-banner in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 139  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[15]+1)))(5,*((C_word*)lf[15]+1),((C_word*)t0)[2],lf[16],t1,lf[17]);}

/* ##csi#print-usage in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 73   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[13]);}

/* k1657 in ##csi#print-usage in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
/* csi.scm: 93   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t3,t6);}

/* k1667 in k1657 in ##csi#print-usage in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 93   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k1660 in k1657 in ##csi#print-usage in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1625 in k1622 in k1619 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 98   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[438] = {
{"toplevel:csi_scm",(void*)C_toplevel},
{"f_1621:csi_scm",(void*)f_1621},
{"f_1624:csi_scm",(void*)f_1624},
{"f_1627:csi_scm",(void*)f_1627},
{"f_1630:csi_scm",(void*)f_1630},
{"f_1633:csi_scm",(void*)f_1633},
{"f_1636:csi_scm",(void*)f_1636},
{"f_1639:csi_scm",(void*)f_1639},
{"f_1642:csi_scm",(void*)f_1642},
{"f_1645:csi_scm",(void*)f_1645},
{"f_1789:csi_scm",(void*)f_1789},
{"f_5645:csi_scm",(void*)f_5645},
{"f_2026:csi_scm",(void*)f_2026},
{"f_2055:csi_scm",(void*)f_2055},
{"f_3366:csi_scm",(void*)f_3366},
{"f_5637:csi_scm",(void*)f_5637},
{"f_5643:csi_scm",(void*)f_5643},
{"f_5640:csi_scm",(void*)f_5640},
{"f_4827:csi_scm",(void*)f_4827},
{"f_5631:csi_scm",(void*)f_5631},
{"f_3073:csi_scm",(void*)f_3073},
{"f_3103:csi_scm",(void*)f_3103},
{"f_3121:csi_scm",(void*)f_3121},
{"f_3160:csi_scm",(void*)f_3160},
{"f_3166:csi_scm",(void*)f_3166},
{"f_3127:csi_scm",(void*)f_3127},
{"f_3135:csi_scm",(void*)f_3135},
{"f_3137:csi_scm",(void*)f_3137},
{"f_3154:csi_scm",(void*)f_3154},
{"f_3109:csi_scm",(void*)f_3109},
{"f_3115:csi_scm",(void*)f_3115},
{"f_3101:csi_scm",(void*)f_3101},
{"f_3098:csi_scm",(void*)f_3098},
{"f_3078:csi_scm",(void*)f_3078},
{"f_3088:csi_scm",(void*)f_3088},
{"f_3091:csi_scm",(void*)f_3091},
{"f_4831:csi_scm",(void*)f_4831},
{"f_5627:csi_scm",(void*)f_5627},
{"f_4834:csi_scm",(void*)f_4834},
{"f_4837:csi_scm",(void*)f_4837},
{"f_4840:csi_scm",(void*)f_4840},
{"f_5623:csi_scm",(void*)f_5623},
{"f_5610:csi_scm",(void*)f_5610},
{"f_5570:csi_scm",(void*)f_5570},
{"f_5520:csi_scm",(void*)f_5520},
{"f_5523:csi_scm",(void*)f_5523},
{"f_5526:csi_scm",(void*)f_5526},
{"f_5529:csi_scm",(void*)f_5529},
{"f_5538:csi_scm",(void*)f_5538},
{"f_4843:csi_scm",(void*)f_4843},
{"f_4846:csi_scm",(void*)f_4846},
{"f_5514:csi_scm",(void*)f_5514},
{"f_4849:csi_scm",(void*)f_4849},
{"f_4852:csi_scm",(void*)f_4852},
{"f_5505:csi_scm",(void*)f_5505},
{"f_5501:csi_scm",(void*)f_5501},
{"f_4858:csi_scm",(void*)f_4858},
{"f_5010:csi_scm",(void*)f_5010},
{"f_5490:csi_scm",(void*)f_5490},
{"f_5493:csi_scm",(void*)f_5493},
{"f_5013:csi_scm",(void*)f_5013},
{"f_5481:csi_scm",(void*)f_5481},
{"f_5484:csi_scm",(void*)f_5484},
{"f_5016:csi_scm",(void*)f_5016},
{"f_5478:csi_scm",(void*)f_5478},
{"f_5471:csi_scm",(void*)f_5471},
{"f_5019:csi_scm",(void*)f_5019},
{"f_5458:csi_scm",(void*)f_5458},
{"f_5461:csi_scm",(void*)f_5461},
{"f_5022:csi_scm",(void*)f_5022},
{"f_5452:csi_scm",(void*)f_5452},
{"f_5025:csi_scm",(void*)f_5025},
{"f_5437:csi_scm",(void*)f_5437},
{"f_5440:csi_scm",(void*)f_5440},
{"f_5443:csi_scm",(void*)f_5443},
{"f_5028:csi_scm",(void*)f_5028},
{"f_5434:csi_scm",(void*)f_5434},
{"f_5031:csi_scm",(void*)f_5031},
{"f_5430:csi_scm",(void*)f_5430},
{"f_5034:csi_scm",(void*)f_5034},
{"f_5426:csi_scm",(void*)f_5426},
{"f_5414:csi_scm",(void*)f_5414},
{"f_5422:csi_scm",(void*)f_5422},
{"f_5418:csi_scm",(void*)f_5418},
{"f_5410:csi_scm",(void*)f_5410},
{"f_5038:csi_scm",(void*)f_5038},
{"f_5041:csi_scm",(void*)f_5041},
{"f_5341:csi_scm",(void*)f_5341},
{"f_5344:csi_scm",(void*)f_5344},
{"f_5044:csi_scm",(void*)f_5044},
{"f_5329:csi_scm",(void*)f_5329},
{"f_5332:csi_scm",(void*)f_5332},
{"f_5047:csi_scm",(void*)f_5047},
{"f_5308:csi_scm",(void*)f_5308},
{"f_5311:csi_scm",(void*)f_5311},
{"f_5314:csi_scm",(void*)f_5314},
{"f_5317:csi_scm",(void*)f_5317},
{"f_5320:csi_scm",(void*)f_5320},
{"f_5050:csi_scm",(void*)f_5050},
{"f_5299:csi_scm",(void*)f_5299},
{"f_4907:csi_scm",(void*)f_4907},
{"f_4913:csi_scm",(void*)f_4913},
{"f_4935:csi_scm",(void*)f_4935},
{"f_4919:csi_scm",(void*)f_4919},
{"f_4922:csi_scm",(void*)f_4922},
{"f_4928:csi_scm",(void*)f_4928},
{"f_5053:csi_scm",(void*)f_5053},
{"f_5058:csi_scm",(void*)f_5058},
{"f_5271:csi_scm",(void*)f_5271},
{"f_5275:csi_scm",(void*)f_5275},
{"f_5278:csi_scm",(void*)f_5278},
{"f_5218:csi_scm",(void*)f_5218},
{"f_5239:csi_scm",(void*)f_5239},
{"f_5250:csi_scm",(void*)f_5250},
{"f_5229:csi_scm",(void*)f_5229},
{"f_5237:csi_scm",(void*)f_5237},
{"f_5208:csi_scm",(void*)f_5208},
{"f_5198:csi_scm",(void*)f_5198},
{"f_5182:csi_scm",(void*)f_5182},
{"f_5172:csi_scm",(void*)f_5172},
{"f_5152:csi_scm",(void*)f_5152},
{"f_5136:csi_scm",(void*)f_5136},
{"f_5112:csi_scm",(void*)f_5112},
{"f_5083:csi_scm",(void*)f_5083},
{"f_5071:csi_scm",(void*)f_5071},
{"f_4940:csi_scm",(void*)f_4940},
{"f_4987:csi_scm",(void*)f_4987},
{"f_4944:csi_scm",(void*)f_4944},
{"f_4947:csi_scm",(void*)f_4947},
{"f_4954:csi_scm",(void*)f_4954},
{"f_4956:csi_scm",(void*)f_4956},
{"f_4979:csi_scm",(void*)f_4979},
{"f_4977:csi_scm",(void*)f_4977},
{"f_4966:csi_scm",(void*)f_4966},
{"f_4973:csi_scm",(void*)f_4973},
{"f_4860:csi_scm",(void*)f_4860},
{"f_4866:csi_scm",(void*)f_4866},
{"f_4893:csi_scm",(void*)f_4893},
{"f_4682:csi_scm",(void*)f_4682},
{"f_4688:csi_scm",(void*)f_4688},
{"f_4710:csi_scm",(void*)f_4710},
{"f_4767:csi_scm",(void*)f_4767},
{"f_4760:csi_scm",(void*)f_4760},
{"f_4726:csi_scm",(void*)f_4726},
{"f_4749:csi_scm",(void*)f_4749},
{"f_4739:csi_scm",(void*)f_4739},
{"f_4743:csi_scm",(void*)f_4743},
{"f_4799:csi_scm",(void*)f_4799},
{"f_4625:csi_scm",(void*)f_4625},
{"f_4631:csi_scm",(void*)f_4631},
{"f_4643:csi_scm",(void*)f_4643},
{"f_4566:csi_scm",(void*)f_4566},
{"f_4570:csi_scm",(void*)f_4570},
{"f_4575:csi_scm",(void*)f_4575},
{"f_4604:csi_scm",(void*)f_4604},
{"f_4591:csi_scm",(void*)f_4591},
{"f_4357:csi_scm",(void*)f_4357},
{"f_4389:csi_scm",(void*)f_4389},
{"f_4564:csi_scm",(void*)f_4564},
{"f_4399:csi_scm",(void*)f_4399},
{"f_4402:csi_scm",(void*)f_4402},
{"f_4474:csi_scm",(void*)f_4474},
{"f_4535:csi_scm",(void*)f_4535},
{"f_4557:csi_scm",(void*)f_4557},
{"f_4553:csi_scm",(void*)f_4553},
{"f_4538:csi_scm",(void*)f_4538},
{"f_4493:csi_scm",(void*)f_4493},
{"f_4511:csi_scm",(void*)f_4511},
{"f_4521:csi_scm",(void*)f_4521},
{"f_4405:csi_scm",(void*)f_4405},
{"f_4408:csi_scm",(void*)f_4408},
{"f_4423:csi_scm",(void*)f_4423},
{"f_4436:csi_scm",(void*)f_4436},
{"f_4439:csi_scm",(void*)f_4439},
{"f_4411:csi_scm",(void*)f_4411},
{"f_4414:csi_scm",(void*)f_4414},
{"f_4360:csi_scm",(void*)f_4360},
{"f_4364:csi_scm",(void*)f_4364},
{"f_4380:csi_scm",(void*)f_4380},
{"f_4196:csi_scm",(void*)f_4196},
{"f_4309:csi_scm",(void*)f_4309},
{"f_4304:csi_scm",(void*)f_4304},
{"f_4198:csi_scm",(void*)f_4198},
{"f_4223:csi_scm",(void*)f_4223},
{"f_4266:csi_scm",(void*)f_4266},
{"f_4276:csi_scm",(void*)f_4276},
{"f_4247:csi_scm",(void*)f_4247},
{"f_4230:csi_scm",(void*)f_4230},
{"f_4201:csi_scm",(void*)f_4201},
{"f_4187:csi_scm",(void*)f_4187},
{"f_4191:csi_scm",(void*)f_4191},
{"f_3368:csi_scm",(void*)f_3368},
{"f_3372:csi_scm",(void*)f_3372},
{"f_4166:csi_scm",(void*)f_4166},
{"f_3500:csi_scm",(void*)f_3500},
{"f_3599:csi_scm",(void*)f_3599},
{"f_3807:csi_scm",(void*)f_3807},
{"f_3835:csi_scm",(void*)f_3835},
{"f_3844:csi_scm",(void*)f_3844},
{"f_3938:csi_scm",(void*)f_3938},
{"f_4072:csi_scm",(void*)f_4072},
{"f_4087:csi_scm",(void*)f_4087},
{"f_4126:csi_scm",(void*)f_4126},
{"f_4115:csi_scm",(void*)f_4115},
{"f_4111:csi_scm",(void*)f_4111},
{"f_4094:csi_scm",(void*)f_4094},
{"f_4005:csi_scm",(void*)f_4005},
{"f_4010:csi_scm",(void*)f_4010},
{"f_4014:csi_scm",(void*)f_4014},
{"f_4023:csi_scm",(void*)f_4023},
{"f_4058:csi_scm",(void*)f_4058},
{"f_4050:csi_scm",(void*)f_4050},
{"f_4033:csi_scm",(void*)f_4033},
{"f_3969:csi_scm",(void*)f_3969},
{"f_3972:csi_scm",(void*)f_3972},
{"f_3977:csi_scm",(void*)f_3977},
{"f_3957:csi_scm",(void*)f_3957},
{"f_3944:csi_scm",(void*)f_3944},
{"f_3932:csi_scm",(void*)f_3932},
{"f_3851:csi_scm",(void*)f_3851},
{"f_3862:csi_scm",(void*)f_3862},
{"f_3826:csi_scm",(void*)f_3826},
{"f_3767:csi_scm",(void*)f_3767},
{"f_3781:csi_scm",(void*)f_3781},
{"f_3777:csi_scm",(void*)f_3777},
{"f_3723:csi_scm",(void*)f_3723},
{"f_3629:csi_scm",(void*)f_3629},
{"f_3703:csi_scm",(void*)f_3703},
{"f_3632:csi_scm",(void*)f_3632},
{"f_3700:csi_scm",(void*)f_3700},
{"f_3697:csi_scm",(void*)f_3697},
{"f_3635:csi_scm",(void*)f_3635},
{"f_3647:csi_scm",(void*)f_3647},
{"f_3652:csi_scm",(void*)f_3652},
{"f_3662:csi_scm",(void*)f_3662},
{"f_3677:csi_scm",(void*)f_3677},
{"f_3665:csi_scm",(void*)f_3665},
{"f_3668:csi_scm",(void*)f_3668},
{"f_3569:csi_scm",(void*)f_3569},
{"f_3575:csi_scm",(void*)f_3575},
{"f_3503:csi_scm",(void*)f_3503},
{"f_3374:csi_scm",(void*)f_3374},
{"f_3497:csi_scm",(void*)f_3497},
{"f_3381:csi_scm",(void*)f_3381},
{"f_3386:csi_scm",(void*)f_3386},
{"f_3409:csi_scm",(void*)f_3409},
{"f_3418:csi_scm",(void*)f_3418},
{"f_3482:csi_scm",(void*)f_3482},
{"f_3428:csi_scm",(void*)f_3428},
{"f_3431:csi_scm",(void*)f_3431},
{"f_3172:csi_scm",(void*)f_3172},
{"f_3180:csi_scm",(void*)f_3180},
{"f_3182:csi_scm",(void*)f_3182},
{"f_3186:csi_scm",(void*)f_3186},
{"f_3189:csi_scm",(void*)f_3189},
{"f_3192:csi_scm",(void*)f_3192},
{"f_3209:csi_scm",(void*)f_3209},
{"f_3352:csi_scm",(void*)f_3352},
{"f_3348:csi_scm",(void*)f_3348},
{"f_3344:csi_scm",(void*)f_3344},
{"f_3311:csi_scm",(void*)f_3311},
{"f_3315:csi_scm",(void*)f_3315},
{"f_3320:csi_scm",(void*)f_3320},
{"f_3328:csi_scm",(void*)f_3328},
{"f_3212:csi_scm",(void*)f_3212},
{"f_3240:csi_scm",(void*)f_3240},
{"f_3248:csi_scm",(void*)f_3248},
{"f_3252:csi_scm",(void*)f_3252},
{"f_3256:csi_scm",(void*)f_3256},
{"f_3260:csi_scm",(void*)f_3260},
{"f_3264:csi_scm",(void*)f_3264},
{"f_3215:csi_scm",(void*)f_3215},
{"f_3218:csi_scm",(void*)f_3218},
{"f_3221:csi_scm",(void*)f_3221},
{"f_3224:csi_scm",(void*)f_3224},
{"f_3194:csi_scm",(void*)f_3194},
{"f_3202:csi_scm",(void*)f_3202},
{"f_3045:csi_scm",(void*)f_3045},
{"f_3055:csi_scm",(void*)f_3055},
{"f_3049:csi_scm",(void*)f_3049},
{"f_2754:csi_scm",(void*)f_2754},
{"f_2759:csi_scm",(void*)f_2759},
{"f_2762:csi_scm",(void*)f_2762},
{"f_2765:csi_scm",(void*)f_2765},
{"f_2768:csi_scm",(void*)f_2768},
{"f_2779:csi_scm",(void*)f_2779},
{"f_2783:csi_scm",(void*)f_2783},
{"f_2771:csi_scm",(void*)f_2771},
{"f_2774:csi_scm",(void*)f_2774},
{"f_2731:csi_scm",(void*)f_2731},
{"f_2735:csi_scm",(void*)f_2735},
{"f_2739:csi_scm",(void*)f_2739},
{"f_2742:csi_scm",(void*)f_2742},
{"f_2745:csi_scm",(void*)f_2745},
{"f_2703:csi_scm",(void*)f_2703},
{"f_2707:csi_scm",(void*)f_2707},
{"f_2712:csi_scm",(void*)f_2712},
{"f_2722:csi_scm",(void*)f_2722},
{"f_2729:csi_scm",(void*)f_2729},
{"f_2662:csi_scm",(void*)f_2662},
{"f_2668:csi_scm",(void*)f_2668},
{"f_2684:csi_scm",(void*)f_2684},
{"f_2694:csi_scm",(void*)f_2694},
{"f_2648:csi_scm",(void*)f_2648},
{"f_2656:csi_scm",(void*)f_2656},
{"f_2660:csi_scm",(void*)f_2660},
{"f_2098:csi_scm",(void*)f_2098},
{"f_2115:csi_scm",(void*)f_2115},
{"f_2629:csi_scm",(void*)f_2629},
{"f_2633:csi_scm",(void*)f_2633},
{"f_2623:csi_scm",(void*)f_2623},
{"f_2121:csi_scm",(void*)f_2121},
{"f_2609:csi_scm",(void*)f_2609},
{"f_2585:csi_scm",(void*)f_2585},
{"f_2593:csi_scm",(void*)f_2593},
{"f_2588:csi_scm",(void*)f_2588},
{"f_2566:csi_scm",(void*)f_2566},
{"f_2569:csi_scm",(void*)f_2569},
{"f_2572:csi_scm",(void*)f_2572},
{"f_2535:csi_scm",(void*)f_2535},
{"f_2538:csi_scm",(void*)f_2538},
{"f_2545:csi_scm",(void*)f_2545},
{"f_2519:csi_scm",(void*)f_2519},
{"f_2491:csi_scm",(void*)f_2491},
{"f_2468:csi_scm",(void*)f_2468},
{"f_2481:csi_scm",(void*)f_2481},
{"f_2459:csi_scm",(void*)f_2459},
{"f_2455:csi_scm",(void*)f_2455},
{"f_2429:csi_scm",(void*)f_2429},
{"f_2425:csi_scm",(void*)f_2425},
{"f_2421:csi_scm",(void*)f_2421},
{"f_3016:csi_scm",(void*)f_3016},
{"f_3020:csi_scm",(void*)f_3020},
{"f_3039:csi_scm",(void*)f_3039},
{"f_2408:csi_scm",(void*)f_2408},
{"f_2404:csi_scm",(void*)f_2404},
{"f_2400:csi_scm",(void*)f_2400},
{"f_2948:csi_scm",(void*)f_2948},
{"f_2952:csi_scm",(void*)f_2952},
{"f_2997:csi_scm",(void*)f_2997},
{"f_3004:csi_scm",(void*)f_3004},
{"f_2958:csi_scm",(void*)f_2958},
{"f_2979:csi_scm",(void*)f_2979},
{"f_2983:csi_scm",(void*)f_2983},
{"f_2935:csi_scm",(void*)f_2935},
{"f_2387:csi_scm",(void*)f_2387},
{"f_2383:csi_scm",(void*)f_2383},
{"f_2379:csi_scm",(void*)f_2379},
{"f_2894:csi_scm",(void*)f_2894},
{"f_2898:csi_scm",(void*)f_2898},
{"f_2917:csi_scm",(void*)f_2917},
{"f_2366:csi_scm",(void*)f_2366},
{"f_2362:csi_scm",(void*)f_2362},
{"f_2358:csi_scm",(void*)f_2358},
{"f_2813:csi_scm",(void*)f_2813},
{"f_2817:csi_scm",(void*)f_2817},
{"f_2856:csi_scm",(void*)f_2856},
{"f_2860:csi_scm",(void*)f_2860},
{"f_2871:csi_scm",(void*)f_2871},
{"f_2875:csi_scm",(void*)f_2875},
{"f_2865:csi_scm",(void*)f_2865},
{"f_2800:csi_scm",(void*)f_2800},
{"f_2305:csi_scm",(void*)f_2305},
{"f_2338:csi_scm",(void*)f_2338},
{"f_2342:csi_scm",(void*)f_2342},
{"f_2310:csi_scm",(void*)f_2310},
{"f_2314:csi_scm",(void*)f_2314},
{"f_2325:csi_scm",(void*)f_2325},
{"f_2336:csi_scm",(void*)f_2336},
{"f_2329:csi_scm",(void*)f_2329},
{"f_2319:csi_scm",(void*)f_2319},
{"f_2296:csi_scm",(void*)f_2296},
{"f_2271:csi_scm",(void*)f_2271},
{"f_2279:csi_scm",(void*)f_2279},
{"f_2285:csi_scm",(void*)f_2285},
{"f_2289:csi_scm",(void*)f_2289},
{"f_2274:csi_scm",(void*)f_2274},
{"f_2262:csi_scm",(void*)f_2262},
{"f_2252:csi_scm",(void*)f_2252},
{"f_2255:csi_scm",(void*)f_2255},
{"f_2213:csi_scm",(void*)f_2213},
{"f_2216:csi_scm",(void*)f_2216},
{"f_2219:csi_scm",(void*)f_2219},
{"f_2222:csi_scm",(void*)f_2222},
{"f_2198:csi_scm",(void*)f_2198},
{"f_2201:csi_scm",(void*)f_2201},
{"f_2183:csi_scm",(void*)f_2183},
{"f_2186:csi_scm",(void*)f_2186},
{"f_2165:csi_scm",(void*)f_2165},
{"f_2168:csi_scm",(void*)f_2168},
{"f_2171:csi_scm",(void*)f_2171},
{"f_2142:csi_scm",(void*)f_2142},
{"f_2156:csi_scm",(void*)f_2156},
{"f_2152:csi_scm",(void*)f_2152},
{"f_2145:csi_scm",(void*)f_2145},
{"f_2127:csi_scm",(void*)f_2127},
{"f_2057:csi_scm",(void*)f_2057},
{"f_2061:csi_scm",(void*)f_2061},
{"f_2041:csi_scm",(void*)f_2041},
{"f_2048:csi_scm",(void*)f_2048},
{"f_2028:csi_scm",(void*)f_2028},
{"f_2001:csi_scm",(void*)f_2001},
{"f_1962:csi_scm",(void*)f_1962},
{"f_1986:csi_scm",(void*)f_1986},
{"f_1972:csi_scm",(void*)f_1972},
{"f_1856:csi_scm",(void*)f_1856},
{"f_1860:csi_scm",(void*)f_1860},
{"f_1901:csi_scm",(void*)f_1901},
{"f_1907:csi_scm",(void*)f_1907},
{"f_1914:csi_scm",(void*)f_1914},
{"f_1916:csi_scm",(void*)f_1916},
{"f_1943:csi_scm",(void*)f_1943},
{"f_1926:csi_scm",(void*)f_1926},
{"f_1929:csi_scm",(void*)f_1929},
{"f_1884:csi_scm",(void*)f_1884},
{"f_1898:csi_scm",(void*)f_1898},
{"f_1894:csi_scm",(void*)f_1894},
{"f_1835:csi_scm",(void*)f_1835},
{"f_1808:csi_scm",(void*)f_1808},
{"f_1815:csi_scm",(void*)f_1815},
{"f_1818:csi_scm",(void*)f_1818},
{"f_1824:csi_scm",(void*)f_1824},
{"f_1758:csi_scm",(void*)f_1758},
{"f_1762:csi_scm",(void*)f_1762},
{"f_1771:csi_scm",(void*)f_1771},
{"f_1732:csi_scm",(void*)f_1732},
{"f_1744:csi_scm",(void*)f_1744},
{"f_1699:csi_scm",(void*)f_1699},
{"f_1720:csi_scm",(void*)f_1720},
{"f_1683:csi_scm",(void*)f_1683},
{"f_1687:csi_scm",(void*)f_1687},
{"f_1690:csi_scm",(void*)f_1690},
{"f_1697:csi_scm",(void*)f_1697},
{"f_1655:csi_scm",(void*)f_1655},
{"f_1659:csi_scm",(void*)f_1659},
{"f_1669:csi_scm",(void*)f_1669},
{"f_1662:csi_scm",(void*)f_1662},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
